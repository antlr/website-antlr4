include('shared.lua')
SWEP.DrawCrosshair	= false
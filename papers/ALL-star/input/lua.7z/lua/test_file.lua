local person = {}

person.id = 'kikito'
person.speak = function() return 'hello there!' end

return person

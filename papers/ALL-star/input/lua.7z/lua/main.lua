-- main.lua

local util = require 'util'
util.show_fps()

local Window_spec = require "Window_spec"
Window_spec.run()
# 1 "pltcl.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "pltcl.c"
# 9 "pltcl.c"
# 1 "postgres.h" 1
# 47 "postgres.h"
# 1 "c.h" 1
# 53 "c.h"
# 1 "pg_config.h" 1
# 54 "c.h" 2
# 1 "pg_config_manual.h" 1
# 55 "c.h" 2


# 1 "pg_config_os.h" 1
# 58 "c.h" 2

# 1 "postgres_ext.h" 1
# 29 "postgres_ext.h"
typedef unsigned int Oid;
# 60 "c.h" 2







# 1 "/usr/include/stdio.h" 1 3 4
# 64 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/sys/cdefs.h" 1 3 4
# 417 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 418 "/usr/include/sys/cdefs.h" 2 3 4
# 494 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_posix_availability.h" 1 3 4
# 495 "/usr/include/sys/cdefs.h" 2 3 4
# 65 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/Availability.h" 1 3 4
# 141 "/usr/include/Availability.h" 3 4
# 1 "/usr/include/AvailabilityInternal.h" 1 3 4
# 142 "/usr/include/Availability.h" 2 3 4
# 66 "/usr/include/stdio.h" 2 3 4

# 1 "/usr/include/_types.h" 1 3 4
# 27 "/usr/include/_types.h" 3 4
# 1 "/usr/include/sys/_types.h" 1 3 4
# 33 "/usr/include/sys/_types.h" 3 4
# 1 "/usr/include/machine/_types.h" 1 3 4
# 32 "/usr/include/machine/_types.h" 3 4
# 1 "/usr/include/i386/_types.h" 1 3 4
# 37 "/usr/include/i386/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 70 "/usr/include/i386/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;


typedef long int __darwin_ptrdiff_t;





typedef long unsigned int __darwin_size_t;





typedef __builtin_va_list __darwin_va_list;





typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 33 "/usr/include/machine/_types.h" 2 3 4
# 34 "/usr/include/sys/_types.h" 2 3 4
# 58 "/usr/include/sys/_types.h" 3 4
struct __darwin_pthread_handler_rec
{
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};
struct _opaque_pthread_attr_t { long __sig; char __opaque[56]; };
struct _opaque_pthread_cond_t { long __sig; char __opaque[40]; };
struct _opaque_pthread_condattr_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_mutex_t { long __sig; char __opaque[56]; };
struct _opaque_pthread_mutexattr_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_once_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_rwlock_t { long __sig; char __opaque[192]; };
struct _opaque_pthread_rwlockattr_t { long __sig; char __opaque[16]; };
struct _opaque_pthread_t { long __sig; struct __darwin_pthread_handler_rec *__cleanup_stack; char __opaque[1168]; };
# 94 "/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef struct _opaque_pthread_attr_t
   __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t
   __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t
   __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t
   __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t
   __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t
   __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t
   __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t
   __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t
   *__darwin_pthread_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];
# 28 "/usr/include/_types.h" 2 3 4
# 39 "/usr/include/_types.h" 3 4
typedef int __darwin_nl_item;
typedef int __darwin_wctrans_t;

typedef __uint32_t __darwin_wctype_t;
# 68 "/usr/include/stdio.h" 2 3 4





typedef __darwin_va_list va_list;




typedef __darwin_size_t size_t;






typedef __darwin_off_t fpos_t;
# 96 "/usr/include/stdio.h" 3 4
struct __sbuf {
 unsigned char *_base;
 int _size;
};


struct __sFILEX;
# 130 "/usr/include/stdio.h" 3 4
typedef struct __sFILE {
 unsigned char *_p;
 int _r;
 int _w;
 short _flags;
 short _file;
 struct __sbuf _bf;
 int _lbfsize;


 void *_cookie;
 int (*_close)(void *);
 int (*_read) (void *, char *, int);
 fpos_t (*_seek) (void *, fpos_t, int);
 int (*_write)(void *, const char *, int);


 struct __sbuf _ub;
 struct __sFILEX *_extra;
 int _ur;


 unsigned char _ubuf[3];
 unsigned char _nbuf[1];


 struct __sbuf _lb;


 int _blksize;
 fpos_t _offset;
} FILE;


extern FILE *__stdinp;
extern FILE *__stdoutp;
extern FILE *__stderrp;

# 238 "/usr/include/stdio.h" 3 4

void clearerr(FILE *);
int fclose(FILE *);
int feof(FILE *);
int ferror(FILE *);
int fflush(FILE *);
int fgetc(FILE *);
int fgetpos(FILE * , fpos_t *);
char *fgets(char * , int, FILE *);



FILE *fopen(const char * , const char * ) __asm("_" "fopen" );

int fprintf(FILE * , const char * , ...) __attribute__((__format__ (__printf__, 2, 3)));
int fputc(int, FILE *);
int fputs(const char * , FILE * ) __asm("_" "fputs" );
size_t fread(void * , size_t, size_t, FILE * );
FILE *freopen(const char * , const char * ,
                 FILE * ) __asm("_" "freopen" );
int fscanf(FILE * , const char * , ...) __attribute__((__format__ (__scanf__, 2, 3)));
int fseek(FILE *, long, int);
int fsetpos(FILE *, const fpos_t *);
long ftell(FILE *);
size_t fwrite(const void * , size_t, size_t, FILE * ) __asm("_" "fwrite" );
int getc(FILE *);
int getchar(void);
char *gets(char *);
void perror(const char *);
int printf(const char * , ...) __attribute__((__format__ (__printf__, 1, 2)));
int putc(int, FILE *);
int putchar(int);
int puts(const char *);
int remove(const char *);
int rename (const char *, const char *);
void rewind(FILE *);
int scanf(const char * , ...) __attribute__((__format__ (__scanf__, 1, 2)));
void setbuf(FILE * , char * );
int setvbuf(FILE * , char * , int, size_t);
int sprintf(char * , const char * , ...) __attribute__((__format__ (__printf__, 2, 3)));
int sscanf(const char * , const char * , ...) __attribute__((__format__ (__scanf__, 2, 3)));
FILE *tmpfile(void);
char *tmpnam(char *);
int ungetc(int, FILE *);
int vfprintf(FILE * , const char * , va_list) __attribute__((__format__ (__printf__, 2, 0)));
int vprintf(const char * , va_list) __attribute__((__format__ (__printf__, 1, 0)));
int vsprintf(char * , const char * , va_list) __attribute__((__format__ (__printf__, 2, 0)));

# 296 "/usr/include/stdio.h" 3 4




char *ctermid(char *);





FILE *fdopen(int, const char *) __asm("_" "fdopen" );

int fileno(FILE *);

# 318 "/usr/include/stdio.h" 3 4

int pclose(FILE *);



FILE *popen(const char *, const char *) __asm("_" "popen" );


# 340 "/usr/include/stdio.h" 3 4

int __srget(FILE *);
int __svfscanf(FILE *, const char *, va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int __swbuf(int, FILE *);








static __inline int __sputc(int _c, FILE *_p) {
 if (--_p->_w >= 0 || (_p->_w >= _p->_lbfsize && (char)_c != '\n'))
  return (*_p->_p++ = _c);
 else
  return (__swbuf(_c, _p));
}
# 377 "/usr/include/stdio.h" 3 4

void flockfile(FILE *);
int ftrylockfile(FILE *);
void funlockfile(FILE *);
int getc_unlocked(FILE *);
int getchar_unlocked(void);
int putc_unlocked(int, FILE *);
int putchar_unlocked(int);



int getw(FILE *);
int putw(int, FILE *);


char *tempnam(const char *, const char *) __asm("_" "tempnam" );

# 414 "/usr/include/stdio.h" 3 4
typedef __darwin_off_t off_t;



int fseeko(FILE *, off_t, int);
off_t ftello(FILE *);





int snprintf(char * , size_t, const char * , ...) __attribute__((__format__ (__printf__, 3, 4)));
int vfscanf(FILE * , const char * , va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int vscanf(const char * , va_list) __attribute__((__format__ (__scanf__, 1, 0)));
int vsnprintf(char * , size_t, const char * , va_list) __attribute__((__format__ (__printf__, 3, 0)));
int vsscanf(const char * , const char * , va_list) __attribute__((__format__ (__scanf__, 2, 0)));

# 442 "/usr/include/stdio.h" 3 4
typedef __darwin_ssize_t ssize_t;



int dprintf(int, const char * , ...) __attribute__((__format__ (__printf__, 2, 3))) __attribute__((visibility("default")));
int vdprintf(int, const char * , va_list) __attribute__((__format__ (__printf__, 2, 0))) __attribute__((visibility("default")));
ssize_t getdelim(char ** , size_t * , int, FILE * ) __attribute__((visibility("default")));
ssize_t getline(char ** , size_t * , FILE * ) __attribute__((visibility("default")));









extern const int sys_nerr;
extern const char *const sys_errlist[];

int asprintf(char **, const char *, ...) __attribute__((__format__ (__printf__, 2, 3)));
char *ctermid_r(char *);
char *fgetln(FILE *, size_t *);
const char *fmtcheck(const char *, const char *);
int fpurge(FILE *);
void setbuffer(FILE *, char *, int);
int setlinebuf(FILE *);
int vasprintf(char **, const char *, va_list) __attribute__((__format__ (__printf__, 2, 0)));
FILE *zopen(const char *, const char *, int);





FILE *funopen(const void *,
                 int (*)(void *, char *, int),
                 int (*)(void *, const char *, int),
                 fpos_t (*)(void *, fpos_t, int),
                 int (*)(void *));

# 499 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/secure/_stdio.h" 1 3 4
# 31 "/usr/include/secure/_stdio.h" 3 4
# 1 "/usr/include/secure/_common.h" 1 3 4
# 32 "/usr/include/secure/_stdio.h" 2 3 4
# 45 "/usr/include/secure/_stdio.h" 3 4
extern int __sprintf_chk (char * , int, size_t,
     const char * , ...)
  ;




extern int __snprintf_chk (char * , size_t, int, size_t,
      const char * , ...)
  ;





extern int __vsprintf_chk (char * , int, size_t,
      const char * , va_list)
  ;




extern int __vsnprintf_chk (char * , size_t, int, size_t,
       const char * , va_list)
  ;
# 500 "/usr/include/stdio.h" 2 3 4
# 68 "c.h" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 65 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/sys/wait.h" 1 3 4
# 79 "/usr/include/sys/wait.h" 3 4
typedef enum {
 P_ALL,
 P_PID,
 P_PGID
} idtype_t;






typedef __darwin_pid_t pid_t;




typedef __darwin_id_t id_t;
# 116 "/usr/include/sys/wait.h" 3 4
# 1 "/usr/include/sys/signal.h" 1 3 4
# 73 "/usr/include/sys/signal.h" 3 4
# 1 "/usr/include/sys/appleapiopts.h" 1 3 4
# 74 "/usr/include/sys/signal.h" 2 3 4







# 1 "/usr/include/machine/signal.h" 1 3 4
# 32 "/usr/include/machine/signal.h" 3 4
# 1 "/usr/include/i386/signal.h" 1 3 4
# 39 "/usr/include/i386/signal.h" 3 4
typedef int sig_atomic_t;
# 55 "/usr/include/i386/signal.h" 3 4
# 1 "/usr/include/i386/_structs.h" 1 3 4
# 56 "/usr/include/i386/signal.h" 2 3 4
# 33 "/usr/include/machine/signal.h" 2 3 4
# 82 "/usr/include/sys/signal.h" 2 3 4
# 148 "/usr/include/sys/signal.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 57 "/usr/include/sys/_structs.h" 3 4
# 1 "/usr/include/machine/_structs.h" 1 3 4
# 29 "/usr/include/machine/_structs.h" 3 4
# 1 "/usr/include/i386/_structs.h" 1 3 4
# 38 "/usr/include/i386/_structs.h" 3 4
# 1 "/usr/include/mach/i386/_structs.h" 1 3 4
# 43 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_thread_state
{
    unsigned int __eax;
    unsigned int __ebx;
    unsigned int __ecx;
    unsigned int __edx;
    unsigned int __edi;
    unsigned int __esi;
    unsigned int __ebp;
    unsigned int __esp;
    unsigned int __ss;
    unsigned int __eflags;
    unsigned int __eip;
    unsigned int __cs;
    unsigned int __ds;
    unsigned int __es;
    unsigned int __fs;
    unsigned int __gs;
};
# 89 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_fp_control
{
    unsigned short __invalid :1,
        __denorm :1,
    __zdiv :1,
    __ovrfl :1,
    __undfl :1,
    __precis :1,
      :2,
    __pc :2,





    __rc :2,






             :1,
      :3;
};
typedef struct __darwin_fp_control __darwin_fp_control_t;
# 147 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_fp_status
{
    unsigned short __invalid :1,
        __denorm :1,
    __zdiv :1,
    __ovrfl :1,
    __undfl :1,
    __precis :1,
    __stkflt :1,
    __errsumm :1,
    __c0 :1,
    __c1 :1,
    __c2 :1,
    __tos :3,
    __c3 :1,
    __busy :1;
};
typedef struct __darwin_fp_status __darwin_fp_status_t;
# 191 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_mmst_reg
{
 char __mmst_reg[10];
 char __mmst_rsrv[6];
};
# 210 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_xmm_reg
{
 char __xmm_reg[16];
};
# 232 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_float_state
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;
 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;
 __uint16_t __fpu_rsrv2;
 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;
 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 char __fpu_rsrv4[14*16];
 int __fpu_reserved1;
};


struct __darwin_i386_avx_state
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;
 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;
 __uint16_t __fpu_rsrv2;
 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;
 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 char __fpu_rsrv4[14*16];
 int __fpu_reserved1;
 char __avx_reserved1[64];
 struct __darwin_xmm_reg __fpu_ymmh0;
 struct __darwin_xmm_reg __fpu_ymmh1;
 struct __darwin_xmm_reg __fpu_ymmh2;
 struct __darwin_xmm_reg __fpu_ymmh3;
 struct __darwin_xmm_reg __fpu_ymmh4;
 struct __darwin_xmm_reg __fpu_ymmh5;
 struct __darwin_xmm_reg __fpu_ymmh6;
 struct __darwin_xmm_reg __fpu_ymmh7;
};
# 402 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_exception_state
{
 __uint16_t __trapno;
 __uint16_t __cpu;
 __uint32_t __err;
 __uint32_t __faultvaddr;
};
# 422 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_debug_state32
{
 unsigned int __dr0;
 unsigned int __dr1;
 unsigned int __dr2;
 unsigned int __dr3;
 unsigned int __dr4;
 unsigned int __dr5;
 unsigned int __dr6;
 unsigned int __dr7;
};
# 454 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_thread_state64
{
 __uint64_t __rax;
 __uint64_t __rbx;
 __uint64_t __rcx;
 __uint64_t __rdx;
 __uint64_t __rdi;
 __uint64_t __rsi;
 __uint64_t __rbp;
 __uint64_t __rsp;
 __uint64_t __r8;
 __uint64_t __r9;
 __uint64_t __r10;
 __uint64_t __r11;
 __uint64_t __r12;
 __uint64_t __r13;
 __uint64_t __r14;
 __uint64_t __r15;
 __uint64_t __rip;
 __uint64_t __rflags;
 __uint64_t __cs;
 __uint64_t __fs;
 __uint64_t __gs;
};
# 509 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_float_state64
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;


 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;

 __uint16_t __fpu_rsrv2;


 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;

 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 struct __darwin_xmm_reg __fpu_xmm8;
 struct __darwin_xmm_reg __fpu_xmm9;
 struct __darwin_xmm_reg __fpu_xmm10;
 struct __darwin_xmm_reg __fpu_xmm11;
 struct __darwin_xmm_reg __fpu_xmm12;
 struct __darwin_xmm_reg __fpu_xmm13;
 struct __darwin_xmm_reg __fpu_xmm14;
 struct __darwin_xmm_reg __fpu_xmm15;
 char __fpu_rsrv4[6*16];
 int __fpu_reserved1;
};


struct __darwin_x86_avx_state64
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;


 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;

 __uint16_t __fpu_rsrv2;


 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;

 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 struct __darwin_xmm_reg __fpu_xmm8;
 struct __darwin_xmm_reg __fpu_xmm9;
 struct __darwin_xmm_reg __fpu_xmm10;
 struct __darwin_xmm_reg __fpu_xmm11;
 struct __darwin_xmm_reg __fpu_xmm12;
 struct __darwin_xmm_reg __fpu_xmm13;
 struct __darwin_xmm_reg __fpu_xmm14;
 struct __darwin_xmm_reg __fpu_xmm15;
 char __fpu_rsrv4[6*16];
 int __fpu_reserved1;
 char __avx_reserved1[64];
 struct __darwin_xmm_reg __fpu_ymmh0;
 struct __darwin_xmm_reg __fpu_ymmh1;
 struct __darwin_xmm_reg __fpu_ymmh2;
 struct __darwin_xmm_reg __fpu_ymmh3;
 struct __darwin_xmm_reg __fpu_ymmh4;
 struct __darwin_xmm_reg __fpu_ymmh5;
 struct __darwin_xmm_reg __fpu_ymmh6;
 struct __darwin_xmm_reg __fpu_ymmh7;
 struct __darwin_xmm_reg __fpu_ymmh8;
 struct __darwin_xmm_reg __fpu_ymmh9;
 struct __darwin_xmm_reg __fpu_ymmh10;
 struct __darwin_xmm_reg __fpu_ymmh11;
 struct __darwin_xmm_reg __fpu_ymmh12;
 struct __darwin_xmm_reg __fpu_ymmh13;
 struct __darwin_xmm_reg __fpu_ymmh14;
 struct __darwin_xmm_reg __fpu_ymmh15;
};
# 751 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_exception_state64
{
    __uint16_t __trapno;
    __uint16_t __cpu;
    __uint32_t __err;
    __uint64_t __faultvaddr;
};
# 771 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_debug_state64
{
 __uint64_t __dr0;
 __uint64_t __dr1;
 __uint64_t __dr2;
 __uint64_t __dr3;
 __uint64_t __dr4;
 __uint64_t __dr5;
 __uint64_t __dr6;
 __uint64_t __dr7;
};
# 39 "/usr/include/i386/_structs.h" 2 3 4
# 48 "/usr/include/i386/_structs.h" 3 4
struct __darwin_mcontext32
{
 struct __darwin_i386_exception_state __es;
 struct __darwin_i386_thread_state __ss;
 struct __darwin_i386_float_state __fs;
};


struct __darwin_mcontext_avx32
{
 struct __darwin_i386_exception_state __es;
 struct __darwin_i386_thread_state __ss;
 struct __darwin_i386_avx_state __fs;
};
# 86 "/usr/include/i386/_structs.h" 3 4
struct __darwin_mcontext64
{
 struct __darwin_x86_exception_state64 __es;
 struct __darwin_x86_thread_state64 __ss;
 struct __darwin_x86_float_state64 __fs;
};


struct __darwin_mcontext_avx64
{
 struct __darwin_x86_exception_state64 __es;
 struct __darwin_x86_thread_state64 __ss;
 struct __darwin_x86_avx_state64 __fs;
};
# 127 "/usr/include/i386/_structs.h" 3 4
typedef struct __darwin_mcontext64 *mcontext_t;
# 30 "/usr/include/machine/_structs.h" 2 3 4
# 58 "/usr/include/sys/_structs.h" 2 3 4
# 75 "/usr/include/sys/_structs.h" 3 4
struct __darwin_sigaltstack
{
 void *ss_sp;
 __darwin_size_t ss_size;
 int ss_flags;
};
# 128 "/usr/include/sys/_structs.h" 3 4
struct __darwin_ucontext
{
 int uc_onstack;
 __darwin_sigset_t uc_sigmask;
 struct __darwin_sigaltstack uc_stack;
 struct __darwin_ucontext *uc_link;
 __darwin_size_t uc_mcsize;
 struct __darwin_mcontext64 *uc_mcontext;



};
# 218 "/usr/include/sys/_structs.h" 3 4
typedef struct __darwin_sigaltstack stack_t;
# 227 "/usr/include/sys/_structs.h" 3 4
typedef struct __darwin_ucontext ucontext_t;
# 149 "/usr/include/sys/signal.h" 2 3 4
# 157 "/usr/include/sys/signal.h" 3 4
typedef __darwin_pthread_attr_t pthread_attr_t;




typedef __darwin_sigset_t sigset_t;
# 172 "/usr/include/sys/signal.h" 3 4
typedef __darwin_uid_t uid_t;


union sigval {

 int sival_int;
 void *sival_ptr;
};





struct sigevent {
 int sigev_notify;
 int sigev_signo;
 union sigval sigev_value;
 void (*sigev_notify_function)(union sigval);
 pthread_attr_t *sigev_notify_attributes;
};


typedef struct __siginfo {
 int si_signo;
 int si_errno;
 int si_code;
 pid_t si_pid;
 uid_t si_uid;
 int si_status;
 void *si_addr;
 union sigval si_value;
 long si_band;
 unsigned long __pad[7];
} siginfo_t;
# 286 "/usr/include/sys/signal.h" 3 4
union __sigaction_u {
 void (*__sa_handler)(int);
 void (*__sa_sigaction)(int, struct __siginfo *,
         void *);
};


struct __sigaction {
 union __sigaction_u __sigaction_u;
 void (*sa_tramp)(void *, int, int, siginfo_t *, void *);
 sigset_t sa_mask;
 int sa_flags;
};




struct sigaction {
 union __sigaction_u __sigaction_u;
 sigset_t sa_mask;
 int sa_flags;
};
# 348 "/usr/include/sys/signal.h" 3 4
typedef void (*sig_t)(int);
# 365 "/usr/include/sys/signal.h" 3 4
struct sigvec {
 void (*sv_handler)(int);
 int sv_mask;
 int sv_flags;
};
# 384 "/usr/include/sys/signal.h" 3 4
struct sigstack {
 char *ss_sp;
 int ss_onstack;
};
# 406 "/usr/include/sys/signal.h" 3 4

void (*signal(int, void (*)(int)))(int);

# 117 "/usr/include/sys/wait.h" 2 3 4
# 1 "/usr/include/sys/resource.h" 1 3 4
# 77 "/usr/include/sys/resource.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 100 "/usr/include/sys/_structs.h" 3 4
struct timeval
{
 __darwin_time_t tv_sec;
 __darwin_suseconds_t tv_usec;
};
# 78 "/usr/include/sys/resource.h" 2 3 4
# 89 "/usr/include/sys/resource.h" 3 4
typedef __uint64_t rlim_t;
# 151 "/usr/include/sys/resource.h" 3 4
struct rusage {
 struct timeval ru_utime;
 struct timeval ru_stime;
# 162 "/usr/include/sys/resource.h" 3 4
 long ru_maxrss;

 long ru_ixrss;
 long ru_idrss;
 long ru_isrss;
 long ru_minflt;
 long ru_majflt;
 long ru_nswap;
 long ru_inblock;
 long ru_oublock;
 long ru_msgsnd;
 long ru_msgrcv;
 long ru_nsignals;
 long ru_nvcsw;
 long ru_nivcsw;


};
# 222 "/usr/include/sys/resource.h" 3 4
struct rlimit {
 rlim_t rlim_cur;
 rlim_t rlim_max;
};
# 244 "/usr/include/sys/resource.h" 3 4

int getpriority(int, id_t);

int getiopolicy_np(int, int) __attribute__((visibility("default")));

int getrlimit(int, struct rlimit *) __asm("_" "getrlimit" );
int getrusage(int, struct rusage *);
int setpriority(int, id_t, int);

int setiopolicy_np(int, int, int) __attribute__((visibility("default")));

int setrlimit(int, const struct rlimit *) __asm("_" "setrlimit" );

# 118 "/usr/include/sys/wait.h" 2 3 4
# 193 "/usr/include/sys/wait.h" 3 4
# 1 "/usr/include/machine/endian.h" 1 3 4
# 35 "/usr/include/machine/endian.h" 3 4
# 1 "/usr/include/i386/endian.h" 1 3 4
# 99 "/usr/include/i386/endian.h" 3 4
# 1 "/usr/include/sys/_endian.h" 1 3 4
# 124 "/usr/include/sys/_endian.h" 3 4
# 1 "/usr/include/libkern/_OSByteOrder.h" 1 3 4
# 66 "/usr/include/libkern/_OSByteOrder.h" 3 4
# 1 "/usr/include/libkern/i386/_OSByteOrder.h" 1 3 4
# 44 "/usr/include/libkern/i386/_OSByteOrder.h" 3 4
static __inline__
__uint16_t
_OSSwapInt16(
    __uint16_t _data
)
{
    return ((_data << 8) | (_data >> 8));
}

static __inline__
__uint32_t
_OSSwapInt32(
    __uint32_t _data
)
{

    return __builtin_bswap32(_data);




}


static __inline__
__uint64_t
_OSSwapInt64(
    __uint64_t _data
)
{
    return __builtin_bswap64(_data);
}
# 67 "/usr/include/libkern/_OSByteOrder.h" 2 3 4
# 125 "/usr/include/sys/_endian.h" 2 3 4
# 100 "/usr/include/i386/endian.h" 2 3 4
# 36 "/usr/include/machine/endian.h" 2 3 4
# 194 "/usr/include/sys/wait.h" 2 3 4







union wait {
 int w_status;



 struct {

  unsigned int w_Termsig:7,
    w_Coredump:1,
    w_Retcode:8,
    w_Filler:16;







 } w_T;





 struct {

  unsigned int w_Stopval:8,
    w_Stopsig:8,
    w_Filler:16;






 } w_S;
};
# 254 "/usr/include/sys/wait.h" 3 4

pid_t wait(int *) __asm("_" "wait" );
pid_t waitpid(pid_t, int *, int) __asm("_" "waitpid" );

int waitid(idtype_t, id_t, siginfo_t *, int) __asm("_" "waitid" );


pid_t wait3(int *, int, struct rusage *);
pid_t wait4(pid_t, int *, int, struct rusage *);


# 66 "/usr/include/stdlib.h" 2 3 4

# 1 "/usr/include/alloca.h" 1 3 4
# 35 "/usr/include/alloca.h" 3 4

void *alloca(size_t);

# 68 "/usr/include/stdlib.h" 2 3 4
# 81 "/usr/include/stdlib.h" 3 4
typedef __darwin_ct_rune_t ct_rune_t;




typedef __darwin_rune_t rune_t;






typedef __darwin_wchar_t wchar_t;



typedef struct {
 int quot;
 int rem;
} div_t;

typedef struct {
 long quot;
 long rem;
} ldiv_t;


typedef struct {
 long long quot;
 long long rem;
} lldiv_t;
# 134 "/usr/include/stdlib.h" 3 4
extern int __mb_cur_max;
# 144 "/usr/include/stdlib.h" 3 4

void abort(void) __attribute__((__noreturn__));
int abs(int) __attribute__((__const__));
int atexit(void (*)(void));
double atof(const char *);
int atoi(const char *);
long atol(const char *);

long long
  atoll(const char *);

void *bsearch(const void *, const void *, size_t,
     size_t, int (*)(const void *, const void *));
void *calloc(size_t, size_t);
div_t div(int, int) __attribute__((__const__));
void exit(int) __attribute__((__noreturn__));
void free(void *);
char *getenv(const char *);
long labs(long) __attribute__((__const__));
ldiv_t ldiv(long, long) __attribute__((__const__));

long long
  llabs(long long);
lldiv_t lldiv(long long, long long);

void *malloc(size_t);
int mblen(const char *, size_t);
size_t mbstowcs(wchar_t * , const char * , size_t);
int mbtowc(wchar_t * , const char * , size_t);
int posix_memalign(void **, size_t, size_t) __attribute__((visibility("default")));
void qsort(void *, size_t, size_t,
     int (*)(const void *, const void *));
int rand(void);
void *realloc(void *, size_t);
void srand(unsigned);
double strtod(const char *, char **) __asm("_" "strtod" );
float strtof(const char *, char **) __asm("_" "strtof" );
long strtol(const char *, char **, int);
long double
  strtold(const char *, char **) ;

long long
  strtoll(const char *, char **, int);

unsigned long
  strtoul(const char *, char **, int);

unsigned long long
  strtoull(const char *, char **, int);

int system(const char *) __asm("_" "system" );
size_t wcstombs(char * , const wchar_t * , size_t);
int wctomb(char *, wchar_t);


void _Exit(int) __attribute__((__noreturn__));
long a64l(const char *);
double drand48(void);
char *ecvt(double, int, int *, int *);
double erand48(unsigned short[3]);
char *fcvt(double, int, int *, int *);
char *gcvt(double, int, char *);
int getsubopt(char **, char * const *, char **);
int grantpt(int);

char *initstate(unsigned, char *, size_t);



long jrand48(unsigned short[3]);
char *l64a(long);
void lcong48(unsigned short[7]);
long lrand48(void);
char *mktemp(char *);
int mkstemp(char *);
long mrand48(void);
long nrand48(unsigned short[3]);
int posix_openpt(int);
char *ptsname(int);
int putenv(char *) __asm("_" "putenv" );
long random(void);
int rand_r(unsigned *);

char *realpath(const char * , char * ) __asm("_" "realpath" "$DARWIN_EXTSN");



unsigned short
 *seed48(unsigned short[3]);
int setenv(const char *, const char *, int) __asm("_" "setenv" );

void setkey(const char *) __asm("_" "setkey" );



char *setstate(const char *);
void srand48(long);

void srandom(unsigned);



int unlockpt(int);

int unsetenv(const char *) __asm("_" "unsetenv" );






# 1 "/usr/include/machine/types.h" 1 3 4
# 35 "/usr/include/machine/types.h" 3 4
# 1 "/usr/include/i386/types.h" 1 3 4
# 70 "/usr/include/i386/types.h" 3 4
# 1 "/usr/include/i386/_types.h" 1 3 4
# 71 "/usr/include/i386/types.h" 2 3 4







typedef signed char int8_t;

typedef unsigned char u_int8_t;


typedef short int16_t;

typedef unsigned short u_int16_t;


typedef int int32_t;

typedef unsigned int u_int32_t;


typedef long long int64_t;

typedef unsigned long long u_int64_t;


typedef int64_t register_t;






typedef __darwin_intptr_t intptr_t;



typedef unsigned long uintptr_t;




typedef u_int64_t user_addr_t;
typedef u_int64_t user_size_t;
typedef int64_t user_ssize_t;
typedef int64_t user_long_t;
typedef u_int64_t user_ulong_t;
typedef int64_t user_time_t;
typedef int64_t user_off_t;







typedef u_int64_t syscall_arg_t;
# 36 "/usr/include/machine/types.h" 2 3 4
# 256 "/usr/include/stdlib.h" 2 3 4


typedef __darwin_dev_t dev_t;




typedef __darwin_mode_t mode_t;



u_int32_t
  arc4random(void);
void arc4random_addrandom(unsigned char * , int );
void arc4random_buf(void * , size_t ) __attribute__((visibility("default")));
void arc4random_stir(void);
u_int32_t
  arc4random_uniform(u_int32_t ) __attribute__((visibility("default")));

int atexit_b(void (^)(void)) __attribute__((visibility("default")));
void *bsearch_b(const void *, const void *, size_t,
     size_t, int (^)(const void *, const void *)) __attribute__((visibility("default")));



char *cgetcap(char *, const char *, int);
int cgetclose(void);
int cgetent(char **, char **, const char *);
int cgetfirst(char **, char **);
int cgetmatch(const char *, const char *);
int cgetnext(char **, char **);
int cgetnum(char *, const char *, long *);
int cgetset(const char *);
int cgetstr(char *, const char *, char **);
int cgetustr(char *, const char *, char **);

int daemon(int, int) __asm("_" "daemon" "$1050") __attribute__((deprecated,visibility("default")));
char *devname(dev_t, mode_t);
char *devname_r(dev_t, mode_t, char *buf, int len);
char *getbsize(int *, long *);
int getloadavg(double [], int);
const char
 *getprogname(void);

int heapsort(void *, size_t, size_t,
     int (*)(const void *, const void *));

int heapsort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

int mergesort(void *, size_t, size_t,
     int (*)(const void *, const void *));

int mergesort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void psort(void *, size_t, size_t,
     int (*)(const void *, const void *)) __attribute__((visibility("default")));

void psort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void psort_r(void *, size_t, size_t, void *,
     int (*)(void *, const void *, const void *)) __attribute__((visibility("default")));

void qsort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void qsort_r(void *, size_t, size_t, void *,
     int (*)(void *, const void *, const void *));
int radixsort(const unsigned char **, int, const unsigned char *,
     unsigned);
void setprogname(const char *);
int sradixsort(const unsigned char **, int, const unsigned char *,
     unsigned);
void sranddev(void);
void srandomdev(void);
void *reallocf(void *, size_t);

long long
  strtoq(const char *, char **, int);
unsigned long long
  strtouq(const char *, char **, int);

extern char *suboptarg;
void *valloc(size_t);







# 69 "c.h" 2
# 1 "/usr/include/string.h" 1 3 4
# 79 "/usr/include/string.h" 3 4

void *memchr(const void *, int, size_t);
int memcmp(const void *, const void *, size_t);
void *memcpy(void *, const void *, size_t);
void *memmove(void *, const void *, size_t);
void *memset(void *, int, size_t);
char *strcat(char *, const char *);
char *strchr(const char *, int);
int strcmp(const char *, const char *);
int strcoll(const char *, const char *);
char *strcpy(char *, const char *);
size_t strcspn(const char *, const char *);
char *strerror(int) __asm("_" "strerror" );
size_t strlen(const char *);
char *strncat(char *, const char *, size_t);
int strncmp(const char *, const char *, size_t);
char *strncpy(char *, const char *, size_t);
char *strpbrk(const char *, const char *);
char *strrchr(const char *, int);
size_t strspn(const char *, const char *);
char *strstr(const char *, const char *);
char *strtok(char *, const char *);
size_t strxfrm(char *, const char *, size_t);

# 113 "/usr/include/string.h" 3 4

char *strtok_r(char *, const char *, char **);

# 125 "/usr/include/string.h" 3 4

int strerror_r(int, char *, size_t);
char *strdup(const char *);
void *memccpy(void *, const void *, int, size_t);

# 139 "/usr/include/string.h" 3 4

char *stpcpy(char *, const char *);
char *stpncpy(char *, const char *, size_t) __attribute__((visibility("default")));
char *strndup(const char *, size_t) __attribute__((visibility("default")));
size_t strnlen(const char *, size_t) __attribute__((visibility("default")));
char *strsignal(int sig);

# 158 "/usr/include/string.h" 3 4

void *memmem(const void *, size_t, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern4(void *, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern8(void *, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern16(void *, const void *, size_t) __attribute__((visibility("default")));

char *strcasestr(const char *, const char *);
char *strnstr(const char *, const char *, size_t);
size_t strlcat(char *, const char *, size_t);
size_t strlcpy(char *, const char *, size_t);
void strmode(int, char *);
char *strsep(char **, const char *);


void swab(const void * , void * , ssize_t);







# 1 "/usr/include/strings.h" 1 3 4
# 71 "/usr/include/strings.h" 3 4



int bcmp(const void *, const void *, size_t) ;
void bcopy(const void *, void *, size_t) ;
void bzero(void *, size_t) ;
char *index(const char *, int) ;
char *rindex(const char *, int) ;


int ffs(int);
int strcasecmp(const char *, const char *);
int strncasecmp(const char *, const char *, size_t);





int ffsl(long) __attribute__((visibility("default")));
int fls(int) __attribute__((visibility("default")));
int flsl(long) __attribute__((visibility("default")));


# 1 "/usr/include/string.h" 1 3 4
# 95 "/usr/include/strings.h" 2 3 4
# 181 "/usr/include/string.h" 2 3 4
# 190 "/usr/include/string.h" 3 4
# 1 "/usr/include/secure/_string.h" 1 3 4
# 58 "/usr/include/secure/_string.h" 3 4
static __inline void *
__inline_memcpy_chk (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memcpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 0));
}






static __inline void *
__inline_memmove_chk (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memmove_chk (__dest, __src, __len, __builtin_object_size (__dest, 0));
}






static __inline void *
__inline_memset_chk (void *__dest, int __val, size_t __len)
{
  return __builtin___memset_chk (__dest, __val, __len, __builtin_object_size (__dest, 0));
}






static __inline char *
__inline_strcpy_chk (char * __dest, const char * __src)
{
  return __builtin___strcpy_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_stpcpy_chk (char *__dest, const char *__src)
{
  return __builtin___stpcpy_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}






static __inline char *
__inline_stpncpy_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___stpncpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_strncpy_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___strncpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}






static __inline char *
__inline_strcat_chk (char * __dest, const char * __src)
{
  return __builtin___strcat_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_strncat_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___strncat_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}
# 191 "/usr/include/string.h" 2 3 4
# 70 "c.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stddef.h" 1 3 4
# 152 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 71 "c.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stdarg.h" 1 3 4
# 43 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 72 "c.h" 2

# 1 "./strings.h" 1
char *s1,
     *s2,
     *s3,
     *s4,
     *s5,
     *s6;
# 74 "c.h" 2


# 1 "/usr/include/stdint.h" 1 3 4
# 40 "/usr/include/stdint.h" 3 4
typedef unsigned char uint8_t;




typedef unsigned short uint16_t;




typedef unsigned int uint32_t;




typedef unsigned long long uint64_t;



typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;
# 97 "/usr/include/stdint.h" 3 4
typedef long int intmax_t;
# 106 "/usr/include/stdint.h" 3 4
typedef long unsigned int uintmax_t;
# 77 "c.h" 2

# 1 "/usr/include/sys/types.h" 1 3 4
# 84 "/usr/include/sys/types.h" 3 4
typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned int u_int;

typedef unsigned long u_long;


typedef unsigned short ushort;
typedef unsigned int uint;


typedef u_int64_t u_quad_t;
typedef int64_t quad_t;
typedef quad_t * qaddr_t;

typedef char * caddr_t;
typedef int32_t daddr_t;






typedef u_int32_t fixpt_t;


typedef __darwin_blkcnt_t blkcnt_t;




typedef __darwin_blksize_t blksize_t;




typedef __darwin_gid_t gid_t;





typedef __uint32_t in_addr_t;




typedef __uint16_t in_port_t;



typedef __darwin_ino_t ino_t;





typedef __darwin_ino64_t ino64_t;






typedef __int32_t key_t;
# 157 "/usr/include/sys/types.h" 3 4
typedef __uint16_t nlink_t;
# 176 "/usr/include/sys/types.h" 3 4
typedef int32_t segsz_t;
typedef int32_t swblk_t;
# 223 "/usr/include/sys/types.h" 3 4
typedef __darwin_clock_t clock_t;
# 240 "/usr/include/sys/types.h" 3 4
typedef __darwin_time_t time_t;




typedef __darwin_useconds_t useconds_t;




typedef __darwin_suseconds_t suseconds_t;
# 260 "/usr/include/sys/types.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 183 "/usr/include/sys/_structs.h" 3 4

typedef struct fd_set {
 __int32_t fds_bits[((((1024) % ((sizeof(__int32_t) * 8))) == 0) ? ((1024) / ((sizeof(__int32_t) * 8))) : (((1024) / ((sizeof(__int32_t) * 8))) + 1))];
} fd_set;



static __inline int
__darwin_fd_isset(int _n, const struct fd_set *_p)
{
 return (_p->fds_bits[_n/(sizeof(__int32_t) * 8)] & (1<<(_n % (sizeof(__int32_t) * 8))));
}
# 261 "/usr/include/sys/types.h" 2 3 4




typedef __int32_t fd_mask;
# 322 "/usr/include/sys/types.h" 3 4
typedef __darwin_pthread_cond_t pthread_cond_t;



typedef __darwin_pthread_condattr_t pthread_condattr_t;



typedef __darwin_pthread_mutex_t pthread_mutex_t;



typedef __darwin_pthread_mutexattr_t pthread_mutexattr_t;



typedef __darwin_pthread_once_t pthread_once_t;



typedef __darwin_pthread_rwlock_t pthread_rwlock_t;



typedef __darwin_pthread_rwlockattr_t pthread_rwlockattr_t;



typedef __darwin_pthread_t pthread_t;






typedef __darwin_pthread_key_t pthread_key_t;





typedef __darwin_fsblkcnt_t fsblkcnt_t;




typedef __darwin_fsfilcnt_t fsfilcnt_t;
# 79 "c.h" 2

# 1 "/usr/include/errno.h" 1 3 4
# 23 "/usr/include/errno.h" 3 4
# 1 "/usr/include/sys/errno.h" 1 3 4
# 74 "/usr/include/sys/errno.h" 3 4

extern int * __error(void);


# 24 "/usr/include/errno.h" 2 3 4
# 81 "c.h" 2
# 91 "c.h"
# 1 "/usr/include/locale.h" 1 3 4
# 40 "/usr/include/locale.h" 3 4
# 1 "/usr/include/_locale.h" 1 3 4
# 43 "/usr/include/_locale.h" 3 4
struct lconv {
 char *decimal_point;
 char *thousands_sep;
 char *grouping;
 char *int_curr_symbol;
 char *currency_symbol;
 char *mon_decimal_point;
 char *mon_thousands_sep;
 char *mon_grouping;
 char *positive_sign;
 char *negative_sign;
 char int_frac_digits;
 char frac_digits;
 char p_cs_precedes;
 char p_sep_by_space;
 char n_cs_precedes;
 char n_sep_by_space;
 char p_sign_posn;
 char n_sign_posn;
 char int_p_cs_precedes;
 char int_n_cs_precedes;
 char int_p_sep_by_space;
 char int_n_sep_by_space;
 char int_p_sign_posn;
 char int_n_sign_posn;
};






struct lconv *localeconv(void);

# 41 "/usr/include/locale.h" 2 3 4
# 52 "/usr/include/locale.h" 3 4

char *setlocale(int, const char *);

# 92 "c.h" 2
# 181 "c.h"
typedef char bool;
# 193 "c.h"
typedef bool *BoolPtr;
# 224 "c.h"
typedef char *Pointer;
# 233 "c.h"
typedef signed char int8;
typedef signed short int16;
typedef signed int int32;
# 245 "c.h"
typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;






typedef uint8 bits8;
typedef uint16 bits16;
typedef uint32 bits32;
# 265 "c.h"
typedef long int int64;


typedef unsigned long int uint64;
# 308 "c.h"
typedef size_t Size;
# 317 "c.h"
typedef unsigned int Index;
# 327 "c.h"
typedef signed int Offset;




typedef int16 int2;
typedef int32 int4;
typedef float float4;
typedef double float8;
# 348 "c.h"
typedef Oid regproc;
typedef regproc RegProcedure;

typedef uint32 TransactionId;

typedef uint32 LocalTransactionId;

typedef uint32 SubTransactionId;





typedef TransactionId MultiXactId;

typedef uint32 MultiXactOffset;

typedef uint32 CommandId;







typedef struct
{
 int indx[6];
} IntArray;
# 391 "c.h"
struct varlena
{
 char vl_len_[4];
 char vl_dat[1];
};
# 404 "c.h"
typedef struct varlena bytea;
typedef struct varlena text;
typedef struct varlena BpChar;
typedef struct varlena VarChar;
# 419 "c.h"
typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
 int dim1;
 int lbound1;
 int2 values[1];
} int2vector;

typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
 int dim1;
 int lbound1;
 Oid values[1];
} oidvector;





typedef struct nameData
{
 char data[64];
} NameData;
typedef NameData *Name;
# 829 "c.h"
extern int fdatasync(int fildes);
# 860 "c.h"
# 1 "port.h" 1
# 16 "port.h"
# 1 "/usr/include/ctype.h" 1 3 4
# 69 "/usr/include/ctype.h" 3 4
# 1 "/usr/include/runetype.h" 1 3 4
# 70 "/usr/include/runetype.h" 3 4
typedef __darwin_wint_t wint_t;
# 81 "/usr/include/runetype.h" 3 4
typedef struct {
 __darwin_rune_t __min;
 __darwin_rune_t __max;
 __darwin_rune_t __map;
 __uint32_t *__types;
} _RuneEntry;

typedef struct {
 int __nranges;
 _RuneEntry *__ranges;
} _RuneRange;

typedef struct {
 char __name[14];
 __uint32_t __mask;
} _RuneCharClass;

typedef struct {
 char __magic[8];
 char __encoding[32];

 __darwin_rune_t (*__sgetrune)(const char *, __darwin_size_t, char const **);
 int (*__sputrune)(__darwin_rune_t, char *, __darwin_size_t, char **);
 __darwin_rune_t __invalid_rune;

 __uint32_t __runetype[(1 <<8 )];
 __darwin_rune_t __maplower[(1 <<8 )];
 __darwin_rune_t __mapupper[(1 <<8 )];






 _RuneRange __runetype_ext;
 _RuneRange __maplower_ext;
 _RuneRange __mapupper_ext;

 void *__variable;
 int __variable_len;




 int __ncharclasses;
 _RuneCharClass *__charclasses;
} _RuneLocale;




extern _RuneLocale _DefaultRuneLocale;
extern _RuneLocale *_CurrentRuneLocale;

# 70 "/usr/include/ctype.h" 2 3 4
# 145 "/usr/include/ctype.h" 3 4

unsigned long ___runetype(__darwin_ct_rune_t);
__darwin_ct_rune_t ___tolower(__darwin_ct_rune_t);
__darwin_ct_rune_t ___toupper(__darwin_ct_rune_t);


static __inline int
isascii(int _c)
{
 return ((_c & ~0x7F) == 0);
}
# 164 "/usr/include/ctype.h" 3 4

int __maskrune(__darwin_ct_rune_t, unsigned long);



static __inline int
__istype(__darwin_ct_rune_t _c, unsigned long _f)
{



 return (isascii(_c) ? !!(_DefaultRuneLocale.__runetype[_c] & _f)
  : !!__maskrune(_c, _f));

}

static __inline __darwin_ct_rune_t
__isctype(__darwin_ct_rune_t _c, unsigned long _f)
{



 return (_c < 0 || _c >= (1 <<8 )) ? 0 :
  !!(_DefaultRuneLocale.__runetype[_c] & _f);

}
# 204 "/usr/include/ctype.h" 3 4

__darwin_ct_rune_t __toupper(__darwin_ct_rune_t);
__darwin_ct_rune_t __tolower(__darwin_ct_rune_t);



static __inline int
__wcwidth(__darwin_ct_rune_t _c)
{
 unsigned int _x;

 if (_c == 0)
  return (0);
 _x = (unsigned int)__maskrune(_c, 0xe0000000L|0x00040000L);
 if ((_x & 0xe0000000L) != 0)
  return ((_x & 0xe0000000L) >> 30);
 return ((_x & 0x00040000L) != 0 ? 1 : -1);
}






static __inline int
isalnum(int _c)
{
 return (__istype(_c, 0x00000100L|0x00000400L));
}

static __inline int
isalpha(int _c)
{
 return (__istype(_c, 0x00000100L));
}

static __inline int
isblank(int _c)
{
 return (__istype(_c, 0x00020000L));
}

static __inline int
iscntrl(int _c)
{
 return (__istype(_c, 0x00000200L));
}


static __inline int
isdigit(int _c)
{
 return (__isctype(_c, 0x00000400L));
}

static __inline int
isgraph(int _c)
{
 return (__istype(_c, 0x00000800L));
}

static __inline int
islower(int _c)
{
 return (__istype(_c, 0x00001000L));
}

static __inline int
isprint(int _c)
{
 return (__istype(_c, 0x00040000L));
}

static __inline int
ispunct(int _c)
{
 return (__istype(_c, 0x00002000L));
}

static __inline int
isspace(int _c)
{
 return (__istype(_c, 0x00004000L));
}

static __inline int
isupper(int _c)
{
 return (__istype(_c, 0x00008000L));
}


static __inline int
isxdigit(int _c)
{
 return (__isctype(_c, 0x00010000L));
}

static __inline int
toascii(int _c)
{
 return (_c & 0x7F);
}

static __inline int
tolower(int _c)
{
        return (__tolower(_c));
}

static __inline int
toupper(int _c)
{
        return (__toupper(_c));
}


static __inline int
digittoint(int _c)
{
 return (__maskrune(_c, 0x0F));
}

static __inline int
ishexnumber(int _c)
{
 return (__istype(_c, 0x00010000L));
}

static __inline int
isideogram(int _c)
{
 return (__istype(_c, 0x00080000L));
}

static __inline int
isnumber(int _c)
{
 return (__istype(_c, 0x00000400L));
}

static __inline int
isphonogram(int _c)
{
 return (__istype(_c, 0x00200000L));
}

static __inline int
isrune(int _c)
{
 return (__istype(_c, 0xFFFFFFF0L));
}

static __inline int
isspecial(int _c)
{
 return (__istype(_c, 0x00100000L));
}
# 17 "port.h" 2
# 1 "./netdb.h" 1
# 18 "port.h" 2
# 1 "./pwd.h" 1
# 19 "port.h" 2



typedef int pgsocket;
# 32 "port.h"
extern bool pg_set_noblock(pgsocket sock);
extern bool pg_set_block(pgsocket sock);



extern bool has_drive_prefix(const char *filename);
extern char *first_dir_separator(const char *filename);
extern char *last_dir_separator(const char *filename);
extern char *first_path_var_separator(const char *pathlist);
extern void join_path_components(char *ret_path,
      const char *head, const char *tail);
extern void canonicalize_path(char *path);
extern void make_native_path(char *path);
extern bool path_contains_parent_reference(const char *path);
extern bool path_is_relative_and_below_cwd(const char *path);
extern bool path_is_prefix_of_path(const char *path1, const char *path2);
extern const char *get_progname(const char *argv0);
extern void get_share_path(const char *my_exec_path, char *ret_path);
extern void get_etc_path(const char *my_exec_path, char *ret_path);
extern void get_include_path(const char *my_exec_path, char *ret_path);
extern void get_pkginclude_path(const char *my_exec_path, char *ret_path);
extern void get_includeserver_path(const char *my_exec_path, char *ret_path);
extern void get_lib_path(const char *my_exec_path, char *ret_path);
extern void get_pkglib_path(const char *my_exec_path, char *ret_path);
extern void get_locale_path(const char *my_exec_path, char *ret_path);
extern void get_doc_path(const char *my_exec_path, char *ret_path);
extern void get_html_path(const char *my_exec_path, char *ret_path);
extern void get_man_path(const char *my_exec_path, char *ret_path);
extern bool get_home_path(char *ret_path);
extern void get_parent_directory(char *path);


extern char **pgfnames(const char *path);
extern void pgfnames_cleanup(char **filenames);
# 92 "port.h"
extern void set_pglocale_pgservice(const char *argv0, const char *app);


extern int find_my_exec(const char *argv0, char *retpath);
extern int find_other_exec(const char *argv0, const char *target,
    const char *versionstr, char *retpath);
# 149 "port.h"
extern void pg_usleep(long microsec);


extern int pg_strcasecmp(const char *s1, const char *s2);
extern int pg_strncasecmp(const char *s1, const char *s2, size_t n);
extern unsigned char pg_toupper(unsigned char ch);
extern unsigned char pg_tolower(unsigned char ch);
extern unsigned char pg_ascii_toupper(unsigned char ch);
extern unsigned char pg_ascii_tolower(unsigned char ch);
# 247 "port.h"
extern char *simple_prompt(const char *prompt, int maxlen, bool echo);







extern int pclose_check(FILE *stream);
# 300 "port.h"
extern bool rmtree(const char *path, bool rmtopdir);
# 372 "port.h"
extern double pg_erand48(unsigned short xseed[3]);
extern long pg_lrand48(void);
extern void pg_srand48(long seed);
# 428 "port.h"
extern char *pqStrerror(int errnum, char *strerrbuf, size_t buflen);


extern int pqGetpwuid(uid_t uid, struct passwd * resultbuf, char *buffer,
     size_t buflen, struct passwd ** result);


extern int pqGethostbyname(const char *name,
    struct hostent * resultbuf,
    char *buffer, size_t buflen,
    struct hostent ** result,
    int *herrno);

extern void pg_qsort(void *base, size_t nel, size_t elsize,
   int (*cmp) (const void *, const void *));



typedef int (*qsort_arg_comparator) (const void *a, const void *b, void *arg);

extern void qsort_arg(void *base, size_t nel, size_t elsize,
    qsort_arg_comparator cmp, void *arg);


extern int pg_get_encoding_from_locale(const char *ctype, bool write_message);


extern char *inet_net_ntop(int af, const void *src, int bits,
     char *dst, size_t size);


extern int pg_check_dir(const char *dir);


extern int pg_mkdir_p(char *path, int omode);
# 861 "c.h" 2
# 48 "postgres.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
# 1 "/usr/include/setjmp.h" 1 3 4
# 26 "/usr/include/setjmp.h" 3 4
# 1 "/usr/include/machine/setjmp.h" 1 3 4
# 35 "/usr/include/machine/setjmp.h" 3 4
# 1 "/usr/include/i386/setjmp.h" 1 3 4
# 47 "/usr/include/i386/setjmp.h" 3 4
typedef int jmp_buf[((9 * 2) + 3 + 16)];
typedef int sigjmp_buf[((9 * 2) + 3 + 16) + 1];
# 65 "/usr/include/i386/setjmp.h" 3 4

int setjmp(jmp_buf);
void longjmp(jmp_buf, int);


int _setjmp(jmp_buf);
void _longjmp(jmp_buf, int);
int sigsetjmp(sigjmp_buf, int);
void siglongjmp(sigjmp_buf, int);



void longjmperror(void);


# 36 "/usr/include/machine/setjmp.h" 2 3 4
# 27 "/usr/include/setjmp.h" 2 3 4
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h" 2
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/errcodes.h" 1
# 70 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h" 2
# 114 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
extern bool errstart(int elevel, const char *filename, int lineno,
   const char *funcname, const char *domain);
extern void errfinish(int dummy,...);

extern int errcode(int sqlerrcode);

extern int errcode_for_file_access(void);
extern int errcode_for_socket_access(void);

extern int
errmsg(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errmsg_internal(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errmsg_plural(const char *fmt_singular, const char *fmt_plural,
     unsigned long n,...)


__attribute__((format(printf, 1, 4)))
__attribute__((format(printf, 2, 4)));

extern int
errdetail(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errdetail_internal(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errdetail_log(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errdetail_plural(const char *fmt_singular, const char *fmt_plural,
     unsigned long n,...)


__attribute__((format(printf, 1, 4)))
__attribute__((format(printf, 2, 4)));

extern int
errhint(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errcontext(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int errhidestmt(bool hide_stmt);

extern int errfunction(const char *funcname);
extern int errposition(int cursorpos);

extern int internalerrposition(int cursorpos);
extern int internalerrquery(const char *query);

extern int geterrcode(void);
extern int geterrposition(void);
extern int getinternalerrposition(void);
# 201 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
extern void elog_start(const char *filename, int lineno, const char *funcname);
extern void
elog_finish(int elevel, const char *fmt,...)


__attribute__((format(printf, 2, 3)));




extern void pre_format_elog_string(int errnumber, const char *domain);
extern char *
format_elog_string(const char *fmt,...)


__attribute__((format(printf, 1, 2)));




typedef struct ErrorContextCallback
{
 struct ErrorContextCallback *previous;
 void (*callback) (void *arg);
 void *arg;
} ErrorContextCallback;

extern ErrorContextCallback *error_context_stack;
# 296 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
extern sigjmp_buf *PG_exception_stack;
# 307 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
typedef struct ErrorData
{
 int elevel;
 bool output_to_server;
 bool output_to_client;
 bool show_funcname;
 bool hide_stmt;
 const char *filename;
 int lineno;
 const char *funcname;
 const char *domain;
 int sqlerrcode;
 char *message;
 char *detail;
 char *detail_log;
 char *hint;
 char *context;
 int cursorpos;
 int internalpos;
 char *internalquery;
 int saved_errno;
} ErrorData;

extern void EmitErrorReport(void);
extern ErrorData *CopyErrorData(void);
extern void FreeErrorData(ErrorData *edata);
extern void FlushErrorState(void);
extern void ReThrowError(ErrorData *edata) __attribute__((noreturn));
extern void pg_re_throw(void) __attribute__((noreturn));


typedef void (*emit_log_hook_type) (ErrorData *edata);
extern emit_log_hook_type emit_log_hook;




typedef enum
{
 PGERROR_TERSE,
 PGERROR_DEFAULT,
 PGERROR_VERBOSE
} PGErrorVerbosity;

extern int Log_error_verbosity;
extern char *Log_line_prefix;
extern int Log_destination;
# 362 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
extern void DebugFileOpen(void);
extern char *unpack_sql_state(int sql_state);
extern bool in_error_recursion_trouble(void);


extern void set_syslog_parameters(const char *ident, int facility);







extern void
write_stderr(const char *fmt,...)


__attribute__((format(printf, 1, 2)));
# 49 "postgres.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h" 1
# 36 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h"
typedef struct MemoryContextData *MemoryContext;






extern MemoryContext CurrentMemoryContext;




extern void *MemoryContextAlloc(MemoryContext context, Size size);
extern void *MemoryContextAllocZero(MemoryContext context, Size size);
extern void *MemoryContextAllocZeroAligned(MemoryContext context, Size size);
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h"
extern void pfree(void *pointer);

extern void *repalloc(void *pointer, Size size);
# 83 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h"
static inline MemoryContext
MemoryContextSwitchTo(MemoryContext context)
{
 MemoryContext old = CurrentMemoryContext;

 CurrentMemoryContext = context;
 return old;
}
# 100 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h"
extern char *MemoryContextStrdup(MemoryContext context, const char *string);



extern char *pnstrdup(const char *in, Size len);
# 50 "postgres.h" 2
# 67 "postgres.h"
struct varatt_external
{
 int32 va_rawsize;
 int32 va_extsize;
 Oid va_valueid;
 Oid va_toastrelid;
};
# 84 "postgres.h"
typedef union
{
 struct
 {
  uint32 va_header;
  char va_data[1];
 } va_4byte;
 struct
 {
  uint32 va_header;
  uint32 va_rawsize;
  char va_data[1];
 } va_compressed;
} varattrib_4b;

typedef struct
{
 uint8 va_header;
 char va_data[1];
} varattrib_1b;

typedef struct
{
 uint8 va_header;
 uint8 va_len_1be;
 char va_data[1];
} varattrib_1b_e;
# 302 "postgres.h"
typedef uintptr_t Datum;



typedef Datum *DatumPtr;
# 561 "postgres.h"
extern float4 DatumGetFloat4(Datum X);
# 574 "postgres.h"
extern Datum Float4GetDatum(float4 X);
# 584 "postgres.h"
extern float8 DatumGetFloat8(Datum X);
# 597 "postgres.h"
extern Datum Float8GetDatum(float8 X);
# 635 "postgres.h"
extern bool assert_enabled;
# 686 "postgres.h"
extern void ExceptionalCondition(const char *conditionName,
      const char *errorType,
    const char *fileName, int lineNumber) __attribute__((noreturn));
# 10 "pltcl.c" 2

# 1 "/usr/include/tcl.h" 1 3 4
# 310 "/usr/include/tcl.h" 3 4
 typedef void *ClientData;
# 400 "/usr/include/tcl.h" 3 4
typedef long Tcl_WideInt;
typedef unsigned long Tcl_WideUInt;


typedef struct stat Tcl_StatBuf;
# 450 "/usr/include/tcl.h" 3 4
typedef struct Tcl_Interp {
    char *result;

    void (*freeProc) (char *blockPtr);







    int errorLine;


} Tcl_Interp;

typedef struct Tcl_AsyncHandler_ *Tcl_AsyncHandler;
typedef struct Tcl_Channel_ *Tcl_Channel;
typedef struct Tcl_ChannelTypeVersion_ *Tcl_ChannelTypeVersion;
typedef struct Tcl_Command_ *Tcl_Command;
typedef struct Tcl_Condition_ *Tcl_Condition;
typedef struct Tcl_Dict_ *Tcl_Dict;
typedef struct Tcl_EncodingState_ *Tcl_EncodingState;
typedef struct Tcl_Encoding_ *Tcl_Encoding;
typedef struct Tcl_Event Tcl_Event;
typedef struct Tcl_InterpState_ *Tcl_InterpState;
typedef struct Tcl_LoadHandle_ *Tcl_LoadHandle;
typedef struct Tcl_Mutex_ *Tcl_Mutex;
typedef struct Tcl_Pid_ *Tcl_Pid;
typedef struct Tcl_RegExp_ *Tcl_RegExp;
typedef struct Tcl_ThreadDataKey_ *Tcl_ThreadDataKey;
typedef struct Tcl_ThreadId_ *Tcl_ThreadId;
typedef struct Tcl_TimerToken_ *Tcl_TimerToken;
typedef struct Tcl_Trace_ *Tcl_Trace;
typedef struct Tcl_Var_ *Tcl_Var;
# 495 "/usr/include/tcl.h" 3 4
typedef void (Tcl_ThreadCreateProc) (ClientData clientData);
# 560 "/usr/include/tcl.h" 3 4
typedef struct Tcl_RegExpIndices {
    long start;

    long end;

} Tcl_RegExpIndices;

typedef struct Tcl_RegExpInfo {
    int nsubs;

    Tcl_RegExpIndices *matches;
    long extendStart;

    long reserved;
} Tcl_RegExpInfo;






typedef Tcl_StatBuf *Tcl_Stat_;
typedef struct stat *Tcl_OldStat_;
# 625 "/usr/include/tcl.h" 3 4
typedef enum {
    TCL_INT, TCL_DOUBLE, TCL_EITHER, TCL_WIDE_INT
} Tcl_ValueType;

typedef struct Tcl_Value {
    Tcl_ValueType type;

    long intValue;
    double doubleValue;
    Tcl_WideInt wideValue;
} Tcl_Value;






struct Tcl_Obj;





typedef int (Tcl_AppInitProc) (Tcl_Interp *interp);
typedef int (Tcl_AsyncProc) (ClientData clientData, Tcl_Interp *interp, int code);

typedef void (Tcl_ChannelProc) (ClientData clientData, int mask);
typedef void (Tcl_CloseProc) (ClientData data);
typedef void (Tcl_CmdDeleteProc) (ClientData clientData);
typedef int (Tcl_CmdProc) (ClientData clientData, Tcl_Interp *interp, int argc, const char *argv[]);

typedef void (Tcl_CmdTraceProc) (ClientData clientData, Tcl_Interp *interp, int level, char *command, Tcl_CmdProc *proc, ClientData cmdClientData, int argc, const char *argv[]);


typedef int (Tcl_CmdObjTraceProc) (ClientData clientData, Tcl_Interp *interp, int level, const char *command, Tcl_Command commandInfo, int objc, struct Tcl_Obj * const * objv);


typedef void (Tcl_CmdObjTraceDeleteProc) (ClientData clientData);
typedef void (Tcl_DupInternalRepProc) (struct Tcl_Obj *srcPtr, struct Tcl_Obj *dupPtr);

typedef int (Tcl_EncodingConvertProc)(ClientData clientData, const char *src, int srcLen, int flags, Tcl_EncodingState *statePtr, char *dst, int dstLen, int *srcReadPtr, int *dstWrotePtr, int *dstCharsPtr);



typedef void (Tcl_EncodingFreeProc)(ClientData clientData);
typedef int (Tcl_EventProc) (Tcl_Event *evPtr, int flags);
typedef void (Tcl_EventCheckProc) (ClientData clientData, int flags);

typedef int (Tcl_EventDeleteProc) (Tcl_Event *evPtr, ClientData clientData);

typedef void (Tcl_EventSetupProc) (ClientData clientData, int flags);

typedef void (Tcl_ExitProc) (ClientData clientData);
typedef void (Tcl_FileProc) (ClientData clientData, int mask);
typedef void (Tcl_FileFreeProc) (ClientData clientData);
typedef void (Tcl_FreeInternalRepProc) (struct Tcl_Obj *objPtr);
typedef void (Tcl_FreeProc) (char *blockPtr);
typedef void (Tcl_IdleProc) (ClientData clientData);
typedef void (Tcl_InterpDeleteProc) (ClientData clientData, Tcl_Interp *interp);

typedef int (Tcl_MathProc) (ClientData clientData, Tcl_Interp *interp, Tcl_Value *args, Tcl_Value *resultPtr);

typedef void (Tcl_NamespaceDeleteProc) (ClientData clientData);
typedef int (Tcl_ObjCmdProc) (ClientData clientData, Tcl_Interp *interp, int objc, struct Tcl_Obj * const * objv);

typedef int (Tcl_PackageInitProc) (Tcl_Interp *interp);
typedef int (Tcl_PackageUnloadProc) (Tcl_Interp *interp, int flags);

typedef void (Tcl_PanicProc) (const char *format, ...);
typedef void (Tcl_TcpAcceptProc) (ClientData callbackData, Tcl_Channel chan, char *address, int port);

typedef void (Tcl_TimerProc) (ClientData clientData);
typedef int (Tcl_SetFromAnyProc) (Tcl_Interp *interp, struct Tcl_Obj *objPtr);

typedef void (Tcl_UpdateStringProc) (struct Tcl_Obj *objPtr);
typedef char *(Tcl_VarTraceProc) (ClientData clientData, Tcl_Interp *interp, const char *part1, const char *part2, int flags);


typedef void (Tcl_CommandTraceProc) (ClientData clientData, Tcl_Interp *interp, const char *oldName, const char *newName, int flags);


typedef void (Tcl_CreateFileHandlerProc) (int fd, int mask, Tcl_FileProc *proc, ClientData clientData);

typedef void (Tcl_DeleteFileHandlerProc) (int fd);
typedef void (Tcl_AlertNotifierProc) (ClientData clientData);
typedef void (Tcl_ServiceModeHookProc) (int mode);
typedef ClientData (Tcl_InitNotifierProc) (void);
typedef void (Tcl_FinalizeNotifierProc) (ClientData clientData);
typedef void (Tcl_MainLoopProc) (void);







typedef struct Tcl_ObjType {
    char *name;
    Tcl_FreeInternalRepProc *freeIntRepProc;



    Tcl_DupInternalRepProc *dupIntRepProc;


    Tcl_UpdateStringProc *updateStringProc;


    Tcl_SetFromAnyProc *setFromAnyProc;



} Tcl_ObjType;







typedef struct Tcl_Obj {
    int refCount;
    char *bytes;
# 758 "/usr/include/tcl.h" 3 4
    int length;

    Tcl_ObjType *typePtr;



    union {
 long longValue;
 double doubleValue;
 void *otherValuePtr;
 Tcl_WideInt wideValue;
 struct {
     void *ptr1;
     void *ptr2;
 } twoPtrValue;
 struct {

     void *ptr;
     unsigned long value;

 } ptrAndLongRep;
    } internalRep;
} Tcl_Obj;
# 793 "/usr/include/tcl.h" 3 4
void Tcl_IncrRefCount (Tcl_Obj *objPtr);
void Tcl_DecrRefCount (Tcl_Obj *objPtr);
int Tcl_IsShared (Tcl_Obj *objPtr);







typedef struct Tcl_SavedResult {
    char *result;
    Tcl_FreeProc *freeProc;
    Tcl_Obj *objResultPtr;
    char *appendResult;
    int appendAvl;
    int appendUsed;
    char resultSpace[200 +1];
} Tcl_SavedResult;







typedef struct Tcl_Namespace {
    char *name;



    char *fullName;

    ClientData clientData;

    Tcl_NamespaceDeleteProc *deleteProc;


    struct Tcl_Namespace *parentPtr;



} Tcl_Namespace;
# 859 "/usr/include/tcl.h" 3 4
typedef struct Tcl_CallFrame {
    Tcl_Namespace *nsPtr;
    int dummy1;
    int dummy2;
    void *dummy3;
    void *dummy4;
    void *dummy5;
    int dummy6;
    void *dummy7;
    void *dummy8;
    int dummy9;
    void *dummy10;
    void *dummy11;
    void *dummy12;
    void *dummy13;
} Tcl_CallFrame;
# 890 "/usr/include/tcl.h" 3 4
typedef struct Tcl_CmdInfo {
    int isNativeObjectProc;



    Tcl_ObjCmdProc *objProc;
    ClientData objClientData;
    Tcl_CmdProc *proc;
    ClientData clientData;
    Tcl_CmdDeleteProc *deleteProc;


    ClientData deleteData;

    Tcl_Namespace *namespacePtr;




} Tcl_CmdInfo;
# 918 "/usr/include/tcl.h" 3 4
typedef struct Tcl_DString {
    char *string;

    int length;

    int spaceAvl;

    char staticSpace[200];


} Tcl_DString;
# 1077 "/usr/include/tcl.h" 3 4
typedef struct Tcl_HashKeyType Tcl_HashKeyType;
typedef struct Tcl_HashTable Tcl_HashTable;
typedef struct Tcl_HashEntry Tcl_HashEntry;

typedef unsigned int (Tcl_HashKeyProc) (Tcl_HashTable *tablePtr, void *keyPtr);

typedef int (Tcl_CompareHashKeysProc) (void *keyPtr, Tcl_HashEntry *hPtr);

typedef Tcl_HashEntry *(Tcl_AllocHashEntryProc) ( Tcl_HashTable *tablePtr, void *keyPtr);

typedef void (Tcl_FreeHashEntryProc) (Tcl_HashEntry *hPtr);
# 1106 "/usr/include/tcl.h" 3 4
struct Tcl_HashEntry {
    Tcl_HashEntry *nextPtr;

    Tcl_HashTable *tablePtr;

    void *hash;







    ClientData clientData;

    union {
 char *oneWordValue;
 Tcl_Obj *objPtr;
 int words[1];


 char string[4];

    } key;
};
# 1155 "/usr/include/tcl.h" 3 4
struct Tcl_HashKeyType {
    int version;



    int flags;
    Tcl_HashKeyProc *hashKeyProc;



    Tcl_CompareHashKeysProc *compareKeysProc;




    Tcl_AllocHashEntryProc *allocEntryProc;
# 1184 "/usr/include/tcl.h" 3 4
    Tcl_FreeHashEntryProc *freeEntryProc;






};
# 1200 "/usr/include/tcl.h" 3 4
struct Tcl_HashTable {
    Tcl_HashEntry **buckets;


    Tcl_HashEntry *staticBuckets[4];


    int numBuckets;

    int numEntries;

    int rebuildSize;

    int downShift;


    int mask;
    int keyType;




    Tcl_HashEntry *(*findProc) (Tcl_HashTable *tablePtr, const char *key);

    Tcl_HashEntry *(*createProc) (Tcl_HashTable *tablePtr, const char *key, int *newPtr);

    Tcl_HashKeyType *typePtr;

};






typedef struct Tcl_HashSearch {
    Tcl_HashTable *tablePtr;
    int nextIndex;

    Tcl_HashEntry *nextEntryPtr;

} Tcl_HashSearch;
# 1275 "/usr/include/tcl.h" 3 4
typedef struct {
    void *next;

    int epoch;

    Tcl_Dict dictionaryPtr;
} Tcl_DictSearch;
# 1304 "/usr/include/tcl.h" 3 4
struct Tcl_Event {
    Tcl_EventProc *proc;
    struct Tcl_Event *nextPtr;
};





typedef enum {
    TCL_QUEUE_TAIL, TCL_QUEUE_HEAD, TCL_QUEUE_MARK
} Tcl_QueuePosition;
# 1331 "/usr/include/tcl.h" 3 4
typedef struct Tcl_Time {
    long sec;
    long usec;
} Tcl_Time;

typedef void (Tcl_SetTimerProc) (Tcl_Time *timePtr);
typedef int (Tcl_WaitForEventProc) (Tcl_Time *timePtr);





typedef void (Tcl_GetTimeProc) (Tcl_Time *timebuf, ClientData clientData);

typedef void (Tcl_ScaleTimeProc) (Tcl_Time *timebuf, ClientData clientData);
# 1404 "/usr/include/tcl.h" 3 4
typedef int (Tcl_DriverBlockModeProc) ( ClientData instanceData, int mode);

typedef int (Tcl_DriverCloseProc) (ClientData instanceData, Tcl_Interp *interp);

typedef int (Tcl_DriverClose2Proc) (ClientData instanceData, Tcl_Interp *interp, int flags);

typedef int (Tcl_DriverInputProc) (ClientData instanceData, char *buf, int toRead, int *errorCodePtr);

typedef int (Tcl_DriverOutputProc) (ClientData instanceData, const char *buf, int toWrite, int *errorCodePtr);

typedef int (Tcl_DriverSeekProc) (ClientData instanceData, long offset, int mode, int *errorCodePtr);

typedef int (Tcl_DriverSetOptionProc) ( ClientData instanceData, Tcl_Interp *interp, const char *optionName, const char *value);


typedef int (Tcl_DriverGetOptionProc) ( ClientData instanceData, Tcl_Interp *interp, const char *optionName, Tcl_DString *dsPtr);


typedef void (Tcl_DriverWatchProc) ( ClientData instanceData, int mask);

typedef int (Tcl_DriverGetHandleProc) ( ClientData instanceData, int direction, ClientData *handlePtr);


typedef int (Tcl_DriverFlushProc) (ClientData instanceData);
typedef int (Tcl_DriverHandlerProc) ( ClientData instanceData, int interestMask);

typedef Tcl_WideInt (Tcl_DriverWideSeekProc) ( ClientData instanceData, Tcl_WideInt offset, int mode, int *errorCodePtr);





typedef void (Tcl_DriverThreadActionProc) ( ClientData instanceData, int action);




typedef int (Tcl_DriverTruncateProc) ( ClientData instanceData, Tcl_WideInt length);
# 1455 "/usr/include/tcl.h" 3 4
typedef struct Tcl_ChannelType {
    char *typeName;


    Tcl_ChannelTypeVersion version;

    Tcl_DriverCloseProc *closeProc;



    Tcl_DriverInputProc *inputProc;

    Tcl_DriverOutputProc *outputProc;

    Tcl_DriverSeekProc *seekProc;


    Tcl_DriverSetOptionProc *setOptionProc;

    Tcl_DriverGetOptionProc *getOptionProc;

    Tcl_DriverWatchProc *watchProc;


    Tcl_DriverGetHandleProc *getHandleProc;


    Tcl_DriverClose2Proc *close2Proc;



    Tcl_DriverBlockModeProc *blockModeProc;





    Tcl_DriverFlushProc *flushProc;


    Tcl_DriverHandlerProc *handlerProc;






    Tcl_DriverWideSeekProc *wideSeekProc;
# 1511 "/usr/include/tcl.h" 3 4
    Tcl_DriverThreadActionProc *threadActionProc;
# 1520 "/usr/include/tcl.h" 3 4
    Tcl_DriverTruncateProc *truncateProc;



} Tcl_ChannelType;
# 1540 "/usr/include/tcl.h" 3 4
typedef enum Tcl_PathType {
    TCL_PATH_ABSOLUTE,
    TCL_PATH_RELATIVE,
    TCL_PATH_VOLUME_RELATIVE
} Tcl_PathType;






typedef struct Tcl_GlobTypeData {
    int type;
    int perm;
    Tcl_Obj *macType;
    Tcl_Obj *macCreator;
} Tcl_GlobTypeData;
# 1588 "/usr/include/tcl.h" 3 4
typedef int (Tcl_FSStatProc) (Tcl_Obj *pathPtr, Tcl_StatBuf *buf);
typedef int (Tcl_FSAccessProc) (Tcl_Obj *pathPtr, int mode);
typedef Tcl_Channel (Tcl_FSOpenFileChannelProc) ( Tcl_Interp *interp, Tcl_Obj *pathPtr, int mode, int permissions);

typedef int (Tcl_FSMatchInDirectoryProc) (Tcl_Interp *interp, Tcl_Obj *result, Tcl_Obj *pathPtr, const char *pattern, Tcl_GlobTypeData * types);


typedef Tcl_Obj * (Tcl_FSGetCwdProc) (Tcl_Interp *interp);
typedef int (Tcl_FSChdirProc) (Tcl_Obj *pathPtr);
typedef int (Tcl_FSLstatProc) (Tcl_Obj *pathPtr, Tcl_StatBuf *buf);

typedef int (Tcl_FSCreateDirectoryProc) (Tcl_Obj *pathPtr);
typedef int (Tcl_FSDeleteFileProc) (Tcl_Obj *pathPtr);
typedef int (Tcl_FSCopyDirectoryProc) (Tcl_Obj *srcPathPtr, Tcl_Obj *destPathPtr, Tcl_Obj **errorPtr);

typedef int (Tcl_FSCopyFileProc) (Tcl_Obj *srcPathPtr, Tcl_Obj *destPathPtr);

typedef int (Tcl_FSRemoveDirectoryProc) (Tcl_Obj *pathPtr, int recursive, Tcl_Obj **errorPtr);

typedef int (Tcl_FSRenameFileProc) (Tcl_Obj *srcPathPtr, Tcl_Obj *destPathPtr);

typedef void (Tcl_FSUnloadFileProc) (Tcl_LoadHandle loadHandle);
typedef Tcl_Obj * (Tcl_FSListVolumesProc) (void);

struct utimbuf;
typedef int (Tcl_FSUtimeProc) (Tcl_Obj *pathPtr, struct utimbuf *tval);

typedef int (Tcl_FSNormalizePathProc) (Tcl_Interp *interp, Tcl_Obj *pathPtr, int nextCheckpoint);

typedef int (Tcl_FSFileAttrsGetProc) (Tcl_Interp *interp, int index, Tcl_Obj *pathPtr, Tcl_Obj **objPtrRef);

typedef const char ** (Tcl_FSFileAttrStringsProc) ( Tcl_Obj *pathPtr, Tcl_Obj **objPtrRef);

typedef int (Tcl_FSFileAttrsSetProc) (Tcl_Interp *interp, int index, Tcl_Obj *pathPtr, Tcl_Obj *objPtr);

typedef Tcl_Obj * (Tcl_FSLinkProc) (Tcl_Obj *pathPtr, Tcl_Obj *toPtr, int linkType);

typedef int (Tcl_FSLoadFileProc) (Tcl_Interp * interp, Tcl_Obj *pathPtr, Tcl_LoadHandle *handlePtr, Tcl_FSUnloadFileProc **unloadProcPtr);


typedef int (Tcl_FSPathInFilesystemProc) (Tcl_Obj *pathPtr, ClientData *clientDataPtr);

typedef Tcl_Obj * (Tcl_FSFilesystemPathTypeProc) ( Tcl_Obj *pathPtr);

typedef Tcl_Obj * (Tcl_FSFilesystemSeparatorProc) ( Tcl_Obj *pathPtr);

typedef void (Tcl_FSFreeInternalRepProc) (ClientData clientData);
typedef ClientData (Tcl_FSDupInternalRepProc) ( ClientData clientData);

typedef Tcl_Obj * (Tcl_FSInternalToNormalizedProc) ( ClientData clientData);

typedef ClientData (Tcl_FSCreateInternalRepProc) ( Tcl_Obj *pathPtr);


typedef struct Tcl_FSVersion_ *Tcl_FSVersion;
# 1668 "/usr/include/tcl.h" 3 4
typedef struct Tcl_Filesystem {
    const char *typeName;
    int structureLength;

    Tcl_FSVersion version;
    Tcl_FSPathInFilesystemProc *pathInFilesystemProc;



    Tcl_FSDupInternalRepProc *dupInternalRepProc;


    Tcl_FSFreeInternalRepProc *freeInternalRepProc;



    Tcl_FSInternalToNormalizedProc *internalToNormalizedProc;




    Tcl_FSCreateInternalRepProc *createInternalRepProc;







    Tcl_FSNormalizePathProc *normalizePathProc;




    Tcl_FSFilesystemPathTypeProc *filesystemPathTypeProc;


    Tcl_FSFilesystemSeparatorProc *filesystemSeparatorProc;



    Tcl_FSStatProc *statProc;


    Tcl_FSAccessProc *accessProc;



    Tcl_FSOpenFileChannelProc *openFileChannelProc;




    Tcl_FSMatchInDirectoryProc *matchInDirectoryProc;





    Tcl_FSUtimeProc *utimeProc;




    Tcl_FSLinkProc *linkProc;



    Tcl_FSListVolumesProc *listVolumesProc;




    Tcl_FSFileAttrStringsProc *fileAttrStringsProc;






    Tcl_FSFileAttrsGetProc *fileAttrsGetProc;



    Tcl_FSFileAttrsSetProc *fileAttrsSetProc;



    Tcl_FSCreateDirectoryProc *createDirectoryProc;



    Tcl_FSRemoveDirectoryProc *removeDirectoryProc;



    Tcl_FSDeleteFileProc *deleteFileProc;



    Tcl_FSCopyFileProc *copyFileProc;





    Tcl_FSRenameFileProc *renameFileProc;




    Tcl_FSCopyDirectoryProc *copyDirectoryProc;






    Tcl_FSLstatProc *lstatProc;


    Tcl_FSLoadFileProc *loadFileProc;




    Tcl_FSGetCwdProc *getCwdProc;





    Tcl_FSChdirProc *chdirProc;
# 1815 "/usr/include/tcl.h" 3 4
} Tcl_Filesystem;
# 1835 "/usr/include/tcl.h" 3 4
typedef struct Tcl_NotifierProcs {
    Tcl_SetTimerProc *setTimerProc;
    Tcl_WaitForEventProc *waitForEventProc;
    Tcl_CreateFileHandlerProc *createFileHandlerProc;
    Tcl_DeleteFileHandlerProc *deleteFileHandlerProc;
    Tcl_InitNotifierProc *initNotifierProc;
    Tcl_FinalizeNotifierProc *finalizeNotifierProc;
    Tcl_AlertNotifierProc *alertNotifierProc;
    Tcl_ServiceModeHookProc *serviceModeHookProc;
} Tcl_NotifierProcs;






typedef struct Tcl_EncodingType {
    const char *encodingName;


    Tcl_EncodingConvertProc *toUtfProc;


    Tcl_EncodingConvertProc *fromUtfProc;


    Tcl_EncodingFreeProc *freeProc;


    ClientData clientData;

    int nullSize;




} Tcl_EncodingType;
# 1917 "/usr/include/tcl.h" 3 4
typedef struct Tcl_Token {
    int type;

    const char *start;
    int size;
    int numComponents;




} Tcl_Token;
# 2033 "/usr/include/tcl.h" 3 4
typedef struct Tcl_Parse {
    const char *commentStart;

    int commentSize;



    const char *commandStart;

    int commandSize;



    int numWords;

    Tcl_Token *tokenPtr;




    int numTokens;
    int tokensAvailable;

    int errorType;







    const char *string;

    const char *end;

    Tcl_Interp *interp;

    const char *term;





    int incomplete;



    Tcl_Token staticTokens[20];





} Tcl_Parse;
# 2152 "/usr/include/tcl.h" 3 4
typedef unsigned short Tcl_UniChar;







typedef struct Tcl_Config {
    const char *key;

    const char *value;

} Tcl_Config;
# 2180 "/usr/include/tcl.h" 3 4
typedef void (Tcl_LimitHandlerProc) (ClientData clientData, Tcl_Interp *interp);

typedef void (Tcl_LimitHandlerDeleteProc) (ClientData clientData);

typedef struct mp_int mp_int;

typedef unsigned int mp_digit;
# 2206 "/usr/include/tcl.h" 3 4
extern const char * Tcl_InitStubs (Tcl_Interp *interp, const char *version, int exact);

extern const char * TclTomMathInitializeStubs ( Tcl_Interp *interp, const char *version, int epoch, int revision);
# 2233 "/usr/include/tcl.h" 3 4
extern void Tcl_Main (int argc, char **argv, Tcl_AppInitProc *appInitProc);

extern const char * Tcl_PkgInitStubsCheck (Tcl_Interp *interp, const char *version, int exact);
# 2246 "/usr/include/tcl.h" 3 4
# 1 "/usr/include/tclDecls.h" 1 3 4
# 43 "/usr/include/tclDecls.h" 3 4
extern int Tcl_PkgProvideEx(Tcl_Interp *interp,
    const char *name, const char *version,
    ClientData clientData);




extern const char * Tcl_PkgRequireEx(Tcl_Interp *interp,
    const char *name, const char *version,
    int exact, ClientData *clientDataPtr);




extern void Tcl_Panic(const char *format, ...);




extern char * Tcl_Alloc(unsigned int size);




extern void Tcl_Free(char *ptr);




extern char * Tcl_Realloc(char *ptr, unsigned int size);




extern char * Tcl_DbCkalloc(unsigned int size, const char *file,
    int line);




extern int Tcl_DbCkfree(char *ptr, const char *file, int line);




extern char * Tcl_DbCkrealloc(char *ptr, unsigned int size,
    const char *file, int line);





extern void Tcl_CreateFileHandler(int fd, int mask,
    Tcl_FileProc *proc, ClientData clientData);
# 111 "/usr/include/tclDecls.h" 3 4
extern void Tcl_DeleteFileHandler(int fd);
# 124 "/usr/include/tclDecls.h" 3 4
extern void Tcl_SetTimer(Tcl_Time *timePtr);




extern void Tcl_Sleep(int ms);




extern int Tcl_WaitForEvent(Tcl_Time *timePtr);




extern int Tcl_AppendAllObjTypes(Tcl_Interp *interp,
    Tcl_Obj *objPtr);




extern void Tcl_AppendStringsToObj(Tcl_Obj *objPtr, ...);




extern void Tcl_AppendToObj(Tcl_Obj *objPtr, const char *bytes,
    int length);




extern Tcl_Obj * Tcl_ConcatObj(int objc, Tcl_Obj *const objv[]);




extern int Tcl_ConvertToType(Tcl_Interp *interp,
    Tcl_Obj *objPtr, Tcl_ObjType *typePtr);




extern void Tcl_DbDecrRefCount(Tcl_Obj *objPtr, const char *file,
    int line);




extern void Tcl_DbIncrRefCount(Tcl_Obj *objPtr, const char *file,
    int line);




extern int Tcl_DbIsShared(Tcl_Obj *objPtr, const char *file,
    int line);




extern Tcl_Obj * Tcl_DbNewBooleanObj(int boolValue, const char *file,
    int line);




extern Tcl_Obj * Tcl_DbNewByteArrayObj(const unsigned char *bytes,
    int length, const char *file, int line);




extern Tcl_Obj * Tcl_DbNewDoubleObj(double doubleValue,
    const char *file, int line);




extern Tcl_Obj * Tcl_DbNewListObj(int objc, Tcl_Obj *const *objv,
    const char *file, int line);




extern Tcl_Obj * Tcl_DbNewLongObj(long longValue, const char *file,
    int line);




extern Tcl_Obj * Tcl_DbNewObj(const char *file, int line);




extern Tcl_Obj * Tcl_DbNewStringObj(const char *bytes, int length,
    const char *file, int line);




extern Tcl_Obj * Tcl_DuplicateObj(Tcl_Obj *objPtr);




extern void TclFreeObj(Tcl_Obj *objPtr);




extern int Tcl_GetBoolean(Tcl_Interp *interp, const char *src,
    int *boolPtr);




extern int Tcl_GetBooleanFromObj(Tcl_Interp *interp,
    Tcl_Obj *objPtr, int *boolPtr);




extern unsigned char * Tcl_GetByteArrayFromObj(Tcl_Obj *objPtr,
    int *lengthPtr);




extern int Tcl_GetDouble(Tcl_Interp *interp, const char *src,
    double *doublePtr);




extern int Tcl_GetDoubleFromObj(Tcl_Interp *interp,
    Tcl_Obj *objPtr, double *doublePtr);




extern int Tcl_GetIndexFromObj(Tcl_Interp *interp,
    Tcl_Obj *objPtr, const char **tablePtr,
    const char *msg, int flags, int *indexPtr);




extern int Tcl_GetInt(Tcl_Interp *interp, const char *src,
    int *intPtr);




extern int Tcl_GetIntFromObj(Tcl_Interp *interp,
    Tcl_Obj *objPtr, int *intPtr);




extern int Tcl_GetLongFromObj(Tcl_Interp *interp,
    Tcl_Obj *objPtr, long *longPtr);




extern Tcl_ObjType * Tcl_GetObjType(const char *typeName);




extern char * Tcl_GetStringFromObj(Tcl_Obj *objPtr, int *lengthPtr);




extern void Tcl_InvalidateStringRep(Tcl_Obj *objPtr);




extern int Tcl_ListObjAppendList(Tcl_Interp *interp,
    Tcl_Obj *listPtr, Tcl_Obj *elemListPtr);




extern int Tcl_ListObjAppendElement(Tcl_Interp *interp,
    Tcl_Obj *listPtr, Tcl_Obj *objPtr);




extern int Tcl_ListObjGetElements(Tcl_Interp *interp,
    Tcl_Obj *listPtr, int *objcPtr,
    Tcl_Obj ***objvPtr);




extern int Tcl_ListObjIndex(Tcl_Interp *interp,
    Tcl_Obj *listPtr, int index,
    Tcl_Obj **objPtrPtr);




extern int Tcl_ListObjLength(Tcl_Interp *interp,
    Tcl_Obj *listPtr, int *lengthPtr);




extern int Tcl_ListObjReplace(Tcl_Interp *interp,
    Tcl_Obj *listPtr, int first, int count,
    int objc, Tcl_Obj *const objv[]);




extern Tcl_Obj * Tcl_NewBooleanObj(int boolValue);




extern Tcl_Obj * Tcl_NewByteArrayObj(const unsigned char *bytes,
    int length);




extern Tcl_Obj * Tcl_NewDoubleObj(double doubleValue);




extern Tcl_Obj * Tcl_NewIntObj(int intValue);




extern Tcl_Obj * Tcl_NewListObj(int objc, Tcl_Obj *const objv[]);




extern Tcl_Obj * Tcl_NewLongObj(long longValue);




extern Tcl_Obj * Tcl_NewObj(void);




extern Tcl_Obj * Tcl_NewStringObj(const char *bytes, int length);




extern void Tcl_SetBooleanObj(Tcl_Obj *objPtr, int boolValue);




extern unsigned char * Tcl_SetByteArrayLength(Tcl_Obj *objPtr, int length);




extern void Tcl_SetByteArrayObj(Tcl_Obj *objPtr,
    const unsigned char *bytes, int length);




extern void Tcl_SetDoubleObj(Tcl_Obj *objPtr, double doubleValue);




extern void Tcl_SetIntObj(Tcl_Obj *objPtr, int intValue);




extern void Tcl_SetListObj(Tcl_Obj *objPtr, int objc,
    Tcl_Obj *const objv[]);




extern void Tcl_SetLongObj(Tcl_Obj *objPtr, long longValue);




extern void Tcl_SetObjLength(Tcl_Obj *objPtr, int length);




extern void Tcl_SetStringObj(Tcl_Obj *objPtr, const char *bytes,
    int length);




extern void Tcl_AddErrorInfo(Tcl_Interp *interp,
    const char *message);




extern void Tcl_AddObjErrorInfo(Tcl_Interp *interp,
    const char *message, int length);




extern void Tcl_AllowExceptions(Tcl_Interp *interp);




extern void Tcl_AppendElement(Tcl_Interp *interp,
    const char *element);




extern void Tcl_AppendResult(Tcl_Interp *interp, ...);




extern Tcl_AsyncHandler Tcl_AsyncCreate(Tcl_AsyncProc *proc,
    ClientData clientData);




extern void Tcl_AsyncDelete(Tcl_AsyncHandler async);




extern int Tcl_AsyncInvoke(Tcl_Interp *interp, int code);




extern void Tcl_AsyncMark(Tcl_AsyncHandler async);




extern int Tcl_AsyncReady(void);




extern void Tcl_BackgroundError(Tcl_Interp *interp);




extern char Tcl_Backslash(const char *src, int *readPtr);




extern int Tcl_BadChannelOption(Tcl_Interp *interp,
    const char *optionName,
    const char *optionList);




extern void Tcl_CallWhenDeleted(Tcl_Interp *interp,
    Tcl_InterpDeleteProc *proc,
    ClientData clientData);




extern void Tcl_CancelIdleCall(Tcl_IdleProc *idleProc,
    ClientData clientData);




extern int Tcl_Close(Tcl_Interp *interp, Tcl_Channel chan);




extern int Tcl_CommandComplete(const char *cmd);




extern char * Tcl_Concat(int argc, const char *const *argv);




extern int Tcl_ConvertElement(const char *src, char *dst,
    int flags);




extern int Tcl_ConvertCountedElement(const char *src,
    int length, char *dst, int flags);




extern int Tcl_CreateAlias(Tcl_Interp *slave,
    const char *slaveCmd, Tcl_Interp *target,
    const char *targetCmd, int argc,
    const char *const *argv);




extern int Tcl_CreateAliasObj(Tcl_Interp *slave,
    const char *slaveCmd, Tcl_Interp *target,
    const char *targetCmd, int objc,
    Tcl_Obj *const objv[]);




extern Tcl_Channel Tcl_CreateChannel(Tcl_ChannelType *typePtr,
    const char *chanName,
    ClientData instanceData, int mask);




extern void Tcl_CreateChannelHandler(Tcl_Channel chan, int mask,
    Tcl_ChannelProc *proc, ClientData clientData);




extern void Tcl_CreateCloseHandler(Tcl_Channel chan,
    Tcl_CloseProc *proc, ClientData clientData);




extern Tcl_Command Tcl_CreateCommand(Tcl_Interp *interp,
    const char *cmdName, Tcl_CmdProc *proc,
    ClientData clientData,
    Tcl_CmdDeleteProc *deleteProc);




extern void Tcl_CreateEventSource(Tcl_EventSetupProc *setupProc,
    Tcl_EventCheckProc *checkProc,
    ClientData clientData);




extern void Tcl_CreateExitHandler(Tcl_ExitProc *proc,
    ClientData clientData);




extern Tcl_Interp * Tcl_CreateInterp(void);




extern void Tcl_CreateMathFunc(Tcl_Interp *interp,
    const char *name, int numArgs,
    Tcl_ValueType *argTypes, Tcl_MathProc *proc,
    ClientData clientData);




extern Tcl_Command Tcl_CreateObjCommand(Tcl_Interp *interp,
    const char *cmdName, Tcl_ObjCmdProc *proc,
    ClientData clientData,
    Tcl_CmdDeleteProc *deleteProc);




extern Tcl_Interp * Tcl_CreateSlave(Tcl_Interp *interp,
    const char *slaveName, int isSafe);




extern Tcl_TimerToken Tcl_CreateTimerHandler(int milliseconds,
    Tcl_TimerProc *proc, ClientData clientData);




extern Tcl_Trace Tcl_CreateTrace(Tcl_Interp *interp, int level,
    Tcl_CmdTraceProc *proc,
    ClientData clientData);




extern void Tcl_DeleteAssocData(Tcl_Interp *interp,
    const char *name);




extern void Tcl_DeleteChannelHandler(Tcl_Channel chan,
    Tcl_ChannelProc *proc, ClientData clientData);




extern void Tcl_DeleteCloseHandler(Tcl_Channel chan,
    Tcl_CloseProc *proc, ClientData clientData);




extern int Tcl_DeleteCommand(Tcl_Interp *interp,
    const char *cmdName);




extern int Tcl_DeleteCommandFromToken(Tcl_Interp *interp,
    Tcl_Command command);




extern void Tcl_DeleteEvents(Tcl_EventDeleteProc *proc,
    ClientData clientData);




extern void Tcl_DeleteEventSource(Tcl_EventSetupProc *setupProc,
    Tcl_EventCheckProc *checkProc,
    ClientData clientData);




extern void Tcl_DeleteExitHandler(Tcl_ExitProc *proc,
    ClientData clientData);




extern void Tcl_DeleteHashEntry(Tcl_HashEntry *entryPtr);




extern void Tcl_DeleteHashTable(Tcl_HashTable *tablePtr);




extern void Tcl_DeleteInterp(Tcl_Interp *interp);




extern void Tcl_DetachPids(int numPids, Tcl_Pid *pidPtr);




extern void Tcl_DeleteTimerHandler(Tcl_TimerToken token);




extern void Tcl_DeleteTrace(Tcl_Interp *interp, Tcl_Trace trace);




extern void Tcl_DontCallWhenDeleted(Tcl_Interp *interp,
    Tcl_InterpDeleteProc *proc,
    ClientData clientData);




extern int Tcl_DoOneEvent(int flags);




extern void Tcl_DoWhenIdle(Tcl_IdleProc *proc,
    ClientData clientData);




extern char * Tcl_DStringAppend(Tcl_DString *dsPtr,
    const char *bytes, int length);




extern char * Tcl_DStringAppendElement(Tcl_DString *dsPtr,
    const char *element);




extern void Tcl_DStringEndSublist(Tcl_DString *dsPtr);




extern void Tcl_DStringFree(Tcl_DString *dsPtr);




extern void Tcl_DStringGetResult(Tcl_Interp *interp,
    Tcl_DString *dsPtr);




extern void Tcl_DStringInit(Tcl_DString *dsPtr);




extern void Tcl_DStringResult(Tcl_Interp *interp,
    Tcl_DString *dsPtr);




extern void Tcl_DStringSetLength(Tcl_DString *dsPtr, int length);




extern void Tcl_DStringStartSublist(Tcl_DString *dsPtr);




extern int Tcl_Eof(Tcl_Channel chan);




extern const char * Tcl_ErrnoId(void);




extern const char * Tcl_ErrnoMsg(int err);




extern int Tcl_Eval(Tcl_Interp *interp, const char *script);




extern int Tcl_EvalFile(Tcl_Interp *interp,
    const char *fileName);




extern int Tcl_EvalObj(Tcl_Interp *interp, Tcl_Obj *objPtr);




extern void Tcl_EventuallyFree(ClientData clientData,
    Tcl_FreeProc *freeProc);




extern void Tcl_Exit(int status);




extern int Tcl_ExposeCommand(Tcl_Interp *interp,
    const char *hiddenCmdToken,
    const char *cmdName);




extern int Tcl_ExprBoolean(Tcl_Interp *interp, const char *expr,
    int *ptr);




extern int Tcl_ExprBooleanObj(Tcl_Interp *interp,
    Tcl_Obj *objPtr, int *ptr);




extern int Tcl_ExprDouble(Tcl_Interp *interp, const char *expr,
    double *ptr);




extern int Tcl_ExprDoubleObj(Tcl_Interp *interp,
    Tcl_Obj *objPtr, double *ptr);




extern int Tcl_ExprLong(Tcl_Interp *interp, const char *expr,
    long *ptr);




extern int Tcl_ExprLongObj(Tcl_Interp *interp, Tcl_Obj *objPtr,
    long *ptr);




extern int Tcl_ExprObj(Tcl_Interp *interp, Tcl_Obj *objPtr,
    Tcl_Obj **resultPtrPtr);




extern int Tcl_ExprString(Tcl_Interp *interp, const char *expr);




extern void Tcl_Finalize(void);




extern void Tcl_FindExecutable(const char *argv0);




extern Tcl_HashEntry * Tcl_FirstHashEntry(Tcl_HashTable *tablePtr,
    Tcl_HashSearch *searchPtr);




extern int Tcl_Flush(Tcl_Channel chan);




extern void Tcl_FreeResult(Tcl_Interp *interp);




extern int Tcl_GetAlias(Tcl_Interp *interp,
    const char *slaveCmd,
    Tcl_Interp **targetInterpPtr,
    const char **targetCmdPtr, int *argcPtr,
    const char ***argvPtr);




extern int Tcl_GetAliasObj(Tcl_Interp *interp,
    const char *slaveCmd,
    Tcl_Interp **targetInterpPtr,
    const char **targetCmdPtr, int *objcPtr,
    Tcl_Obj ***objv);




extern ClientData Tcl_GetAssocData(Tcl_Interp *interp,
    const char *name,
    Tcl_InterpDeleteProc **procPtr);




extern Tcl_Channel Tcl_GetChannel(Tcl_Interp *interp,
    const char *chanName, int *modePtr);




extern int Tcl_GetChannelBufferSize(Tcl_Channel chan);




extern int Tcl_GetChannelHandle(Tcl_Channel chan, int direction,
    ClientData *handlePtr);




extern ClientData Tcl_GetChannelInstanceData(Tcl_Channel chan);




extern int Tcl_GetChannelMode(Tcl_Channel chan);




extern const char * Tcl_GetChannelName(Tcl_Channel chan);




extern int Tcl_GetChannelOption(Tcl_Interp *interp,
    Tcl_Channel chan, const char *optionName,
    Tcl_DString *dsPtr);




extern Tcl_ChannelType * Tcl_GetChannelType(Tcl_Channel chan);




extern int Tcl_GetCommandInfo(Tcl_Interp *interp,
    const char *cmdName, Tcl_CmdInfo *infoPtr);




extern const char * Tcl_GetCommandName(Tcl_Interp *interp,
    Tcl_Command command);




extern int Tcl_GetErrno(void);




extern const char * Tcl_GetHostName(void);




extern int Tcl_GetInterpPath(Tcl_Interp *askInterp,
    Tcl_Interp *slaveInterp);




extern Tcl_Interp * Tcl_GetMaster(Tcl_Interp *interp);




extern const char * Tcl_GetNameOfExecutable(void);




extern Tcl_Obj * Tcl_GetObjResult(Tcl_Interp *interp);





extern int Tcl_GetOpenFile(Tcl_Interp *interp,
    const char *chanID, int forWriting,
    int checkUsage, ClientData *filePtr);
# 1039 "/usr/include/tclDecls.h" 3 4
extern Tcl_PathType Tcl_GetPathType(const char *path);




extern int Tcl_Gets(Tcl_Channel chan, Tcl_DString *dsPtr);




extern int Tcl_GetsObj(Tcl_Channel chan, Tcl_Obj *objPtr);




extern int Tcl_GetServiceMode(void);




extern Tcl_Interp * Tcl_GetSlave(Tcl_Interp *interp,
    const char *slaveName);




extern Tcl_Channel Tcl_GetStdChannel(int type);




extern const char * Tcl_GetStringResult(Tcl_Interp *interp);




extern const char * Tcl_GetVar(Tcl_Interp *interp,
    const char *varName, int flags);




extern const char * Tcl_GetVar2(Tcl_Interp *interp,
    const char *part1, const char *part2,
    int flags);




extern int Tcl_GlobalEval(Tcl_Interp *interp,
    const char *command);




extern int Tcl_GlobalEvalObj(Tcl_Interp *interp,
    Tcl_Obj *objPtr);




extern int Tcl_HideCommand(Tcl_Interp *interp,
    const char *cmdName,
    const char *hiddenCmdToken);




extern int Tcl_Init(Tcl_Interp *interp);




extern void Tcl_InitHashTable(Tcl_HashTable *tablePtr,
    int keyType);




extern int Tcl_InputBlocked(Tcl_Channel chan);




extern int Tcl_InputBuffered(Tcl_Channel chan);




extern int Tcl_InterpDeleted(Tcl_Interp *interp);




extern int Tcl_IsSafe(Tcl_Interp *interp);




extern char * Tcl_JoinPath(int argc, const char *const *argv,
    Tcl_DString *resultPtr);




extern int Tcl_LinkVar(Tcl_Interp *interp, const char *varName,
    char *addr, int type);





extern Tcl_Channel Tcl_MakeFileChannel(ClientData handle, int mode);




extern int Tcl_MakeSafe(Tcl_Interp *interp);




extern Tcl_Channel Tcl_MakeTcpClientChannel(ClientData tcpSocket);




extern char * Tcl_Merge(int argc, const char *const *argv);




extern Tcl_HashEntry * Tcl_NextHashEntry(Tcl_HashSearch *searchPtr);




extern void Tcl_NotifyChannel(Tcl_Channel channel, int mask);




extern Tcl_Obj * Tcl_ObjGetVar2(Tcl_Interp *interp, Tcl_Obj *part1Ptr,
    Tcl_Obj *part2Ptr, int flags);




extern Tcl_Obj * Tcl_ObjSetVar2(Tcl_Interp *interp, Tcl_Obj *part1Ptr,
    Tcl_Obj *part2Ptr, Tcl_Obj *newValuePtr,
    int flags);




extern Tcl_Channel Tcl_OpenCommandChannel(Tcl_Interp *interp, int argc,
    const char **argv, int flags);




extern Tcl_Channel Tcl_OpenFileChannel(Tcl_Interp *interp,
    const char *fileName, const char *modeString,
    int permissions);




extern Tcl_Channel Tcl_OpenTcpClient(Tcl_Interp *interp, int port,
    const char *address, const char *myaddr,
    int myport, int async);




extern Tcl_Channel Tcl_OpenTcpServer(Tcl_Interp *interp, int port,
    const char *host,
    Tcl_TcpAcceptProc *acceptProc,
    ClientData callbackData);




extern void Tcl_Preserve(ClientData data);




extern void Tcl_PrintDouble(Tcl_Interp *interp, double value,
    char *dst);




extern int Tcl_PutEnv(const char *assignment);




extern const char * Tcl_PosixError(Tcl_Interp *interp);




extern void Tcl_QueueEvent(Tcl_Event *evPtr,
    Tcl_QueuePosition position);




extern int Tcl_Read(Tcl_Channel chan, char *bufPtr, int toRead);




extern void Tcl_ReapDetachedProcs(void);




extern int Tcl_RecordAndEval(Tcl_Interp *interp,
    const char *cmd, int flags);




extern int Tcl_RecordAndEvalObj(Tcl_Interp *interp,
    Tcl_Obj *cmdPtr, int flags);




extern void Tcl_RegisterChannel(Tcl_Interp *interp,
    Tcl_Channel chan);




extern void Tcl_RegisterObjType(Tcl_ObjType *typePtr);




extern Tcl_RegExp Tcl_RegExpCompile(Tcl_Interp *interp,
    const char *pattern);




extern int Tcl_RegExpExec(Tcl_Interp *interp, Tcl_RegExp regexp,
    const char *text, const char *start);




extern int Tcl_RegExpMatch(Tcl_Interp *interp, const char *text,
    const char *pattern);




extern void Tcl_RegExpRange(Tcl_RegExp regexp, int index,
    const char **startPtr,
    const char **endPtr);




extern void Tcl_Release(ClientData clientData);




extern void Tcl_ResetResult(Tcl_Interp *interp);




extern int Tcl_ScanElement(const char *str, int *flagPtr);




extern int Tcl_ScanCountedElement(const char *str, int length,
    int *flagPtr);




extern int Tcl_SeekOld(Tcl_Channel chan, int offset, int mode);




extern int Tcl_ServiceAll(void);




extern int Tcl_ServiceEvent(int flags);




extern void Tcl_SetAssocData(Tcl_Interp *interp,
    const char *name, Tcl_InterpDeleteProc *proc,
    ClientData clientData);




extern void Tcl_SetChannelBufferSize(Tcl_Channel chan, int sz);




extern int Tcl_SetChannelOption(Tcl_Interp *interp,
    Tcl_Channel chan, const char *optionName,
    const char *newValue);




extern int Tcl_SetCommandInfo(Tcl_Interp *interp,
    const char *cmdName,
    const Tcl_CmdInfo *infoPtr);




extern void Tcl_SetErrno(int err);




extern void Tcl_SetErrorCode(Tcl_Interp *interp, ...);




extern void Tcl_SetMaxBlockTime(Tcl_Time *timePtr);




extern void Tcl_SetPanicProc(Tcl_PanicProc *panicProc);




extern int Tcl_SetRecursionLimit(Tcl_Interp *interp, int depth);




extern void Tcl_SetResult(Tcl_Interp *interp, char *result,
    Tcl_FreeProc *freeProc);




extern int Tcl_SetServiceMode(int mode);




extern void Tcl_SetObjErrorCode(Tcl_Interp *interp,
    Tcl_Obj *errorObjPtr);




extern void Tcl_SetObjResult(Tcl_Interp *interp,
    Tcl_Obj *resultObjPtr);




extern void Tcl_SetStdChannel(Tcl_Channel channel, int type);




extern const char * Tcl_SetVar(Tcl_Interp *interp,
    const char *varName, const char *newValue,
    int flags);




extern const char * Tcl_SetVar2(Tcl_Interp *interp,
    const char *part1, const char *part2,
    const char *newValue, int flags);




extern const char * Tcl_SignalId(int sig);




extern const char * Tcl_SignalMsg(int sig);




extern void Tcl_SourceRCFile(Tcl_Interp *interp);




extern int Tcl_SplitList(Tcl_Interp *interp,
    const char *listStr, int *argcPtr,
    const char ***argvPtr);




extern void Tcl_SplitPath(const char *path, int *argcPtr,
    const char ***argvPtr);




extern void Tcl_StaticPackage(Tcl_Interp *interp,
    const char *pkgName,
    Tcl_PackageInitProc *initProc,
    Tcl_PackageInitProc *safeInitProc);




extern int Tcl_StringMatch(const char *str, const char *pattern);




extern int Tcl_TellOld(Tcl_Channel chan);




extern int Tcl_TraceVar(Tcl_Interp *interp, const char *varName,
    int flags, Tcl_VarTraceProc *proc,
    ClientData clientData);




extern int Tcl_TraceVar2(Tcl_Interp *interp, const char *part1,
    const char *part2, int flags,
    Tcl_VarTraceProc *proc,
    ClientData clientData);




extern char * Tcl_TranslateFileName(Tcl_Interp *interp,
    const char *name, Tcl_DString *bufferPtr);




extern int Tcl_Ungets(Tcl_Channel chan, const char *str,
    int len, int atHead);




extern void Tcl_UnlinkVar(Tcl_Interp *interp,
    const char *varName);




extern int Tcl_UnregisterChannel(Tcl_Interp *interp,
    Tcl_Channel chan);




extern int Tcl_UnsetVar(Tcl_Interp *interp, const char *varName,
    int flags);




extern int Tcl_UnsetVar2(Tcl_Interp *interp, const char *part1,
    const char *part2, int flags);




extern void Tcl_UntraceVar(Tcl_Interp *interp,
    const char *varName, int flags,
    Tcl_VarTraceProc *proc,
    ClientData clientData);




extern void Tcl_UntraceVar2(Tcl_Interp *interp,
    const char *part1, const char *part2,
    int flags, Tcl_VarTraceProc *proc,
    ClientData clientData);




extern void Tcl_UpdateLinkedVar(Tcl_Interp *interp,
    const char *varName);




extern int Tcl_UpVar(Tcl_Interp *interp, const char *frameName,
    const char *varName, const char *localName,
    int flags);




extern int Tcl_UpVar2(Tcl_Interp *interp, const char *frameName,
    const char *part1, const char *part2,
    const char *localName, int flags);




extern int Tcl_VarEval(Tcl_Interp *interp, ...);




extern ClientData Tcl_VarTraceInfo(Tcl_Interp *interp,
    const char *varName, int flags,
    Tcl_VarTraceProc *procPtr,
    ClientData prevClientData);




extern ClientData Tcl_VarTraceInfo2(Tcl_Interp *interp,
    const char *part1, const char *part2,
    int flags, Tcl_VarTraceProc *procPtr,
    ClientData prevClientData);




extern int Tcl_Write(Tcl_Channel chan, const char *s, int slen);




extern void Tcl_WrongNumArgs(Tcl_Interp *interp, int objc,
    Tcl_Obj *const objv[], const char *message);




extern int Tcl_DumpActiveMemory(const char *fileName);




extern void Tcl_ValidateAllMemory(const char *file, int line);




extern void Tcl_AppendResultVA(Tcl_Interp *interp,
    va_list argList);




extern void Tcl_AppendStringsToObjVA(Tcl_Obj *objPtr,
    va_list argList);




extern char * Tcl_HashStats(Tcl_HashTable *tablePtr);




extern const char * Tcl_ParseVar(Tcl_Interp *interp,
    const char *start, const char **termPtr);




extern const char * Tcl_PkgPresent(Tcl_Interp *interp,
    const char *name, const char *version,
    int exact);




extern const char * Tcl_PkgPresentEx(Tcl_Interp *interp,
    const char *name, const char *version,
    int exact, ClientData *clientDataPtr);




extern int Tcl_PkgProvide(Tcl_Interp *interp, const char *name,
    const char *version);




extern const char * Tcl_PkgRequire(Tcl_Interp *interp,
    const char *name, const char *version,
    int exact);




extern void Tcl_SetErrorCodeVA(Tcl_Interp *interp,
    va_list argList);




extern int Tcl_VarEvalVA(Tcl_Interp *interp, va_list argList);




extern Tcl_Pid Tcl_WaitPid(Tcl_Pid pid, int *statPtr, int options);




extern void Tcl_PanicVA(const char *format, va_list argList);




extern void Tcl_GetVersion(int *major, int *minor,
    int *patchLevel, int *type);




extern void Tcl_InitMemory(Tcl_Interp *interp);




extern Tcl_Channel Tcl_StackChannel(Tcl_Interp *interp,
    Tcl_ChannelType *typePtr,
    ClientData instanceData, int mask,
    Tcl_Channel prevChan);




extern int Tcl_UnstackChannel(Tcl_Interp *interp,
    Tcl_Channel chan);




extern Tcl_Channel Tcl_GetStackedChannel(Tcl_Channel chan);




extern void Tcl_SetMainLoop(Tcl_MainLoopProc *proc);





extern void Tcl_AppendObjToObj(Tcl_Obj *objPtr,
    Tcl_Obj *appendObjPtr);




extern Tcl_Encoding Tcl_CreateEncoding(const Tcl_EncodingType *typePtr);




extern void Tcl_CreateThreadExitHandler(Tcl_ExitProc *proc,
    ClientData clientData);




extern void Tcl_DeleteThreadExitHandler(Tcl_ExitProc *proc,
    ClientData clientData);




extern void Tcl_DiscardResult(Tcl_SavedResult *statePtr);




extern int Tcl_EvalEx(Tcl_Interp *interp, const char *script,
    int numBytes, int flags);




extern int Tcl_EvalObjv(Tcl_Interp *interp, int objc,
    Tcl_Obj *const objv[], int flags);




extern int Tcl_EvalObjEx(Tcl_Interp *interp, Tcl_Obj *objPtr,
    int flags);




extern void Tcl_ExitThread(int status);




extern int Tcl_ExternalToUtf(Tcl_Interp *interp,
    Tcl_Encoding encoding, const char *src,
    int srcLen, int flags,
    Tcl_EncodingState *statePtr, char *dst,
    int dstLen, int *srcReadPtr,
    int *dstWrotePtr, int *dstCharsPtr);




extern char * Tcl_ExternalToUtfDString(Tcl_Encoding encoding,
    const char *src, int srcLen,
    Tcl_DString *dsPtr);




extern void Tcl_FinalizeThread(void);




extern void Tcl_FinalizeNotifier(ClientData clientData);




extern void Tcl_FreeEncoding(Tcl_Encoding encoding);




extern Tcl_ThreadId Tcl_GetCurrentThread(void);




extern Tcl_Encoding Tcl_GetEncoding(Tcl_Interp *interp, const char *name);




extern const char * Tcl_GetEncodingName(Tcl_Encoding encoding);




extern void Tcl_GetEncodingNames(Tcl_Interp *interp);




extern int Tcl_GetIndexFromObjStruct(Tcl_Interp *interp,
    Tcl_Obj *objPtr, const void *tablePtr,
    int offset, const char *msg, int flags,
    int *indexPtr);




extern void * Tcl_GetThreadData(Tcl_ThreadDataKey *keyPtr,
    int size);




extern Tcl_Obj * Tcl_GetVar2Ex(Tcl_Interp *interp, const char *part1,
    const char *part2, int flags);




extern ClientData Tcl_InitNotifier(void);




extern void Tcl_MutexLock(Tcl_Mutex *mutexPtr);




extern void Tcl_MutexUnlock(Tcl_Mutex *mutexPtr);




extern void Tcl_ConditionNotify(Tcl_Condition *condPtr);




extern void Tcl_ConditionWait(Tcl_Condition *condPtr,
    Tcl_Mutex *mutexPtr, Tcl_Time *timePtr);




extern int Tcl_NumUtfChars(const char *src, int length);




extern int Tcl_ReadChars(Tcl_Channel channel, Tcl_Obj *objPtr,
    int charsToRead, int appendFlag);




extern void Tcl_RestoreResult(Tcl_Interp *interp,
    Tcl_SavedResult *statePtr);




extern void Tcl_SaveResult(Tcl_Interp *interp,
    Tcl_SavedResult *statePtr);




extern int Tcl_SetSystemEncoding(Tcl_Interp *interp,
    const char *name);




extern Tcl_Obj * Tcl_SetVar2Ex(Tcl_Interp *interp, const char *part1,
    const char *part2, Tcl_Obj *newValuePtr,
    int flags);




extern void Tcl_ThreadAlert(Tcl_ThreadId threadId);




extern void Tcl_ThreadQueueEvent(Tcl_ThreadId threadId,
    Tcl_Event *evPtr, Tcl_QueuePosition position);




extern Tcl_UniChar Tcl_UniCharAtIndex(const char *src, int index);




extern Tcl_UniChar Tcl_UniCharToLower(int ch);




extern Tcl_UniChar Tcl_UniCharToTitle(int ch);




extern Tcl_UniChar Tcl_UniCharToUpper(int ch);




extern int Tcl_UniCharToUtf(int ch, char *buf);




extern const char * Tcl_UtfAtIndex(const char *src, int index);




extern int Tcl_UtfCharComplete(const char *src, int length);




extern int Tcl_UtfBackslash(const char *src, int *readPtr,
    char *dst);




extern const char * Tcl_UtfFindFirst(const char *src, int ch);




extern const char * Tcl_UtfFindLast(const char *src, int ch);




extern const char * Tcl_UtfNext(const char *src);




extern const char * Tcl_UtfPrev(const char *src, const char *start);




extern int Tcl_UtfToExternal(Tcl_Interp *interp,
    Tcl_Encoding encoding, const char *src,
    int srcLen, int flags,
    Tcl_EncodingState *statePtr, char *dst,
    int dstLen, int *srcReadPtr,
    int *dstWrotePtr, int *dstCharsPtr);




extern char * Tcl_UtfToExternalDString(Tcl_Encoding encoding,
    const char *src, int srcLen,
    Tcl_DString *dsPtr);




extern int Tcl_UtfToLower(char *src);




extern int Tcl_UtfToTitle(char *src);




extern int Tcl_UtfToUniChar(const char *src, Tcl_UniChar *chPtr);




extern int Tcl_UtfToUpper(char *src);




extern int Tcl_WriteChars(Tcl_Channel chan, const char *src,
    int srcLen);




extern int Tcl_WriteObj(Tcl_Channel chan, Tcl_Obj *objPtr);




extern char * Tcl_GetString(Tcl_Obj *objPtr);




extern const char * Tcl_GetDefaultEncodingDir(void);




extern void Tcl_SetDefaultEncodingDir(const char *path);




extern void Tcl_AlertNotifier(ClientData clientData);




extern void Tcl_ServiceModeHook(int mode);




extern int Tcl_UniCharIsAlnum(int ch);




extern int Tcl_UniCharIsAlpha(int ch);




extern int Tcl_UniCharIsDigit(int ch);




extern int Tcl_UniCharIsLower(int ch);




extern int Tcl_UniCharIsSpace(int ch);




extern int Tcl_UniCharIsUpper(int ch);




extern int Tcl_UniCharIsWordChar(int ch);




extern int Tcl_UniCharLen(const Tcl_UniChar *uniStr);




extern int Tcl_UniCharNcmp(const Tcl_UniChar *ucs,
    const Tcl_UniChar *uct,
    unsigned long numChars);




extern char * Tcl_UniCharToUtfDString(const Tcl_UniChar *uniStr,
    int uniLength, Tcl_DString *dsPtr);




extern Tcl_UniChar * Tcl_UtfToUniCharDString(const char *src, int length,
    Tcl_DString *dsPtr);




extern Tcl_RegExp Tcl_GetRegExpFromObj(Tcl_Interp *interp,
    Tcl_Obj *patObj, int flags);




extern Tcl_Obj * Tcl_EvalTokens(Tcl_Interp *interp,
    Tcl_Token *tokenPtr, int count);




extern void Tcl_FreeParse(Tcl_Parse *parsePtr);




extern void Tcl_LogCommandInfo(Tcl_Interp *interp,
    const char *script, const char *command,
    int length);




extern int Tcl_ParseBraces(Tcl_Interp *interp,
    const char *start, int numBytes,
    Tcl_Parse *parsePtr, int append,
    const char **termPtr);




extern int Tcl_ParseCommand(Tcl_Interp *interp,
    const char *start, int numBytes, int nested,
    Tcl_Parse *parsePtr);




extern int Tcl_ParseExpr(Tcl_Interp *interp, const char *start,
    int numBytes, Tcl_Parse *parsePtr);




extern int Tcl_ParseQuotedString(Tcl_Interp *interp,
    const char *start, int numBytes,
    Tcl_Parse *parsePtr, int append,
    const char **termPtr);




extern int Tcl_ParseVarName(Tcl_Interp *interp,
    const char *start, int numBytes,
    Tcl_Parse *parsePtr, int append);




extern char * Tcl_GetCwd(Tcl_Interp *interp, Tcl_DString *cwdPtr);




extern int Tcl_Chdir(const char *dirName);




extern int Tcl_Access(const char *path, int mode);




extern int Tcl_Stat(const char *path, struct stat *bufPtr);




extern int Tcl_UtfNcmp(const char *s1, const char *s2,
    unsigned long n);




extern int Tcl_UtfNcasecmp(const char *s1, const char *s2,
    unsigned long n);




extern int Tcl_StringCaseMatch(const char *str,
    const char *pattern, int nocase);




extern int Tcl_UniCharIsControl(int ch);




extern int Tcl_UniCharIsGraph(int ch);




extern int Tcl_UniCharIsPrint(int ch);




extern int Tcl_UniCharIsPunct(int ch);




extern int Tcl_RegExpExecObj(Tcl_Interp *interp,
    Tcl_RegExp regexp, Tcl_Obj *textObj,
    int offset, int nmatches, int flags);




extern void Tcl_RegExpGetInfo(Tcl_RegExp regexp,
    Tcl_RegExpInfo *infoPtr);




extern Tcl_Obj * Tcl_NewUnicodeObj(const Tcl_UniChar *unicode,
    int numChars);




extern void Tcl_SetUnicodeObj(Tcl_Obj *objPtr,
    const Tcl_UniChar *unicode, int numChars);




extern int Tcl_GetCharLength(Tcl_Obj *objPtr);




extern Tcl_UniChar Tcl_GetUniChar(Tcl_Obj *objPtr, int index);




extern Tcl_UniChar * Tcl_GetUnicode(Tcl_Obj *objPtr);




extern Tcl_Obj * Tcl_GetRange(Tcl_Obj *objPtr, int first, int last);




extern void Tcl_AppendUnicodeToObj(Tcl_Obj *objPtr,
    const Tcl_UniChar *unicode, int length);




extern int Tcl_RegExpMatchObj(Tcl_Interp *interp,
    Tcl_Obj *textObj, Tcl_Obj *patternObj);




extern void Tcl_SetNotifier(Tcl_NotifierProcs *notifierProcPtr);




extern Tcl_Mutex * Tcl_GetAllocMutex(void);




extern int Tcl_GetChannelNames(Tcl_Interp *interp);




extern int Tcl_GetChannelNamesEx(Tcl_Interp *interp,
    const char *pattern);




extern int Tcl_ProcObjCmd(ClientData clientData,
    Tcl_Interp *interp, int objc,
    Tcl_Obj *const objv[]);




extern void Tcl_ConditionFinalize(Tcl_Condition *condPtr);




extern void Tcl_MutexFinalize(Tcl_Mutex *mutex);




extern int Tcl_CreateThread(Tcl_ThreadId *idPtr,
    Tcl_ThreadCreateProc proc,
    ClientData clientData, int stackSize,
    int flags);




extern int Tcl_ReadRaw(Tcl_Channel chan, char *dst,
    int bytesToRead);




extern int Tcl_WriteRaw(Tcl_Channel chan, const char *src,
    int srcLen);




extern Tcl_Channel Tcl_GetTopChannel(Tcl_Channel chan);




extern int Tcl_ChannelBuffered(Tcl_Channel chan);




extern const char * Tcl_ChannelName(
    const Tcl_ChannelType *chanTypePtr);




extern Tcl_ChannelTypeVersion Tcl_ChannelVersion(
    const Tcl_ChannelType *chanTypePtr);




extern Tcl_DriverBlockModeProc * Tcl_ChannelBlockModeProc(
    const Tcl_ChannelType *chanTypePtr);




extern Tcl_DriverCloseProc * Tcl_ChannelCloseProc(
    const Tcl_ChannelType *chanTypePtr);




extern Tcl_DriverClose2Proc * Tcl_ChannelClose2Proc(
    const Tcl_ChannelType *chanTypePtr);




extern Tcl_DriverInputProc * Tcl_ChannelInputProc(
    const Tcl_ChannelType *chanTypePtr);




extern Tcl_DriverOutputProc * Tcl_ChannelOutputProc(
    const Tcl_ChannelType *chanTypePtr);




extern Tcl_DriverSeekProc * Tcl_ChannelSeekProc(
    const Tcl_ChannelType *chanTypePtr);




extern Tcl_DriverSetOptionProc * Tcl_ChannelSetOptionProc(
    const Tcl_ChannelType *chanTypePtr);




extern Tcl_DriverGetOptionProc * Tcl_ChannelGetOptionProc(
    const Tcl_ChannelType *chanTypePtr);




extern Tcl_DriverWatchProc * Tcl_ChannelWatchProc(
    const Tcl_ChannelType *chanTypePtr);




extern Tcl_DriverGetHandleProc * Tcl_ChannelGetHandleProc(
    const Tcl_ChannelType *chanTypePtr);




extern Tcl_DriverFlushProc * Tcl_ChannelFlushProc(
    const Tcl_ChannelType *chanTypePtr);




extern Tcl_DriverHandlerProc * Tcl_ChannelHandlerProc(
    const Tcl_ChannelType *chanTypePtr);




extern int Tcl_JoinThread(Tcl_ThreadId threadId, int *result);




extern int Tcl_IsChannelShared(Tcl_Channel channel);




extern int Tcl_IsChannelRegistered(Tcl_Interp *interp,
    Tcl_Channel channel);




extern void Tcl_CutChannel(Tcl_Channel channel);




extern void Tcl_SpliceChannel(Tcl_Channel channel);




extern void Tcl_ClearChannelHandlers(Tcl_Channel channel);




extern int Tcl_IsChannelExisting(const char *channelName);




extern int Tcl_UniCharNcasecmp(const Tcl_UniChar *ucs,
    const Tcl_UniChar *uct,
    unsigned long numChars);




extern int Tcl_UniCharCaseMatch(const Tcl_UniChar *uniStr,
    const Tcl_UniChar *uniPattern, int nocase);




extern Tcl_HashEntry * Tcl_FindHashEntry(Tcl_HashTable *tablePtr,
    const char *key);




extern Tcl_HashEntry * Tcl_CreateHashEntry(Tcl_HashTable *tablePtr,
    const char *key, int *newPtr);




extern void Tcl_InitCustomHashTable(Tcl_HashTable *tablePtr,
    int keyType, Tcl_HashKeyType *typePtr);




extern void Tcl_InitObjHashTable(Tcl_HashTable *tablePtr);




extern ClientData Tcl_CommandTraceInfo(Tcl_Interp *interp,
    const char *varName, int flags,
    Tcl_CommandTraceProc *procPtr,
    ClientData prevClientData);




extern int Tcl_TraceCommand(Tcl_Interp *interp,
    const char *varName, int flags,
    Tcl_CommandTraceProc *proc,
    ClientData clientData);




extern void Tcl_UntraceCommand(Tcl_Interp *interp,
    const char *varName, int flags,
    Tcl_CommandTraceProc *proc,
    ClientData clientData);




extern char * Tcl_AttemptAlloc(unsigned int size);




extern char * Tcl_AttemptDbCkalloc(unsigned int size,
    const char *file, int line);




extern char * Tcl_AttemptRealloc(char *ptr, unsigned int size);




extern char * Tcl_AttemptDbCkrealloc(char *ptr, unsigned int size,
    const char *file, int line);




extern int Tcl_AttemptSetObjLength(Tcl_Obj *objPtr, int length);




extern Tcl_ThreadId Tcl_GetChannelThread(Tcl_Channel channel);




extern Tcl_UniChar * Tcl_GetUnicodeFromObj(Tcl_Obj *objPtr,
    int *lengthPtr);




extern int Tcl_GetMathFuncInfo(Tcl_Interp *interp,
    const char *name, int *numArgsPtr,
    Tcl_ValueType **argTypesPtr,
    Tcl_MathProc **procPtr,
    ClientData *clientDataPtr);




extern Tcl_Obj * Tcl_ListMathFuncs(Tcl_Interp *interp,
    const char *pattern);




extern Tcl_Obj * Tcl_SubstObj(Tcl_Interp *interp, Tcl_Obj *objPtr,
    int flags);




extern int Tcl_DetachChannel(Tcl_Interp *interp,
    Tcl_Channel channel);




extern int Tcl_IsStandardChannel(Tcl_Channel channel);




extern int Tcl_FSCopyFile(Tcl_Obj *srcPathPtr,
    Tcl_Obj *destPathPtr);




extern int Tcl_FSCopyDirectory(Tcl_Obj *srcPathPtr,
    Tcl_Obj *destPathPtr, Tcl_Obj **errorPtr);




extern int Tcl_FSCreateDirectory(Tcl_Obj *pathPtr);




extern int Tcl_FSDeleteFile(Tcl_Obj *pathPtr);




extern int Tcl_FSLoadFile(Tcl_Interp *interp, Tcl_Obj *pathPtr,
    const char *sym1, const char *sym2,
    Tcl_PackageInitProc **proc1Ptr,
    Tcl_PackageInitProc **proc2Ptr,
    Tcl_LoadHandle *handlePtr,
    Tcl_FSUnloadFileProc **unloadProcPtr);




extern int Tcl_FSMatchInDirectory(Tcl_Interp *interp,
    Tcl_Obj *result, Tcl_Obj *pathPtr,
    const char *pattern, Tcl_GlobTypeData *types);




extern Tcl_Obj * Tcl_FSLink(Tcl_Obj *pathPtr, Tcl_Obj *toPtr,
    int linkAction);




extern int Tcl_FSRemoveDirectory(Tcl_Obj *pathPtr,
    int recursive, Tcl_Obj **errorPtr);




extern int Tcl_FSRenameFile(Tcl_Obj *srcPathPtr,
    Tcl_Obj *destPathPtr);




extern int Tcl_FSLstat(Tcl_Obj *pathPtr, Tcl_StatBuf *buf);




extern int Tcl_FSUtime(Tcl_Obj *pathPtr, struct utimbuf *tval);




extern int Tcl_FSFileAttrsGet(Tcl_Interp *interp, int index,
    Tcl_Obj *pathPtr, Tcl_Obj **objPtrRef);




extern int Tcl_FSFileAttrsSet(Tcl_Interp *interp, int index,
    Tcl_Obj *pathPtr, Tcl_Obj *objPtr);




extern const char ** Tcl_FSFileAttrStrings(Tcl_Obj *pathPtr,
    Tcl_Obj **objPtrRef);




extern int Tcl_FSStat(Tcl_Obj *pathPtr, Tcl_StatBuf *buf);




extern int Tcl_FSAccess(Tcl_Obj *pathPtr, int mode);




extern Tcl_Channel Tcl_FSOpenFileChannel(Tcl_Interp *interp,
    Tcl_Obj *pathPtr, const char *modeString,
    int permissions);




extern Tcl_Obj * Tcl_FSGetCwd(Tcl_Interp *interp);




extern int Tcl_FSChdir(Tcl_Obj *pathPtr);




extern int Tcl_FSConvertToPathType(Tcl_Interp *interp,
    Tcl_Obj *pathPtr);




extern Tcl_Obj * Tcl_FSJoinPath(Tcl_Obj *listObj, int elements);




extern Tcl_Obj * Tcl_FSSplitPath(Tcl_Obj *pathPtr, int *lenPtr);




extern int Tcl_FSEqualPaths(Tcl_Obj *firstPtr,
    Tcl_Obj *secondPtr);




extern Tcl_Obj * Tcl_FSGetNormalizedPath(Tcl_Interp *interp,
    Tcl_Obj *pathPtr);




extern Tcl_Obj * Tcl_FSJoinToPath(Tcl_Obj *pathPtr, int objc,
    Tcl_Obj *const objv[]);




extern ClientData Tcl_FSGetInternalRep(Tcl_Obj *pathPtr,
    Tcl_Filesystem *fsPtr);




extern Tcl_Obj * Tcl_FSGetTranslatedPath(Tcl_Interp *interp,
    Tcl_Obj *pathPtr);




extern int Tcl_FSEvalFile(Tcl_Interp *interp, Tcl_Obj *fileName);




extern Tcl_Obj * Tcl_FSNewNativePath(Tcl_Filesystem *fromFilesystem,
    ClientData clientData);




extern const char * Tcl_FSGetNativePath(Tcl_Obj *pathPtr);




extern Tcl_Obj * Tcl_FSFileSystemInfo(Tcl_Obj *pathPtr);




extern Tcl_Obj * Tcl_FSPathSeparator(Tcl_Obj *pathPtr);




extern Tcl_Obj * Tcl_FSListVolumes(void);




extern int Tcl_FSRegister(ClientData clientData,
    Tcl_Filesystem *fsPtr);




extern int Tcl_FSUnregister(Tcl_Filesystem *fsPtr);




extern ClientData Tcl_FSData(Tcl_Filesystem *fsPtr);




extern const char * Tcl_FSGetTranslatedStringPath(Tcl_Interp *interp,
    Tcl_Obj *pathPtr);




extern Tcl_Filesystem * Tcl_FSGetFileSystemForPath(Tcl_Obj *pathPtr);




extern Tcl_PathType Tcl_FSGetPathType(Tcl_Obj *pathPtr);




extern int Tcl_OutputBuffered(Tcl_Channel chan);




extern void Tcl_FSMountsChanged(Tcl_Filesystem *fsPtr);




extern int Tcl_EvalTokensStandard(Tcl_Interp *interp,
    Tcl_Token *tokenPtr, int count);




extern void Tcl_GetTime(Tcl_Time *timeBuf);




extern Tcl_Trace Tcl_CreateObjTrace(Tcl_Interp *interp, int level,
    int flags, Tcl_CmdObjTraceProc *objProc,
    ClientData clientData,
    Tcl_CmdObjTraceDeleteProc *delProc);




extern int Tcl_GetCommandInfoFromToken(Tcl_Command token,
    Tcl_CmdInfo *infoPtr);




extern int Tcl_SetCommandInfoFromToken(Tcl_Command token,
    const Tcl_CmdInfo *infoPtr);




extern Tcl_Obj * Tcl_DbNewWideIntObj(Tcl_WideInt wideValue,
    const char *file, int line);




extern int Tcl_GetWideIntFromObj(Tcl_Interp *interp,
    Tcl_Obj *objPtr, Tcl_WideInt *widePtr);




extern Tcl_Obj * Tcl_NewWideIntObj(Tcl_WideInt wideValue);




extern void Tcl_SetWideIntObj(Tcl_Obj *objPtr,
    Tcl_WideInt wideValue);




extern Tcl_StatBuf * Tcl_AllocStatBuf(void);




extern Tcl_WideInt Tcl_Seek(Tcl_Channel chan, Tcl_WideInt offset,
    int mode);




extern Tcl_WideInt Tcl_Tell(Tcl_Channel chan);




extern Tcl_DriverWideSeekProc * Tcl_ChannelWideSeekProc(
    const Tcl_ChannelType *chanTypePtr);




extern int Tcl_DictObjPut(Tcl_Interp *interp, Tcl_Obj *dictPtr,
    Tcl_Obj *keyPtr, Tcl_Obj *valuePtr);




extern int Tcl_DictObjGet(Tcl_Interp *interp, Tcl_Obj *dictPtr,
    Tcl_Obj *keyPtr, Tcl_Obj **valuePtrPtr);




extern int Tcl_DictObjRemove(Tcl_Interp *interp,
    Tcl_Obj *dictPtr, Tcl_Obj *keyPtr);




extern int Tcl_DictObjSize(Tcl_Interp *interp, Tcl_Obj *dictPtr,
    int *sizePtr);




extern int Tcl_DictObjFirst(Tcl_Interp *interp,
    Tcl_Obj *dictPtr, Tcl_DictSearch *searchPtr,
    Tcl_Obj **keyPtrPtr, Tcl_Obj **valuePtrPtr,
    int *donePtr);




extern void Tcl_DictObjNext(Tcl_DictSearch *searchPtr,
    Tcl_Obj **keyPtrPtr, Tcl_Obj **valuePtrPtr,
    int *donePtr);




extern void Tcl_DictObjDone(Tcl_DictSearch *searchPtr);




extern int Tcl_DictObjPutKeyList(Tcl_Interp *interp,
    Tcl_Obj *dictPtr, int keyc,
    Tcl_Obj *const *keyv, Tcl_Obj *valuePtr);




extern int Tcl_DictObjRemoveKeyList(Tcl_Interp *interp,
    Tcl_Obj *dictPtr, int keyc,
    Tcl_Obj *const *keyv);




extern Tcl_Obj * Tcl_NewDictObj(void);




extern Tcl_Obj * Tcl_DbNewDictObj(const char *file, int line);




extern void Tcl_RegisterConfig(Tcl_Interp *interp,
    const char *pkgName,
    Tcl_Config *configuration,
    const char *valEncoding);




extern Tcl_Namespace * Tcl_CreateNamespace(Tcl_Interp *interp,
    const char *name, ClientData clientData,
    Tcl_NamespaceDeleteProc *deleteProc);




extern void Tcl_DeleteNamespace(Tcl_Namespace *nsPtr);




extern int Tcl_AppendExportList(Tcl_Interp *interp,
    Tcl_Namespace *nsPtr, Tcl_Obj *objPtr);




extern int Tcl_Export(Tcl_Interp *interp, Tcl_Namespace *nsPtr,
    const char *pattern, int resetListFirst);




extern int Tcl_Import(Tcl_Interp *interp, Tcl_Namespace *nsPtr,
    const char *pattern, int allowOverwrite);




extern int Tcl_ForgetImport(Tcl_Interp *interp,
    Tcl_Namespace *nsPtr, const char *pattern);




extern Tcl_Namespace * Tcl_GetCurrentNamespace(Tcl_Interp *interp);




extern Tcl_Namespace * Tcl_GetGlobalNamespace(Tcl_Interp *interp);




extern Tcl_Namespace * Tcl_FindNamespace(Tcl_Interp *interp,
    const char *name,
    Tcl_Namespace *contextNsPtr, int flags);




extern Tcl_Command Tcl_FindCommand(Tcl_Interp *interp, const char *name,
    Tcl_Namespace *contextNsPtr, int flags);




extern Tcl_Command Tcl_GetCommandFromObj(Tcl_Interp *interp,
    Tcl_Obj *objPtr);




extern void Tcl_GetCommandFullName(Tcl_Interp *interp,
    Tcl_Command command, Tcl_Obj *objPtr);




extern int Tcl_FSEvalFileEx(Tcl_Interp *interp,
    Tcl_Obj *fileName, const char *encodingName);




extern Tcl_ExitProc * Tcl_SetExitProc(Tcl_ExitProc *proc);




extern void Tcl_LimitAddHandler(Tcl_Interp *interp, int type,
    Tcl_LimitHandlerProc *handlerProc,
    ClientData clientData,
    Tcl_LimitHandlerDeleteProc *deleteProc);




extern void Tcl_LimitRemoveHandler(Tcl_Interp *interp, int type,
    Tcl_LimitHandlerProc *handlerProc,
    ClientData clientData);




extern int Tcl_LimitReady(Tcl_Interp *interp);




extern int Tcl_LimitCheck(Tcl_Interp *interp);




extern int Tcl_LimitExceeded(Tcl_Interp *interp);




extern void Tcl_LimitSetCommands(Tcl_Interp *interp,
    int commandLimit);




extern void Tcl_LimitSetTime(Tcl_Interp *interp,
    Tcl_Time *timeLimitPtr);




extern void Tcl_LimitSetGranularity(Tcl_Interp *interp, int type,
    int granularity);




extern int Tcl_LimitTypeEnabled(Tcl_Interp *interp, int type);




extern int Tcl_LimitTypeExceeded(Tcl_Interp *interp, int type);




extern void Tcl_LimitTypeSet(Tcl_Interp *interp, int type);




extern void Tcl_LimitTypeReset(Tcl_Interp *interp, int type);




extern int Tcl_LimitGetCommands(Tcl_Interp *interp);




extern void Tcl_LimitGetTime(Tcl_Interp *interp,
    Tcl_Time *timeLimitPtr);




extern int Tcl_LimitGetGranularity(Tcl_Interp *interp, int type);




extern Tcl_InterpState Tcl_SaveInterpState(Tcl_Interp *interp, int status);




extern int Tcl_RestoreInterpState(Tcl_Interp *interp,
    Tcl_InterpState state);




extern void Tcl_DiscardInterpState(Tcl_InterpState state);




extern int Tcl_SetReturnOptions(Tcl_Interp *interp,
    Tcl_Obj *options);




extern Tcl_Obj * Tcl_GetReturnOptions(Tcl_Interp *interp, int result);




extern int Tcl_IsEnsemble(Tcl_Command token);




extern Tcl_Command Tcl_CreateEnsemble(Tcl_Interp *interp,
    const char *name,
    Tcl_Namespace *namespacePtr, int flags);




extern Tcl_Command Tcl_FindEnsemble(Tcl_Interp *interp,
    Tcl_Obj *cmdNameObj, int flags);




extern int Tcl_SetEnsembleSubcommandList(Tcl_Interp *interp,
    Tcl_Command token, Tcl_Obj *subcmdList);




extern int Tcl_SetEnsembleMappingDict(Tcl_Interp *interp,
    Tcl_Command token, Tcl_Obj *mapDict);




extern int Tcl_SetEnsembleUnknownHandler(Tcl_Interp *interp,
    Tcl_Command token, Tcl_Obj *unknownList);




extern int Tcl_SetEnsembleFlags(Tcl_Interp *interp,
    Tcl_Command token, int flags);




extern int Tcl_GetEnsembleSubcommandList(Tcl_Interp *interp,
    Tcl_Command token, Tcl_Obj **subcmdListPtr);




extern int Tcl_GetEnsembleMappingDict(Tcl_Interp *interp,
    Tcl_Command token, Tcl_Obj **mapDictPtr);




extern int Tcl_GetEnsembleUnknownHandler(Tcl_Interp *interp,
    Tcl_Command token, Tcl_Obj **unknownListPtr);




extern int Tcl_GetEnsembleFlags(Tcl_Interp *interp,
    Tcl_Command token, int *flagsPtr);




extern int Tcl_GetEnsembleNamespace(Tcl_Interp *interp,
    Tcl_Command token,
    Tcl_Namespace **namespacePtrPtr);




extern void Tcl_SetTimeProc(Tcl_GetTimeProc *getProc,
    Tcl_ScaleTimeProc *scaleProc,
    ClientData clientData);




extern void Tcl_QueryTimeProc(Tcl_GetTimeProc **getProc,
    Tcl_ScaleTimeProc **scaleProc,
    ClientData *clientData);




extern Tcl_DriverThreadActionProc * Tcl_ChannelThreadActionProc(
    const Tcl_ChannelType *chanTypePtr);




extern Tcl_Obj * Tcl_NewBignumObj(mp_int *value);




extern Tcl_Obj * Tcl_DbNewBignumObj(mp_int *value, const char *file,
    int line);




extern void Tcl_SetBignumObj(Tcl_Obj *obj, mp_int *value);




extern int Tcl_GetBignumFromObj(Tcl_Interp *interp,
    Tcl_Obj *obj, mp_int *value);




extern int Tcl_TakeBignumFromObj(Tcl_Interp *interp,
    Tcl_Obj *obj, mp_int *value);




extern int Tcl_TruncateChannel(Tcl_Channel chan,
    Tcl_WideInt length);




extern Tcl_DriverTruncateProc * Tcl_ChannelTruncateProc(
    const Tcl_ChannelType *chanTypePtr);




extern void Tcl_SetChannelErrorInterp(Tcl_Interp *interp,
    Tcl_Obj *msg);




extern void Tcl_GetChannelErrorInterp(Tcl_Interp *interp,
    Tcl_Obj **msg);




extern void Tcl_SetChannelError(Tcl_Channel chan, Tcl_Obj *msg);




extern void Tcl_GetChannelError(Tcl_Channel chan, Tcl_Obj **msg);




extern int Tcl_InitBignumFromDouble(Tcl_Interp *interp,
    double initval, mp_int *toInit);




extern Tcl_Obj * Tcl_GetNamespaceUnknownHandler(Tcl_Interp *interp,
    Tcl_Namespace *nsPtr);




extern int Tcl_SetNamespaceUnknownHandler(Tcl_Interp *interp,
    Tcl_Namespace *nsPtr, Tcl_Obj *handlerPtr);




extern int Tcl_GetEncodingFromObj(Tcl_Interp *interp,
    Tcl_Obj *objPtr, Tcl_Encoding *encodingPtr);




extern Tcl_Obj * Tcl_GetEncodingSearchPath(void);




extern int Tcl_SetEncodingSearchPath(Tcl_Obj *searchPath);




extern const char * Tcl_GetEncodingNameFromEnvironment(
    Tcl_DString *bufPtr);




extern int Tcl_PkgRequireProc(Tcl_Interp *interp,
    const char *name, int objc,
    Tcl_Obj *const objv[],
    ClientData *clientDataPtr);




extern void Tcl_AppendObjToErrorInfo(Tcl_Interp *interp,
    Tcl_Obj *objPtr);




extern void Tcl_AppendLimitedToObj(Tcl_Obj *objPtr,
    const char *bytes, int length, int limit,
    const char *ellipsis);




extern Tcl_Obj * Tcl_Format(Tcl_Interp *interp, const char *format,
    int objc, Tcl_Obj *const objv[]);




extern int Tcl_AppendFormatToObj(Tcl_Interp *interp,
    Tcl_Obj *objPtr, const char *format,
    int objc, Tcl_Obj *const objv[]);




extern Tcl_Obj * Tcl_ObjPrintf(const char *format, ...);




extern void Tcl_AppendPrintfToObj(Tcl_Obj *objPtr,
    const char *format, ...);


typedef struct TclStubHooks {
    struct TclPlatStubs *tclPlatStubs;
    struct TclIntStubs *tclIntStubs;
    struct TclIntPlatStubs *tclIntPlatStubs;
} TclStubHooks;

typedef struct TclStubs {
    int magic;
    struct TclStubHooks *hooks;

    int (*tcl_PkgProvideEx) (Tcl_Interp *interp, const char *name, const char *version, ClientData clientData);
    const char * (*tcl_PkgRequireEx) (Tcl_Interp *interp, const char *name, const char *version, int exact, ClientData *clientDataPtr);
    void (*tcl_Panic) (const char *format, ...);
    char * (*tcl_Alloc) (unsigned int size);
    void (*tcl_Free) (char *ptr);
    char * (*tcl_Realloc) (char *ptr, unsigned int size);
    char * (*tcl_DbCkalloc) (unsigned int size, const char *file, int line);
    int (*tcl_DbCkfree) (char *ptr, const char *file, int line);
    char * (*tcl_DbCkrealloc) (char *ptr, unsigned int size, const char *file, int line);

    void (*tcl_CreateFileHandler) (int fd, int mask, Tcl_FileProc *proc, ClientData clientData);
# 3443 "/usr/include/tclDecls.h" 3 4
    void (*tcl_DeleteFileHandler) (int fd);







    void (*tcl_SetTimer) (Tcl_Time *timePtr);
    void (*tcl_Sleep) (int ms);
    int (*tcl_WaitForEvent) (Tcl_Time *timePtr);
    int (*tcl_AppendAllObjTypes) (Tcl_Interp *interp, Tcl_Obj *objPtr);
    void (*tcl_AppendStringsToObj) (Tcl_Obj *objPtr, ...);
    void (*tcl_AppendToObj) (Tcl_Obj *objPtr, const char *bytes, int length);
    Tcl_Obj * (*tcl_ConcatObj) (int objc, Tcl_Obj *const objv[]);
    int (*tcl_ConvertToType) (Tcl_Interp *interp, Tcl_Obj *objPtr, Tcl_ObjType *typePtr);
    void (*tcl_DbDecrRefCount) (Tcl_Obj *objPtr, const char *file, int line);
    void (*tcl_DbIncrRefCount) (Tcl_Obj *objPtr, const char *file, int line);
    int (*tcl_DbIsShared) (Tcl_Obj *objPtr, const char *file, int line);
    Tcl_Obj * (*tcl_DbNewBooleanObj) (int boolValue, const char *file, int line);
    Tcl_Obj * (*tcl_DbNewByteArrayObj) (const unsigned char *bytes, int length, const char *file, int line);
    Tcl_Obj * (*tcl_DbNewDoubleObj) (double doubleValue, const char *file, int line);
    Tcl_Obj * (*tcl_DbNewListObj) (int objc, Tcl_Obj *const *objv, const char *file, int line);
    Tcl_Obj * (*tcl_DbNewLongObj) (long longValue, const char *file, int line);
    Tcl_Obj * (*tcl_DbNewObj) (const char *file, int line);
    Tcl_Obj * (*tcl_DbNewStringObj) (const char *bytes, int length, const char *file, int line);
    Tcl_Obj * (*tcl_DuplicateObj) (Tcl_Obj *objPtr);
    void (*tclFreeObj) (Tcl_Obj *objPtr);
    int (*tcl_GetBoolean) (Tcl_Interp *interp, const char *src, int *boolPtr);
    int (*tcl_GetBooleanFromObj) (Tcl_Interp *interp, Tcl_Obj *objPtr, int *boolPtr);
    unsigned char * (*tcl_GetByteArrayFromObj) (Tcl_Obj *objPtr, int *lengthPtr);
    int (*tcl_GetDouble) (Tcl_Interp *interp, const char *src, double *doublePtr);
    int (*tcl_GetDoubleFromObj) (Tcl_Interp *interp, Tcl_Obj *objPtr, double *doublePtr);
    int (*tcl_GetIndexFromObj) (Tcl_Interp *interp, Tcl_Obj *objPtr, const char **tablePtr, const char *msg, int flags, int *indexPtr);
    int (*tcl_GetInt) (Tcl_Interp *interp, const char *src, int *intPtr);
    int (*tcl_GetIntFromObj) (Tcl_Interp *interp, Tcl_Obj *objPtr, int *intPtr);
    int (*tcl_GetLongFromObj) (Tcl_Interp *interp, Tcl_Obj *objPtr, long *longPtr);
    Tcl_ObjType * (*tcl_GetObjType) (const char *typeName);
    char * (*tcl_GetStringFromObj) (Tcl_Obj *objPtr, int *lengthPtr);
    void (*tcl_InvalidateStringRep) (Tcl_Obj *objPtr);
    int (*tcl_ListObjAppendList) (Tcl_Interp *interp, Tcl_Obj *listPtr, Tcl_Obj *elemListPtr);
    int (*tcl_ListObjAppendElement) (Tcl_Interp *interp, Tcl_Obj *listPtr, Tcl_Obj *objPtr);
    int (*tcl_ListObjGetElements) (Tcl_Interp *interp, Tcl_Obj *listPtr, int *objcPtr, Tcl_Obj ***objvPtr);
    int (*tcl_ListObjIndex) (Tcl_Interp *interp, Tcl_Obj *listPtr, int index, Tcl_Obj **objPtrPtr);
    int (*tcl_ListObjLength) (Tcl_Interp *interp, Tcl_Obj *listPtr, int *lengthPtr);
    int (*tcl_ListObjReplace) (Tcl_Interp *interp, Tcl_Obj *listPtr, int first, int count, int objc, Tcl_Obj *const objv[]);
    Tcl_Obj * (*tcl_NewBooleanObj) (int boolValue);
    Tcl_Obj * (*tcl_NewByteArrayObj) (const unsigned char *bytes, int length);
    Tcl_Obj * (*tcl_NewDoubleObj) (double doubleValue);
    Tcl_Obj * (*tcl_NewIntObj) (int intValue);
    Tcl_Obj * (*tcl_NewListObj) (int objc, Tcl_Obj *const objv[]);
    Tcl_Obj * (*tcl_NewLongObj) (long longValue);
    Tcl_Obj * (*tcl_NewObj) (void);
    Tcl_Obj * (*tcl_NewStringObj) (const char *bytes, int length);
    void (*tcl_SetBooleanObj) (Tcl_Obj *objPtr, int boolValue);
    unsigned char * (*tcl_SetByteArrayLength) (Tcl_Obj *objPtr, int length);
    void (*tcl_SetByteArrayObj) (Tcl_Obj *objPtr, const unsigned char *bytes, int length);
    void (*tcl_SetDoubleObj) (Tcl_Obj *objPtr, double doubleValue);
    void (*tcl_SetIntObj) (Tcl_Obj *objPtr, int intValue);
    void (*tcl_SetListObj) (Tcl_Obj *objPtr, int objc, Tcl_Obj *const objv[]);
    void (*tcl_SetLongObj) (Tcl_Obj *objPtr, long longValue);
    void (*tcl_SetObjLength) (Tcl_Obj *objPtr, int length);
    void (*tcl_SetStringObj) (Tcl_Obj *objPtr, const char *bytes, int length);
    void (*tcl_AddErrorInfo) (Tcl_Interp *interp, const char *message);
    void (*tcl_AddObjErrorInfo) (Tcl_Interp *interp, const char *message, int length);
    void (*tcl_AllowExceptions) (Tcl_Interp *interp);
    void (*tcl_AppendElement) (Tcl_Interp *interp, const char *element);
    void (*tcl_AppendResult) (Tcl_Interp *interp, ...);
    Tcl_AsyncHandler (*tcl_AsyncCreate) (Tcl_AsyncProc *proc, ClientData clientData);
    void (*tcl_AsyncDelete) (Tcl_AsyncHandler async);
    int (*tcl_AsyncInvoke) (Tcl_Interp *interp, int code);
    void (*tcl_AsyncMark) (Tcl_AsyncHandler async);
    int (*tcl_AsyncReady) (void);
    void (*tcl_BackgroundError) (Tcl_Interp *interp);
    char (*tcl_Backslash) (const char *src, int *readPtr);
    int (*tcl_BadChannelOption) (Tcl_Interp *interp, const char *optionName, const char *optionList);
    void (*tcl_CallWhenDeleted) (Tcl_Interp *interp, Tcl_InterpDeleteProc *proc, ClientData clientData);
    void (*tcl_CancelIdleCall) (Tcl_IdleProc *idleProc, ClientData clientData);
    int (*tcl_Close) (Tcl_Interp *interp, Tcl_Channel chan);
    int (*tcl_CommandComplete) (const char *cmd);
    char * (*tcl_Concat) (int argc, const char *const *argv);
    int (*tcl_ConvertElement) (const char *src, char *dst, int flags);
    int (*tcl_ConvertCountedElement) (const char *src, int length, char *dst, int flags);
    int (*tcl_CreateAlias) (Tcl_Interp *slave, const char *slaveCmd, Tcl_Interp *target, const char *targetCmd, int argc, const char *const *argv);
    int (*tcl_CreateAliasObj) (Tcl_Interp *slave, const char *slaveCmd, Tcl_Interp *target, const char *targetCmd, int objc, Tcl_Obj *const objv[]);
    Tcl_Channel (*tcl_CreateChannel) (Tcl_ChannelType *typePtr, const char *chanName, ClientData instanceData, int mask);
    void (*tcl_CreateChannelHandler) (Tcl_Channel chan, int mask, Tcl_ChannelProc *proc, ClientData clientData);
    void (*tcl_CreateCloseHandler) (Tcl_Channel chan, Tcl_CloseProc *proc, ClientData clientData);
    Tcl_Command (*tcl_CreateCommand) (Tcl_Interp *interp, const char *cmdName, Tcl_CmdProc *proc, ClientData clientData, Tcl_CmdDeleteProc *deleteProc);
    void (*tcl_CreateEventSource) (Tcl_EventSetupProc *setupProc, Tcl_EventCheckProc *checkProc, ClientData clientData);
    void (*tcl_CreateExitHandler) (Tcl_ExitProc *proc, ClientData clientData);
    Tcl_Interp * (*tcl_CreateInterp) (void);
    void (*tcl_CreateMathFunc) (Tcl_Interp *interp, const char *name, int numArgs, Tcl_ValueType *argTypes, Tcl_MathProc *proc, ClientData clientData);
    Tcl_Command (*tcl_CreateObjCommand) (Tcl_Interp *interp, const char *cmdName, Tcl_ObjCmdProc *proc, ClientData clientData, Tcl_CmdDeleteProc *deleteProc);
    Tcl_Interp * (*tcl_CreateSlave) (Tcl_Interp *interp, const char *slaveName, int isSafe);
    Tcl_TimerToken (*tcl_CreateTimerHandler) (int milliseconds, Tcl_TimerProc *proc, ClientData clientData);
    Tcl_Trace (*tcl_CreateTrace) (Tcl_Interp *interp, int level, Tcl_CmdTraceProc *proc, ClientData clientData);
    void (*tcl_DeleteAssocData) (Tcl_Interp *interp, const char *name);
    void (*tcl_DeleteChannelHandler) (Tcl_Channel chan, Tcl_ChannelProc *proc, ClientData clientData);
    void (*tcl_DeleteCloseHandler) (Tcl_Channel chan, Tcl_CloseProc *proc, ClientData clientData);
    int (*tcl_DeleteCommand) (Tcl_Interp *interp, const char *cmdName);
    int (*tcl_DeleteCommandFromToken) (Tcl_Interp *interp, Tcl_Command command);
    void (*tcl_DeleteEvents) (Tcl_EventDeleteProc *proc, ClientData clientData);
    void (*tcl_DeleteEventSource) (Tcl_EventSetupProc *setupProc, Tcl_EventCheckProc *checkProc, ClientData clientData);
    void (*tcl_DeleteExitHandler) (Tcl_ExitProc *proc, ClientData clientData);
    void (*tcl_DeleteHashEntry) (Tcl_HashEntry *entryPtr);
    void (*tcl_DeleteHashTable) (Tcl_HashTable *tablePtr);
    void (*tcl_DeleteInterp) (Tcl_Interp *interp);
    void (*tcl_DetachPids) (int numPids, Tcl_Pid *pidPtr);
    void (*tcl_DeleteTimerHandler) (Tcl_TimerToken token);
    void (*tcl_DeleteTrace) (Tcl_Interp *interp, Tcl_Trace trace);
    void (*tcl_DontCallWhenDeleted) (Tcl_Interp *interp, Tcl_InterpDeleteProc *proc, ClientData clientData);
    int (*tcl_DoOneEvent) (int flags);
    void (*tcl_DoWhenIdle) (Tcl_IdleProc *proc, ClientData clientData);
    char * (*tcl_DStringAppend) (Tcl_DString *dsPtr, const char *bytes, int length);
    char * (*tcl_DStringAppendElement) (Tcl_DString *dsPtr, const char *element);
    void (*tcl_DStringEndSublist) (Tcl_DString *dsPtr);
    void (*tcl_DStringFree) (Tcl_DString *dsPtr);
    void (*tcl_DStringGetResult) (Tcl_Interp *interp, Tcl_DString *dsPtr);
    void (*tcl_DStringInit) (Tcl_DString *dsPtr);
    void (*tcl_DStringResult) (Tcl_Interp *interp, Tcl_DString *dsPtr);
    void (*tcl_DStringSetLength) (Tcl_DString *dsPtr, int length);
    void (*tcl_DStringStartSublist) (Tcl_DString *dsPtr);
    int (*tcl_Eof) (Tcl_Channel chan);
    const char * (*tcl_ErrnoId) (void);
    const char * (*tcl_ErrnoMsg) (int err);
    int (*tcl_Eval) (Tcl_Interp *interp, const char *script);
    int (*tcl_EvalFile) (Tcl_Interp *interp, const char *fileName);
    int (*tcl_EvalObj) (Tcl_Interp *interp, Tcl_Obj *objPtr);
    void (*tcl_EventuallyFree) (ClientData clientData, Tcl_FreeProc *freeProc);
    void (*tcl_Exit) (int status);
    int (*tcl_ExposeCommand) (Tcl_Interp *interp, const char *hiddenCmdToken, const char *cmdName);
    int (*tcl_ExprBoolean) (Tcl_Interp *interp, const char *expr, int *ptr);
    int (*tcl_ExprBooleanObj) (Tcl_Interp *interp, Tcl_Obj *objPtr, int *ptr);
    int (*tcl_ExprDouble) (Tcl_Interp *interp, const char *expr, double *ptr);
    int (*tcl_ExprDoubleObj) (Tcl_Interp *interp, Tcl_Obj *objPtr, double *ptr);
    int (*tcl_ExprLong) (Tcl_Interp *interp, const char *expr, long *ptr);
    int (*tcl_ExprLongObj) (Tcl_Interp *interp, Tcl_Obj *objPtr, long *ptr);
    int (*tcl_ExprObj) (Tcl_Interp *interp, Tcl_Obj *objPtr, Tcl_Obj **resultPtrPtr);
    int (*tcl_ExprString) (Tcl_Interp *interp, const char *expr);
    void (*tcl_Finalize) (void);
    void (*tcl_FindExecutable) (const char *argv0);
    Tcl_HashEntry * (*tcl_FirstHashEntry) (Tcl_HashTable *tablePtr, Tcl_HashSearch *searchPtr);
    int (*tcl_Flush) (Tcl_Channel chan);
    void (*tcl_FreeResult) (Tcl_Interp *interp);
    int (*tcl_GetAlias) (Tcl_Interp *interp, const char *slaveCmd, Tcl_Interp **targetInterpPtr, const char **targetCmdPtr, int *argcPtr, const char ***argvPtr);
    int (*tcl_GetAliasObj) (Tcl_Interp *interp, const char *slaveCmd, Tcl_Interp **targetInterpPtr, const char **targetCmdPtr, int *objcPtr, Tcl_Obj ***objv);
    ClientData (*tcl_GetAssocData) (Tcl_Interp *interp, const char *name, Tcl_InterpDeleteProc **procPtr);
    Tcl_Channel (*tcl_GetChannel) (Tcl_Interp *interp, const char *chanName, int *modePtr);
    int (*tcl_GetChannelBufferSize) (Tcl_Channel chan);
    int (*tcl_GetChannelHandle) (Tcl_Channel chan, int direction, ClientData *handlePtr);
    ClientData (*tcl_GetChannelInstanceData) (Tcl_Channel chan);
    int (*tcl_GetChannelMode) (Tcl_Channel chan);
    const char * (*tcl_GetChannelName) (Tcl_Channel chan);
    int (*tcl_GetChannelOption) (Tcl_Interp *interp, Tcl_Channel chan, const char *optionName, Tcl_DString *dsPtr);
    Tcl_ChannelType * (*tcl_GetChannelType) (Tcl_Channel chan);
    int (*tcl_GetCommandInfo) (Tcl_Interp *interp, const char *cmdName, Tcl_CmdInfo *infoPtr);
    const char * (*tcl_GetCommandName) (Tcl_Interp *interp, Tcl_Command command);
    int (*tcl_GetErrno) (void);
    const char * (*tcl_GetHostName) (void);
    int (*tcl_GetInterpPath) (Tcl_Interp *askInterp, Tcl_Interp *slaveInterp);
    Tcl_Interp * (*tcl_GetMaster) (Tcl_Interp *interp);
    const char * (*tcl_GetNameOfExecutable) (void);
    Tcl_Obj * (*tcl_GetObjResult) (Tcl_Interp *interp);

    int (*tcl_GetOpenFile) (Tcl_Interp *interp, const char *chanID, int forWriting, int checkUsage, ClientData *filePtr);







    Tcl_PathType (*tcl_GetPathType) (const char *path);
    int (*tcl_Gets) (Tcl_Channel chan, Tcl_DString *dsPtr);
    int (*tcl_GetsObj) (Tcl_Channel chan, Tcl_Obj *objPtr);
    int (*tcl_GetServiceMode) (void);
    Tcl_Interp * (*tcl_GetSlave) (Tcl_Interp *interp, const char *slaveName);
    Tcl_Channel (*tcl_GetStdChannel) (int type);
    const char * (*tcl_GetStringResult) (Tcl_Interp *interp);
    const char * (*tcl_GetVar) (Tcl_Interp *interp, const char *varName, int flags);
    const char * (*tcl_GetVar2) (Tcl_Interp *interp, const char *part1, const char *part2, int flags);
    int (*tcl_GlobalEval) (Tcl_Interp *interp, const char *command);
    int (*tcl_GlobalEvalObj) (Tcl_Interp *interp, Tcl_Obj *objPtr);
    int (*tcl_HideCommand) (Tcl_Interp *interp, const char *cmdName, const char *hiddenCmdToken);
    int (*tcl_Init) (Tcl_Interp *interp);
    void (*tcl_InitHashTable) (Tcl_HashTable *tablePtr, int keyType);
    int (*tcl_InputBlocked) (Tcl_Channel chan);
    int (*tcl_InputBuffered) (Tcl_Channel chan);
    int (*tcl_InterpDeleted) (Tcl_Interp *interp);
    int (*tcl_IsSafe) (Tcl_Interp *interp);
    char * (*tcl_JoinPath) (int argc, const char *const *argv, Tcl_DString *resultPtr);
    int (*tcl_LinkVar) (Tcl_Interp *interp, const char *varName, char *addr, int type);
    void *reserved188;
    Tcl_Channel (*tcl_MakeFileChannel) (ClientData handle, int mode);
    int (*tcl_MakeSafe) (Tcl_Interp *interp);
    Tcl_Channel (*tcl_MakeTcpClientChannel) (ClientData tcpSocket);
    char * (*tcl_Merge) (int argc, const char *const *argv);
    Tcl_HashEntry * (*tcl_NextHashEntry) (Tcl_HashSearch *searchPtr);
    void (*tcl_NotifyChannel) (Tcl_Channel channel, int mask);
    Tcl_Obj * (*tcl_ObjGetVar2) (Tcl_Interp *interp, Tcl_Obj *part1Ptr, Tcl_Obj *part2Ptr, int flags);
    Tcl_Obj * (*tcl_ObjSetVar2) (Tcl_Interp *interp, Tcl_Obj *part1Ptr, Tcl_Obj *part2Ptr, Tcl_Obj *newValuePtr, int flags);
    Tcl_Channel (*tcl_OpenCommandChannel) (Tcl_Interp *interp, int argc, const char **argv, int flags);
    Tcl_Channel (*tcl_OpenFileChannel) (Tcl_Interp *interp, const char *fileName, const char *modeString, int permissions);
    Tcl_Channel (*tcl_OpenTcpClient) (Tcl_Interp *interp, int port, const char *address, const char *myaddr, int myport, int async);
    Tcl_Channel (*tcl_OpenTcpServer) (Tcl_Interp *interp, int port, const char *host, Tcl_TcpAcceptProc *acceptProc, ClientData callbackData);
    void (*tcl_Preserve) (ClientData data);
    void (*tcl_PrintDouble) (Tcl_Interp *interp, double value, char *dst);
    int (*tcl_PutEnv) (const char *assignment);
    const char * (*tcl_PosixError) (Tcl_Interp *interp);
    void (*tcl_QueueEvent) (Tcl_Event *evPtr, Tcl_QueuePosition position);
    int (*tcl_Read) (Tcl_Channel chan, char *bufPtr, int toRead);
    void (*tcl_ReapDetachedProcs) (void);
    int (*tcl_RecordAndEval) (Tcl_Interp *interp, const char *cmd, int flags);
    int (*tcl_RecordAndEvalObj) (Tcl_Interp *interp, Tcl_Obj *cmdPtr, int flags);
    void (*tcl_RegisterChannel) (Tcl_Interp *interp, Tcl_Channel chan);
    void (*tcl_RegisterObjType) (Tcl_ObjType *typePtr);
    Tcl_RegExp (*tcl_RegExpCompile) (Tcl_Interp *interp, const char *pattern);
    int (*tcl_RegExpExec) (Tcl_Interp *interp, Tcl_RegExp regexp, const char *text, const char *start);
    int (*tcl_RegExpMatch) (Tcl_Interp *interp, const char *text, const char *pattern);
    void (*tcl_RegExpRange) (Tcl_RegExp regexp, int index, const char **startPtr, const char **endPtr);
    void (*tcl_Release) (ClientData clientData);
    void (*tcl_ResetResult) (Tcl_Interp *interp);
    int (*tcl_ScanElement) (const char *str, int *flagPtr);
    int (*tcl_ScanCountedElement) (const char *str, int length, int *flagPtr);
    int (*tcl_SeekOld) (Tcl_Channel chan, int offset, int mode);
    int (*tcl_ServiceAll) (void);
    int (*tcl_ServiceEvent) (int flags);
    void (*tcl_SetAssocData) (Tcl_Interp *interp, const char *name, Tcl_InterpDeleteProc *proc, ClientData clientData);
    void (*tcl_SetChannelBufferSize) (Tcl_Channel chan, int sz);
    int (*tcl_SetChannelOption) (Tcl_Interp *interp, Tcl_Channel chan, const char *optionName, const char *newValue);
    int (*tcl_SetCommandInfo) (Tcl_Interp *interp, const char *cmdName, const Tcl_CmdInfo *infoPtr);
    void (*tcl_SetErrno) (int err);
    void (*tcl_SetErrorCode) (Tcl_Interp *interp, ...);
    void (*tcl_SetMaxBlockTime) (Tcl_Time *timePtr);
    void (*tcl_SetPanicProc) (Tcl_PanicProc *panicProc);
    int (*tcl_SetRecursionLimit) (Tcl_Interp *interp, int depth);
    void (*tcl_SetResult) (Tcl_Interp *interp, char *result, Tcl_FreeProc *freeProc);
    int (*tcl_SetServiceMode) (int mode);
    void (*tcl_SetObjErrorCode) (Tcl_Interp *interp, Tcl_Obj *errorObjPtr);
    void (*tcl_SetObjResult) (Tcl_Interp *interp, Tcl_Obj *resultObjPtr);
    void (*tcl_SetStdChannel) (Tcl_Channel channel, int type);
    const char * (*tcl_SetVar) (Tcl_Interp *interp, const char *varName, const char *newValue, int flags);
    const char * (*tcl_SetVar2) (Tcl_Interp *interp, const char *part1, const char *part2, const char *newValue, int flags);
    const char * (*tcl_SignalId) (int sig);
    const char * (*tcl_SignalMsg) (int sig);
    void (*tcl_SourceRCFile) (Tcl_Interp *interp);
    int (*tcl_SplitList) (Tcl_Interp *interp, const char *listStr, int *argcPtr, const char ***argvPtr);
    void (*tcl_SplitPath) (const char *path, int *argcPtr, const char ***argvPtr);
    void (*tcl_StaticPackage) (Tcl_Interp *interp, const char *pkgName, Tcl_PackageInitProc *initProc, Tcl_PackageInitProc *safeInitProc);
    int (*tcl_StringMatch) (const char *str, const char *pattern);
    int (*tcl_TellOld) (Tcl_Channel chan);
    int (*tcl_TraceVar) (Tcl_Interp *interp, const char *varName, int flags, Tcl_VarTraceProc *proc, ClientData clientData);
    int (*tcl_TraceVar2) (Tcl_Interp *interp, const char *part1, const char *part2, int flags, Tcl_VarTraceProc *proc, ClientData clientData);
    char * (*tcl_TranslateFileName) (Tcl_Interp *interp, const char *name, Tcl_DString *bufferPtr);
    int (*tcl_Ungets) (Tcl_Channel chan, const char *str, int len, int atHead);
    void (*tcl_UnlinkVar) (Tcl_Interp *interp, const char *varName);
    int (*tcl_UnregisterChannel) (Tcl_Interp *interp, Tcl_Channel chan);
    int (*tcl_UnsetVar) (Tcl_Interp *interp, const char *varName, int flags);
    int (*tcl_UnsetVar2) (Tcl_Interp *interp, const char *part1, const char *part2, int flags);
    void (*tcl_UntraceVar) (Tcl_Interp *interp, const char *varName, int flags, Tcl_VarTraceProc *proc, ClientData clientData);
    void (*tcl_UntraceVar2) (Tcl_Interp *interp, const char *part1, const char *part2, int flags, Tcl_VarTraceProc *proc, ClientData clientData);
    void (*tcl_UpdateLinkedVar) (Tcl_Interp *interp, const char *varName);
    int (*tcl_UpVar) (Tcl_Interp *interp, const char *frameName, const char *varName, const char *localName, int flags);
    int (*tcl_UpVar2) (Tcl_Interp *interp, const char *frameName, const char *part1, const char *part2, const char *localName, int flags);
    int (*tcl_VarEval) (Tcl_Interp *interp, ...);
    ClientData (*tcl_VarTraceInfo) (Tcl_Interp *interp, const char *varName, int flags, Tcl_VarTraceProc *procPtr, ClientData prevClientData);
    ClientData (*tcl_VarTraceInfo2) (Tcl_Interp *interp, const char *part1, const char *part2, int flags, Tcl_VarTraceProc *procPtr, ClientData prevClientData);
    int (*tcl_Write) (Tcl_Channel chan, const char *s, int slen);
    void (*tcl_WrongNumArgs) (Tcl_Interp *interp, int objc, Tcl_Obj *const objv[], const char *message);
    int (*tcl_DumpActiveMemory) (const char *fileName);
    void (*tcl_ValidateAllMemory) (const char *file, int line);
    void (*tcl_AppendResultVA) (Tcl_Interp *interp, va_list argList);
    void (*tcl_AppendStringsToObjVA) (Tcl_Obj *objPtr, va_list argList);
    char * (*tcl_HashStats) (Tcl_HashTable *tablePtr);
    const char * (*tcl_ParseVar) (Tcl_Interp *interp, const char *start, const char **termPtr);
    const char * (*tcl_PkgPresent) (Tcl_Interp *interp, const char *name, const char *version, int exact);
    const char * (*tcl_PkgPresentEx) (Tcl_Interp *interp, const char *name, const char *version, int exact, ClientData *clientDataPtr);
    int (*tcl_PkgProvide) (Tcl_Interp *interp, const char *name, const char *version);
    const char * (*tcl_PkgRequire) (Tcl_Interp *interp, const char *name, const char *version, int exact);
    void (*tcl_SetErrorCodeVA) (Tcl_Interp *interp, va_list argList);
    int (*tcl_VarEvalVA) (Tcl_Interp *interp, va_list argList);
    Tcl_Pid (*tcl_WaitPid) (Tcl_Pid pid, int *statPtr, int options);
    void (*tcl_PanicVA) (const char *format, va_list argList);
    void (*tcl_GetVersion) (int *major, int *minor, int *patchLevel, int *type);
    void (*tcl_InitMemory) (Tcl_Interp *interp);
    Tcl_Channel (*tcl_StackChannel) (Tcl_Interp *interp, Tcl_ChannelType *typePtr, ClientData instanceData, int mask, Tcl_Channel prevChan);
    int (*tcl_UnstackChannel) (Tcl_Interp *interp, Tcl_Channel chan);
    Tcl_Channel (*tcl_GetStackedChannel) (Tcl_Channel chan);
    void (*tcl_SetMainLoop) (Tcl_MainLoopProc *proc);
    void *reserved285;
    void (*tcl_AppendObjToObj) (Tcl_Obj *objPtr, Tcl_Obj *appendObjPtr);
    Tcl_Encoding (*tcl_CreateEncoding) (const Tcl_EncodingType *typePtr);
    void (*tcl_CreateThreadExitHandler) (Tcl_ExitProc *proc, ClientData clientData);
    void (*tcl_DeleteThreadExitHandler) (Tcl_ExitProc *proc, ClientData clientData);
    void (*tcl_DiscardResult) (Tcl_SavedResult *statePtr);
    int (*tcl_EvalEx) (Tcl_Interp *interp, const char *script, int numBytes, int flags);
    int (*tcl_EvalObjv) (Tcl_Interp *interp, int objc, Tcl_Obj *const objv[], int flags);
    int (*tcl_EvalObjEx) (Tcl_Interp *interp, Tcl_Obj *objPtr, int flags);
    void (*tcl_ExitThread) (int status);
    int (*tcl_ExternalToUtf) (Tcl_Interp *interp, Tcl_Encoding encoding, const char *src, int srcLen, int flags, Tcl_EncodingState *statePtr, char *dst, int dstLen, int *srcReadPtr, int *dstWrotePtr, int *dstCharsPtr);
    char * (*tcl_ExternalToUtfDString) (Tcl_Encoding encoding, const char *src, int srcLen, Tcl_DString *dsPtr);
    void (*tcl_FinalizeThread) (void);
    void (*tcl_FinalizeNotifier) (ClientData clientData);
    void (*tcl_FreeEncoding) (Tcl_Encoding encoding);
    Tcl_ThreadId (*tcl_GetCurrentThread) (void);
    Tcl_Encoding (*tcl_GetEncoding) (Tcl_Interp *interp, const char *name);
    const char * (*tcl_GetEncodingName) (Tcl_Encoding encoding);
    void (*tcl_GetEncodingNames) (Tcl_Interp *interp);
    int (*tcl_GetIndexFromObjStruct) (Tcl_Interp *interp, Tcl_Obj *objPtr, const void *tablePtr, int offset, const char *msg, int flags, int *indexPtr);
    void * (*tcl_GetThreadData) (Tcl_ThreadDataKey *keyPtr, int size);
    Tcl_Obj * (*tcl_GetVar2Ex) (Tcl_Interp *interp, const char *part1, const char *part2, int flags);
    ClientData (*tcl_InitNotifier) (void);
    void (*tcl_MutexLock) (Tcl_Mutex *mutexPtr);
    void (*tcl_MutexUnlock) (Tcl_Mutex *mutexPtr);
    void (*tcl_ConditionNotify) (Tcl_Condition *condPtr);
    void (*tcl_ConditionWait) (Tcl_Condition *condPtr, Tcl_Mutex *mutexPtr, Tcl_Time *timePtr);
    int (*tcl_NumUtfChars) (const char *src, int length);
    int (*tcl_ReadChars) (Tcl_Channel channel, Tcl_Obj *objPtr, int charsToRead, int appendFlag);
    void (*tcl_RestoreResult) (Tcl_Interp *interp, Tcl_SavedResult *statePtr);
    void (*tcl_SaveResult) (Tcl_Interp *interp, Tcl_SavedResult *statePtr);
    int (*tcl_SetSystemEncoding) (Tcl_Interp *interp, const char *name);
    Tcl_Obj * (*tcl_SetVar2Ex) (Tcl_Interp *interp, const char *part1, const char *part2, Tcl_Obj *newValuePtr, int flags);
    void (*tcl_ThreadAlert) (Tcl_ThreadId threadId);
    void (*tcl_ThreadQueueEvent) (Tcl_ThreadId threadId, Tcl_Event *evPtr, Tcl_QueuePosition position);
    Tcl_UniChar (*tcl_UniCharAtIndex) (const char *src, int index);
    Tcl_UniChar (*tcl_UniCharToLower) (int ch);
    Tcl_UniChar (*tcl_UniCharToTitle) (int ch);
    Tcl_UniChar (*tcl_UniCharToUpper) (int ch);
    int (*tcl_UniCharToUtf) (int ch, char *buf);
    const char * (*tcl_UtfAtIndex) (const char *src, int index);
    int (*tcl_UtfCharComplete) (const char *src, int length);
    int (*tcl_UtfBackslash) (const char *src, int *readPtr, char *dst);
    const char * (*tcl_UtfFindFirst) (const char *src, int ch);
    const char * (*tcl_UtfFindLast) (const char *src, int ch);
    const char * (*tcl_UtfNext) (const char *src);
    const char * (*tcl_UtfPrev) (const char *src, const char *start);
    int (*tcl_UtfToExternal) (Tcl_Interp *interp, Tcl_Encoding encoding, const char *src, int srcLen, int flags, Tcl_EncodingState *statePtr, char *dst, int dstLen, int *srcReadPtr, int *dstWrotePtr, int *dstCharsPtr);
    char * (*tcl_UtfToExternalDString) (Tcl_Encoding encoding, const char *src, int srcLen, Tcl_DString *dsPtr);
    int (*tcl_UtfToLower) (char *src);
    int (*tcl_UtfToTitle) (char *src);
    int (*tcl_UtfToUniChar) (const char *src, Tcl_UniChar *chPtr);
    int (*tcl_UtfToUpper) (char *src);
    int (*tcl_WriteChars) (Tcl_Channel chan, const char *src, int srcLen);
    int (*tcl_WriteObj) (Tcl_Channel chan, Tcl_Obj *objPtr);
    char * (*tcl_GetString) (Tcl_Obj *objPtr);
    const char * (*tcl_GetDefaultEncodingDir) (void);
    void (*tcl_SetDefaultEncodingDir) (const char *path);
    void (*tcl_AlertNotifier) (ClientData clientData);
    void (*tcl_ServiceModeHook) (int mode);
    int (*tcl_UniCharIsAlnum) (int ch);
    int (*tcl_UniCharIsAlpha) (int ch);
    int (*tcl_UniCharIsDigit) (int ch);
    int (*tcl_UniCharIsLower) (int ch);
    int (*tcl_UniCharIsSpace) (int ch);
    int (*tcl_UniCharIsUpper) (int ch);
    int (*tcl_UniCharIsWordChar) (int ch);
    int (*tcl_UniCharLen) (const Tcl_UniChar *uniStr);
    int (*tcl_UniCharNcmp) (const Tcl_UniChar *ucs, const Tcl_UniChar *uct, unsigned long numChars);
    char * (*tcl_UniCharToUtfDString) (const Tcl_UniChar *uniStr, int uniLength, Tcl_DString *dsPtr);
    Tcl_UniChar * (*tcl_UtfToUniCharDString) (const char *src, int length, Tcl_DString *dsPtr);
    Tcl_RegExp (*tcl_GetRegExpFromObj) (Tcl_Interp *interp, Tcl_Obj *patObj, int flags);
    Tcl_Obj * (*tcl_EvalTokens) (Tcl_Interp *interp, Tcl_Token *tokenPtr, int count);
    void (*tcl_FreeParse) (Tcl_Parse *parsePtr);
    void (*tcl_LogCommandInfo) (Tcl_Interp *interp, const char *script, const char *command, int length);
    int (*tcl_ParseBraces) (Tcl_Interp *interp, const char *start, int numBytes, Tcl_Parse *parsePtr, int append, const char **termPtr);
    int (*tcl_ParseCommand) (Tcl_Interp *interp, const char *start, int numBytes, int nested, Tcl_Parse *parsePtr);
    int (*tcl_ParseExpr) (Tcl_Interp *interp, const char *start, int numBytes, Tcl_Parse *parsePtr);
    int (*tcl_ParseQuotedString) (Tcl_Interp *interp, const char *start, int numBytes, Tcl_Parse *parsePtr, int append, const char **termPtr);
    int (*tcl_ParseVarName) (Tcl_Interp *interp, const char *start, int numBytes, Tcl_Parse *parsePtr, int append);
    char * (*tcl_GetCwd) (Tcl_Interp *interp, Tcl_DString *cwdPtr);
    int (*tcl_Chdir) (const char *dirName);
    int (*tcl_Access) (const char *path, int mode);
    int (*tcl_Stat) (const char *path, struct stat *bufPtr);
    int (*tcl_UtfNcmp) (const char *s1, const char *s2, unsigned long n);
    int (*tcl_UtfNcasecmp) (const char *s1, const char *s2, unsigned long n);
    int (*tcl_StringCaseMatch) (const char *str, const char *pattern, int nocase);
    int (*tcl_UniCharIsControl) (int ch);
    int (*tcl_UniCharIsGraph) (int ch);
    int (*tcl_UniCharIsPrint) (int ch);
    int (*tcl_UniCharIsPunct) (int ch);
    int (*tcl_RegExpExecObj) (Tcl_Interp *interp, Tcl_RegExp regexp, Tcl_Obj *textObj, int offset, int nmatches, int flags);
    void (*tcl_RegExpGetInfo) (Tcl_RegExp regexp, Tcl_RegExpInfo *infoPtr);
    Tcl_Obj * (*tcl_NewUnicodeObj) (const Tcl_UniChar *unicode, int numChars);
    void (*tcl_SetUnicodeObj) (Tcl_Obj *objPtr, const Tcl_UniChar *unicode, int numChars);
    int (*tcl_GetCharLength) (Tcl_Obj *objPtr);
    Tcl_UniChar (*tcl_GetUniChar) (Tcl_Obj *objPtr, int index);
    Tcl_UniChar * (*tcl_GetUnicode) (Tcl_Obj *objPtr);
    Tcl_Obj * (*tcl_GetRange) (Tcl_Obj *objPtr, int first, int last);
    void (*tcl_AppendUnicodeToObj) (Tcl_Obj *objPtr, const Tcl_UniChar *unicode, int length);
    int (*tcl_RegExpMatchObj) (Tcl_Interp *interp, Tcl_Obj *textObj, Tcl_Obj *patternObj);
    void (*tcl_SetNotifier) (Tcl_NotifierProcs *notifierProcPtr);
    Tcl_Mutex * (*tcl_GetAllocMutex) (void);
    int (*tcl_GetChannelNames) (Tcl_Interp *interp);
    int (*tcl_GetChannelNamesEx) (Tcl_Interp *interp, const char *pattern);
    int (*tcl_ProcObjCmd) (ClientData clientData, Tcl_Interp *interp, int objc, Tcl_Obj *const objv[]);
    void (*tcl_ConditionFinalize) (Tcl_Condition *condPtr);
    void (*tcl_MutexFinalize) (Tcl_Mutex *mutex);
    int (*tcl_CreateThread) (Tcl_ThreadId *idPtr, Tcl_ThreadCreateProc proc, ClientData clientData, int stackSize, int flags);
    int (*tcl_ReadRaw) (Tcl_Channel chan, char *dst, int bytesToRead);
    int (*tcl_WriteRaw) (Tcl_Channel chan, const char *src, int srcLen);
    Tcl_Channel (*tcl_GetTopChannel) (Tcl_Channel chan);
    int (*tcl_ChannelBuffered) (Tcl_Channel chan);
    const char * (*tcl_ChannelName) (const Tcl_ChannelType *chanTypePtr);
    Tcl_ChannelTypeVersion (*tcl_ChannelVersion) (const Tcl_ChannelType *chanTypePtr);
    Tcl_DriverBlockModeProc * (*tcl_ChannelBlockModeProc) (const Tcl_ChannelType *chanTypePtr);
    Tcl_DriverCloseProc * (*tcl_ChannelCloseProc) (const Tcl_ChannelType *chanTypePtr);
    Tcl_DriverClose2Proc * (*tcl_ChannelClose2Proc) (const Tcl_ChannelType *chanTypePtr);
    Tcl_DriverInputProc * (*tcl_ChannelInputProc) (const Tcl_ChannelType *chanTypePtr);
    Tcl_DriverOutputProc * (*tcl_ChannelOutputProc) (const Tcl_ChannelType *chanTypePtr);
    Tcl_DriverSeekProc * (*tcl_ChannelSeekProc) (const Tcl_ChannelType *chanTypePtr);
    Tcl_DriverSetOptionProc * (*tcl_ChannelSetOptionProc) (const Tcl_ChannelType *chanTypePtr);
    Tcl_DriverGetOptionProc * (*tcl_ChannelGetOptionProc) (const Tcl_ChannelType *chanTypePtr);
    Tcl_DriverWatchProc * (*tcl_ChannelWatchProc) (const Tcl_ChannelType *chanTypePtr);
    Tcl_DriverGetHandleProc * (*tcl_ChannelGetHandleProc) (const Tcl_ChannelType *chanTypePtr);
    Tcl_DriverFlushProc * (*tcl_ChannelFlushProc) (const Tcl_ChannelType *chanTypePtr);
    Tcl_DriverHandlerProc * (*tcl_ChannelHandlerProc) (const Tcl_ChannelType *chanTypePtr);
    int (*tcl_JoinThread) (Tcl_ThreadId threadId, int *result);
    int (*tcl_IsChannelShared) (Tcl_Channel channel);
    int (*tcl_IsChannelRegistered) (Tcl_Interp *interp, Tcl_Channel channel);
    void (*tcl_CutChannel) (Tcl_Channel channel);
    void (*tcl_SpliceChannel) (Tcl_Channel channel);
    void (*tcl_ClearChannelHandlers) (Tcl_Channel channel);
    int (*tcl_IsChannelExisting) (const char *channelName);
    int (*tcl_UniCharNcasecmp) (const Tcl_UniChar *ucs, const Tcl_UniChar *uct, unsigned long numChars);
    int (*tcl_UniCharCaseMatch) (const Tcl_UniChar *uniStr, const Tcl_UniChar *uniPattern, int nocase);
    Tcl_HashEntry * (*tcl_FindHashEntry) (Tcl_HashTable *tablePtr, const char *key);
    Tcl_HashEntry * (*tcl_CreateHashEntry) (Tcl_HashTable *tablePtr, const char *key, int *newPtr);
    void (*tcl_InitCustomHashTable) (Tcl_HashTable *tablePtr, int keyType, Tcl_HashKeyType *typePtr);
    void (*tcl_InitObjHashTable) (Tcl_HashTable *tablePtr);
    ClientData (*tcl_CommandTraceInfo) (Tcl_Interp *interp, const char *varName, int flags, Tcl_CommandTraceProc *procPtr, ClientData prevClientData);
    int (*tcl_TraceCommand) (Tcl_Interp *interp, const char *varName, int flags, Tcl_CommandTraceProc *proc, ClientData clientData);
    void (*tcl_UntraceCommand) (Tcl_Interp *interp, const char *varName, int flags, Tcl_CommandTraceProc *proc, ClientData clientData);
    char * (*tcl_AttemptAlloc) (unsigned int size);
    char * (*tcl_AttemptDbCkalloc) (unsigned int size, const char *file, int line);
    char * (*tcl_AttemptRealloc) (char *ptr, unsigned int size);
    char * (*tcl_AttemptDbCkrealloc) (char *ptr, unsigned int size, const char *file, int line);
    int (*tcl_AttemptSetObjLength) (Tcl_Obj *objPtr, int length);
    Tcl_ThreadId (*tcl_GetChannelThread) (Tcl_Channel channel);
    Tcl_UniChar * (*tcl_GetUnicodeFromObj) (Tcl_Obj *objPtr, int *lengthPtr);
    int (*tcl_GetMathFuncInfo) (Tcl_Interp *interp, const char *name, int *numArgsPtr, Tcl_ValueType **argTypesPtr, Tcl_MathProc **procPtr, ClientData *clientDataPtr);
    Tcl_Obj * (*tcl_ListMathFuncs) (Tcl_Interp *interp, const char *pattern);
    Tcl_Obj * (*tcl_SubstObj) (Tcl_Interp *interp, Tcl_Obj *objPtr, int flags);
    int (*tcl_DetachChannel) (Tcl_Interp *interp, Tcl_Channel channel);
    int (*tcl_IsStandardChannel) (Tcl_Channel channel);
    int (*tcl_FSCopyFile) (Tcl_Obj *srcPathPtr, Tcl_Obj *destPathPtr);
    int (*tcl_FSCopyDirectory) (Tcl_Obj *srcPathPtr, Tcl_Obj *destPathPtr, Tcl_Obj **errorPtr);
    int (*tcl_FSCreateDirectory) (Tcl_Obj *pathPtr);
    int (*tcl_FSDeleteFile) (Tcl_Obj *pathPtr);
    int (*tcl_FSLoadFile) (Tcl_Interp *interp, Tcl_Obj *pathPtr, const char *sym1, const char *sym2, Tcl_PackageInitProc **proc1Ptr, Tcl_PackageInitProc **proc2Ptr, Tcl_LoadHandle *handlePtr, Tcl_FSUnloadFileProc **unloadProcPtr);
    int (*tcl_FSMatchInDirectory) (Tcl_Interp *interp, Tcl_Obj *result, Tcl_Obj *pathPtr, const char *pattern, Tcl_GlobTypeData *types);
    Tcl_Obj * (*tcl_FSLink) (Tcl_Obj *pathPtr, Tcl_Obj *toPtr, int linkAction);
    int (*tcl_FSRemoveDirectory) (Tcl_Obj *pathPtr, int recursive, Tcl_Obj **errorPtr);
    int (*tcl_FSRenameFile) (Tcl_Obj *srcPathPtr, Tcl_Obj *destPathPtr);
    int (*tcl_FSLstat) (Tcl_Obj *pathPtr, Tcl_StatBuf *buf);
    int (*tcl_FSUtime) (Tcl_Obj *pathPtr, struct utimbuf *tval);
    int (*tcl_FSFileAttrsGet) (Tcl_Interp *interp, int index, Tcl_Obj *pathPtr, Tcl_Obj **objPtrRef);
    int (*tcl_FSFileAttrsSet) (Tcl_Interp *interp, int index, Tcl_Obj *pathPtr, Tcl_Obj *objPtr);
    const char ** (*tcl_FSFileAttrStrings) (Tcl_Obj *pathPtr, Tcl_Obj **objPtrRef);
    int (*tcl_FSStat) (Tcl_Obj *pathPtr, Tcl_StatBuf *buf);
    int (*tcl_FSAccess) (Tcl_Obj *pathPtr, int mode);
    Tcl_Channel (*tcl_FSOpenFileChannel) (Tcl_Interp *interp, Tcl_Obj *pathPtr, const char *modeString, int permissions);
    Tcl_Obj * (*tcl_FSGetCwd) (Tcl_Interp *interp);
    int (*tcl_FSChdir) (Tcl_Obj *pathPtr);
    int (*tcl_FSConvertToPathType) (Tcl_Interp *interp, Tcl_Obj *pathPtr);
    Tcl_Obj * (*tcl_FSJoinPath) (Tcl_Obj *listObj, int elements);
    Tcl_Obj * (*tcl_FSSplitPath) (Tcl_Obj *pathPtr, int *lenPtr);
    int (*tcl_FSEqualPaths) (Tcl_Obj *firstPtr, Tcl_Obj *secondPtr);
    Tcl_Obj * (*tcl_FSGetNormalizedPath) (Tcl_Interp *interp, Tcl_Obj *pathPtr);
    Tcl_Obj * (*tcl_FSJoinToPath) (Tcl_Obj *pathPtr, int objc, Tcl_Obj *const objv[]);
    ClientData (*tcl_FSGetInternalRep) (Tcl_Obj *pathPtr, Tcl_Filesystem *fsPtr);
    Tcl_Obj * (*tcl_FSGetTranslatedPath) (Tcl_Interp *interp, Tcl_Obj *pathPtr);
    int (*tcl_FSEvalFile) (Tcl_Interp *interp, Tcl_Obj *fileName);
    Tcl_Obj * (*tcl_FSNewNativePath) (Tcl_Filesystem *fromFilesystem, ClientData clientData);
    const char * (*tcl_FSGetNativePath) (Tcl_Obj *pathPtr);
    Tcl_Obj * (*tcl_FSFileSystemInfo) (Tcl_Obj *pathPtr);
    Tcl_Obj * (*tcl_FSPathSeparator) (Tcl_Obj *pathPtr);
    Tcl_Obj * (*tcl_FSListVolumes) (void);
    int (*tcl_FSRegister) (ClientData clientData, Tcl_Filesystem *fsPtr);
    int (*tcl_FSUnregister) (Tcl_Filesystem *fsPtr);
    ClientData (*tcl_FSData) (Tcl_Filesystem *fsPtr);
    const char * (*tcl_FSGetTranslatedStringPath) (Tcl_Interp *interp, Tcl_Obj *pathPtr);
    Tcl_Filesystem * (*tcl_FSGetFileSystemForPath) (Tcl_Obj *pathPtr);
    Tcl_PathType (*tcl_FSGetPathType) (Tcl_Obj *pathPtr);
    int (*tcl_OutputBuffered) (Tcl_Channel chan);
    void (*tcl_FSMountsChanged) (Tcl_Filesystem *fsPtr);
    int (*tcl_EvalTokensStandard) (Tcl_Interp *interp, Tcl_Token *tokenPtr, int count);
    void (*tcl_GetTime) (Tcl_Time *timeBuf);
    Tcl_Trace (*tcl_CreateObjTrace) (Tcl_Interp *interp, int level, int flags, Tcl_CmdObjTraceProc *objProc, ClientData clientData, Tcl_CmdObjTraceDeleteProc *delProc);
    int (*tcl_GetCommandInfoFromToken) (Tcl_Command token, Tcl_CmdInfo *infoPtr);
    int (*tcl_SetCommandInfoFromToken) (Tcl_Command token, const Tcl_CmdInfo *infoPtr);
    Tcl_Obj * (*tcl_DbNewWideIntObj) (Tcl_WideInt wideValue, const char *file, int line);
    int (*tcl_GetWideIntFromObj) (Tcl_Interp *interp, Tcl_Obj *objPtr, Tcl_WideInt *widePtr);
    Tcl_Obj * (*tcl_NewWideIntObj) (Tcl_WideInt wideValue);
    void (*tcl_SetWideIntObj) (Tcl_Obj *objPtr, Tcl_WideInt wideValue);
    Tcl_StatBuf * (*tcl_AllocStatBuf) (void);
    Tcl_WideInt (*tcl_Seek) (Tcl_Channel chan, Tcl_WideInt offset, int mode);
    Tcl_WideInt (*tcl_Tell) (Tcl_Channel chan);
    Tcl_DriverWideSeekProc * (*tcl_ChannelWideSeekProc) (const Tcl_ChannelType *chanTypePtr);
    int (*tcl_DictObjPut) (Tcl_Interp *interp, Tcl_Obj *dictPtr, Tcl_Obj *keyPtr, Tcl_Obj *valuePtr);
    int (*tcl_DictObjGet) (Tcl_Interp *interp, Tcl_Obj *dictPtr, Tcl_Obj *keyPtr, Tcl_Obj **valuePtrPtr);
    int (*tcl_DictObjRemove) (Tcl_Interp *interp, Tcl_Obj *dictPtr, Tcl_Obj *keyPtr);
    int (*tcl_DictObjSize) (Tcl_Interp *interp, Tcl_Obj *dictPtr, int *sizePtr);
    int (*tcl_DictObjFirst) (Tcl_Interp *interp, Tcl_Obj *dictPtr, Tcl_DictSearch *searchPtr, Tcl_Obj **keyPtrPtr, Tcl_Obj **valuePtrPtr, int *donePtr);
    void (*tcl_DictObjNext) (Tcl_DictSearch *searchPtr, Tcl_Obj **keyPtrPtr, Tcl_Obj **valuePtrPtr, int *donePtr);
    void (*tcl_DictObjDone) (Tcl_DictSearch *searchPtr);
    int (*tcl_DictObjPutKeyList) (Tcl_Interp *interp, Tcl_Obj *dictPtr, int keyc, Tcl_Obj *const *keyv, Tcl_Obj *valuePtr);
    int (*tcl_DictObjRemoveKeyList) (Tcl_Interp *interp, Tcl_Obj *dictPtr, int keyc, Tcl_Obj *const *keyv);
    Tcl_Obj * (*tcl_NewDictObj) (void);
    Tcl_Obj * (*tcl_DbNewDictObj) (const char *file, int line);
    void (*tcl_RegisterConfig) (Tcl_Interp *interp, const char *pkgName, Tcl_Config *configuration, const char *valEncoding);
    Tcl_Namespace * (*tcl_CreateNamespace) (Tcl_Interp *interp, const char *name, ClientData clientData, Tcl_NamespaceDeleteProc *deleteProc);
    void (*tcl_DeleteNamespace) (Tcl_Namespace *nsPtr);
    int (*tcl_AppendExportList) (Tcl_Interp *interp, Tcl_Namespace *nsPtr, Tcl_Obj *objPtr);
    int (*tcl_Export) (Tcl_Interp *interp, Tcl_Namespace *nsPtr, const char *pattern, int resetListFirst);
    int (*tcl_Import) (Tcl_Interp *interp, Tcl_Namespace *nsPtr, const char *pattern, int allowOverwrite);
    int (*tcl_ForgetImport) (Tcl_Interp *interp, Tcl_Namespace *nsPtr, const char *pattern);
    Tcl_Namespace * (*tcl_GetCurrentNamespace) (Tcl_Interp *interp);
    Tcl_Namespace * (*tcl_GetGlobalNamespace) (Tcl_Interp *interp);
    Tcl_Namespace * (*tcl_FindNamespace) (Tcl_Interp *interp, const char *name, Tcl_Namespace *contextNsPtr, int flags);
    Tcl_Command (*tcl_FindCommand) (Tcl_Interp *interp, const char *name, Tcl_Namespace *contextNsPtr, int flags);
    Tcl_Command (*tcl_GetCommandFromObj) (Tcl_Interp *interp, Tcl_Obj *objPtr);
    void (*tcl_GetCommandFullName) (Tcl_Interp *interp, Tcl_Command command, Tcl_Obj *objPtr);
    int (*tcl_FSEvalFileEx) (Tcl_Interp *interp, Tcl_Obj *fileName, const char *encodingName);
    Tcl_ExitProc * (*tcl_SetExitProc) (Tcl_ExitProc *proc);
    void (*tcl_LimitAddHandler) (Tcl_Interp *interp, int type, Tcl_LimitHandlerProc *handlerProc, ClientData clientData, Tcl_LimitHandlerDeleteProc *deleteProc);
    void (*tcl_LimitRemoveHandler) (Tcl_Interp *interp, int type, Tcl_LimitHandlerProc *handlerProc, ClientData clientData);
    int (*tcl_LimitReady) (Tcl_Interp *interp);
    int (*tcl_LimitCheck) (Tcl_Interp *interp);
    int (*tcl_LimitExceeded) (Tcl_Interp *interp);
    void (*tcl_LimitSetCommands) (Tcl_Interp *interp, int commandLimit);
    void (*tcl_LimitSetTime) (Tcl_Interp *interp, Tcl_Time *timeLimitPtr);
    void (*tcl_LimitSetGranularity) (Tcl_Interp *interp, int type, int granularity);
    int (*tcl_LimitTypeEnabled) (Tcl_Interp *interp, int type);
    int (*tcl_LimitTypeExceeded) (Tcl_Interp *interp, int type);
    void (*tcl_LimitTypeSet) (Tcl_Interp *interp, int type);
    void (*tcl_LimitTypeReset) (Tcl_Interp *interp, int type);
    int (*tcl_LimitGetCommands) (Tcl_Interp *interp);
    void (*tcl_LimitGetTime) (Tcl_Interp *interp, Tcl_Time *timeLimitPtr);
    int (*tcl_LimitGetGranularity) (Tcl_Interp *interp, int type);
    Tcl_InterpState (*tcl_SaveInterpState) (Tcl_Interp *interp, int status);
    int (*tcl_RestoreInterpState) (Tcl_Interp *interp, Tcl_InterpState state);
    void (*tcl_DiscardInterpState) (Tcl_InterpState state);
    int (*tcl_SetReturnOptions) (Tcl_Interp *interp, Tcl_Obj *options);
    Tcl_Obj * (*tcl_GetReturnOptions) (Tcl_Interp *interp, int result);
    int (*tcl_IsEnsemble) (Tcl_Command token);
    Tcl_Command (*tcl_CreateEnsemble) (Tcl_Interp *interp, const char *name, Tcl_Namespace *namespacePtr, int flags);
    Tcl_Command (*tcl_FindEnsemble) (Tcl_Interp *interp, Tcl_Obj *cmdNameObj, int flags);
    int (*tcl_SetEnsembleSubcommandList) (Tcl_Interp *interp, Tcl_Command token, Tcl_Obj *subcmdList);
    int (*tcl_SetEnsembleMappingDict) (Tcl_Interp *interp, Tcl_Command token, Tcl_Obj *mapDict);
    int (*tcl_SetEnsembleUnknownHandler) (Tcl_Interp *interp, Tcl_Command token, Tcl_Obj *unknownList);
    int (*tcl_SetEnsembleFlags) (Tcl_Interp *interp, Tcl_Command token, int flags);
    int (*tcl_GetEnsembleSubcommandList) (Tcl_Interp *interp, Tcl_Command token, Tcl_Obj **subcmdListPtr);
    int (*tcl_GetEnsembleMappingDict) (Tcl_Interp *interp, Tcl_Command token, Tcl_Obj **mapDictPtr);
    int (*tcl_GetEnsembleUnknownHandler) (Tcl_Interp *interp, Tcl_Command token, Tcl_Obj **unknownListPtr);
    int (*tcl_GetEnsembleFlags) (Tcl_Interp *interp, Tcl_Command token, int *flagsPtr);
    int (*tcl_GetEnsembleNamespace) (Tcl_Interp *interp, Tcl_Command token, Tcl_Namespace **namespacePtrPtr);
    void (*tcl_SetTimeProc) (Tcl_GetTimeProc *getProc, Tcl_ScaleTimeProc *scaleProc, ClientData clientData);
    void (*tcl_QueryTimeProc) (Tcl_GetTimeProc **getProc, Tcl_ScaleTimeProc **scaleProc, ClientData *clientData);
    Tcl_DriverThreadActionProc * (*tcl_ChannelThreadActionProc) (const Tcl_ChannelType *chanTypePtr);
    Tcl_Obj * (*tcl_NewBignumObj) (mp_int *value);
    Tcl_Obj * (*tcl_DbNewBignumObj) (mp_int *value, const char *file, int line);
    void (*tcl_SetBignumObj) (Tcl_Obj *obj, mp_int *value);
    int (*tcl_GetBignumFromObj) (Tcl_Interp *interp, Tcl_Obj *obj, mp_int *value);
    int (*tcl_TakeBignumFromObj) (Tcl_Interp *interp, Tcl_Obj *obj, mp_int *value);
    int (*tcl_TruncateChannel) (Tcl_Channel chan, Tcl_WideInt length);
    Tcl_DriverTruncateProc * (*tcl_ChannelTruncateProc) (const Tcl_ChannelType *chanTypePtr);
    void (*tcl_SetChannelErrorInterp) (Tcl_Interp *interp, Tcl_Obj *msg);
    void (*tcl_GetChannelErrorInterp) (Tcl_Interp *interp, Tcl_Obj **msg);
    void (*tcl_SetChannelError) (Tcl_Channel chan, Tcl_Obj *msg);
    void (*tcl_GetChannelError) (Tcl_Channel chan, Tcl_Obj **msg);
    int (*tcl_InitBignumFromDouble) (Tcl_Interp *interp, double initval, mp_int *toInit);
    Tcl_Obj * (*tcl_GetNamespaceUnknownHandler) (Tcl_Interp *interp, Tcl_Namespace *nsPtr);
    int (*tcl_SetNamespaceUnknownHandler) (Tcl_Interp *interp, Tcl_Namespace *nsPtr, Tcl_Obj *handlerPtr);
    int (*tcl_GetEncodingFromObj) (Tcl_Interp *interp, Tcl_Obj *objPtr, Tcl_Encoding *encodingPtr);
    Tcl_Obj * (*tcl_GetEncodingSearchPath) (void);
    int (*tcl_SetEncodingSearchPath) (Tcl_Obj *searchPath);
    const char * (*tcl_GetEncodingNameFromEnvironment) (Tcl_DString *bufPtr);
    int (*tcl_PkgRequireProc) (Tcl_Interp *interp, const char *name, int objc, Tcl_Obj *const objv[], ClientData *clientDataPtr);
    void (*tcl_AppendObjToErrorInfo) (Tcl_Interp *interp, Tcl_Obj *objPtr);
    void (*tcl_AppendLimitedToObj) (Tcl_Obj *objPtr, const char *bytes, int length, int limit, const char *ellipsis);
    Tcl_Obj * (*tcl_Format) (Tcl_Interp *interp, const char *format, int objc, Tcl_Obj *const objv[]);
    int (*tcl_AppendFormatToObj) (Tcl_Interp *interp, Tcl_Obj *objPtr, const char *format, int objc, Tcl_Obj *const objv[]);
    Tcl_Obj * (*tcl_ObjPrintf) (const char *format, ...);
    void (*tcl_AppendPrintfToObj) (Tcl_Obj *objPtr, const char *format, ...);
} TclStubs;




extern TclStubs *tclStubsPtr;
# 2247 "/usr/include/tcl.h" 2 3 4






# 1 "/usr/include/tclPlatDecls.h" 1 3 4
# 77 "/usr/include/tclPlatDecls.h" 3 4
typedef struct TclPlatStubs {
    int magic;
    struct TclPlatStubHooks *hooks;
# 89 "/usr/include/tclPlatDecls.h" 3 4
} TclPlatStubs;




extern TclPlatStubs *tclPlatStubsPtr;
# 2254 "/usr/include/tcl.h" 2 3 4
# 2429 "/usr/include/tcl.h" 3 4
extern int Tcl_AppInit (Tcl_Interp *interp);
# 12 "pltcl.c" 2

# 1 "./unistd.h" 1
# 14 "pltcl.c" 2
# 1 "/usr/include/fcntl.h" 1 3 4
# 23 "/usr/include/fcntl.h" 3 4
# 1 "/usr/include/sys/fcntl.h" 1 3 4
# 339 "/usr/include/sys/fcntl.h" 3 4
struct flock {
 off_t l_start;
 off_t l_len;
 pid_t l_pid;
 short l_type;
 short l_whence;
};
# 355 "/usr/include/sys/fcntl.h" 3 4
struct radvisory {
       off_t ra_offset;
       int ra_count;
};
# 367 "/usr/include/sys/fcntl.h" 3 4
typedef struct fsignatures {
 off_t fs_file_start;
 void *fs_blob_start;
 size_t fs_blob_size;
} fsignatures_t;
# 381 "/usr/include/sys/fcntl.h" 3 4
typedef struct fstore {
 unsigned int fst_flags;
 int fst_posmode;
 off_t fst_offset;
 off_t fst_length;
 off_t fst_bytesalloc;
} fstore_t;



typedef struct fbootstraptransfer {
  off_t fbt_offset;
  size_t fbt_length;
  void *fbt_buffer;
} fbootstraptransfer_t;
# 419 "/usr/include/sys/fcntl.h" 3 4
#pragma pack(4)

struct log2phys {
 unsigned int l2p_flags;
 off_t l2p_contigbytes;


 off_t l2p_devoffset;


};

#pragma pack()
# 442 "/usr/include/sys/fcntl.h" 3 4
struct _filesec;
typedef struct _filesec *filesec_t;


typedef enum {
 FILESEC_OWNER = 1,
 FILESEC_GROUP = 2,
 FILESEC_UUID = 3,
 FILESEC_MODE = 4,
 FILESEC_ACL = 5,
 FILESEC_GRPUUID = 6,


 FILESEC_ACL_RAW = 100,
 FILESEC_ACL_ALLOCSIZE = 101
} filesec_property_t;






int open(const char *, int, ...) __asm("_" "open" );
int creat(const char *, mode_t) __asm("_" "creat" );
int fcntl(int, int, ...) __asm("_" "fcntl" );


int openx_np(const char *, int, filesec_t);
int flock(int, int);
filesec_t filesec_init(void);
filesec_t filesec_dup(filesec_t);
void filesec_free(filesec_t);
int filesec_get_property(filesec_t, filesec_property_t, void *);
int filesec_query_property(filesec_t, filesec_property_t, int *);
int filesec_set_property(filesec_t, filesec_property_t, const void *);
int filesec_unset_property(filesec_t, filesec_property_t) __attribute__((visibility("default")));




# 23 "/usr/include/fcntl.h" 2 3 4
# 15 "pltcl.c" 2






# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 1
# 14 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/rmgr.h" 1
# 11 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/rmgr.h"
typedef uint8 RmgrId;
# 15 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h" 1
# 15 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
# 1 "/usr/include/fcntl.h" 1 3 4
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h" 2
# 32 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
typedef struct XLogRecPtr
{
 uint32 xlogid;
 uint32 xrecoff;
} XLogRecPtr;
# 84 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
typedef uint32 TimeLineID;
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h"
# 1 "/usr/include/math.h" 1 3 4
# 28 "/usr/include/math.h" 3 4
# 1 "/usr/include/architecture/i386/math.h" 1 3 4
# 49 "/usr/include/architecture/i386/math.h" 3 4
 typedef float float_t;
 typedef double double_t;
# 108 "/usr/include/architecture/i386/math.h" 3 4
extern int __math_errhandling ( void );
# 128 "/usr/include/architecture/i386/math.h" 3 4
extern int __fpclassifyf(float );
extern int __fpclassifyd(double );
extern int __fpclassify (long double);
# 163 "/usr/include/architecture/i386/math.h" 3 4
 static __inline__ int __inline_isfinitef (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isfinited (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isfinite (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_isinff (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isinfd (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isinf (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_isnanf (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnand (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnan (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_isnormalf (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnormald (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnormal (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_signbitf (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_signbitd (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_signbit (long double) __attribute__ ((always_inline));

 static __inline__ int __inline_isinff( float __x ) { return __builtin_fabsf(__x) == __builtin_inff(); }
 static __inline__ int __inline_isinfd( double __x ) { return __builtin_fabs(__x) == __builtin_inf(); }
 static __inline__ int __inline_isinf( long double __x ) { return __builtin_fabsl(__x) == __builtin_infl(); }
 static __inline__ int __inline_isfinitef( float __x ) { return __x == __x && __builtin_fabsf(__x) != __builtin_inff(); }
 static __inline__ int __inline_isfinited( double __x ) { return __x == __x && __builtin_fabs(__x) != __builtin_inf(); }
 static __inline__ int __inline_isfinite( long double __x ) { return __x == __x && __builtin_fabsl(__x) != __builtin_infl(); }
 static __inline__ int __inline_isnanf( float __x ) { return __x != __x; }
 static __inline__ int __inline_isnand( double __x ) { return __x != __x; }
 static __inline__ int __inline_isnan( long double __x ) { return __x != __x; }
 static __inline__ int __inline_signbitf( float __x ) { union{ float __f; unsigned int __u; }__u; __u.__f = __x; return (int)(__u.__u >> 31); }
 static __inline__ int __inline_signbitd( double __x ) { union{ double __f; unsigned int __u[2]; }__u; __u.__f = __x; return (int)(__u.__u[1] >> 31); }
 static __inline__ int __inline_signbit( long double __x ){ union{ long double __ld; struct{ unsigned int __m[2]; short __sexp; }__p; }__u; __u.__ld = __x; return (int) (((unsigned short) __u.__p.__sexp) >> 15); }
 static __inline__ int __inline_isnormalf( float __x ) { float fabsf = __builtin_fabsf(__x); if( __x != __x ) return 0; return fabsf < __builtin_inff() && fabsf >= 1.17549435e-38F; }
 static __inline__ int __inline_isnormald( double __x ) { double fabsf = __builtin_fabs(__x); if( __x != __x ) return 0; return fabsf < __builtin_inf() && fabsf >= 2.2250738585072014e-308; }
 static __inline__ int __inline_isnormal( long double __x ) { long double fabsf = __builtin_fabsl(__x); if( __x != __x ) return 0; return fabsf < __builtin_infl() && fabsf >= 3.36210314311209350626e-4932L; }
# 253 "/usr/include/architecture/i386/math.h" 3 4
extern double acos( double );
extern float acosf( float );

extern double asin( double );
extern float asinf( float );

extern double atan( double );
extern float atanf( float );

extern double atan2( double, double );
extern float atan2f( float, float );

extern double cos( double );
extern float cosf( float );

extern double sin( double );
extern float sinf( float );

extern double tan( double );
extern float tanf( float );

extern double acosh( double );
extern float acoshf( float );

extern double asinh( double );
extern float asinhf( float );

extern double atanh( double );
extern float atanhf( float );

extern double cosh( double );
extern float coshf( float );

extern double sinh( double );
extern float sinhf( float );

extern double tanh( double );
extern float tanhf( float );

extern double exp ( double );
extern float expf ( float );

extern double exp2 ( double );
extern float exp2f ( float );

extern double expm1 ( double );
extern float expm1f ( float );

extern double log ( double );
extern float logf ( float );

extern double log10 ( double );
extern float log10f ( float );

extern double log2 ( double );
extern float log2f ( float );

extern double log1p ( double );
extern float log1pf ( float );

extern double logb ( double );
extern float logbf ( float );

extern double modf ( double, double * );
extern float modff ( float, float * );

extern double ldexp ( double, int );
extern float ldexpf ( float, int );

extern double frexp ( double, int * );
extern float frexpf ( float, int * );

extern int ilogb ( double );
extern int ilogbf ( float );

extern double scalbn ( double, int );
extern float scalbnf ( float, int );

extern double scalbln ( double, long int );
extern float scalblnf ( float, long int );

extern double fabs( double );
extern float fabsf( float );

extern double cbrt( double );
extern float cbrtf( float );

extern double hypot ( double, double );
extern float hypotf ( float, float );

extern double pow ( double, double );
extern float powf ( float, float );

extern double sqrt( double );
extern float sqrtf( float );

extern double erf( double );
extern float erff( float );

extern double erfc( double );
extern float erfcf( float );






extern double lgamma( double );
extern float lgammaf( float );

extern double tgamma( double );
extern float tgammaf( float );

extern double ceil ( double );
extern float ceilf ( float );

extern double floor ( double );
extern float floorf ( float );

extern double nearbyint ( double );
extern float nearbyintf ( float );

extern double rint ( double );
extern float rintf ( float );

extern long int lrint ( double );
extern long int lrintf ( float );

extern double round ( double );
extern float roundf ( float );

extern long int lround ( double );
extern long int lroundf ( float );



    extern long long int llrint ( double );
    extern long long int llrintf ( float );
    extern long long int llround ( double );
    extern long long int llroundf ( float );


extern double trunc ( double );
extern float truncf ( float );

extern double fmod ( double, double );
extern float fmodf ( float, float );

extern double remainder ( double, double );
extern float remainderf ( float, float );

extern double remquo ( double, double, int * );
extern float remquof ( float, float, int * );

extern double copysign ( double, double );
extern float copysignf ( float, float );

extern double nan( const char * );
extern float nanf( const char * );

extern double nextafter ( double, double );
extern float nextafterf ( float, float );

extern double fdim ( double, double );
extern float fdimf ( float, float );

extern double fmax ( double, double );
extern float fmaxf ( float, float );

extern double fmin ( double, double );
extern float fminf ( float, float );

extern double fma ( double, double, double );
extern float fmaf ( float, float, float );

extern long double acosl(long double);
extern long double asinl(long double);
extern long double atanl(long double);
extern long double atan2l(long double, long double);
extern long double cosl(long double);
extern long double sinl(long double);
extern long double tanl(long double);
extern long double acoshl(long double);
extern long double asinhl(long double);
extern long double atanhl(long double);
extern long double coshl(long double);
extern long double sinhl(long double);
extern long double tanhl(long double);
extern long double expl(long double);
extern long double exp2l(long double);
extern long double expm1l(long double);
extern long double logl(long double);
extern long double log10l(long double);
extern long double log2l(long double);
extern long double log1pl(long double);
extern long double logbl(long double);
extern long double modfl(long double, long double *);
extern long double ldexpl(long double, int);
extern long double frexpl(long double, int *);
extern int ilogbl(long double);
extern long double scalbnl(long double, int);
extern long double scalblnl(long double, long int);
extern long double fabsl(long double);
extern long double cbrtl(long double);
extern long double hypotl(long double, long double);
extern long double powl(long double, long double);
extern long double sqrtl(long double);
extern long double erfl(long double);
extern long double erfcl(long double);






extern long double lgammal(long double);

extern long double tgammal(long double);
extern long double ceill(long double);
extern long double floorl(long double);
extern long double nearbyintl(long double);
extern long double rintl(long double);
extern long int lrintl(long double);
extern long double roundl(long double);
extern long int lroundl(long double);



    extern long long int llrintl(long double);
    extern long long int llroundl(long double);


extern long double truncl(long double);
extern long double fmodl(long double, long double);
extern long double remainderl(long double, long double);
extern long double remquol(long double, long double, int *);
extern long double copysignl(long double, long double);
extern long double nanl(const char *);
extern long double nextafterl(long double, long double);
extern double nexttoward(double, long double);
extern float nexttowardf(float, long double);
extern long double nexttowardl(long double, long double);
extern long double fdiml(long double, long double);
extern long double fmaxl(long double, long double);
extern long double fminl(long double, long double);
extern long double fmal(long double, long double, long double);
# 507 "/usr/include/architecture/i386/math.h" 3 4
extern double __inf( void );
extern float __inff( void );
extern long double __infl( void );
extern float __nan( void );


extern double j0 ( double );

extern double j1 ( double );

extern double jn ( int, double );

extern double y0 ( double );

extern double y1 ( double );

extern double yn ( int, double );

extern double scalb ( double, double );
# 543 "/usr/include/architecture/i386/math.h" 3 4
extern int signgam;
# 558 "/usr/include/architecture/i386/math.h" 3 4
extern long int rinttol ( double );


extern long int roundtol ( double );
# 570 "/usr/include/architecture/i386/math.h" 3 4
struct exception {
 int type;
 char *name;
 double arg1;
 double arg2;
 double retval;
};
# 601 "/usr/include/architecture/i386/math.h" 3 4
extern int finite ( double );


extern double gamma ( double );




extern int matherr ( struct exception * );





extern double significand ( double );






extern double drem ( double, double );
# 29 "/usr/include/math.h" 2 3 4
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 1 3 4






# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/syslimits.h" 1 3 4
# 8 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 2 3 4







# 1 "/usr/include/limits.h" 1 3 4
# 64 "/usr/include/limits.h" 3 4
# 1 "/usr/include/machine/limits.h" 1 3 4





# 1 "/usr/include/i386/limits.h" 1 3 4
# 40 "/usr/include/i386/limits.h" 3 4
# 1 "/usr/include/i386/_limits.h" 1 3 4
# 41 "/usr/include/i386/limits.h" 2 3 4
# 7 "/usr/include/machine/limits.h" 2 3 4
# 65 "/usr/include/limits.h" 2 3 4
# 1 "/usr/include/sys/syslimits.h" 1 3 4
# 66 "/usr/include/limits.h" 2 3 4
# 16 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 2 3 4
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/float.h" 1 3 4
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h" 2
# 44 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h"
typedef int64 Timestamp;
typedef int64 TimestampTz;
typedef int64 TimeOffset;
typedef int32 fsec_t;
# 56 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h"
typedef struct
{
 TimeOffset time;

 int32 day;
 int32 month;
} Interval;
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h" 1
# 35 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
typedef struct StringInfoData
{
 char *data;
 int len;
 int maxlen;
 int cursor;
} StringInfoData;

typedef StringInfoData *StringInfo;
# 72 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
extern StringInfo makeStringInfo(void);






extern void initStringInfo(StringInfo str);






extern void resetStringInfo(StringInfo str);
# 95 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
extern void
appendStringInfo(StringInfo str, const char *fmt,...)

__attribute__((format(printf, 2, 3)));
# 108 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
extern bool
appendStringInfoVA(StringInfo str, const char *fmt, va_list args)
__attribute__((format(printf, 2, 0)));






extern void appendStringInfoString(StringInfo str, const char *s);






extern void appendStringInfoChar(StringInfo str, char ch);
# 140 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
extern void appendStringInfoSpaces(StringInfo str, int count);






extern void appendBinaryStringInfo(StringInfo str,
        const char *data, int datalen);





extern void enlargeStringInfo(StringInfo str, int needed);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h"
typedef int Buffer;
# 44 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h"
typedef struct BufferAccessStrategyData *BufferAccessStrategy;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/pg_crc.h" 1
# 32 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/pg_crc.h"
typedef uint32 pg_crc32;
# 57 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/pg_crc.h"
extern const uint32 pg_crc32_table[];
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 2
# 41 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
typedef struct XLogRecord
{
 pg_crc32 xl_crc;
 XLogRecPtr xl_prev;
 TransactionId xl_xid;
 uint32 xl_tot_len;
 uint32 xl_len;
 uint8 xl_info;
 RmgrId xl_rmid;





} XLogRecord;
# 88 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
extern int sync_method;
# 120 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
typedef struct XLogRecData
{
 char *data;
 uint32 len;
 Buffer buffer;
 bool buffer_std;
 struct XLogRecData *next;
} XLogRecData;

extern TimeLineID ThisTimeLineID;
# 138 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
extern bool InRecovery;
# 161 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
typedef enum
{
 STANDBY_DISABLED,
 STANDBY_INITIALIZED,
 STANDBY_SNAPSHOT_PENDING,
 STANDBY_SNAPSHOT_READY
} HotStandbyState;

extern HotStandbyState standbyState;







typedef enum
{
 RECOVERY_TARGET_UNSET,
 RECOVERY_TARGET_XID,
 RECOVERY_TARGET_TIME,
 RECOVERY_TARGET_NAME
} RecoveryTargetType;

extern XLogRecPtr XactLastRecEnd;

extern bool reachedConsistency;


extern int CheckPointSegments;
extern int wal_keep_segments;
extern int XLOGbuffers;
extern int XLogArchiveTimeout;
extern bool XLogArchiveMode;
extern char *XLogArchiveCommand;
extern bool EnableHotStandby;
extern bool fullPageWrites;
extern bool log_checkpoints;


typedef enum WalLevel
{
 WAL_LEVEL_MINIMAL = 0,
 WAL_LEVEL_ARCHIVE,
 WAL_LEVEL_HOT_STANDBY
} WalLevel;
extern int wal_level;
# 245 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
typedef struct CheckpointStatsData
{
 TimestampTz ckpt_start_t;
 TimestampTz ckpt_write_t;
 TimestampTz ckpt_sync_t;
 TimestampTz ckpt_sync_end_t;
 TimestampTz ckpt_end_t;

 int ckpt_bufs_written;

 int ckpt_segs_added;
 int ckpt_segs_removed;
 int ckpt_segs_recycled;

 int ckpt_sync_rels;
 uint64 ckpt_longest_sync;
 uint64 ckpt_agg_sync_time;



} CheckpointStatsData;

extern CheckpointStatsData CheckpointStats;

extern XLogRecPtr XLogInsert(RmgrId rmid, uint8 info, XLogRecData *rdata);
extern void XLogFlush(XLogRecPtr RecPtr);
extern bool XLogBackgroundFlush(void);
extern bool XLogNeedsFlush(XLogRecPtr RecPtr);
extern int XLogFileInit(uint32 log, uint32 seg,
    bool *use_existent, bool use_lock);
extern int XLogFileOpen(uint32 log, uint32 seg);


extern void CheckXLogRemoved(uint32 log, uint32 seg, TimeLineID tli);
extern void XLogSetAsyncXactLSN(XLogRecPtr record);

extern Buffer RestoreBackupBlock(XLogRecPtr lsn, XLogRecord *record,
       int block_index,
       bool get_cleanup_lock, bool keep_buffer);

extern void xlog_redo(XLogRecPtr lsn, XLogRecord *record);
extern void xlog_desc(StringInfo buf, uint8 xl_info, char *rec);

extern void issue_xlog_fsync(int fd, uint32 log, uint32 seg);

extern bool RecoveryInProgress(void);
extern bool HotStandbyActive(void);
extern bool XLogInsertAllowed(void);
extern void GetXLogReceiptTime(TimestampTz *rtime, bool *fromStream);
extern XLogRecPtr GetXLogReplayRecPtr(TimeLineID *targetTLI);
extern XLogRecPtr GetStandbyFlushRecPtr(TimeLineID *targetTLI);
extern XLogRecPtr GetXLogInsertRecPtr(void);
extern XLogRecPtr GetXLogWriteRecPtr(void);
extern bool RecoveryIsPaused(void);
extern void SetRecoveryPause(bool recoveryPause);
extern TimestampTz GetLatestXTime(void);
extern TimestampTz GetCurrentChunkReplayStartTime(void);

extern void UpdateControlFile(void);
extern uint64 GetSystemIdentifier(void);
extern Size XLOGShmemSize(void);
extern void XLOGShmemInit(void);
extern void BootStrapXLOG(void);
extern void StartupXLOG(void);
extern void ShutdownXLOG(int code, Datum arg);
extern void InitXLOGAccess(void);
extern void CreateCheckPoint(int flags);
extern bool CreateRestartPoint(int flags);
extern void XLogPutNextOid(Oid nextOid);
extern XLogRecPtr XLogRestorePoint(const char *rpName);
extern void UpdateFullPageWrites(void);
extern XLogRecPtr GetRedoRecPtr(void);
extern XLogRecPtr GetInsertRecPtr(void);
extern XLogRecPtr GetFlushRecPtr(void);
extern void GetNextXidAndEpoch(TransactionId *xid, uint32 *epoch);
extern TimeLineID GetRecoveryTargetTLI(void);

extern bool CheckPromoteSignal(void);
extern void WakeupRecovery(void);
extern void SetWalWriterSleeping(bool sleeping);




extern XLogRecPtr do_pg_start_backup(const char *backupidstr, bool fast, char **labelfile);
extern XLogRecPtr do_pg_stop_backup(char *labelfile, bool waitforarchive);
extern void do_pg_abort_backup(void);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 1
# 40 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h" 1
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum NodeTag
{
 T_Invalid = 0,




 T_IndexInfo = 10,
 T_ExprContext,
 T_ProjectionInfo,
 T_JunkFilter,
 T_ResultRelInfo,
 T_EState,
 T_TupleTableSlot,




 T_Plan = 100,
 T_Result,
 T_ModifyTable,
 T_Append,
 T_MergeAppend,
 T_RecursiveUnion,
 T_BitmapAnd,
 T_BitmapOr,
 T_Scan,
 T_SeqScan,
 T_IndexScan,
 T_IndexOnlyScan,
 T_BitmapIndexScan,
 T_BitmapHeapScan,
 T_TidScan,
 T_SubqueryScan,
 T_FunctionScan,
 T_ValuesScan,
 T_CteScan,
 T_WorkTableScan,
 T_ForeignScan,
 T_Join,
 T_NestLoop,
 T_MergeJoin,
 T_HashJoin,
 T_Material,
 T_Sort,
 T_Group,
 T_Agg,
 T_WindowAgg,
 T_Unique,
 T_Hash,
 T_SetOp,
 T_LockRows,
 T_Limit,

 T_NestLoopParam,
 T_PlanRowMark,
 T_PlanInvalItem,






 T_PlanState = 200,
 T_ResultState,
 T_ModifyTableState,
 T_AppendState,
 T_MergeAppendState,
 T_RecursiveUnionState,
 T_BitmapAndState,
 T_BitmapOrState,
 T_ScanState,
 T_SeqScanState,
 T_IndexScanState,
 T_IndexOnlyScanState,
 T_BitmapIndexScanState,
 T_BitmapHeapScanState,
 T_TidScanState,
 T_SubqueryScanState,
 T_FunctionScanState,
 T_ValuesScanState,
 T_CteScanState,
 T_WorkTableScanState,
 T_ForeignScanState,
 T_JoinState,
 T_NestLoopState,
 T_MergeJoinState,
 T_HashJoinState,
 T_MaterialState,
 T_SortState,
 T_GroupState,
 T_AggState,
 T_WindowAggState,
 T_UniqueState,
 T_HashState,
 T_SetOpState,
 T_LockRowsState,
 T_LimitState,




 T_Alias = 300,
 T_RangeVar,
 T_Expr,
 T_Var,
 T_Const,
 T_Param,
 T_Aggref,
 T_WindowFunc,
 T_ArrayRef,
 T_FuncExpr,
 T_NamedArgExpr,
 T_OpExpr,
 T_DistinctExpr,
 T_NullIfExpr,
 T_ScalarArrayOpExpr,
 T_BoolExpr,
 T_SubLink,
 T_SubPlan,
 T_AlternativeSubPlan,
 T_FieldSelect,
 T_FieldStore,
 T_RelabelType,
 T_CoerceViaIO,
 T_ArrayCoerceExpr,
 T_ConvertRowtypeExpr,
 T_CollateExpr,
 T_CaseExpr,
 T_CaseWhen,
 T_CaseTestExpr,
 T_ArrayExpr,
 T_RowExpr,
 T_RowCompareExpr,
 T_CoalesceExpr,
 T_MinMaxExpr,
 T_XmlExpr,
 T_NullTest,
 T_BooleanTest,
 T_CoerceToDomain,
 T_CoerceToDomainValue,
 T_SetToDefault,
 T_CurrentOfExpr,
 T_TargetEntry,
 T_RangeTblRef,
 T_JoinExpr,
 T_FromExpr,
 T_IntoClause,







 T_ExprState = 400,
 T_GenericExprState,
 T_AggrefExprState,
 T_WindowFuncExprState,
 T_ArrayRefExprState,
 T_FuncExprState,
 T_ScalarArrayOpExprState,
 T_BoolExprState,
 T_SubPlanState,
 T_AlternativeSubPlanState,
 T_FieldSelectState,
 T_FieldStoreState,
 T_CoerceViaIOState,
 T_ArrayCoerceExprState,
 T_ConvertRowtypeExprState,
 T_CaseExprState,
 T_CaseWhenState,
 T_ArrayExprState,
 T_RowExprState,
 T_RowCompareExprState,
 T_CoalesceExprState,
 T_MinMaxExprState,
 T_XmlExprState,
 T_NullTestState,
 T_CoerceToDomainState,
 T_DomainConstraintState,
 T_WholeRowVarExprState,




 T_PlannerInfo = 500,
 T_PlannerGlobal,
 T_RelOptInfo,
 T_IndexOptInfo,
 T_ParamPathInfo,
 T_Path,
 T_IndexPath,
 T_BitmapHeapPath,
 T_BitmapAndPath,
 T_BitmapOrPath,
 T_NestPath,
 T_MergePath,
 T_HashPath,
 T_TidPath,
 T_ForeignPath,
 T_AppendPath,
 T_MergeAppendPath,
 T_ResultPath,
 T_MaterialPath,
 T_UniquePath,
 T_EquivalenceClass,
 T_EquivalenceMember,
 T_PathKey,
 T_RestrictInfo,
 T_PlaceHolderVar,
 T_SpecialJoinInfo,
 T_AppendRelInfo,
 T_PlaceHolderInfo,
 T_MinMaxAggInfo,
 T_PlannerParamItem,




 T_MemoryContext = 600,
 T_AllocSetContext,




 T_Value = 650,
 T_Integer,
 T_Float,
 T_String,
 T_BitString,
 T_Null,




 T_List,
 T_IntList,
 T_OidList,




 T_Query = 700,
 T_PlannedStmt,
 T_InsertStmt,
 T_DeleteStmt,
 T_UpdateStmt,
 T_SelectStmt,
 T_AlterTableStmt,
 T_AlterTableCmd,
 T_AlterDomainStmt,
 T_SetOperationStmt,
 T_GrantStmt,
 T_GrantRoleStmt,
 T_AlterDefaultPrivilegesStmt,
 T_ClosePortalStmt,
 T_ClusterStmt,
 T_CopyStmt,
 T_CreateStmt,
 T_DefineStmt,
 T_DropStmt,
 T_TruncateStmt,
 T_CommentStmt,
 T_FetchStmt,
 T_IndexStmt,
 T_CreateFunctionStmt,
 T_AlterFunctionStmt,
 T_DoStmt,
 T_RenameStmt,
 T_RuleStmt,
 T_NotifyStmt,
 T_ListenStmt,
 T_UnlistenStmt,
 T_TransactionStmt,
 T_ViewStmt,
 T_LoadStmt,
 T_CreateDomainStmt,
 T_CreatedbStmt,
 T_DropdbStmt,
 T_VacuumStmt,
 T_ExplainStmt,
 T_CreateTableAsStmt,
 T_CreateSeqStmt,
 T_AlterSeqStmt,
 T_VariableSetStmt,
 T_VariableShowStmt,
 T_DiscardStmt,
 T_CreateTrigStmt,
 T_CreatePLangStmt,
 T_CreateRoleStmt,
 T_AlterRoleStmt,
 T_DropRoleStmt,
 T_LockStmt,
 T_ConstraintsSetStmt,
 T_ReindexStmt,
 T_CheckPointStmt,
 T_CreateSchemaStmt,
 T_AlterDatabaseStmt,
 T_AlterDatabaseSetStmt,
 T_AlterRoleSetStmt,
 T_CreateConversionStmt,
 T_CreateCastStmt,
 T_CreateOpClassStmt,
 T_CreateOpFamilyStmt,
 T_AlterOpFamilyStmt,
 T_PrepareStmt,
 T_ExecuteStmt,
 T_DeallocateStmt,
 T_DeclareCursorStmt,
 T_CreateTableSpaceStmt,
 T_DropTableSpaceStmt,
 T_AlterObjectSchemaStmt,
 T_AlterOwnerStmt,
 T_DropOwnedStmt,
 T_ReassignOwnedStmt,
 T_CompositeTypeStmt,
 T_CreateEnumStmt,
 T_CreateRangeStmt,
 T_AlterEnumStmt,
 T_AlterTSDictionaryStmt,
 T_AlterTSConfigurationStmt,
 T_CreateFdwStmt,
 T_AlterFdwStmt,
 T_CreateForeignServerStmt,
 T_AlterForeignServerStmt,
 T_CreateUserMappingStmt,
 T_AlterUserMappingStmt,
 T_DropUserMappingStmt,
 T_AlterTableSpaceOptionsStmt,
 T_SecLabelStmt,
 T_CreateForeignTableStmt,
 T_CreateExtensionStmt,
 T_AlterExtensionStmt,
 T_AlterExtensionContentsStmt,




 T_A_Expr = 900,
 T_ColumnRef,
 T_ParamRef,
 T_A_Const,
 T_FuncCall,
 T_A_Star,
 T_A_Indices,
 T_A_Indirection,
 T_A_ArrayExpr,
 T_ResTarget,
 T_TypeCast,
 T_CollateClause,
 T_SortBy,
 T_WindowDef,
 T_RangeSubselect,
 T_RangeFunction,
 T_TypeName,
 T_ColumnDef,
 T_IndexElem,
 T_Constraint,
 T_DefElem,
 T_RangeTblEntry,
 T_SortGroupClause,
 T_WindowClause,
 T_PrivGrantee,
 T_FuncWithArgs,
 T_AccessPriv,
 T_CreateOpClassItem,
 T_TableLikeClause,
 T_FunctionParameter,
 T_LockingClause,
 T_RowMarkClause,
 T_XmlSerialize,
 T_WithClause,
 T_CommonTableExpr,




 T_IdentifySystemCmd,
 T_BaseBackupCmd,
 T_StartReplicationCmd,
# 416 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
 T_TriggerData = 950,
 T_ReturnSetInfo,
 T_WindowObjectData,
 T_TIDBitmap,
 T_InlineCodeBlock,
 T_FdwRoutine
} NodeTag;







typedef struct Node
{
 NodeTag type;
} Node;
# 491 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
extern char *nodeToString(const void *obj);




extern void *stringToNode(char *str);




extern void *copyObject(const void *obj);




extern bool equal(const void *a, const void *b);
# 517 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef double Selectivity;
typedef double Cost;
# 527 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum CmdType
{
 CMD_UNKNOWN,
 CMD_SELECT,
 CMD_UPDATE,
 CMD_INSERT,
 CMD_DELETE,
 CMD_UTILITY,

 CMD_NOTHING

} CmdType;
# 551 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum JoinType
{




 JOIN_INNER,
 JOIN_LEFT,
 JOIN_FULL,
 JOIN_RIGHT,
# 571 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
 JOIN_SEMI,
 JOIN_ANTI,





 JOIN_UNIQUE_OUTER,
 JOIN_UNIQUE_INNER




} JoinType;
# 41 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 2


typedef struct ListCell ListCell;

typedef struct List
{
 NodeTag type;
 int length;
 ListCell *head;
 ListCell *tail;
} List;

struct ListCell
{
 union
 {
  void *ptr_value;
  int int_value;
  Oid oid_value;
 } data;
 ListCell *next;
};
# 79 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
static inline ListCell *
list_head(const List *l)
{
 return l ? l->head : ((void *)0);
}

static inline ListCell *
list_tail(List *l)
{
 return l ? l->tail : ((void *)0);
}

static inline int
list_length(const List *l)
{
 return l ? l->length : 0;
}
# 194 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
extern List *lappend(List *list, void *datum);
extern List *lappend_int(List *list, int datum);
extern List *lappend_oid(List *list, Oid datum);

extern ListCell *lappend_cell(List *list, ListCell *prev, void *datum);
extern ListCell *lappend_cell_int(List *list, ListCell *prev, int datum);
extern ListCell *lappend_cell_oid(List *list, ListCell *prev, Oid datum);

extern List *lcons(void *datum, List *list);
extern List *lcons_int(int datum, List *list);
extern List *lcons_oid(Oid datum, List *list);

extern List *list_concat(List *list1, List *list2);
extern List *list_truncate(List *list, int new_size);

extern void *list_nth(const List *list, int n);
extern int list_nth_int(const List *list, int n);
extern Oid list_nth_oid(const List *list, int n);

extern bool list_member(const List *list, const void *datum);
extern bool list_member_ptr(const List *list, const void *datum);
extern bool list_member_int(const List *list, int datum);
extern bool list_member_oid(const List *list, Oid datum);

extern List *list_delete(List *list, void *datum);
extern List *list_delete_ptr(List *list, void *datum);
extern List *list_delete_int(List *list, int datum);
extern List *list_delete_oid(List *list, Oid datum);
extern List *list_delete_first(List *list);
extern List *list_delete_cell(List *list, ListCell *cell, ListCell *prev);

extern List *list_union(const List *list1, const List *list2);
extern List *list_union_ptr(const List *list1, const List *list2);
extern List *list_union_int(const List *list1, const List *list2);
extern List *list_union_oid(const List *list1, const List *list2);

extern List *list_intersection(const List *list1, const List *list2);



extern List *list_difference(const List *list1, const List *list2);
extern List *list_difference_ptr(const List *list1, const List *list2);
extern List *list_difference_int(const List *list1, const List *list2);
extern List *list_difference_oid(const List *list1, const List *list2);

extern List *list_append_unique(List *list, void *datum);
extern List *list_append_unique_ptr(List *list, void *datum);
extern List *list_append_unique_int(List *list, int datum);
extern List *list_append_unique_oid(List *list, Oid datum);

extern List *list_concat_unique(List *list1, List *list2);
extern List *list_concat_unique_ptr(List *list1, List *list2);
extern List *list_concat_unique_int(List *list1, List *list2);
extern List *list_concat_unique_oid(List *list1, List *list2);

extern void list_free(List *list);
extern void list_free_deep(List *list);

extern List *list_copy(const List *list);
extern List *list_copy_tail(const List *list, int nskip);
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/backendid.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/backendid.h"
typedef int BackendId;



extern BackendId MyBackendId;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h" 2







typedef enum ForkNumber
{
 InvalidForkNumber = -1,
 MAIN_FORKNUM = 0,
 FSM_FORKNUM,
 VISIBILITYMAP_FORKNUM,
 INIT_FORKNUM





} ForkNumber;
# 77 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
typedef struct RelFileNode
{
 Oid spcNode;
 Oid dbNode;
 Oid relNode;
} RelFileNode;
# 92 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
typedef struct RelFileNodeBackend
{
 RelFileNode node;
 BackendId backend;
} RelFileNodeBackend;
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h" 2
# 30 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
extern int DefaultXactIsoLevel;
extern int XactIsoLevel;
# 44 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
extern bool DefaultXactReadOnly;
extern bool XactReadOnly;





extern bool DefaultXactDeferrable;
extern bool XactDeferrable;

typedef enum
{
 SYNCHRONOUS_COMMIT_OFF,
 SYNCHRONOUS_COMMIT_LOCAL_FLUSH,
 SYNCHRONOUS_COMMIT_REMOTE_WRITE,

 SYNCHRONOUS_COMMIT_REMOTE_FLUSH
} SyncCommitLevel;





extern int synchronous_commit;


extern bool MyXactAccessedTempRel;




typedef enum
{
 XACT_EVENT_COMMIT,
 XACT_EVENT_ABORT,
 XACT_EVENT_PREPARE
} XactEvent;

typedef void (*XactCallback) (XactEvent event, void *arg);

typedef enum
{
 SUBXACT_EVENT_START_SUB,
 SUBXACT_EVENT_COMMIT_SUB,
 SUBXACT_EVENT_ABORT_SUB
} SubXactEvent;

typedef void (*SubXactCallback) (SubXactEvent event, SubTransactionId mySubid,
         SubTransactionId parentSubid, void *arg);
# 112 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
typedef struct xl_xact_assignment
{
 TransactionId xtop;
 int nsubxacts;
 TransactionId xsub[1];
} xl_xact_assignment;



typedef struct xl_xact_commit_compact
{
 TimestampTz xact_time;
 int nsubxacts;

 TransactionId subxacts[1];
} xl_xact_commit_compact;



typedef struct xl_xact_commit
{
 TimestampTz xact_time;
 uint32 xinfo;
 int nrels;
 int nsubxacts;
 int nmsgs;
 Oid dbId;
 Oid tsId;

 RelFileNode xnodes[1];


} xl_xact_commit;
# 163 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
typedef struct xl_xact_abort
{
 TimestampTz xact_time;
 int nrels;
 int nsubxacts;

 RelFileNode xnodes[1];

} xl_xact_abort;
# 184 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
typedef struct xl_xact_commit_prepared
{
 TransactionId xid;
 xl_xact_commit crec;

} xl_xact_commit_prepared;



typedef struct xl_xact_abort_prepared
{
 TransactionId xid;
 xl_xact_abort arec;

} xl_xact_abort_prepared;
# 207 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
extern bool IsTransactionState(void);
extern bool IsAbortedTransactionBlockState(void);
extern TransactionId GetTopTransactionId(void);
extern TransactionId GetTopTransactionIdIfAny(void);
extern TransactionId GetCurrentTransactionId(void);
extern TransactionId GetCurrentTransactionIdIfAny(void);
extern TransactionId GetStableLatestTransactionId(void);
extern SubTransactionId GetCurrentSubTransactionId(void);
extern bool SubTransactionIsActive(SubTransactionId subxid);
extern CommandId GetCurrentCommandId(bool used);
extern TimestampTz GetCurrentTransactionStartTimestamp(void);
extern TimestampTz GetCurrentStatementStartTimestamp(void);
extern TimestampTz GetCurrentTransactionStopTimestamp(void);
extern void SetCurrentStatementStartTimestamp(void);
extern int GetCurrentTransactionNestLevel(void);
extern bool TransactionIdIsCurrentTransactionId(TransactionId xid);
extern void CommandCounterIncrement(void);
extern void ForceSyncCommit(void);
extern void StartTransactionCommand(void);
extern void CommitTransactionCommand(void);
extern void AbortCurrentTransaction(void);
extern void BeginTransactionBlock(void);
extern bool EndTransactionBlock(void);
extern bool PrepareTransactionBlock(char *gid);
extern void UserAbortTransactionBlock(void);
extern void ReleaseSavepoint(List *options);
extern void DefineSavepoint(char *name);
extern void RollbackToSavepoint(List *options);
extern void BeginInternalSubTransaction(char *name);
extern void ReleaseCurrentSubTransaction(void);
extern void RollbackAndReleaseCurrentSubTransaction(void);
extern bool IsSubTransaction(void);
extern bool IsTransactionBlock(void);
extern bool IsTransactionOrTransactionBlock(void);
extern char TransactionBlockStatusCode(void);
extern void AbortOutOfAnyTransaction(void);
extern void PreventTransactionChain(bool isTopLevel, const char *stmtType);
extern void RequireTransactionChain(bool isTopLevel, const char *stmtType);
extern bool IsInTransactionChain(bool isTopLevel);
extern void RegisterXactCallback(XactCallback callback, void *arg);
extern void UnregisterXactCallback(XactCallback callback, void *arg);
extern void RegisterSubXactCallback(SubXactCallback callback, void *arg);
extern void UnregisterSubXactCallback(SubXactCallback callback, void *arg);

extern int xactGetCommittedChildren(TransactionId **ptr);

extern void xact_redo(XLogRecPtr lsn, XLogRecord *record);
extern void xact_desc(StringInfo buf, uint8 xl_info, char *rec);
# 22 "pltcl.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_proc.h" 1
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_proc.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/genbki.h" 1
# 49 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/genbki.h"
typedef int aclitem;
typedef int pg_node_tree;
# 27 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_proc.h" 2
# 36 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_proc.h"
typedef struct FormData_pg_proc
{
 NameData proname;
 Oid pronamespace;
 Oid proowner;
 Oid prolang;
 float4 procost;
 float4 prorows;
 Oid provariadic;
 regproc protransform;
 bool proisagg;
 bool proiswindow;
 bool prosecdef;
 bool proleakproof;
 bool proisstrict;
 bool proretset;
 char provolatile;
 int2 pronargs;
 int2 pronargdefaults;
 Oid prorettype;





 oidvector proargtypes;
# 74 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_proc.h"
} FormData_pg_proc;






typedef FormData_pg_proc *Form_pg_proc;
# 144 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_proc.h"
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;





extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;





extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;





extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;




extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
# 23 "pltcl.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h" 1
# 37 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
typedef struct FormData_pg_type
{
 NameData typname;
 Oid typnamespace;
 Oid typowner;
# 50 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
 int2 typlen;
# 60 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
 bool typbyval;
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
 char typtype;







 char typcategory;

 bool typispreferred;





 bool typisdefined;

 char typdelim;

 Oid typrelid;
# 102 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
 Oid typelem;





 Oid typarray;




 regproc typinput;
 regproc typoutput;
 regproc typreceive;
 regproc typsend;




 regproc typmodin;
 regproc typmodout;




 regproc typanalyze;
# 153 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
 char typalign;
# 165 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
 char typstorage;
# 175 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
 bool typnotnull;





 Oid typbasetype;






 int4 typtypmod;





 int4 typndims;





 Oid typcollation;
# 226 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
} FormData_pg_type;






typedef FormData_pg_type *Form_pg_type;
# 286 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;





extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;




extern int no_such_variable;
extern int no_such_variable;
# 379 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;





extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;




extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
# 639 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;
# 24 "pltcl.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/trigger.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/trigger.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/sdir.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/sdir.h"
typedef enum ScanDirection
{
 BackwardScanDirection = -1,
 NoMovementScanDirection = 0,
 ForwardScanDirection = 1
} ScanDirection;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/skey.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/skey.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h"
typedef int16 AttrNumber;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/skey.h" 2
# 1 "./fmgr.h" 1
# 22 "./fmgr.h"
typedef struct Node *fmNodePtr;


typedef struct StringInfoData *fmStringInfo;
# 34 "./fmgr.h"
typedef struct FunctionCallInfoData *FunctionCallInfo;

typedef Datum (*PGFunction) (FunctionCallInfo fcinfo);
# 49 "./fmgr.h"
typedef struct FmgrInfo
{
 PGFunction fn_addr;
 Oid fn_oid;
 short fn_nargs;

 bool fn_strict;
 bool fn_retset;
 unsigned char fn_stats;
 void *fn_extra;
 MemoryContext fn_mcxt;
 fmNodePtr fn_expr;
} FmgrInfo;




typedef struct FunctionCallInfoData
{
 FmgrInfo *flinfo;
 fmNodePtr context;
 fmNodePtr resultinfo;
 Oid fncollation;
 bool isnull;
 short nargs;
 Datum arg[100];
 bool argnull[100];
} FunctionCallInfoData;





extern void fmgr_info(Oid functionId, FmgrInfo *finfo);






extern void fmgr_info_cxt(Oid functionId, FmgrInfo *finfo,
     MemoryContext mcxt);
# 99 "./fmgr.h"
extern void fmgr_info_copy(FmgrInfo *dstinfo, FmgrInfo *srcinfo,
      MemoryContext destcxt);
# 187 "./fmgr.h"
extern struct varlena *pg_detoast_datum(struct varlena * datum);
extern struct varlena *pg_detoast_datum_copy(struct varlena * datum);
extern struct varlena *pg_detoast_datum_slice(struct varlena * datum,
        int32 first, int32 count);
extern struct varlena *pg_detoast_datum_packed(struct varlena * datum);
# 332 "./fmgr.h"
typedef struct
{
 int api_version;

} Pg_finfo_record;


typedef const Pg_finfo_record *(*PGFInfoFunction) (void);
# 383 "./fmgr.h"
typedef struct
{
 int len;
 int version;
 int funcmaxargs;
 int indexmaxkeys;
 int namedatalen;
 int float4byval;
 int float8byval;
} Pg_magic_struct;
# 410 "./fmgr.h"
typedef const Pg_magic_struct *(*PGModuleMagicFunction) (void);
# 435 "./fmgr.h"
extern Datum DirectFunctionCall1Coll(PGFunction func, Oid collation,
      Datum arg1);
extern Datum DirectFunctionCall2Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2);
extern Datum DirectFunctionCall3Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3);
extern Datum DirectFunctionCall4Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4);
extern Datum DirectFunctionCall5Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5);
extern Datum DirectFunctionCall6Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6);
extern Datum DirectFunctionCall7Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7);
extern Datum DirectFunctionCall8Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8);
extern Datum DirectFunctionCall9Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8,
      Datum arg9);





extern Datum FunctionCall1Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1);
extern Datum FunctionCall2Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2);
extern Datum FunctionCall3Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3);
extern Datum FunctionCall4Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4);
extern Datum FunctionCall5Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5);
extern Datum FunctionCall6Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6);
extern Datum FunctionCall7Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7);
extern Datum FunctionCall8Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8);
extern Datum FunctionCall9Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8,
      Datum arg9);







extern Datum OidFunctionCall0Coll(Oid functionId, Oid collation);
extern Datum OidFunctionCall1Coll(Oid functionId, Oid collation,
      Datum arg1);
extern Datum OidFunctionCall2Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2);
extern Datum OidFunctionCall3Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3);
extern Datum OidFunctionCall4Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4);
extern Datum OidFunctionCall5Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5);
extern Datum OidFunctionCall6Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6);
extern Datum OidFunctionCall7Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7);
extern Datum OidFunctionCall8Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8);
extern Datum OidFunctionCall9Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8,
      Datum arg9);
# 602 "./fmgr.h"
extern Datum InputFunctionCall(FmgrInfo *flinfo, char *str,
      Oid typioparam, int32 typmod);
extern Datum OidInputFunctionCall(Oid functionId, char *str,
      Oid typioparam, int32 typmod);
extern char *OutputFunctionCall(FmgrInfo *flinfo, Datum val);
extern char *OidOutputFunctionCall(Oid functionId, Datum val);
extern Datum ReceiveFunctionCall(FmgrInfo *flinfo, fmStringInfo buf,
     Oid typioparam, int32 typmod);
extern Datum OidReceiveFunctionCall(Oid functionId, fmStringInfo buf,
        Oid typioparam, int32 typmod);
extern bytea *SendFunctionCall(FmgrInfo *flinfo, Datum val);
extern bytea *OidSendFunctionCall(Oid functionId, Datum val);





extern const Pg_finfo_record *fetch_finfo_record(void *filehandle, char *funcname);
extern void clear_external_function_hash(void *filehandle);
extern Oid fmgr_internal_function(const char *proname);
extern Oid get_fn_expr_rettype(FmgrInfo *flinfo);
extern Oid get_fn_expr_argtype(FmgrInfo *flinfo, int argnum);
extern Oid get_call_expr_argtype(fmNodePtr expr, int argnum);
extern bool get_fn_expr_arg_stable(FmgrInfo *flinfo, int argnum);
extern bool get_call_expr_arg_stable(fmNodePtr expr, int argnum);




extern char *Dynamic_library_path;

extern PGFunction load_external_function(char *filename, char *funcname,
        bool signalNotFound, void **filehandle);
extern PGFunction lookup_external_function(void *filehandle, char *funcname);
extern void load_file(const char *filename, bool restricted);
extern void **find_rendezvous_variable(const char *varName);
# 650 "./fmgr.h"
extern int AggCheckCallContext(FunctionCallInfo fcinfo,
     MemoryContext *aggcontext);
# 662 "./fmgr.h"
typedef enum FmgrHookEventType
{
 FHET_START,
 FHET_END,
 FHET_ABORT
} FmgrHookEventType;

typedef bool (*needs_fmgr_hook_type) (Oid fn_oid);

typedef void (*fmgr_hook_type) (FmgrHookEventType event,
           FmgrInfo *flinfo, Datum *arg);

extern needs_fmgr_hook_type needs_fmgr_hook;
extern fmgr_hook_type fmgr_hook;
# 693 "./fmgr.h"
extern char *fmgr(Oid procedureId,...);
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/skey.h" 2







typedef uint16 StrategyNumber;
# 85 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/skey.h"
typedef struct ScanKeyData
{
 int sk_flags;
 AttrNumber sk_attno;
 StrategyNumber sk_strategy;
 Oid sk_subtype;
 Oid sk_collation;
 FmgrInfo sk_func;
 Datum sk_argument;
} ScanKeyData;

typedef ScanKeyData *ScanKey;
# 151 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/skey.h"
extern void ScanKeyInit(ScanKey entry,
   AttrNumber attributeNumber,
   StrategyNumber strategy,
   RegProcedure procedure,
   Datum argument);
extern void ScanKeyEntryInitialize(ScanKey entry,
        int flags,
        AttrNumber attributeNumber,
        StrategyNumber strategy,
        Oid subtype,
        Oid collation,
        RegProcedure procedure,
        Datum argument);
extern void ScanKeyEntryInitializeWithInfo(ScanKey entry,
          int flags,
          AttrNumber attributeNumber,
          StrategyNumber strategy,
          Oid subtype,
          Oid collation,
          FmgrInfo *finfo,
          Datum argument);
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/tidbitmap.h" 1
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/tidbitmap.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h" 1
# 31 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h"
typedef uint32 BlockNumber;
# 53 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h"
typedef struct BlockIdData
{
 uint16 bi_hi;
 uint16 bi_lo;
} BlockIdData;

typedef BlockIdData *BlockId;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h"
typedef struct ItemIdData
{
 unsigned lp_off:15,
    lp_flags:2,
    lp_len:15;
} ItemIdData;

typedef ItemIdData *ItemId;
# 46 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h"
typedef uint16 ItemOffset;
typedef uint16 ItemLength;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h" 2






typedef uint16 OffsetNumber;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h" 2
# 37 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
typedef struct ItemPointerData
{
 BlockIdData ip_blkid;
 OffsetNumber ip_posid;
}




ItemPointerData;




typedef ItemPointerData *ItemPointer;
# 143 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
extern bool ItemPointerEquals(ItemPointer pointer1, ItemPointer pointer2);
extern int32 ItemPointerCompare(ItemPointer arg1, ItemPointer arg2);
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/tidbitmap.h" 2






typedef struct TIDBitmap TIDBitmap;


typedef struct TBMIterator TBMIterator;


typedef struct
{
 BlockNumber blockno;
 int ntuples;
 bool recheck;

 OffsetNumber offsets[1];
} TBMIterateResult;



extern TIDBitmap *tbm_create(long maxbytes);
extern void tbm_free(TIDBitmap *tbm);

extern void tbm_add_tuples(TIDBitmap *tbm,
      const ItemPointer tids, int ntids,
      bool recheck);
extern void tbm_add_page(TIDBitmap *tbm, BlockNumber pageno);

extern void tbm_union(TIDBitmap *a, const TIDBitmap *b);
extern void tbm_intersect(TIDBitmap *a, const TIDBitmap *b);

extern bool tbm_is_empty(const TIDBitmap *tbm);

extern TBMIterator *tbm_begin_iterate(TIDBitmap *tbm);
extern TBMIterateResult *tbm_iterate(TBMIterator *iterator);
extern void tbm_end_iterate(TBMIterator *iterator);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lwlock.h" 1
# 47 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lwlock.h"
typedef enum LWLockId
{
 BufFreelistLock,
 ShmemIndexLock,
 OidGenLock,
 XidGenLock,
 ProcArrayLock,
 SInvalReadLock,
 SInvalWriteLock,
 WALInsertLock,
 WALWriteLock,
 ControlFileLock,
 CheckpointLock,
 CLogControlLock,
 SubtransControlLock,
 MultiXactGenLock,
 MultiXactOffsetControlLock,
 MultiXactMemberControlLock,
 RelCacheInitLock,
 CheckpointerCommLock,
 TwoPhaseStateLock,
 TablespaceCreateLock,
 BtreeVacuumLock,
 AddinShmemInitLock,
 AutovacuumLock,
 AutovacuumScheduleLock,
 SyncScanLock,
 RelationMappingLock,
 AsyncCtlLock,
 AsyncQueueLock,
 SerializableXactHashLock,
 SerializableFinishedListLock,
 SerializablePredicateLockListLock,
 OldSerXidLock,
 SyncRepLock,

 FirstBufMappingLock,
 FirstLockMgrLock = FirstBufMappingLock + 16,
 FirstPredicateLockMgrLock = FirstLockMgrLock + (1 << 4),


 NumFixedLWLocks = FirstPredicateLockMgrLock + (1 << 4),

 MaxDynamicLWLock = 1000000000
} LWLockId;


typedef enum LWLockMode
{
 LW_EXCLUSIVE,
 LW_SHARED,
 LW_WAIT_UNTIL_FREE


} LWLockMode;






extern LWLockId LWLockAssign(void);
extern void LWLockAcquire(LWLockId lockid, LWLockMode mode);
extern bool LWLockConditionalAcquire(LWLockId lockid, LWLockMode mode);
extern bool LWLockAcquireOrWait(LWLockId lockid, LWLockMode mode);
extern void LWLockRelease(LWLockId lockid);
extern void LWLockReleaseAll(void);
extern bool LWLockHeldByMe(LWLockId lockid);

extern int NumLWLocks(void);
extern Size LWLockShmemSize(void);
extern void CreateLWLocks(void);

extern void RequestAddinLWLocks(int n);
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/shmem.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/shmem.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/hsearch.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/hsearch.h"
typedef uint32 (*HashValueFunc) (const void *key, Size keysize);







typedef int (*HashCompareFunc) (const void *key1, const void *key2,
           Size keysize);






typedef void *(*HashCopyFunc) (void *dest, const void *src, Size keysize);






typedef void *(*HashAllocFunc) (Size request);






typedef struct HASHELEMENT
{
 struct HASHELEMENT *link;
 uint32 hashvalue;
} HASHELEMENT;


typedef struct HASHHDR HASHHDR;


typedef struct HTAB HTAB;



typedef struct HASHCTL
{
 long num_partitions;
 long ssize;
 long dsize;
 long max_dsize;
 long ffactor;
 Size keysize;
 Size entrysize;
 HashValueFunc hash;
 HashCompareFunc match;
 HashCopyFunc keycopy;
 HashAllocFunc alloc;
 MemoryContext hcxt;
 HASHHDR *hctl;
} HASHCTL;
# 102 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/hsearch.h"
typedef enum
{
 HASH_FIND,
 HASH_ENTER,
 HASH_REMOVE,
 HASH_ENTER_NULL
} HASHACTION;


typedef struct
{
 HTAB *hashp;
 uint32 curBucket;
 HASHELEMENT *curEntry;
} HASH_SEQ_STATUS;




extern HTAB *hash_create(const char *tabname, long nelem,
   HASHCTL *info, int flags);
extern void hash_destroy(HTAB *hashp);
extern void hash_stats(const char *where, HTAB *hashp);
extern void *hash_search(HTAB *hashp, const void *keyPtr, HASHACTION action,
   bool *foundPtr);
extern uint32 get_hash_value(HTAB *hashp, const void *keyPtr);
extern void *hash_search_with_hash_value(HTAB *hashp, const void *keyPtr,
       uint32 hashvalue, HASHACTION action,
       bool *foundPtr);
extern long hash_get_num_entries(HTAB *hashp);
extern void hash_seq_init(HASH_SEQ_STATUS *status, HTAB *hashp);
extern void *hash_seq_search(HASH_SEQ_STATUS *status);
extern void hash_seq_term(HASH_SEQ_STATUS *status);
extern void hash_freeze(HTAB *hashp);
extern Size hash_estimate_size(long num_entries, Size entrysize);
extern long hash_select_dirsize(long num_entries);
extern Size hash_get_shared_size(HASHCTL *info, int flags);
extern void AtEOXact_HashTables(bool isCommit);
extern void AtEOSubXact_HashTables(bool isCommit, int nestDepth);




extern uint32 string_hash(const void *key, Size keysize);
extern uint32 tag_hash(const void *key, Size keysize);
extern uint32 oid_hash(const void *key, Size keysize);
extern uint32 bitmap_hash(const void *key, Size keysize);
extern int bitmap_match(const void *key1, const void *key2, Size keysize);
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/shmem.h" 2



typedef struct SHM_QUEUE
{
 struct SHM_QUEUE *prev;
 struct SHM_QUEUE *next;
} SHM_QUEUE;


extern void InitShmemAccess(void *seghdr);
extern void InitShmemAllocation(void);
extern void *ShmemAlloc(Size size);
extern bool ShmemAddrIsValid(const void *addr);
extern void InitShmemIndex(void);
extern HTAB *ShmemInitHash(const char *name, long init_size, long max_size,
     HASHCTL *infoP, int hash_flags);
extern void *ShmemInitStruct(const char *name, Size size, bool *foundPtr);
extern Size add_size(Size s1, Size s2);
extern Size mul_size(Size s1, Size s2);


extern void RequestAddinShmemSpace(Size size);
# 56 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/shmem.h"
typedef struct
{
 char key[(48)];
 void *location;
 Size size;
} ShmemIndexEnt;




extern void SHMQueueInit(SHM_QUEUE *queue);
extern void SHMQueueElemInit(SHM_QUEUE *queue);
extern void SHMQueueDelete(SHM_QUEUE *queue);
extern void SHMQueueInsertBefore(SHM_QUEUE *queue, SHM_QUEUE *elem);
extern void SHMQueueInsertAfter(SHM_QUEUE *queue, SHM_QUEUE *elem);
extern Pointer SHMQueueNext(const SHM_QUEUE *queue, const SHM_QUEUE *curElem,
    Size linkOffset);
extern Pointer SHMQueuePrev(const SHM_QUEUE *queue, const SHM_QUEUE *curElem,
    Size linkOffset);
extern bool SHMQueueEmpty(const SHM_QUEUE *queue);
extern bool SHMQueueIsDetached(const SHM_QUEUE *queue);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h" 2



typedef struct PGPROC PGPROC;

typedef struct PROC_QUEUE
{
 SHM_QUEUE links;
 int size;
} PROC_QUEUE;


extern int max_locks_per_xact;
# 58 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct
{
 BackendId backendId;
 LocalTransactionId localTransactionId;

} VirtualTransactionId;
# 86 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef int LOCKMASK;
typedef int LOCKMODE;
# 116 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct LockMethodData
{
 int numLockModes;
 const LOCKMASK *conflictTab;
 const char *const * lockModeNames;
 const bool *trace_flag;
} LockMethodData;

typedef const LockMethodData *LockMethod;





typedef uint16 LOCKMETHODID;
# 165 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef enum LockTagType
{
 LOCKTAG_RELATION,

 LOCKTAG_RELATION_EXTEND,

 LOCKTAG_PAGE,

 LOCKTAG_TUPLE,

 LOCKTAG_TRANSACTION,

 LOCKTAG_VIRTUALTRANSACTION,

 LOCKTAG_OBJECT,







 LOCKTAG_USERLOCK,
 LOCKTAG_ADVISORY
} LockTagType;
# 201 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct LOCKTAG
{
 uint32 locktag_field1;
 uint32 locktag_field2;
 uint32 locktag_field3;
 uint16 locktag_field4;
 uint8 locktag_type;
 uint8 locktag_lockmethodid;
} LOCKTAG;
# 299 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct LOCK
{

 LOCKTAG tag;


 LOCKMASK grantMask;
 LOCKMASK waitMask;
 SHM_QUEUE procLocks;
 PROC_QUEUE waitProcs;
 int requested[10];
 int nRequested;
 int granted[10];
 int nGranted;
} LOCK;
# 352 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct PROCLOCKTAG
{

 LOCK *myLock;
 PGPROC *myProc;
} PROCLOCKTAG;

typedef struct PROCLOCK
{

 PROCLOCKTAG tag;


 LOCKMASK holdMask;
 LOCKMASK releaseMask;
 SHM_QUEUE lockLink;
 SHM_QUEUE procLink;
} PROCLOCK;
# 383 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct LOCALLOCKTAG
{
 LOCKTAG lock;
 LOCKMODE mode;
} LOCALLOCKTAG;

typedef struct LOCALLOCKOWNER
{






 struct ResourceOwnerData *owner;
 int64 nLocks;
} LOCALLOCKOWNER;

typedef struct LOCALLOCK
{

 LOCALLOCKTAG tag;


 LOCK *lock;
 PROCLOCK *proclock;
 uint32 hashcode;
 int64 nLocks;
 int numLockOwners;
 int maxLockOwners;
 bool holdsStrongLockCount;
 LOCALLOCKOWNER *lockOwners;
} LOCALLOCK;
# 425 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct LockInstanceData
{
 LOCKTAG locktag;
 LOCKMASK holdMask;
 LOCKMODE waitLockMode;
 BackendId backend;
 LocalTransactionId lxid;
 int pid;
 bool fastpath;
} LockInstanceData;

typedef struct LockData
{
 int nelements;
 LockInstanceData *locks;
} LockData;



typedef enum
{
 LOCKACQUIRE_NOT_AVAIL,
 LOCKACQUIRE_OK,
 LOCKACQUIRE_ALREADY_HELD
} LockAcquireResult;


typedef enum
{
 DS_NOT_YET_CHECKED,
 DS_NO_DEADLOCK,
 DS_SOFT_DEADLOCK,
 DS_HARD_DEADLOCK,
 DS_BLOCKED_BY_AUTOVACUUM

} DeadLockState;
# 478 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
extern void InitLocks(void);
extern LockMethod GetLocksMethodTable(const LOCK *lock);
extern uint32 LockTagHashCode(const LOCKTAG *locktag);
extern LockAcquireResult LockAcquire(const LOCKTAG *locktag,
   LOCKMODE lockmode,
   bool sessionLock,
   bool dontWait);
extern LockAcquireResult LockAcquireExtended(const LOCKTAG *locktag,
     LOCKMODE lockmode,
     bool sessionLock,
     bool dontWait,
     bool report_memory_error);
extern void AbortStrongLockAcquire(void);
extern bool LockRelease(const LOCKTAG *locktag,
   LOCKMODE lockmode, bool sessionLock);
extern void LockReleaseAll(LOCKMETHODID lockmethodid, bool allLocks);
extern void LockReleaseSession(LOCKMETHODID lockmethodid);
extern void LockReleaseCurrentOwner(void);
extern void LockReassignCurrentOwner(void);
extern bool LockHasWaiters(const LOCKTAG *locktag,
      LOCKMODE lockmode, bool sessionLock);
extern VirtualTransactionId *GetLockConflicts(const LOCKTAG *locktag,
     LOCKMODE lockmode);
extern void AtPrepare_Locks(void);
extern void PostPrepare_Locks(TransactionId xid);
extern int LockCheckConflicts(LockMethod lockMethodTable,
       LOCKMODE lockmode,
       LOCK *lock, PROCLOCK *proclock, PGPROC *proc);
extern void GrantLock(LOCK *lock, PROCLOCK *proclock, LOCKMODE lockmode);
extern void GrantAwaitedLock(void);
extern void RemoveFromWaitQueue(PGPROC *proc, uint32 hashcode);
extern Size LockShmemSize(void);
extern LockData *GetLockStatusData(void);

extern void ReportLockTableError(bool report);

typedef struct xl_standby_lock
{
 TransactionId xid;
 Oid dbOid;
 Oid relOid;
} xl_standby_lock;

extern xl_standby_lock *GetRunningTransactionLocks(int *nlocks);
extern const char *GetLockmodeName(LOCKMETHODID lockmethodid, LOCKMODE mode);

extern void lock_twophase_recover(TransactionId xid, uint16 info,
       void *recdata, uint32 len);
extern void lock_twophase_postcommit(TransactionId xid, uint16 info,
       void *recdata, uint32 len);
extern void lock_twophase_postabort(TransactionId xid, uint16 info,
      void *recdata, uint32 len);
extern void lock_twophase_standby_recover(TransactionId xid, uint16 info,
         void *recdata, uint32 len);

extern DeadLockState DeadLockCheck(PGPROC *proc);
extern PGPROC *GetBlockingAutoVacuumPgproc(void);
extern void DeadLockReport(void);
extern void RememberSimpleDeadLock(PGPROC *proc1,
        LOCKMODE lockmode,
        LOCK *lock,
        PGPROC *proc2);
extern void InitDeadLockChecking(void);







extern void VirtualXactLockTableInsert(VirtualTransactionId vxid);
extern void VirtualXactLockTableCleanup(void);
extern bool VirtualXactLock(VirtualTransactionId vxid, bool wait);
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h" 1
# 36 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
typedef struct FormData_pg_attribute
{
 Oid attrelid;
 NameData attname;
# 48 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 Oid atttypid;
# 57 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int4 attstattarget;





 int2 attlen;
# 78 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int2 attnum;





 int4 attndims;
# 93 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int4 attcacheoff;







 int4 atttypmod;





 bool attbyval;
# 122 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 char attstorage;





 char attalign;


 bool attnotnull;


 bool atthasdef;


 bool attisdropped;


 bool attislocal;


 int4 attinhcount;


 Oid attcollation;
# 160 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
} FormData_pg_attribute;
# 176 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
typedef FormData_pg_attribute *Form_pg_attribute;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 2



typedef struct attrDefault
{
 AttrNumber adnum;
 char *adbin;
} AttrDefault;

typedef struct constrCheck
{
 char *ccname;
 char *ccbin;
 bool ccvalid;
 bool ccnoinherit;
} ConstrCheck;


typedef struct tupleConstr
{
 AttrDefault *defval;
 ConstrCheck *check;
 uint16 num_defval;
 uint16 num_check;
 bool has_not_null;
} TupleConstr;
# 71 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
typedef struct tupleDesc
{
 int natts;
 Form_pg_attribute *attrs;

 TupleConstr *constr;
 Oid tdtypeid;
 int32 tdtypmod;
 bool tdhasoid;
 int tdrefcount;
} *TupleDesc;


extern TupleDesc CreateTemplateTupleDesc(int natts, bool hasoid);

extern TupleDesc CreateTupleDesc(int natts, bool hasoid,
    Form_pg_attribute *attrs);

extern TupleDesc CreateTupleDescCopy(TupleDesc tupdesc);

extern TupleDesc CreateTupleDescCopyConstr(TupleDesc tupdesc);

extern void FreeTupleDesc(TupleDesc tupdesc);

extern void IncrTupleDescRefCount(TupleDesc tupdesc);
extern void DecrTupleDescRefCount(TupleDesc tupdesc);
# 110 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
extern bool equalTupleDescs(TupleDesc tupdesc1, TupleDesc tupdesc2);

extern void TupleDescInitEntry(TupleDesc desc,
       AttrNumber attributeNumber,
       const char *attributeName,
       Oid oidtypeid,
       int32 typmod,
       int attdim);

extern void TupleDescInitEntryCollation(TupleDesc desc,
       AttrNumber attributeNumber,
       Oid collationid);

extern TupleDesc BuildDescForRelation(List *schema);

extern TupleDesc BuildDescFromLists(List *names, List *types, List *typmods, List *collations);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/bitmapset.h" 1
# 29 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/bitmapset.h"
typedef uint32 bitmapword;
typedef int32 signedbitmapword;

typedef struct Bitmapset
{
 int nwords;
 bitmapword words[1];
} Bitmapset;



typedef enum
{
 BMS_EQUAL,
 BMS_SUBSET1,
 BMS_SUBSET2,
 BMS_DIFFERENT
} BMS_Comparison;


typedef enum
{
 BMS_EMPTY_SET,
 BMS_SINGLETON,
 BMS_MULTIPLE
} BMS_Membership;






extern Bitmapset *bms_copy(const Bitmapset *a);
extern bool bms_equal(const Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_make_singleton(int x);
extern void bms_free(Bitmapset *a);

extern Bitmapset *bms_union(const Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_intersect(const Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_difference(const Bitmapset *a, const Bitmapset *b);
extern bool bms_is_subset(const Bitmapset *a, const Bitmapset *b);
extern BMS_Comparison bms_subset_compare(const Bitmapset *a, const Bitmapset *b);
extern bool bms_is_member(int x, const Bitmapset *a);
extern bool bms_overlap(const Bitmapset *a, const Bitmapset *b);
extern bool bms_nonempty_difference(const Bitmapset *a, const Bitmapset *b);
extern int bms_singleton_member(const Bitmapset *a);
extern int bms_num_members(const Bitmapset *a);


extern BMS_Membership bms_membership(const Bitmapset *a);
extern bool bms_is_empty(const Bitmapset *a);



extern Bitmapset *bms_add_member(Bitmapset *a, int x);
extern Bitmapset *bms_del_member(Bitmapset *a, int x);
extern Bitmapset *bms_add_members(Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_int_members(Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_del_members(Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_join(Bitmapset *a, Bitmapset *b);


extern int bms_first_member(Bitmapset *a);


extern uint32 bms_hash_value(const Bitmapset *a);
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h" 2


typedef struct RelationData *Relation;







typedef Relation *RelationPtr;




extern Relation RelationIdGetRelation(Oid relationId);
extern void RelationClose(Relation relation);




extern List *RelationGetIndexList(Relation relation);
extern Oid RelationGetOidIndex(Relation relation);
extern List *RelationGetIndexExpressions(Relation relation);
extern List *RelationGetIndexPredicate(Relation relation);
extern Bitmapset *RelationGetIndexAttrBitmap(Relation relation);
extern void RelationGetExclusionInfo(Relation indexRelation,
       Oid **operators,
       Oid **procs,
       uint16 **strategies);

extern void RelationSetIndexList(Relation relation,
      List *indexIds, Oid oidIndex);

extern void RelationInitIndexAccessInfo(Relation relation);




extern void RelationCacheInitialize(void);
extern void RelationCacheInitializePhase2(void);
extern void RelationCacheInitializePhase3(void);




extern Relation RelationBuildLocalRelation(const char *relname,
         Oid relnamespace,
         TupleDesc tupDesc,
         Oid relid,
         Oid relfilenode,
         Oid reltablespace,
         bool shared_relation,
         bool mapped_relation,
         char relpersistence);




extern void RelationSetNewRelfilenode(Relation relation,
        TransactionId freezeXid);




extern void RelationForgetRelation(Oid rid);

extern void RelationCacheInvalidateEntry(Oid relationId);

extern void RelationCacheInvalidate(void);

extern void RelationCloseSmgrByOid(Oid relationId);

extern void AtEOXact_RelationCache(bool isCommit);
extern void AtEOSubXact_RelationCache(bool isCommit, SubTransactionId mySubid,
        SubTransactionId parentSubid);




extern bool RelationIdIsInInitFile(Oid relationId);
extern void RelationCacheInitFilePreInvalidate(void);
extern void RelationCacheInitFilePostInvalidate(void);
extern void RelationCacheInitFileRemove(void);


extern bool criticalRelcachesBuilt;


extern bool criticalSharedRelcachesBuilt;
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupmacs.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/item.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/item.h"
typedef Pointer Item;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 2
# 73 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef Pointer Page;
# 82 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef uint16 LocationIndex;
# 122 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef struct PageHeaderData
{

 XLogRecPtr pd_lsn;

 uint16 pd_tli;

 uint16 pd_flags;
 LocationIndex pd_lower;
 LocationIndex pd_upper;
 LocationIndex pd_special;
 uint16 pd_pagesize_version;
 TransactionId pd_prune_xid;
 ItemIdData pd_linp[1];
} PageHeaderData;

typedef PageHeaderData *PageHeader;
# 370 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
extern void PageInit(Page page, Size pageSize, Size specialSize);
extern bool PageHeaderIsValid(PageHeader page);
extern OffsetNumber PageAddItem(Page page, Item item, Size size,
   OffsetNumber offsetNumber, bool overwrite, bool is_heap);
extern Page PageGetTempPage(Page page);
extern Page PageGetTempPageCopy(Page page);
extern Page PageGetTempPageCopySpecial(Page page);
extern void PageRestoreTempPage(Page tempPage, Page oldPage);
extern void PageRepairFragmentation(Page page);
extern Size PageGetFreeSpace(Page page);
extern Size PageGetExactFreeSpace(Page page);
extern Size PageGetHeapFreeSpace(Page page);
extern void PageIndexTupleDelete(Page page, OffsetNumber offset);
extern void PageIndexMultiDelete(Page page, OffsetNumber *itemnos, int nitems);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 107 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct HeapTupleFields
{
 TransactionId t_xmin;
 TransactionId t_xmax;

 union
 {
  CommandId t_cid;
  TransactionId t_xvac;
 } t_field3;
} HeapTupleFields;

typedef struct DatumTupleFields
{
 int32 datum_len_;

 int32 datum_typmod;

 Oid datum_typeid;





} DatumTupleFields;

typedef struct HeapTupleHeaderData
{
 union
 {
  HeapTupleFields t_heap;
  DatumTupleFields t_datum;
 } t_choice;

 ItemPointerData t_ctid;



 uint16 t_infomask2;

 uint16 t_infomask;

 uint8 t_hoff;



 bits8 t_bits[1];


} HeapTupleHeaderData;

typedef HeapTupleHeaderData *HeapTupleHeader;
# 461 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct MinimalTupleData
{
 uint32 t_len;

 char mt_padding[((__builtin_offsetof (HeapTupleHeaderData, t_infomask2) - sizeof(uint32)) % 8)];



 uint16 t_infomask2;

 uint16 t_infomask;

 uint8 t_hoff;



 bits8 t_bits[1];


} MinimalTupleData;

typedef MinimalTupleData *MinimalTuple;
# 517 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct HeapTupleData
{
 uint32 t_len;
 ItemPointerData t_self;
 Oid t_tableOid;
 HeapTupleHeader t_data;
} HeapTupleData;

typedef HeapTupleData *HeapTuple;
# 621 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heaptid
{
 RelFileNode node;
 ItemPointerData tid;
} xl_heaptid;




typedef struct xl_heap_delete
{
 xl_heaptid target;
 bool all_visible_cleared;
} xl_heap_delete;
# 646 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_header
{
 uint16 t_infomask2;
 uint16 t_infomask;
 uint8 t_hoff;
} xl_heap_header;




typedef struct xl_heap_insert
{
 xl_heaptid target;
 bool all_visible_cleared;

} xl_heap_insert;
# 671 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_multi_insert
{
 RelFileNode node;
 BlockNumber blkno;
 bool all_visible_cleared;
 uint16 ntuples;
 OffsetNumber offsets[1];


} xl_heap_multi_insert;



typedef struct xl_multi_insert_tuple
{
 uint16 datalen;
 uint16 t_infomask2;
 uint16 t_infomask;
 uint8 t_hoff;

} xl_multi_insert_tuple;




typedef struct xl_heap_update
{
 xl_heaptid target;
 ItemPointerData newtid;
 bool all_visible_cleared;
 bool new_all_visible_cleared;

} xl_heap_update;
# 718 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_clean
{
 RelFileNode node;
 BlockNumber block;
 TransactionId latestRemovedXid;
 uint16 nredirected;
 uint16 ndead;

} xl_heap_clean;
# 735 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_cleanup_info
{
 RelFileNode node;
 TransactionId latestRemovedXid;
} xl_heap_cleanup_info;





typedef struct xl_heap_newpage
{
 RelFileNode node;
 ForkNumber forknum;
 BlockNumber blkno;

} xl_heap_newpage;




typedef struct xl_heap_lock
{
 xl_heaptid target;
 TransactionId locking_xid;
 bool xid_is_mxact;
 bool shared_lock;
} xl_heap_lock;




typedef struct xl_heap_inplace
{
 xl_heaptid target;

} xl_heap_inplace;




typedef struct xl_heap_freeze
{
 RelFileNode node;
 BlockNumber block;
 TransactionId cutoff_xid;

} xl_heap_freeze;




typedef struct xl_heap_visible
{
 RelFileNode node;
 BlockNumber block;
 TransactionId cutoff_xid;
} xl_heap_visible;



extern void HeapTupleHeaderAdvanceLatestRemovedXid(HeapTupleHeader tuple,
            TransactionId *latestRemovedXid);


extern CommandId HeapTupleHeaderGetCmin(HeapTupleHeader tup);
extern CommandId HeapTupleHeaderGetCmax(HeapTupleHeader tup);
extern void HeapTupleHeaderAdjustCmax(HeapTupleHeader tup,
        CommandId *cmax,
        bool *iscombo);
# 890 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
extern Size heap_compute_data_size(TupleDesc tupleDesc,
        Datum *values, bool *isnull);
extern void heap_fill_tuple(TupleDesc tupleDesc,
    Datum *values, bool *isnull,
    char *data, Size data_size,
    uint16 *infomask, bits8 *bit);
extern bool heap_attisnull(HeapTuple tup, int attnum);
extern Datum nocachegetattr(HeapTuple tup, int attnum,
      TupleDesc att);
extern Datum heap_getsysattr(HeapTuple tup, int attnum, TupleDesc tupleDesc,
    bool *isnull);
extern HeapTuple heap_copytuple(HeapTuple tuple);
extern void heap_copytuple_with_tuple(HeapTuple src, HeapTuple dest);
extern HeapTuple heap_form_tuple(TupleDesc tupleDescriptor,
    Datum *values, bool *isnull);
extern HeapTuple heap_modify_tuple(HeapTuple tuple,
      TupleDesc tupleDesc,
      Datum *replValues,
      bool *replIsnull,
      bool *doReplace);
extern void heap_deform_tuple(HeapTuple tuple, TupleDesc tupleDesc,
      Datum *values, bool *isnull);


extern HeapTuple heap_formtuple(TupleDesc tupleDescriptor,
      Datum *values, char *nulls);
extern HeapTuple heap_modifytuple(HeapTuple tuple,
     TupleDesc tupleDesc,
     Datum *replValues,
     char *replNulls,
     char *replActions);
extern void heap_deformtuple(HeapTuple tuple, TupleDesc tupleDesc,
     Datum *values, char *nulls);
extern void heap_freetuple(HeapTuple htup);
extern MinimalTuple heap_form_minimal_tuple(TupleDesc tupleDescriptor,
      Datum *values, bool *isnull);
extern void heap_free_minimal_tuple(MinimalTuple mtup);
extern MinimalTuple heap_copy_minimal_tuple(MinimalTuple mtup);
extern HeapTuple heap_tuple_from_minimal_tuple(MinimalTuple mtup);
extern MinimalTuple minimal_tuple_from_heap_tuple(HeapTuple htup);
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h" 2


typedef struct SnapshotData *Snapshot;
# 30 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h"
typedef bool (*SnapshotSatisfiesFunc) (HeapTupleHeader tuple,
             Snapshot snapshot, Buffer buffer);

typedef struct SnapshotData
{
 SnapshotSatisfiesFunc satisfies;
# 47 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h"
 TransactionId xmin;
 TransactionId xmax;
 TransactionId *xip;
 uint32 xcnt;

 int32 subxcnt;
 TransactionId *subxip;
 bool suboverflowed;
 bool takenDuringRecovery;
 bool copied;





 CommandId curcid;
 uint32 active_count;
 uint32 regd_count;
} SnapshotData;





typedef enum
{
 HeapTupleMayBeUpdated,
 HeapTupleInvisible,
 HeapTupleSelfUpdated,
 HeapTupleUpdated,
 HeapTupleBeingUpdated
} HTSU_Result;
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h" 2




typedef struct IndexBuildResult
{
 double heap_tuples;
 double index_tuples;
} IndexBuildResult;
# 41 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h"
typedef struct IndexVacuumInfo
{
 Relation index;
 bool analyze_only;
 bool estimated_count;
 int message_level;
 double num_heap_tuples;
 BufferAccessStrategy strategy;
} IndexVacuumInfo;
# 68 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h"
typedef struct IndexBulkDeleteResult
{
 BlockNumber num_pages;
 BlockNumber pages_removed;
 bool estimated_count;
 double num_index_tuples;
 double tuples_removed;
 BlockNumber pages_deleted;
 BlockNumber pages_free;
} IndexBulkDeleteResult;


typedef bool (*IndexBulkDeleteCallback) (ItemPointer itemptr, void *state);


typedef struct IndexScanDescData *IndexScanDesc;
typedef struct SysScanDescData *SysScanDesc;
# 106 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h"
typedef enum IndexUniqueCheck
{
 UNIQUE_CHECK_NO,
 UNIQUE_CHECK_YES,
 UNIQUE_CHECK_PARTIAL,
 UNIQUE_CHECK_EXISTING
} IndexUniqueCheck;
# 125 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h"
extern Relation index_open(Oid relationId, LOCKMODE lockmode);
extern void index_close(Relation relation, LOCKMODE lockmode);

extern bool index_insert(Relation indexRelation,
    Datum *values, bool *isnull,
    ItemPointer heap_t_ctid,
    Relation heapRelation,
    IndexUniqueCheck checkUnique);

extern IndexScanDesc index_beginscan(Relation heapRelation,
    Relation indexRelation,
    Snapshot snapshot,
    int nkeys, int norderbys);
extern IndexScanDesc index_beginscan_bitmap(Relation indexRelation,
        Snapshot snapshot,
        int nkeys);
extern void index_rescan(IndexScanDesc scan,
    ScanKey keys, int nkeys,
    ScanKey orderbys, int norderbys);
extern void index_endscan(IndexScanDesc scan);
extern void index_markpos(IndexScanDesc scan);
extern void index_restrpos(IndexScanDesc scan);
extern ItemPointer index_getnext_tid(IndexScanDesc scan,
      ScanDirection direction);
extern HeapTuple index_fetch_heap(IndexScanDesc scan);
extern HeapTuple index_getnext(IndexScanDesc scan, ScanDirection direction);
extern int64 index_getbitmap(IndexScanDesc scan, TIDBitmap *bitmap);

extern IndexBulkDeleteResult *index_bulk_delete(IndexVacuumInfo *info,
      IndexBulkDeleteResult *stats,
      IndexBulkDeleteCallback callback,
      void *callback_state);
extern IndexBulkDeleteResult *index_vacuum_cleanup(IndexVacuumInfo *info,
      IndexBulkDeleteResult *stats);
extern bool index_can_return(Relation indexRelation);
extern RegProcedure index_getprocid(Relation irel, AttrNumber attnum,
    uint16 procnum);
extern FmgrInfo *index_getprocinfo(Relation irel, AttrNumber attnum,
      uint16 procnum);




extern IndexScanDesc RelationGetIndexScan(Relation indexRelation,
      int nkeys, int norderbys);
extern void IndexScanEnd(IndexScanDesc scan);
extern char *BuildIndexValueDescription(Relation indexRelation,
         Datum *values, bool *isnull);




extern SysScanDesc systable_beginscan(Relation heapRelation,
       Oid indexId,
       bool indexOK,
       Snapshot snapshot,
       int nkeys, ScanKey key);
extern HeapTuple systable_getnext(SysScanDesc sysscan);
extern bool systable_recheck_tuple(SysScanDesc sysscan, HeapTuple tup);
extern void systable_endscan(SysScanDesc sysscan);
extern SysScanDesc systable_beginscan_ordered(Relation heapRelation,
         Relation indexRelation,
         Snapshot snapshot,
         int nkeys, ScanKey key);
extern HeapTuple systable_getnext_ordered(SysScanDesc sysscan,
       ScanDirection direction);
extern void systable_endscan_ordered(SysScanDesc sysscan);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 2
# 38 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Alias
{
 NodeTag type;
 char *aliasname;
 List *colnames;
} Alias;

typedef enum InhOption
{
 INH_NO,
 INH_YES,
 INH_DEFAULT
} InhOption;


typedef enum OnCommitAction
{
 ONCOMMIT_NOOP,
 ONCOMMIT_PRESERVE_ROWS,
 ONCOMMIT_DELETE_ROWS,
 ONCOMMIT_DROP
} OnCommitAction;
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RangeVar
{
 NodeTag type;
 char *catalogname;
 char *schemaname;
 char *relname;
 InhOption inhOpt;

 char relpersistence;
 Alias *alias;
 int location;
} RangeVar;




typedef struct IntoClause
{
 NodeTag type;

 RangeVar *rel;
 List *colNames;
 List *options;
 OnCommitAction onCommit;
 char *tableSpaceName;
 bool skipData;
} IntoClause;
# 111 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Expr
{
 NodeTag type;
} Expr;
# 138 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Var
{
 Expr xpr;
 Index varno;

 AttrNumber varattno;

 Oid vartype;
 int32 vartypmod;
 Oid varcollid;
 Index varlevelsup;


 Index varnoold;
 AttrNumber varoattno;
 int location;
} Var;




typedef struct Const
{
 Expr xpr;
 Oid consttype;
 int32 consttypmod;
 Oid constcollid;
 int constlen;
 Datum constvalue;
 bool constisnull;

 bool constbyval;



 int location;
} Const;
# 201 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum ParamKind
{
 PARAM_EXTERN,
 PARAM_EXEC,
 PARAM_SUBLINK
} ParamKind;

typedef struct Param
{
 Expr xpr;
 ParamKind paramkind;
 int paramid;
 Oid paramtype;
 int32 paramtypmod;
 Oid paramcollid;
 int location;
} Param;
# 234 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Aggref
{
 Expr xpr;
 Oid aggfnoid;
 Oid aggtype;
 Oid aggcollid;
 Oid inputcollid;
 List *args;
 List *aggorder;
 List *aggdistinct;
 bool aggstar;
 Index agglevelsup;
 int location;
} Aggref;




typedef struct WindowFunc
{
 Expr xpr;
 Oid winfnoid;
 Oid wintype;
 Oid wincollid;
 Oid inputcollid;
 List *args;
 Index winref;
 bool winstar;
 bool winagg;
 int location;
} WindowFunc;
# 288 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ArrayRef
{
 Expr xpr;
 Oid refarraytype;
 Oid refelemtype;
 int32 reftypmod;
 Oid refcollid;
 List *refupperindexpr;

 List *reflowerindexpr;

 Expr *refexpr;

 Expr *refassgnexpr;

} ArrayRef;







typedef enum CoercionContext
{
 COERCION_IMPLICIT,
 COERCION_ASSIGNMENT,
 COERCION_EXPLICIT
} CoercionContext;
# 327 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum CoercionForm
{
 COERCE_EXPLICIT_CALL,
 COERCE_EXPLICIT_CAST,
 COERCE_IMPLICIT_CAST,
 COERCE_DONTCARE
} CoercionForm;




typedef struct FuncExpr
{
 Expr xpr;
 Oid funcid;
 Oid funcresulttype;
 bool funcretset;
 CoercionForm funcformat;
 Oid funccollid;
 Oid inputcollid;
 List *args;
 int location;
} FuncExpr;
# 365 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct NamedArgExpr
{
 Expr xpr;
 Expr *arg;
 char *name;
 int argnumber;
 int location;
} NamedArgExpr;
# 383 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct OpExpr
{
 Expr xpr;
 Oid opno;
 Oid opfuncid;
 Oid opresulttype;
 bool opretset;
 Oid opcollid;
 Oid inputcollid;
 List *args;
 int location;
} OpExpr;
# 406 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef OpExpr DistinctExpr;







typedef OpExpr NullIfExpr;
# 426 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ScalarArrayOpExpr
{
 Expr xpr;
 Oid opno;
 Oid opfuncid;
 bool useOr;
 Oid inputcollid;
 List *args;
 int location;
} ScalarArrayOpExpr;
# 448 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum BoolExprType
{
 AND_EXPR, OR_EXPR, NOT_EXPR
} BoolExprType;

typedef struct BoolExpr
{
 Expr xpr;
 BoolExprType boolop;
 List *args;
 int location;
} BoolExpr;
# 504 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum SubLinkType
{
 EXISTS_SUBLINK,
 ALL_SUBLINK,
 ANY_SUBLINK,
 ROWCOMPARE_SUBLINK,
 EXPR_SUBLINK,
 ARRAY_SUBLINK,
 CTE_SUBLINK
} SubLinkType;


typedef struct SubLink
{
 Expr xpr;
 SubLinkType subLinkType;
 Node *testexpr;
 List *operName;
 Node *subselect;
 int location;
} SubLink;
# 564 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct SubPlan
{
 Expr xpr;

 SubLinkType subLinkType;

 Node *testexpr;
 List *paramIds;

 int plan_id;

 char *plan_name;

 Oid firstColType;
 int32 firstColTypmod;
 Oid firstColCollation;


 bool useHashTable;

 bool unknownEqFalse;




 List *setParam;

 List *parParam;
 List *args;

 Cost startup_cost;
 Cost per_call_cost;
} SubPlan;
# 606 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct AlternativeSubPlan
{
 Expr xpr;
 List *subplans;
} AlternativeSubPlan;
# 621 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct FieldSelect
{
 Expr xpr;
 Expr *arg;
 AttrNumber fieldnum;
 Oid resulttype;

 int32 resulttypmod;
 Oid resultcollid;
} FieldSelect;
# 647 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct FieldStore
{
 Expr xpr;
 Expr *arg;
 List *newvals;
 List *fieldnums;
 Oid resulttype;

} FieldStore;
# 670 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RelabelType
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;
 int32 resulttypmod;
 Oid resultcollid;
 CoercionForm relabelformat;
 int location;
} RelabelType;
# 690 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CoerceViaIO
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;

 Oid resultcollid;
 CoercionForm coerceformat;
 int location;
} CoerceViaIO;
# 713 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ArrayCoerceExpr
{
 Expr xpr;
 Expr *arg;
 Oid elemfuncid;
 Oid resulttype;
 int32 resulttypmod;
 Oid resultcollid;
 bool isExplicit;
 CoercionForm coerceformat;
 int location;
} ArrayCoerceExpr;
# 738 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ConvertRowtypeExpr
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;

 CoercionForm convertformat;
 int location;
} ConvertRowtypeExpr;
# 755 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CollateExpr
{
 Expr xpr;
 Expr *arg;
 Oid collOid;
 int location;
} CollateExpr;
# 785 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CaseExpr
{
 Expr xpr;
 Oid casetype;
 Oid casecollid;
 Expr *arg;
 List *args;
 Expr *defresult;
 int location;
} CaseExpr;




typedef struct CaseWhen
{
 Expr xpr;
 Expr *expr;
 Expr *result;
 int location;
} CaseWhen;
# 815 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CaseTestExpr
{
 Expr xpr;
 Oid typeId;
 int32 typeMod;
 Oid collation;
} CaseTestExpr;
# 831 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ArrayExpr
{
 Expr xpr;
 Oid array_typeid;
 Oid array_collid;
 Oid element_typeid;
 List *elements;
 bool multidims;
 int location;
} ArrayExpr;
# 865 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RowExpr
{
 Expr xpr;
 List *args;
 Oid row_typeid;
# 880 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
 CoercionForm row_format;
 List *colnames;
 int location;
} RowExpr;
# 899 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum RowCompareType
{

 ROWCOMPARE_LT = 1,
 ROWCOMPARE_LE = 2,
 ROWCOMPARE_EQ = 3,
 ROWCOMPARE_GE = 4,
 ROWCOMPARE_GT = 5,
 ROWCOMPARE_NE = 6
} RowCompareType;

typedef struct RowCompareExpr
{
 Expr xpr;
 RowCompareType rctype;
 List *opnos;
 List *opfamilies;
 List *inputcollids;
 List *largs;
 List *rargs;
} RowCompareExpr;




typedef struct CoalesceExpr
{
 Expr xpr;
 Oid coalescetype;
 Oid coalescecollid;
 List *args;
 int location;
} CoalesceExpr;




typedef enum MinMaxOp
{
 IS_GREATEST,
 IS_LEAST
} MinMaxOp;

typedef struct MinMaxExpr
{
 Expr xpr;
 Oid minmaxtype;
 Oid minmaxcollid;
 Oid inputcollid;
 MinMaxOp op;
 List *args;
 int location;
} MinMaxExpr;
# 965 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum XmlExprOp
{
 IS_XMLCONCAT,
 IS_XMLELEMENT,
 IS_XMLFOREST,
 IS_XMLPARSE,
 IS_XMLPI,
 IS_XMLROOT,
 IS_XMLSERIALIZE,
 IS_DOCUMENT
} XmlExprOp;

typedef enum
{
 XMLOPTION_DOCUMENT,
 XMLOPTION_CONTENT
} XmlOptionType;

typedef struct XmlExpr
{
 Expr xpr;
 XmlExprOp op;
 char *name;
 List *named_args;
 List *arg_names;
 List *args;
 XmlOptionType xmloption;
 Oid type;
 int32 typmod;
 int location;
} XmlExpr;
# 1008 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum NullTestType
{
 IS_NULL, IS_NOT_NULL
} NullTestType;

typedef struct NullTest
{
 Expr xpr;
 Expr *arg;
 NullTestType nulltesttype;
 bool argisrow;
} NullTest;
# 1030 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum BoolTestType
{
 IS_TRUE, IS_NOT_TRUE, IS_FALSE, IS_NOT_FALSE, IS_UNKNOWN, IS_NOT_UNKNOWN
} BoolTestType;

typedef struct BooleanTest
{
 Expr xpr;
 Expr *arg;
 BoolTestType booltesttype;
} BooleanTest;
# 1051 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CoerceToDomain
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;
 int32 resulttypmod;
 Oid resultcollid;
 CoercionForm coercionformat;
 int location;
} CoerceToDomain;
# 1071 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CoerceToDomainValue
{
 Expr xpr;
 Oid typeId;
 int32 typeMod;
 Oid collation;
 int location;
} CoerceToDomainValue;
# 1087 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct SetToDefault
{
 Expr xpr;
 Oid typeId;
 int32 typeMod;
 Oid collation;
 int location;
} SetToDefault;
# 1108 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CurrentOfExpr
{
 Expr xpr;
 Index cvarno;
 char *cursor_name;
 int cursor_param;
} CurrentOfExpr;
# 1170 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct TargetEntry
{
 Expr xpr;
 Expr *expr;
 AttrNumber resno;
 char *resname;
 Index ressortgroupref;

 Oid resorigtbl;
 AttrNumber resorigcol;
 bool resjunk;

} TargetEntry;
# 1222 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RangeTblRef
{
 NodeTag type;
 int rtindex;
} RangeTblRef;
# 1251 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct JoinExpr
{
 NodeTag type;
 JoinType jointype;
 bool isNatural;
 Node *larg;
 Node *rarg;
 List *usingClause;
 Node *quals;
 Alias *alias;
 int rtindex;
} JoinExpr;
# 1273 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct FromExpr
{
 NodeTag type;
 List *fromlist;
 Node *quals;
} FromExpr;
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h" 2
# 30 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h"
typedef struct BulkInsertStateData *BulkInsertState;

typedef enum
{
 LockTupleShared,
 LockTupleExclusive
} LockTupleMode;
# 48 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h"
extern Relation relation_open(Oid relationId, LOCKMODE lockmode);
extern Relation try_relation_open(Oid relationId, LOCKMODE lockmode);
extern Relation relation_openrv(const RangeVar *relation, LOCKMODE lockmode);
extern Relation relation_openrv_extended(const RangeVar *relation,
       LOCKMODE lockmode, bool missing_ok);
extern void relation_close(Relation relation, LOCKMODE lockmode);

extern Relation heap_open(Oid relationId, LOCKMODE lockmode);
extern Relation heap_openrv(const RangeVar *relation, LOCKMODE lockmode);
extern Relation heap_openrv_extended(const RangeVar *relation,
      LOCKMODE lockmode, bool missing_ok);




typedef struct HeapScanDescData *HeapScanDesc;







extern HeapScanDesc heap_beginscan(Relation relation, Snapshot snapshot,
      int nkeys, ScanKey key);
extern HeapScanDesc heap_beginscan_strat(Relation relation, Snapshot snapshot,
      int nkeys, ScanKey key,
      bool allow_strat, bool allow_sync);
extern HeapScanDesc heap_beginscan_bm(Relation relation, Snapshot snapshot,
      int nkeys, ScanKey key);
extern void heap_rescan(HeapScanDesc scan, ScanKey key);
extern void heap_endscan(HeapScanDesc scan);
extern HeapTuple heap_getnext(HeapScanDesc scan, ScanDirection direction);

extern bool heap_fetch(Relation relation, Snapshot snapshot,
     HeapTuple tuple, Buffer *userbuf, bool keep_buf,
     Relation stats_relation);
extern bool heap_hot_search_buffer(ItemPointer tid, Relation relation,
        Buffer buffer, Snapshot snapshot, HeapTuple heapTuple,
        bool *all_dead, bool first_call);
extern bool heap_hot_search(ItemPointer tid, Relation relation,
    Snapshot snapshot, bool *all_dead);

extern void heap_get_latest_tid(Relation relation, Snapshot snapshot,
     ItemPointer tid);
extern void setLastTid(const ItemPointer tid);

extern BulkInsertState GetBulkInsertState(void);
extern void FreeBulkInsertState(BulkInsertState);

extern Oid heap_insert(Relation relation, HeapTuple tup, CommandId cid,
   int options, BulkInsertState bistate);
extern void heap_multi_insert(Relation relation, HeapTuple *tuples, int ntuples,
      CommandId cid, int options, BulkInsertState bistate);
extern HTSU_Result heap_delete(Relation relation, ItemPointer tid,
   ItemPointer ctid, TransactionId *update_xmax,
   CommandId cid, Snapshot crosscheck, bool wait);
extern HTSU_Result heap_update(Relation relation, ItemPointer otid,
   HeapTuple newtup,
   ItemPointer ctid, TransactionId *update_xmax,
   CommandId cid, Snapshot crosscheck, bool wait);
extern HTSU_Result heap_lock_tuple(Relation relation, HeapTuple tuple,
    Buffer *buffer, ItemPointer ctid,
    TransactionId *update_xmax, CommandId cid,
    LockTupleMode mode, bool nowait);
extern void heap_inplace_update(Relation relation, HeapTuple tuple);
extern bool heap_freeze_tuple(HeapTupleHeader tuple, TransactionId cutoff_xid);
extern bool heap_tuple_needs_freeze(HeapTupleHeader tuple, TransactionId cutoff_xid,
      Buffer buf);

extern Oid simple_heap_insert(Relation relation, HeapTuple tup);
extern void simple_heap_delete(Relation relation, ItemPointer tid);
extern void simple_heap_update(Relation relation, ItemPointer otid,
       HeapTuple tup);

extern void heap_markpos(HeapScanDesc scan);
extern void heap_restrpos(HeapScanDesc scan);

extern void heap_sync(Relation relation);

extern void heap_redo(XLogRecPtr lsn, XLogRecord *rptr);
extern void heap_desc(StringInfo buf, uint8 xl_info, char *rec);
extern void heap2_redo(XLogRecPtr lsn, XLogRecord *rptr);
extern void heap2_desc(StringInfo buf, uint8 xl_info, char *rec);

extern XLogRecPtr log_heap_cleanup_info(RelFileNode rnode,
       TransactionId latestRemovedXid);
extern XLogRecPtr log_heap_clean(Relation reln, Buffer buffer,
      OffsetNumber *redirected, int nredirected,
      OffsetNumber *nowdead, int ndead,
      OffsetNumber *nowunused, int nunused,
      TransactionId latestRemovedXid);
extern XLogRecPtr log_heap_freeze(Relation reln, Buffer buffer,
    TransactionId cutoff_xid,
    OffsetNumber *offsets, int offcnt);
extern XLogRecPtr log_heap_visible(RelFileNode rnode, BlockNumber block,
     Buffer vm_buffer, TransactionId cutoff_xid);
extern XLogRecPtr log_newpage(RelFileNode *rnode, ForkNumber forkNum,
   BlockNumber blk, Page page);


extern void heap_page_prune_opt(Relation relation, Buffer buffer,
     TransactionId OldestXmin);
extern int heap_page_prune(Relation relation, Buffer buffer,
    TransactionId OldestXmin,
    bool report_stats, TransactionId *latestRemovedXid);
extern void heap_page_prune_execute(Buffer buffer,
      OffsetNumber *redirected, int nredirected,
      OffsetNumber *nowdead, int ndead,
      OffsetNumber *nowunused, int nunused);
extern void heap_get_root_tuples(Page page, OffsetNumber *root_offsets);


extern void ss_report_location(Relation rel, BlockNumber location);
extern BlockNumber ss_get_location(Relation rel, BlockNumber relnblocks);
extern void SyncScanShmemInit(void);
extern Size SyncScanShmemSize(void);
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/instrument.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/instrument.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/portability/instr_time.h" 1
# 57 "/Users/parrt/tmp/postgresql-9.2.4/src/include/portability/instr_time.h"
# 1 "/usr/include/sys/time.h" 1 3 4
# 78 "/usr/include/sys/time.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 88 "/usr/include/sys/_structs.h" 3 4
struct timespec
{
 __darwin_time_t tv_sec;
 long tv_nsec;
};
# 79 "/usr/include/sys/time.h" 2 3 4
# 94 "/usr/include/sys/time.h" 3 4
struct itimerval {
 struct timeval it_interval;
 struct timeval it_value;
};
# 144 "/usr/include/sys/time.h" 3 4
struct timezone {
 int tz_minuteswest;
 int tz_dsttime;
};
# 187 "/usr/include/sys/time.h" 3 4
struct clockinfo {
 int hz;
 int tick;
 int tickadj;
 int stathz;
 int profhz;
};




# 1 "./time.h" 1 3 4
# 199 "/usr/include/sys/time.h" 2 3 4





int adjtime(const struct timeval *, struct timeval *);
int futimes(int, const struct timeval *);
int lutimes(const char *, const struct timeval *) __attribute__((visibility("default")));
int settimeofday(const struct timeval *, const struct timezone *);


int getitimer(int, struct itimerval *);
int gettimeofday(struct timeval * , void * );

# 1 "/usr/include/sys/_select.h" 1 3 4
# 39 "/usr/include/sys/_select.h" 3 4
int select(int, fd_set * , fd_set * ,
  fd_set * , struct timeval * )




  __asm("_" "select" "$1050")




  ;
# 214 "/usr/include/sys/time.h" 2 3 4

int setitimer(int, const struct itimerval * ,
  struct itimerval * );
int utimes(const char *, const struct timeval *);


# 58 "/Users/parrt/tmp/postgresql-9.2.4/src/include/portability/instr_time.h" 2

typedef struct timeval instr_time;
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/instrument.h" 2


typedef struct BufferUsage
{
 long shared_blks_hit;
 long shared_blks_read;
 long shared_blks_dirtied;
 long shared_blks_written;
 long local_blks_hit;
 long local_blks_read;
 long local_blks_dirtied;
 long local_blks_written;
 long temp_blks_read;
 long temp_blks_written;
 instr_time blk_read_time;
 instr_time blk_write_time;
} BufferUsage;


typedef enum InstrumentOption
{
 INSTRUMENT_TIMER = 1 << 0,
 INSTRUMENT_BUFFERS = 1 << 1,
 INSTRUMENT_ROWS = 1 << 2,
 INSTRUMENT_ALL = 0x7FFFFFFF
} InstrumentOption;

typedef struct Instrumentation
{

 bool need_timer;
 bool need_bufusage;

 bool running;
 instr_time starttime;
 instr_time counter;
 double firsttuple;
 double tuplecount;
 BufferUsage bufusage_start;

 double startup;
 double total;
 double ntuples;
 double nloops;
 double nfiltered1;
 double nfiltered2;
 BufferUsage bufusage;
} Instrumentation;

extern BufferUsage pgBufferUsage;

extern Instrumentation *InstrAlloc(int n, int instrument_options);
extern void InstrStartNode(Instrumentation *instr);
extern void InstrStopNode(Instrumentation *instr, double nTuples);
extern void InstrEndLoop(Instrumentation *instr);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/params.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/params.h"
struct ParseState;
# 53 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/params.h"
typedef struct ParamExternData
{
 Datum value;
 bool isnull;
 uint16 pflags;
 Oid ptype;
} ParamExternData;

typedef struct ParamListInfoData *ParamListInfo;

typedef void (*ParamFetchHook) (ParamListInfo params, int paramid);

typedef void (*ParserSetupHook) (struct ParseState *pstate, void *arg);

typedef struct ParamListInfoData
{
 ParamFetchHook paramFetch;
 void *paramFetchArg;
 ParserSetupHook parserSetup;
 void *parserSetupArg;
 int numParams;
 ParamExternData params[1];
} ParamListInfoData;
# 95 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/params.h"
typedef struct ParamExecData
{
 void *execPlan;
 Datum value;
 bool isnull;
} ParamExecData;



extern ParamListInfo copyParamList(ParamListInfo from);
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/sdir.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/bitmapset.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h" 2
# 34 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct PlannedStmt
{
 NodeTag type;

 CmdType commandType;

 uint32 queryId;

 bool hasReturning;

 bool hasModifyingCTE;

 bool canSetTag;

 bool transientPlan;

 struct Plan *planTree;

 List *rtable;


 List *resultRelations;

 Node *utilityStmt;

 List *subplans;

 Bitmapset *rewindPlanIDs;

 List *rowMarks;

 List *relationOids;

 List *invalItems;

 int nParamExec;
} PlannedStmt;
# 89 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct Plan
{
 NodeTag type;




 Cost startup_cost;
 Cost total_cost;




 double plan_rows;
 int plan_width;




 List *targetlist;
 List *qual;
 struct Plan *lefttree;
 struct Plan *righttree;
 List *initPlan;
# 126 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
 Bitmapset *extParam;
 Bitmapset *allParam;
} Plan;
# 152 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct Result
{
 Plan plan;
 Node *resconstantqual;
} Result;
# 167 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct ModifyTable
{
 Plan plan;
 CmdType operation;
 bool canSetTag;
 List *resultRelations;
 int resultRelIndex;
 List *plans;
 List *returningLists;
 List *rowMarks;
 int epqParam;
} ModifyTable;






typedef struct Append
{
 Plan plan;
 List *appendplans;
} Append;






typedef struct MergeAppend
{
 Plan plan;
 List *mergeplans;

 int numCols;
 AttrNumber *sortColIdx;
 Oid *sortOperators;
 Oid *collations;
 bool *nullsFirst;
} MergeAppend;
# 216 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct RecursiveUnion
{
 Plan plan;
 int wtParam;

 int numCols;

 AttrNumber *dupColIdx;
 Oid *dupOperators;
 long numGroups;
} RecursiveUnion;
# 236 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct BitmapAnd
{
 Plan plan;
 List *bitmapplans;
} BitmapAnd;
# 250 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct BitmapOr
{
 Plan plan;
 List *bitmapplans;
} BitmapOr;






typedef struct Scan
{
 Plan plan;
 Index scanrelid;
} Scan;





typedef Scan SeqScan;
# 305 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct IndexScan
{
 Scan scan;
 Oid indexid;
 List *indexqual;
 List *indexqualorig;
 List *indexorderby;
 List *indexorderbyorig;
 ScanDirection indexorderdir;
} IndexScan;
# 333 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct IndexOnlyScan
{
 Scan scan;
 Oid indexid;
 List *indexqual;
 List *indexorderby;
 List *indextlist;
 ScanDirection indexorderdir;
} IndexOnlyScan;
# 360 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct BitmapIndexScan
{
 Scan scan;
 Oid indexid;
 List *indexqual;
 List *indexqualorig;
} BitmapIndexScan;
# 377 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct BitmapHeapScan
{
 Scan scan;
 List *bitmapqualorig;
} BitmapHeapScan;
# 390 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct TidScan
{
 Scan scan;
 List *tidquals;
} TidScan;
# 412 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct SubqueryScan
{
 Scan scan;
 Plan *subplan;
} SubqueryScan;





typedef struct FunctionScan
{
 Scan scan;
 Node *funcexpr;
 List *funccolnames;
 List *funccoltypes;
 List *funccoltypmods;
 List *funccolcollations;
} FunctionScan;





typedef struct ValuesScan
{
 Scan scan;
 List *values_lists;
} ValuesScan;





typedef struct CteScan
{
 Scan scan;
 int ctePlanId;
 int cteParam;
} CteScan;





typedef struct WorkTableScan
{
 Scan scan;
 int wtParam;
} WorkTableScan;
# 475 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct ForeignScan
{
 Scan scan;
 List *fdw_exprs;
 List *fdw_private;
 bool fsSystemCol;
} ForeignScan;
# 506 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct Join
{
 Plan plan;
 JoinType jointype;
 List *joinqual;
} Join;
# 524 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct NestLoop
{
 Join join;
 List *nestParams;
} NestLoop;

typedef struct NestLoopParam
{
 NodeTag type;
 int paramno;
 Var *paramval;
} NestLoopParam;
# 548 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct MergeJoin
{
 Join join;
 List *mergeclauses;

 Oid *mergeFamilies;
 Oid *mergeCollations;
 int *mergeStrategies;
 bool *mergeNullsFirst;
} MergeJoin;





typedef struct HashJoin
{
 Join join;
 List *hashclauses;
} HashJoin;





typedef struct Material
{
 Plan plan;
} Material;





typedef struct Sort
{
 Plan plan;
 int numCols;
 AttrNumber *sortColIdx;
 Oid *sortOperators;
 Oid *collations;
 bool *nullsFirst;
} Sort;







typedef struct Group
{
 Plan plan;
 int numCols;
 AttrNumber *grpColIdx;
 Oid *grpOperators;
} Group;
# 620 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef enum AggStrategy
{
 AGG_PLAIN,
 AGG_SORTED,
 AGG_HASHED
} AggStrategy;

typedef struct Agg
{
 Plan plan;
 AggStrategy aggstrategy;
 int numCols;
 AttrNumber *grpColIdx;
 Oid *grpOperators;
 long numGroups;
} Agg;





typedef struct WindowAgg
{
 Plan plan;
 Index winref;
 int partNumCols;
 AttrNumber *partColIdx;
 Oid *partOperators;
 int ordNumCols;
 AttrNumber *ordColIdx;
 Oid *ordOperators;
 int frameOptions;
 Node *startOffset;
 Node *endOffset;
} WindowAgg;





typedef struct Unique
{
 Plan plan;
 int numCols;
 AttrNumber *uniqColIdx;
 Oid *uniqOperators;
} Unique;
# 677 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct Hash
{
 Plan plan;
 Oid skewTable;
 AttrNumber skewColumn;
 bool skewInherit;
 Oid skewColType;
 int32 skewColTypmod;

} Hash;





typedef enum SetOpCmd
{
 SETOPCMD_INTERSECT,
 SETOPCMD_INTERSECT_ALL,
 SETOPCMD_EXCEPT,
 SETOPCMD_EXCEPT_ALL
} SetOpCmd;

typedef enum SetOpStrategy
{
 SETOP_SORTED,
 SETOP_HASHED
} SetOpStrategy;

typedef struct SetOp
{
 Plan plan;
 SetOpCmd cmd;
 SetOpStrategy strategy;
 int numCols;

 AttrNumber *dupColIdx;
 Oid *dupOperators;
 AttrNumber flagColIdx;
 int firstFlag;
 long numGroups;
} SetOp;
# 729 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct LockRows
{
 Plan plan;
 List *rowMarks;
 int epqParam;
} LockRows;
# 743 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct Limit
{
 Plan plan;
 Node *limitOffset;
 Node *limitCount;
} Limit;
# 763 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef enum RowMarkType
{
 ROW_MARK_EXCLUSIVE,
 ROW_MARK_SHARE,
 ROW_MARK_REFERENCE,
 ROW_MARK_COPY
} RowMarkType;
# 807 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct PlanRowMark
{
 NodeTag type;
 Index rti;
 Index prti;
 Index rowmarkId;
 RowMarkType markType;
 bool noWait;
 bool isParent;
} PlanRowMark;
# 828 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct PlanInvalItem
{
 NodeTag type;
 int cacheId;
 uint32 hashValue;
} PlanInvalItem;
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/reltrigger.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/reltrigger.h"
typedef struct Trigger
{
 Oid tgoid;

 char *tgname;
 Oid tgfoid;
 int16 tgtype;
 char tgenabled;
 bool tgisinternal;
 Oid tgconstrrelid;
 Oid tgconstrindid;
 Oid tgconstraint;
 bool tgdeferrable;
 bool tginitdeferred;
 int16 tgnargs;
 int16 tgnattr;
 int16 *tgattr;
 char **tgargs;
 char *tgqual;
} Trigger;

typedef struct TriggerDesc
{
 Trigger *triggers;
 int numtriggers;





 bool trig_insert_before_row;
 bool trig_insert_after_row;
 bool trig_insert_instead_row;
 bool trig_insert_before_statement;
 bool trig_insert_after_statement;
 bool trig_update_before_row;
 bool trig_update_after_row;
 bool trig_update_instead_row;
 bool trig_update_before_statement;
 bool trig_update_after_statement;
 bool trig_delete_before_row;
 bool trig_delete_after_row;
 bool trig_delete_instead_row;
 bool trig_delete_before_statement;
 bool trig_delete_after_statement;

 bool trig_truncate_before_statement;
 bool trig_truncate_after_statement;
} TriggerDesc;
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/sortsupport.h" 1
# 50 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/sortsupport.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h" 1
# 51 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/sortsupport.h" 2

typedef struct SortSupportData *SortSupport;

typedef struct SortSupportData
{




 MemoryContext ssup_cxt;
 Oid ssup_collation;






 bool ssup_reverse;
 bool ssup_nulls_first;





 AttrNumber ssup_attno;





 void *ssup_extra;
# 96 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/sortsupport.h"
 int (*comparator) (Datum x, Datum y, SortSupport ssup);




} SortSupportData;
# 111 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/sortsupport.h"
static inline int
ApplySortComparator(Datum datum1, bool isNull1,
     Datum datum2, bool isNull2,
     SortSupport ssup)
{
 int compare;

 if (isNull1)
 {
  if (isNull2)
   compare = 0;
  else if (ssup->ssup_nulls_first)
   compare = -1;
  else
   compare = 1;
 }
 else if (isNull2)
 {
  if (ssup->ssup_nulls_first)
   compare = 1;
  else
   compare = -1;
 }
 else
 {
  compare = (*ssup->comparator) (datum1, datum2, ssup);
  if (ssup->ssup_reverse)
   compare = -compare;
 }

 return compare;
}
# 151 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/sortsupport.h"
extern void PrepareSortSupportComparisonShim(Oid cmpFunc, SortSupport ssup);
extern void PrepareSortSupportFromOrderingOp(Oid orderingOp, SortSupport ssup);
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/tuplestore.h" 1
# 34 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/tuplestore.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 2
# 112 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
typedef struct TupleTableSlot
{
 NodeTag type;
 bool tts_isempty;
 bool tts_shouldFree;
 bool tts_shouldFreeMin;
 bool tts_slow;
 HeapTuple tts_tuple;
 TupleDesc tts_tupleDescriptor;
 MemoryContext tts_mcxt;
 Buffer tts_buffer;
 int tts_nvalid;
 Datum *tts_values;
 bool *tts_isnull;
 MinimalTuple tts_mintuple;
 HeapTupleData tts_minhdr;
 long tts_off;
} TupleTableSlot;
# 141 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
extern TupleTableSlot *MakeTupleTableSlot(void);
extern TupleTableSlot *ExecAllocTableSlot(List **tupleTable);
extern void ExecResetTupleTable(List *tupleTable, bool shouldFree);
extern TupleTableSlot *MakeSingleTupleTableSlot(TupleDesc tupdesc);
extern void ExecDropSingleTupleTableSlot(TupleTableSlot *slot);
extern void ExecSetSlotDescriptor(TupleTableSlot *slot, TupleDesc tupdesc);
extern TupleTableSlot *ExecStoreTuple(HeapTuple tuple,
      TupleTableSlot *slot,
      Buffer buffer,
      bool shouldFree);
extern TupleTableSlot *ExecStoreMinimalTuple(MinimalTuple mtup,
       TupleTableSlot *slot,
       bool shouldFree);
extern TupleTableSlot *ExecClearTuple(TupleTableSlot *slot);
extern TupleTableSlot *ExecStoreVirtualTuple(TupleTableSlot *slot);
extern TupleTableSlot *ExecStoreAllNullTuple(TupleTableSlot *slot);
extern HeapTuple ExecCopySlotTuple(TupleTableSlot *slot);
extern MinimalTuple ExecCopySlotMinimalTuple(TupleTableSlot *slot);
extern HeapTuple ExecFetchSlotTuple(TupleTableSlot *slot);
extern MinimalTuple ExecFetchSlotMinimalTuple(TupleTableSlot *slot);
extern Datum ExecFetchSlotTupleDatum(TupleTableSlot *slot);
extern HeapTuple ExecMaterializeSlot(TupleTableSlot *slot);
extern TupleTableSlot *ExecCopySlot(TupleTableSlot *dstslot,
    TupleTableSlot *srcslot);


extern Datum slot_getattr(TupleTableSlot *slot, int attnum, bool *isnull);
extern void slot_getallattrs(TupleTableSlot *slot);
extern void slot_getsomeattrs(TupleTableSlot *slot, int attnum);
extern bool slot_attisnull(TupleTableSlot *slot, int attnum);
# 35 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/tuplestore.h" 2





typedef struct Tuplestorestate Tuplestorestate;






extern Tuplestorestate *tuplestore_begin_heap(bool randomAccess,
       bool interXact,
       int maxKBytes);

extern void tuplestore_set_eflags(Tuplestorestate *state, int eflags);

extern void tuplestore_puttupleslot(Tuplestorestate *state,
      TupleTableSlot *slot);
extern void tuplestore_puttuple(Tuplestorestate *state, HeapTuple tuple);
extern void tuplestore_putvalues(Tuplestorestate *state, TupleDesc tdesc,
      Datum *values, bool *isnull);




extern int tuplestore_alloc_read_pointer(Tuplestorestate *state, int eflags);

extern void tuplestore_select_read_pointer(Tuplestorestate *state, int ptr);

extern void tuplestore_copy_read_pointer(Tuplestorestate *state,
        int srcptr, int destptr);

extern void tuplestore_trim(Tuplestorestate *state);

extern bool tuplestore_in_memory(Tuplestorestate *state);

extern bool tuplestore_gettupleslot(Tuplestorestate *state, bool forward,
      bool copy, TupleTableSlot *slot);
extern bool tuplestore_advance(Tuplestorestate *state, bool forward);

extern bool tuplestore_ateof(Tuplestorestate *state);

extern void tuplestore_rescan(Tuplestorestate *state);

extern void tuplestore_clear(Tuplestorestate *state);

extern void tuplestore_end(Tuplestorestate *state);
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 2
# 53 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct IndexInfo
{
 NodeTag type;
 int ii_NumIndexAttrs;
 AttrNumber ii_KeyAttrNumbers[32];
 List *ii_Expressions;
 List *ii_ExpressionsState;
 List *ii_Predicate;
 List *ii_PredicateState;
 Oid *ii_ExclusionOps;
 Oid *ii_ExclusionProcs;
 uint16 *ii_ExclusionStrats;
 bool ii_Unique;
 bool ii_ReadyForInserts;
 bool ii_Concurrent;
 bool ii_BrokenHotChain;
} IndexInfo;







typedef void (*ExprContextCallbackFunction) (Datum arg);

typedef struct ExprContext_CB
{
 struct ExprContext_CB *next;
 ExprContextCallbackFunction function;
 Datum arg;
} ExprContext_CB;
# 109 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ExprContext
{
 NodeTag type;


 TupleTableSlot *ecxt_scantuple;
 TupleTableSlot *ecxt_innertuple;
 TupleTableSlot *ecxt_outertuple;


 MemoryContext ecxt_per_query_memory;
 MemoryContext ecxt_per_tuple_memory;


 ParamExecData *ecxt_param_exec_vals;
 ParamListInfo ecxt_param_list_info;





 Datum *ecxt_aggvalues;
 bool *ecxt_aggnulls;


 Datum caseValue_datum;
 bool caseValue_isNull;


 Datum domainValue_datum;
 bool domainValue_isNull;


 struct EState *ecxt_estate;


 ExprContext_CB *ecxt_callbacks;
} ExprContext;




typedef enum
{
 ExprSingleResult,
 ExprMultipleResult,
 ExprEndResult
} ExprDoneCond;







typedef enum
{
 SFRM_ValuePerCall = 0x01,
 SFRM_Materialize = 0x02,
 SFRM_Materialize_Random = 0x04,
 SFRM_Materialize_Preferred = 0x08
} SetFunctionReturnMode;







typedef struct ReturnSetInfo
{
 NodeTag type;

 ExprContext *econtext;
 TupleDesc expectedDesc;
 int allowedModes;

 SetFunctionReturnMode returnMode;
 ExprDoneCond isDone;

 Tuplestorestate *setResult;
 TupleDesc setDesc;
} ReturnSetInfo;
# 232 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ProjectionInfo
{
 NodeTag type;
 List *pi_targetlist;
 ExprContext *pi_exprContext;
 TupleTableSlot *pi_slot;
 ExprDoneCond *pi_itemIsDone;
 bool pi_directMap;
 int pi_numSimpleVars;
 int *pi_varSlotOffsets;
 int *pi_varNumbers;
 int *pi_varOutputCols;
 int pi_lastInnerVar;
 int pi_lastOuterVar;
 int pi_lastScanVar;
} ProjectionInfo;
# 276 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct JunkFilter
{
 NodeTag type;
 List *jf_targetList;
 TupleDesc jf_cleanTupType;
 AttrNumber *jf_cleanMap;
 TupleTableSlot *jf_resultSlot;
 AttrNumber jf_junkAttNo;
} JunkFilter;
# 308 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ResultRelInfo
{
 NodeTag type;
 Index ri_RangeTableIndex;
 Relation ri_RelationDesc;
 int ri_NumIndices;
 RelationPtr ri_IndexRelationDescs;
 IndexInfo **ri_IndexRelationInfo;
 TriggerDesc *ri_TrigDesc;
 FmgrInfo *ri_TrigFunctions;
 List **ri_TrigWhenExprs;
 Instrumentation *ri_TrigInstrument;
 List **ri_ConstraintExprs;
 JunkFilter *ri_junkFilter;
 ProjectionInfo *ri_projectReturning;
} ResultRelInfo;







typedef struct EState
{
 NodeTag type;


 ScanDirection es_direction;
 Snapshot es_snapshot;
 Snapshot es_crosscheck_snapshot;
 List *es_range_table;
 PlannedStmt *es_plannedstmt;

 JunkFilter *es_junkFilter;


 CommandId es_output_cid;


 ResultRelInfo *es_result_relations;
 int es_num_result_relations;
 ResultRelInfo *es_result_relation_info;


 List *es_trig_target_relations;
 TupleTableSlot *es_trig_tuple_slot;
 TupleTableSlot *es_trig_oldtup_slot;
 TupleTableSlot *es_trig_newtup_slot;


 ParamListInfo es_param_list_info;
 ParamExecData *es_param_exec_vals;


 MemoryContext es_query_cxt;

 List *es_tupleTable;

 List *es_rowMarks;

 uint32 es_processed;
 Oid es_lastoid;

 int es_top_eflags;
 int es_instrument;
 bool es_finished;

 List *es_exprcontexts;

 List *es_subplanstates;

 List *es_auxmodifytables;






 ExprContext *es_per_tuple_exprcontext;
# 398 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
 HeapTuple *es_epqTuple;
 bool *es_epqTupleSet;
 bool *es_epqScanDone;
} EState;
# 416 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ExecRowMark
{
 Relation relation;
 Index rti;
 Index prti;
 Index rowmarkId;
 RowMarkType markType;
 bool noWait;
 ItemPointerData curCtid;
} ExecRowMark;
# 439 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ExecAuxRowMark
{
 ExecRowMark *rowmark;
 AttrNumber ctidAttNo;
 AttrNumber toidAttNo;
 AttrNumber wholeAttNo;
} ExecAuxRowMark;
# 464 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct TupleHashEntryData *TupleHashEntry;
typedef struct TupleHashTableData *TupleHashTable;

typedef struct TupleHashEntryData
{

 MinimalTuple firstTuple;

} TupleHashEntryData;

typedef struct TupleHashTableData
{
 HTAB *hashtab;
 int numCols;
 AttrNumber *keyColIdx;
 FmgrInfo *tab_hash_funcs;
 FmgrInfo *tab_eq_funcs;
 MemoryContext tablecxt;
 MemoryContext tempcxt;
 Size entrysize;
 TupleTableSlot *tableslot;

 TupleTableSlot *inputslot;
 FmgrInfo *in_hash_funcs;
 FmgrInfo *cur_eq_funcs;
} TupleHashTableData;

typedef HASH_SEQ_STATUS TupleHashIterator;
# 536 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ExprState ExprState;

typedef Datum (*ExprStateEvalFunc) (ExprState *expression,
            ExprContext *econtext,
            bool *isNull,
            ExprDoneCond *isDone);

struct ExprState
{
 NodeTag type;
 Expr *expr;
 ExprStateEvalFunc evalfunc;
};
# 557 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct GenericExprState
{
 ExprState xprstate;
 ExprState *arg;
} GenericExprState;





typedef struct WholeRowVarExprState
{
 ExprState xprstate;
 struct PlanState *parent;
 JunkFilter *wrv_junkFilter;
} WholeRowVarExprState;





typedef struct AggrefExprState
{
 ExprState xprstate;
 List *args;
 int aggno;
} AggrefExprState;





typedef struct WindowFuncExprState
{
 ExprState xprstate;
 List *args;
 int wfuncno;
} WindowFuncExprState;
# 604 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ArrayRefExprState
{
 ExprState xprstate;
 List *refupperindexpr;
 List *reflowerindexpr;
 ExprState *refexpr;
 ExprState *refassgnexpr;
 int16 refattrlength;
 int16 refelemlength;
 bool refelembyval;
 char refelemalign;
} ArrayRefExprState;
# 625 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct FuncExprState
{
 ExprState xprstate;
 List *args;






 FmgrInfo func;






 Tuplestorestate *funcResultStore;
 TupleTableSlot *funcResultSlot;





 TupleDesc funcResultDesc;
 bool funcReturnsTuple;
# 660 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
 bool setArgsValid;






 bool setHasSetArg;







 bool shutdown_reg;






 FunctionCallInfoData fcinfo_data;
} FuncExprState;







typedef struct ScalarArrayOpExprState
{
 FuncExprState fxprstate;

 Oid element_type;
 int16 typlen;
 bool typbyval;
 char typalign;
} ScalarArrayOpExprState;





typedef struct BoolExprState
{
 ExprState xprstate;
 List *args;
} BoolExprState;





typedef struct SubPlanState
{
 ExprState xprstate;
 struct PlanState *planstate;
 ExprState *testexpr;
 List *args;
 HeapTuple curTuple;
 Datum curArray;

 ProjectionInfo *projLeft;
 ProjectionInfo *projRight;
 TupleHashTable hashtable;
 TupleHashTable hashnulls;
 bool havehashrows;
 bool havenullrows;
 MemoryContext hashtablecxt;
 MemoryContext hashtempcxt;
 ExprContext *innerecontext;
 AttrNumber *keyColIdx;
 FmgrInfo *tab_hash_funcs;
 FmgrInfo *tab_eq_funcs;
 FmgrInfo *lhs_hash_funcs;
 FmgrInfo *cur_eq_funcs;
} SubPlanState;





typedef struct AlternativeSubPlanState
{
 ExprState xprstate;
 List *subplans;
 int active;
} AlternativeSubPlanState;





typedef struct FieldSelectState
{
 ExprState xprstate;
 ExprState *arg;
 TupleDesc argdesc;
} FieldSelectState;





typedef struct FieldStoreState
{
 ExprState xprstate;
 ExprState *arg;
 List *newvals;
 TupleDesc argdesc;
} FieldStoreState;





typedef struct CoerceViaIOState
{
 ExprState xprstate;
 ExprState *arg;
 FmgrInfo outfunc;
 FmgrInfo infunc;
 Oid intypioparam;
} CoerceViaIOState;





typedef struct ArrayCoerceExprState
{
 ExprState xprstate;
 ExprState *arg;
 Oid resultelemtype;
 FmgrInfo elemfunc;

 struct ArrayMapState *amstate;
} ArrayCoerceExprState;





typedef struct ConvertRowtypeExprState
{
 ExprState xprstate;
 ExprState *arg;
 TupleDesc indesc;
 TupleDesc outdesc;

 struct TupleConversionMap *map;
 bool initialized;
} ConvertRowtypeExprState;





typedef struct CaseExprState
{
 ExprState xprstate;
 ExprState *arg;
 List *args;
 ExprState *defresult;
} CaseExprState;





typedef struct CaseWhenState
{
 ExprState xprstate;
 ExprState *expr;
 ExprState *result;
} CaseWhenState;
# 846 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ArrayExprState
{
 ExprState xprstate;
 List *elements;
 int16 elemlength;
 bool elembyval;
 char elemalign;
} ArrayExprState;





typedef struct RowExprState
{
 ExprState xprstate;
 List *args;
 TupleDesc tupdesc;
} RowExprState;





typedef struct RowCompareExprState
{
 ExprState xprstate;
 List *largs;
 List *rargs;
 FmgrInfo *funcs;
 Oid *collations;
} RowCompareExprState;





typedef struct CoalesceExprState
{
 ExprState xprstate;
 List *args;
} CoalesceExprState;





typedef struct MinMaxExprState
{
 ExprState xprstate;
 List *args;
 FmgrInfo cfunc;
} MinMaxExprState;





typedef struct XmlExprState
{
 ExprState xprstate;
 List *named_args;
 List *args;
} XmlExprState;





typedef struct NullTestState
{
 ExprState xprstate;
 ExprState *arg;

 TupleDesc argdesc;
} NullTestState;





typedef struct CoerceToDomainState
{
 ExprState xprstate;
 ExprState *arg;

 List *constraints;
} CoerceToDomainState;
# 942 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef enum DomainConstraintType
{
 DOM_CONSTRAINT_NOTNULL,
 DOM_CONSTRAINT_CHECK
} DomainConstraintType;

typedef struct DomainConstraintState
{
 NodeTag type;
 DomainConstraintType constrainttype;
 char *name;
 ExprState *check_expr;
} DomainConstraintState;
# 972 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct PlanState
{
 NodeTag type;

 Plan *plan;

 EState *state;



 Instrumentation *instrument;






 List *targetlist;
 List *qual;
 struct PlanState *lefttree;
 struct PlanState *righttree;
 List *initPlan;

 List *subPlan;




 Bitmapset *chgParam;




 TupleTableSlot *ps_ResultTupleSlot;
 ExprContext *ps_ExprContext;
 ProjectionInfo *ps_ProjInfo;
 bool ps_TupFromTlist;

} PlanState;
# 1039 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct EPQState
{
 EState *estate;
 PlanState *planstate;
 TupleTableSlot *origslot;
 Plan *plan;
 List *arowMarks;
 int epqParam;
} EPQState;






typedef struct ResultState
{
 PlanState ps;
 ExprState *resconstantqual;
 bool rs_done;
 bool rs_checkqual;
} ResultState;





typedef struct ModifyTableState
{
 PlanState ps;
 CmdType operation;
 bool canSetTag;
 bool mt_done;
 PlanState **mt_plans;
 int mt_nplans;
 int mt_whichplan;
 ResultRelInfo *resultRelInfo;
 List **mt_arowmarks;
 EPQState mt_epqstate;
 bool fireBSTriggers;
} ModifyTableState;
# 1088 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct AppendState
{
 PlanState ps;
 PlanState **appendplans;
 int as_nplans;
 int as_whichplan;
} AppendState;
# 1109 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct MergeAppendState
{
 PlanState ps;
 PlanState **mergeplans;
 int ms_nplans;
 int ms_nkeys;
 SortSupport ms_sortkeys;
 TupleTableSlot **ms_slots;
 int *ms_heap;
 int ms_heap_size;
 bool ms_initialized;
 int ms_last_slot;
} MergeAppendState;
# 1134 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct RecursiveUnionState
{
 PlanState ps;
 bool recursing;
 bool intermediate_empty;
 Tuplestorestate *working_table;
 Tuplestorestate *intermediate_table;

 FmgrInfo *eqfunctions;
 FmgrInfo *hashfunctions;
 MemoryContext tempContext;
 TupleHashTable hashtable;
 MemoryContext tableContext;
} RecursiveUnionState;





typedef struct BitmapAndState
{
 PlanState ps;
 PlanState **bitmapplans;
 int nplans;
} BitmapAndState;





typedef struct BitmapOrState
{
 PlanState ps;
 PlanState **bitmapplans;
 int nplans;
} BitmapOrState;
# 1190 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ScanState
{
 PlanState ps;
 Relation ss_currentRelation;
 HeapScanDesc ss_currentScanDesc;
 TupleTableSlot *ss_ScanTupleSlot;
} ScanState;





typedef ScanState SeqScanState;






typedef struct
{
 ScanKey scan_key;
 ExprState *key_expr;
 bool key_toastable;
} IndexRuntimeKeyInfo;

typedef struct
{
 ScanKey scan_key;
 ExprState *array_expr;
 int next_elem;
 int num_elems;
 Datum *elem_values;
 bool *elem_nulls;
} IndexArrayKeyInfo;
# 1242 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct IndexScanState
{
 ScanState ss;
 List *indexqualorig;
 ScanKey iss_ScanKeys;
 int iss_NumScanKeys;
 ScanKey iss_OrderByKeys;
 int iss_NumOrderByKeys;
 IndexRuntimeKeyInfo *iss_RuntimeKeys;
 int iss_NumRuntimeKeys;
 bool iss_RuntimeKeysReady;
 ExprContext *iss_RuntimeContext;
 Relation iss_RelationDesc;
 IndexScanDesc iss_ScanDesc;
} IndexScanState;
# 1276 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct IndexOnlyScanState
{
 ScanState ss;
 List *indexqual;
 ScanKey ioss_ScanKeys;
 int ioss_NumScanKeys;
 ScanKey ioss_OrderByKeys;
 int ioss_NumOrderByKeys;
 IndexRuntimeKeyInfo *ioss_RuntimeKeys;
 int ioss_NumRuntimeKeys;
 bool ioss_RuntimeKeysReady;
 ExprContext *ioss_RuntimeContext;
 Relation ioss_RelationDesc;
 IndexScanDesc ioss_ScanDesc;
 Buffer ioss_VMBuffer;
 long ioss_HeapFetches;
} IndexOnlyScanState;
# 1310 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct BitmapIndexScanState
{
 ScanState ss;
 TIDBitmap *biss_result;
 ScanKey biss_ScanKeys;
 int biss_NumScanKeys;
 IndexRuntimeKeyInfo *biss_RuntimeKeys;
 int biss_NumRuntimeKeys;
 IndexArrayKeyInfo *biss_ArrayKeys;
 int biss_NumArrayKeys;
 bool biss_RuntimeKeysReady;
 ExprContext *biss_RuntimeContext;
 Relation biss_RelationDesc;
 IndexScanDesc biss_ScanDesc;
} BitmapIndexScanState;
# 1338 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct BitmapHeapScanState
{
 ScanState ss;
 List *bitmapqualorig;
 TIDBitmap *tbm;
 TBMIterator *tbmiterator;
 TBMIterateResult *tbmres;
 TBMIterator *prefetch_iterator;
 int prefetch_pages;
 int prefetch_target;
} BitmapHeapScanState;
# 1359 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct TidScanState
{
 ScanState ss;
 List *tss_tidquals;
 bool tss_isCurrentOf;
 int tss_NumTids;
 int tss_TidPtr;
 int tss_MarkTidPtr;
 ItemPointerData *tss_TidList;
 HeapTupleData tss_htup;
} TidScanState;
# 1378 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct SubqueryScanState
{
 ScanState ss;
 PlanState *subplan;
} SubqueryScanState;
# 1396 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct FunctionScanState
{
 ScanState ss;
 int eflags;
 TupleDesc tupdesc;
 Tuplestorestate *tuplestorestate;
 ExprState *funcexpr;
} FunctionScanState;
# 1423 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ValuesScanState
{
 ScanState ss;
 ExprContext *rowcontext;
 List **exprlists;
 int array_len;
 int curr_idx;
 int marked_idx;
} ValuesScanState;
# 1443 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct CteScanState
{
 ScanState ss;
 int eflags;
 int readptr;
 PlanState *cteplanstate;

 struct CteScanState *leader;

 Tuplestorestate *cte_table;
 bool eof_cte;
} CteScanState;
# 1464 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct WorkTableScanState
{
 ScanState ss;
 RecursiveUnionState *rustate;
} WorkTableScanState;







typedef struct ForeignScanState
{
 ScanState ss;

 struct FdwRoutine *fdwroutine;
 void *fdw_state;
} ForeignScanState;
# 1495 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct JoinState
{
 PlanState ps;
 JoinType jointype;
 List *joinqual;
} JoinState;
# 1510 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct NestLoopState
{
 JoinState js;
 bool nl_NeedNewOuter;
 bool nl_MatchedOuter;
 TupleTableSlot *nl_NullInnerTupleSlot;
} NestLoopState;
# 1540 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct MergeJoinClauseData *MergeJoinClause;

typedef struct MergeJoinState
{
 JoinState js;
 int mj_NumClauses;
 MergeJoinClause mj_Clauses;
 int mj_JoinState;
 bool mj_ExtraMarks;
 bool mj_ConstFalseJoin;
 bool mj_FillOuter;
 bool mj_FillInner;
 bool mj_MatchedOuter;
 bool mj_MatchedInner;
 TupleTableSlot *mj_OuterTupleSlot;
 TupleTableSlot *mj_InnerTupleSlot;
 TupleTableSlot *mj_MarkedTupleSlot;
 TupleTableSlot *mj_NullOuterTupleSlot;
 TupleTableSlot *mj_NullInnerTupleSlot;
 ExprContext *mj_OuterEContext;
 ExprContext *mj_InnerEContext;
} MergeJoinState;
# 1591 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct HashJoinTupleData *HashJoinTuple;
typedef struct HashJoinTableData *HashJoinTable;

typedef struct HashJoinState
{
 JoinState js;
 List *hashclauses;
 List *hj_OuterHashKeys;
 List *hj_InnerHashKeys;
 List *hj_HashOperators;
 HashJoinTable hj_HashTable;
 uint32 hj_CurHashValue;
 int hj_CurBucketNo;
 int hj_CurSkewBucketNo;
 HashJoinTuple hj_CurTuple;
 TupleTableSlot *hj_OuterTupleSlot;
 TupleTableSlot *hj_HashTupleSlot;
 TupleTableSlot *hj_NullOuterTupleSlot;
 TupleTableSlot *hj_NullInnerTupleSlot;
 TupleTableSlot *hj_FirstOuterTupleSlot;
 int hj_JoinState;
 bool hj_MatchedOuter;
 bool hj_OuterNotEmpty;
} HashJoinState;
# 1631 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct MaterialState
{
 ScanState ss;
 int eflags;
 bool eof_underlying;
 Tuplestorestate *tuplestorestate;
} MaterialState;





typedef struct SortState
{
 ScanState ss;
 bool randomAccess;
 bool bounded;
 int64 bound;
 bool sort_Done;
 bool bounded_Done;
 int64 bound_Done;
 void *tuplesortstate;
} SortState;





typedef struct GroupState
{
 ScanState ss;
 FmgrInfo *eqfunctions;
 bool grp_done;
} GroupState;
# 1679 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct AggStatePerAggData *AggStatePerAgg;
typedef struct AggStatePerGroupData *AggStatePerGroup;

typedef struct AggState
{
 ScanState ss;
 List *aggs;
 int numaggs;
 FmgrInfo *eqfunctions;
 FmgrInfo *hashfunctions;
 AggStatePerAgg peragg;
 MemoryContext aggcontext;
 ExprContext *tmpcontext;
 bool agg_done;

 AggStatePerGroup pergroup;
 HeapTuple grp_firstTuple;

 TupleHashTable hashtable;
 TupleTableSlot *hashslot;
 List *hash_needed;
 bool table_filled;
 TupleHashIterator hashiter;
} AggState;






typedef struct WindowStatePerFuncData *WindowStatePerFunc;
typedef struct WindowStatePerAggData *WindowStatePerAgg;

typedef struct WindowAggState
{
 ScanState ss;


 List *funcs;
 int numfuncs;
 int numaggs;

 WindowStatePerFunc perfunc;
 WindowStatePerAgg peragg;
 FmgrInfo *partEqfunctions;
 FmgrInfo *ordEqfunctions;
 Tuplestorestate *buffer;
 int current_ptr;
 int64 spooled_rows;
 int64 currentpos;
 int64 frameheadpos;
 int64 frametailpos;

 struct WindowObjectData *agg_winobj;

 int64 aggregatedbase;
 int64 aggregatedupto;

 int frameOptions;
 ExprState *startOffset;
 ExprState *endOffset;
 Datum startOffsetValue;
 Datum endOffsetValue;

 MemoryContext partcontext;
 MemoryContext aggcontext;
 ExprContext *tmpcontext;

 bool all_first;
 bool all_done;
 bool partition_spooled;


 bool more_partitions;

 bool framehead_valid;

 bool frametail_valid;


 TupleTableSlot *first_part_slot;



 TupleTableSlot *agg_row_slot;
 TupleTableSlot *temp_slot_1;
 TupleTableSlot *temp_slot_2;
} WindowAggState;
# 1779 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct UniqueState
{
 PlanState ps;
 FmgrInfo *eqfunctions;
 MemoryContext tempContext;
} UniqueState;





typedef struct HashState
{
 PlanState ps;
 HashJoinTable hashtable;
 List *hashkeys;

} HashState;
# 1808 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct SetOpStatePerGroupData *SetOpStatePerGroup;

typedef struct SetOpState
{
 PlanState ps;
 FmgrInfo *eqfunctions;
 FmgrInfo *hashfunctions;
 bool setop_done;
 long numOutput;
 MemoryContext tempContext;

 SetOpStatePerGroup pergroup;
 HeapTuple grp_firstTuple;

 TupleHashTable hashtable;
 MemoryContext tableContext;
 bool table_filled;
 TupleHashIterator hashiter;
} SetOpState;







typedef struct LockRowsState
{
 PlanState ps;
 List *lr_arowMarks;
 EPQState lr_epqstate;
} LockRowsState;
# 1853 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef enum
{
 LIMIT_INITIAL,
 LIMIT_RESCAN,
 LIMIT_EMPTY,
 LIMIT_INWINDOW,
 LIMIT_SUBPLANEOF,
 LIMIT_WINDOWEND,
 LIMIT_WINDOWSTART
} LimitStateCond;

typedef struct LimitState
{
 PlanState ps;
 ExprState *limitOffset;
 ExprState *limitCount;
 int64 offset;
 int64 count;
 bool noCount;
 LimitStateCond lstate;
 int64 position;
 TupleTableSlot *subSlot;
} LimitState;
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/trigger.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 1
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/value.h" 1
# 42 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/value.h"
typedef struct Value
{
 NodeTag type;
 union ValUnion
 {
  long ival;
  char *str;
 } val;
} Value;





extern Value *makeInteger(long i);
extern Value *makeFloat(char *numericStr);
extern Value *makeString(char *str);
extern Value *makeBitString(char *str);
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 2


typedef enum QuerySource
{
 QSRC_ORIGINAL,
 QSRC_PARSER,
 QSRC_INSTEAD_RULE,
 QSRC_QUAL_INSTEAD_RULE,
 QSRC_NON_INSTEAD_RULE
} QuerySource;


typedef enum SortByDir
{
 SORTBY_DEFAULT,
 SORTBY_ASC,
 SORTBY_DESC,
 SORTBY_USING
} SortByDir;

typedef enum SortByNulls
{
 SORTBY_NULLS_DEFAULT,
 SORTBY_NULLS_FIRST,
 SORTBY_NULLS_LAST
} SortByNulls;
# 60 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef uint32 AclMode;
# 98 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct Query
{
 NodeTag type;

 CmdType commandType;

 QuerySource querySource;

 uint32 queryId;

 bool canSetTag;

 Node *utilityStmt;


 int resultRelation;


 bool hasAggs;
 bool hasWindowFuncs;
 bool hasSubLinks;
 bool hasDistinctOn;
 bool hasRecursive;
 bool hasModifyingCTE;
 bool hasForUpdate;

 List *cteList;

 List *rtable;
 FromExpr *jointree;

 List *targetList;

 List *returningList;

 List *groupClause;

 Node *havingQual;

 List *windowClause;

 List *distinctClause;

 List *sortClause;

 Node *limitOffset;
 Node *limitCount;

 List *rowMarks;

 Node *setOperations;


 List *constraintDeps;

} Query;
# 177 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct TypeName
{
 NodeTag type;
 List *names;
 Oid typeOid;
 bool setof;
 bool pct_type;
 List *typmods;
 int32 typemod;
 List *arrayBounds;
 int location;
} TypeName;
# 203 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ColumnRef
{
 NodeTag type;
 List *fields;
 int location;
} ColumnRef;




typedef struct ParamRef
{
 NodeTag type;
 int number;
 int location;
} ParamRef;




typedef enum A_Expr_Kind
{
 AEXPR_OP,
 AEXPR_AND,
 AEXPR_OR,
 AEXPR_NOT,
 AEXPR_OP_ANY,
 AEXPR_OP_ALL,
 AEXPR_DISTINCT,
 AEXPR_NULLIF,
 AEXPR_OF,
 AEXPR_IN
} A_Expr_Kind;

typedef struct A_Expr
{
 NodeTag type;
 A_Expr_Kind kind;
 List *name;
 Node *lexpr;
 Node *rexpr;
 int location;
} A_Expr;




typedef struct A_Const
{
 NodeTag type;
 Value val;
 int location;
} A_Const;




typedef struct TypeCast
{
 NodeTag type;
 Node *arg;
 TypeName *typeName;
 int location;
} TypeCast;




typedef struct CollateClause
{
 NodeTag type;
 Node *arg;
 List *collname;
 int location;
} CollateClause;
# 289 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct FuncCall
{
 NodeTag type;
 List *funcname;
 List *args;
 List *agg_order;
 bool agg_star;
 bool agg_distinct;
 bool func_variadic;
 struct WindowDef *over;
 int location;
} FuncCall;







typedef struct A_Star
{
 NodeTag type;
} A_Star;




typedef struct A_Indices
{
 NodeTag type;
 Node *lidx;
 Node *uidx;
} A_Indices;
# 338 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct A_Indirection
{
 NodeTag type;
 Node *arg;
 List *indirection;
} A_Indirection;




typedef struct A_ArrayExpr
{
 NodeTag type;
 List *elements;
 int location;
} A_ArrayExpr;
# 373 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ResTarget
{
 NodeTag type;
 char *name;
 List *indirection;
 Node *val;
 int location;
} ResTarget;




typedef struct SortBy
{
 NodeTag type;
 Node *node;
 SortByDir sortby_dir;
 SortByNulls sortby_nulls;
 List *useOp;
 int location;
} SortBy;
# 403 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct WindowDef
{
 NodeTag type;
 char *name;
 char *refname;
 List *partitionClause;
 List *orderClause;
 int frameOptions;
 Node *startOffset;
 Node *endOffset;
 int location;
} WindowDef;
# 451 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct RangeSubselect
{
 NodeTag type;
 Node *subquery;
 Alias *alias;
} RangeSubselect;




typedef struct RangeFunction
{
 NodeTag type;
 Node *funccallnode;
 Alias *alias;
 List *coldeflist;

} RangeFunction;
# 488 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ColumnDef
{
 NodeTag type;
 char *colname;
 TypeName *typeName;
 int inhcount;
 bool is_local;
 bool is_not_null;
 bool is_from_type;
 char storage;
 Node *raw_default;
 Node *cooked_default;
 CollateClause *collClause;
 Oid collOid;
 List *constraints;
 List *fdwoptions;
} ColumnDef;




typedef struct TableLikeClause
{
 NodeTag type;
 RangeVar *relation;
 bits32 options;
} TableLikeClause;

typedef enum TableLikeOption
{
 CREATE_TABLE_LIKE_DEFAULTS = 1 << 0,
 CREATE_TABLE_LIKE_CONSTRAINTS = 1 << 1,
 CREATE_TABLE_LIKE_INDEXES = 1 << 2,
 CREATE_TABLE_LIKE_STORAGE = 1 << 3,
 CREATE_TABLE_LIKE_COMMENTS = 1 << 4,
 CREATE_TABLE_LIKE_ALL = 0x7FFFFFFF
} TableLikeOption;
# 533 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct IndexElem
{
 NodeTag type;
 char *name;
 Node *expr;
 char *indexcolname;
 List *collation;
 List *opclass;
 SortByDir ordering;
 SortByNulls nulls_ordering;
} IndexElem;
# 555 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum DefElemAction
{
 DEFELEM_UNSPEC,
 DEFELEM_SET,
 DEFELEM_ADD,
 DEFELEM_DROP
} DefElemAction;

typedef struct DefElem
{
 NodeTag type;
 char *defnamespace;
 char *defname;
 Node *arg;
 DefElemAction defaction;
} DefElem;
# 580 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct LockingClause
{
 NodeTag type;
 List *lockedRels;
 bool forUpdate;
 bool noWait;
} LockingClause;




typedef struct XmlSerialize
{
 NodeTag type;
 XmlOptionType xmloption;
 Node *expr;
 TypeName *typeName;
 int location;
} XmlSerialize;
# 677 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum RTEKind
{
 RTE_RELATION,
 RTE_SUBQUERY,
 RTE_JOIN,
 RTE_FUNCTION,
 RTE_VALUES,
 RTE_CTE
} RTEKind;

typedef struct RangeTblEntry
{
 NodeTag type;

 RTEKind rtekind;
# 702 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 Oid relid;
 char relkind;




 Query *subquery;
 bool security_barrier;
# 722 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 JoinType jointype;
 List *joinaliasvars;
# 733 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 Node *funcexpr;
 List *funccoltypes;
 List *funccoltypmods;
 List *funccolcollations;




 List *values_lists;
 List *values_collations;




 char *ctename;
 Index ctelevelsup;
 bool self_reference;
 List *ctecoltypes;
 List *ctecoltypmods;
 List *ctecolcollations;




 Alias *alias;
 Alias *eref;
 bool inh;
 bool inFromCl;
 AclMode requiredPerms;
 Oid checkAsUser;
 Bitmapset *selectedCols;
 Bitmapset *modifiedCols;
} RangeTblEntry;
# 825 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct SortGroupClause
{
 NodeTag type;
 Index tleSortGroupRef;
 Oid eqop;
 Oid sortop;
 bool nulls_first;
 bool hashable;
} SortGroupClause;
# 849 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct WindowClause
{
 NodeTag type;
 char *name;
 char *refname;
 List *partitionClause;
 List *orderClause;
 int frameOptions;
 Node *startOffset;
 Node *endOffset;
 Index winref;
 bool copiedOrder;
} WindowClause;
# 875 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct RowMarkClause
{
 NodeTag type;
 Index rti;
 bool forUpdate;
 bool noWait;
 bool pushedDown;
} RowMarkClause;
# 891 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct WithClause
{
 NodeTag type;
 List *ctes;
 bool recursive;
 int location;
} WithClause;







typedef struct CommonTableExpr
{
 NodeTag type;
 char *ctename;
 List *aliascolnames;

 Node *ctequery;
 int location;

 bool cterecursive;
 int cterefcount;

 List *ctecolnames;
 List *ctecoltypes;
 List *ctecoltypmods;
 List *ctecolcollations;
} CommonTableExpr;
# 943 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct InsertStmt
{
 NodeTag type;
 RangeVar *relation;
 List *cols;
 Node *selectStmt;
 List *returningList;
 WithClause *withClause;
} InsertStmt;





typedef struct DeleteStmt
{
 NodeTag type;
 RangeVar *relation;
 List *usingClause;
 Node *whereClause;
 List *returningList;
 WithClause *withClause;
} DeleteStmt;





typedef struct UpdateStmt
{
 NodeTag type;
 RangeVar *relation;
 List *targetList;
 Node *whereClause;
 List *fromClause;
 List *returningList;
 WithClause *withClause;
} UpdateStmt;
# 995 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum SetOperation
{
 SETOP_NONE = 0,
 SETOP_UNION,
 SETOP_INTERSECT,
 SETOP_EXCEPT
} SetOperation;

typedef struct SelectStmt
{
 NodeTag type;




 List *distinctClause;

 IntoClause *intoClause;
 List *targetList;
 List *fromClause;
 Node *whereClause;
 List *groupClause;
 Node *havingClause;
 List *windowClause;
 WithClause *withClause;
# 1029 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 List *valuesLists;





 List *sortClause;
 Node *limitOffset;
 Node *limitCount;
 List *lockingClause;




 SetOperation op;
 bool all;
 struct SelectStmt *larg;
 struct SelectStmt *rarg;

} SelectStmt;
# 1070 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct SetOperationStmt
{
 NodeTag type;
 SetOperation op;
 bool all;
 Node *larg;
 Node *rarg;



 List *colTypes;
 List *colTypmods;
 List *colCollations;
 List *groupClauses;

} SetOperationStmt;
# 1105 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum ObjectType
{
 OBJECT_AGGREGATE,
 OBJECT_ATTRIBUTE,
 OBJECT_CAST,
 OBJECT_COLUMN,
 OBJECT_CONSTRAINT,
 OBJECT_COLLATION,
 OBJECT_CONVERSION,
 OBJECT_DATABASE,
 OBJECT_DOMAIN,
 OBJECT_EXTENSION,
 OBJECT_FDW,
 OBJECT_FOREIGN_SERVER,
 OBJECT_FOREIGN_TABLE,
 OBJECT_FUNCTION,
 OBJECT_INDEX,
 OBJECT_LANGUAGE,
 OBJECT_LARGEOBJECT,
 OBJECT_OPCLASS,
 OBJECT_OPERATOR,
 OBJECT_OPFAMILY,
 OBJECT_ROLE,
 OBJECT_RULE,
 OBJECT_SCHEMA,
 OBJECT_SEQUENCE,
 OBJECT_TABLE,
 OBJECT_TABLESPACE,
 OBJECT_TRIGGER,
 OBJECT_TSCONFIGURATION,
 OBJECT_TSDICTIONARY,
 OBJECT_TSPARSER,
 OBJECT_TSTEMPLATE,
 OBJECT_TYPE,
 OBJECT_VIEW
} ObjectType;
# 1150 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CreateSchemaStmt
{
 NodeTag type;
 char *schemaname;
 char *authid;
 List *schemaElts;
} CreateSchemaStmt;

typedef enum DropBehavior
{
 DROP_RESTRICT,
 DROP_CASCADE
} DropBehavior;





typedef struct AlterTableStmt
{
 NodeTag type;
 RangeVar *relation;
 List *cmds;
 ObjectType relkind;
 bool missing_ok;
} AlterTableStmt;

typedef enum AlterTableType
{
 AT_AddColumn,
 AT_AddColumnRecurse,
 AT_AddColumnToView,
 AT_ColumnDefault,
 AT_DropNotNull,
 AT_SetNotNull,
 AT_SetStatistics,
 AT_SetOptions,
 AT_ResetOptions,
 AT_SetStorage,
 AT_DropColumn,
 AT_DropColumnRecurse,
 AT_AddIndex,
 AT_ReAddIndex,
 AT_AddConstraint,
 AT_AddConstraintRecurse,
 AT_ValidateConstraint,
 AT_ValidateConstraintRecurse,
 AT_ProcessedConstraint,

 AT_AddIndexConstraint,
 AT_DropConstraint,
 AT_DropConstraintRecurse,
 AT_AlterColumnType,
 AT_AlterColumnGenericOptions,
 AT_ChangeOwner,
 AT_ClusterOn,
 AT_DropCluster,
 AT_AddOids,
 AT_AddOidsRecurse,
 AT_DropOids,
 AT_SetTableSpace,
 AT_SetRelOptions,
 AT_ResetRelOptions,
 AT_ReplaceRelOptions,
 AT_EnableTrig,
 AT_EnableAlwaysTrig,
 AT_EnableReplicaTrig,
 AT_DisableTrig,
 AT_EnableTrigAll,
 AT_DisableTrigAll,
 AT_EnableTrigUser,
 AT_DisableTrigUser,
 AT_EnableRule,
 AT_EnableAlwaysRule,
 AT_EnableReplicaRule,
 AT_DisableRule,
 AT_AddInherit,
 AT_DropInherit,
 AT_AddOf,
 AT_DropOf,
 AT_GenericOptions,

 AT_ReAddConstraint
} AlterTableType;

typedef struct AlterTableCmd
{
 NodeTag type;
 AlterTableType subtype;
 char *name;

 Node *def;

 DropBehavior behavior;
 bool missing_ok;
} AlterTableCmd;
# 1255 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct AlterDomainStmt
{
 NodeTag type;
 char subtype;







 List *typeName;
 char *name;
 Node *def;
 DropBehavior behavior;
 bool missing_ok;
} AlterDomainStmt;






typedef enum GrantTargetType
{
 ACL_TARGET_OBJECT,
 ACL_TARGET_ALL_IN_SCHEMA,
 ACL_TARGET_DEFAULTS
} GrantTargetType;

typedef enum GrantObjectType
{
 ACL_OBJECT_COLUMN,
 ACL_OBJECT_RELATION,
 ACL_OBJECT_SEQUENCE,
 ACL_OBJECT_DATABASE,
 ACL_OBJECT_DOMAIN,
 ACL_OBJECT_FDW,
 ACL_OBJECT_FOREIGN_SERVER,
 ACL_OBJECT_FUNCTION,
 ACL_OBJECT_LANGUAGE,
 ACL_OBJECT_LARGEOBJECT,
 ACL_OBJECT_NAMESPACE,
 ACL_OBJECT_TABLESPACE,
 ACL_OBJECT_TYPE
} GrantObjectType;

typedef struct GrantStmt
{
 NodeTag type;
 bool is_grant;
 GrantTargetType targtype;
 GrantObjectType objtype;
 List *objects;

 List *privileges;

 List *grantees;
 bool grant_option;
 DropBehavior behavior;
} GrantStmt;

typedef struct PrivGrantee
{
 NodeTag type;
 char *rolname;
} PrivGrantee;






typedef struct FuncWithArgs
{
 NodeTag type;
 List *funcname;
 List *funcargs;
} FuncWithArgs;
# 1342 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct AccessPriv
{
 NodeTag type;
 char *priv_name;
 List *cols;
} AccessPriv;
# 1358 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct GrantRoleStmt
{
 NodeTag type;
 List *granted_roles;
 List *grantee_roles;
 bool is_grant;
 bool admin_opt;
 char *grantor;
 DropBehavior behavior;
} GrantRoleStmt;





typedef struct AlterDefaultPrivilegesStmt
{
 NodeTag type;
 List *options;
 GrantStmt *action;
} AlterDefaultPrivilegesStmt;
# 1388 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CopyStmt
{
 NodeTag type;
 RangeVar *relation;
 Node *query;
 List *attlist;

 bool is_from;
 char *filename;
 List *options;
} CopyStmt;
# 1407 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum
{
 VAR_SET_VALUE,
 VAR_SET_DEFAULT,
 VAR_SET_CURRENT,
 VAR_SET_MULTI,
 VAR_RESET,
 VAR_RESET_ALL
} VariableSetKind;

typedef struct VariableSetStmt
{
 NodeTag type;
 VariableSetKind kind;
 char *name;
 List *args;
 bool is_local;
} VariableSetStmt;





typedef struct VariableShowStmt
{
 NodeTag type;
 char *name;
} VariableShowStmt;
# 1447 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CreateStmt
{
 NodeTag type;
 RangeVar *relation;
 List *tableElts;
 List *inhRelations;

 TypeName *ofTypename;
 List *constraints;
 List *options;
 OnCommitAction oncommit;
 char *tablespacename;
 bool if_not_exists;
} CreateStmt;
# 1493 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum ConstrType
{
 CONSTR_NULL,
 CONSTR_NOTNULL,
 CONSTR_DEFAULT,
 CONSTR_CHECK,
 CONSTR_PRIMARY,
 CONSTR_UNIQUE,
 CONSTR_EXCLUSION,
 CONSTR_FOREIGN,
 CONSTR_ATTR_DEFERRABLE,
 CONSTR_ATTR_NOT_DEFERRABLE,
 CONSTR_ATTR_DEFERRED,
 CONSTR_ATTR_IMMEDIATE
} ConstrType;
# 1521 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct Constraint
{
 NodeTag type;
 ConstrType contype;


 char *conname;
 bool deferrable;
 bool initdeferred;
 int location;


 bool is_no_inherit;
 Node *raw_expr;
 char *cooked_expr;


 List *keys;


 List *exclusions;


 List *options;
 char *indexname;
 char *indexspace;

 char *access_method;
 Node *where_clause;


 RangeVar *pktable;
 List *fk_attrs;
 List *pk_attrs;
 char fk_matchtype;
 char fk_upd_action;
 char fk_del_action;
 List *old_conpfeqop;


 bool skip_validation;
 bool initially_valid;
} Constraint;






typedef struct CreateTableSpaceStmt
{
 NodeTag type;
 char *tablespacename;
 char *owner;
 char *location;
} CreateTableSpaceStmt;

typedef struct DropTableSpaceStmt
{
 NodeTag type;
 char *tablespacename;
 bool missing_ok;
} DropTableSpaceStmt;

typedef struct AlterTableSpaceOptionsStmt
{
 NodeTag type;
 char *tablespacename;
 List *options;
 bool isReset;
} AlterTableSpaceOptionsStmt;






typedef struct CreateExtensionStmt
{
 NodeTag type;
 char *extname;
 bool if_not_exists;
 List *options;
} CreateExtensionStmt;


typedef struct AlterExtensionStmt
{
 NodeTag type;
 char *extname;
 List *options;
} AlterExtensionStmt;

typedef struct AlterExtensionContentsStmt
{
 NodeTag type;
 char *extname;
 int action;
 ObjectType objtype;
 List *objname;
 List *objargs;
} AlterExtensionContentsStmt;






typedef struct CreateFdwStmt
{
 NodeTag type;
 char *fdwname;
 List *func_options;
 List *options;
} CreateFdwStmt;

typedef struct AlterFdwStmt
{
 NodeTag type;
 char *fdwname;
 List *func_options;
 List *options;
} AlterFdwStmt;






typedef struct CreateForeignServerStmt
{
 NodeTag type;
 char *servername;
 char *servertype;
 char *version;
 char *fdwname;
 List *options;
} CreateForeignServerStmt;

typedef struct AlterForeignServerStmt
{
 NodeTag type;
 char *servername;
 char *version;
 List *options;
 bool has_version;
} AlterForeignServerStmt;






typedef struct CreateForeignTableStmt
{
 CreateStmt base;
 char *servername;
 List *options;
} CreateForeignTableStmt;






typedef struct CreateUserMappingStmt
{
 NodeTag type;
 char *username;
 char *servername;
 List *options;
} CreateUserMappingStmt;

typedef struct AlterUserMappingStmt
{
 NodeTag type;
 char *username;
 char *servername;
 List *options;
} AlterUserMappingStmt;

typedef struct DropUserMappingStmt
{
 NodeTag type;
 char *username;
 char *servername;
 bool missing_ok;
} DropUserMappingStmt;





typedef struct CreateTrigStmt
{
 NodeTag type;
 char *trigname;
 RangeVar *relation;
 List *funcname;
 List *args;
 bool row;

 int16 timing;

 int16 events;
 List *columns;
 Node *whenClause;
 bool isconstraint;

 bool deferrable;
 bool initdeferred;
 RangeVar *constrrel;
} CreateTrigStmt;





typedef struct CreatePLangStmt
{
 NodeTag type;
 bool replace;
 char *plname;
 List *plhandler;
 List *plinline;
 List *plvalidator;
 bool pltrusted;
} CreatePLangStmt;
# 1759 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum RoleStmtType
{
 ROLESTMT_ROLE,
 ROLESTMT_USER,
 ROLESTMT_GROUP
} RoleStmtType;

typedef struct CreateRoleStmt
{
 NodeTag type;
 RoleStmtType stmt_type;
 char *role;
 List *options;
} CreateRoleStmt;

typedef struct AlterRoleStmt
{
 NodeTag type;
 char *role;
 List *options;
 int action;
} AlterRoleStmt;

typedef struct AlterRoleSetStmt
{
 NodeTag type;
 char *role;
 char *database;
 VariableSetStmt *setstmt;
} AlterRoleSetStmt;

typedef struct DropRoleStmt
{
 NodeTag type;
 List *roles;
 bool missing_ok;
} DropRoleStmt;






typedef struct CreateSeqStmt
{
 NodeTag type;
 RangeVar *sequence;
 List *options;
 Oid ownerId;
} CreateSeqStmt;

typedef struct AlterSeqStmt
{
 NodeTag type;
 RangeVar *sequence;
 List *options;
 bool missing_ok;
} AlterSeqStmt;





typedef struct DefineStmt
{
 NodeTag type;
 ObjectType kind;
 bool oldstyle;
 List *defnames;
 List *args;
 List *definition;
} DefineStmt;





typedef struct CreateDomainStmt
{
 NodeTag type;
 List *domainname;
 TypeName *typeName;
 CollateClause *collClause;
 List *constraints;
} CreateDomainStmt;





typedef struct CreateOpClassStmt
{
 NodeTag type;
 List *opclassname;
 List *opfamilyname;
 char *amname;
 TypeName *datatype;
 List *items;
 bool isDefault;
} CreateOpClassStmt;





typedef struct CreateOpClassItem
{
 NodeTag type;
 int itemtype;

 List *name;
 List *args;
 int number;
 List *order_family;
 List *class_args;

 TypeName *storedtype;
} CreateOpClassItem;





typedef struct CreateOpFamilyStmt
{
 NodeTag type;
 List *opfamilyname;
 char *amname;
} CreateOpFamilyStmt;





typedef struct AlterOpFamilyStmt
{
 NodeTag type;
 List *opfamilyname;
 char *amname;
 bool isDrop;
 List *items;
} AlterOpFamilyStmt;






typedef struct DropStmt
{
 NodeTag type;
 List *objects;
 List *arguments;
 ObjectType removeType;
 DropBehavior behavior;
 bool missing_ok;
 bool concurrent;
} DropStmt;





typedef struct TruncateStmt
{
 NodeTag type;
 List *relations;
 bool restart_seqs;
 DropBehavior behavior;
} TruncateStmt;





typedef struct CommentStmt
{
 NodeTag type;
 ObjectType objtype;
 List *objname;
 List *objargs;
 char *comment;
} CommentStmt;





typedef struct SecLabelStmt
{
 NodeTag type;
 ObjectType objtype;
 List *objname;
 List *objargs;
 char *provider;
 char *label;
} SecLabelStmt;
# 1975 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct DeclareCursorStmt
{
 NodeTag type;
 char *portalname;
 int options;
 Node *query;
} DeclareCursorStmt;





typedef struct ClosePortalStmt
{
 NodeTag type;
 char *portalname;

} ClosePortalStmt;





typedef enum FetchDirection
{

 FETCH_FORWARD,
 FETCH_BACKWARD,

 FETCH_ABSOLUTE,
 FETCH_RELATIVE
} FetchDirection;



typedef struct FetchStmt
{
 NodeTag type;
 FetchDirection direction;
 long howMany;
 char *portalname;
 bool ismove;
} FetchStmt;
# 2030 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct IndexStmt
{
 NodeTag type;
 char *idxname;
 RangeVar *relation;
 char *accessMethod;
 char *tableSpace;
 List *indexParams;
 List *options;
 Node *whereClause;
 List *excludeOpNames;
 char *idxcomment;
 Oid indexOid;
 Oid oldNode;
 bool unique;
 bool primary;
 bool isconstraint;
 bool deferrable;
 bool initdeferred;
 bool concurrent;
} IndexStmt;





typedef struct CreateFunctionStmt
{
 NodeTag type;
 bool replace;
 List *funcname;
 List *parameters;
 TypeName *returnType;
 List *options;
 List *withClause;
} CreateFunctionStmt;

typedef enum FunctionParameterMode
{

 FUNC_PARAM_IN = 'i',
 FUNC_PARAM_OUT = 'o',
 FUNC_PARAM_INOUT = 'b',
 FUNC_PARAM_VARIADIC = 'v',
 FUNC_PARAM_TABLE = 't'
} FunctionParameterMode;

typedef struct FunctionParameter
{
 NodeTag type;
 char *name;
 TypeName *argType;
 FunctionParameterMode mode;
 Node *defexpr;
} FunctionParameter;

typedef struct AlterFunctionStmt
{
 NodeTag type;
 FuncWithArgs *func;
 List *actions;
} AlterFunctionStmt;







typedef struct DoStmt
{
 NodeTag type;
 List *args;
} DoStmt;

typedef struct InlineCodeBlock
{
 NodeTag type;
 char *source_text;
 Oid langOid;
 bool langIsTrusted;
} InlineCodeBlock;





typedef struct RenameStmt
{
 NodeTag type;
 ObjectType renameType;
 ObjectType relationType;
 RangeVar *relation;
 List *object;
 List *objarg;
 char *subname;

 char *newname;
 DropBehavior behavior;
 bool missing_ok;
} RenameStmt;





typedef struct AlterObjectSchemaStmt
{
 NodeTag type;
 ObjectType objectType;
 RangeVar *relation;
 List *object;
 List *objarg;
 char *addname;
 char *newschema;
 bool missing_ok;
} AlterObjectSchemaStmt;





typedef struct AlterOwnerStmt
{
 NodeTag type;
 ObjectType objectType;
 RangeVar *relation;
 List *object;
 List *objarg;
 char *addname;
 char *newowner;
} AlterOwnerStmt;






typedef struct RuleStmt
{
 NodeTag type;
 RangeVar *relation;
 char *rulename;
 Node *whereClause;
 CmdType event;
 bool instead;
 List *actions;
 bool replace;
} RuleStmt;





typedef struct NotifyStmt
{
 NodeTag type;
 char *conditionname;
 char *payload;
} NotifyStmt;





typedef struct ListenStmt
{
 NodeTag type;
 char *conditionname;
} ListenStmt;





typedef struct UnlistenStmt
{
 NodeTag type;
 char *conditionname;
} UnlistenStmt;





typedef enum TransactionStmtKind
{
 TRANS_STMT_BEGIN,
 TRANS_STMT_START,
 TRANS_STMT_COMMIT,
 TRANS_STMT_ROLLBACK,
 TRANS_STMT_SAVEPOINT,
 TRANS_STMT_RELEASE,
 TRANS_STMT_ROLLBACK_TO,
 TRANS_STMT_PREPARE,
 TRANS_STMT_COMMIT_PREPARED,
 TRANS_STMT_ROLLBACK_PREPARED
} TransactionStmtKind;

typedef struct TransactionStmt
{
 NodeTag type;
 TransactionStmtKind kind;
 List *options;
 char *gid;
} TransactionStmt;





typedef struct CompositeTypeStmt
{
 NodeTag type;
 RangeVar *typevar;
 List *coldeflist;
} CompositeTypeStmt;





typedef struct CreateEnumStmt
{
 NodeTag type;
 List *typeName;
 List *vals;
} CreateEnumStmt;





typedef struct CreateRangeStmt
{
 NodeTag type;
 List *typeName;
 List *params;
} CreateRangeStmt;





typedef struct AlterEnumStmt
{
 NodeTag type;
 List *typeName;
 char *newVal;
 char *newValNeighbor;
 bool newValIsAfter;
} AlterEnumStmt;





typedef struct ViewStmt
{
 NodeTag type;
 RangeVar *view;
 List *aliases;
 Node *query;
 bool replace;
 List *options;
} ViewStmt;





typedef struct LoadStmt
{
 NodeTag type;
 char *filename;
} LoadStmt;





typedef struct CreatedbStmt
{
 NodeTag type;
 char *dbname;
 List *options;
} CreatedbStmt;





typedef struct AlterDatabaseStmt
{
 NodeTag type;
 char *dbname;
 List *options;
} AlterDatabaseStmt;

typedef struct AlterDatabaseSetStmt
{
 NodeTag type;
 char *dbname;
 VariableSetStmt *setstmt;
} AlterDatabaseSetStmt;





typedef struct DropdbStmt
{
 NodeTag type;
 char *dbname;
 bool missing_ok;
} DropdbStmt;





typedef struct ClusterStmt
{
 NodeTag type;
 RangeVar *relation;
 char *indexname;
 bool verbose;
} ClusterStmt;
# 2369 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum VacuumOption
{
 VACOPT_VACUUM = 1 << 0,
 VACOPT_ANALYZE = 1 << 1,
 VACOPT_VERBOSE = 1 << 2,
 VACOPT_FREEZE = 1 << 3,
 VACOPT_FULL = 1 << 4,
 VACOPT_NOWAIT = 1 << 5
} VacuumOption;

typedef struct VacuumStmt
{
 NodeTag type;
 int options;
 int freeze_min_age;
 int freeze_table_age;
 RangeVar *relation;
 List *va_cols;
} VacuumStmt;
# 2397 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ExplainStmt
{
 NodeTag type;
 Node *query;
 List *options;
} ExplainStmt;
# 2415 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CreateTableAsStmt
{
 NodeTag type;
 Node *query;
 IntoClause *into;
 bool is_select_into;
} CreateTableAsStmt;





typedef struct CheckPointStmt
{
 NodeTag type;
} CheckPointStmt;






typedef enum DiscardMode
{
 DISCARD_ALL,
 DISCARD_PLANS,
 DISCARD_TEMP
} DiscardMode;

typedef struct DiscardStmt
{
 NodeTag type;
 DiscardMode target;
} DiscardStmt;





typedef struct LockStmt
{
 NodeTag type;
 List *relations;
 int mode;
 bool nowait;
} LockStmt;





typedef struct ConstraintsSetStmt
{
 NodeTag type;
 List *constraints;
 bool deferred;
} ConstraintsSetStmt;





typedef struct ReindexStmt
{
 NodeTag type;
 ObjectType kind;
 RangeVar *relation;
 const char *name;
 bool do_system;
 bool do_user;
} ReindexStmt;





typedef struct CreateConversionStmt
{
 NodeTag type;
 List *conversion_name;
 char *for_encoding_name;
 char *to_encoding_name;
 List *func_name;
 bool def;
} CreateConversionStmt;





typedef struct CreateCastStmt
{
 NodeTag type;
 TypeName *sourcetype;
 TypeName *targettype;
 FuncWithArgs *func;
 CoercionContext context;
 bool inout;
} CreateCastStmt;





typedef struct PrepareStmt
{
 NodeTag type;
 char *name;
 List *argtypes;
 Node *query;
} PrepareStmt;







typedef struct ExecuteStmt
{
 NodeTag type;
 char *name;
 List *params;
} ExecuteStmt;






typedef struct DeallocateStmt
{
 NodeTag type;
 char *name;

} DeallocateStmt;




typedef struct DropOwnedStmt
{
 NodeTag type;
 List *roles;
 DropBehavior behavior;
} DropOwnedStmt;




typedef struct ReassignOwnedStmt
{
 NodeTag type;
 List *roles;
 char *newrole;
} ReassignOwnedStmt;




typedef struct AlterTSDictionaryStmt
{
 NodeTag type;
 List *dictname;
 List *options;
} AlterTSDictionaryStmt;




typedef struct AlterTSConfigurationStmt
{
 NodeTag type;
 List *cfgname;





 List *tokentype;
 List *dicts;
 bool override;
 bool replace;
 bool missing_ok;
} AlterTSConfigurationStmt;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/trigger.h" 2
# 27 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/trigger.h"
typedef uint32 TriggerEvent;

typedef struct TriggerData
{
 NodeTag type;
 TriggerEvent tg_event;
 Relation tg_relation;
 HeapTuple tg_trigtuple;
 HeapTuple tg_newtuple;
 Trigger *tg_trigger;
 Buffer tg_trigtuplebuf;
 Buffer tg_newtuplebuf;
} TriggerData;
# 100 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/trigger.h"
extern int SessionReplicationRole;
# 111 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/trigger.h"
extern Oid CreateTrigger(CreateTrigStmt *stmt, const char *queryString,
     Oid constraintOid, Oid indexOid,
     bool isInternal);

extern void RemoveTriggerById(Oid trigOid);
extern Oid get_trigger_oid(Oid relid, const char *name, bool missing_ok);

extern void renametrig(RenameStmt *stmt);

extern void EnableDisableTrigger(Relation rel, const char *tgname,
      char fires_when, bool skip_system);

extern void RelationBuildTriggers(Relation relation);

extern TriggerDesc *CopyTriggerDesc(TriggerDesc *trigdesc);

extern void FreeTriggerDesc(TriggerDesc *trigdesc);

extern void ExecBSInsertTriggers(EState *estate,
      ResultRelInfo *relinfo);
extern void ExecASInsertTriggers(EState *estate,
      ResultRelInfo *relinfo);
extern TupleTableSlot *ExecBRInsertTriggers(EState *estate,
      ResultRelInfo *relinfo,
      TupleTableSlot *slot);
extern void ExecARInsertTriggers(EState *estate,
      ResultRelInfo *relinfo,
      HeapTuple trigtuple,
      List *recheckIndexes);
extern TupleTableSlot *ExecIRInsertTriggers(EState *estate,
      ResultRelInfo *relinfo,
      TupleTableSlot *slot);
extern void ExecBSDeleteTriggers(EState *estate,
      ResultRelInfo *relinfo);
extern void ExecASDeleteTriggers(EState *estate,
      ResultRelInfo *relinfo);
extern bool ExecBRDeleteTriggers(EState *estate,
      EPQState *epqstate,
      ResultRelInfo *relinfo,
      ItemPointer tupleid);
extern void ExecARDeleteTriggers(EState *estate,
      ResultRelInfo *relinfo,
      ItemPointer tupleid);
extern bool ExecIRDeleteTriggers(EState *estate,
      ResultRelInfo *relinfo,
      HeapTuple trigtuple);
extern void ExecBSUpdateTriggers(EState *estate,
      ResultRelInfo *relinfo);
extern void ExecASUpdateTriggers(EState *estate,
      ResultRelInfo *relinfo);
extern TupleTableSlot *ExecBRUpdateTriggers(EState *estate,
      EPQState *epqstate,
      ResultRelInfo *relinfo,
      ItemPointer tupleid,
      TupleTableSlot *slot);
extern void ExecARUpdateTriggers(EState *estate,
      ResultRelInfo *relinfo,
      ItemPointer tupleid,
      HeapTuple newtuple,
      List *recheckIndexes);
extern TupleTableSlot *ExecIRUpdateTriggers(EState *estate,
      ResultRelInfo *relinfo,
      HeapTuple trigtuple,
      TupleTableSlot *slot);
extern void ExecBSTruncateTriggers(EState *estate,
        ResultRelInfo *relinfo);
extern void ExecASTruncateTriggers(EState *estate,
        ResultRelInfo *relinfo);

extern void AfterTriggerBeginXact(void);
extern void AfterTriggerBeginQuery(void);
extern void AfterTriggerEndQuery(EState *estate);
extern void AfterTriggerFireDeferred(void);
extern void AfterTriggerEndXact(bool isCommit);
extern void AfterTriggerBeginSubXact(void);
extern void AfterTriggerEndSubXact(bool isCommit);
extern void AfterTriggerSetState(ConstraintsSetStmt *stmt);
extern bool AfterTriggerPendingOnRel(Oid relid);





extern bool RI_FKey_keyequal_upd_pk(Trigger *trigger, Relation pk_rel,
      HeapTuple old_row, HeapTuple new_row);
extern bool RI_FKey_keyequal_upd_fk(Trigger *trigger, Relation fk_rel,
      HeapTuple old_row, HeapTuple new_row);
extern bool RI_Initial_Check(Trigger *trigger,
     Relation fk_rel, Relation pk_rel);






extern int RI_FKey_trigger_type(Oid tgfoid);

extern Datum pg_trigger_depth(FunctionCallInfo fcinfo);
# 25 "pltcl.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/spi.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/spi.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/spi.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/portal.h" 1
# 49 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/portal.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h" 1
# 50 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/portal.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/execdesc.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/execdesc.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/execdesc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h" 1
# 70 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 1
# 71 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h" 2
# 86 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h"
typedef enum
{
 DestNone,
 DestDebug,
 DestRemote,
 DestRemoteExecute,
 DestSPI,
 DestTuplestore,
 DestIntoRel,
 DestCopyOut,
 DestSQLFunction
} CommandDest;
# 108 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h"
typedef struct _DestReceiver DestReceiver;

struct _DestReceiver
{

 void (*receiveSlot) (TupleTableSlot *slot,
           DestReceiver *self);

 void (*rStartup) (DestReceiver *self,
           int operation,
           TupleDesc typeinfo);
 void (*rShutdown) (DestReceiver *self);

 void (*rDestroy) (DestReceiver *self);

 CommandDest mydest;

};

extern DestReceiver *None_Receiver;



extern void BeginCommand(const char *commandTag, CommandDest dest);
extern DestReceiver *CreateDestReceiver(CommandDest dest);
extern void EndCommand(const char *commandTag, CommandDest dest);



extern void NullCommand(CommandDest dest);
extern void ReadyForQuery(CommandDest dest);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/execdesc.h" 2
# 33 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/execdesc.h"
typedef struct QueryDesc
{

 CmdType operation;
 PlannedStmt *plannedstmt;
 Node *utilitystmt;
 const char *sourceText;
 Snapshot snapshot;
 Snapshot crosscheck_snapshot;
 DestReceiver *dest;
 ParamListInfo params;
 int instrument_options;


 TupleDesc tupDesc;
 EState *estate;
 PlanState *planstate;


 struct Instrumentation *totaltime;
} QueryDesc;


extern QueryDesc *CreateQueryDesc(PlannedStmt *plannedstmt,
    const char *sourceText,
    Snapshot snapshot,
    Snapshot crosscheck_snapshot,
    DestReceiver *dest,
    ParamListInfo params,
    int instrument_options);

extern QueryDesc *CreateUtilityQueryDesc(Node *utilitystmt,
        const char *sourceText,
        Snapshot snapshot,
        DestReceiver *dest,
        ParamListInfo params);

extern void FreeQueryDesc(QueryDesc *qdesc);
# 51 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/portal.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/resowner.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/resowner.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/fd.h" 1
# 41 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/fd.h"
# 1 "./dirent.h" 1
# 9 "./dirent.h"
struct dirent
{
 long d_ino;
 unsigned short d_reclen;
 unsigned short d_namlen;
 char d_name[MAX_PATH];
};

typedef struct DIR DIR;

DIR *opendir(const char *);
struct dirent *readdir(DIR *);
int closedir(DIR *);
# 42 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/fd.h" 2






typedef char *FileName;

typedef int File;



extern int max_files_per_process;




extern int max_safe_fds;







extern File PathNameOpenFile(FileName fileName, int fileFlags, int fileMode);
extern File OpenTemporaryFile(bool interXact);
extern void FileClose(File file);
extern int FilePrefetch(File file, off_t offset, int amount);
extern int FileRead(File file, char *buffer, int amount);
extern int FileWrite(File file, char *buffer, int amount);
extern int FileSync(File file);
extern off_t FileSeek(File file, off_t offset, int whence);
extern int FileTruncate(File file, off_t offset);
extern char *FilePathName(File file);


extern FILE *AllocateFile(const char *name, const char *mode);
extern int FreeFile(FILE *file);


extern DIR *AllocateDir(const char *dirname);
extern struct dirent *ReadDir(DIR *dir, const char *dirname);
extern int FreeDir(DIR *dir);


extern int BasicOpenFile(FileName fileName, int fileFlags, int fileMode);


extern void InitFileAccess(void);
extern void set_max_safe_fds(void);
extern void closeAllVfds(void);
extern void SetTempTablespaces(Oid *tableSpaces, int numSpaces);
extern bool TempTablespacesAreSet(void);
extern Oid GetNextTempTableSpace(void);
extern void AtEOXact_Files(void);
extern void AtEOSubXact_Files(bool isCommit, SubTransactionId mySubid,
      SubTransactionId parentSubid);
extern void RemovePgTempFiles(void);

extern int pg_fsync(int fd);
extern int pg_fsync_no_writethrough(int fd);
extern int pg_fsync_writethrough(int fd);
extern int pg_fdatasync(int fd);
extern int pg_flush_data(int fd, off_t offset, off_t amount);
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/resowner.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/skey.h" 1
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/dllist.h" 1
# 45 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/dllist.h"
struct Dllist;
struct Dlelem;

typedef struct Dlelem
{
 struct Dlelem *dle_next;
 struct Dlelem *dle_prev;
 void *dle_val;
 struct Dllist *dle_list;
} Dlelem;

typedef struct Dllist
{
 Dlelem *dll_head;
 Dlelem *dll_tail;
} Dllist;

extern Dllist *DLNewList(void);
extern void DLInitList(Dllist *list);
extern void DLFreeList(Dllist *list);

extern Dlelem *DLNewElem(void *val);
extern void DLInitElem(Dlelem *e, void *val);
extern void DLFreeElem(Dlelem *e);
extern void DLRemove(Dlelem *e);
extern void DLAddHead(Dllist *list, Dlelem *node);
extern void DLAddTail(Dllist *list, Dlelem *node);
extern Dlelem *DLRemHead(Dllist *list);
extern Dlelem *DLRemTail(Dllist *list);
extern void DLMoveToFront(Dlelem *e);
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h" 1
# 27 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h" 2
# 37 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h"
typedef struct catcache
{
 int id;
 struct catcache *cc_next;
 const char *cc_relname;
 Oid cc_reloid;
 Oid cc_indexoid;
 bool cc_relisshared;
 TupleDesc cc_tupdesc;
 int cc_ntup;
 int cc_nbuckets;
 int cc_nkeys;
 int cc_key[4];
 PGFunction cc_hashfunc[4];
 ScanKeyData cc_skey[4];

 bool cc_isname[4];
 Dllist cc_lists;
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h"
 Dllist cc_bucket[1];
} CatCache;


typedef struct catctup
{
 int ct_magic;

 CatCache *my_cache;






 Dlelem cache_elem;
# 93 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h"
 struct catclist *c_list;
# 107 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h"
 int refcount;
 bool dead;
 bool negative;
 uint32 hash_value;
 HeapTupleData tuple;
} CatCTup;


typedef struct catclist
{
 int cl_magic;

 CatCache *my_cache;
# 142 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h"
 Dlelem cache_elem;
 int refcount;
 bool dead;
 bool ordered;
 short nkeys;
 uint32 hash_value;
 HeapTupleData tuple;
 int n_members;
 CatCTup *members[1];
} CatCList;


typedef struct catcacheheader
{
 CatCache *ch_caches;
 int ch_ntup;
} CatCacheHeader;



extern MemoryContext CacheMemoryContext;

extern void CreateCacheMemoryContext(void);
extern void AtEOXact_CatCache(bool isCommit);

extern CatCache *InitCatCache(int id, Oid reloid, Oid indexoid,
    int nkeys, const int *key,
    int nbuckets);
extern void InitCatCachePhase2(CatCache *cache, bool touch_index);

extern HeapTuple SearchCatCache(CatCache *cache,
      Datum v1, Datum v2,
      Datum v3, Datum v4);
extern void ReleaseCatCache(HeapTuple tuple);

extern uint32 GetCatCacheHashValue(CatCache *cache,
      Datum v1, Datum v2,
      Datum v3, Datum v4);

extern CatCList *SearchCatCacheList(CatCache *cache, int nkeys,
       Datum v1, Datum v2,
       Datum v3, Datum v4);
extern void ReleaseCatCacheList(CatCList *list);

extern void ResetCatalogCaches(void);
extern void CatalogCacheFlushCatalog(Oid catId);
extern void CatalogCacheIdInvalidate(int cacheId, uint32 hashValue);
extern void PrepareToInvalidateCacheTuple(Relation relation,
         HeapTuple tuple,
         HeapTuple newtuple,
         void (*function) (int, uint32, Oid));

extern void PrintCatCacheLeakWarning(HeapTuple tuple);
extern void PrintCatCacheListLeakWarning(CatCList *list);
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/resowner.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/plancache.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/plancache.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/params.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/plancache.h" 2
# 76 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/plancache.h"
typedef struct CachedPlanSource
{
 int magic;
 Node *raw_parse_tree;
 const char *query_string;
 const char *commandTag;
 Oid *param_types;
 int num_params;
 ParserSetupHook parserSetup;
 void *parserSetupArg;
 int cursor_options;
 bool fixed_result;
 TupleDesc resultDesc;
 struct OverrideSearchPath *search_path;
 MemoryContext context;

 List *query_list;
 List *relationOids;
 List *invalItems;
 MemoryContext query_context;

 struct CachedPlan *gplan;

 bool is_complete;
 bool is_saved;
 bool is_valid;
 bool is_oneshot;
 int generation;

 struct CachedPlanSource *next_saved;

 double generic_cost;
 double total_custom_cost;
 int num_custom_plans;
} CachedPlanSource;
# 122 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/plancache.h"
typedef struct CachedPlan
{
 int magic;
 List *stmt_list;

 bool is_saved;
 bool is_valid;
 bool is_oneshot;
 TransactionId saved_xmin;

 int generation;
 int refcount;
 MemoryContext context;
} CachedPlan;


extern void InitPlanCache(void);
extern void ResetPlanCache(void);

extern CachedPlanSource *CreateCachedPlan(Node *raw_parse_tree,
     const char *query_string,
     const char *commandTag);
extern CachedPlanSource *CreateOneShotCachedPlan(Node *raw_parse_tree,
     const char *query_string,
     const char *commandTag);
extern void CompleteCachedPlan(CachedPlanSource *plansource,
       List *querytree_list,
       MemoryContext querytree_context,
       Oid *param_types,
       int num_params,
       ParserSetupHook parserSetup,
       void *parserSetupArg,
       int cursor_options,
       bool fixed_result);

extern void SaveCachedPlan(CachedPlanSource *plansource);
extern void DropCachedPlan(CachedPlanSource *plansource);

extern void CachedPlanSetParentContext(CachedPlanSource *plansource,
         MemoryContext newcontext);

extern CachedPlanSource *CopyCachedPlan(CachedPlanSource *plansource);

extern bool CachedPlanIsValid(CachedPlanSource *plansource);

extern List *CachedPlanGetTargetList(CachedPlanSource *plansource);

extern CachedPlan *GetCachedPlan(CachedPlanSource *plansource,
     ParamListInfo boundParams,
     bool useResOwner);
extern void ReleaseCachedPlan(CachedPlan *plan, bool useResOwner);
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/resowner.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h" 1
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/resowner.h" 2






typedef struct ResourceOwnerData *ResourceOwner;





extern ResourceOwner CurrentResourceOwner;
extern ResourceOwner CurTransactionResourceOwner;
extern ResourceOwner TopTransactionResourceOwner;
# 50 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/resowner.h"
typedef enum
{
 RESOURCE_RELEASE_BEFORE_LOCKS,
 RESOURCE_RELEASE_LOCKS,
 RESOURCE_RELEASE_AFTER_LOCKS
} ResourceReleasePhase;





typedef void (*ResourceReleaseCallback) (ResourceReleasePhase phase,
              bool isCommit,
              bool isTopLevel,
              void *arg);







extern ResourceOwner ResourceOwnerCreate(ResourceOwner parent,
     const char *name);
extern void ResourceOwnerRelease(ResourceOwner owner,
      ResourceReleasePhase phase,
      bool isCommit,
      bool isTopLevel);
extern void ResourceOwnerDelete(ResourceOwner owner);
extern ResourceOwner ResourceOwnerGetParent(ResourceOwner owner);
extern void ResourceOwnerNewParent(ResourceOwner owner,
        ResourceOwner newparent);
extern void RegisterResourceReleaseCallback(ResourceReleaseCallback callback,
        void *arg);
extern void UnregisterResourceReleaseCallback(ResourceReleaseCallback callback,
          void *arg);


extern void ResourceOwnerEnlargeBuffers(ResourceOwner owner);
extern void ResourceOwnerRememberBuffer(ResourceOwner owner, Buffer buffer);
extern void ResourceOwnerForgetBuffer(ResourceOwner owner, Buffer buffer);


extern void ResourceOwnerEnlargeCatCacheRefs(ResourceOwner owner);
extern void ResourceOwnerRememberCatCacheRef(ResourceOwner owner,
         HeapTuple tuple);
extern void ResourceOwnerForgetCatCacheRef(ResourceOwner owner,
          HeapTuple tuple);
extern void ResourceOwnerEnlargeCatCacheListRefs(ResourceOwner owner);
extern void ResourceOwnerRememberCatCacheListRef(ResourceOwner owner,
          CatCList *list);
extern void ResourceOwnerForgetCatCacheListRef(ResourceOwner owner,
           CatCList *list);


extern void ResourceOwnerEnlargeRelationRefs(ResourceOwner owner);
extern void ResourceOwnerRememberRelationRef(ResourceOwner owner,
         Relation rel);
extern void ResourceOwnerForgetRelationRef(ResourceOwner owner,
          Relation rel);


extern void ResourceOwnerEnlargePlanCacheRefs(ResourceOwner owner);
extern void ResourceOwnerRememberPlanCacheRef(ResourceOwner owner,
          CachedPlan *plan);
extern void ResourceOwnerForgetPlanCacheRef(ResourceOwner owner,
        CachedPlan *plan);


extern void ResourceOwnerEnlargeTupleDescs(ResourceOwner owner);
extern void ResourceOwnerRememberTupleDesc(ResourceOwner owner,
          TupleDesc tupdesc);
extern void ResourceOwnerForgetTupleDesc(ResourceOwner owner,
        TupleDesc tupdesc);


extern void ResourceOwnerEnlargeSnapshots(ResourceOwner owner);
extern void ResourceOwnerRememberSnapshot(ResourceOwner owner,
         Snapshot snapshot);
extern void ResourceOwnerForgetSnapshot(ResourceOwner owner,
       Snapshot snapshot);


extern void ResourceOwnerEnlargeFiles(ResourceOwner owner);
extern void ResourceOwnerRememberFile(ResourceOwner owner,
        File file);
extern void ResourceOwnerForgetFile(ResourceOwner owner,
      File file);
# 52 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/portal.h" 2
# 87 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/portal.h"
typedef enum PortalStrategy
{
 PORTAL_ONE_SELECT,
 PORTAL_ONE_RETURNING,
 PORTAL_ONE_MOD_WITH,
 PORTAL_UTIL_SELECT,
 PORTAL_MULTI_QUERY
} PortalStrategy;






typedef enum PortalStatus
{
 PORTAL_NEW,
 PORTAL_DEFINED,
 PORTAL_READY,
 PORTAL_ACTIVE,
 PORTAL_DONE,
 PORTAL_FAILED
} PortalStatus;

typedef struct PortalData *Portal;

typedef struct PortalData
{

 const char *name;
 const char *prepStmtName;
 MemoryContext heap;
 ResourceOwner resowner;
 void (*cleanup) (Portal portal);
 SubTransactionId createSubid;







 const char *sourceText;
 const char *commandTag;
 List *stmts;
 CachedPlan *cplan;

 ParamListInfo portalParams;


 PortalStrategy strategy;
 int cursorOptions;


 PortalStatus status;
 bool portalPinned;


 QueryDesc *queryDesc;


 TupleDesc tupDesc;

 int16 *formats;






 Tuplestorestate *holdStore;
 MemoryContext holdContext;
# 169 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/portal.h"
 bool atStart;
 bool atEnd;
 bool posOverflow;
 long portalPos;


 TimestampTz creation_time;
 bool visible;
} PortalData;
# 194 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/portal.h"
extern void EnablePortalManager(void);
extern bool PreCommit_Portals(bool isPrepare);
extern void AtAbort_Portals(void);
extern void AtCleanup_Portals(void);
extern void AtSubCommit_Portals(SubTransactionId mySubid,
     SubTransactionId parentSubid,
     ResourceOwner parentXactOwner);
extern void AtSubAbort_Portals(SubTransactionId mySubid,
       SubTransactionId parentSubid,
       ResourceOwner parentXactOwner);
extern void AtSubCleanup_Portals(SubTransactionId mySubid);
extern Portal CreatePortal(const char *name, bool allowDup, bool dupSilent);
extern Portal CreateNewPortal(void);
extern void PinPortal(Portal portal);
extern void UnpinPortal(Portal portal);
extern void MarkPortalDone(Portal portal);
extern void MarkPortalFailed(Portal portal);
extern void PortalDrop(Portal portal, bool isTopCommit);
extern Portal GetPortalByName(const char *name);
extern void PortalDefineQuery(Portal portal,
      const char *prepStmtName,
      const char *sourceText,
      const char *commandTag,
      List *stmts,
      CachedPlan *cplan);
extern Node *PortalListGetPrimaryStmt(List *stmts);
extern void PortalCreateHoldStore(Portal portal);
extern void PortalHashTableDeleteAll(void);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/spi.h" 2


typedef struct SPITupleTable
{
 MemoryContext tuptabcxt;
 uint32 alloced;
 uint32 free;
 TupleDesc tupdesc;
 HeapTuple *vals;
} SPITupleTable;


typedef struct _SPI_plan *SPIPlanPtr;
# 59 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/spi.h"
extern uint32 SPI_processed;
extern Oid SPI_lastoid;
extern SPITupleTable *SPI_tuptable;
extern int SPI_result;

extern int SPI_connect(void);
extern int SPI_finish(void);
extern void SPI_push(void);
extern void SPI_pop(void);
extern bool SPI_push_conditional(void);
extern void SPI_pop_conditional(bool pushed);
extern void SPI_restore_connection(void);
extern int SPI_execute(const char *src, bool read_only, long tcount);
extern int SPI_execute_plan(SPIPlanPtr plan, Datum *Values, const char *Nulls,
     bool read_only, long tcount);
extern int SPI_execute_plan_with_paramlist(SPIPlanPtr plan,
        ParamListInfo params,
        bool read_only, long tcount);
extern int SPI_exec(const char *src, long tcount);
extern int SPI_execp(SPIPlanPtr plan, Datum *Values, const char *Nulls,
    long tcount);
extern int SPI_execute_snapshot(SPIPlanPtr plan,
      Datum *Values, const char *Nulls,
      Snapshot snapshot,
      Snapshot crosscheck_snapshot,
      bool read_only, bool fire_triggers, long tcount);
extern int SPI_execute_with_args(const char *src,
       int nargs, Oid *argtypes,
       Datum *Values, const char *Nulls,
       bool read_only, long tcount);
extern SPIPlanPtr SPI_prepare(const char *src, int nargs, Oid *argtypes);
extern SPIPlanPtr SPI_prepare_cursor(const char *src, int nargs, Oid *argtypes,
       int cursorOptions);
extern SPIPlanPtr SPI_prepare_params(const char *src,
       ParserSetupHook parserSetup,
       void *parserSetupArg,
       int cursorOptions);
extern int SPI_keepplan(SPIPlanPtr plan);
extern SPIPlanPtr SPI_saveplan(SPIPlanPtr plan);
extern int SPI_freeplan(SPIPlanPtr plan);

extern Oid SPI_getargtypeid(SPIPlanPtr plan, int argIndex);
extern int SPI_getargcount(SPIPlanPtr plan);
extern bool SPI_is_cursor_plan(SPIPlanPtr plan);
extern bool SPI_plan_is_valid(SPIPlanPtr plan);
extern const char *SPI_result_code_string(int code);

extern List *SPI_plan_get_plan_sources(SPIPlanPtr plan);
extern CachedPlan *SPI_plan_get_cached_plan(SPIPlanPtr plan);

extern HeapTuple SPI_copytuple(HeapTuple tuple);
extern HeapTupleHeader SPI_returntuple(HeapTuple tuple, TupleDesc tupdesc);
extern HeapTuple SPI_modifytuple(Relation rel, HeapTuple tuple, int natts,
    int *attnum, Datum *Values, const char *Nulls);
extern int SPI_fnumber(TupleDesc tupdesc, const char *fname);
extern char *SPI_fname(TupleDesc tupdesc, int fnumber);
extern char *SPI_getvalue(HeapTuple tuple, TupleDesc tupdesc, int fnumber);
extern Datum SPI_getbinval(HeapTuple tuple, TupleDesc tupdesc, int fnumber, bool *isnull);
extern char *SPI_gettype(TupleDesc tupdesc, int fnumber);
extern Oid SPI_gettypeid(TupleDesc tupdesc, int fnumber);
extern char *SPI_getrelname(Relation rel);
extern char *SPI_getnspname(Relation rel);
extern void *SPI_palloc(Size size);
extern void *SPI_repalloc(void *pointer, Size size);
extern void SPI_pfree(void *pointer);
extern void SPI_freetuple(HeapTuple pointer);
extern void SPI_freetuptable(SPITupleTable *tuptable);

extern Portal SPI_cursor_open(const char *name, SPIPlanPtr plan,
    Datum *Values, const char *Nulls, bool read_only);
extern Portal SPI_cursor_open_with_args(const char *name,
        const char *src,
        int nargs, Oid *argtypes,
        Datum *Values, const char *Nulls,
        bool read_only, int cursorOptions);
extern Portal SPI_cursor_open_with_paramlist(const char *name, SPIPlanPtr plan,
          ParamListInfo params, bool read_only);
extern Portal SPI_cursor_find(const char *name);
extern void SPI_cursor_fetch(Portal portal, bool forward, long count);
extern void SPI_cursor_move(Portal portal, bool forward, long count);
extern void SPI_scroll_cursor_fetch(Portal, FetchDirection direction, long count);
extern void SPI_scroll_cursor_move(Portal, FetchDirection direction, long count);
extern void SPI_cursor_close(Portal portal);

extern void AtEOXact_SPI(bool isCommit);
extern void AtEOSubXact_SPI(bool isCommit, SubTransactionId mySubid);
# 26 "pltcl.c" 2
# 1 "fmgr.h" 1
# 27 "pltcl.c" 2
# 1 "miscadmin.h" 1
# 26 "miscadmin.h"
# 1 "pgtime.h" 1
# 23 "pgtime.h"
typedef int64 pg_time_t;

struct pg_tm
{
 int tm_sec;
 int tm_min;
 int tm_hour;
 int tm_mday;
 int tm_mon;
 int tm_year;
 int tm_wday;
 int tm_yday;
 int tm_isdst;
 long int tm_gmtoff;
 const char *tm_zone;
};

typedef struct pg_tz pg_tz;
typedef struct pg_tzenum pg_tzenum;






extern struct pg_tm *pg_localtime(const pg_time_t *timep, const pg_tz *tz);
extern struct pg_tm *pg_gmtime(const pg_time_t *timep);
extern int pg_next_dst_boundary(const pg_time_t *timep,
      long int *before_gmtoff,
      int *before_isdst,
      pg_time_t *boundary,
      long int *after_gmtoff,
      int *after_isdst,
      const pg_tz *tz);
extern size_t pg_strftime(char *s, size_t max, const char *format,
   const struct pg_tm * tm);

extern bool pg_get_timezone_offset(const pg_tz *tz, long int *gmtoff);
extern const char *pg_get_timezone_name(pg_tz *tz);
extern bool pg_tz_acceptable(pg_tz *tz);



extern pg_tz *session_timezone;
extern pg_tz *log_timezone;

extern void pg_timezone_initialize(void);
extern pg_tz *pg_tzset(const char *tzname);

extern pg_tzenum *pg_tzenumerate_start(void);
extern pg_tz *pg_tzenumerate_next(pg_tzenum *dir);
extern void pg_tzenumerate_end(pg_tzenum *dir);
# 27 "miscadmin.h" 2
# 74 "miscadmin.h"
extern volatile bool InterruptPending;
extern volatile bool QueryCancelPending;
extern volatile bool ProcDiePending;

extern volatile bool ClientConnectionLost;


extern volatile bool ImmediateInterruptOK;
extern volatile uint32 InterruptHoldoffCount;
extern volatile uint32 CritSectionCount;


extern void ProcessInterrupts(void);
# 131 "miscadmin.h"
extern pid_t PostmasterPid;
extern bool IsPostmasterEnvironment;
extern bool IsUnderPostmaster;
extern bool IsBinaryUpgrade;

extern bool ExitOnAnyError;

extern char *DataDir;

extern int NBuffers;
extern int MaxBackends;
extern int MaxConnections;

extern int MyProcPid;
extern pg_time_t MyStartTime;
extern struct Port *MyProcPort;
extern long MyCancelKey;
extern int MyPMChildSlot;

extern char OutputFileName[];
extern char my_exec_path[];
extern char pkglib_path[];
# 163 "miscadmin.h"
extern Oid MyDatabaseId;

extern Oid MyDatabaseTableSpace;
# 201 "miscadmin.h"
extern int DateStyle;
extern int DateOrder;
# 216 "miscadmin.h"
extern int IntervalStyle;







extern bool HasCTZSet;
extern int CTimeZone;



extern bool enableFsync;
extern bool allowSystemTableMods;
extern int work_mem;
extern int maintenance_work_mem;

extern int VacuumCostPageHit;
extern int VacuumCostPageMiss;
extern int VacuumCostPageDirty;
extern int VacuumCostLimit;
extern int VacuumCostDelay;

extern int VacuumPageHit;
extern int VacuumPageMiss;
extern int VacuumPageDirty;

extern int VacuumCostBalance;
extern bool VacuumCostActive;
# 257 "miscadmin.h"
typedef char *pg_stack_base_t;


extern pg_stack_base_t set_stack_base(void);
extern void restore_stack_base(pg_stack_base_t base);
extern void check_stack_depth(void);


extern void PreventCommandIfReadOnly(const char *cmdname);
extern void PreventCommandDuringRecovery(const char *cmdname);


extern int trace_recovery_messages;
extern int trace_recovery(int trace_level);
# 281 "miscadmin.h"
extern char *DatabasePath;


extern void SetDatabasePath(const char *path);

extern char *GetUserNameFromId(Oid roleid);
extern Oid GetUserId(void);
extern Oid GetOuterUserId(void);
extern Oid GetSessionUserId(void);
extern void GetUserIdAndSecContext(Oid *userid, int *sec_context);
extern void SetUserIdAndSecContext(Oid userid, int sec_context);
extern bool InLocalUserIdChange(void);
extern bool InSecurityRestrictedOperation(void);
extern void GetUserIdAndContext(Oid *userid, bool *sec_def_context);
extern void SetUserIdAndContext(Oid userid, bool sec_def_context);
extern void InitializeSessionUserId(const char *rolename);
extern void InitializeSessionUserIdStandalone(void);
extern void SetSessionAuthorization(Oid userid, bool is_superuser);
extern Oid GetCurrentRoleId(void);
extern void SetCurrentRoleId(Oid roleid, bool is_superuser);

extern void SetDataDir(const char *dir);
extern void ChangeToDataDir(void);
extern char *make_absolute_path(const char *path);


extern bool superuser(void);
extern bool superuser_arg(Oid roleid);
# 335 "miscadmin.h"
typedef enum ProcessingMode
{
 BootstrapProcessing,
 InitProcessing,
 NormalProcessing
} ProcessingMode;

extern ProcessingMode Mode;
# 365 "miscadmin.h"
typedef enum
{
 NotAnAuxProcess = -1,
 CheckerProcess = 0,
 BootstrapProcess,
 StartupProcess,
 BgWriterProcess,
 CheckpointerProcess,
 WalWriterProcess,
 WalReceiverProcess,

 NUM_AUXPROCTYPES
} AuxProcType;

extern AuxProcType MyAuxProcType;
# 395 "miscadmin.h"
extern void pg_split_opts(char **argv, int *argcp, char *optstr);
extern void InitPostgres(const char *in_dbname, Oid dboid, const char *username,
    char *out_dbname);
extern void BaseInit(void);


extern bool IgnoreSystemIndexes;
extern bool process_shared_preload_libraries_in_progress;
extern char *shared_preload_libraries_string;
extern char *local_preload_libraries_string;
# 431 "miscadmin.h"
extern void CreateDataDirLockFile(bool amPostmaster);
extern void CreateSocketLockFile(const char *socketfile, bool amPostmaster);
extern void TouchSocketLockFile(void);
extern void AddToDataDirLockFile(int target_line, const char *str);
extern void ValidatePgVersion(const char *path);
extern void process_shared_preload_libraries(void);
extern void process_local_preload_libraries(void);
extern void pg_bindtextdomain(const char *domain);
extern bool has_rolreplication(Oid roleid);


extern bool BackupInProgress(void);
extern void CancelBackup(void);
# 28 "pltcl.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/makefuncs.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/makefuncs.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/makefuncs.h" 2


extern A_Expr *makeA_Expr(A_Expr_Kind kind, List *name,
     Node *lexpr, Node *rexpr, int location);

extern A_Expr *makeSimpleA_Expr(A_Expr_Kind kind, char *name,
     Node *lexpr, Node *rexpr, int location);

extern Var *makeVar(Index varno,
  AttrNumber varattno,
  Oid vartype,
  int32 vartypmod,
  Oid varcollid,
  Index varlevelsup);

extern Var *makeVarFromTargetEntry(Index varno,
        TargetEntry *tle);

extern Var *makeWholeRowVar(RangeTblEntry *rte,
    Index varno,
    Index varlevelsup,
    bool allowScalar);

extern TargetEntry *makeTargetEntry(Expr *expr,
    AttrNumber resno,
    char *resname,
    bool resjunk);

extern TargetEntry *flatCopyTargetEntry(TargetEntry *src_tle);

extern FromExpr *makeFromExpr(List *fromlist, Node *quals);

extern Const *makeConst(Oid consttype,
    int32 consttypmod,
    Oid constcollid,
    int constlen,
    Datum constvalue,
    bool constisnull,
    bool constbyval);

extern Const *makeNullConst(Oid consttype, int32 consttypmod, Oid constcollid);

extern Node *makeBoolConst(bool value, bool isnull);

extern Expr *makeBoolExpr(BoolExprType boolop, List *args, int location);

extern Alias *makeAlias(const char *aliasname, List *colnames);

extern RelabelType *makeRelabelType(Expr *arg, Oid rtype, int32 rtypmod,
    Oid rcollid, CoercionForm rformat);

extern RangeVar *makeRangeVar(char *schemaname, char *relname, int location);

extern TypeName *makeTypeName(char *typnam);
extern TypeName *makeTypeNameFromNameList(List *names);
extern TypeName *makeTypeNameFromOid(Oid typeOid, int32 typmod);

extern FuncExpr *makeFuncExpr(Oid funcid, Oid rettype, List *args,
    Oid funccollid, Oid inputcollid, CoercionForm fformat);

extern DefElem *makeDefElem(char *name, Node *arg);
extern DefElem *makeDefElemExtended(char *nameSpace, char *name, Node *arg,
     DefElemAction defaction);
# 29 "pltcl.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_type.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_type.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_type.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_node.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_node.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_node.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_node.h" 2





typedef struct ParseState ParseState;

typedef Node *(*PreParseColumnRefHook) (ParseState *pstate, ColumnRef *cref);
typedef Node *(*PostParseColumnRefHook) (ParseState *pstate, ColumnRef *cref, Node *var);
typedef Node *(*ParseParamRefHook) (ParseState *pstate, ParamRef *pref);
typedef Node *(*CoerceParamHook) (ParseState *pstate, Param *param,
            Oid targetTypeId, int32 targetTypeMod,
             int location);
# 86 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_node.h"
struct ParseState
{
 struct ParseState *parentParseState;
 const char *p_sourcetext;
 List *p_rtable;
 List *p_joinexprs;
 List *p_joinlist;

 List *p_relnamespace;
 List *p_varnamespace;
 List *p_ctenamespace;
 List *p_future_ctes;
 CommonTableExpr *p_parent_cte;
 List *p_windowdefs;
 int p_next_resno;
 List *p_locking_clause;
 Node *p_value_substitute;
 bool p_hasAggs;
 bool p_hasWindowFuncs;
 bool p_hasSubLinks;
 bool p_hasModifyingCTE;
 bool p_is_insert;
 bool p_is_update;
 bool p_locked_from_parent;
 Relation p_target_relation;
 RangeTblEntry *p_target_rangetblentry;





 PreParseColumnRefHook p_pre_columnref_hook;
 PostParseColumnRefHook p_post_columnref_hook;
 ParseParamRefHook p_paramref_hook;
 CoerceParamHook p_coerce_param_hook;
 void *p_ref_hook_state;
};


typedef struct ParseCallbackState
{
 ParseState *pstate;
 int location;
 ErrorContextCallback errcontext;
} ParseCallbackState;


extern ParseState *make_parsestate(ParseState *parentParseState);
extern void free_parsestate(ParseState *pstate);
extern int parser_errposition(ParseState *pstate, int location);

extern void setup_parser_errposition_callback(ParseCallbackState *pcbstate,
          ParseState *pstate, int location);
extern void cancel_parser_errposition_callback(ParseCallbackState *pcbstate);

extern Var *make_var(ParseState *pstate, RangeTblEntry *rte, int attrno,
   int location);
extern Oid transformArrayType(Oid *arrayType, int32 *arrayTypmod);
extern ArrayRef *transformArraySubscripts(ParseState *pstate,
       Node *arrayBase,
       Oid arrayType,
       Oid elementType,
       int32 arrayTypMod,
       List *indirection,
       Node *assignFrom);
extern Const *make_const(ParseState *pstate, Value *value, int location);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_type.h" 2


typedef HeapTuple Type;

extern Type LookupTypeName(ParseState *pstate, const TypeName *typeName,
      int32 *typmod_p);
extern Type typenameType(ParseState *pstate, const TypeName *typeName,
    int32 *typmod_p);
extern Oid typenameTypeId(ParseState *pstate, const TypeName *typeName);
extern void typenameTypeIdAndMod(ParseState *pstate, const TypeName *typeName,
      Oid *typeid_p, int32 *typmod_p);

extern char *TypeNameToString(const TypeName *typeName);
extern char *TypeNameListToString(List *typenames);

extern Oid LookupCollation(ParseState *pstate, List *collnames, int location);
extern Oid GetColumnDefCollation(ParseState *pstate, ColumnDef *coldef, Oid typeOid);

extern Type typeidType(Oid id);

extern Oid typeTypeId(Type tp);
extern int16 typeLen(Type t);
extern bool typeByVal(Type t);
extern char *typeTypeName(Type t);
extern Oid typeTypeRelid(Type typ);
extern Oid typeTypeCollation(Type typ);
extern Datum stringTypeDatum(Type tp, char *string, int32 atttypmod);

extern Oid typeidTypeRelid(Oid type_id);

extern void parseTypeString(const char *str, Oid *typeid_p, int32 *typmod_p);
# 30 "pltcl.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/tcopprot.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/tcopprot.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/execdesc.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/tcopprot.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/tcopprot.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/procsignal.h" 1
# 30 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/procsignal.h"
typedef enum
{
 PROCSIG_CATCHUP_INTERRUPT,
 PROCSIG_NOTIFY_INTERRUPT,


 PROCSIG_RECOVERY_CONFLICT_DATABASE,
 PROCSIG_RECOVERY_CONFLICT_TABLESPACE,
 PROCSIG_RECOVERY_CONFLICT_LOCK,
 PROCSIG_RECOVERY_CONFLICT_SNAPSHOT,
 PROCSIG_RECOVERY_CONFLICT_BUFFERPIN,
 PROCSIG_RECOVERY_CONFLICT_STARTUP_DEADLOCK,

 NUM_PROCSIGNALS
} ProcSignalReason;




extern Size ProcSignalShmemSize(void);
extern void ProcSignalShmemInit(void);

extern void ProcSignalInit(int pss_idx);
extern int SendProcSignal(pid_t pid, ProcSignalReason reason,
      BackendId backendId);

extern void procsignal_sigusr1_handler(int postgres_signal_arg);
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/tcopprot.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h" 1
# 59 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h"
# 1 "./fmgr.h" 1
# 60 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h" 2
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h"
typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
} ArrayType;




typedef struct ArrayBuildState
{
 MemoryContext mcontext;
 Datum *dvalues;
 bool *dnulls;
 int alen;
 int nelems;
 Oid element_type;
 int16 typlen;
 bool typbyval;
 char typalign;
} ArrayBuildState;




typedef struct ArrayMetaState
{
 Oid element_type;
 int16 typlen;
 bool typbyval;
 char typalign;
 char typdelim;
 Oid typioparam;
 Oid typiofunc;
 FmgrInfo proc;
} ArrayMetaState;




typedef struct ArrayMapState
{
 ArrayMetaState inp_extra;
 ArrayMetaState ret_extra;
} ArrayMapState;


typedef struct ArrayIteratorData *ArrayIterator;
# 182 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h"
extern bool Array_nulls;




extern Datum array_in(FunctionCallInfo fcinfo);
extern Datum array_out(FunctionCallInfo fcinfo);
extern Datum array_recv(FunctionCallInfo fcinfo);
extern Datum array_send(FunctionCallInfo fcinfo);
extern Datum array_eq(FunctionCallInfo fcinfo);
extern Datum array_ne(FunctionCallInfo fcinfo);
extern Datum array_lt(FunctionCallInfo fcinfo);
extern Datum array_gt(FunctionCallInfo fcinfo);
extern Datum array_le(FunctionCallInfo fcinfo);
extern Datum array_ge(FunctionCallInfo fcinfo);
extern Datum btarraycmp(FunctionCallInfo fcinfo);
extern Datum hash_array(FunctionCallInfo fcinfo);
extern Datum arrayoverlap(FunctionCallInfo fcinfo);
extern Datum arraycontains(FunctionCallInfo fcinfo);
extern Datum arraycontained(FunctionCallInfo fcinfo);
extern Datum array_ndims(FunctionCallInfo fcinfo);
extern Datum array_dims(FunctionCallInfo fcinfo);
extern Datum array_lower(FunctionCallInfo fcinfo);
extern Datum array_upper(FunctionCallInfo fcinfo);
extern Datum array_length(FunctionCallInfo fcinfo);
extern Datum array_larger(FunctionCallInfo fcinfo);
extern Datum array_smaller(FunctionCallInfo fcinfo);
extern Datum generate_subscripts(FunctionCallInfo fcinfo);
extern Datum generate_subscripts_nodir(FunctionCallInfo fcinfo);
extern Datum array_fill(FunctionCallInfo fcinfo);
extern Datum array_fill_with_lower_bounds(FunctionCallInfo fcinfo);
extern Datum array_unnest(FunctionCallInfo fcinfo);

extern Datum array_ref(ArrayType *array, int nSubscripts, int *indx,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign,
    bool *isNull);
extern ArrayType *array_set(ArrayType *array, int nSubscripts, int *indx,
    Datum dataValue, bool isNull,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign);
extern ArrayType *array_get_slice(ArrayType *array, int nSubscripts,
    int *upperIndx, int *lowerIndx,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign);
extern ArrayType *array_set_slice(ArrayType *array, int nSubscripts,
    int *upperIndx, int *lowerIndx,
    ArrayType *srcArray, bool isNull,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign);

extern Datum array_map(FunctionCallInfo fcinfo, Oid inpType, Oid retType,
    ArrayMapState *amstate);

extern void array_bitmap_copy(bits8 *destbitmap, int destoffset,
      const bits8 *srcbitmap, int srcoffset,
      int nitems);

extern ArrayType *construct_array(Datum *elems, int nelems,
    Oid elmtype,
    int elmlen, bool elmbyval, char elmalign);
extern ArrayType *construct_md_array(Datum *elems,
       bool *nulls,
       int ndims,
       int *dims,
       int *lbs,
       Oid elmtype, int elmlen, bool elmbyval, char elmalign);
extern ArrayType *construct_empty_array(Oid elmtype);
extern void deconstruct_array(ArrayType *array,
      Oid elmtype,
      int elmlen, bool elmbyval, char elmalign,
      Datum **elemsp, bool **nullsp, int *nelemsp);
extern bool array_contains_nulls(ArrayType *array);
extern ArrayBuildState *accumArrayResult(ArrayBuildState *astate,
     Datum dvalue, bool disnull,
     Oid element_type,
     MemoryContext rcontext);
extern Datum makeArrayResult(ArrayBuildState *astate,
    MemoryContext rcontext);
extern Datum makeMdArrayResult(ArrayBuildState *astate, int ndims,
      int *dims, int *lbs, MemoryContext rcontext, bool release);

extern ArrayIterator array_create_iterator(ArrayType *arr, int slice_ndim);
extern bool array_iterate(ArrayIterator iterator, Datum *value, bool *isnull);
extern void array_free_iterator(ArrayIterator iterator);





extern int ArrayGetOffset(int n, const int *dim, const int *lb, const int *indx);
extern int ArrayGetOffset0(int n, const int *tup, const int *scale);
extern int ArrayGetNItems(int ndim, const int *dims);
extern void mda_get_range(int n, int *span, const int *st, const int *endp);
extern void mda_get_prod(int n, const int *range, int *prod);
extern void mda_get_offset_values(int n, int *dist, const int *prod, const int *span);
extern int mda_next_tuple(int n, int *curr, const int *span);
extern int32 *ArrayGetIntegerTypmods(ArrayType *arr, int *n);




extern Datum array_push(FunctionCallInfo fcinfo);
extern Datum array_cat(FunctionCallInfo fcinfo);

extern ArrayType *create_singleton_array(FunctionCallInfo fcinfo,
        Oid element_type,
        Datum element,
        bool isNull,
        int ndims);

extern Datum array_agg_transfn(FunctionCallInfo fcinfo);
extern Datum array_agg_finalfn(FunctionCallInfo fcinfo);




extern Datum array_typanalyze(FunctionCallInfo fcinfo);
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 2
# 51 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
typedef enum
{
 PGC_INTERNAL,
 PGC_POSTMASTER,
 PGC_SIGHUP,
 PGC_BACKEND,
 PGC_SUSET,
 PGC_USERSET
} GucContext;
# 83 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
typedef enum
{
 PGC_S_DEFAULT,
 PGC_S_DYNAMIC_DEFAULT,
 PGC_S_ENV_VAR,
 PGC_S_FILE,
 PGC_S_ARGV,
 PGC_S_DATABASE,
 PGC_S_USER,
 PGC_S_DATABASE_USER,
 PGC_S_CLIENT,
 PGC_S_OVERRIDE,
 PGC_S_INTERACTIVE,
 PGC_S_TEST,
 PGC_S_SESSION
} GucSource;





typedef struct ConfigVariable
{
 char *name;
 char *value;
 char *filename;
 int sourceline;
 struct ConfigVariable *next;
} ConfigVariable;

extern bool ParseConfigFile(const char *config_file, const char *calling_file,
    bool strict, int depth, int elevel,
    ConfigVariable **head_p, ConfigVariable **tail_p);
extern bool ParseConfigFp(FILE *fp, const char *config_file,
     int depth, int elevel,
     ConfigVariable **head_p, ConfigVariable **tail_p);
extern void FreeConfigVariables(ConfigVariable *list);






struct config_enum_entry
{
 const char *name;
 int val;
 bool hidden;
};




typedef bool (*GucBoolCheckHook) (bool *newval, void **extra, GucSource source);
typedef bool (*GucIntCheckHook) (int *newval, void **extra, GucSource source);
typedef bool (*GucRealCheckHook) (double *newval, void **extra, GucSource source);
typedef bool (*GucStringCheckHook) (char **newval, void **extra, GucSource source);
typedef bool (*GucEnumCheckHook) (int *newval, void **extra, GucSource source);

typedef void (*GucBoolAssignHook) (bool newval, void *extra);
typedef void (*GucIntAssignHook) (int newval, void *extra);
typedef void (*GucRealAssignHook) (double newval, void *extra);
typedef void (*GucStringAssignHook) (const char *newval, void *extra);
typedef void (*GucEnumAssignHook) (int newval, void *extra);

typedef const char *(*GucShowHook) (void);




typedef enum
{

 GUC_ACTION_SET,
 GUC_ACTION_LOCAL,
 GUC_ACTION_SAVE
} GucAction;
# 190 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
extern bool log_duration;
extern bool Debug_print_plan;
extern bool Debug_print_parse;
extern bool Debug_print_rewritten;
extern bool Debug_pretty_print;

extern bool log_parser_stats;
extern bool log_planner_stats;
extern bool log_executor_stats;
extern bool log_statement_stats;
extern bool log_btree_build_stats;

extern bool check_function_bodies;
extern bool default_with_oids;
extern bool SQL_inheritance;

extern int log_min_error_statement;
extern int log_min_messages;
extern int client_min_messages;
extern int log_min_duration_statement;
extern int log_temp_files;

extern int temp_file_limit;

extern int num_temp_buffers;

extern char *data_directory;
extern char *ConfigFileName;
extern char *HbaFileName;
extern char *IdentFileName;
extern char *external_pid_file;

extern char *application_name;

extern int tcp_keepalives_idle;
extern int tcp_keepalives_interval;
extern int tcp_keepalives_count;




extern void SetConfigOption(const char *name, const char *value,
    GucContext context, GucSource source);

extern void DefineCustomBoolVariable(
       const char *name,
       const char *short_desc,
       const char *long_desc,
       bool *valueAddr,
       bool bootValue,
       GucContext context,
       int flags,
       GucBoolCheckHook check_hook,
       GucBoolAssignHook assign_hook,
       GucShowHook show_hook);

extern void DefineCustomIntVariable(
      const char *name,
      const char *short_desc,
      const char *long_desc,
      int *valueAddr,
      int bootValue,
      int minValue,
      int maxValue,
      GucContext context,
      int flags,
      GucIntCheckHook check_hook,
      GucIntAssignHook assign_hook,
      GucShowHook show_hook);

extern void DefineCustomRealVariable(
       const char *name,
       const char *short_desc,
       const char *long_desc,
       double *valueAddr,
       double bootValue,
       double minValue,
       double maxValue,
       GucContext context,
       int flags,
       GucRealCheckHook check_hook,
       GucRealAssignHook assign_hook,
       GucShowHook show_hook);

extern void DefineCustomStringVariable(
         const char *name,
         const char *short_desc,
         const char *long_desc,
         char **valueAddr,
         const char *bootValue,
         GucContext context,
         int flags,
         GucStringCheckHook check_hook,
         GucStringAssignHook assign_hook,
         GucShowHook show_hook);

extern void DefineCustomEnumVariable(
       const char *name,
       const char *short_desc,
       const char *long_desc,
       int *valueAddr,
       int bootValue,
       const struct config_enum_entry * options,
       GucContext context,
       int flags,
       GucEnumCheckHook check_hook,
       GucEnumAssignHook assign_hook,
       GucShowHook show_hook);

extern void EmitWarningsOnPlaceholders(const char *className);

extern const char *GetConfigOption(const char *name, bool missing_ok,
    bool restrict_superuser);
extern const char *GetConfigOptionResetString(const char *name);
extern void ProcessConfigFile(GucContext context);
extern void InitializeGUCOptions(void);
extern bool SelectConfigFiles(const char *userDoption, const char *progname);
extern void ResetAllOptions(void);
extern void AtStart_GUC(void);
extern int NewGUCNestLevel(void);
extern void AtEOXact_GUC(bool isCommit, int nestLevel);
extern void BeginReportingGUCOptions(void);
extern void ParseLongOption(const char *string, char **name, char **value);
extern bool parse_int(const char *value, int *result, int flags,
    const char **hintmsg);
extern bool parse_real(const char *value, double *result);
extern int set_config_option(const char *name, const char *value,
      GucContext context, GucSource source,
      GucAction action, bool changeVal, int elevel);
extern char *GetConfigOptionByName(const char *name, const char **varname);
extern void GetConfigOptionByNum(int varnum, const char **values, bool *noshow);
extern int GetNumConfigOptions(void);

extern void SetPGVariable(const char *name, List *args, bool is_local);
extern void GetPGVariable(const char *name, DestReceiver *dest);
extern TupleDesc GetPGVariableResultDesc(const char *name);

extern void ExecSetVariableStmt(VariableSetStmt *stmt);
extern char *ExtractSetVariableArgs(VariableSetStmt *stmt);

extern void ProcessGUCArray(ArrayType *array,
    GucContext context, GucSource source, GucAction action);
extern ArrayType *GUCArrayAdd(ArrayType *array, const char *name, const char *value);
extern ArrayType *GUCArrayDelete(ArrayType *array, const char *name);
extern ArrayType *GUCArrayReset(ArrayType *array);
# 343 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
extern char *GUC_check_errmsg_string;
extern char *GUC_check_errdetail_string;
extern char *GUC_check_errhint_string;

extern void GUC_check_errcode(int sqlerrcode);
# 369 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
extern bool check_default_tablespace(char **newval, void **extra, GucSource source);
extern bool check_temp_tablespaces(char **newval, void **extra, GucSource source);
extern void assign_temp_tablespaces(const char *newval, void *extra);


extern bool check_search_path(char **newval, void **extra, GucSource source);
extern void assign_search_path(const char *newval, void *extra);


extern bool check_wal_buffers(int *newval, void **extra, GucSource source);
extern void assign_xlog_sync_method(int new_sync_method, void *extra);
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/tcopprot.h" 2





extern CommandDest whereToSendOutput;
extern const char *debug_query_string;
extern int max_stack_depth;
extern int PostAuthDelay;



typedef enum
{
 LOGSTMT_NONE,
 LOGSTMT_DDL,
 LOGSTMT_MOD,
 LOGSTMT_ALL
} LogStmtLevel;

extern int log_statement;

extern List *pg_parse_query(const char *query_string);
extern List *pg_analyze_and_rewrite(Node *parsetree, const char *query_string,
        Oid *paramTypes, int numParams);
extern List *pg_analyze_and_rewrite_params(Node *parsetree,
         const char *query_string,
         ParserSetupHook parserSetup,
         void *parserSetupArg);
extern PlannedStmt *pg_plan_query(Query *querytree, int cursorOptions,
     ParamListInfo boundParams);
extern List *pg_plan_queries(List *querytrees, int cursorOptions,
    ParamListInfo boundParams);

extern bool check_max_stack_depth(int *newval, void **extra, GucSource source);
extern void assign_max_stack_depth(int newval, void *extra);

extern void die(int postgres_signal_arg);
extern void quickdie(int postgres_signal_arg);
extern void StatementCancelHandler(int postgres_signal_arg);
extern void FloatExceptionHandler(int postgres_signal_arg);
extern void RecoveryConflictInterrupt(ProcSignalReason reason);

extern void prepare_for_client_read(void);
extern void client_read_ended(void);
extern void process_postgres_switches(int argc, char *argv[],
        GucContext ctx, const char **dbname);
extern int PostgresMain(int argc, char *argv[],
       const char *dbname, const char *username);
extern long get_stack_depth_rlimit(void);
extern void ResetUsage(void);
extern void ShowUsage(const char *title);
extern int check_log_duration(char *msec_str, bool was_logged);
extern void set_debug_options(int debug_flag,
      GucContext context, GucSource source);
extern bool set_plan_disabling_options(const char *arg,
         GucContext context, GucSource source);
extern const char *get_stats_option_name(const char *arg);
# 31 "pltcl.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/builtins.h" 1
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/builtins.h"
extern Datum has_any_column_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_any_column_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_any_column_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_any_column_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_any_column_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_any_column_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_name_name_name(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_name_name_attnum(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_name_id_name(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_name_id_attnum(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_id_name_name(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_id_name_attnum(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_id_id_name(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_id_id_attnum(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_name_attnum(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_id_attnum(FunctionCallInfo fcinfo);
extern Datum has_table_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_table_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_table_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_table_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_table_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_table_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_sequence_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_sequence_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_sequence_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_sequence_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_sequence_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_sequence_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_database_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_database_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_database_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_database_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_database_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_database_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_foreign_data_wrapper_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_foreign_data_wrapper_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_foreign_data_wrapper_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_foreign_data_wrapper_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_foreign_data_wrapper_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_foreign_data_wrapper_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_function_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_function_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_function_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_function_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_function_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_function_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_language_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_language_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_language_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_language_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_language_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_language_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_schema_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_schema_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_schema_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_schema_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_schema_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_schema_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_server_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_server_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_server_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_server_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_server_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_server_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_tablespace_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_tablespace_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_tablespace_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_tablespace_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_tablespace_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_tablespace_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_type_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_type_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_type_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_type_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_type_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_type_privilege_id(FunctionCallInfo fcinfo);
extern Datum pg_has_role_name_name(FunctionCallInfo fcinfo);
extern Datum pg_has_role_name_id(FunctionCallInfo fcinfo);
extern Datum pg_has_role_id_name(FunctionCallInfo fcinfo);
extern Datum pg_has_role_id_id(FunctionCallInfo fcinfo);
extern Datum pg_has_role_name(FunctionCallInfo fcinfo);
extern Datum pg_has_role_id(FunctionCallInfo fcinfo);


extern Datum boolin(FunctionCallInfo fcinfo);
extern Datum boolout(FunctionCallInfo fcinfo);
extern Datum boolrecv(FunctionCallInfo fcinfo);
extern Datum boolsend(FunctionCallInfo fcinfo);
extern Datum booltext(FunctionCallInfo fcinfo);
extern Datum booleq(FunctionCallInfo fcinfo);
extern Datum boolne(FunctionCallInfo fcinfo);
extern Datum boollt(FunctionCallInfo fcinfo);
extern Datum boolgt(FunctionCallInfo fcinfo);
extern Datum boolle(FunctionCallInfo fcinfo);
extern Datum boolge(FunctionCallInfo fcinfo);
extern Datum booland_statefunc(FunctionCallInfo fcinfo);
extern Datum boolor_statefunc(FunctionCallInfo fcinfo);
extern bool parse_bool(const char *value, bool *result);
extern bool parse_bool_with_len(const char *value, size_t len, bool *result);


extern Datum charin(FunctionCallInfo fcinfo);
extern Datum charout(FunctionCallInfo fcinfo);
extern Datum charrecv(FunctionCallInfo fcinfo);
extern Datum charsend(FunctionCallInfo fcinfo);
extern Datum chareq(FunctionCallInfo fcinfo);
extern Datum charne(FunctionCallInfo fcinfo);
extern Datum charlt(FunctionCallInfo fcinfo);
extern Datum charle(FunctionCallInfo fcinfo);
extern Datum chargt(FunctionCallInfo fcinfo);
extern Datum charge(FunctionCallInfo fcinfo);
extern Datum chartoi4(FunctionCallInfo fcinfo);
extern Datum i4tochar(FunctionCallInfo fcinfo);
extern Datum text_char(FunctionCallInfo fcinfo);
extern Datum char_text(FunctionCallInfo fcinfo);


extern Datum domain_in(FunctionCallInfo fcinfo);
extern Datum domain_recv(FunctionCallInfo fcinfo);
extern void domain_check(Datum value, bool isnull, Oid domainType, void **extra, MemoryContext mcxt);


extern Datum binary_encode(FunctionCallInfo fcinfo);
extern Datum binary_decode(FunctionCallInfo fcinfo);
extern unsigned hex_encode(const char *src, unsigned len, char *dst);
extern unsigned hex_decode(const char *src, unsigned len, char *dst);


extern Datum enum_in(FunctionCallInfo fcinfo);
extern Datum enum_out(FunctionCallInfo fcinfo);
extern Datum enum_recv(FunctionCallInfo fcinfo);
extern Datum enum_send(FunctionCallInfo fcinfo);
extern Datum enum_lt(FunctionCallInfo fcinfo);
extern Datum enum_le(FunctionCallInfo fcinfo);
extern Datum enum_eq(FunctionCallInfo fcinfo);
extern Datum enum_ne(FunctionCallInfo fcinfo);
extern Datum enum_ge(FunctionCallInfo fcinfo);
extern Datum enum_gt(FunctionCallInfo fcinfo);
extern Datum enum_cmp(FunctionCallInfo fcinfo);
extern Datum enum_smaller(FunctionCallInfo fcinfo);
extern Datum enum_larger(FunctionCallInfo fcinfo);
extern Datum enum_first(FunctionCallInfo fcinfo);
extern Datum enum_last(FunctionCallInfo fcinfo);
extern Datum enum_range_bounds(FunctionCallInfo fcinfo);
extern Datum enum_range_all(FunctionCallInfo fcinfo);


extern Datum int2in(FunctionCallInfo fcinfo);
extern Datum int2out(FunctionCallInfo fcinfo);
extern Datum int2recv(FunctionCallInfo fcinfo);
extern Datum int2send(FunctionCallInfo fcinfo);
extern Datum int2vectorin(FunctionCallInfo fcinfo);
extern Datum int2vectorout(FunctionCallInfo fcinfo);
extern Datum int2vectorrecv(FunctionCallInfo fcinfo);
extern Datum int2vectorsend(FunctionCallInfo fcinfo);
extern Datum int2vectoreq(FunctionCallInfo fcinfo);
extern Datum int4in(FunctionCallInfo fcinfo);
extern Datum int4out(FunctionCallInfo fcinfo);
extern Datum int4recv(FunctionCallInfo fcinfo);
extern Datum int4send(FunctionCallInfo fcinfo);
extern Datum i2toi4(FunctionCallInfo fcinfo);
extern Datum i4toi2(FunctionCallInfo fcinfo);
extern Datum int4_bool(FunctionCallInfo fcinfo);
extern Datum bool_int4(FunctionCallInfo fcinfo);
extern Datum int4eq(FunctionCallInfo fcinfo);
extern Datum int4ne(FunctionCallInfo fcinfo);
extern Datum int4lt(FunctionCallInfo fcinfo);
extern Datum int4le(FunctionCallInfo fcinfo);
extern Datum int4gt(FunctionCallInfo fcinfo);
extern Datum int4ge(FunctionCallInfo fcinfo);
extern Datum int2eq(FunctionCallInfo fcinfo);
extern Datum int2ne(FunctionCallInfo fcinfo);
extern Datum int2lt(FunctionCallInfo fcinfo);
extern Datum int2le(FunctionCallInfo fcinfo);
extern Datum int2gt(FunctionCallInfo fcinfo);
extern Datum int2ge(FunctionCallInfo fcinfo);
extern Datum int24eq(FunctionCallInfo fcinfo);
extern Datum int24ne(FunctionCallInfo fcinfo);
extern Datum int24lt(FunctionCallInfo fcinfo);
extern Datum int24le(FunctionCallInfo fcinfo);
extern Datum int24gt(FunctionCallInfo fcinfo);
extern Datum int24ge(FunctionCallInfo fcinfo);
extern Datum int42eq(FunctionCallInfo fcinfo);
extern Datum int42ne(FunctionCallInfo fcinfo);
extern Datum int42lt(FunctionCallInfo fcinfo);
extern Datum int42le(FunctionCallInfo fcinfo);
extern Datum int42gt(FunctionCallInfo fcinfo);
extern Datum int42ge(FunctionCallInfo fcinfo);
extern Datum int4um(FunctionCallInfo fcinfo);
extern Datum int4up(FunctionCallInfo fcinfo);
extern Datum int4pl(FunctionCallInfo fcinfo);
extern Datum int4mi(FunctionCallInfo fcinfo);
extern Datum int4mul(FunctionCallInfo fcinfo);
extern Datum int4div(FunctionCallInfo fcinfo);
extern Datum int4abs(FunctionCallInfo fcinfo);
extern Datum int4inc(FunctionCallInfo fcinfo);
extern Datum int2um(FunctionCallInfo fcinfo);
extern Datum int2up(FunctionCallInfo fcinfo);
extern Datum int2pl(FunctionCallInfo fcinfo);
extern Datum int2mi(FunctionCallInfo fcinfo);
extern Datum int2mul(FunctionCallInfo fcinfo);
extern Datum int2div(FunctionCallInfo fcinfo);
extern Datum int2abs(FunctionCallInfo fcinfo);
extern Datum int24pl(FunctionCallInfo fcinfo);
extern Datum int24mi(FunctionCallInfo fcinfo);
extern Datum int24mul(FunctionCallInfo fcinfo);
extern Datum int24div(FunctionCallInfo fcinfo);
extern Datum int42pl(FunctionCallInfo fcinfo);
extern Datum int42mi(FunctionCallInfo fcinfo);
extern Datum int42mul(FunctionCallInfo fcinfo);
extern Datum int42div(FunctionCallInfo fcinfo);
extern Datum int4mod(FunctionCallInfo fcinfo);
extern Datum int2mod(FunctionCallInfo fcinfo);
extern Datum int2larger(FunctionCallInfo fcinfo);
extern Datum int2smaller(FunctionCallInfo fcinfo);
extern Datum int4larger(FunctionCallInfo fcinfo);
extern Datum int4smaller(FunctionCallInfo fcinfo);

extern Datum int4and(FunctionCallInfo fcinfo);
extern Datum int4or(FunctionCallInfo fcinfo);
extern Datum int4xor(FunctionCallInfo fcinfo);
extern Datum int4not(FunctionCallInfo fcinfo);
extern Datum int4shl(FunctionCallInfo fcinfo);
extern Datum int4shr(FunctionCallInfo fcinfo);
extern Datum int2and(FunctionCallInfo fcinfo);
extern Datum int2or(FunctionCallInfo fcinfo);
extern Datum int2xor(FunctionCallInfo fcinfo);
extern Datum int2not(FunctionCallInfo fcinfo);
extern Datum int2shl(FunctionCallInfo fcinfo);
extern Datum int2shr(FunctionCallInfo fcinfo);
extern Datum generate_series_int4(FunctionCallInfo fcinfo);
extern Datum generate_series_step_int4(FunctionCallInfo fcinfo);
extern int2vector *buildint2vector(const int2 *int2s, int n);


extern Datum namein(FunctionCallInfo fcinfo);
extern Datum nameout(FunctionCallInfo fcinfo);
extern Datum namerecv(FunctionCallInfo fcinfo);
extern Datum namesend(FunctionCallInfo fcinfo);
extern Datum nameeq(FunctionCallInfo fcinfo);
extern Datum namene(FunctionCallInfo fcinfo);
extern Datum namelt(FunctionCallInfo fcinfo);
extern Datum namele(FunctionCallInfo fcinfo);
extern Datum namegt(FunctionCallInfo fcinfo);
extern Datum namege(FunctionCallInfo fcinfo);
extern int namecpy(Name n1, Name n2);
extern int namestrcpy(Name name, const char *str);
extern int namestrcmp(Name name, const char *str);
extern Datum current_user(FunctionCallInfo fcinfo);
extern Datum session_user(FunctionCallInfo fcinfo);
extern Datum current_schema(FunctionCallInfo fcinfo);
extern Datum current_schemas(FunctionCallInfo fcinfo);


extern int32 pg_atoi(char *s, int size, int c);
extern void pg_itoa(int16 i, char *a);
extern void pg_ltoa(int32 l, char *a);
extern void pg_lltoa(int64 ll, char *a);





extern Datum btboolcmp(FunctionCallInfo fcinfo);
extern Datum btint2cmp(FunctionCallInfo fcinfo);
extern Datum btint4cmp(FunctionCallInfo fcinfo);
extern Datum btint8cmp(FunctionCallInfo fcinfo);
extern Datum btfloat4cmp(FunctionCallInfo fcinfo);
extern Datum btfloat8cmp(FunctionCallInfo fcinfo);
extern Datum btint48cmp(FunctionCallInfo fcinfo);
extern Datum btint84cmp(FunctionCallInfo fcinfo);
extern Datum btint24cmp(FunctionCallInfo fcinfo);
extern Datum btint42cmp(FunctionCallInfo fcinfo);
extern Datum btint28cmp(FunctionCallInfo fcinfo);
extern Datum btint82cmp(FunctionCallInfo fcinfo);
extern Datum btfloat48cmp(FunctionCallInfo fcinfo);
extern Datum btfloat84cmp(FunctionCallInfo fcinfo);
extern Datum btoidcmp(FunctionCallInfo fcinfo);
extern Datum btoidvectorcmp(FunctionCallInfo fcinfo);
extern Datum btabstimecmp(FunctionCallInfo fcinfo);
extern Datum btreltimecmp(FunctionCallInfo fcinfo);
extern Datum bttintervalcmp(FunctionCallInfo fcinfo);
extern Datum btcharcmp(FunctionCallInfo fcinfo);
extern Datum btnamecmp(FunctionCallInfo fcinfo);
extern Datum bttextcmp(FunctionCallInfo fcinfo);






extern Datum btint2sortsupport(FunctionCallInfo fcinfo);
extern Datum btint4sortsupport(FunctionCallInfo fcinfo);
extern Datum btint8sortsupport(FunctionCallInfo fcinfo);
extern Datum btfloat4sortsupport(FunctionCallInfo fcinfo);
extern Datum btfloat8sortsupport(FunctionCallInfo fcinfo);
extern Datum btoidsortsupport(FunctionCallInfo fcinfo);
extern Datum btnamesortsupport(FunctionCallInfo fcinfo);


extern int extra_float_digits;

extern double get_float8_infinity(void);
extern float get_float4_infinity(void);
extern double get_float8_nan(void);
extern float get_float4_nan(void);
extern int is_infinite(double val);

extern Datum float4in(FunctionCallInfo fcinfo);
extern Datum float4out(FunctionCallInfo fcinfo);
extern Datum float4recv(FunctionCallInfo fcinfo);
extern Datum float4send(FunctionCallInfo fcinfo);
extern Datum float8in(FunctionCallInfo fcinfo);
extern Datum float8out(FunctionCallInfo fcinfo);
extern Datum float8recv(FunctionCallInfo fcinfo);
extern Datum float8send(FunctionCallInfo fcinfo);
extern Datum float4abs(FunctionCallInfo fcinfo);
extern Datum float4um(FunctionCallInfo fcinfo);
extern Datum float4up(FunctionCallInfo fcinfo);
extern Datum float4larger(FunctionCallInfo fcinfo);
extern Datum float4smaller(FunctionCallInfo fcinfo);
extern Datum float8abs(FunctionCallInfo fcinfo);
extern Datum float8um(FunctionCallInfo fcinfo);
extern Datum float8up(FunctionCallInfo fcinfo);
extern Datum float8larger(FunctionCallInfo fcinfo);
extern Datum float8smaller(FunctionCallInfo fcinfo);
extern Datum float4pl(FunctionCallInfo fcinfo);
extern Datum float4mi(FunctionCallInfo fcinfo);
extern Datum float4mul(FunctionCallInfo fcinfo);
extern Datum float4div(FunctionCallInfo fcinfo);
extern Datum float8pl(FunctionCallInfo fcinfo);
extern Datum float8mi(FunctionCallInfo fcinfo);
extern Datum float8mul(FunctionCallInfo fcinfo);
extern Datum float8div(FunctionCallInfo fcinfo);
extern Datum float4eq(FunctionCallInfo fcinfo);
extern Datum float4ne(FunctionCallInfo fcinfo);
extern Datum float4lt(FunctionCallInfo fcinfo);
extern Datum float4le(FunctionCallInfo fcinfo);
extern Datum float4gt(FunctionCallInfo fcinfo);
extern Datum float4ge(FunctionCallInfo fcinfo);
extern Datum float8eq(FunctionCallInfo fcinfo);
extern Datum float8ne(FunctionCallInfo fcinfo);
extern Datum float8lt(FunctionCallInfo fcinfo);
extern Datum float8le(FunctionCallInfo fcinfo);
extern Datum float8gt(FunctionCallInfo fcinfo);
extern Datum float8ge(FunctionCallInfo fcinfo);
extern Datum ftod(FunctionCallInfo fcinfo);
extern Datum i4tod(FunctionCallInfo fcinfo);
extern Datum i2tod(FunctionCallInfo fcinfo);
extern Datum dtof(FunctionCallInfo fcinfo);
extern Datum dtoi4(FunctionCallInfo fcinfo);
extern Datum dtoi2(FunctionCallInfo fcinfo);
extern Datum i4tof(FunctionCallInfo fcinfo);
extern Datum i2tof(FunctionCallInfo fcinfo);
extern Datum ftoi4(FunctionCallInfo fcinfo);
extern Datum ftoi2(FunctionCallInfo fcinfo);
extern Datum dround(FunctionCallInfo fcinfo);
extern Datum dceil(FunctionCallInfo fcinfo);
extern Datum dfloor(FunctionCallInfo fcinfo);
extern Datum dsign(FunctionCallInfo fcinfo);
extern Datum dtrunc(FunctionCallInfo fcinfo);
extern Datum dsqrt(FunctionCallInfo fcinfo);
extern Datum dcbrt(FunctionCallInfo fcinfo);
extern Datum dpow(FunctionCallInfo fcinfo);
extern Datum dexp(FunctionCallInfo fcinfo);
extern Datum dlog1(FunctionCallInfo fcinfo);
extern Datum dlog10(FunctionCallInfo fcinfo);
extern Datum dacos(FunctionCallInfo fcinfo);
extern Datum dasin(FunctionCallInfo fcinfo);
extern Datum datan(FunctionCallInfo fcinfo);
extern Datum datan2(FunctionCallInfo fcinfo);
extern Datum dcos(FunctionCallInfo fcinfo);
extern Datum dcot(FunctionCallInfo fcinfo);
extern Datum dsin(FunctionCallInfo fcinfo);
extern Datum dtan(FunctionCallInfo fcinfo);
extern Datum degrees(FunctionCallInfo fcinfo);
extern Datum dpi(FunctionCallInfo fcinfo);
extern Datum radians(FunctionCallInfo fcinfo);
extern Datum drandom(FunctionCallInfo fcinfo);
extern Datum setseed(FunctionCallInfo fcinfo);
extern Datum float8_accum(FunctionCallInfo fcinfo);
extern Datum float4_accum(FunctionCallInfo fcinfo);
extern Datum float8_avg(FunctionCallInfo fcinfo);
extern Datum float8_var_pop(FunctionCallInfo fcinfo);
extern Datum float8_var_samp(FunctionCallInfo fcinfo);
extern Datum float8_stddev_pop(FunctionCallInfo fcinfo);
extern Datum float8_stddev_samp(FunctionCallInfo fcinfo);
extern Datum float8_regr_accum(FunctionCallInfo fcinfo);
extern Datum float8_regr_sxx(FunctionCallInfo fcinfo);
extern Datum float8_regr_syy(FunctionCallInfo fcinfo);
extern Datum float8_regr_sxy(FunctionCallInfo fcinfo);
extern Datum float8_regr_avgx(FunctionCallInfo fcinfo);
extern Datum float8_regr_avgy(FunctionCallInfo fcinfo);
extern Datum float8_covar_pop(FunctionCallInfo fcinfo);
extern Datum float8_covar_samp(FunctionCallInfo fcinfo);
extern Datum float8_corr(FunctionCallInfo fcinfo);
extern Datum float8_regr_r2(FunctionCallInfo fcinfo);
extern Datum float8_regr_slope(FunctionCallInfo fcinfo);
extern Datum float8_regr_intercept(FunctionCallInfo fcinfo);
extern Datum float48pl(FunctionCallInfo fcinfo);
extern Datum float48mi(FunctionCallInfo fcinfo);
extern Datum float48mul(FunctionCallInfo fcinfo);
extern Datum float48div(FunctionCallInfo fcinfo);
extern Datum float84pl(FunctionCallInfo fcinfo);
extern Datum float84mi(FunctionCallInfo fcinfo);
extern Datum float84mul(FunctionCallInfo fcinfo);
extern Datum float84div(FunctionCallInfo fcinfo);
extern Datum float48eq(FunctionCallInfo fcinfo);
extern Datum float48ne(FunctionCallInfo fcinfo);
extern Datum float48lt(FunctionCallInfo fcinfo);
extern Datum float48le(FunctionCallInfo fcinfo);
extern Datum float48gt(FunctionCallInfo fcinfo);
extern Datum float48ge(FunctionCallInfo fcinfo);
extern Datum float84eq(FunctionCallInfo fcinfo);
extern Datum float84ne(FunctionCallInfo fcinfo);
extern Datum float84lt(FunctionCallInfo fcinfo);
extern Datum float84le(FunctionCallInfo fcinfo);
extern Datum float84gt(FunctionCallInfo fcinfo);
extern Datum float84ge(FunctionCallInfo fcinfo);
extern Datum width_bucket_float8(FunctionCallInfo fcinfo);


extern Datum pg_tablespace_size_oid(FunctionCallInfo fcinfo);
extern Datum pg_tablespace_size_name(FunctionCallInfo fcinfo);
extern Datum pg_database_size_oid(FunctionCallInfo fcinfo);
extern Datum pg_database_size_name(FunctionCallInfo fcinfo);
extern Datum pg_relation_size(FunctionCallInfo fcinfo);
extern Datum pg_total_relation_size(FunctionCallInfo fcinfo);
extern Datum pg_size_pretty(FunctionCallInfo fcinfo);
extern Datum pg_size_pretty_numeric(FunctionCallInfo fcinfo);
extern Datum pg_table_size(FunctionCallInfo fcinfo);
extern Datum pg_indexes_size(FunctionCallInfo fcinfo);
extern Datum pg_relation_filenode(FunctionCallInfo fcinfo);
extern Datum pg_relation_filepath(FunctionCallInfo fcinfo);


extern bytea *read_binary_file(const char *filename,
     int64 seek_offset, int64 bytes_to_read);
extern Datum pg_stat_file(FunctionCallInfo fcinfo);
extern Datum pg_read_file(FunctionCallInfo fcinfo);
extern Datum pg_read_file_all(FunctionCallInfo fcinfo);
extern Datum pg_read_binary_file(FunctionCallInfo fcinfo);
extern Datum pg_read_binary_file_all(FunctionCallInfo fcinfo);
extern Datum pg_ls_dir(FunctionCallInfo fcinfo);


extern Datum current_database(FunctionCallInfo fcinfo);
extern Datum current_query(FunctionCallInfo fcinfo);
extern Datum pg_cancel_backend(FunctionCallInfo fcinfo);
extern Datum pg_terminate_backend(FunctionCallInfo fcinfo);
extern Datum pg_reload_conf(FunctionCallInfo fcinfo);
extern Datum pg_tablespace_databases(FunctionCallInfo fcinfo);
extern Datum pg_tablespace_location(FunctionCallInfo fcinfo);
extern Datum pg_rotate_logfile(FunctionCallInfo fcinfo);
extern Datum pg_sleep(FunctionCallInfo fcinfo);
extern Datum pg_get_keywords(FunctionCallInfo fcinfo);
extern Datum pg_typeof(FunctionCallInfo fcinfo);
extern Datum pg_collation_for(FunctionCallInfo fcinfo);


extern Datum oidin(FunctionCallInfo fcinfo);
extern Datum oidout(FunctionCallInfo fcinfo);
extern Datum oidrecv(FunctionCallInfo fcinfo);
extern Datum oidsend(FunctionCallInfo fcinfo);
extern Datum oideq(FunctionCallInfo fcinfo);
extern Datum oidne(FunctionCallInfo fcinfo);
extern Datum oidlt(FunctionCallInfo fcinfo);
extern Datum oidle(FunctionCallInfo fcinfo);
extern Datum oidge(FunctionCallInfo fcinfo);
extern Datum oidgt(FunctionCallInfo fcinfo);
extern Datum oidlarger(FunctionCallInfo fcinfo);
extern Datum oidsmaller(FunctionCallInfo fcinfo);
extern Datum oidvectorin(FunctionCallInfo fcinfo);
extern Datum oidvectorout(FunctionCallInfo fcinfo);
extern Datum oidvectorrecv(FunctionCallInfo fcinfo);
extern Datum oidvectorsend(FunctionCallInfo fcinfo);
extern Datum oidvectoreq(FunctionCallInfo fcinfo);
extern Datum oidvectorne(FunctionCallInfo fcinfo);
extern Datum oidvectorlt(FunctionCallInfo fcinfo);
extern Datum oidvectorle(FunctionCallInfo fcinfo);
extern Datum oidvectorge(FunctionCallInfo fcinfo);
extern Datum oidvectorgt(FunctionCallInfo fcinfo);
extern oidvector *buildoidvector(const Oid *oids, int n);
extern Oid oidparse(Node *node);


extern Datum cstring_in(FunctionCallInfo fcinfo);
extern Datum cstring_out(FunctionCallInfo fcinfo);
extern Datum cstring_recv(FunctionCallInfo fcinfo);
extern Datum cstring_send(FunctionCallInfo fcinfo);
extern Datum any_in(FunctionCallInfo fcinfo);
extern Datum any_out(FunctionCallInfo fcinfo);
extern Datum anyarray_in(FunctionCallInfo fcinfo);
extern Datum anyarray_out(FunctionCallInfo fcinfo);
extern Datum anyarray_recv(FunctionCallInfo fcinfo);
extern Datum anyarray_send(FunctionCallInfo fcinfo);
extern Datum anynonarray_in(FunctionCallInfo fcinfo);
extern Datum anynonarray_out(FunctionCallInfo fcinfo);
extern Datum anyenum_in(FunctionCallInfo fcinfo);
extern Datum anyenum_out(FunctionCallInfo fcinfo);
extern Datum anyrange_in(FunctionCallInfo fcinfo);
extern Datum anyrange_out(FunctionCallInfo fcinfo);
extern Datum void_in(FunctionCallInfo fcinfo);
extern Datum void_out(FunctionCallInfo fcinfo);
extern Datum void_recv(FunctionCallInfo fcinfo);
extern Datum void_send(FunctionCallInfo fcinfo);
extern Datum trigger_in(FunctionCallInfo fcinfo);
extern Datum trigger_out(FunctionCallInfo fcinfo);
extern Datum language_handler_in(FunctionCallInfo fcinfo);
extern Datum language_handler_out(FunctionCallInfo fcinfo);
extern Datum fdw_handler_in(FunctionCallInfo fcinfo);
extern Datum fdw_handler_out(FunctionCallInfo fcinfo);
extern Datum internal_in(FunctionCallInfo fcinfo);
extern Datum internal_out(FunctionCallInfo fcinfo);
extern Datum opaque_in(FunctionCallInfo fcinfo);
extern Datum opaque_out(FunctionCallInfo fcinfo);
extern Datum anyelement_in(FunctionCallInfo fcinfo);
extern Datum anyelement_out(FunctionCallInfo fcinfo);
extern Datum shell_in(FunctionCallInfo fcinfo);
extern Datum shell_out(FunctionCallInfo fcinfo);
extern Datum pg_node_tree_in(FunctionCallInfo fcinfo);
extern Datum pg_node_tree_out(FunctionCallInfo fcinfo);
extern Datum pg_node_tree_recv(FunctionCallInfo fcinfo);
extern Datum pg_node_tree_send(FunctionCallInfo fcinfo);


extern Datum nameregexeq(FunctionCallInfo fcinfo);
extern Datum nameregexne(FunctionCallInfo fcinfo);
extern Datum textregexeq(FunctionCallInfo fcinfo);
extern Datum textregexne(FunctionCallInfo fcinfo);
extern Datum nameicregexeq(FunctionCallInfo fcinfo);
extern Datum nameicregexne(FunctionCallInfo fcinfo);
extern Datum texticregexeq(FunctionCallInfo fcinfo);
extern Datum texticregexne(FunctionCallInfo fcinfo);
extern Datum textregexsubstr(FunctionCallInfo fcinfo);
extern Datum textregexreplace_noopt(FunctionCallInfo fcinfo);
extern Datum textregexreplace(FunctionCallInfo fcinfo);
extern Datum similar_escape(FunctionCallInfo fcinfo);
extern Datum regexp_matches(FunctionCallInfo fcinfo);
extern Datum regexp_matches_no_flags(FunctionCallInfo fcinfo);
extern Datum regexp_split_to_table(FunctionCallInfo fcinfo);
extern Datum regexp_split_to_table_no_flags(FunctionCallInfo fcinfo);
extern Datum regexp_split_to_array(FunctionCallInfo fcinfo);
extern Datum regexp_split_to_array_no_flags(FunctionCallInfo fcinfo);
extern char *regexp_fixed_prefix(text *text_re, bool case_insensitive,
         Oid collation, bool *exact);


extern Datum regprocin(FunctionCallInfo fcinfo);
extern Datum regprocout(FunctionCallInfo fcinfo);
extern Datum regprocrecv(FunctionCallInfo fcinfo);
extern Datum regprocsend(FunctionCallInfo fcinfo);
extern Datum regprocedurein(FunctionCallInfo fcinfo);
extern Datum regprocedureout(FunctionCallInfo fcinfo);
extern Datum regprocedurerecv(FunctionCallInfo fcinfo);
extern Datum regproceduresend(FunctionCallInfo fcinfo);
extern Datum regoperin(FunctionCallInfo fcinfo);
extern Datum regoperout(FunctionCallInfo fcinfo);
extern Datum regoperrecv(FunctionCallInfo fcinfo);
extern Datum regopersend(FunctionCallInfo fcinfo);
extern Datum regoperatorin(FunctionCallInfo fcinfo);
extern Datum regoperatorout(FunctionCallInfo fcinfo);
extern Datum regoperatorrecv(FunctionCallInfo fcinfo);
extern Datum regoperatorsend(FunctionCallInfo fcinfo);
extern Datum regclassin(FunctionCallInfo fcinfo);
extern Datum regclassout(FunctionCallInfo fcinfo);
extern Datum regclassrecv(FunctionCallInfo fcinfo);
extern Datum regclasssend(FunctionCallInfo fcinfo);
extern Datum regtypein(FunctionCallInfo fcinfo);
extern Datum regtypeout(FunctionCallInfo fcinfo);
extern Datum regtyperecv(FunctionCallInfo fcinfo);
extern Datum regtypesend(FunctionCallInfo fcinfo);
extern Datum regconfigin(FunctionCallInfo fcinfo);
extern Datum regconfigout(FunctionCallInfo fcinfo);
extern Datum regconfigrecv(FunctionCallInfo fcinfo);
extern Datum regconfigsend(FunctionCallInfo fcinfo);
extern Datum regdictionaryin(FunctionCallInfo fcinfo);
extern Datum regdictionaryout(FunctionCallInfo fcinfo);
extern Datum regdictionaryrecv(FunctionCallInfo fcinfo);
extern Datum regdictionarysend(FunctionCallInfo fcinfo);
extern Datum text_regclass(FunctionCallInfo fcinfo);
extern List *stringToQualifiedNameList(const char *string);
extern char *format_procedure(Oid procedure_oid);
extern char *format_operator(Oid operator_oid);


extern Datum record_in(FunctionCallInfo fcinfo);
extern Datum record_out(FunctionCallInfo fcinfo);
extern Datum record_recv(FunctionCallInfo fcinfo);
extern Datum record_send(FunctionCallInfo fcinfo);
extern Datum record_eq(FunctionCallInfo fcinfo);
extern Datum record_ne(FunctionCallInfo fcinfo);
extern Datum record_lt(FunctionCallInfo fcinfo);
extern Datum record_gt(FunctionCallInfo fcinfo);
extern Datum record_le(FunctionCallInfo fcinfo);
extern Datum record_ge(FunctionCallInfo fcinfo);
extern Datum btrecordcmp(FunctionCallInfo fcinfo);


extern bool quote_all_identifiers;
extern Datum pg_get_ruledef(FunctionCallInfo fcinfo);
extern Datum pg_get_ruledef_ext(FunctionCallInfo fcinfo);
extern Datum pg_get_viewdef(FunctionCallInfo fcinfo);
extern Datum pg_get_viewdef_ext(FunctionCallInfo fcinfo);
extern Datum pg_get_viewdef_wrap(FunctionCallInfo fcinfo);
extern Datum pg_get_viewdef_name(FunctionCallInfo fcinfo);
extern Datum pg_get_viewdef_name_ext(FunctionCallInfo fcinfo);
extern Datum pg_get_indexdef(FunctionCallInfo fcinfo);
extern Datum pg_get_indexdef_ext(FunctionCallInfo fcinfo);
extern char *pg_get_indexdef_string(Oid indexrelid);
extern char *pg_get_indexdef_columns(Oid indexrelid, bool pretty);
extern Datum pg_get_triggerdef(FunctionCallInfo fcinfo);
extern Datum pg_get_triggerdef_ext(FunctionCallInfo fcinfo);
extern Datum pg_get_constraintdef(FunctionCallInfo fcinfo);
extern Datum pg_get_constraintdef_ext(FunctionCallInfo fcinfo);
extern char *pg_get_constraintdef_string(Oid constraintId);
extern Datum pg_get_expr(FunctionCallInfo fcinfo);
extern Datum pg_get_expr_ext(FunctionCallInfo fcinfo);
extern Datum pg_get_userbyid(FunctionCallInfo fcinfo);
extern Datum pg_get_serial_sequence(FunctionCallInfo fcinfo);
extern Datum pg_get_functiondef(FunctionCallInfo fcinfo);
extern Datum pg_get_function_arguments(FunctionCallInfo fcinfo);
extern Datum pg_get_function_identity_arguments(FunctionCallInfo fcinfo);
extern Datum pg_get_function_result(FunctionCallInfo fcinfo);
extern char *deparse_expression(Node *expr, List *dpcontext,
       bool forceprefix, bool showimplicit);
extern List *deparse_context_for(const char *aliasname, Oid relid);
extern List *deparse_context_for_planstate(Node *planstate, List *ancestors,
         List *rtable);
extern const char *quote_identifier(const char *ident);
extern char *quote_qualified_identifier(const char *qualifier,
         const char *ident);
extern char *generate_collation_name(Oid collid);



extern Datum tidin(FunctionCallInfo fcinfo);
extern Datum tidout(FunctionCallInfo fcinfo);
extern Datum tidrecv(FunctionCallInfo fcinfo);
extern Datum tidsend(FunctionCallInfo fcinfo);
extern Datum tideq(FunctionCallInfo fcinfo);
extern Datum tidne(FunctionCallInfo fcinfo);
extern Datum tidlt(FunctionCallInfo fcinfo);
extern Datum tidle(FunctionCallInfo fcinfo);
extern Datum tidgt(FunctionCallInfo fcinfo);
extern Datum tidge(FunctionCallInfo fcinfo);
extern Datum bttidcmp(FunctionCallInfo fcinfo);
extern Datum tidlarger(FunctionCallInfo fcinfo);
extern Datum tidsmaller(FunctionCallInfo fcinfo);
extern Datum currtid_byreloid(FunctionCallInfo fcinfo);
extern Datum currtid_byrelname(FunctionCallInfo fcinfo);


extern Datum bpcharin(FunctionCallInfo fcinfo);
extern Datum bpcharout(FunctionCallInfo fcinfo);
extern Datum bpcharrecv(FunctionCallInfo fcinfo);
extern Datum bpcharsend(FunctionCallInfo fcinfo);
extern Datum bpchartypmodin(FunctionCallInfo fcinfo);
extern Datum bpchartypmodout(FunctionCallInfo fcinfo);
extern Datum bpchar(FunctionCallInfo fcinfo);
extern Datum char_bpchar(FunctionCallInfo fcinfo);
extern Datum name_bpchar(FunctionCallInfo fcinfo);
extern Datum bpchar_name(FunctionCallInfo fcinfo);
extern Datum bpchareq(FunctionCallInfo fcinfo);
extern Datum bpcharne(FunctionCallInfo fcinfo);
extern Datum bpcharlt(FunctionCallInfo fcinfo);
extern Datum bpcharle(FunctionCallInfo fcinfo);
extern Datum bpchargt(FunctionCallInfo fcinfo);
extern Datum bpcharge(FunctionCallInfo fcinfo);
extern Datum bpcharcmp(FunctionCallInfo fcinfo);
extern Datum bpchar_larger(FunctionCallInfo fcinfo);
extern Datum bpchar_smaller(FunctionCallInfo fcinfo);
extern Datum bpcharlen(FunctionCallInfo fcinfo);
extern Datum bpcharoctetlen(FunctionCallInfo fcinfo);
extern Datum hashbpchar(FunctionCallInfo fcinfo);
extern Datum bpchar_pattern_lt(FunctionCallInfo fcinfo);
extern Datum bpchar_pattern_le(FunctionCallInfo fcinfo);
extern Datum bpchar_pattern_gt(FunctionCallInfo fcinfo);
extern Datum bpchar_pattern_ge(FunctionCallInfo fcinfo);
extern Datum btbpchar_pattern_cmp(FunctionCallInfo fcinfo);

extern Datum varcharin(FunctionCallInfo fcinfo);
extern Datum varcharout(FunctionCallInfo fcinfo);
extern Datum varcharrecv(FunctionCallInfo fcinfo);
extern Datum varcharsend(FunctionCallInfo fcinfo);
extern Datum varchartypmodin(FunctionCallInfo fcinfo);
extern Datum varchartypmodout(FunctionCallInfo fcinfo);
extern Datum varchar_transform(FunctionCallInfo fcinfo);
extern Datum varchar(FunctionCallInfo fcinfo);


extern text *cstring_to_text(const char *s);
extern text *cstring_to_text_with_len(const char *s, int len);
extern char *text_to_cstring(const text *t);
extern void text_to_cstring_buffer(const text *src, char *dst, size_t dst_len);




extern Datum textin(FunctionCallInfo fcinfo);
extern Datum textout(FunctionCallInfo fcinfo);
extern Datum textrecv(FunctionCallInfo fcinfo);
extern Datum textsend(FunctionCallInfo fcinfo);
extern Datum textcat(FunctionCallInfo fcinfo);
extern Datum texteq(FunctionCallInfo fcinfo);
extern Datum textne(FunctionCallInfo fcinfo);
extern Datum text_lt(FunctionCallInfo fcinfo);
extern Datum text_le(FunctionCallInfo fcinfo);
extern Datum text_gt(FunctionCallInfo fcinfo);
extern Datum text_ge(FunctionCallInfo fcinfo);
extern Datum text_larger(FunctionCallInfo fcinfo);
extern Datum text_smaller(FunctionCallInfo fcinfo);
extern Datum text_pattern_lt(FunctionCallInfo fcinfo);
extern Datum text_pattern_le(FunctionCallInfo fcinfo);
extern Datum text_pattern_gt(FunctionCallInfo fcinfo);
extern Datum text_pattern_ge(FunctionCallInfo fcinfo);
extern Datum bttext_pattern_cmp(FunctionCallInfo fcinfo);
extern Datum textlen(FunctionCallInfo fcinfo);
extern Datum textoctetlen(FunctionCallInfo fcinfo);
extern Datum textpos(FunctionCallInfo fcinfo);
extern Datum text_substr(FunctionCallInfo fcinfo);
extern Datum text_substr_no_len(FunctionCallInfo fcinfo);
extern Datum textoverlay(FunctionCallInfo fcinfo);
extern Datum textoverlay_no_len(FunctionCallInfo fcinfo);
extern Datum name_text(FunctionCallInfo fcinfo);
extern Datum text_name(FunctionCallInfo fcinfo);
extern int varstr_cmp(char *arg1, int len1, char *arg2, int len2, Oid collid);
extern List *textToQualifiedNameList(text *textval);
extern bool SplitIdentifierString(char *rawstring, char separator,
       List **namelist);
extern Datum replace_text(FunctionCallInfo fcinfo);
extern text *replace_text_regexp(text *src_text, void *regexp,
     text *replace_text, bool glob);
extern Datum split_text(FunctionCallInfo fcinfo);
extern Datum text_to_array(FunctionCallInfo fcinfo);
extern Datum array_to_text(FunctionCallInfo fcinfo);
extern Datum text_to_array_null(FunctionCallInfo fcinfo);
extern Datum array_to_text_null(FunctionCallInfo fcinfo);
extern Datum to_hex32(FunctionCallInfo fcinfo);
extern Datum to_hex64(FunctionCallInfo fcinfo);
extern Datum md5_text(FunctionCallInfo fcinfo);
extern Datum md5_bytea(FunctionCallInfo fcinfo);

extern Datum unknownin(FunctionCallInfo fcinfo);
extern Datum unknownout(FunctionCallInfo fcinfo);
extern Datum unknownrecv(FunctionCallInfo fcinfo);
extern Datum unknownsend(FunctionCallInfo fcinfo);

extern Datum pg_column_size(FunctionCallInfo fcinfo);

extern Datum bytea_string_agg_transfn(FunctionCallInfo fcinfo);
extern Datum bytea_string_agg_finalfn(FunctionCallInfo fcinfo);
extern Datum string_agg_transfn(FunctionCallInfo fcinfo);
extern Datum string_agg_finalfn(FunctionCallInfo fcinfo);

extern Datum text_concat(FunctionCallInfo fcinfo);
extern Datum text_concat_ws(FunctionCallInfo fcinfo);
extern Datum text_left(FunctionCallInfo fcinfo);
extern Datum text_right(FunctionCallInfo fcinfo);
extern Datum text_reverse(FunctionCallInfo fcinfo);
extern Datum text_format(FunctionCallInfo fcinfo);
extern Datum text_format_nv(FunctionCallInfo fcinfo);


extern Datum pgsql_version(FunctionCallInfo fcinfo);


extern Datum xidin(FunctionCallInfo fcinfo);
extern Datum xidout(FunctionCallInfo fcinfo);
extern Datum xidrecv(FunctionCallInfo fcinfo);
extern Datum xidsend(FunctionCallInfo fcinfo);
extern Datum xideq(FunctionCallInfo fcinfo);
extern Datum xid_age(FunctionCallInfo fcinfo);
extern int xidComparator(const void *arg1, const void *arg2);
extern Datum cidin(FunctionCallInfo fcinfo);
extern Datum cidout(FunctionCallInfo fcinfo);
extern Datum cidrecv(FunctionCallInfo fcinfo);
extern Datum cidsend(FunctionCallInfo fcinfo);
extern Datum cideq(FunctionCallInfo fcinfo);


extern Datum namelike(FunctionCallInfo fcinfo);
extern Datum namenlike(FunctionCallInfo fcinfo);
extern Datum nameiclike(FunctionCallInfo fcinfo);
extern Datum nameicnlike(FunctionCallInfo fcinfo);
extern Datum textlike(FunctionCallInfo fcinfo);
extern Datum textnlike(FunctionCallInfo fcinfo);
extern Datum texticlike(FunctionCallInfo fcinfo);
extern Datum texticnlike(FunctionCallInfo fcinfo);
extern Datum bytealike(FunctionCallInfo fcinfo);
extern Datum byteanlike(FunctionCallInfo fcinfo);
extern Datum like_escape(FunctionCallInfo fcinfo);
extern Datum like_escape_bytea(FunctionCallInfo fcinfo);


extern Datum lower(FunctionCallInfo fcinfo);
extern Datum upper(FunctionCallInfo fcinfo);
extern Datum initcap(FunctionCallInfo fcinfo);
extern Datum lpad(FunctionCallInfo fcinfo);
extern Datum rpad(FunctionCallInfo fcinfo);
extern Datum btrim(FunctionCallInfo fcinfo);
extern Datum btrim1(FunctionCallInfo fcinfo);
extern Datum byteatrim(FunctionCallInfo fcinfo);
extern Datum ltrim(FunctionCallInfo fcinfo);
extern Datum ltrim1(FunctionCallInfo fcinfo);
extern Datum rtrim(FunctionCallInfo fcinfo);
extern Datum rtrim1(FunctionCallInfo fcinfo);
extern Datum translate(FunctionCallInfo fcinfo);
extern Datum chr (FunctionCallInfo fcinfo);
extern Datum repeat(FunctionCallInfo fcinfo);
extern Datum ascii(FunctionCallInfo fcinfo);


extern char *inet_cidr_ntop(int af, const void *src, int bits,
      char *dst, size_t size);


extern int inet_net_pton(int af, const char *src,
     void *dst, size_t size);


extern Datum inet_in(FunctionCallInfo fcinfo);
extern Datum inet_out(FunctionCallInfo fcinfo);
extern Datum inet_recv(FunctionCallInfo fcinfo);
extern Datum inet_send(FunctionCallInfo fcinfo);
extern Datum cidr_in(FunctionCallInfo fcinfo);
extern Datum cidr_out(FunctionCallInfo fcinfo);
extern Datum cidr_recv(FunctionCallInfo fcinfo);
extern Datum cidr_send(FunctionCallInfo fcinfo);
extern Datum network_cmp(FunctionCallInfo fcinfo);
extern Datum network_lt(FunctionCallInfo fcinfo);
extern Datum network_le(FunctionCallInfo fcinfo);
extern Datum network_eq(FunctionCallInfo fcinfo);
extern Datum network_ge(FunctionCallInfo fcinfo);
extern Datum network_gt(FunctionCallInfo fcinfo);
extern Datum network_ne(FunctionCallInfo fcinfo);
extern Datum hashinet(FunctionCallInfo fcinfo);
extern Datum network_sub(FunctionCallInfo fcinfo);
extern Datum network_subeq(FunctionCallInfo fcinfo);
extern Datum network_sup(FunctionCallInfo fcinfo);
extern Datum network_supeq(FunctionCallInfo fcinfo);
extern Datum network_network(FunctionCallInfo fcinfo);
extern Datum network_netmask(FunctionCallInfo fcinfo);
extern Datum network_hostmask(FunctionCallInfo fcinfo);
extern Datum network_masklen(FunctionCallInfo fcinfo);
extern Datum network_family(FunctionCallInfo fcinfo);
extern Datum network_broadcast(FunctionCallInfo fcinfo);
extern Datum network_host(FunctionCallInfo fcinfo);
extern Datum network_show(FunctionCallInfo fcinfo);
extern Datum inet_abbrev(FunctionCallInfo fcinfo);
extern Datum cidr_abbrev(FunctionCallInfo fcinfo);
extern double convert_network_to_scalar(Datum value, Oid typid);
extern Datum inet_to_cidr(FunctionCallInfo fcinfo);
extern Datum inet_set_masklen(FunctionCallInfo fcinfo);
extern Datum cidr_set_masklen(FunctionCallInfo fcinfo);
extern Datum network_scan_first(Datum in);
extern Datum network_scan_last(Datum in);
extern Datum inet_client_addr(FunctionCallInfo fcinfo);
extern Datum inet_client_port(FunctionCallInfo fcinfo);
extern Datum inet_server_addr(FunctionCallInfo fcinfo);
extern Datum inet_server_port(FunctionCallInfo fcinfo);
extern Datum inetnot(FunctionCallInfo fcinfo);
extern Datum inetand(FunctionCallInfo fcinfo);
extern Datum inetor(FunctionCallInfo fcinfo);
extern Datum inetpl(FunctionCallInfo fcinfo);
extern Datum inetmi_int8(FunctionCallInfo fcinfo);
extern Datum inetmi(FunctionCallInfo fcinfo);
extern void clean_ipv6_addr(int addr_family, char *addr);


extern Datum macaddr_in(FunctionCallInfo fcinfo);
extern Datum macaddr_out(FunctionCallInfo fcinfo);
extern Datum macaddr_recv(FunctionCallInfo fcinfo);
extern Datum macaddr_send(FunctionCallInfo fcinfo);
extern Datum macaddr_cmp(FunctionCallInfo fcinfo);
extern Datum macaddr_lt(FunctionCallInfo fcinfo);
extern Datum macaddr_le(FunctionCallInfo fcinfo);
extern Datum macaddr_eq(FunctionCallInfo fcinfo);
extern Datum macaddr_ge(FunctionCallInfo fcinfo);
extern Datum macaddr_gt(FunctionCallInfo fcinfo);
extern Datum macaddr_ne(FunctionCallInfo fcinfo);
extern Datum macaddr_not(FunctionCallInfo fcinfo);
extern Datum macaddr_and(FunctionCallInfo fcinfo);
extern Datum macaddr_or(FunctionCallInfo fcinfo);
extern Datum macaddr_trunc(FunctionCallInfo fcinfo);
extern Datum hashmacaddr(FunctionCallInfo fcinfo);


extern Datum numeric_in(FunctionCallInfo fcinfo);
extern Datum numeric_out(FunctionCallInfo fcinfo);
extern Datum numeric_recv(FunctionCallInfo fcinfo);
extern Datum numeric_send(FunctionCallInfo fcinfo);
extern Datum numerictypmodin(FunctionCallInfo fcinfo);
extern Datum numerictypmodout(FunctionCallInfo fcinfo);
extern Datum numeric_transform(FunctionCallInfo fcinfo);
extern Datum numeric (FunctionCallInfo fcinfo);
extern Datum numeric_abs(FunctionCallInfo fcinfo);
extern Datum numeric_uminus(FunctionCallInfo fcinfo);
extern Datum numeric_uplus(FunctionCallInfo fcinfo);
extern Datum numeric_sign(FunctionCallInfo fcinfo);
extern Datum numeric_round(FunctionCallInfo fcinfo);
extern Datum numeric_trunc(FunctionCallInfo fcinfo);
extern Datum numeric_ceil(FunctionCallInfo fcinfo);
extern Datum numeric_floor(FunctionCallInfo fcinfo);
extern Datum numeric_cmp(FunctionCallInfo fcinfo);
extern Datum numeric_eq(FunctionCallInfo fcinfo);
extern Datum numeric_ne(FunctionCallInfo fcinfo);
extern Datum numeric_gt(FunctionCallInfo fcinfo);
extern Datum numeric_ge(FunctionCallInfo fcinfo);
extern Datum numeric_lt(FunctionCallInfo fcinfo);
extern Datum numeric_le(FunctionCallInfo fcinfo);
extern Datum numeric_add(FunctionCallInfo fcinfo);
extern Datum numeric_sub(FunctionCallInfo fcinfo);
extern Datum numeric_mul(FunctionCallInfo fcinfo);
extern Datum numeric_div(FunctionCallInfo fcinfo);
extern Datum numeric_div_trunc(FunctionCallInfo fcinfo);
extern Datum numeric_mod(FunctionCallInfo fcinfo);
extern Datum numeric_inc(FunctionCallInfo fcinfo);
extern Datum numeric_smaller(FunctionCallInfo fcinfo);
extern Datum numeric_larger(FunctionCallInfo fcinfo);
extern Datum numeric_fac(FunctionCallInfo fcinfo);
extern Datum numeric_sqrt(FunctionCallInfo fcinfo);
extern Datum numeric_exp(FunctionCallInfo fcinfo);
extern Datum numeric_ln(FunctionCallInfo fcinfo);
extern Datum numeric_log(FunctionCallInfo fcinfo);
extern Datum numeric_power(FunctionCallInfo fcinfo);
extern Datum int4_numeric(FunctionCallInfo fcinfo);
extern Datum numeric_int4(FunctionCallInfo fcinfo);
extern Datum int8_numeric(FunctionCallInfo fcinfo);
extern Datum numeric_int8(FunctionCallInfo fcinfo);
extern Datum int2_numeric(FunctionCallInfo fcinfo);
extern Datum numeric_int2(FunctionCallInfo fcinfo);
extern Datum float8_numeric(FunctionCallInfo fcinfo);
extern Datum numeric_float8(FunctionCallInfo fcinfo);
extern Datum numeric_float8_no_overflow(FunctionCallInfo fcinfo);
extern Datum float4_numeric(FunctionCallInfo fcinfo);
extern Datum numeric_float4(FunctionCallInfo fcinfo);
extern Datum numeric_accum(FunctionCallInfo fcinfo);
extern Datum numeric_avg_accum(FunctionCallInfo fcinfo);
extern Datum int2_accum(FunctionCallInfo fcinfo);
extern Datum int4_accum(FunctionCallInfo fcinfo);
extern Datum int8_accum(FunctionCallInfo fcinfo);
extern Datum int8_avg_accum(FunctionCallInfo fcinfo);
extern Datum numeric_avg(FunctionCallInfo fcinfo);
extern Datum numeric_var_pop(FunctionCallInfo fcinfo);
extern Datum numeric_var_samp(FunctionCallInfo fcinfo);
extern Datum numeric_stddev_pop(FunctionCallInfo fcinfo);
extern Datum numeric_stddev_samp(FunctionCallInfo fcinfo);
extern Datum int2_sum(FunctionCallInfo fcinfo);
extern Datum int4_sum(FunctionCallInfo fcinfo);
extern Datum int8_sum(FunctionCallInfo fcinfo);
extern Datum int2_avg_accum(FunctionCallInfo fcinfo);
extern Datum int4_avg_accum(FunctionCallInfo fcinfo);
extern Datum int8_avg(FunctionCallInfo fcinfo);
extern Datum width_bucket_numeric(FunctionCallInfo fcinfo);
extern Datum hash_numeric(FunctionCallInfo fcinfo);


extern Datum RI_FKey_check_ins(FunctionCallInfo fcinfo);
extern Datum RI_FKey_check_upd(FunctionCallInfo fcinfo);
extern Datum RI_FKey_noaction_del(FunctionCallInfo fcinfo);
extern Datum RI_FKey_noaction_upd(FunctionCallInfo fcinfo);
extern Datum RI_FKey_cascade_del(FunctionCallInfo fcinfo);
extern Datum RI_FKey_cascade_upd(FunctionCallInfo fcinfo);
extern Datum RI_FKey_restrict_del(FunctionCallInfo fcinfo);
extern Datum RI_FKey_restrict_upd(FunctionCallInfo fcinfo);
extern Datum RI_FKey_setnull_del(FunctionCallInfo fcinfo);
extern Datum RI_FKey_setnull_upd(FunctionCallInfo fcinfo);
extern Datum RI_FKey_setdefault_del(FunctionCallInfo fcinfo);
extern Datum RI_FKey_setdefault_upd(FunctionCallInfo fcinfo);


extern Datum suppress_redundant_updates_trigger(FunctionCallInfo fcinfo);


extern Datum getdatabaseencoding(FunctionCallInfo fcinfo);
extern Datum database_character_set(FunctionCallInfo fcinfo);
extern Datum pg_client_encoding(FunctionCallInfo fcinfo);
extern Datum PG_encoding_to_char(FunctionCallInfo fcinfo);
extern Datum PG_char_to_encoding(FunctionCallInfo fcinfo);
extern Datum PG_character_set_name(FunctionCallInfo fcinfo);
extern Datum PG_character_set_id(FunctionCallInfo fcinfo);
extern Datum pg_convert(FunctionCallInfo fcinfo);
extern Datum pg_convert_to(FunctionCallInfo fcinfo);
extern Datum pg_convert_from(FunctionCallInfo fcinfo);
extern Datum length_in_encoding(FunctionCallInfo fcinfo);
extern Datum pg_encoding_max_length_sql(FunctionCallInfo fcinfo);


extern Datum format_type(FunctionCallInfo fcinfo);
extern char *format_type_be(Oid type_oid);
extern char *format_type_with_typemod(Oid type_oid, int32 typemod);
extern Datum oidvectortypes(FunctionCallInfo fcinfo);
extern int32 type_maximum_size(Oid type_oid, int32 typemod);


extern Datum quote_ident(FunctionCallInfo fcinfo);
extern Datum quote_literal(FunctionCallInfo fcinfo);
extern char *quote_literal_cstr(const char *rawstr);
extern Datum quote_nullable(FunctionCallInfo fcinfo);


extern Datum show_config_by_name(FunctionCallInfo fcinfo);
extern Datum set_config_by_name(FunctionCallInfo fcinfo);
extern Datum show_all_settings(FunctionCallInfo fcinfo);


extern Datum pg_lock_status(FunctionCallInfo fcinfo);
extern Datum pg_advisory_lock_int8(FunctionCallInfo fcinfo);
extern Datum pg_advisory_xact_lock_int8(FunctionCallInfo fcinfo);
extern Datum pg_advisory_lock_shared_int8(FunctionCallInfo fcinfo);
extern Datum pg_advisory_xact_lock_shared_int8(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_lock_int8(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_xact_lock_int8(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_lock_shared_int8(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_xact_lock_shared_int8(FunctionCallInfo fcinfo);
extern Datum pg_advisory_unlock_int8(FunctionCallInfo fcinfo);
extern Datum pg_advisory_unlock_shared_int8(FunctionCallInfo fcinfo);
extern Datum pg_advisory_lock_int4(FunctionCallInfo fcinfo);
extern Datum pg_advisory_xact_lock_int4(FunctionCallInfo fcinfo);
extern Datum pg_advisory_lock_shared_int4(FunctionCallInfo fcinfo);
extern Datum pg_advisory_xact_lock_shared_int4(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_lock_int4(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_xact_lock_int4(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_lock_shared_int4(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_xact_lock_shared_int4(FunctionCallInfo fcinfo);
extern Datum pg_advisory_unlock_int4(FunctionCallInfo fcinfo);
extern Datum pg_advisory_unlock_shared_int4(FunctionCallInfo fcinfo);
extern Datum pg_advisory_unlock_all(FunctionCallInfo fcinfo);


extern Datum txid_snapshot_in(FunctionCallInfo fcinfo);
extern Datum txid_snapshot_out(FunctionCallInfo fcinfo);
extern Datum txid_snapshot_recv(FunctionCallInfo fcinfo);
extern Datum txid_snapshot_send(FunctionCallInfo fcinfo);
extern Datum txid_current(FunctionCallInfo fcinfo);
extern Datum txid_current_snapshot(FunctionCallInfo fcinfo);
extern Datum txid_snapshot_xmin(FunctionCallInfo fcinfo);
extern Datum txid_snapshot_xmax(FunctionCallInfo fcinfo);
extern Datum txid_snapshot_xip(FunctionCallInfo fcinfo);
extern Datum txid_visible_in_snapshot(FunctionCallInfo fcinfo);


extern Datum uuid_in(FunctionCallInfo fcinfo);
extern Datum uuid_out(FunctionCallInfo fcinfo);
extern Datum uuid_send(FunctionCallInfo fcinfo);
extern Datum uuid_recv(FunctionCallInfo fcinfo);
extern Datum uuid_lt(FunctionCallInfo fcinfo);
extern Datum uuid_le(FunctionCallInfo fcinfo);
extern Datum uuid_eq(FunctionCallInfo fcinfo);
extern Datum uuid_ge(FunctionCallInfo fcinfo);
extern Datum uuid_gt(FunctionCallInfo fcinfo);
extern Datum uuid_ne(FunctionCallInfo fcinfo);
extern Datum uuid_cmp(FunctionCallInfo fcinfo);
extern Datum uuid_hash(FunctionCallInfo fcinfo);


extern Datum window_row_number(FunctionCallInfo fcinfo);
extern Datum window_rank(FunctionCallInfo fcinfo);
extern Datum window_dense_rank(FunctionCallInfo fcinfo);
extern Datum window_percent_rank(FunctionCallInfo fcinfo);
extern Datum window_cume_dist(FunctionCallInfo fcinfo);
extern Datum window_ntile(FunctionCallInfo fcinfo);
extern Datum window_lag(FunctionCallInfo fcinfo);
extern Datum window_lag_with_offset(FunctionCallInfo fcinfo);
extern Datum window_lag_with_offset_and_default(FunctionCallInfo fcinfo);
extern Datum window_lead(FunctionCallInfo fcinfo);
extern Datum window_lead_with_offset(FunctionCallInfo fcinfo);
extern Datum window_lead_with_offset_and_default(FunctionCallInfo fcinfo);
extern Datum window_first_value(FunctionCallInfo fcinfo);
extern Datum window_last_value(FunctionCallInfo fcinfo);
extern Datum window_nth_value(FunctionCallInfo fcinfo);


extern Datum spg_quad_config(FunctionCallInfo fcinfo);
extern Datum spg_quad_choose(FunctionCallInfo fcinfo);
extern Datum spg_quad_picksplit(FunctionCallInfo fcinfo);
extern Datum spg_quad_inner_consistent(FunctionCallInfo fcinfo);
extern Datum spg_quad_leaf_consistent(FunctionCallInfo fcinfo);


extern Datum spg_kd_config(FunctionCallInfo fcinfo);
extern Datum spg_kd_choose(FunctionCallInfo fcinfo);
extern Datum spg_kd_picksplit(FunctionCallInfo fcinfo);
extern Datum spg_kd_inner_consistent(FunctionCallInfo fcinfo);


extern Datum spg_text_config(FunctionCallInfo fcinfo);
extern Datum spg_text_choose(FunctionCallInfo fcinfo);
extern Datum spg_text_picksplit(FunctionCallInfo fcinfo);
extern Datum spg_text_inner_consistent(FunctionCallInfo fcinfo);
extern Datum spg_text_leaf_consistent(FunctionCallInfo fcinfo);


extern Datum ginarrayextract(FunctionCallInfo fcinfo);
extern Datum ginarrayextract_2args(FunctionCallInfo fcinfo);
extern Datum ginqueryarrayextract(FunctionCallInfo fcinfo);
extern Datum ginarrayconsistent(FunctionCallInfo fcinfo);


extern Datum pg_prepared_xact(FunctionCallInfo fcinfo);


extern Datum pg_describe_object(FunctionCallInfo fcinfo);


extern Datum unique_key_recheck(FunctionCallInfo fcinfo);


extern Datum pg_available_extensions(FunctionCallInfo fcinfo);
extern Datum pg_available_extension_versions(FunctionCallInfo fcinfo);
extern Datum pg_extension_update_paths(FunctionCallInfo fcinfo);
extern Datum pg_extension_config_dump(FunctionCallInfo fcinfo);


extern Datum pg_prepared_statement(FunctionCallInfo fcinfo);


extern Datum pg_cursor(FunctionCallInfo fcinfo);
# 32 "pltcl.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/lsyscache.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/lsyscache.h"
typedef struct OpBtreeInterpretation
{
 Oid opfamily_id;
 int strategy;
 Oid oplefttype;
 Oid oprighttype;
} OpBtreeInterpretation;


typedef enum IOFuncSelector
{
 IOFunc_input,
 IOFunc_output,
 IOFunc_receive,
 IOFunc_send
} IOFuncSelector;


typedef int32 (*get_attavgwidth_hook_type) (Oid relid, AttrNumber attnum);
extern get_attavgwidth_hook_type get_attavgwidth_hook;

extern bool op_in_opfamily(Oid opno, Oid opfamily);
extern int get_op_opfamily_strategy(Oid opno, Oid opfamily);
extern Oid get_op_opfamily_sortfamily(Oid opno, Oid opfamily);
extern void get_op_opfamily_properties(Oid opno, Oid opfamily, bool ordering_op,
         int *strategy,
         Oid *lefttype,
         Oid *righttype);
extern Oid get_opfamily_member(Oid opfamily, Oid lefttype, Oid righttype,
     int16 strategy);
extern bool get_ordering_op_properties(Oid opno,
         Oid *opfamily, Oid *opcintype, int16 *strategy);
extern bool get_sort_function_for_ordering_op(Oid opno, Oid *sortfunc,
          bool *issupport, bool *reverse);
extern Oid get_equality_op_for_ordering_op(Oid opno, bool *reverse);
extern Oid get_ordering_op_for_equality_op(Oid opno, bool use_lhs_type);
extern List *get_mergejoin_opfamilies(Oid opno);
extern bool get_compatible_hash_operators(Oid opno,
         Oid *lhs_opno, Oid *rhs_opno);
extern bool get_op_hash_functions(Oid opno,
       RegProcedure *lhs_procno, RegProcedure *rhs_procno);
extern List *get_op_btree_interpretation(Oid opno);
extern bool equality_ops_are_compatible(Oid opno1, Oid opno2);
extern Oid get_opfamily_proc(Oid opfamily, Oid lefttype, Oid righttype,
      int16 procnum);
extern char *get_attname(Oid relid, AttrNumber attnum);
extern char *get_relid_attribute_name(Oid relid, AttrNumber attnum);
extern AttrNumber get_attnum(Oid relid, const char *attname);
extern Oid get_atttype(Oid relid, AttrNumber attnum);
extern int32 get_atttypmod(Oid relid, AttrNumber attnum);
extern void get_atttypetypmodcoll(Oid relid, AttrNumber attnum,
       Oid *typid, int32 *typmod, Oid *collid);
extern char *get_collation_name(Oid colloid);
extern char *get_constraint_name(Oid conoid);
extern Oid get_opclass_family(Oid opclass);
extern Oid get_opclass_input_type(Oid opclass);
extern RegProcedure get_opcode(Oid opno);
extern char *get_opname(Oid opno);
extern void op_input_types(Oid opno, Oid *lefttype, Oid *righttype);
extern bool op_mergejoinable(Oid opno, Oid inputtype);
extern bool op_hashjoinable(Oid opno, Oid inputtype);
extern bool op_strict(Oid opno);
extern char op_volatile(Oid opno);
extern Oid get_commutator(Oid opno);
extern Oid get_negator(Oid opno);
extern RegProcedure get_oprrest(Oid opno);
extern RegProcedure get_oprjoin(Oid opno);
extern char *get_func_name(Oid funcid);
extern Oid get_func_namespace(Oid funcid);
extern Oid get_func_rettype(Oid funcid);
extern int get_func_nargs(Oid funcid);
extern Oid get_func_signature(Oid funcid, Oid **argtypes, int *nargs);
extern bool get_func_retset(Oid funcid);
extern bool func_strict(Oid funcid);
extern char func_volatile(Oid funcid);
extern bool get_func_leakproof(Oid funcid);
extern float4 get_func_cost(Oid funcid);
extern float4 get_func_rows(Oid funcid);
extern Oid get_relname_relid(const char *relname, Oid relnamespace);
extern char *get_rel_name(Oid relid);
extern Oid get_rel_namespace(Oid relid);
extern Oid get_rel_type_id(Oid relid);
extern char get_rel_relkind(Oid relid);
extern Oid get_rel_tablespace(Oid relid);
extern bool get_typisdefined(Oid typid);
extern int16 get_typlen(Oid typid);
extern bool get_typbyval(Oid typid);
extern void get_typlenbyval(Oid typid, int16 *typlen, bool *typbyval);
extern void get_typlenbyvalalign(Oid typid, int16 *typlen, bool *typbyval,
      char *typalign);
extern Oid getTypeIOParam(HeapTuple typeTuple);
extern void get_type_io_data(Oid typid,
     IOFuncSelector which_func,
     int16 *typlen,
     bool *typbyval,
     char *typalign,
     char *typdelim,
     Oid *typioparam,
     Oid *func);
extern char get_typstorage(Oid typid);
extern Node *get_typdefault(Oid typid);
extern char get_typtype(Oid typid);
extern bool type_is_rowtype(Oid typid);
extern bool type_is_enum(Oid typid);
extern bool type_is_range(Oid typid);
extern void get_type_category_preferred(Oid typid,
       char *typcategory,
       bool *typispreferred);
extern Oid get_typ_typrelid(Oid typid);
extern Oid get_element_type(Oid typid);
extern Oid get_array_type(Oid typid);
extern Oid get_base_element_type(Oid typid);
extern void getTypeInputInfo(Oid type, Oid *typInput, Oid *typIOParam);
extern void getTypeOutputInfo(Oid type, Oid *typOutput, bool *typIsVarlena);
extern void getTypeBinaryInputInfo(Oid type, Oid *typReceive, Oid *typIOParam);
extern void getTypeBinaryOutputInfo(Oid type, Oid *typSend, bool *typIsVarlena);
extern Oid get_typmodin(Oid typid);
extern Oid get_typcollation(Oid typid);
extern bool type_is_collatable(Oid typid);
extern Oid getBaseType(Oid typid);
extern Oid getBaseTypeAndTypmod(Oid typid, int32 *typmod);
extern int32 get_typavgwidth(Oid typid, int32 typmod);
extern int32 get_attavgwidth(Oid relid, AttrNumber attnum);
extern bool get_attstatsslot(HeapTuple statstuple,
     Oid atttype, int32 atttypmod,
     int reqkind, Oid reqop,
     Oid *actualop,
     Datum **values, int *nvalues,
     float4 **numbers, int *nnumbers);
extern void free_attstatsslot(Oid atttype,
      Datum *values, int nvalues,
      float4 *numbers, int nnumbers);
extern char *get_namespace_name(Oid nspid);
extern Oid get_range_subtype(Oid rangeOid);
# 33 "pltcl.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/memnodes.h" 1
# 36 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/memnodes.h"
typedef struct MemoryContextMethods
{
 void *(*alloc) (MemoryContext context, Size size);

 void (*free_p) (MemoryContext context, void *pointer);
 void *(*realloc) (MemoryContext context, void *pointer, Size size);
 void (*init) (MemoryContext context);
 void (*reset) (MemoryContext context);
 void (*delete_context) (MemoryContext context);
 Size (*get_chunk_space) (MemoryContext context, void *pointer);
 bool (*is_empty) (MemoryContext context);
 void (*stats) (MemoryContext context, int level);



} MemoryContextMethods;


typedef struct MemoryContextData
{
 NodeTag type;
 MemoryContextMethods *methods;
 MemoryContext parent;
 MemoryContext firstchild;
 MemoryContext nextchild;
 char *name;
 bool isReset;
} MemoryContextData;
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h" 2
# 53 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h"
typedef struct StandardChunkHeader
{
 MemoryContext context;
 Size size;




} StandardChunkHeader;
# 72 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h"
extern MemoryContext TopMemoryContext;
extern MemoryContext ErrorContext;
extern MemoryContext PostmasterContext;
extern MemoryContext CacheMemoryContext;
extern MemoryContext MessageContext;
extern MemoryContext TopTransactionContext;
extern MemoryContext CurTransactionContext;


extern MemoryContext PortalContext;





extern void MemoryContextInit(void);
extern void MemoryContextReset(MemoryContext context);
extern void MemoryContextDelete(MemoryContext context);
extern void MemoryContextResetChildren(MemoryContext context);
extern void MemoryContextDeleteChildren(MemoryContext context);
extern void MemoryContextResetAndDeleteChildren(MemoryContext context);
extern void MemoryContextSetParent(MemoryContext context,
        MemoryContext new_parent);
extern Size GetMemoryChunkSpace(void *pointer);
extern MemoryContext GetMemoryChunkContext(void *pointer);
extern MemoryContext MemoryContextGetParent(MemoryContext context);
extern bool MemoryContextIsEmpty(MemoryContext context);
extern void MemoryContextStats(MemoryContext context);




extern bool MemoryContextContains(MemoryContext context, void *pointer);






extern MemoryContext MemoryContextCreate(NodeTag tag, Size size,
     MemoryContextMethods *methods,
     MemoryContext parent,
     const char *name);







extern MemoryContext AllocSetContextCreate(MemoryContext parent,
       const char *name,
       Size minContextSize,
       Size initBlockSize,
       Size maxBlockSize);
# 34 "pltcl.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_am.h" 1
# 34 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_am.h"
typedef struct FormData_pg_am
{
 NameData amname;
 int2 amstrategies;



 int2 amsupport;

 bool amcanorder;
 bool amcanorderbyop;
 bool amcanbackward;
 bool amcanunique;
 bool amcanmulticol;
 bool amoptionalkey;
 bool amsearcharray;
 bool amsearchnulls;
 bool amstorage;
 bool amclusterable;
 bool ampredlocks;
 Oid amkeytype;
 regproc aminsert;
 regproc ambeginscan;
 regproc amgettuple;
 regproc amgetbitmap;
 regproc amrescan;
 regproc amendscan;
 regproc ammarkpos;
 regproc amrestrpos;
 regproc ambuild;
 regproc ambuildempty;
 regproc ambulkdelete;
 regproc amvacuumcleanup;
 regproc amcanreturn;
 regproc amcostestimate;
 regproc amoptions;
} FormData_pg_am;






typedef FormData_pg_am *Form_pg_am;
# 120 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_am.h"
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_class.h" 1
# 32 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_class.h"
typedef struct FormData_pg_class
{
 NameData relname;
 Oid relnamespace;
 Oid reltype;

 Oid reloftype;

 Oid relowner;
 Oid relam;
 Oid relfilenode;


 Oid reltablespace;
 int4 relpages;
 float4 reltuples;
 int4 relallvisible;

 Oid reltoastrelid;
 Oid reltoastidxid;
 bool relhasindex;
 bool relisshared;
 char relpersistence;
 char relkind;
 int2 relnatts;






 int2 relchecks;
 bool relhasoids;
 bool relhaspkey;
 bool relhasrules;
 bool relhastriggers;
 bool relhassubclass;
 TransactionId relfrozenxid;






} FormData_pg_class;
# 87 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_class.h"
typedef FormData_pg_class *Form_pg_class;
# 133 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_class.h"
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_index.h" 1
# 31 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_index.h"
typedef struct FormData_pg_index
{
 Oid indexrelid;
 Oid indrelid;
 int2 indnatts;
 bool indisunique;
 bool indisprimary;
 bool indisexclusion;
 bool indimmediate;
 bool indisclustered;
 bool indisvalid;
 bool indcheckxmin;
 bool indisready;


 int2vector indkey;
# 58 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_index.h"
} FormData_pg_index;






typedef FormData_pg_index *Form_pg_index;
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h" 2


# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/rewrite/prs2lock.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/rewrite/prs2lock.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/rewrite/prs2lock.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/rewrite/prs2lock.h" 2






typedef struct RewriteRule
{
 Oid ruleId;
 CmdType event;
 AttrNumber attrno;
 Node *qual;
 List *actions;
 char enabled;
 bool isInstead;
} RewriteRule;







typedef struct RuleLock
{
 int numLocks;
 RewriteRule **rules;
} RuleLock;
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h" 1
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h" 1
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h" 2

# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/reltrigger.h" 1
# 28 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h" 2







typedef struct LockRelId
{
 Oid relId;
 Oid dbId;
} LockRelId;

typedef struct LockInfoData
{
 LockRelId lockRelId;
} LockInfoData;

typedef LockInfoData *LockInfo;






typedef struct RelationAmInfo
{
 FmgrInfo aminsert;
 FmgrInfo ambeginscan;
 FmgrInfo amgettuple;
 FmgrInfo amgetbitmap;
 FmgrInfo amrescan;
 FmgrInfo amendscan;
 FmgrInfo ammarkpos;
 FmgrInfo amrestrpos;
 FmgrInfo ambuild;
 FmgrInfo ambuildempty;
 FmgrInfo ambulkdelete;
 FmgrInfo amvacuumcleanup;
 FmgrInfo amcanreturn;
 FmgrInfo amcostestimate;
 FmgrInfo amoptions;
} RelationAmInfo;






typedef struct RelationData
{
 RelFileNode rd_node;

 struct SMgrRelationData *rd_smgr;
 int rd_refcnt;
 BackendId rd_backend;
 bool rd_isnailed;
 bool rd_isvalid;
 char rd_indexvalid;

 bool rd_islocaltemp;
# 99 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h"
 SubTransactionId rd_createSubid;
 SubTransactionId rd_newRelfilenodeSubid;


 Form_pg_class rd_rel;
 TupleDesc rd_att;
 Oid rd_id;
 List *rd_indexlist;
 Bitmapset *rd_indexattr;
 Oid rd_oidindex;
 LockInfoData rd_lockInfo;
 RuleLock *rd_rules;
 MemoryContext rd_rulescxt;
 TriggerDesc *trigdesc;






 bytea *rd_options;


 Form_pg_index rd_index;

 struct HeapTupleData *rd_indextuple;
 Form_pg_am rd_am;
# 142 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h"
 MemoryContext rd_indexcxt;
 RelationAmInfo *rd_aminfo;
 Oid *rd_opfamily;
 Oid *rd_opcintype;
 RegProcedure *rd_support;
 FmgrInfo *rd_supportinfo;
 int16 *rd_indoption;
 List *rd_indexprs;
 List *rd_indpred;
 Oid *rd_exclops;
 Oid *rd_exclprocs;
 uint16 *rd_exclstrats;
 void *rd_amcache;
 Oid *rd_indcollation;
# 166 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h"
 Oid rd_toastoid;


 struct PgStat_TableStatus *pgstat_info;
} RelationData;
# 181 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h"
typedef struct AutoVacOpts
{
 bool enabled;
 int vacuum_threshold;
 int analyze_threshold;
 int vacuum_cost_delay;
 int vacuum_cost_limit;
 int freeze_min_age;
 int freeze_max_age;
 int freeze_table_age;
 float8 vacuum_scale_factor;
 float8 analyze_scale_factor;
} AutoVacOpts;

typedef struct StdRdOptions
{
 int32 vl_len_;
 int fillfactor;
 AutoVacOpts autovacuum;
 bool security_barrier;
} StdRdOptions;
# 389 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h"
extern void RelationIncrementReferenceCount(Relation rel);
extern void RelationDecrementReferenceCount(Relation rel);
# 35 "pltcl.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/syscache.h" 1
# 30 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/syscache.h"
enum SysCacheIdentifier
{
 AGGFNOID = 0,
 AMNAME,
 AMOID,
 AMOPOPID,
 AMOPSTRATEGY,
 AMPROCNUM,
 ATTNAME,
 ATTNUM,
 AUTHMEMMEMROLE,
 AUTHMEMROLEMEM,
 AUTHNAME,
 AUTHOID,
 CASTSOURCETARGET,
 CLAAMNAMENSP,
 CLAOID,
 COLLNAMEENCNSP,
 COLLOID,
 CONDEFAULT,
 CONNAMENSP,
 CONSTROID,
 CONVOID,
 DATABASEOID,
 DEFACLROLENSPOBJ,
 ENUMOID,
 ENUMTYPOIDNAME,
 FOREIGNDATAWRAPPERNAME,
 FOREIGNDATAWRAPPEROID,
 FOREIGNSERVERNAME,
 FOREIGNSERVEROID,
 FOREIGNTABLEREL,
 INDEXRELID,
 LANGNAME,
 LANGOID,
 NAMESPACENAME,
 NAMESPACEOID,
 OPERNAMENSP,
 OPEROID,
 OPFAMILYAMNAMENSP,
 OPFAMILYOID,
 PROCNAMEARGSNSP,
 PROCOID,
 RANGETYPE,
 RELNAMENSP,
 RELOID,
 RULERELNAME,
 STATRELATTINH,
 TABLESPACEOID,
 TSCONFIGMAP,
 TSCONFIGNAMENSP,
 TSCONFIGOID,
 TSDICTNAMENSP,
 TSDICTOID,
 TSPARSERNAMENSP,
 TSPARSEROID,
 TSTEMPLATENAMENSP,
 TSTEMPLATEOID,
 TYPENAMENSP,
 TYPEOID,
 USERMAPPINGOID,
 USERMAPPINGUSERSERVER
};

extern void InitCatalogCache(void);
extern void InitCatalogCachePhase2(void);

extern HeapTuple SearchSysCache(int cacheId,
      Datum key1, Datum key2, Datum key3, Datum key4);
extern void ReleaseSysCache(HeapTuple tuple);


extern HeapTuple SearchSysCacheCopy(int cacheId,
       Datum key1, Datum key2, Datum key3, Datum key4);
extern bool SearchSysCacheExists(int cacheId,
      Datum key1, Datum key2, Datum key3, Datum key4);
extern Oid GetSysCacheOid(int cacheId,
      Datum key1, Datum key2, Datum key3, Datum key4);

extern HeapTuple SearchSysCacheAttName(Oid relid, const char *attname);
extern HeapTuple SearchSysCacheCopyAttName(Oid relid, const char *attname);
extern bool SearchSysCacheExistsAttName(Oid relid, const char *attname);

extern Datum SysCacheGetAttr(int cacheId, HeapTuple tup,
    AttrNumber attributeNumber, bool *isNull);

extern uint32 GetSysCacheHashValue(int cacheId,
      Datum key1, Datum key2, Datum key3, Datum key4);


extern struct catclist *SearchSysCacheList(int cacheId, int nkeys,
       Datum key1, Datum key2, Datum key3, Datum key4);
# 36 "pltcl.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/typcache.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/typcache.h"
struct TypeCacheEnumData;

typedef struct TypeCacheEntry
{

 Oid type_id;


 int16 typlen;
 bool typbyval;
 char typalign;
 char typstorage;
 char typtype;
 Oid typrelid;
# 47 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/typcache.h"
 Oid btree_opf;
 Oid btree_opintype;
 Oid hash_opf;
 Oid hash_opintype;
 Oid eq_opr;
 Oid lt_opr;
 Oid gt_opr;
 Oid cmp_proc;
 Oid hash_proc;
# 64 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/typcache.h"
 FmgrInfo eq_opr_finfo;
 FmgrInfo cmp_proc_finfo;
 FmgrInfo hash_proc_finfo;






 TupleDesc tupDesc;







 struct TypeCacheEntry *rngelemtype;
 Oid rng_collation;
 FmgrInfo rng_cmp_proc_finfo;
 FmgrInfo rng_canonical_finfo;
 FmgrInfo rng_subdiff_finfo;


 int flags;





 struct TypeCacheEnumData *enumData;
} TypeCacheEntry;
# 111 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/typcache.h"
extern TypeCacheEntry *lookup_type_cache(Oid type_id, int flags);

extern TupleDesc lookup_rowtype_tupdesc(Oid type_id, int32 typmod);

extern TupleDesc lookup_rowtype_tupdesc_noerror(Oid type_id, int32 typmod,
          bool noError);

extern TupleDesc lookup_rowtype_tupdesc_copy(Oid type_id, int32 typmod);

extern void assign_record_type_typmod(TupleDesc tupDesc);

extern int compare_values_of_enum(TypeCacheEntry *tcache, Oid arg1, Oid arg2);
# 37 "pltcl.c" 2
# 84 "pltcl.c"
extern const Pg_magic_struct *Pg_magic_func(void); const Pg_magic_struct * Pg_magic_func(void) { static const Pg_magic_struct Pg_magic_data = { sizeof(Pg_magic_struct), 90204 / 100, 100, 32, 64, ((bool) 1), ((bool) 1) }; return &Pg_magic_data; } extern int no_such_variable;
# 97 "pltcl.c"
typedef struct pltcl_interp_desc
{
 Oid user_id;
 Tcl_Interp *interp;
 Tcl_HashTable query_hash;
} pltcl_interp_desc;





typedef struct pltcl_proc_desc
{
 char *user_proname;
 char *internal_proname;
 TransactionId fn_xmin;
 ItemPointerData fn_tid;
 bool fn_readonly;
 bool lanpltrusted;
 pltcl_interp_desc *interp_desc;
 FmgrInfo result_in_func;
 Oid result_typioparam;
 int nargs;
 FmgrInfo arg_out_func[100];
 bool arg_is_rowtype[100];
} pltcl_proc_desc;





typedef struct pltcl_query_desc
{
 char qname[20];
 SPIPlanPtr plan;
 int nargs;
 Oid *argtypes;
 FmgrInfo *arginfuncs;
 Oid *argtypioparams;
} pltcl_query_desc;
# 150 "pltcl.c"
typedef struct pltcl_proc_key
{
 Oid proc_id;





 Oid is_trigger;
 Oid user_id;
} pltcl_proc_key;

typedef struct pltcl_proc_ptr
{
 pltcl_proc_key proc_key;
 pltcl_proc_desc *proc_ptr;
} pltcl_proc_ptr;





static bool pltcl_pm_init_done = ((bool) 0);
static Tcl_Interp *pltcl_hold_interp = ((void *)0);
static HTAB *pltcl_interp_htab = ((void *)0);
static HTAB *pltcl_proc_htab = ((void *)0);


static FunctionCallInfo pltcl_current_fcinfo = ((void *)0);
static pltcl_proc_desc *pltcl_current_prodesc = ((void *)0);




Datum pltcl_call_handler(FunctionCallInfo fcinfo);
Datum pltclu_call_handler(FunctionCallInfo fcinfo);
void _PG_init(void);

static void pltcl_init_interp(pltcl_interp_desc *interp_desc, bool pltrusted);
static pltcl_interp_desc *pltcl_fetch_interp(bool pltrusted);
static void pltcl_init_load_unknown(Tcl_Interp *interp);

static Datum pltcl_handler(FunctionCallInfo fcinfo, bool pltrusted);

static Datum pltcl_func_handler(FunctionCallInfo fcinfo, bool pltrusted);

static HeapTuple pltcl_trigger_handler(FunctionCallInfo fcinfo, bool pltrusted);

static void throw_tcl_error(Tcl_Interp *interp, const char *proname);

static pltcl_proc_desc *compile_pltcl_function(Oid fn_oid, Oid tgreloid,
        bool pltrusted);

static int pltcl_elog(ClientData cdata, Tcl_Interp *interp,
     int argc, const char *argv[]);
static int pltcl_quote(ClientData cdata, Tcl_Interp *interp,
   int argc, const char *argv[]);
static int pltcl_argisnull(ClientData cdata, Tcl_Interp *interp,
    int argc, const char *argv[]);
static int pltcl_returnnull(ClientData cdata, Tcl_Interp *interp,
     int argc, const char *argv[]);

static int pltcl_SPI_execute(ClientData cdata, Tcl_Interp *interp,
      int argc, const char *argv[]);
static int pltcl_process_SPI_result(Tcl_Interp *interp,
       const char *arrayname,
       const char *loop_body,
       int spi_rc,
       SPITupleTable *tuptable,
       int ntuples);
static int pltcl_SPI_prepare(ClientData cdata, Tcl_Interp *interp,
      int argc, const char *argv[]);
static int pltcl_SPI_execute_plan(ClientData cdata, Tcl_Interp *interp,
        int argc, const char *argv[]);
static int pltcl_SPI_lastoid(ClientData cdata, Tcl_Interp *interp,
      int argc, const char *argv[]);

static void pltcl_set_tuple_values(Tcl_Interp *interp, const char *arrayname,
        int tupno, HeapTuple tuple, TupleDesc tupdesc);
static void pltcl_build_tuple_argument(HeapTuple tuple, TupleDesc tupdesc,
         Tcl_DString *retval);
# 247 "pltcl.c"
static ClientData
pltcl_InitNotifier(void)
{
 static int fakeThreadKey;

 return (ClientData) &(fakeThreadKey);
}

static void
pltcl_FinalizeNotifier(ClientData clientData)
{
}

static void
pltcl_SetTimer(Tcl_Time *timePtr)
{
}

static void
pltcl_AlertNotifier(ClientData clientData)
{
}

static void
pltcl_CreateFileHandler(int fd, int mask,
      Tcl_FileProc *proc, ClientData clientData)
{
}

static void
pltcl_DeleteFileHandler(int fd)
{
}

static void
pltcl_ServiceModeHook(int mode)
{
}

static int
pltcl_WaitForEvent(Tcl_Time *timePtr)
{
 return 0;
}
# 305 "pltcl.c"
static void
perm_fmgr_info(Oid functionId, FmgrInfo *finfo)
{
 fmgr_info_cxt(functionId, finfo, TopMemoryContext);
}
# 319 "pltcl.c"
void
_PG_init(void)
{
 HASHCTL hash_ctl;


 if (pltcl_pm_init_done)
  return;

 pg_bindtextdomain(("pltcl" "-" "9.2"));
# 340 "pltcl.c"
 {
  Tcl_NotifierProcs notifier;

  notifier.setTimerProc = pltcl_SetTimer;
  notifier.waitForEventProc = pltcl_WaitForEvent;
  notifier.createFileHandlerProc = pltcl_CreateFileHandler;
  notifier.deleteFileHandlerProc = pltcl_DeleteFileHandler;
  notifier.initNotifierProc = pltcl_InitNotifier;
  notifier.finalizeNotifierProc = pltcl_FinalizeNotifier;
  notifier.alertNotifierProc = pltcl_AlertNotifier;
  notifier.serviceModeHookProc = pltcl_ServiceModeHook;
  Tcl_SetNotifier(&notifier);
 }






 if ((pltcl_hold_interp = Tcl_CreateInterp()) == ((void *)0))
  elog_start("pltcl.c", 360, __func__), elog_finish(20, "could not create master Tcl interpreter");
 if (Tcl_Init(pltcl_hold_interp) == 1)
  elog_start("pltcl.c", 362, __func__), elog_finish(20, "could not initialize master Tcl interpreter");




 ((__builtin_object_size (&hash_ctl, 0) != (size_t) -1) ? __builtin___memset_chk (&hash_ctl, 0, sizeof(hash_ctl), __builtin_object_size (&hash_ctl, 0)) : __inline_memset_chk (&hash_ctl, 0, sizeof(hash_ctl)));
 hash_ctl.keysize = sizeof(Oid);
 hash_ctl.entrysize = sizeof(pltcl_interp_desc);
 hash_ctl.hash = oid_hash;
 pltcl_interp_htab = hash_create("PL/Tcl interpreters",
         8,
         &hash_ctl,
         0x020 | 0x010);




 ((__builtin_object_size (&hash_ctl, 0) != (size_t) -1) ? __builtin___memset_chk (&hash_ctl, 0, sizeof(hash_ctl), __builtin_object_size (&hash_ctl, 0)) : __inline_memset_chk (&hash_ctl, 0, sizeof(hash_ctl)));
 hash_ctl.keysize = sizeof(pltcl_proc_key);
 hash_ctl.entrysize = sizeof(pltcl_proc_ptr);
 hash_ctl.hash = tag_hash;
 pltcl_proc_htab = hash_create("PL/Tcl functions",
          100,
          &hash_ctl,
          0x020 | 0x010);

 pltcl_pm_init_done = ((bool) 1);
}




static void
pltcl_init_interp(pltcl_interp_desc *interp_desc, bool pltrusted)
{
 Tcl_Interp *interp;
 char interpname[32];






 __builtin___snprintf_chk (interpname, sizeof(interpname), 0, __builtin_object_size (interpname, 2 > 1), "slave_%u", interp_desc->user_id);
 if ((interp = Tcl_CreateSlave(pltcl_hold_interp, interpname,
          pltrusted ? 1 : 0)) == ((void *)0))
  elog_start("pltcl.c", 408, __func__), elog_finish(20, "could not create slave Tcl interpreter");
 interp_desc->interp = interp;




 Tcl_InitHashTable(&interp_desc->query_hash, 0);




 Tcl_CreateCommand(interp, "elog",
       pltcl_elog, ((void *)0), ((void *)0));
 Tcl_CreateCommand(interp, "quote",
       pltcl_quote, ((void *)0), ((void *)0));
 Tcl_CreateCommand(interp, "argisnull",
       pltcl_argisnull, ((void *)0), ((void *)0));
 Tcl_CreateCommand(interp, "return_null",
       pltcl_returnnull, ((void *)0), ((void *)0));

 Tcl_CreateCommand(interp, "spi_exec",
       pltcl_SPI_execute, ((void *)0), ((void *)0));
 Tcl_CreateCommand(interp, "spi_prepare",
       pltcl_SPI_prepare, ((void *)0), ((void *)0));
 Tcl_CreateCommand(interp, "spi_execp",
       pltcl_SPI_execute_plan, ((void *)0), ((void *)0));
 Tcl_CreateCommand(interp, "spi_lastoid",
       pltcl_SPI_lastoid, ((void *)0), ((void *)0));




 pltcl_init_load_unknown(interp);
}







static pltcl_interp_desc *
pltcl_fetch_interp(bool pltrusted)
{
 Oid user_id;
 pltcl_interp_desc *interp_desc;
 bool found;


 if (pltrusted)
  user_id = GetUserId();
 else
  user_id = ((Oid) 0);

 interp_desc = hash_search(pltcl_interp_htab, &user_id,
         HASH_ENTER,
         &found);
 if (!found)
  pltcl_init_interp(interp_desc, pltrusted);

 return interp_desc;
}





static void
pltcl_init_load_unknown(Tcl_Interp *interp)
{
 Relation pmrel;
 char *pmrelname,
      *nspname;
 char *buf;
 int buflen;
 int spi_rc;
 int tcl_rc;
 Tcl_DString unknown_src;
 char *part;
 int i;
 int fno;
# 497 "pltcl.c"
 pmrel = relation_openrv_extended(makeRangeVar(((void *)0), "pltcl_modules", -1),
          1, ((bool) 1));
 if (pmrel == ((void *)0))
  return;

 if (!(pmrel->rd_rel->relkind == 'r' ||
    pmrel->rd_rel->relkind == 'v'))
 {
  relation_close(pmrel, 1);
  return;
 }

 if (!superuser_arg(pmrel->rd_rel->relowner))
 {
  relation_close(pmrel, 1);
  return;
 }

 nspname = get_namespace_name(((pmrel)->rd_rel->relnamespace));
 if (!nspname)
  elog_start("pltcl.c", 517, __func__), elog_finish(20, "cache lookup failed for namespace %u",
    ((pmrel)->rd_rel->relnamespace));
 pmrelname = quote_qualified_identifier(nspname,
             ((((pmrel)->rd_rel->relname).data)));





 buflen = strlen(pmrelname) + 100;
 buf = (char *) MemoryContextAlloc(CurrentMemoryContext, (buflen));
 __builtin___snprintf_chk (buf, buflen, 0, __builtin_object_size (buf, 2 > 1), "select modsrc from %s where modname = 'unknown' order by modseq", pmrelname);



 spi_rc = SPI_execute(buf, ((bool) 0), 0);
 if (spi_rc != 5)
  elog_start("pltcl.c", 534, __func__), elog_finish(20, "select from pltcl_modules failed");

 pfree(buf);




 if (SPI_processed == 0)
 {
  SPI_freetuptable(SPI_tuptable);
  elog_start("pltcl.c", 544, __func__), elog_finish(19, "module \"unknown\" not found in pltcl_modules");
  relation_close(pmrel, 1);
  return;
 }






 fno = SPI_fnumber(SPI_tuptable->tupdesc, "modsrc");

 Tcl_DStringInit(&unknown_src);

 for (i = 0; i < SPI_processed; i++)
 {
  part = SPI_getvalue(SPI_tuptable->vals[i],
       SPI_tuptable->tupdesc, fno);
  if (part != ((void *)0))
  {
   ;
   Tcl_DStringAppend(&unknown_src, (part), -1);
   ;
   pfree(part);
  }
 }
 tcl_rc = Tcl_GlobalEval(interp, ((&unknown_src)->string));

 Tcl_DStringFree(&unknown_src);
 SPI_freetuptable(SPI_tuptable);

 if (tcl_rc != 0)
 {
  ;
  elog_start("pltcl.c", 578, __func__), elog_finish(20, "could not load module \"unknown\": %s",
    (Tcl_GetStringResult(interp)));
  ;
 }

 relation_close(pmrel, 1);
}
# 594 "pltcl.c"
extern const Pg_finfo_record * pg_finfo_pltcl_call_handler(void); const Pg_finfo_record * pg_finfo_pltcl_call_handler (void) { static const Pg_finfo_record my_finfo = { 1 }; return &my_finfo; } extern int no_such_variable;


Datum
pltcl_call_handler(FunctionCallInfo fcinfo)
{
 return pltcl_handler(fcinfo, ((bool) 1));
}




extern const Pg_finfo_record * pg_finfo_pltclu_call_handler(void); const Pg_finfo_record * pg_finfo_pltclu_call_handler (void) { static const Pg_finfo_record my_finfo = { 1 }; return &my_finfo; } extern int no_such_variable;


Datum
pltclu_call_handler(FunctionCallInfo fcinfo)
{
 return pltcl_handler(fcinfo, ((bool) 0));
}


static Datum
pltcl_handler(FunctionCallInfo fcinfo, bool pltrusted)
{
 Datum retval;
 FunctionCallInfo save_fcinfo;
 pltcl_proc_desc *save_prodesc;




 save_fcinfo = pltcl_current_fcinfo;
 save_prodesc = pltcl_current_prodesc;

 do { sigjmp_buf *save_exception_stack = PG_exception_stack; ErrorContextCallback *save_context_stack = error_context_stack; sigjmp_buf local_sigjmp_buf; if (sigsetjmp(local_sigjmp_buf, 0) == 0) { PG_exception_stack = &local_sigjmp_buf;
 {




  if (((fcinfo)->context != ((void *)0) && ((((const Node*)((fcinfo)->context))->type) == T_TriggerData)))
  {
   pltcl_current_fcinfo = ((void *)0);
   retval = ((Datum) (pltcl_trigger_handler(fcinfo, pltrusted)));
  }
  else
  {
   pltcl_current_fcinfo = fcinfo;
   retval = pltcl_func_handler(fcinfo, pltrusted);
  }
 }
 } else { PG_exception_stack = save_exception_stack; error_context_stack = save_context_stack;
 {
  pltcl_current_fcinfo = save_fcinfo;
  pltcl_current_prodesc = save_prodesc;
  pg_re_throw();
 }
 } PG_exception_stack = save_exception_stack; error_context_stack = save_context_stack; } while (0);

 pltcl_current_fcinfo = save_fcinfo;
 pltcl_current_prodesc = save_prodesc;

 return retval;
}





static Datum
pltcl_func_handler(FunctionCallInfo fcinfo, bool pltrusted)
{
 pltcl_proc_desc *prodesc;
 Tcl_Interp *volatile interp;
 Tcl_DString tcl_cmd;
 Tcl_DString list_tmp;
 int i;
 int tcl_rc;
 Datum retval;


 if (SPI_connect() != 1)
  elog_start("pltcl.c", 677, __func__), elog_finish(20, "could not connect to SPI manager");


 prodesc = compile_pltcl_function(fcinfo->flinfo->fn_oid, ((Oid) 0),
          pltrusted);

 pltcl_current_prodesc = prodesc;

 interp = prodesc->interp_desc->interp;





 Tcl_DStringInit(&tcl_cmd);
 Tcl_DStringInit(&list_tmp);
 Tcl_DStringAppendElement(&tcl_cmd, prodesc->internal_proname);




 do { sigjmp_buf *save_exception_stack = PG_exception_stack; ErrorContextCallback *save_context_stack = error_context_stack; sigjmp_buf local_sigjmp_buf; if (sigsetjmp(local_sigjmp_buf, 0) == 0) { PG_exception_stack = &local_sigjmp_buf;
 {
  for (i = 0; i < prodesc->nargs; i++)
  {
   if (prodesc->arg_is_rowtype[i])
   {



    if (fcinfo->argnull[i])
     Tcl_DStringAppendElement(&tcl_cmd, "");
    else
    {
     HeapTupleHeader td;
     Oid tupType;
     int32 tupTypmod;
     TupleDesc tupdesc;
     HeapTupleData tmptup;

     td = ((HeapTupleHeader) pg_detoast_datum((struct varlena *) ((Pointer) (fcinfo->arg[i]))));

     tupType = ( (td)->t_choice.t_datum.datum_typeid );
     tupTypmod = ( (td)->t_choice.t_datum.datum_typmod );
     tupdesc = lookup_rowtype_tupdesc(tupType, tupTypmod);

     tmptup.t_len = ((((varattrib_4b *) (td))->va_4byte.va_header >> 2) & 0x3FFFFFFF);
     tmptup.t_data = td;

     Tcl_DStringSetLength(&list_tmp, 0);
     pltcl_build_tuple_argument(&tmptup, tupdesc, &list_tmp);
     Tcl_DStringAppendElement(&tcl_cmd,
            ((&list_tmp)->string));
     do { if ((tupdesc)->tdrefcount >= 0) DecrTupleDescRefCount(tupdesc); } while (0);
    }
   }
   else
   {




    if (fcinfo->argnull[i])
     Tcl_DStringAppendElement(&tcl_cmd, "");
    else
    {
     char *tmp;

     tmp = OutputFunctionCall(&prodesc->arg_out_func[i],
            fcinfo->arg[i]);
     ;
     Tcl_DStringAppendElement(&tcl_cmd, (tmp));
     ;
     pfree(tmp);
    }
   }
  }
 }
 } else { PG_exception_stack = save_exception_stack; error_context_stack = save_context_stack;
 {
  Tcl_DStringFree(&tcl_cmd);
  Tcl_DStringFree(&list_tmp);
  pg_re_throw();
 }
 } PG_exception_stack = save_exception_stack; error_context_stack = save_context_stack; } while (0);
 Tcl_DStringFree(&list_tmp);






 tcl_rc = Tcl_GlobalEval(interp, ((&tcl_cmd)->string));
 Tcl_DStringFree(&tcl_cmd);




 if (tcl_rc != 0)
  throw_tcl_error(interp, prodesc->user_proname);
# 787 "pltcl.c"
 if (SPI_finish() != 2)
  elog_start("pltcl.c", 788, __func__), elog_finish(20, "SPI_finish() failed");

 if (fcinfo->isnull)
  retval = InputFunctionCall(&prodesc->result_in_func,
           ((void *)0),
           prodesc->result_typioparam,
           -1);
 else
 {
  ;
  retval = InputFunctionCall(&prodesc->result_in_func,
          ((char *) Tcl_GetStringResult(interp)),
           prodesc->result_typioparam,
           -1);
  ;
 }

 return retval;
}





static HeapTuple
pltcl_trigger_handler(FunctionCallInfo fcinfo, bool pltrusted)
{
 pltcl_proc_desc *prodesc;
 Tcl_Interp *volatile interp;
 TriggerData *trigdata = (TriggerData *) fcinfo->context;
 char *stroid;
 TupleDesc tupdesc;
 volatile HeapTuple rettup;
 Tcl_DString tcl_cmd;
 Tcl_DString tcl_trigtup;
 Tcl_DString tcl_newtup;
 int tcl_rc;
 int i;
 int *modattrs;
 Datum *modvalues;
 char *modnulls;
 int ret_numvals;
 const char *result;
 const char **ret_values;


 if (SPI_connect() != 1)
  elog_start("pltcl.c", 835, __func__), elog_finish(20, "could not connect to SPI manager");


 prodesc = compile_pltcl_function(fcinfo->flinfo->fn_oid,
          ((trigdata->tg_relation)->rd_id),
          pltrusted);

 pltcl_current_prodesc = prodesc;

 interp = prodesc->interp_desc->interp;

 tupdesc = trigdata->tg_relation->rd_att;





 Tcl_DStringInit(&tcl_cmd);
 Tcl_DStringInit(&tcl_trigtup);
 Tcl_DStringInit(&tcl_newtup);
 do { sigjmp_buf *save_exception_stack = PG_exception_stack; ErrorContextCallback *save_context_stack = error_context_stack; sigjmp_buf local_sigjmp_buf; if (sigsetjmp(local_sigjmp_buf, 0) == 0) { PG_exception_stack = &local_sigjmp_buf;
 {

  Tcl_DStringAppendElement(&tcl_cmd, prodesc->internal_proname);


  Tcl_DStringAppendElement(&tcl_cmd, trigdata->tg_trigger->tgname);


  stroid = ((char *) ((Pointer) (DirectFunctionCall1Coll(oidout, ((Oid) 0), ((Datum) (((Datum) (trigdata->tg_relation->rd_id)) & 0xffffffff))))));

  Tcl_DStringAppendElement(&tcl_cmd, stroid);
  pfree(stroid);


  stroid = SPI_getrelname(trigdata->tg_relation);
  Tcl_DStringAppendElement(&tcl_cmd, stroid);
  pfree(stroid);


  stroid = SPI_getnspname(trigdata->tg_relation);
  Tcl_DStringAppendElement(&tcl_cmd, stroid);
  pfree(stroid);


  Tcl_DStringAppendElement(&tcl_trigtup, "");
  for (i = 0; i < tupdesc->natts; i++)
  {
   if (tupdesc->attrs[i]->attisdropped)
    Tcl_DStringAppendElement(&tcl_trigtup, "");
   else
    Tcl_DStringAppendElement(&tcl_trigtup,
           ((tupdesc->attrs[i]->attname).data));
  }
  Tcl_DStringAppendElement(&tcl_cmd, ((&tcl_trigtup)->string));
  Tcl_DStringFree(&tcl_trigtup);
  Tcl_DStringInit(&tcl_trigtup);


  if ((((trigdata->tg_event) & 0x00000018) == 0x00000008))
   Tcl_DStringAppendElement(&tcl_cmd, "BEFORE");
  else if ((((trigdata->tg_event) & 0x00000018) == 0x00000000))
   Tcl_DStringAppendElement(&tcl_cmd, "AFTER");
  else if ((((trigdata->tg_event) & 0x00000018) == 0x00000010))
   Tcl_DStringAppendElement(&tcl_cmd, "INSTEAD OF");
  else
   elog_start("pltcl.c", 901, __func__), elog_finish(20, "unrecognized WHEN tg_event: %u", trigdata->tg_event);


  if (((trigdata->tg_event) & 0x00000004))
  {
   Tcl_DStringAppendElement(&tcl_cmd, "ROW");


   pltcl_build_tuple_argument(trigdata->tg_trigtuple,
            tupdesc, &tcl_trigtup);





   if ((((trigdata->tg_event) & 0x00000003) == 0x00000000))
   {
    Tcl_DStringAppendElement(&tcl_cmd, "INSERT");

    Tcl_DStringAppendElement(&tcl_cmd, ((&tcl_trigtup)->string));
    Tcl_DStringAppendElement(&tcl_cmd, "");

    rettup = trigdata->tg_trigtuple;
   }
   else if ((((trigdata->tg_event) & 0x00000003) == 0x00000001))
   {
    Tcl_DStringAppendElement(&tcl_cmd, "DELETE");

    Tcl_DStringAppendElement(&tcl_cmd, "");
    Tcl_DStringAppendElement(&tcl_cmd, ((&tcl_trigtup)->string));

    rettup = trigdata->tg_trigtuple;
   }
   else if ((((trigdata->tg_event) & 0x00000003) == 0x00000002))
   {
    Tcl_DStringAppendElement(&tcl_cmd, "UPDATE");

    pltcl_build_tuple_argument(trigdata->tg_newtuple,
             tupdesc, &tcl_newtup);

    Tcl_DStringAppendElement(&tcl_cmd, ((&tcl_newtup)->string));
    Tcl_DStringAppendElement(&tcl_cmd, ((&tcl_trigtup)->string));

    rettup = trigdata->tg_newtuple;
   }
   else
    elog_start("pltcl.c", 947, __func__), elog_finish(20, "unrecognized OP tg_event: %u", trigdata->tg_event);
  }
  else if ((!((trigdata->tg_event) & 0x00000004)))
  {
   Tcl_DStringAppendElement(&tcl_cmd, "STATEMENT");

   if ((((trigdata->tg_event) & 0x00000003) == 0x00000000))
    Tcl_DStringAppendElement(&tcl_cmd, "INSERT");
   else if ((((trigdata->tg_event) & 0x00000003) == 0x00000001))
    Tcl_DStringAppendElement(&tcl_cmd, "DELETE");
   else if ((((trigdata->tg_event) & 0x00000003) == 0x00000002))
    Tcl_DStringAppendElement(&tcl_cmd, "UPDATE");
   else if ((((trigdata->tg_event) & 0x00000003) == 0x00000003))
    Tcl_DStringAppendElement(&tcl_cmd, "TRUNCATE");
   else
    elog_start("pltcl.c", 962, __func__), elog_finish(20, "unrecognized OP tg_event: %u", trigdata->tg_event);

   Tcl_DStringAppendElement(&tcl_cmd, "");
   Tcl_DStringAppendElement(&tcl_cmd, "");

   rettup = (HeapTuple) ((void *)0);
  }
  else
   elog_start("pltcl.c", 970, __func__), elog_finish(20, "unrecognized LEVEL tg_event: %u", trigdata->tg_event);


  for (i = 0; i < trigdata->tg_trigger->tgnargs; i++)
   Tcl_DStringAppendElement(&tcl_cmd, trigdata->tg_trigger->tgargs[i]);

 }
 } else { PG_exception_stack = save_exception_stack; error_context_stack = save_context_stack;
 {
  Tcl_DStringFree(&tcl_cmd);
  Tcl_DStringFree(&tcl_trigtup);
  Tcl_DStringFree(&tcl_newtup);
  pg_re_throw();
 }
 } PG_exception_stack = save_exception_stack; error_context_stack = save_context_stack; } while (0);
 Tcl_DStringFree(&tcl_trigtup);
 Tcl_DStringFree(&tcl_newtup);






 tcl_rc = Tcl_GlobalEval(interp, ((&tcl_cmd)->string));
 Tcl_DStringFree(&tcl_cmd);




 if (tcl_rc != 0)
  throw_tcl_error(interp, prodesc->user_proname);






 if (SPI_finish() != 2)
  elog_start("pltcl.c", 1008, __func__), elog_finish(20, "SPI_finish() failed");

 result = Tcl_GetStringResult(interp);

 if (strcmp(result, "OK") == 0)
  return rettup;
 if (strcmp(result, "SKIP") == 0)
  return (HeapTuple) ((void *)0);





 if (Tcl_SplitList(interp, result,
       &ret_numvals, &ret_values) != 0)
 {
  ;
  elog_start("pltcl.c", 1025, __func__), elog_finish(20, "could not split return value from trigger: %s",
    (Tcl_GetStringResult(interp)));
  ;
 }


 do { sigjmp_buf *save_exception_stack = PG_exception_stack; ErrorContextCallback *save_context_stack = error_context_stack; sigjmp_buf local_sigjmp_buf; if (sigsetjmp(local_sigjmp_buf, 0) == 0) { PG_exception_stack = &local_sigjmp_buf;
 {
  if (ret_numvals % 2 != 0)
   elog_start("pltcl.c", 1034, __func__), elog_finish(20, "invalid return list from trigger - must have even # of elements");

  modattrs = (int *) MemoryContextAlloc(CurrentMemoryContext, (tupdesc->natts * sizeof(int)));
  modvalues = (Datum *) MemoryContextAlloc(CurrentMemoryContext, (tupdesc->natts * sizeof(Datum)));
  for (i = 0; i < tupdesc->natts; i++)
  {
   modattrs[i] = i + 1;
   modvalues[i] = (Datum) ((void *)0);
  }

  modnulls = MemoryContextAlloc(CurrentMemoryContext, (tupdesc->natts));
  ((__builtin_object_size (modnulls, 0) != (size_t) -1) ? __builtin___memset_chk (modnulls, 'n', tupdesc->natts, __builtin_object_size (modnulls, 0)) : __inline_memset_chk (modnulls, 'n', tupdesc->natts));

  for (i = 0; i < ret_numvals; i += 2)
  {
   const char *ret_name = ret_values[i];
   const char *ret_value = ret_values[i + 1];
   int attnum;
   HeapTuple typeTup;
   Oid typinput;
   Oid typioparam;
   FmgrInfo finfo;




   if (strcmp(ret_name, ".tupno") == 0)
    continue;




   attnum = SPI_fnumber(tupdesc, ret_name);
   if (attnum == (-9))
    elog_start("pltcl.c", 1068, __func__), elog_finish(20, "invalid attribute \"%s\"", ret_name);
   if (attnum <= 0)
    elog_start("pltcl.c", 1070, __func__), elog_finish(20, "cannot set system attribute \"%s\"", ret_name);




   if (tupdesc->attrs[attnum - 1]->attisdropped)
    continue;





   typeTup = SearchSysCache(TYPEOID, ((Datum) (((Datum) (tupdesc->attrs[attnum - 1]->atttypid)) & 0xffffffff)), 0, 0, 0);

   if (!((const void*)(typeTup) != ((void *)0)))
    elog_start("pltcl.c", 1085, __func__), elog_finish(20, "cache lookup failed for type %u",
      tupdesc->attrs[attnum - 1]->atttypid);
   typinput = ((Form_pg_type) ((char *) ((typeTup)->t_data) + (typeTup)->t_data->t_hoff))->typinput;
   typioparam = getTypeIOParam(typeTup);
   ReleaseSysCache(typeTup);




   modnulls[attnum - 1] = ' ';
   fmgr_info(typinput, &finfo);
   ;
   modvalues[attnum - 1] = InputFunctionCall(&finfo,
             (char *) (ret_value),
               typioparam,
           tupdesc->attrs[attnum - 1]->atttypmod);
   ;
  }

  rettup = SPI_modifytuple(trigdata->tg_relation, rettup, tupdesc->natts,
         modattrs, modvalues, modnulls);

  pfree(modattrs);
  pfree(modvalues);
  pfree(modnulls);

  if (rettup == ((void *)0))
   elog_start("pltcl.c", 1112, __func__), elog_finish(20, "SPI_modifytuple() failed - RC = %d", SPI_result);

 }
 } else { PG_exception_stack = save_exception_stack; error_context_stack = save_context_stack;
 {
  Tcl_Free((char *) ret_values);
  pg_re_throw();
 }
 } PG_exception_stack = save_exception_stack; error_context_stack = save_context_stack; } while (0);
 Tcl_Free((char *) ret_values);

 return rettup;
}





static void
throw_tcl_error(Tcl_Interp *interp, const char *proname)
{







 char *emsg;
 char *econtext;

 ;
 emsg = MemoryContextStrdup(CurrentMemoryContext, ((Tcl_GetStringResult(interp))));
 ;
 ;
 econtext = ((char *) Tcl_GetVar(interp, "errorInfo", 1));

 (errstart(20, "pltcl.c", 1152, __func__, ("pltcl" "-" "9.2")) ? (errfinish (errmsg("%s", emsg), errcontext("%s\nin PL/Tcl function \"%s\"", econtext, proname))) : (void) 0);



 ;
}
# 1163 "pltcl.c"
static pltcl_proc_desc *
compile_pltcl_function(Oid fn_oid, Oid tgreloid, bool pltrusted)
{
 HeapTuple procTup;
 Form_pg_proc procStruct;
 pltcl_proc_key proc_key;
 pltcl_proc_ptr *proc_ptr;
 bool found;
 pltcl_proc_desc *prodesc;


 procTup = SearchSysCache(PROCOID, ((Datum) (((Datum) (fn_oid)) & 0xffffffff)), 0, 0, 0);
 if (!((const void*)(procTup) != ((void *)0)))
  elog_start("pltcl.c", 1176, __func__), elog_finish(20, "cache lookup failed for function %u", fn_oid);
 procStruct = (Form_pg_proc) ((char *) ((procTup)->t_data) + (procTup)->t_data->t_hoff);


 proc_key.proc_id = fn_oid;
 proc_key.is_trigger = ((bool) ((tgreloid) != ((Oid) 0)));
 proc_key.user_id = pltrusted ? GetUserId() : ((Oid) 0);

 proc_ptr = hash_search(pltcl_proc_htab, &proc_key,
         HASH_ENTER,
         &found);
 if (!found)
  proc_ptr->proc_ptr = ((void *)0);

 prodesc = proc_ptr->proc_ptr;






 if (prodesc != ((void *)0))
 {
  bool uptodate;

  uptodate = (prodesc->fn_xmin == ( (procTup->t_data)->t_choice.t_heap.t_xmin ) &&
     ItemPointerEquals(&prodesc->fn_tid, &procTup->t_self));

  if (!uptodate)
  {
   proc_ptr->proc_ptr = ((void *)0);
   prodesc = ((void *)0);
  }
 }
# 1219 "pltcl.c"
 if (prodesc == ((void *)0))
 {
  bool is_trigger = ((bool) ((tgreloid) != ((Oid) 0)));
  char internal_proname[128];
  HeapTuple typeTup;
  Form_pg_type typeStruct;
  Tcl_DString proc_internal_def;
  Tcl_DString proc_internal_body;
  char proc_internal_args[33 * 100];
  Datum prosrcdatum;
  bool isnull;
  char *proc_source;
  char buf[32];
  Tcl_Interp *interp;
  int i;
  int tcl_rc;






  if (!is_trigger)
   __builtin___snprintf_chk (internal_proname, sizeof(internal_proname), 0, __builtin_object_size (internal_proname, 2 > 1), "__PLTcl_proc_%u", fn_oid);

  else
   __builtin___snprintf_chk (internal_proname, sizeof(internal_proname), 0, __builtin_object_size (internal_proname, 2 > 1), "__PLTcl_proc_%u_trigger", fn_oid);





  prodesc = (pltcl_proc_desc *) malloc(sizeof(pltcl_proc_desc));
  if (prodesc == ((void *)0))
   (errstart(20, "pltcl.c", 1255, __func__, ("pltcl" "-" "9.2")) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('3') - '0') & 0x3F) << 6) + (((('2') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("out of memory"))) : (void) 0);


  do { void *_vstart = (void *) (prodesc); int _val = (0); Size _len = (sizeof(pltcl_proc_desc)); if ((((intptr_t) _vstart) & (sizeof(long) - 1)) == 0 && (_len & (sizeof(long) - 1)) == 0 && _val == 0 && _len <= 1024 && 1024 != 0) { long *_start = (long *) _vstart; long *_stop = (long *) ((char *) _start + _len); while (_start < _stop) *_start++ = 0; } else ((__builtin_object_size (_vstart, 0) != (size_t) -1) ? __builtin___memset_chk (_vstart, _val, _len, __builtin_object_size (_vstart, 0)) : __inline_memset_chk (_vstart, _val, _len)); } while (0);
  prodesc->user_proname = strdup(((procStruct->proname).data));
  prodesc->internal_proname = strdup(internal_proname);
  if (prodesc->user_proname == ((void *)0) || prodesc->internal_proname == ((void *)0))
   (errstart(20, "pltcl.c", 1262, __func__, ("pltcl" "-" "9.2")) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('3') - '0') & 0x3F) << 6) + (((('2') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("out of memory"))) : (void) 0);


  prodesc->fn_xmin = ( (procTup->t_data)->t_choice.t_heap.t_xmin );
  prodesc->fn_tid = procTup->t_self;


  prodesc->fn_readonly =
   (procStruct->provolatile != 'v');

  prodesc->lanpltrusted = pltrusted;




  prodesc->interp_desc = pltcl_fetch_interp(prodesc->lanpltrusted);
  interp = prodesc->interp_desc->interp;





  if (!is_trigger)
  {
   typeTup =
    SearchSysCache(TYPEOID, ((Datum) (((Datum) (procStruct->prorettype)) & 0xffffffff)), 0, 0, 0);

   if (!((const void*)(typeTup) != ((void *)0)))
   {
    free(prodesc->user_proname);
    free(prodesc->internal_proname);
    free(prodesc);
    elog_start("pltcl.c", 1292, __func__), elog_finish(20, "cache lookup failed for type %u",
      procStruct->prorettype);
   }
   typeStruct = (Form_pg_type) ((char *) ((typeTup)->t_data) + (typeTup)->t_data->t_hoff);


   if (typeStruct->typtype == 'p')
   {
    if (procStruct->prorettype == 2278)
                 ;
    else if (procStruct->prorettype == 2279)
    {
     free(prodesc->user_proname);
     free(prodesc->internal_proname);
     free(prodesc);
     (errstart(20, "pltcl.c", 1309, __func__, ("pltcl" "-" "9.2")) ? (errfinish (errcode((((('0') - '0') & 0x3F) + (((('A') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("trigger functions can only be called as triggers"))) : (void) 0);


    }
    else
    {
     free(prodesc->user_proname);
     free(prodesc->internal_proname);
     free(prodesc);
     (errstart(20, "pltcl.c", 1319, __func__, ("pltcl" "-" "9.2")) ? (errfinish (errcode((((('0') - '0') & 0x3F) + (((('A') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("PL/Tcl functions cannot return type %s", format_type_be(procStruct->prorettype)))) : (void) 0);



    }
   }

   if (typeStruct->typtype == 'c')
   {
    free(prodesc->user_proname);
    free(prodesc->internal_proname);
    free(prodesc);
    (errstart(20, "pltcl.c", 1330, __func__, ("pltcl" "-" "9.2")) ? (errfinish (errcode((((('0') - '0') & 0x3F) + (((('A') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("PL/Tcl functions cannot return composite types"))) : (void) 0);


   }

   perm_fmgr_info(typeStruct->typinput, &(prodesc->result_in_func));
   prodesc->result_typioparam = getTypeIOParam(typeTup);

   ReleaseSysCache(typeTup);
  }





  if (!is_trigger)
  {
   prodesc->nargs = procStruct->pronargs;
   proc_internal_args[0] = '\0';
   for (i = 0; i < prodesc->nargs; i++)
   {
    typeTup = SearchSysCache(TYPEOID, ((Datum) (((Datum) (procStruct->proargtypes.values[i])) & 0xffffffff)), 0, 0, 0);

    if (!((const void*)(typeTup) != ((void *)0)))
    {
     free(prodesc->user_proname);
     free(prodesc->internal_proname);
     free(prodesc);
     elog_start("pltcl.c", 1356, __func__), elog_finish(20, "cache lookup failed for type %u",
       procStruct->proargtypes.values[i]);
    }
    typeStruct = (Form_pg_type) ((char *) ((typeTup)->t_data) + (typeTup)->t_data->t_hoff);


    if (typeStruct->typtype == 'p')
    {
     free(prodesc->user_proname);
     free(prodesc->internal_proname);
     free(prodesc);
     (errstart(20, "pltcl.c", 1370, __func__, ("pltcl" "-" "9.2")) ? (errfinish (errcode((((('0') - '0') & 0x3F) + (((('A') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("PL/Tcl functions cannot accept type %s", format_type_be(procStruct->proargtypes.values[i])))) : (void) 0);



    }

    if (typeStruct->typtype == 'c')
    {
     prodesc->arg_is_rowtype[i] = ((bool) 1);
     __builtin___snprintf_chk (buf, sizeof(buf), 0, __builtin_object_size (buf, 2 > 1), "__PLTcl_Tup_%d", i + 1);
    }
    else
    {
     prodesc->arg_is_rowtype[i] = ((bool) 0);
     perm_fmgr_info(typeStruct->typoutput,
           &(prodesc->arg_out_func[i]));
     __builtin___snprintf_chk (buf, sizeof(buf), 0, __builtin_object_size (buf, 2 > 1), "%d", i + 1);
    }

    if (i > 0)
     ((__builtin_object_size (proc_internal_args, 0) != (size_t) -1) ? __builtin___strcat_chk (proc_internal_args, " ", __builtin_object_size (proc_internal_args, 2 > 1)) : __inline_strcat_chk (proc_internal_args, " "));
    ((__builtin_object_size (proc_internal_args, 0) != (size_t) -1) ? __builtin___strcat_chk (proc_internal_args, buf, __builtin_object_size (proc_internal_args, 2 > 1)) : __inline_strcat_chk (proc_internal_args, buf));

    ReleaseSysCache(typeTup);
   }
  }
  else
  {

   ((__builtin_object_size (proc_internal_args, 0) != (size_t) -1) ? __builtin___strcpy_chk (proc_internal_args, "TG_name TG_relid TG_table_name TG_table_schema TG_relatts TG_when TG_level TG_op __PLTcl_Tup_NEW __PLTcl_Tup_OLD args", __builtin_object_size (proc_internal_args, 2 > 1)) : __inline_strcpy_chk (proc_internal_args, "TG_name TG_relid TG_table_name TG_table_schema TG_relatts TG_when TG_level TG_op __PLTcl_Tup_NEW __PLTcl_Tup_OLD args"));

  }





  Tcl_DStringInit(&proc_internal_def);
  Tcl_DStringInit(&proc_internal_body);
  Tcl_DStringAppendElement(&proc_internal_def, "proc");
  Tcl_DStringAppendElement(&proc_internal_def, internal_proname);
  Tcl_DStringAppendElement(&proc_internal_def, proc_internal_args);






  Tcl_DStringAppend(&proc_internal_body, "upvar #0 ", -1);
  Tcl_DStringAppend(&proc_internal_body, internal_proname, -1);
  Tcl_DStringAppend(&proc_internal_body, " GD\n", -1);
  if (!is_trigger)
  {
   for (i = 0; i < prodesc->nargs; i++)
   {
    if (prodesc->arg_is_rowtype[i])
    {
     __builtin___snprintf_chk (buf, sizeof(buf), 0, __builtin_object_size (buf, 2 > 1), "array set %d $__PLTcl_Tup_%d\n", i + 1, i + 1);


     Tcl_DStringAppend(&proc_internal_body, buf, -1);
    }
   }
  }
  else
  {
   Tcl_DStringAppend(&proc_internal_body,
         "array set NEW $__PLTcl_Tup_NEW\n", -1);
   Tcl_DStringAppend(&proc_internal_body,
         "array set OLD $__PLTcl_Tup_OLD\n", -1);

   Tcl_DStringAppend(&proc_internal_body,
         "set i 0\n"
         "set v 0\n"
         "foreach v $args {\n"
         "  incr i\n"
         "  set $i $v\n"
         "}\n"
         "unset i v\n\n", -1);
  }




  prosrcdatum = SysCacheGetAttr(PROCOID, procTup,
           24, &isnull);
  if (isnull)
   elog_start("pltcl.c", 1454, __func__), elog_finish(20, "null prosrc");
  proc_source = text_to_cstring((text *) ((Pointer) (prosrcdatum)));
  ;
  Tcl_DStringAppend(&proc_internal_body, (proc_source), -1);
  ;
  pfree(proc_source);
  Tcl_DStringAppendElement(&proc_internal_def,
         ((&proc_internal_body)->string));
  Tcl_DStringFree(&proc_internal_body);




  tcl_rc = Tcl_GlobalEval(interp,
        ((&proc_internal_def)->string));
  Tcl_DStringFree(&proc_internal_def);
  if (tcl_rc != 0)
  {
   free(prodesc->user_proname);
   free(prodesc->internal_proname);
   free(prodesc);
   ;
   elog_start("pltcl.c", 1476, __func__), elog_finish(20, "could not create internal procedure \"%s\": %s",
     internal_proname, (Tcl_GetStringResult(interp)));
   ;
  }







  proc_ptr->proc_ptr = prodesc;
 }

 ReleaseSysCache(procTup);

 return prodesc;
}





static int
pltcl_elog(ClientData cdata, Tcl_Interp *interp,
     int argc, const char *argv[])
{
 volatile int level;
 MemoryContext oldcontext;

 if (argc != 3)
 {
  Tcl_SetResult(interp, "syntax error - 'elog level msg'", ((Tcl_FreeProc *) 0));
  return 1;
 }

 if (strcmp(argv[1], "DEBUG") == 0)
  level = 13;
 else if (strcmp(argv[1], "LOG") == 0)
  level = 15;
 else if (strcmp(argv[1], "INFO") == 0)
  level = 17;
 else if (strcmp(argv[1], "NOTICE") == 0)
  level = 18;
 else if (strcmp(argv[1], "WARNING") == 0)
  level = 19;
 else if (strcmp(argv[1], "ERROR") == 0)
  level = 20;
 else if (strcmp(argv[1], "FATAL") == 0)
  level = 21;
 else
 {
  Tcl_AppendResult(interp, "Unknown elog level '", argv[1],
       "'", ((void *)0));
  return 1;
 }

 if (level == 20)
 {





  Tcl_SetResult(interp, (char *) argv[2], ((Tcl_FreeProc *) 1));
  return 1;
 }
# 1553 "pltcl.c"
 oldcontext = CurrentMemoryContext;
 do { sigjmp_buf *save_exception_stack = PG_exception_stack; ErrorContextCallback *save_context_stack = error_context_stack; sigjmp_buf local_sigjmp_buf; if (sigsetjmp(local_sigjmp_buf, 0) == 0) { PG_exception_stack = &local_sigjmp_buf;
 {
  ;
  elog_start("pltcl.c", 1557, __func__), elog_finish(level, "%s", (argv[2]));
  ;
 }
 } else { PG_exception_stack = save_exception_stack; error_context_stack = save_context_stack;
 {
  ErrorData *edata;


  MemoryContextSwitchTo(oldcontext);
  edata = CopyErrorData();
  FlushErrorState();


  ;
  Tcl_SetResult(interp, (edata->message), ((Tcl_FreeProc *) 1));
  ;
  FreeErrorData(edata);

  return 1;
 }
 } PG_exception_stack = save_exception_stack; error_context_stack = save_context_stack; } while (0);

 return 0;
}






static int
pltcl_quote(ClientData cdata, Tcl_Interp *interp,
   int argc, const char *argv[])
{
 char *tmp;
 const char *cp1;
 char *cp2;




 if (argc != 2)
 {
  Tcl_SetResult(interp, "syntax error - 'quote string'", ((Tcl_FreeProc *) 0));
  return 1;
 }





 tmp = MemoryContextAlloc(CurrentMemoryContext, (strlen(argv[1]) * 2 + 1));
 cp1 = argv[1];
 cp2 = tmp;




 while (*cp1)
 {
  if (*cp1 == '\'')
   *cp2++ = '\'';
  else
  {
   if (*cp1 == '\\')
    *cp2++ = '\\';
  }
  *cp2++ = *cp1++;
 }




 *cp2 = '\0';
 Tcl_SetResult(interp, tmp, ((Tcl_FreeProc *) 1));
 pfree(tmp);
 return 0;
}





static int
pltcl_argisnull(ClientData cdata, Tcl_Interp *interp,
    int argc, const char *argv[])
{
 int argno;
 FunctionCallInfo fcinfo = pltcl_current_fcinfo;




 if (argc != 2)
 {
  Tcl_SetResult(interp, "syntax error - 'argisnull argno'",
       ((Tcl_FreeProc *) 0));
  return 1;
 }




 if (fcinfo == ((void *)0))
 {
  Tcl_SetResult(interp, "argisnull cannot be used in triggers",
       ((Tcl_FreeProc *) 0));
  return 1;
 }




 if (Tcl_GetInt(interp, argv[1], &argno) != 0)
  return 1;




 argno--;
 if (argno < 0 || argno >= fcinfo->nargs)
 {
  Tcl_SetResult(interp, "argno out of range", ((Tcl_FreeProc *) 0));
  return 1;
 }




 if ((fcinfo->argnull[argno]))
  Tcl_SetResult(interp, "1", ((Tcl_FreeProc *) 0));
 else
  Tcl_SetResult(interp, "0", ((Tcl_FreeProc *) 0));

 return 0;
}





static int
pltcl_returnnull(ClientData cdata, Tcl_Interp *interp,
     int argc, const char *argv[])
{
 FunctionCallInfo fcinfo = pltcl_current_fcinfo;




 if (argc != 1)
 {
  Tcl_SetResult(interp, "syntax error - 'return_null'", ((Tcl_FreeProc *) 0));
  return 1;
 }




 if (fcinfo == ((void *)0))
 {
  Tcl_SetResult(interp, "return_null cannot be used in triggers",
       ((Tcl_FreeProc *) 0));
  return 1;
 }





 fcinfo->isnull = ((bool) 1);

 return 2;
}
# 1757 "pltcl.c"
static void
pltcl_subtrans_begin(MemoryContext oldcontext, ResourceOwner oldowner)
{
 BeginInternalSubTransaction(((void *)0));


 MemoryContextSwitchTo(oldcontext);
}

static void
pltcl_subtrans_commit(MemoryContext oldcontext, ResourceOwner oldowner)
{

 ReleaseCurrentSubTransaction();
 MemoryContextSwitchTo(oldcontext);
 CurrentResourceOwner = oldowner;





 SPI_restore_connection();
}

static void
pltcl_subtrans_abort(Tcl_Interp *interp,
      MemoryContext oldcontext, ResourceOwner oldowner)
{
 ErrorData *edata;


 MemoryContextSwitchTo(oldcontext);
 edata = CopyErrorData();
 FlushErrorState();


 RollbackAndReleaseCurrentSubTransaction();
 MemoryContextSwitchTo(oldcontext);
 CurrentResourceOwner = oldowner;






 SPI_restore_connection();


 ;
 Tcl_SetResult(interp, (edata->message), ((Tcl_FreeProc *) 1));
 ;
 FreeErrorData(edata);
}






static int
pltcl_SPI_execute(ClientData cdata, Tcl_Interp *interp,
      int argc, const char *argv[])
{
 int my_rc;
 int spi_rc;
 int query_idx;
 int i;
 int count = 0;
 const char *volatile arrayname = ((void *)0);
 const char *volatile loop_body = ((void *)0);
 MemoryContext oldcontext = CurrentMemoryContext;
 ResourceOwner oldowner = CurrentResourceOwner;

 char *usage = "syntax error - 'SPI_exec "
 "?-count n? "
 "?-array name? query ?loop body?";




 if (argc < 2)
 {
  Tcl_SetResult(interp, usage, ((Tcl_FreeProc *) 0));
  return 1;
 }

 i = 1;
 while (i < argc)
 {
  if (strcmp(argv[i], "-array") == 0)
  {
   if (++i >= argc)
   {
    Tcl_SetResult(interp, usage, ((Tcl_FreeProc *) 0));
    return 1;
   }
   arrayname = argv[i++];
   continue;
  }

  if (strcmp(argv[i], "-count") == 0)
  {
   if (++i >= argc)
   {
    Tcl_SetResult(interp, usage, ((Tcl_FreeProc *) 0));
    return 1;
   }
   if (Tcl_GetInt(interp, argv[i++], &count) != 0)
    return 1;
   continue;
  }

  break;
 }

 query_idx = i;
 if (query_idx >= argc || query_idx + 2 < argc)
 {
  Tcl_SetResult(interp, usage, ((Tcl_FreeProc *) 0));
  return 1;
 }
 if (query_idx + 1 < argc)
  loop_body = argv[query_idx + 1];






 pltcl_subtrans_begin(oldcontext, oldowner);

 do { sigjmp_buf *save_exception_stack = PG_exception_stack; ErrorContextCallback *save_context_stack = error_context_stack; sigjmp_buf local_sigjmp_buf; if (sigsetjmp(local_sigjmp_buf, 0) == 0) { PG_exception_stack = &local_sigjmp_buf;
 {
  ;
  spi_rc = SPI_execute((argv[query_idx]),
        pltcl_current_prodesc->fn_readonly, count);
  ;

  my_rc = pltcl_process_SPI_result(interp,
           arrayname,
           loop_body,
           spi_rc,
           SPI_tuptable,
           SPI_processed);

  pltcl_subtrans_commit(oldcontext, oldowner);
 }
 } else { PG_exception_stack = save_exception_stack; error_context_stack = save_context_stack;
 {
  pltcl_subtrans_abort(interp, oldcontext, oldowner);
  return 1;
 }
 } PG_exception_stack = save_exception_stack; error_context_stack = save_context_stack; } while (0);

 return my_rc;
}






static int
pltcl_process_SPI_result(Tcl_Interp *interp,
       const char *arrayname,
       const char *loop_body,
       int spi_rc,
       SPITupleTable *tuptable,
       int ntuples)
{
 int my_rc = 0;
 char buf[64];
 int i;
 int loop_rc;
 HeapTuple *tuples;
 TupleDesc tupdesc;

 switch (spi_rc)
 {
  case 6:
  case 7:
  case 8:
  case 9:
   __builtin___snprintf_chk (buf, sizeof(buf), 0, __builtin_object_size (buf, 2 > 1), "%d", ntuples);
   Tcl_SetResult(interp, buf, ((Tcl_FreeProc *) 1));
   break;

  case 4:
  case 14:
   if (tuptable == ((void *)0))
   {
    Tcl_SetResult(interp, "0", ((Tcl_FreeProc *) 0));
    break;
   }


  case 5:
  case 11:
  case 12:
  case 13:




   tuples = tuptable->vals;
   tupdesc = tuptable->tupdesc;

   if (loop_body == ((void *)0))
   {




    if (ntuples > 0)
     pltcl_set_tuple_values(interp, arrayname, 0,
             tuples[0], tupdesc);
   }
   else
   {




    for (i = 0; i < ntuples; i++)
    {
     pltcl_set_tuple_values(interp, arrayname, i,
             tuples[i], tupdesc);

     loop_rc = Tcl_Eval(interp, loop_body);

     if (loop_rc == 0)
      continue;
     if (loop_rc == 4)
      continue;
     if (loop_rc == 2)
     {
      my_rc = 2;
      break;
     }
     if (loop_rc == 3)
      break;
     my_rc = 1;
     break;
    }
   }

   if (my_rc == 0)
   {
    __builtin___snprintf_chk (buf, sizeof(buf), 0, __builtin_object_size (buf, 2 > 1), "%d", ntuples);
    Tcl_SetResult(interp, buf, ((Tcl_FreeProc *) 1));
   }
   break;

  default:
   Tcl_AppendResult(interp, "pltcl: SPI_execute failed: ",
        SPI_result_code_string(spi_rc), ((void *)0));
   my_rc = 1;
   break;
 }

 SPI_freetuptable(tuptable);

 return my_rc;
}
# 2031 "pltcl.c"
static int
pltcl_SPI_prepare(ClientData cdata, Tcl_Interp *interp,
      int argc, const char *argv[])
{
 int nargs;
 const char **args;
 pltcl_query_desc *qdesc;
 int i;
 Tcl_HashEntry *hashent;
 int hashnew;
 Tcl_HashTable *query_hash;
 MemoryContext oldcontext = CurrentMemoryContext;
 ResourceOwner oldowner = CurrentResourceOwner;




 if (argc != 3)
 {
  Tcl_SetResult(interp, "syntax error - 'SPI_prepare query argtypes'",
       ((Tcl_FreeProc *) 0));
  return 1;
 }




 if (Tcl_SplitList(interp, argv[2], &nargs, &args) != 0)
  return 1;




 qdesc = (pltcl_query_desc *) malloc(sizeof(pltcl_query_desc));
 __builtin___snprintf_chk (qdesc->qname, sizeof(qdesc->qname), 0, __builtin_object_size (qdesc->qname, 2 > 1), "%p", qdesc);
 qdesc->nargs = nargs;
 qdesc->argtypes = (Oid *) malloc(nargs * sizeof(Oid));
 qdesc->arginfuncs = (FmgrInfo *) malloc(nargs * sizeof(FmgrInfo));
 qdesc->argtypioparams = (Oid *) malloc(nargs * sizeof(Oid));






 pltcl_subtrans_begin(oldcontext, oldowner);

 do { sigjmp_buf *save_exception_stack = PG_exception_stack; ErrorContextCallback *save_context_stack = error_context_stack; sigjmp_buf local_sigjmp_buf; if (sigsetjmp(local_sigjmp_buf, 0) == 0) { PG_exception_stack = &local_sigjmp_buf;
 {





  for (i = 0; i < nargs; i++)
  {
   Oid typId,
      typInput,
      typIOParam;
   int32 typmod;

   parseTypeString(args[i], &typId, &typmod);

   getTypeInputInfo(typId, &typInput, &typIOParam);

   qdesc->argtypes[i] = typId;
   perm_fmgr_info(typInput, &(qdesc->arginfuncs[i]));
   qdesc->argtypioparams[i] = typIOParam;
  }




  ;
  qdesc->plan = SPI_prepare((argv[1]), nargs, qdesc->argtypes);
  ;

  if (qdesc->plan == ((void *)0))
   elog_start("pltcl.c", 2109, __func__), elog_finish(20, "SPI_prepare() failed");





  if (SPI_keepplan(qdesc->plan))
   elog_start("pltcl.c", 2116, __func__), elog_finish(20, "SPI_keepplan() failed");

  pltcl_subtrans_commit(oldcontext, oldowner);
 }
 } else { PG_exception_stack = save_exception_stack; error_context_stack = save_context_stack;
 {
  pltcl_subtrans_abort(interp, oldcontext, oldowner);

  free(qdesc->argtypes);
  free(qdesc->arginfuncs);
  free(qdesc->argtypioparams);
  free(qdesc);
  Tcl_Free((char *) args);

  return 1;
 }
 } PG_exception_stack = save_exception_stack; error_context_stack = save_context_stack; } while (0);





 query_hash = &pltcl_current_prodesc->interp_desc->query_hash;

 hashent = (*((query_hash)->createProc))(query_hash, qdesc->qname, &hashnew);
 ((hashent)->clientData = (ClientData) ((ClientData) qdesc));

 Tcl_Free((char *) args);


 Tcl_SetResult(interp, qdesc->qname, ((Tcl_FreeProc *) 1));
 return 0;
}





static int
pltcl_SPI_execute_plan(ClientData cdata, Tcl_Interp *interp,
        int argc, const char *argv[])
{
 int my_rc;
 int spi_rc;
 int i;
 int j;
 Tcl_HashEntry *hashent;
 pltcl_query_desc *qdesc;
 const char *volatile nulls = ((void *)0);
 const char *volatile arrayname = ((void *)0);
 const char *volatile loop_body = ((void *)0);
 int count = 0;
 int callnargs;
 const char **callargs = ((void *)0);
 Datum *argvalues;
 MemoryContext oldcontext = CurrentMemoryContext;
 ResourceOwner oldowner = CurrentResourceOwner;
 Tcl_HashTable *query_hash;

 char *usage = "syntax error - 'SPI_execp "
 "?-nulls string? ?-count n? "
 "?-array name? query ?args? ?loop body?";




 i = 1;
 while (i < argc)
 {
  if (strcmp(argv[i], "-array") == 0)
  {
   if (++i >= argc)
   {
    Tcl_SetResult(interp, usage, ((Tcl_FreeProc *) 0));
    return 1;
   }
   arrayname = argv[i++];
   continue;
  }
  if (strcmp(argv[i], "-nulls") == 0)
  {
   if (++i >= argc)
   {
    Tcl_SetResult(interp, usage, ((Tcl_FreeProc *) 0));
    return 1;
   }
   nulls = argv[i++];
   continue;
  }
  if (strcmp(argv[i], "-count") == 0)
  {
   if (++i >= argc)
   {
    Tcl_SetResult(interp, usage, ((Tcl_FreeProc *) 0));
    return 1;
   }
   if (Tcl_GetInt(interp, argv[i++], &count) != 0)
    return 1;
   continue;
  }

  break;
 }




 if (i >= argc)
 {
  Tcl_SetResult(interp, usage, ((Tcl_FreeProc *) 0));
  return 1;
 }

 query_hash = &pltcl_current_prodesc->interp_desc->query_hash;

 hashent = (*((query_hash)->findProc))(query_hash, argv[i]);
 if (hashent == ((void *)0))
 {
  Tcl_AppendResult(interp, "invalid queryid '", argv[i], "'", ((void *)0));
  return 1;
 }
 qdesc = (pltcl_query_desc *) ((hashent)->clientData);
 i++;




 if (nulls != ((void *)0))
 {
  if (strlen(nulls) != qdesc->nargs)
  {
   Tcl_SetResult(interp,
        "length of nulls string doesn't match # of arguments",
        ((Tcl_FreeProc *) 0));
   return 1;
  }
 }





 if (qdesc->nargs > 0)
 {
  if (i >= argc)
  {
   Tcl_SetResult(interp, "missing argument list", ((Tcl_FreeProc *) 0));
   return 1;
  }




  if (Tcl_SplitList(interp, argv[i++], &callnargs, &callargs) != 0)
   return 1;




  if (callnargs != qdesc->nargs)
  {
   Tcl_SetResult(interp,
      "argument list length doesn't match # of arguments for query",
        ((Tcl_FreeProc *) 0));
   Tcl_Free((char *) callargs);
   return 1;
  }
 }
 else
  callnargs = 0;




 if (i < argc)
  loop_body = argv[i++];

 if (i != argc)
 {
  Tcl_SetResult(interp, usage, ((Tcl_FreeProc *) 0));
  return 1;
 }






 pltcl_subtrans_begin(oldcontext, oldowner);

 do { sigjmp_buf *save_exception_stack = PG_exception_stack; ErrorContextCallback *save_context_stack = error_context_stack; sigjmp_buf local_sigjmp_buf; if (sigsetjmp(local_sigjmp_buf, 0) == 0) { PG_exception_stack = &local_sigjmp_buf;
 {




  argvalues = (Datum *) MemoryContextAlloc(CurrentMemoryContext, (callnargs * sizeof(Datum)));

  for (j = 0; j < callnargs; j++)
  {
   if (nulls && nulls[j] == 'n')
   {
    argvalues[j] = InputFunctionCall(&qdesc->arginfuncs[j],
             ((void *)0),
             qdesc->argtypioparams[j],
             -1);
   }
   else
   {
    ;
    argvalues[j] = InputFunctionCall(&qdesc->arginfuncs[j],
              (char *) (callargs[j]),
             qdesc->argtypioparams[j],
             -1);
    ;
   }
  }

  if (callargs)
   Tcl_Free((char *) callargs);
  callargs = ((void *)0);




  spi_rc = SPI_execute_plan(qdesc->plan, argvalues, nulls,
          pltcl_current_prodesc->fn_readonly, count);

  my_rc = pltcl_process_SPI_result(interp,
           arrayname,
           loop_body,
           spi_rc,
           SPI_tuptable,
           SPI_processed);

  pltcl_subtrans_commit(oldcontext, oldowner);
 }
 } else { PG_exception_stack = save_exception_stack; error_context_stack = save_context_stack;
 {
  pltcl_subtrans_abort(interp, oldcontext, oldowner);

  if (callargs)
   Tcl_Free((char *) callargs);

  return 1;
 }
 } PG_exception_stack = save_exception_stack; error_context_stack = save_context_stack; } while (0);

 return my_rc;
}






static int
pltcl_SPI_lastoid(ClientData cdata, Tcl_Interp *interp,
      int argc, const char *argv[])
{
 char buf[64];

 __builtin___snprintf_chk (buf, sizeof(buf), 0, __builtin_object_size (buf, 2 > 1), "%u", SPI_lastoid);
 Tcl_SetResult(interp, buf, ((Tcl_FreeProc *) 1));
 return 0;
}






static void
pltcl_set_tuple_values(Tcl_Interp *interp, const char *arrayname,
        int tupno, HeapTuple tuple, TupleDesc tupdesc)
{
 int i;
 char *outputstr;
 char buf[64];
 Datum attr;
 bool isnull;

 const char *attname;
 HeapTuple typeTup;
 Oid typoutput;

 const char **arrptr;
 const char **nameptr;
 const char *nullname = ((void *)0);





 if (arrayname == ((void *)0))
 {
  arrptr = &attname;
  nameptr = &nullname;
 }
 else
 {
  arrptr = &arrayname;
  nameptr = &attname;
  __builtin___snprintf_chk (buf, sizeof(buf), 0, __builtin_object_size (buf, 2 > 1), "%d", tupno);
  Tcl_SetVar2(interp, arrayname, ".tupno", buf, 0);
 }

 for (i = 0; i < tupdesc->natts; i++)
 {

  if (tupdesc->attrs[i]->attisdropped)
   continue;




  attname = ((tupdesc->attrs[i]->attname).data);




  attr = ( ((i + 1) > 0) ? ( ((i + 1) > (int) (((tuple)->t_data)->t_infomask2 & 0x07FF)) ? ( (*(&isnull) = ((bool) 1)), (Datum)((void *)0) ) : ( ((void)((bool) 1)), (*((&isnull)) = ((bool) 0)), (!(((tuple))->t_data->t_infomask & 0x0001)) ? ( ((tupdesc))->attrs[((i + 1))-1]->attcacheoff >= 0 ? ( ( ((((tupdesc))->attrs[((i + 1))-1])->attbyval) ? ( ((((tupdesc))->attrs[((i + 1))-1])->attlen) == (int) sizeof(Datum) ? *((Datum *)((char *) ((tuple))->t_data + ((tuple))->t_data->t_hoff + ((tupdesc))->attrs[((i + 1))-1]->attcacheoff)) : ( ((((tupdesc))->attrs[((i + 1))-1])->attlen) == (int) sizeof(int32) ? ((Datum) (((Datum) (*((int32 *)((char *) ((tuple))->t_data + ((tuple))->t_data->t_hoff + ((tupdesc))->attrs[((i + 1))-1]->attcacheoff)))) & 0xffffffff)) : ( ((((tupdesc))->attrs[((i + 1))-1])->attlen) == (int) sizeof(int16) ? ((Datum) (((Datum) (*((int16 *)((char *) ((tuple))->t_data + ((tuple))->t_data->t_hoff + ((tupdesc))->attrs[((i + 1))-1]->attcacheoff)))) & 0x0000ffff)) : ( ((void)((bool) 1)), ((Datum) (((Datum) (*((char *)((char *) ((tuple))->t_data + ((tuple))->t_data->t_hoff + ((tupdesc))->attrs[((i + 1))-1]->attcacheoff)))) & 0x000000ff)) ) ) ) ) : ((Datum) ((char *) ((char *) ((tuple))->t_data + ((tuple))->t_data->t_hoff + ((tupdesc))->attrs[((i + 1))-1]->attcacheoff))) ) ) : nocachegetattr(((tuple)), ((i + 1)), ((tupdesc))) ) : ( (!((((tuple))->t_data->t_bits)[(((i + 1))-1) >> 3] & (1 << ((((i + 1))-1) & 0x07)))) ? ( (*((&isnull)) = ((bool) 1)), (Datum)((void *)0) ) : ( nocachegetattr(((tuple)), ((i + 1)), ((tupdesc))) ) ) ) ) : heap_getsysattr((tuple), (i + 1), (tupdesc), (&isnull)) );





  typeTup = SearchSysCache(TYPEOID, ((Datum) (((Datum) (tupdesc->attrs[i]->atttypid)) & 0xffffffff)), 0, 0, 0);

  if (!((const void*)(typeTup) != ((void *)0)))
   elog_start("pltcl.c", 2446, __func__), elog_finish(20, "cache lookup failed for type %u",
     tupdesc->attrs[i]->atttypid);

  typoutput = ((Form_pg_type) ((char *) ((typeTup)->t_data) + (typeTup)->t_data->t_hoff))->typoutput;
  ReleaseSysCache(typeTup);
# 2460 "pltcl.c"
  if (!isnull && ((bool) ((typoutput) != ((Oid) 0))))
  {
   outputstr = OidOutputFunctionCall(typoutput, attr);
   ;
   Tcl_SetVar2(interp, *arrptr, *nameptr, (outputstr), 0);
   ;
   pfree(outputstr);
  }
  else
   Tcl_UnsetVar2(interp, *arrptr, *nameptr, 0);
 }
}






static void
pltcl_build_tuple_argument(HeapTuple tuple, TupleDesc tupdesc,
         Tcl_DString *retval)
{
 int i;
 char *outputstr;
 Datum attr;
 bool isnull;

 char *attname;
 HeapTuple typeTup;
 Oid typoutput;

 for (i = 0; i < tupdesc->natts; i++)
 {

  if (tupdesc->attrs[i]->attisdropped)
   continue;




  attname = ((tupdesc->attrs[i]->attname).data);




  attr = ( ((i + 1) > 0) ? ( ((i + 1) > (int) (((tuple)->t_data)->t_infomask2 & 0x07FF)) ? ( (*(&isnull) = ((bool) 1)), (Datum)((void *)0) ) : ( ((void)((bool) 1)), (*((&isnull)) = ((bool) 0)), (!(((tuple))->t_data->t_infomask & 0x0001)) ? ( ((tupdesc))->attrs[((i + 1))-1]->attcacheoff >= 0 ? ( ( ((((tupdesc))->attrs[((i + 1))-1])->attbyval) ? ( ((((tupdesc))->attrs[((i + 1))-1])->attlen) == (int) sizeof(Datum) ? *((Datum *)((char *) ((tuple))->t_data + ((tuple))->t_data->t_hoff + ((tupdesc))->attrs[((i + 1))-1]->attcacheoff)) : ( ((((tupdesc))->attrs[((i + 1))-1])->attlen) == (int) sizeof(int32) ? ((Datum) (((Datum) (*((int32 *)((char *) ((tuple))->t_data + ((tuple))->t_data->t_hoff + ((tupdesc))->attrs[((i + 1))-1]->attcacheoff)))) & 0xffffffff)) : ( ((((tupdesc))->attrs[((i + 1))-1])->attlen) == (int) sizeof(int16) ? ((Datum) (((Datum) (*((int16 *)((char *) ((tuple))->t_data + ((tuple))->t_data->t_hoff + ((tupdesc))->attrs[((i + 1))-1]->attcacheoff)))) & 0x0000ffff)) : ( ((void)((bool) 1)), ((Datum) (((Datum) (*((char *)((char *) ((tuple))->t_data + ((tuple))->t_data->t_hoff + ((tupdesc))->attrs[((i + 1))-1]->attcacheoff)))) & 0x000000ff)) ) ) ) ) : ((Datum) ((char *) ((char *) ((tuple))->t_data + ((tuple))->t_data->t_hoff + ((tupdesc))->attrs[((i + 1))-1]->attcacheoff))) ) ) : nocachegetattr(((tuple)), ((i + 1)), ((tupdesc))) ) : ( (!((((tuple))->t_data->t_bits)[(((i + 1))-1) >> 3] & (1 << ((((i + 1))-1) & 0x07)))) ? ( (*((&isnull)) = ((bool) 1)), (Datum)((void *)0) ) : ( nocachegetattr(((tuple)), ((i + 1)), ((tupdesc))) ) ) ) ) : heap_getsysattr((tuple), (i + 1), (tupdesc), (&isnull)) );





  typeTup = SearchSysCache(TYPEOID, ((Datum) (((Datum) (tupdesc->attrs[i]->atttypid)) & 0xffffffff)), 0, 0, 0);

  if (!((const void*)(typeTup) != ((void *)0)))
   elog_start("pltcl.c", 2514, __func__), elog_finish(20, "cache lookup failed for type %u",
     tupdesc->attrs[i]->atttypid);

  typoutput = ((Form_pg_type) ((char *) ((typeTup)->t_data) + (typeTup)->t_data->t_hoff))->typoutput;
  ReleaseSysCache(typeTup);
# 2528 "pltcl.c"
  if (!isnull && ((bool) ((typoutput) != ((Oid) 0))))
  {
   outputstr = OidOutputFunctionCall(typoutput, attr);
   Tcl_DStringAppendElement(retval, attname);
   ;
   Tcl_DStringAppendElement(retval, (outputstr));
   ;
   pfree(outputstr);
  }
 }
}

# 1 "pg_ctl.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "pg_ctl.c"
# 20 "pg_ctl.c"
# 1 "postgres_fe.h" 1
# 25 "postgres_fe.h"
# 1 "c.h" 1
# 53 "c.h"
# 1 "pg_config.h" 1
# 54 "c.h" 2
# 1 "pg_config_manual.h" 1
# 55 "c.h" 2


# 1 "pg_config_os.h" 1
# 58 "c.h" 2

# 1 "postgres_ext.h" 1
# 29 "postgres_ext.h"
typedef unsigned int Oid;
# 60 "c.h" 2







# 1 "/usr/include/stdio.h" 1 3 4
# 64 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/sys/cdefs.h" 1 3 4
# 417 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 418 "/usr/include/sys/cdefs.h" 2 3 4
# 494 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_posix_availability.h" 1 3 4
# 495 "/usr/include/sys/cdefs.h" 2 3 4
# 65 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/Availability.h" 1 3 4
# 141 "/usr/include/Availability.h" 3 4
# 1 "/usr/include/AvailabilityInternal.h" 1 3 4
# 142 "/usr/include/Availability.h" 2 3 4
# 66 "/usr/include/stdio.h" 2 3 4

# 1 "/usr/include/_types.h" 1 3 4
# 27 "/usr/include/_types.h" 3 4
# 1 "/usr/include/sys/_types.h" 1 3 4
# 33 "/usr/include/sys/_types.h" 3 4
# 1 "/usr/include/machine/_types.h" 1 3 4
# 32 "/usr/include/machine/_types.h" 3 4
# 1 "/usr/include/i386/_types.h" 1 3 4
# 37 "/usr/include/i386/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 70 "/usr/include/i386/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;


typedef long int __darwin_ptrdiff_t;





typedef long unsigned int __darwin_size_t;





typedef __builtin_va_list __darwin_va_list;





typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 33 "/usr/include/machine/_types.h" 2 3 4
# 34 "/usr/include/sys/_types.h" 2 3 4
# 58 "/usr/include/sys/_types.h" 3 4
struct __darwin_pthread_handler_rec
{
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};
struct _opaque_pthread_attr_t { long __sig; char __opaque[56]; };
struct _opaque_pthread_cond_t { long __sig; char __opaque[40]; };
struct _opaque_pthread_condattr_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_mutex_t { long __sig; char __opaque[56]; };
struct _opaque_pthread_mutexattr_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_once_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_rwlock_t { long __sig; char __opaque[192]; };
struct _opaque_pthread_rwlockattr_t { long __sig; char __opaque[16]; };
struct _opaque_pthread_t { long __sig; struct __darwin_pthread_handler_rec *__cleanup_stack; char __opaque[1168]; };
# 94 "/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef struct _opaque_pthread_attr_t
   __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t
   __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t
   __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t
   __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t
   __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t
   __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t
   __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t
   __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t
   *__darwin_pthread_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];
# 28 "/usr/include/_types.h" 2 3 4
# 39 "/usr/include/_types.h" 3 4
typedef int __darwin_nl_item;
typedef int __darwin_wctrans_t;

typedef __uint32_t __darwin_wctype_t;
# 68 "/usr/include/stdio.h" 2 3 4





typedef __darwin_va_list va_list;




typedef __darwin_size_t size_t;






typedef __darwin_off_t fpos_t;
# 96 "/usr/include/stdio.h" 3 4
struct __sbuf {
 unsigned char *_base;
 int _size;
};


struct __sFILEX;
# 130 "/usr/include/stdio.h" 3 4
typedef struct __sFILE {
 unsigned char *_p;
 int _r;
 int _w;
 short _flags;
 short _file;
 struct __sbuf _bf;
 int _lbfsize;


 void *_cookie;
 int (*_close)(void *);
 int (*_read) (void *, char *, int);
 fpos_t (*_seek) (void *, fpos_t, int);
 int (*_write)(void *, const char *, int);


 struct __sbuf _ub;
 struct __sFILEX *_extra;
 int _ur;


 unsigned char _ubuf[3];
 unsigned char _nbuf[1];


 struct __sbuf _lb;


 int _blksize;
 fpos_t _offset;
} FILE;


extern FILE *__stdinp;
extern FILE *__stdoutp;
extern FILE *__stderrp;

# 238 "/usr/include/stdio.h" 3 4

void clearerr(FILE *);
int fclose(FILE *);
int feof(FILE *);
int ferror(FILE *);
int fflush(FILE *);
int fgetc(FILE *);
int fgetpos(FILE * , fpos_t *);
char *fgets(char * , int, FILE *);



FILE *fopen(const char * , const char * ) __asm("_" "fopen" );

int fprintf(FILE * , const char * , ...) __attribute__((__format__ (__printf__, 2, 3)));
int fputc(int, FILE *);
int fputs(const char * , FILE * ) __asm("_" "fputs" );
size_t fread(void * , size_t, size_t, FILE * );
FILE *freopen(const char * , const char * ,
                 FILE * ) __asm("_" "freopen" );
int fscanf(FILE * , const char * , ...) __attribute__((__format__ (__scanf__, 2, 3)));
int fseek(FILE *, long, int);
int fsetpos(FILE *, const fpos_t *);
long ftell(FILE *);
size_t fwrite(const void * , size_t, size_t, FILE * ) __asm("_" "fwrite" );
int getc(FILE *);
int getchar(void);
char *gets(char *);
void perror(const char *);
int printf(const char * , ...) __attribute__((__format__ (__printf__, 1, 2)));
int putc(int, FILE *);
int putchar(int);
int puts(const char *);
int remove(const char *);
int rename (const char *, const char *);
void rewind(FILE *);
int scanf(const char * , ...) __attribute__((__format__ (__scanf__, 1, 2)));
void setbuf(FILE * , char * );
int setvbuf(FILE * , char * , int, size_t);
int sprintf(char * , const char * , ...) __attribute__((__format__ (__printf__, 2, 3)));
int sscanf(const char * , const char * , ...) __attribute__((__format__ (__scanf__, 2, 3)));
FILE *tmpfile(void);
char *tmpnam(char *);
int ungetc(int, FILE *);
int vfprintf(FILE * , const char * , va_list) __attribute__((__format__ (__printf__, 2, 0)));
int vprintf(const char * , va_list) __attribute__((__format__ (__printf__, 1, 0)));
int vsprintf(char * , const char * , va_list) __attribute__((__format__ (__printf__, 2, 0)));

# 296 "/usr/include/stdio.h" 3 4




char *ctermid(char *);





FILE *fdopen(int, const char *) __asm("_" "fdopen" );

int fileno(FILE *);

# 318 "/usr/include/stdio.h" 3 4

int pclose(FILE *);



FILE *popen(const char *, const char *) __asm("_" "popen" );


# 340 "/usr/include/stdio.h" 3 4

int __srget(FILE *);
int __svfscanf(FILE *, const char *, va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int __swbuf(int, FILE *);








static __inline int __sputc(int _c, FILE *_p) {
 if (--_p->_w >= 0 || (_p->_w >= _p->_lbfsize && (char)_c != '\n'))
  return (*_p->_p++ = _c);
 else
  return (__swbuf(_c, _p));
}
# 377 "/usr/include/stdio.h" 3 4

void flockfile(FILE *);
int ftrylockfile(FILE *);
void funlockfile(FILE *);
int getc_unlocked(FILE *);
int getchar_unlocked(void);
int putc_unlocked(int, FILE *);
int putchar_unlocked(int);



int getw(FILE *);
int putw(int, FILE *);


char *tempnam(const char *, const char *) __asm("_" "tempnam" );

# 414 "/usr/include/stdio.h" 3 4
typedef __darwin_off_t off_t;



int fseeko(FILE *, off_t, int);
off_t ftello(FILE *);





int snprintf(char * , size_t, const char * , ...) __attribute__((__format__ (__printf__, 3, 4)));
int vfscanf(FILE * , const char * , va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int vscanf(const char * , va_list) __attribute__((__format__ (__scanf__, 1, 0)));
int vsnprintf(char * , size_t, const char * , va_list) __attribute__((__format__ (__printf__, 3, 0)));
int vsscanf(const char * , const char * , va_list) __attribute__((__format__ (__scanf__, 2, 0)));

# 442 "/usr/include/stdio.h" 3 4
typedef __darwin_ssize_t ssize_t;



int dprintf(int, const char * , ...) __attribute__((__format__ (__printf__, 2, 3))) __attribute__((visibility("default")));
int vdprintf(int, const char * , va_list) __attribute__((__format__ (__printf__, 2, 0))) __attribute__((visibility("default")));
ssize_t getdelim(char ** , size_t * , int, FILE * ) __attribute__((visibility("default")));
ssize_t getline(char ** , size_t * , FILE * ) __attribute__((visibility("default")));









extern const int sys_nerr;
extern const char *const sys_errlist[];

int asprintf(char **, const char *, ...) __attribute__((__format__ (__printf__, 2, 3)));
char *ctermid_r(char *);
char *fgetln(FILE *, size_t *);
const char *fmtcheck(const char *, const char *);
int fpurge(FILE *);
void setbuffer(FILE *, char *, int);
int setlinebuf(FILE *);
int vasprintf(char **, const char *, va_list) __attribute__((__format__ (__printf__, 2, 0)));
FILE *zopen(const char *, const char *, int);





FILE *funopen(const void *,
                 int (*)(void *, char *, int),
                 int (*)(void *, const char *, int),
                 fpos_t (*)(void *, fpos_t, int),
                 int (*)(void *));

# 499 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/secure/_stdio.h" 1 3 4
# 31 "/usr/include/secure/_stdio.h" 3 4
# 1 "/usr/include/secure/_common.h" 1 3 4
# 32 "/usr/include/secure/_stdio.h" 2 3 4
# 45 "/usr/include/secure/_stdio.h" 3 4
extern int __sprintf_chk (char * , int, size_t,
     const char * , ...)
  ;




extern int __snprintf_chk (char * , size_t, int, size_t,
      const char * , ...)
  ;





extern int __vsprintf_chk (char * , int, size_t,
      const char * , va_list)
  ;




extern int __vsnprintf_chk (char * , size_t, int, size_t,
       const char * , va_list)
  ;
# 500 "/usr/include/stdio.h" 2 3 4
# 68 "c.h" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 65 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/sys/wait.h" 1 3 4
# 79 "/usr/include/sys/wait.h" 3 4
typedef enum {
 P_ALL,
 P_PID,
 P_PGID
} idtype_t;






typedef __darwin_pid_t pid_t;




typedef __darwin_id_t id_t;
# 116 "/usr/include/sys/wait.h" 3 4
# 1 "/usr/include/sys/signal.h" 1 3 4
# 73 "/usr/include/sys/signal.h" 3 4
# 1 "/usr/include/sys/appleapiopts.h" 1 3 4
# 74 "/usr/include/sys/signal.h" 2 3 4







# 1 "/usr/include/machine/signal.h" 1 3 4
# 32 "/usr/include/machine/signal.h" 3 4
# 1 "/usr/include/i386/signal.h" 1 3 4
# 39 "/usr/include/i386/signal.h" 3 4
typedef int sig_atomic_t;
# 55 "/usr/include/i386/signal.h" 3 4
# 1 "/usr/include/i386/_structs.h" 1 3 4
# 56 "/usr/include/i386/signal.h" 2 3 4
# 33 "/usr/include/machine/signal.h" 2 3 4
# 82 "/usr/include/sys/signal.h" 2 3 4
# 148 "/usr/include/sys/signal.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 57 "/usr/include/sys/_structs.h" 3 4
# 1 "/usr/include/machine/_structs.h" 1 3 4
# 29 "/usr/include/machine/_structs.h" 3 4
# 1 "/usr/include/i386/_structs.h" 1 3 4
# 38 "/usr/include/i386/_structs.h" 3 4
# 1 "/usr/include/mach/i386/_structs.h" 1 3 4
# 43 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_thread_state
{
    unsigned int __eax;
    unsigned int __ebx;
    unsigned int __ecx;
    unsigned int __edx;
    unsigned int __edi;
    unsigned int __esi;
    unsigned int __ebp;
    unsigned int __esp;
    unsigned int __ss;
    unsigned int __eflags;
    unsigned int __eip;
    unsigned int __cs;
    unsigned int __ds;
    unsigned int __es;
    unsigned int __fs;
    unsigned int __gs;
};
# 89 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_fp_control
{
    unsigned short __invalid :1,
        __denorm :1,
    __zdiv :1,
    __ovrfl :1,
    __undfl :1,
    __precis :1,
      :2,
    __pc :2,





    __rc :2,






             :1,
      :3;
};
typedef struct __darwin_fp_control __darwin_fp_control_t;
# 147 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_fp_status
{
    unsigned short __invalid :1,
        __denorm :1,
    __zdiv :1,
    __ovrfl :1,
    __undfl :1,
    __precis :1,
    __stkflt :1,
    __errsumm :1,
    __c0 :1,
    __c1 :1,
    __c2 :1,
    __tos :3,
    __c3 :1,
    __busy :1;
};
typedef struct __darwin_fp_status __darwin_fp_status_t;
# 191 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_mmst_reg
{
 char __mmst_reg[10];
 char __mmst_rsrv[6];
};
# 210 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_xmm_reg
{
 char __xmm_reg[16];
};
# 232 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_float_state
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;
 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;
 __uint16_t __fpu_rsrv2;
 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;
 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 char __fpu_rsrv4[14*16];
 int __fpu_reserved1;
};


struct __darwin_i386_avx_state
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;
 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;
 __uint16_t __fpu_rsrv2;
 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;
 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 char __fpu_rsrv4[14*16];
 int __fpu_reserved1;
 char __avx_reserved1[64];
 struct __darwin_xmm_reg __fpu_ymmh0;
 struct __darwin_xmm_reg __fpu_ymmh1;
 struct __darwin_xmm_reg __fpu_ymmh2;
 struct __darwin_xmm_reg __fpu_ymmh3;
 struct __darwin_xmm_reg __fpu_ymmh4;
 struct __darwin_xmm_reg __fpu_ymmh5;
 struct __darwin_xmm_reg __fpu_ymmh6;
 struct __darwin_xmm_reg __fpu_ymmh7;
};
# 402 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_exception_state
{
 __uint16_t __trapno;
 __uint16_t __cpu;
 __uint32_t __err;
 __uint32_t __faultvaddr;
};
# 422 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_debug_state32
{
 unsigned int __dr0;
 unsigned int __dr1;
 unsigned int __dr2;
 unsigned int __dr3;
 unsigned int __dr4;
 unsigned int __dr5;
 unsigned int __dr6;
 unsigned int __dr7;
};
# 454 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_thread_state64
{
 __uint64_t __rax;
 __uint64_t __rbx;
 __uint64_t __rcx;
 __uint64_t __rdx;
 __uint64_t __rdi;
 __uint64_t __rsi;
 __uint64_t __rbp;
 __uint64_t __rsp;
 __uint64_t __r8;
 __uint64_t __r9;
 __uint64_t __r10;
 __uint64_t __r11;
 __uint64_t __r12;
 __uint64_t __r13;
 __uint64_t __r14;
 __uint64_t __r15;
 __uint64_t __rip;
 __uint64_t __rflags;
 __uint64_t __cs;
 __uint64_t __fs;
 __uint64_t __gs;
};
# 509 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_float_state64
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;


 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;

 __uint16_t __fpu_rsrv2;


 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;

 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 struct __darwin_xmm_reg __fpu_xmm8;
 struct __darwin_xmm_reg __fpu_xmm9;
 struct __darwin_xmm_reg __fpu_xmm10;
 struct __darwin_xmm_reg __fpu_xmm11;
 struct __darwin_xmm_reg __fpu_xmm12;
 struct __darwin_xmm_reg __fpu_xmm13;
 struct __darwin_xmm_reg __fpu_xmm14;
 struct __darwin_xmm_reg __fpu_xmm15;
 char __fpu_rsrv4[6*16];
 int __fpu_reserved1;
};


struct __darwin_x86_avx_state64
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;


 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;

 __uint16_t __fpu_rsrv2;


 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;

 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 struct __darwin_xmm_reg __fpu_xmm8;
 struct __darwin_xmm_reg __fpu_xmm9;
 struct __darwin_xmm_reg __fpu_xmm10;
 struct __darwin_xmm_reg __fpu_xmm11;
 struct __darwin_xmm_reg __fpu_xmm12;
 struct __darwin_xmm_reg __fpu_xmm13;
 struct __darwin_xmm_reg __fpu_xmm14;
 struct __darwin_xmm_reg __fpu_xmm15;
 char __fpu_rsrv4[6*16];
 int __fpu_reserved1;
 char __avx_reserved1[64];
 struct __darwin_xmm_reg __fpu_ymmh0;
 struct __darwin_xmm_reg __fpu_ymmh1;
 struct __darwin_xmm_reg __fpu_ymmh2;
 struct __darwin_xmm_reg __fpu_ymmh3;
 struct __darwin_xmm_reg __fpu_ymmh4;
 struct __darwin_xmm_reg __fpu_ymmh5;
 struct __darwin_xmm_reg __fpu_ymmh6;
 struct __darwin_xmm_reg __fpu_ymmh7;
 struct __darwin_xmm_reg __fpu_ymmh8;
 struct __darwin_xmm_reg __fpu_ymmh9;
 struct __darwin_xmm_reg __fpu_ymmh10;
 struct __darwin_xmm_reg __fpu_ymmh11;
 struct __darwin_xmm_reg __fpu_ymmh12;
 struct __darwin_xmm_reg __fpu_ymmh13;
 struct __darwin_xmm_reg __fpu_ymmh14;
 struct __darwin_xmm_reg __fpu_ymmh15;
};
# 751 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_exception_state64
{
    __uint16_t __trapno;
    __uint16_t __cpu;
    __uint32_t __err;
    __uint64_t __faultvaddr;
};
# 771 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_debug_state64
{
 __uint64_t __dr0;
 __uint64_t __dr1;
 __uint64_t __dr2;
 __uint64_t __dr3;
 __uint64_t __dr4;
 __uint64_t __dr5;
 __uint64_t __dr6;
 __uint64_t __dr7;
};
# 39 "/usr/include/i386/_structs.h" 2 3 4
# 48 "/usr/include/i386/_structs.h" 3 4
struct __darwin_mcontext32
{
 struct __darwin_i386_exception_state __es;
 struct __darwin_i386_thread_state __ss;
 struct __darwin_i386_float_state __fs;
};


struct __darwin_mcontext_avx32
{
 struct __darwin_i386_exception_state __es;
 struct __darwin_i386_thread_state __ss;
 struct __darwin_i386_avx_state __fs;
};
# 86 "/usr/include/i386/_structs.h" 3 4
struct __darwin_mcontext64
{
 struct __darwin_x86_exception_state64 __es;
 struct __darwin_x86_thread_state64 __ss;
 struct __darwin_x86_float_state64 __fs;
};


struct __darwin_mcontext_avx64
{
 struct __darwin_x86_exception_state64 __es;
 struct __darwin_x86_thread_state64 __ss;
 struct __darwin_x86_avx_state64 __fs;
};
# 127 "/usr/include/i386/_structs.h" 3 4
typedef struct __darwin_mcontext64 *mcontext_t;
# 30 "/usr/include/machine/_structs.h" 2 3 4
# 58 "/usr/include/sys/_structs.h" 2 3 4
# 75 "/usr/include/sys/_structs.h" 3 4
struct __darwin_sigaltstack
{
 void *ss_sp;
 __darwin_size_t ss_size;
 int ss_flags;
};
# 128 "/usr/include/sys/_structs.h" 3 4
struct __darwin_ucontext
{
 int uc_onstack;
 __darwin_sigset_t uc_sigmask;
 struct __darwin_sigaltstack uc_stack;
 struct __darwin_ucontext *uc_link;
 __darwin_size_t uc_mcsize;
 struct __darwin_mcontext64 *uc_mcontext;



};
# 218 "/usr/include/sys/_structs.h" 3 4
typedef struct __darwin_sigaltstack stack_t;
# 227 "/usr/include/sys/_structs.h" 3 4
typedef struct __darwin_ucontext ucontext_t;
# 149 "/usr/include/sys/signal.h" 2 3 4
# 157 "/usr/include/sys/signal.h" 3 4
typedef __darwin_pthread_attr_t pthread_attr_t;




typedef __darwin_sigset_t sigset_t;
# 172 "/usr/include/sys/signal.h" 3 4
typedef __darwin_uid_t uid_t;


union sigval {

 int sival_int;
 void *sival_ptr;
};





struct sigevent {
 int sigev_notify;
 int sigev_signo;
 union sigval sigev_value;
 void (*sigev_notify_function)(union sigval);
 pthread_attr_t *sigev_notify_attributes;
};


typedef struct __siginfo {
 int si_signo;
 int si_errno;
 int si_code;
 pid_t si_pid;
 uid_t si_uid;
 int si_status;
 void *si_addr;
 union sigval si_value;
 long si_band;
 unsigned long __pad[7];
} siginfo_t;
# 286 "/usr/include/sys/signal.h" 3 4
union __sigaction_u {
 void (*__sa_handler)(int);
 void (*__sa_sigaction)(int, struct __siginfo *,
         void *);
};


struct __sigaction {
 union __sigaction_u __sigaction_u;
 void (*sa_tramp)(void *, int, int, siginfo_t *, void *);
 sigset_t sa_mask;
 int sa_flags;
};




struct sigaction {
 union __sigaction_u __sigaction_u;
 sigset_t sa_mask;
 int sa_flags;
};
# 348 "/usr/include/sys/signal.h" 3 4
typedef void (*sig_t)(int);
# 365 "/usr/include/sys/signal.h" 3 4
struct sigvec {
 void (*sv_handler)(int);
 int sv_mask;
 int sv_flags;
};
# 384 "/usr/include/sys/signal.h" 3 4
struct sigstack {
 char *ss_sp;
 int ss_onstack;
};
# 406 "/usr/include/sys/signal.h" 3 4

void (*signal(int, void (*)(int)))(int);

# 117 "/usr/include/sys/wait.h" 2 3 4
# 1 "/usr/include/sys/resource.h" 1 3 4
# 77 "/usr/include/sys/resource.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 100 "/usr/include/sys/_structs.h" 3 4
struct timeval
{
 __darwin_time_t tv_sec;
 __darwin_suseconds_t tv_usec;
};
# 78 "/usr/include/sys/resource.h" 2 3 4
# 89 "/usr/include/sys/resource.h" 3 4
typedef __uint64_t rlim_t;
# 151 "/usr/include/sys/resource.h" 3 4
struct rusage {
 struct timeval ru_utime;
 struct timeval ru_stime;
# 162 "/usr/include/sys/resource.h" 3 4
 long ru_maxrss;

 long ru_ixrss;
 long ru_idrss;
 long ru_isrss;
 long ru_minflt;
 long ru_majflt;
 long ru_nswap;
 long ru_inblock;
 long ru_oublock;
 long ru_msgsnd;
 long ru_msgrcv;
 long ru_nsignals;
 long ru_nvcsw;
 long ru_nivcsw;


};
# 222 "/usr/include/sys/resource.h" 3 4
struct rlimit {
 rlim_t rlim_cur;
 rlim_t rlim_max;
};
# 244 "/usr/include/sys/resource.h" 3 4

int getpriority(int, id_t);

int getiopolicy_np(int, int) __attribute__((visibility("default")));

int getrlimit(int, struct rlimit *) __asm("_" "getrlimit" );
int getrusage(int, struct rusage *);
int setpriority(int, id_t, int);

int setiopolicy_np(int, int, int) __attribute__((visibility("default")));

int setrlimit(int, const struct rlimit *) __asm("_" "setrlimit" );

# 118 "/usr/include/sys/wait.h" 2 3 4
# 193 "/usr/include/sys/wait.h" 3 4
# 1 "/usr/include/machine/endian.h" 1 3 4
# 35 "/usr/include/machine/endian.h" 3 4
# 1 "/usr/include/i386/endian.h" 1 3 4
# 99 "/usr/include/i386/endian.h" 3 4
# 1 "/usr/include/sys/_endian.h" 1 3 4
# 124 "/usr/include/sys/_endian.h" 3 4
# 1 "/usr/include/libkern/_OSByteOrder.h" 1 3 4
# 66 "/usr/include/libkern/_OSByteOrder.h" 3 4
# 1 "/usr/include/libkern/i386/_OSByteOrder.h" 1 3 4
# 44 "/usr/include/libkern/i386/_OSByteOrder.h" 3 4
static __inline__
__uint16_t
_OSSwapInt16(
    __uint16_t _data
)
{
    return ((_data << 8) | (_data >> 8));
}

static __inline__
__uint32_t
_OSSwapInt32(
    __uint32_t _data
)
{

    return __builtin_bswap32(_data);




}


static __inline__
__uint64_t
_OSSwapInt64(
    __uint64_t _data
)
{
    return __builtin_bswap64(_data);
}
# 67 "/usr/include/libkern/_OSByteOrder.h" 2 3 4
# 125 "/usr/include/sys/_endian.h" 2 3 4
# 100 "/usr/include/i386/endian.h" 2 3 4
# 36 "/usr/include/machine/endian.h" 2 3 4
# 194 "/usr/include/sys/wait.h" 2 3 4







union wait {
 int w_status;



 struct {

  unsigned int w_Termsig:7,
    w_Coredump:1,
    w_Retcode:8,
    w_Filler:16;







 } w_T;





 struct {

  unsigned int w_Stopval:8,
    w_Stopsig:8,
    w_Filler:16;






 } w_S;
};
# 254 "/usr/include/sys/wait.h" 3 4

pid_t wait(int *) __asm("_" "wait" );
pid_t waitpid(pid_t, int *, int) __asm("_" "waitpid" );

int waitid(idtype_t, id_t, siginfo_t *, int) __asm("_" "waitid" );


pid_t wait3(int *, int, struct rusage *);
pid_t wait4(pid_t, int *, int, struct rusage *);


# 66 "/usr/include/stdlib.h" 2 3 4

# 1 "/usr/include/alloca.h" 1 3 4
# 35 "/usr/include/alloca.h" 3 4

void *alloca(size_t);

# 68 "/usr/include/stdlib.h" 2 3 4
# 81 "/usr/include/stdlib.h" 3 4
typedef __darwin_ct_rune_t ct_rune_t;




typedef __darwin_rune_t rune_t;






typedef __darwin_wchar_t wchar_t;



typedef struct {
 int quot;
 int rem;
} div_t;

typedef struct {
 long quot;
 long rem;
} ldiv_t;


typedef struct {
 long long quot;
 long long rem;
} lldiv_t;
# 134 "/usr/include/stdlib.h" 3 4
extern int __mb_cur_max;
# 144 "/usr/include/stdlib.h" 3 4

void abort(void) __attribute__((__noreturn__));
int abs(int) __attribute__((__const__));
int atexit(void (*)(void));
double atof(const char *);
int atoi(const char *);
long atol(const char *);

long long
  atoll(const char *);

void *bsearch(const void *, const void *, size_t,
     size_t, int (*)(const void *, const void *));
void *calloc(size_t, size_t);
div_t div(int, int) __attribute__((__const__));
void exit(int) __attribute__((__noreturn__));
void free(void *);
char *getenv(const char *);
long labs(long) __attribute__((__const__));
ldiv_t ldiv(long, long) __attribute__((__const__));

long long
  llabs(long long);
lldiv_t lldiv(long long, long long);

void *malloc(size_t);
int mblen(const char *, size_t);
size_t mbstowcs(wchar_t * , const char * , size_t);
int mbtowc(wchar_t * , const char * , size_t);
int posix_memalign(void **, size_t, size_t) __attribute__((visibility("default")));
void qsort(void *, size_t, size_t,
     int (*)(const void *, const void *));
int rand(void);
void *realloc(void *, size_t);
void srand(unsigned);
double strtod(const char *, char **) __asm("_" "strtod" );
float strtof(const char *, char **) __asm("_" "strtof" );
long strtol(const char *, char **, int);
long double
  strtold(const char *, char **) ;

long long
  strtoll(const char *, char **, int);

unsigned long
  strtoul(const char *, char **, int);

unsigned long long
  strtoull(const char *, char **, int);

int system(const char *) __asm("_" "system" );
size_t wcstombs(char * , const wchar_t * , size_t);
int wctomb(char *, wchar_t);


void _Exit(int) __attribute__((__noreturn__));
long a64l(const char *);
double drand48(void);
char *ecvt(double, int, int *, int *);
double erand48(unsigned short[3]);
char *fcvt(double, int, int *, int *);
char *gcvt(double, int, char *);
int getsubopt(char **, char * const *, char **);
int grantpt(int);

char *initstate(unsigned, char *, size_t);



long jrand48(unsigned short[3]);
char *l64a(long);
void lcong48(unsigned short[7]);
long lrand48(void);
char *mktemp(char *);
int mkstemp(char *);
long mrand48(void);
long nrand48(unsigned short[3]);
int posix_openpt(int);
char *ptsname(int);
int putenv(char *) __asm("_" "putenv" );
long random(void);
int rand_r(unsigned *);

char *realpath(const char * , char * ) __asm("_" "realpath" "$DARWIN_EXTSN");



unsigned short
 *seed48(unsigned short[3]);
int setenv(const char *, const char *, int) __asm("_" "setenv" );

void setkey(const char *) __asm("_" "setkey" );



char *setstate(const char *);
void srand48(long);

void srandom(unsigned);



int unlockpt(int);

int unsetenv(const char *) __asm("_" "unsetenv" );






# 1 "/usr/include/machine/types.h" 1 3 4
# 35 "/usr/include/machine/types.h" 3 4
# 1 "/usr/include/i386/types.h" 1 3 4
# 70 "/usr/include/i386/types.h" 3 4
# 1 "/usr/include/i386/_types.h" 1 3 4
# 71 "/usr/include/i386/types.h" 2 3 4







typedef signed char int8_t;

typedef unsigned char u_int8_t;


typedef short int16_t;

typedef unsigned short u_int16_t;


typedef int int32_t;

typedef unsigned int u_int32_t;


typedef long long int64_t;

typedef unsigned long long u_int64_t;


typedef int64_t register_t;






typedef __darwin_intptr_t intptr_t;



typedef unsigned long uintptr_t;




typedef u_int64_t user_addr_t;
typedef u_int64_t user_size_t;
typedef int64_t user_ssize_t;
typedef int64_t user_long_t;
typedef u_int64_t user_ulong_t;
typedef int64_t user_time_t;
typedef int64_t user_off_t;







typedef u_int64_t syscall_arg_t;
# 36 "/usr/include/machine/types.h" 2 3 4
# 256 "/usr/include/stdlib.h" 2 3 4


typedef __darwin_dev_t dev_t;




typedef __darwin_mode_t mode_t;



u_int32_t
  arc4random(void);
void arc4random_addrandom(unsigned char * , int );
void arc4random_buf(void * , size_t ) __attribute__((visibility("default")));
void arc4random_stir(void);
u_int32_t
  arc4random_uniform(u_int32_t ) __attribute__((visibility("default")));

int atexit_b(void (^)(void)) __attribute__((visibility("default")));
void *bsearch_b(const void *, const void *, size_t,
     size_t, int (^)(const void *, const void *)) __attribute__((visibility("default")));



char *cgetcap(char *, const char *, int);
int cgetclose(void);
int cgetent(char **, char **, const char *);
int cgetfirst(char **, char **);
int cgetmatch(const char *, const char *);
int cgetnext(char **, char **);
int cgetnum(char *, const char *, long *);
int cgetset(const char *);
int cgetstr(char *, const char *, char **);
int cgetustr(char *, const char *, char **);

int daemon(int, int) __asm("_" "daemon" "$1050") __attribute__((deprecated,visibility("default")));
char *devname(dev_t, mode_t);
char *devname_r(dev_t, mode_t, char *buf, int len);
char *getbsize(int *, long *);
int getloadavg(double [], int);
const char
 *getprogname(void);

int heapsort(void *, size_t, size_t,
     int (*)(const void *, const void *));

int heapsort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

int mergesort(void *, size_t, size_t,
     int (*)(const void *, const void *));

int mergesort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void psort(void *, size_t, size_t,
     int (*)(const void *, const void *)) __attribute__((visibility("default")));

void psort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void psort_r(void *, size_t, size_t, void *,
     int (*)(void *, const void *, const void *)) __attribute__((visibility("default")));

void qsort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void qsort_r(void *, size_t, size_t, void *,
     int (*)(void *, const void *, const void *));
int radixsort(const unsigned char **, int, const unsigned char *,
     unsigned);
void setprogname(const char *);
int sradixsort(const unsigned char **, int, const unsigned char *,
     unsigned);
void sranddev(void);
void srandomdev(void);
void *reallocf(void *, size_t);

long long
  strtoq(const char *, char **, int);
unsigned long long
  strtouq(const char *, char **, int);

extern char *suboptarg;
void *valloc(size_t);







# 69 "c.h" 2
# 1 "/usr/include/string.h" 1 3 4
# 79 "/usr/include/string.h" 3 4

void *memchr(const void *, int, size_t);
int memcmp(const void *, const void *, size_t);
void *memcpy(void *, const void *, size_t);
void *memmove(void *, const void *, size_t);
void *memset(void *, int, size_t);
char *strcat(char *, const char *);
char *strchr(const char *, int);
int strcmp(const char *, const char *);
int strcoll(const char *, const char *);
char *strcpy(char *, const char *);
size_t strcspn(const char *, const char *);
char *strerror(int) __asm("_" "strerror" );
size_t strlen(const char *);
char *strncat(char *, const char *, size_t);
int strncmp(const char *, const char *, size_t);
char *strncpy(char *, const char *, size_t);
char *strpbrk(const char *, const char *);
char *strrchr(const char *, int);
size_t strspn(const char *, const char *);
char *strstr(const char *, const char *);
char *strtok(char *, const char *);
size_t strxfrm(char *, const char *, size_t);

# 113 "/usr/include/string.h" 3 4

char *strtok_r(char *, const char *, char **);

# 125 "/usr/include/string.h" 3 4

int strerror_r(int, char *, size_t);
char *strdup(const char *);
void *memccpy(void *, const void *, int, size_t);

# 139 "/usr/include/string.h" 3 4

char *stpcpy(char *, const char *);
char *stpncpy(char *, const char *, size_t) __attribute__((visibility("default")));
char *strndup(const char *, size_t) __attribute__((visibility("default")));
size_t strnlen(const char *, size_t) __attribute__((visibility("default")));
char *strsignal(int sig);

# 158 "/usr/include/string.h" 3 4

void *memmem(const void *, size_t, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern4(void *, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern8(void *, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern16(void *, const void *, size_t) __attribute__((visibility("default")));

char *strcasestr(const char *, const char *);
char *strnstr(const char *, const char *, size_t);
size_t strlcat(char *, const char *, size_t);
size_t strlcpy(char *, const char *, size_t);
void strmode(int, char *);
char *strsep(char **, const char *);


void swab(const void * , void * , ssize_t);







# 1 "/usr/include/strings.h" 1 3 4
# 71 "/usr/include/strings.h" 3 4



int bcmp(const void *, const void *, size_t) ;
void bcopy(const void *, void *, size_t) ;
void bzero(void *, size_t) ;
char *index(const char *, int) ;
char *rindex(const char *, int) ;


int ffs(int);
int strcasecmp(const char *, const char *);
int strncasecmp(const char *, const char *, size_t);





int ffsl(long) __attribute__((visibility("default")));
int fls(int) __attribute__((visibility("default")));
int flsl(long) __attribute__((visibility("default")));


# 1 "/usr/include/string.h" 1 3 4
# 95 "/usr/include/strings.h" 2 3 4
# 181 "/usr/include/string.h" 2 3 4
# 190 "/usr/include/string.h" 3 4
# 1 "/usr/include/secure/_string.h" 1 3 4
# 58 "/usr/include/secure/_string.h" 3 4
static __inline void *
__inline_memcpy_chk (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memcpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 0));
}






static __inline void *
__inline_memmove_chk (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memmove_chk (__dest, __src, __len, __builtin_object_size (__dest, 0));
}






static __inline void *
__inline_memset_chk (void *__dest, int __val, size_t __len)
{
  return __builtin___memset_chk (__dest, __val, __len, __builtin_object_size (__dest, 0));
}






static __inline char *
__inline_strcpy_chk (char * __dest, const char * __src)
{
  return __builtin___strcpy_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_stpcpy_chk (char *__dest, const char *__src)
{
  return __builtin___stpcpy_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}






static __inline char *
__inline_stpncpy_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___stpncpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_strncpy_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___strncpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}






static __inline char *
__inline_strcat_chk (char * __dest, const char * __src)
{
  return __builtin___strcat_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_strncat_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___strncat_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}
# 191 "/usr/include/string.h" 2 3 4
# 70 "c.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stddef.h" 1 3 4
# 152 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 71 "c.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stdarg.h" 1 3 4
# 43 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 72 "c.h" 2

# 1 "./strings.h" 1
char *s1,
     *s2,
     *s3,
     *s4,
     *s5,
     *s6;
# 74 "c.h" 2


# 1 "/usr/include/stdint.h" 1 3 4
# 40 "/usr/include/stdint.h" 3 4
typedef unsigned char uint8_t;




typedef unsigned short uint16_t;




typedef unsigned int uint32_t;




typedef unsigned long long uint64_t;



typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;
# 97 "/usr/include/stdint.h" 3 4
typedef long int intmax_t;
# 106 "/usr/include/stdint.h" 3 4
typedef long unsigned int uintmax_t;
# 77 "c.h" 2

# 1 "/usr/include/sys/types.h" 1 3 4
# 84 "/usr/include/sys/types.h" 3 4
typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned int u_int;

typedef unsigned long u_long;


typedef unsigned short ushort;
typedef unsigned int uint;


typedef u_int64_t u_quad_t;
typedef int64_t quad_t;
typedef quad_t * qaddr_t;

typedef char * caddr_t;
typedef int32_t daddr_t;






typedef u_int32_t fixpt_t;


typedef __darwin_blkcnt_t blkcnt_t;




typedef __darwin_blksize_t blksize_t;




typedef __darwin_gid_t gid_t;





typedef __uint32_t in_addr_t;




typedef __uint16_t in_port_t;



typedef __darwin_ino_t ino_t;





typedef __darwin_ino64_t ino64_t;






typedef __int32_t key_t;
# 157 "/usr/include/sys/types.h" 3 4
typedef __uint16_t nlink_t;
# 176 "/usr/include/sys/types.h" 3 4
typedef int32_t segsz_t;
typedef int32_t swblk_t;
# 223 "/usr/include/sys/types.h" 3 4
typedef __darwin_clock_t clock_t;
# 240 "/usr/include/sys/types.h" 3 4
typedef __darwin_time_t time_t;




typedef __darwin_useconds_t useconds_t;




typedef __darwin_suseconds_t suseconds_t;
# 260 "/usr/include/sys/types.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 183 "/usr/include/sys/_structs.h" 3 4

typedef struct fd_set {
 __int32_t fds_bits[((((1024) % ((sizeof(__int32_t) * 8))) == 0) ? ((1024) / ((sizeof(__int32_t) * 8))) : (((1024) / ((sizeof(__int32_t) * 8))) + 1))];
} fd_set;



static __inline int
__darwin_fd_isset(int _n, const struct fd_set *_p)
{
 return (_p->fds_bits[_n/(sizeof(__int32_t) * 8)] & (1<<(_n % (sizeof(__int32_t) * 8))));
}
# 261 "/usr/include/sys/types.h" 2 3 4




typedef __int32_t fd_mask;
# 322 "/usr/include/sys/types.h" 3 4
typedef __darwin_pthread_cond_t pthread_cond_t;



typedef __darwin_pthread_condattr_t pthread_condattr_t;



typedef __darwin_pthread_mutex_t pthread_mutex_t;



typedef __darwin_pthread_mutexattr_t pthread_mutexattr_t;



typedef __darwin_pthread_once_t pthread_once_t;



typedef __darwin_pthread_rwlock_t pthread_rwlock_t;



typedef __darwin_pthread_rwlockattr_t pthread_rwlockattr_t;



typedef __darwin_pthread_t pthread_t;






typedef __darwin_pthread_key_t pthread_key_t;





typedef __darwin_fsblkcnt_t fsblkcnt_t;




typedef __darwin_fsfilcnt_t fsfilcnt_t;
# 79 "c.h" 2

# 1 "/usr/include/errno.h" 1 3 4
# 23 "/usr/include/errno.h" 3 4
# 1 "/usr/include/sys/errno.h" 1 3 4
# 74 "/usr/include/sys/errno.h" 3 4

extern int * __error(void);


# 24 "/usr/include/errno.h" 2 3 4
# 81 "c.h" 2
# 91 "c.h"
# 1 "/usr/include/locale.h" 1 3 4
# 40 "/usr/include/locale.h" 3 4
# 1 "/usr/include/_locale.h" 1 3 4
# 43 "/usr/include/_locale.h" 3 4
struct lconv {
 char *decimal_point;
 char *thousands_sep;
 char *grouping;
 char *int_curr_symbol;
 char *currency_symbol;
 char *mon_decimal_point;
 char *mon_thousands_sep;
 char *mon_grouping;
 char *positive_sign;
 char *negative_sign;
 char int_frac_digits;
 char frac_digits;
 char p_cs_precedes;
 char p_sep_by_space;
 char n_cs_precedes;
 char n_sep_by_space;
 char p_sign_posn;
 char n_sign_posn;
 char int_p_cs_precedes;
 char int_n_cs_precedes;
 char int_p_sep_by_space;
 char int_n_sep_by_space;
 char int_p_sign_posn;
 char int_n_sign_posn;
};






struct lconv *localeconv(void);

# 41 "/usr/include/locale.h" 2 3 4
# 52 "/usr/include/locale.h" 3 4

char *setlocale(int, const char *);

# 92 "c.h" 2
# 181 "c.h"
typedef char bool;
# 193 "c.h"
typedef bool *BoolPtr;
# 224 "c.h"
typedef char *Pointer;
# 233 "c.h"
typedef signed char int8;
typedef signed short int16;
typedef signed int int32;
# 245 "c.h"
typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;






typedef uint8 bits8;
typedef uint16 bits16;
typedef uint32 bits32;
# 265 "c.h"
typedef long int int64;


typedef unsigned long int uint64;
# 308 "c.h"
typedef size_t Size;
# 317 "c.h"
typedef unsigned int Index;
# 327 "c.h"
typedef signed int Offset;




typedef int16 int2;
typedef int32 int4;
typedef float float4;
typedef double float8;
# 348 "c.h"
typedef Oid regproc;
typedef regproc RegProcedure;

typedef uint32 TransactionId;

typedef uint32 LocalTransactionId;

typedef uint32 SubTransactionId;





typedef TransactionId MultiXactId;

typedef uint32 MultiXactOffset;

typedef uint32 CommandId;







typedef struct
{
 int indx[6];
} IntArray;
# 391 "c.h"
struct varlena
{
 char vl_len_[4];
 char vl_dat[1];
};
# 404 "c.h"
typedef struct varlena bytea;
typedef struct varlena text;
typedef struct varlena BpChar;
typedef struct varlena VarChar;
# 419 "c.h"
typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
 int dim1;
 int lbound1;
 int2 values[1];
} int2vector;

typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
 int dim1;
 int lbound1;
 Oid values[1];
} oidvector;





typedef struct nameData
{
 char data[64];
} NameData;
typedef NameData *Name;
# 829 "c.h"
extern int fdatasync(int fildes);
# 860 "c.h"
# 1 "port.h" 1
# 16 "port.h"
# 1 "/usr/include/ctype.h" 1 3 4
# 69 "/usr/include/ctype.h" 3 4
# 1 "/usr/include/runetype.h" 1 3 4
# 70 "/usr/include/runetype.h" 3 4
typedef __darwin_wint_t wint_t;
# 81 "/usr/include/runetype.h" 3 4
typedef struct {
 __darwin_rune_t __min;
 __darwin_rune_t __max;
 __darwin_rune_t __map;
 __uint32_t *__types;
} _RuneEntry;

typedef struct {
 int __nranges;
 _RuneEntry *__ranges;
} _RuneRange;

typedef struct {
 char __name[14];
 __uint32_t __mask;
} _RuneCharClass;

typedef struct {
 char __magic[8];
 char __encoding[32];

 __darwin_rune_t (*__sgetrune)(const char *, __darwin_size_t, char const **);
 int (*__sputrune)(__darwin_rune_t, char *, __darwin_size_t, char **);
 __darwin_rune_t __invalid_rune;

 __uint32_t __runetype[(1 <<8 )];
 __darwin_rune_t __maplower[(1 <<8 )];
 __darwin_rune_t __mapupper[(1 <<8 )];






 _RuneRange __runetype_ext;
 _RuneRange __maplower_ext;
 _RuneRange __mapupper_ext;

 void *__variable;
 int __variable_len;




 int __ncharclasses;
 _RuneCharClass *__charclasses;
} _RuneLocale;




extern _RuneLocale _DefaultRuneLocale;
extern _RuneLocale *_CurrentRuneLocale;

# 70 "/usr/include/ctype.h" 2 3 4
# 145 "/usr/include/ctype.h" 3 4

unsigned long ___runetype(__darwin_ct_rune_t);
__darwin_ct_rune_t ___tolower(__darwin_ct_rune_t);
__darwin_ct_rune_t ___toupper(__darwin_ct_rune_t);


static __inline int
isascii(int _c)
{
 return ((_c & ~0x7F) == 0);
}
# 164 "/usr/include/ctype.h" 3 4

int __maskrune(__darwin_ct_rune_t, unsigned long);



static __inline int
__istype(__darwin_ct_rune_t _c, unsigned long _f)
{



 return (isascii(_c) ? !!(_DefaultRuneLocale.__runetype[_c] & _f)
  : !!__maskrune(_c, _f));

}

static __inline __darwin_ct_rune_t
__isctype(__darwin_ct_rune_t _c, unsigned long _f)
{



 return (_c < 0 || _c >= (1 <<8 )) ? 0 :
  !!(_DefaultRuneLocale.__runetype[_c] & _f);

}
# 204 "/usr/include/ctype.h" 3 4

__darwin_ct_rune_t __toupper(__darwin_ct_rune_t);
__darwin_ct_rune_t __tolower(__darwin_ct_rune_t);



static __inline int
__wcwidth(__darwin_ct_rune_t _c)
{
 unsigned int _x;

 if (_c == 0)
  return (0);
 _x = (unsigned int)__maskrune(_c, 0xe0000000L|0x00040000L);
 if ((_x & 0xe0000000L) != 0)
  return ((_x & 0xe0000000L) >> 30);
 return ((_x & 0x00040000L) != 0 ? 1 : -1);
}






static __inline int
isalnum(int _c)
{
 return (__istype(_c, 0x00000100L|0x00000400L));
}

static __inline int
isalpha(int _c)
{
 return (__istype(_c, 0x00000100L));
}

static __inline int
isblank(int _c)
{
 return (__istype(_c, 0x00020000L));
}

static __inline int
iscntrl(int _c)
{
 return (__istype(_c, 0x00000200L));
}


static __inline int
isdigit(int _c)
{
 return (__isctype(_c, 0x00000400L));
}

static __inline int
isgraph(int _c)
{
 return (__istype(_c, 0x00000800L));
}

static __inline int
islower(int _c)
{
 return (__istype(_c, 0x00001000L));
}

static __inline int
isprint(int _c)
{
 return (__istype(_c, 0x00040000L));
}

static __inline int
ispunct(int _c)
{
 return (__istype(_c, 0x00002000L));
}

static __inline int
isspace(int _c)
{
 return (__istype(_c, 0x00004000L));
}

static __inline int
isupper(int _c)
{
 return (__istype(_c, 0x00008000L));
}


static __inline int
isxdigit(int _c)
{
 return (__isctype(_c, 0x00010000L));
}

static __inline int
toascii(int _c)
{
 return (_c & 0x7F);
}

static __inline int
tolower(int _c)
{
        return (__tolower(_c));
}

static __inline int
toupper(int _c)
{
        return (__toupper(_c));
}


static __inline int
digittoint(int _c)
{
 return (__maskrune(_c, 0x0F));
}

static __inline int
ishexnumber(int _c)
{
 return (__istype(_c, 0x00010000L));
}

static __inline int
isideogram(int _c)
{
 return (__istype(_c, 0x00080000L));
}

static __inline int
isnumber(int _c)
{
 return (__istype(_c, 0x00000400L));
}

static __inline int
isphonogram(int _c)
{
 return (__istype(_c, 0x00200000L));
}

static __inline int
isrune(int _c)
{
 return (__istype(_c, 0xFFFFFFF0L));
}

static __inline int
isspecial(int _c)
{
 return (__istype(_c, 0x00100000L));
}
# 17 "port.h" 2
# 1 "./netdb.h" 1
# 18 "port.h" 2
# 1 "./pwd.h" 1
# 19 "port.h" 2



typedef int pgsocket;
# 32 "port.h"
extern bool pg_set_noblock(pgsocket sock);
extern bool pg_set_block(pgsocket sock);



extern bool has_drive_prefix(const char *filename);
extern char *first_dir_separator(const char *filename);
extern char *last_dir_separator(const char *filename);
extern char *first_path_var_separator(const char *pathlist);
extern void join_path_components(char *ret_path,
      const char *head, const char *tail);
extern void canonicalize_path(char *path);
extern void make_native_path(char *path);
extern bool path_contains_parent_reference(const char *path);
extern bool path_is_relative_and_below_cwd(const char *path);
extern bool path_is_prefix_of_path(const char *path1, const char *path2);
extern const char *get_progname(const char *argv0);
extern void get_share_path(const char *my_exec_path, char *ret_path);
extern void get_etc_path(const char *my_exec_path, char *ret_path);
extern void get_include_path(const char *my_exec_path, char *ret_path);
extern void get_pkginclude_path(const char *my_exec_path, char *ret_path);
extern void get_includeserver_path(const char *my_exec_path, char *ret_path);
extern void get_lib_path(const char *my_exec_path, char *ret_path);
extern void get_pkglib_path(const char *my_exec_path, char *ret_path);
extern void get_locale_path(const char *my_exec_path, char *ret_path);
extern void get_doc_path(const char *my_exec_path, char *ret_path);
extern void get_html_path(const char *my_exec_path, char *ret_path);
extern void get_man_path(const char *my_exec_path, char *ret_path);
extern bool get_home_path(char *ret_path);
extern void get_parent_directory(char *path);


extern char **pgfnames(const char *path);
extern void pgfnames_cleanup(char **filenames);
# 92 "port.h"
extern void set_pglocale_pgservice(const char *argv0, const char *app);


extern int find_my_exec(const char *argv0, char *retpath);
extern int find_other_exec(const char *argv0, const char *target,
    const char *versionstr, char *retpath);
# 149 "port.h"
extern void pg_usleep(long microsec);


extern int pg_strcasecmp(const char *s1, const char *s2);
extern int pg_strncasecmp(const char *s1, const char *s2, size_t n);
extern unsigned char pg_toupper(unsigned char ch);
extern unsigned char pg_tolower(unsigned char ch);
extern unsigned char pg_ascii_toupper(unsigned char ch);
extern unsigned char pg_ascii_tolower(unsigned char ch);
# 247 "port.h"
extern char *simple_prompt(const char *prompt, int maxlen, bool echo);







extern int pclose_check(FILE *stream);
# 300 "port.h"
extern bool rmtree(const char *path, bool rmtopdir);
# 372 "port.h"
extern double pg_erand48(unsigned short xseed[3]);
extern long pg_lrand48(void);
extern void pg_srand48(long seed);
# 428 "port.h"
extern char *pqStrerror(int errnum, char *strerrbuf, size_t buflen);


extern int pqGetpwuid(uid_t uid, struct passwd * resultbuf, char *buffer,
     size_t buflen, struct passwd ** result);


extern int pqGethostbyname(const char *name,
    struct hostent * resultbuf,
    char *buffer, size_t buflen,
    struct hostent ** result,
    int *herrno);

extern void pg_qsort(void *base, size_t nel, size_t elsize,
   int (*cmp) (const void *, const void *));



typedef int (*qsort_arg_comparator) (const void *a, const void *b, void *arg);

extern void qsort_arg(void *base, size_t nel, size_t elsize,
    qsort_arg_comparator cmp, void *arg);


extern int pg_get_encoding_from_locale(const char *ctype, bool write_message);


extern char *inet_net_ntop(int af, const void *src, int bits,
     char *dst, size_t size);


extern int pg_check_dir(const char *dir);


extern int pg_mkdir_p(char *path, int omode);
# 861 "c.h" 2
# 26 "postgres_fe.h" 2
# 21 "pg_ctl.c" 2
# 1 "libpq-fe.h" 1
# 47 "libpq-fe.h"
typedef enum
{
 CONNECTION_OK,
 CONNECTION_BAD,






 CONNECTION_STARTED,
 CONNECTION_MADE,
 CONNECTION_AWAITING_RESPONSE,

 CONNECTION_AUTH_OK,

 CONNECTION_SETENV,
 CONNECTION_SSL_STARTUP,
 CONNECTION_NEEDED
} ConnStatusType;

typedef enum
{
 PGRES_POLLING_FAILED = 0,
 PGRES_POLLING_READING,
 PGRES_POLLING_WRITING,
 PGRES_POLLING_OK,
 PGRES_POLLING_ACTIVE

} PostgresPollingStatusType;

typedef enum
{
 PGRES_EMPTY_QUERY = 0,
 PGRES_COMMAND_OK,


 PGRES_TUPLES_OK,


 PGRES_COPY_OUT,
 PGRES_COPY_IN,
 PGRES_BAD_RESPONSE,

 PGRES_NONFATAL_ERROR,
 PGRES_FATAL_ERROR,
 PGRES_COPY_BOTH,
 PGRES_SINGLE_TUPLE
} ExecStatusType;

typedef enum
{
 PQTRANS_IDLE,
 PQTRANS_ACTIVE,
 PQTRANS_INTRANS,
 PQTRANS_INERROR,
 PQTRANS_UNKNOWN
} PGTransactionStatusType;

typedef enum
{
 PQERRORS_TERSE,
 PQERRORS_DEFAULT,
 PQERRORS_VERBOSE
} PGVerbosity;

typedef enum
{
 PQPING_OK,
 PQPING_REJECT,
 PQPING_NO_RESPONSE,
 PQPING_NO_ATTEMPT
} PGPing;




typedef struct pg_conn PGconn;






typedef struct pg_result PGresult;





typedef struct pg_cancel PGcancel;







typedef struct pgNotify
{
 char *relname;
 int be_pid;
 char *extra;

 struct pgNotify *next;
} PGnotify;


typedef void (*PQnoticeReceiver) (void *arg, const PGresult *res);
typedef void (*PQnoticeProcessor) (void *arg, const char *message);


typedef char pqbool;

typedef struct _PQprintOpt
{
 pqbool header;
 pqbool align;
 pqbool standard;
 pqbool html3;
 pqbool expanded;
 pqbool pager;
 char *fieldSep;
 char *tableOpt;
 char *caption;
 char **fieldName;

} PQprintOpt;
# 185 "libpq-fe.h"
typedef struct _PQconninfoOption
{
 char *keyword;
 char *envvar;
 char *compiled;
 char *val;
 char *label;
 char *dispchar;




 int dispsize;
} PQconninfoOption;





typedef struct
{
 int len;
 int isint;
 union
 {
  int *ptr;
  int integer;
 } u;
} PQArgBlock;





typedef struct pgresAttDesc
{
 char *name;
 Oid tableid;
 int columnid;
 int format;
 Oid typid;
 int typlen;
 int atttypmod;
} PGresAttDesc;
# 239 "libpq-fe.h"
extern PGconn *PQconnectStart(const char *conninfo);
extern PGconn *PQconnectStartParams(const char *const * keywords,
      const char *const * values, int expand_dbname);
extern PostgresPollingStatusType PQconnectPoll(PGconn *conn);


extern PGconn *PQconnectdb(const char *conninfo);
extern PGconn *PQconnectdbParams(const char *const * keywords,
      const char *const * values, int expand_dbname);
extern PGconn *PQsetdbLogin(const char *pghost, const char *pgport,
    const char *pgoptions, const char *pgtty,
    const char *dbName,
    const char *login, const char *pwd);





extern void PQfinish(PGconn *conn);


extern PQconninfoOption *PQconndefaults(void);


extern PQconninfoOption *PQconninfoParse(const char *conninfo, char **errmsg);


extern void PQconninfoFree(PQconninfoOption *connOptions);






extern int PQresetStart(PGconn *conn);
extern PostgresPollingStatusType PQresetPoll(PGconn *conn);


extern void PQreset(PGconn *conn);


extern PGcancel *PQgetCancel(PGconn *conn);


extern void PQfreeCancel(PGcancel *cancel);


extern int PQcancel(PGcancel *cancel, char *errbuf, int errbufsize);


extern int PQrequestCancel(PGconn *conn);


extern char *PQdb(const PGconn *conn);
extern char *PQuser(const PGconn *conn);
extern char *PQpass(const PGconn *conn);
extern char *PQhost(const PGconn *conn);
extern char *PQport(const PGconn *conn);
extern char *PQtty(const PGconn *conn);
extern char *PQoptions(const PGconn *conn);
extern ConnStatusType PQstatus(const PGconn *conn);
extern PGTransactionStatusType PQtransactionStatus(const PGconn *conn);
extern const char *PQparameterStatus(const PGconn *conn,
      const char *paramName);
extern int PQprotocolVersion(const PGconn *conn);
extern int PQserverVersion(const PGconn *conn);
extern char *PQerrorMessage(const PGconn *conn);
extern int PQsocket(const PGconn *conn);
extern int PQbackendPID(const PGconn *conn);
extern int PQconnectionNeedsPassword(const PGconn *conn);
extern int PQconnectionUsedPassword(const PGconn *conn);
extern int PQclientEncoding(const PGconn *conn);
extern int PQsetClientEncoding(PGconn *conn, const char *encoding);



extern void *PQgetssl(PGconn *conn);


extern void PQinitSSL(int do_init);


extern void PQinitOpenSSL(int do_ssl, int do_crypto);


extern PGVerbosity PQsetErrorVerbosity(PGconn *conn, PGVerbosity verbosity);


extern void PQtrace(PGconn *conn, FILE *debug_port);
extern void PQuntrace(PGconn *conn);


extern PQnoticeReceiver PQsetNoticeReceiver(PGconn *conn,
     PQnoticeReceiver proc,
     void *arg);
extern PQnoticeProcessor PQsetNoticeProcessor(PGconn *conn,
      PQnoticeProcessor proc,
      void *arg);
# 345 "libpq-fe.h"
typedef void (*pgthreadlock_t) (int acquire);

extern pgthreadlock_t PQregisterThreadLock(pgthreadlock_t newhandler);




extern PGresult *PQexec(PGconn *conn, const char *query);
extern PGresult *PQexecParams(PGconn *conn,
    const char *command,
    int nParams,
    const Oid *paramTypes,
    const char *const * paramValues,
    const int *paramLengths,
    const int *paramFormats,
    int resultFormat);
extern PGresult *PQprepare(PGconn *conn, const char *stmtName,
    const char *query, int nParams,
    const Oid *paramTypes);
extern PGresult *PQexecPrepared(PGconn *conn,
      const char *stmtName,
      int nParams,
      const char *const * paramValues,
      const int *paramLengths,
      const int *paramFormats,
      int resultFormat);


extern int PQsendQuery(PGconn *conn, const char *query);
extern int PQsendQueryParams(PGconn *conn,
      const char *command,
      int nParams,
      const Oid *paramTypes,
      const char *const * paramValues,
      const int *paramLengths,
      const int *paramFormats,
      int resultFormat);
extern int PQsendPrepare(PGconn *conn, const char *stmtName,
     const char *query, int nParams,
     const Oid *paramTypes);
extern int PQsendQueryPrepared(PGconn *conn,
     const char *stmtName,
     int nParams,
     const char *const * paramValues,
     const int *paramLengths,
     const int *paramFormats,
     int resultFormat);
extern int PQsetSingleRowMode(PGconn *conn);
extern PGresult *PQgetResult(PGconn *conn);


extern int PQisBusy(PGconn *conn);
extern int PQconsumeInput(PGconn *conn);


extern PGnotify *PQnotifies(PGconn *conn);


extern int PQputCopyData(PGconn *conn, const char *buffer, int nbytes);
extern int PQputCopyEnd(PGconn *conn, const char *errormsg);
extern int PQgetCopyData(PGconn *conn, char **buffer, int async);


extern int PQgetline(PGconn *conn, char *string, int length);
extern int PQputline(PGconn *conn, const char *string);
extern int PQgetlineAsync(PGconn *conn, char *buffer, int bufsize);
extern int PQputnbytes(PGconn *conn, const char *buffer, int nbytes);
extern int PQendcopy(PGconn *conn);


extern int PQsetnonblocking(PGconn *conn, int arg);
extern int PQisnonblocking(const PGconn *conn);
extern int PQisthreadsafe(void);
extern PGPing PQping(const char *conninfo);
extern PGPing PQpingParams(const char *const * keywords,
    const char *const * values, int expand_dbname);


extern int PQflush(PGconn *conn);





extern PGresult *PQfn(PGconn *conn,
  int fnid,
  int *result_buf,
  int *result_len,
  int result_is_int,
  const PQArgBlock *args,
  int nargs);


extern ExecStatusType PQresultStatus(const PGresult *res);
extern char *PQresStatus(ExecStatusType status);
extern char *PQresultErrorMessage(const PGresult *res);
extern char *PQresultErrorField(const PGresult *res, int fieldcode);
extern int PQntuples(const PGresult *res);
extern int PQnfields(const PGresult *res);
extern int PQbinaryTuples(const PGresult *res);
extern char *PQfname(const PGresult *res, int field_num);
extern int PQfnumber(const PGresult *res, const char *field_name);
extern Oid PQftable(const PGresult *res, int field_num);
extern int PQftablecol(const PGresult *res, int field_num);
extern int PQfformat(const PGresult *res, int field_num);
extern Oid PQftype(const PGresult *res, int field_num);
extern int PQfsize(const PGresult *res, int field_num);
extern int PQfmod(const PGresult *res, int field_num);
extern char *PQcmdStatus(PGresult *res);
extern char *PQoidStatus(const PGresult *res);
extern Oid PQoidValue(const PGresult *res);
extern char *PQcmdTuples(PGresult *res);
extern char *PQgetvalue(const PGresult *res, int tup_num, int field_num);
extern int PQgetlength(const PGresult *res, int tup_num, int field_num);
extern int PQgetisnull(const PGresult *res, int tup_num, int field_num);
extern int PQnparams(const PGresult *res);
extern Oid PQparamtype(const PGresult *res, int param_num);


extern PGresult *PQdescribePrepared(PGconn *conn, const char *stmt);
extern PGresult *PQdescribePortal(PGconn *conn, const char *portal);
extern int PQsendDescribePrepared(PGconn *conn, const char *stmt);
extern int PQsendDescribePortal(PGconn *conn, const char *portal);


extern void PQclear(PGresult *res);


extern void PQfreemem(void *ptr);
# 483 "libpq-fe.h"
extern PGresult *PQmakeEmptyPGresult(PGconn *conn, ExecStatusType status);
extern PGresult *PQcopyResult(const PGresult *src, int flags);
extern int PQsetResultAttrs(PGresult *res, int numAttributes, PGresAttDesc *attDescs);
extern void *PQresultAlloc(PGresult *res, size_t nBytes);
extern int PQsetvalue(PGresult *res, int tup_num, int field_num, char *value, int len);


extern size_t PQescapeStringConn(PGconn *conn,
       char *to, const char *from, size_t length,
       int *error);
extern char *PQescapeLiteral(PGconn *conn, const char *str, size_t len);
extern char *PQescapeIdentifier(PGconn *conn, const char *str, size_t len);
extern unsigned char *PQescapeByteaConn(PGconn *conn,
      const unsigned char *from, size_t from_length,
      size_t *to_length);
extern unsigned char *PQunescapeBytea(const unsigned char *strtext,
    size_t *retbuflen);


extern size_t PQescapeString(char *to, const char *from, size_t length);
extern unsigned char *PQescapeBytea(const unsigned char *from, size_t from_length,
     size_t *to_length);





extern void
PQprint(FILE *fout,
  const PGresult *res,
  const PQprintOpt *ps);




extern void
PQdisplayTuples(const PGresult *res,
    FILE *fp,
    int fillAlign,
    const char *fieldSep,
    int printHeader,
    int quiet);

extern void
PQprintTuples(const PGresult *res,
     FILE *fout,
     int printAttName,
     int terseOutput,
     int width);





extern int lo_open(PGconn *conn, Oid lobjId, int mode);
extern int lo_close(PGconn *conn, int fd);
extern int lo_read(PGconn *conn, int fd, char *buf, size_t len);
extern int lo_write(PGconn *conn, int fd, const char *buf, size_t len);
extern int lo_lseek(PGconn *conn, int fd, int offset, int whence);
extern Oid lo_creat(PGconn *conn, int mode);
extern Oid lo_create(PGconn *conn, Oid lobjId);
extern int lo_tell(PGconn *conn, int fd);
extern int lo_truncate(PGconn *conn, int fd, size_t len);
extern int lo_unlink(PGconn *conn, Oid lobjId);
extern Oid lo_import(PGconn *conn, const char *filename);
extern Oid lo_import_with_oid(PGconn *conn, const char *filename, Oid lobjId);
extern int lo_export(PGconn *conn, Oid lobjId, const char *filename);




extern int PQlibVersion(void);


extern int PQmblen(const char *s, int encoding);


extern int PQdsplen(const char *s, int encoding);


extern int PQenv2encoding(void);



extern char *PQencryptPassword(const char *passwd, const char *user);



extern int pg_char_to_encoding(const char *name);
extern const char *pg_encoding_to_char(int encoding);
extern int pg_valid_server_encoding_id(int encoding);
# 22 "pg_ctl.c" 2

# 1 "/usr/include/fcntl.h" 1 3 4
# 23 "/usr/include/fcntl.h" 3 4
# 1 "/usr/include/sys/fcntl.h" 1 3 4
# 339 "/usr/include/sys/fcntl.h" 3 4
struct flock {
 off_t l_start;
 off_t l_len;
 pid_t l_pid;
 short l_type;
 short l_whence;
};
# 355 "/usr/include/sys/fcntl.h" 3 4
struct radvisory {
       off_t ra_offset;
       int ra_count;
};
# 367 "/usr/include/sys/fcntl.h" 3 4
typedef struct fsignatures {
 off_t fs_file_start;
 void *fs_blob_start;
 size_t fs_blob_size;
} fsignatures_t;
# 381 "/usr/include/sys/fcntl.h" 3 4
typedef struct fstore {
 unsigned int fst_flags;
 int fst_posmode;
 off_t fst_offset;
 off_t fst_length;
 off_t fst_bytesalloc;
} fstore_t;



typedef struct fbootstraptransfer {
  off_t fbt_offset;
  size_t fbt_length;
  void *fbt_buffer;
} fbootstraptransfer_t;
# 419 "/usr/include/sys/fcntl.h" 3 4
#pragma pack(4)

struct log2phys {
 unsigned int l2p_flags;
 off_t l2p_contigbytes;


 off_t l2p_devoffset;


};

#pragma pack()
# 442 "/usr/include/sys/fcntl.h" 3 4
struct _filesec;
typedef struct _filesec *filesec_t;


typedef enum {
 FILESEC_OWNER = 1,
 FILESEC_GROUP = 2,
 FILESEC_UUID = 3,
 FILESEC_MODE = 4,
 FILESEC_ACL = 5,
 FILESEC_GRPUUID = 6,


 FILESEC_ACL_RAW = 100,
 FILESEC_ACL_ALLOCSIZE = 101
} filesec_property_t;






int open(const char *, int, ...) __asm("_" "open" );
int creat(const char *, mode_t) __asm("_" "creat" );
int fcntl(int, int, ...) __asm("_" "fcntl" );


int openx_np(const char *, int, filesec_t);
int flock(int, int);
filesec_t filesec_init(void);
filesec_t filesec_dup(filesec_t);
void filesec_free(filesec_t);
int filesec_get_property(filesec_t, filesec_property_t, void *);
int filesec_query_property(filesec_t, filesec_property_t, int *);
int filesec_set_property(filesec_t, filesec_property_t, const void *);
int filesec_unset_property(filesec_t, filesec_property_t) __attribute__((visibility("default")));




# 23 "/usr/include/fcntl.h" 2 3 4
# 24 "pg_ctl.c" 2

# 1 "/usr/include/signal.h" 1 3 4
# 71 "/usr/include/signal.h" 3 4
extern const char *const sys_signame[32];
extern const char *const sys_siglist[32];



int raise(int);




void (*bsd_signal(int, void (*)(int)))(int);
int kill(pid_t, int) __asm("_" "kill" );
int killpg(pid_t, int) __asm("_" "killpg" );
int pthread_kill(pthread_t, int);
int pthread_sigmask(int, const sigset_t *, sigset_t *) __asm("_" "pthread_sigmask" );
int sigaction(int, const struct sigaction * ,
     struct sigaction * );
int sigaddset(sigset_t *, int);
int sigaltstack(const stack_t * , stack_t * ) __asm("_" "sigaltstack" );
int sigdelset(sigset_t *, int);
int sigemptyset(sigset_t *);
int sigfillset(sigset_t *);
int sighold(int);
int sigignore(int);
int siginterrupt(int, int);
int sigismember(const sigset_t *, int);
int sigpause(int) __asm("_" "sigpause" );
int sigpending(sigset_t *);
int sigprocmask(int, const sigset_t * , sigset_t * );
int sigrelse(int);
void (*sigset(int, void (*)(int)))(int);
int sigsuspend(const sigset_t *) __asm("_" "sigsuspend" );
int sigwait(const sigset_t * , int * ) __asm("_" "sigwait" );

void psignal(unsigned int, const char *);
int sigblock(int);
int sigsetmask(int);
int sigvec(int, struct sigvec *, struct sigvec *);






static __inline int
__sigbits(int __signo)
{
    return __signo > 32 ? 0 : (1 << (__signo - 1));
}
# 26 "pg_ctl.c" 2
# 1 "./time.h" 1
# 27 "pg_ctl.c" 2

# 1 "/usr/include/sys/stat.h" 1 3 4
# 79 "/usr/include/sys/stat.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 88 "/usr/include/sys/_structs.h" 3 4
struct timespec
{
 __darwin_time_t tv_sec;
 long tv_nsec;
};
# 80 "/usr/include/sys/stat.h" 2 3 4
# 153 "/usr/include/sys/stat.h" 3 4
struct ostat {
 __uint16_t st_dev;
 ino_t st_ino;
 mode_t st_mode;
 nlink_t st_nlink;
 __uint16_t st_uid;
 __uint16_t st_gid;
 __uint16_t st_rdev;
 __int32_t st_size;
 struct timespec st_atimespec;
 struct timespec st_mtimespec;
 struct timespec st_ctimespec;
 __int32_t st_blksize;
 __int32_t st_blocks;
 __uint32_t st_flags;
 __uint32_t st_gen;
};
# 225 "/usr/include/sys/stat.h" 3 4
struct stat { dev_t st_dev; mode_t st_mode; nlink_t st_nlink; __darwin_ino64_t st_ino; uid_t st_uid; gid_t st_gid; dev_t st_rdev; struct timespec st_atimespec; struct timespec st_mtimespec; struct timespec st_ctimespec; struct timespec st_birthtimespec; off_t st_size; blkcnt_t st_blocks; blksize_t st_blksize; __uint32_t st_flags; __uint32_t st_gen; __int32_t st_lspare; __int64_t st_qspare[2]; };
# 264 "/usr/include/sys/stat.h" 3 4
struct stat64 { dev_t st_dev; mode_t st_mode; nlink_t st_nlink; __darwin_ino64_t st_ino; uid_t st_uid; gid_t st_gid; dev_t st_rdev; struct timespec st_atimespec; struct timespec st_mtimespec; struct timespec st_ctimespec; struct timespec st_birthtimespec; off_t st_size; blkcnt_t st_blocks; blksize_t st_blksize; __uint32_t st_flags; __uint32_t st_gen; __int32_t st_lspare; __int64_t st_qspare[2]; };
# 428 "/usr/include/sys/stat.h" 3 4


int chmod(const char *, mode_t) __asm("_" "chmod" );
int fchmod(int, mode_t) __asm("_" "fchmod" );
int fstat(int, struct stat *) __asm("_" "fstat" "$INODE64");
int lstat(const char *, struct stat *) __asm("_" "lstat" "$INODE64");
int mkdir(const char *, mode_t);
int mkfifo(const char *, mode_t);
int stat(const char *, struct stat *) __asm("_" "stat" "$INODE64");
int mknod(const char *, mode_t, dev_t);
mode_t umask(mode_t);







int chflags(const char *, __uint32_t);
int chmodx_np(const char *, filesec_t);
int fchflags(int, __uint32_t);
int fchmodx_np(int, filesec_t);
int fstatx_np(int, struct stat *, filesec_t) __asm("_" "fstatx_np" "$INODE64");
int lchflags(const char *, __uint32_t) __attribute__((visibility("default")));
int lchmod(const char *, mode_t) __attribute__((visibility("default")));
int lstatx_np(const char *, struct stat *, filesec_t) __asm("_" "lstatx_np" "$INODE64");
int mkdirx_np(const char *, filesec_t);
int mkfifox_np(const char *, filesec_t);
int statx_np(const char *, struct stat *, filesec_t) __asm("_" "statx_np" "$INODE64");
int umaskx_np(filesec_t) __attribute__((deprecated,visibility("default")));



int fstatx64_np(int, struct stat64 *, filesec_t) __attribute__((deprecated,visibility("default")));
int lstatx64_np(const char *, struct stat64 *, filesec_t) __attribute__((deprecated,visibility("default")));
int statx64_np(const char *, struct stat64 *, filesec_t) __attribute__((deprecated,visibility("default")));
int fstat64(int, struct stat64 *) __attribute__((deprecated,visibility("default")));
int lstat64(const char *, struct stat64 *) __attribute__((deprecated,visibility("default")));
int stat64(const char *, struct stat64 *) __attribute__((deprecated,visibility("default")));




# 29 "pg_ctl.c" 2
# 1 "./unistd.h" 1
# 30 "pg_ctl.c" 2


# 1 "/usr/include/sys/time.h" 1 3 4
# 78 "/usr/include/sys/time.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 79 "/usr/include/sys/time.h" 2 3 4
# 94 "/usr/include/sys/time.h" 3 4
struct itimerval {
 struct timeval it_interval;
 struct timeval it_value;
};
# 144 "/usr/include/sys/time.h" 3 4
struct timezone {
 int tz_minuteswest;
 int tz_dsttime;
};
# 187 "/usr/include/sys/time.h" 3 4
struct clockinfo {
 int hz;
 int tick;
 int tickadj;
 int stathz;
 int profhz;
};




# 1 "./time.h" 1 3 4
# 199 "/usr/include/sys/time.h" 2 3 4





int adjtime(const struct timeval *, struct timeval *);
int futimes(int, const struct timeval *);
int lutimes(const char *, const struct timeval *) __attribute__((visibility("default")));
int settimeofday(const struct timeval *, const struct timezone *);


int getitimer(int, struct itimerval *);
int gettimeofday(struct timeval * , void * );

# 1 "/usr/include/sys/_select.h" 1 3 4
# 39 "/usr/include/sys/_select.h" 3 4
int select(int, fd_set * , fd_set * ,
  fd_set * , struct timeval * )




  __asm("_" "select" "$1050")




  ;
# 214 "/usr/include/sys/time.h" 2 3 4

int setitimer(int, const struct itimerval * ,
  struct itimerval * );
int utimes(const char *, const struct timeval *);


# 33 "pg_ctl.c" 2



# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqsignal.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqsignal.h"
extern sigset_t UnBlockSig,
   BlockSig,
   StartupBlockSig;
# 45 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqsignal.h"
typedef void (*pqsigfunc) (int);

extern void pqinitmask(void);

extern pqsigfunc pqsignal(int signo, pqsigfunc func);
# 37 "pg_ctl.c" 2
# 1 "getopt_long.h" 1
# 13 "getopt_long.h"
# 1 "/usr/include/getopt.h" 1 3 4
# 44 "/usr/include/getopt.h" 3 4
# 1 "./unistd.h" 1 3 4
# 45 "/usr/include/getopt.h" 2 3 4
# 54 "/usr/include/getopt.h" 3 4
struct option {

 const char *name;




 int has_arg;

 int *flag;

 int val;
};


int getopt_long(int, char * const *, const char *,
 const struct option *, int *);
int getopt_long_only(int, char * const *, const char *,
 const struct option *, int *);


int getopt(int, char * const [], const char *) __asm("_" "getopt" );

extern char *optarg;
extern int optind, opterr, optopt;



extern int optreset;


# 14 "getopt_long.h" 2



extern int opterr;
extern int optind;
extern int optopt;
extern char *optarg;
# 38 "pg_ctl.c" 2
# 1 "miscadmin.h" 1
# 26 "miscadmin.h"
# 1 "pgtime.h" 1
# 23 "pgtime.h"
typedef int64 pg_time_t;

struct pg_tm
{
 int tm_sec;
 int tm_min;
 int tm_hour;
 int tm_mday;
 int tm_mon;
 int tm_year;
 int tm_wday;
 int tm_yday;
 int tm_isdst;
 long int tm_gmtoff;
 const char *tm_zone;
};

typedef struct pg_tz pg_tz;
typedef struct pg_tzenum pg_tzenum;






extern struct pg_tm *pg_localtime(const pg_time_t *timep, const pg_tz *tz);
extern struct pg_tm *pg_gmtime(const pg_time_t *timep);
extern int pg_next_dst_boundary(const pg_time_t *timep,
      long int *before_gmtoff,
      int *before_isdst,
      pg_time_t *boundary,
      long int *after_gmtoff,
      int *after_isdst,
      const pg_tz *tz);
extern size_t pg_strftime(char *s, size_t max, const char *format,
   const struct pg_tm * tm);

extern bool pg_get_timezone_offset(const pg_tz *tz, long int *gmtoff);
extern const char *pg_get_timezone_name(pg_tz *tz);
extern bool pg_tz_acceptable(pg_tz *tz);



extern pg_tz *session_timezone;
extern pg_tz *log_timezone;

extern void pg_timezone_initialize(void);
extern pg_tz *pg_tzset(const char *tzname);

extern pg_tzenum *pg_tzenumerate_start(void);
extern pg_tz *pg_tzenumerate_next(pg_tzenum *dir);
extern void pg_tzenumerate_end(pg_tzenum *dir);
# 27 "miscadmin.h" 2
# 74 "miscadmin.h"
extern volatile bool InterruptPending;
extern volatile bool QueryCancelPending;
extern volatile bool ProcDiePending;

extern volatile bool ClientConnectionLost;


extern volatile bool ImmediateInterruptOK;
extern volatile uint32 InterruptHoldoffCount;
extern volatile uint32 CritSectionCount;


extern void ProcessInterrupts(void);
# 131 "miscadmin.h"
extern pid_t PostmasterPid;
extern bool IsPostmasterEnvironment;
extern bool IsUnderPostmaster;
extern bool IsBinaryUpgrade;

extern bool ExitOnAnyError;

extern char *DataDir;

extern int NBuffers;
extern int MaxBackends;
extern int MaxConnections;

extern int MyProcPid;
extern pg_time_t MyStartTime;
extern struct Port *MyProcPort;
extern long MyCancelKey;
extern int MyPMChildSlot;

extern char OutputFileName[];
extern char my_exec_path[];
extern char pkglib_path[];
# 163 "miscadmin.h"
extern Oid MyDatabaseId;

extern Oid MyDatabaseTableSpace;
# 201 "miscadmin.h"
extern int DateStyle;
extern int DateOrder;
# 216 "miscadmin.h"
extern int IntervalStyle;







extern bool HasCTZSet;
extern int CTimeZone;



extern bool enableFsync;
extern bool allowSystemTableMods;
extern int work_mem;
extern int maintenance_work_mem;

extern int VacuumCostPageHit;
extern int VacuumCostPageMiss;
extern int VacuumCostPageDirty;
extern int VacuumCostLimit;
extern int VacuumCostDelay;

extern int VacuumPageHit;
extern int VacuumPageMiss;
extern int VacuumPageDirty;

extern int VacuumCostBalance;
extern bool VacuumCostActive;
# 257 "miscadmin.h"
typedef char *pg_stack_base_t;


extern pg_stack_base_t set_stack_base(void);
extern void restore_stack_base(pg_stack_base_t base);
extern void check_stack_depth(void);


extern void PreventCommandIfReadOnly(const char *cmdname);
extern void PreventCommandDuringRecovery(const char *cmdname);


extern int trace_recovery_messages;
extern int trace_recovery(int trace_level);
# 281 "miscadmin.h"
extern char *DatabasePath;


extern void SetDatabasePath(const char *path);

extern char *GetUserNameFromId(Oid roleid);
extern Oid GetUserId(void);
extern Oid GetOuterUserId(void);
extern Oid GetSessionUserId(void);
extern void GetUserIdAndSecContext(Oid *userid, int *sec_context);
extern void SetUserIdAndSecContext(Oid userid, int sec_context);
extern bool InLocalUserIdChange(void);
extern bool InSecurityRestrictedOperation(void);
extern void GetUserIdAndContext(Oid *userid, bool *sec_def_context);
extern void SetUserIdAndContext(Oid userid, bool sec_def_context);
extern void InitializeSessionUserId(const char *rolename);
extern void InitializeSessionUserIdStandalone(void);
extern void SetSessionAuthorization(Oid userid, bool is_superuser);
extern Oid GetCurrentRoleId(void);
extern void SetCurrentRoleId(Oid roleid, bool is_superuser);

extern void SetDataDir(const char *dir);
extern void ChangeToDataDir(void);
extern char *make_absolute_path(const char *path);


extern bool superuser(void);
extern bool superuser_arg(Oid roleid);
# 335 "miscadmin.h"
typedef enum ProcessingMode
{
 BootstrapProcessing,
 InitProcessing,
 NormalProcessing
} ProcessingMode;

extern ProcessingMode Mode;
# 365 "miscadmin.h"
typedef enum
{
 NotAnAuxProcess = -1,
 CheckerProcess = 0,
 BootstrapProcess,
 StartupProcess,
 BgWriterProcess,
 CheckpointerProcess,
 WalWriterProcess,
 WalReceiverProcess,

 NUM_AUXPROCTYPES
} AuxProcType;

extern AuxProcType MyAuxProcType;
# 395 "miscadmin.h"
extern void pg_split_opts(char **argv, int *argcp, char *optstr);
extern void InitPostgres(const char *in_dbname, Oid dboid, const char *username,
    char *out_dbname);
extern void BaseInit(void);


extern bool IgnoreSystemIndexes;
extern bool process_shared_preload_libraries_in_progress;
extern char *shared_preload_libraries_string;
extern char *local_preload_libraries_string;
# 431 "miscadmin.h"
extern void CreateDataDirLockFile(bool amPostmaster);
extern void CreateSocketLockFile(const char *socketfile, bool amPostmaster);
extern void TouchSocketLockFile(void);
extern void AddToDataDirLockFile(int target_line, const char *str);
extern void ValidatePgVersion(const char *path);
extern void process_shared_preload_libraries(void);
extern void process_local_preload_libraries(void);
extern void pg_bindtextdomain(const char *domain);
extern bool has_rolreplication(Oid roleid);


extern bool BackupInProgress(void);
extern void CancelBackup(void);
# 39 "pg_ctl.c" 2
# 48 "pg_ctl.c"
typedef long pgpid_t;


typedef enum
{
 SMART_MODE,
 FAST_MODE,
 IMMEDIATE_MODE
} ShutdownMode;


typedef enum
{
 NO_COMMAND = 0,
 INIT_COMMAND,
 START_COMMAND,
 STOP_COMMAND,
 RESTART_COMMAND,
 RELOAD_COMMAND,
 STATUS_COMMAND,
 PROMOTE_COMMAND,
 KILL_COMMAND,
 REGISTER_COMMAND,
 UNREGISTER_COMMAND,
 RUN_AS_SERVICE_COMMAND
} CtlCommand;



static bool do_wait = ((bool) 0);
static bool wait_set = ((bool) 0);
static int wait_seconds = 60;
static bool silent_mode = ((bool) 0);
static ShutdownMode shutdown_mode = SMART_MODE;
static int sig = 15;
static CtlCommand ctl_command = NO_COMMAND;
static char *pg_data = ((void *)0);
static char *pg_config = ((void *)0);
static char *pgdata_opt = ((void *)0);
static char *post_opts = ((void *)0);
static const char *progname;
static char *log_file = ((void *)0);
static char *exec_path = ((void *)0);
static char *register_servicename = "PostgreSQL";
static char *register_username = ((void *)0);
static char *register_password = ((void *)0);
static char *argv0 = ((void *)0);
static bool allow_core_files = ((bool) 0);
static time_t start_time;

static char postopts_file[1024];
static char pid_file[1024];
static char backup_file[1024];
static char recovery_file[1024];
static char promote_file[1024];
# 116 "pg_ctl.c"
static void
write_stderr(const char *fmt,...)


__attribute__((format(printf, 1, 2)));
static void *pg_malloc(size_t size);
static char *xstrdup(const char *s);
static void do_advice(void);
static void do_help(void);
static void set_mode(char *modeopt);
static void set_sig(char *signame);
static void do_init(void);
static void do_start(void);
static void do_stop(void);
static void do_restart(void);
static void do_reload(void);
static void do_status(void);
static void do_promote(void);
static void do_kill(pgpid_t pid);
static void print_msg(const char *msg);
static void adjust_data_dir(void);
# 150 "pg_ctl.c"
static pgpid_t get_pgpid(void);
static char **readfile(const char *path);
static int start_postmaster(void);
static void read_post_opts(void);

static PGPing test_postmaster_connection(bool);
static bool postmaster_is_alive(pid_t pid);


static void unlimit_core_size(void);
# 198 "pg_ctl.c"
static void
write_stderr(const char *fmt,...)
{
 va_list ap;

 __builtin_va_start(ap,fmt);


 vfprintf(__stderrp, fmt, ap);
# 225 "pg_ctl.c"
 __builtin_va_end(ap);
}





static void *
pg_malloc(size_t size)
{
 void *result;


 if (size == 0)
  size = 1;
 result = malloc(size);
 if (!result)
 {
  write_stderr(("%s: out of memory\n"), progname);
  exit(1);
 }
 return result;
}


static char *
xstrdup(const char *s)
{
 char *result;

 result = strdup(s);
 if (!result)
 {
  write_stderr(("%s: out of memory\n"), progname);
  exit(1);
 }
 return result;
}





static void
print_msg(const char *msg)
{
 if (!silent_mode)
 {
  fputs(msg, __stdoutp);
  fflush(__stdoutp);
 }
}

static pgpid_t
get_pgpid(void)
{
 FILE *pidf;
 long pid;

 pidf = fopen(pid_file, "r");
 if (pidf == ((void *)0))
 {

  if ((*__error()) == 2)
   return 0;
  else
  {
   write_stderr(("%s: could not open PID file \"%s\": %s\n"),
       progname, pid_file, strerror((*__error())));
   exit(1);
  }
 }
 if (fscanf(pidf, "%ld", &pid) != 1)
 {
  write_stderr(("%s: invalid data in PID file \"%s\"\n"),
      progname, pid_file);
  exit(1);
 }
 fclose(pidf);
 return (pgpid_t) pid;
}





static char **
readfile(const char *path)
{
 int fd;
 int nlines;
 char **result;
 char *buffer;
 char *linebegin;
 int i;
 int n;
 int len;
 struct stat statbuf;
# 332 "pg_ctl.c"
 fd = open(path, 0x0000 | 0, 0);
 if (fd < 0)
  return ((void *)0);
 if (fstat(fd, &statbuf) < 0)
 {
  close(fd);
  return ((void *)0);
 }
 if (statbuf.st_size == 0)
 {

  close(fd);
  result = (char **) pg_malloc(sizeof(char *));
  *result = ((void *)0);
  return result;
 }
 buffer = pg_malloc(statbuf.st_size + 1);

 len = read(fd, buffer, statbuf.st_size + 1);
 close(fd);
 if (len != statbuf.st_size)
 {

  free(buffer);
  return ((void *)0);
 }






 nlines = 0;
 for (i = 0; i < len; i++)
 {
  if (buffer[i] == '\n')
   nlines++;
 }


 result = (char **) pg_malloc((nlines + 1) * sizeof(char *));


 linebegin = buffer;
 n = 0;
 for (i = 0; i < len; i++)
 {
  if (buffer[i] == '\n')
  {
   int slen = &buffer[i] - linebegin + 1;
   char *linebuf = pg_malloc(slen + 1);
   ((__builtin_object_size (linebuf, 0) != (size_t) -1) ? __builtin___memcpy_chk (linebuf, linebegin, slen, __builtin_object_size (linebuf, 0)) : __inline_memcpy_chk (linebuf, linebegin, slen));
   linebuf[slen] = '\0';
   result[n++] = linebuf;
   linebegin = &buffer[i + 1];
  }
 }
 result[n] = ((void *)0);

 free(buffer);

 return result;
}







static int
start_postmaster(void)
{
 char cmd[1024];
# 417 "pg_ctl.c"
 if (log_file != ((void *)0))
  __builtin___snprintf_chk (cmd, 1024, 0, __builtin_object_size (cmd, 2 > 1), "" "\"%s\" %s%s < \"%s\" >> \"%s\" 2>&1 &" "", exec_path, pgdata_opt, post_opts, "/dev/null", log_file);


 else
  __builtin___snprintf_chk (cmd, 1024, 0, __builtin_object_size (cmd, 2 > 1), "" "\"%s\" %s%s < \"%s\" 2>&1 &" "", exec_path, pgdata_opt, post_opts, "/dev/null");


 return system(cmd);
# 448 "pg_ctl.c"
}
# 458 "pg_ctl.c"
static PGPing
test_postmaster_connection(bool do_checkpoint)
{
 PGPing ret = PQPING_NO_RESPONSE;
 bool found_stale_pidfile = ((bool) 0);
 pgpid_t pm_pid = 0;
 char connstr[1024 * 2 + 256];
 int i;


 if (wait_seconds <= 0)
  return PQPING_REJECT;

 connstr[0] = '\0';

 for (i = 0; i < wait_seconds; i++)
 {

  if (connstr[0] == '\0')
  {
# 499 "pg_ctl.c"
   char **optlines;


   if ((optlines = readfile(pid_file)) != ((void *)0) &&
    optlines[0] != ((void *)0) &&
    optlines[1] != ((void *)0) &&
    optlines[2] != ((void *)0))
   {
    if (optlines[3] == ((void *)0))
    {

     write_stderr(("\n%s: -w option is not supported when starting a pre-9.1 server\n"),
         progname);
     return PQPING_NO_ATTEMPT;
    }
    else if (optlines[4] != ((void *)0) &&
       optlines[5] != ((void *)0))
    {

     long pmpid;
     time_t pmstart;
# 530 "pg_ctl.c"
     pmpid = atol(optlines[1 - 1]);
     pmstart = atol(optlines[3 - 1]);
     if (pmpid <= 0 || pmstart < start_time - 2)
     {




      found_stale_pidfile = ((bool) 1);
     }
     else
     {



      int portnum;
      char *sockdir;
      char *hostaddr;
      char host_str[1024];

      found_stale_pidfile = ((bool) 0);
      pm_pid = (pgpid_t) pmpid;





      portnum = atoi(optlines[4 - 1]);
      sockdir = optlines[5 - 1];
      hostaddr = optlines[6 - 1];
# 568 "pg_ctl.c"
      if (sockdir[0] == '/')
       strlcpy(host_str, sockdir, sizeof(host_str));
      else
       strlcpy(host_str, hostaddr, sizeof(host_str));


      if (strchr(host_str, '\n') != ((void *)0))
       *strchr(host_str, '\n') = '\0';


      if (host_str[0] == '\0')
      {
       write_stderr(("\n%s: -w option cannot use a relative socket directory specification\n"),
           progname);
       return PQPING_NO_ATTEMPT;
      }


      if (strcmp(host_str, "*") == 0)
       ((__builtin_object_size (host_str, 0) != (size_t) -1) ? __builtin___strcpy_chk (host_str, "localhost", __builtin_object_size (host_str, 2 > 1)) : __inline_strcpy_chk (host_str, "localhost"));






      __builtin___snprintf_chk (connstr, sizeof(connstr), 0, __builtin_object_size (connstr, 2 > 1), "dbname=postgres port=%d host='%s' connect_timeout=5", portnum, host_str);


     }
    }
   }
  }


  if (connstr[0] != '\0')
  {
   ret = PQping(connstr);
   if (ret == PQPING_OK || ret == PQPING_NO_ATTEMPT)
    break;
  }
# 619 "pg_ctl.c"
  if (i >= 5)
  {
   struct stat statbuf;

   if (stat(pid_file, &statbuf) != 0)
    return PQPING_NO_RESPONSE;

   if (found_stale_pidfile)
   {
    write_stderr(("\n%s: this data directory appears to be running a pre-existing postmaster\n"),
        progname);
    return PQPING_NO_RESPONSE;
   }
  }







  if (pm_pid > 0 && !postmaster_is_alive((pid_t) pm_pid))
   return PQPING_NO_RESPONSE;
# 659 "pg_ctl.c"
   print_msg(".");

  pg_usleep(1000000);
 }


 return ret;
}



static void
unlimit_core_size(void)
{
 struct rlimit lim;

 getrlimit(4, &lim);
 if (lim.rlim_max == 0)
 {
  write_stderr(("%s: cannot set core file size limit; disallowed by hard limit\n"),
      progname);
  return;
 }
 else if (lim.rlim_max == (((__uint64_t)1 << 63) - 1) || lim.rlim_cur < lim.rlim_max)
 {
  lim.rlim_cur = lim.rlim_max;
  setrlimit(4, &lim);
 }
}


static void
read_post_opts(void)
{
 if (post_opts == ((void *)0))
 {
  post_opts = "";
  if (ctl_command == RESTART_COMMAND)
  {
   char **optlines;

   optlines = readfile(postopts_file);
   if (optlines == ((void *)0))
   {
    write_stderr(("%s: could not read file \"%s\"\n"), progname, postopts_file);
    exit(1);
   }
   else if (optlines[0] == ((void *)0) || optlines[1] != ((void *)0))
   {
    write_stderr(("%s: option file \"%s\" must have exactly one line\n"),
        progname, postopts_file);
    exit(1);
   }
   else
   {
    int len;
    char *optline;
    char *arg1;

    optline = optlines[0];

    len = strcspn(optline, "\r\n");
    optline[len] = '\0';





    if ((arg1 = strstr(optline, " \"")) != ((void *)0))
    {
     *arg1 = '\0';

     post_opts = arg1 + 1;
    }
    if (exec_path == ((void *)0))
     exec_path = optline;
   }
  }
 }
}

static char *
find_other_exec_or_die(const char *argv0, const char *target, const char *versionstr)
{
 int ret;
 char *found_path;

 found_path = pg_malloc(1024);

 if ((ret = find_other_exec(argv0, target, versionstr, found_path)) < 0)
 {
  char full_path[1024];

  if (find_my_exec(argv0, full_path) < 0)
   strlcpy(full_path, progname, sizeof(full_path));

  if (ret == -1)
   write_stderr(("The program \"%s\" is needed by %s " "but was not found in the\n" "same directory as \"%s\".\n" "Check your installation.\n"),



       target, progname, full_path);
  else
   write_stderr(("The program \"%s\" was found by \"%s\"\n" "but was not the same version as %s.\n" "Check your installation.\n"),


       target, full_path, progname);
  exit(1);
 }

 return found_path;
}

static void
do_init(void)
{
 char cmd[1024];

 if (exec_path == ((void *)0))
  exec_path = find_other_exec_or_die(argv0, "initdb", "initdb (PostgreSQL) " "9.2.4" "\n");

 if (pgdata_opt == ((void *)0))
  pgdata_opt = "";

 if (post_opts == ((void *)0))
  post_opts = "";

 if (!silent_mode)
  __builtin___snprintf_chk (cmd, 1024, 0, __builtin_object_size (cmd, 2 > 1), "" "\"%s\" %s%s" "", exec_path, pgdata_opt, post_opts);

 else
  __builtin___snprintf_chk (cmd, 1024, 0, __builtin_object_size (cmd, 2 > 1), "" "\"%s\" %s%s > \"%s\"" "", exec_path, pgdata_opt, post_opts, "/dev/null");


 if (system(cmd) != 0)
 {
  write_stderr(("%s: database system initialization failed\n"), progname);
  exit(1);
 }
}

static void
do_start(void)
{
 pgpid_t old_pid = 0;
 int exitcode;

 if (ctl_command != RESTART_COMMAND)
 {
  old_pid = get_pgpid();
  if (old_pid != 0)
   write_stderr(("%s: another server might be running; " "trying to start server anyway\n"),

       progname);
 }

 read_post_opts();


 if (ctl_command == RESTART_COMMAND || pgdata_opt == ((void *)0))
  pgdata_opt = "";

 if (exec_path == ((void *)0))
  exec_path = find_other_exec_or_die(argv0, "postgres", "postgres (PostgreSQL) " "9.2.4" "\n");


 if (allow_core_files)
  unlimit_core_size();
# 835 "pg_ctl.c"
 {
  static char env_var[32];

  __builtin___snprintf_chk (env_var, sizeof(env_var), 0, __builtin_object_size (env_var, 2 > 1), "PG_GRANDPARENT_PID=%d", (int) getppid());

  putenv(env_var);
 }


 exitcode = start_postmaster();
 if (exitcode != 0)
 {
  write_stderr(("%s: could not start server: exit code was %d\n"),
      progname, exitcode);
  exit(1);
 }

 if (do_wait)
 {
  print_msg(("waiting for server to start..."));

  switch (test_postmaster_connection(((bool) 0)))
  {
   case PQPING_OK:
    print_msg((" done\n"));
    print_msg(("server started\n"));
    break;
   case PQPING_REJECT:
    print_msg((" stopped waiting\n"));
    print_msg(("server is still starting up\n"));
    break;
   case PQPING_NO_RESPONSE:
    print_msg((" stopped waiting\n"));
    write_stderr(("%s: could not start server\n" "Examine the log output.\n"),

        progname);
    exit(1);
    break;
   case PQPING_NO_ATTEMPT:
    print_msg((" failed\n"));
    write_stderr(("%s: could not wait for server because of misconfiguration\n"),
        progname);
    exit(1);
  }
 }
 else
  print_msg(("server starting\n"));
}


static void
do_stop(void)
{
 int cnt;
 pgpid_t pid;
 struct stat statbuf;

 pid = get_pgpid();

 if (pid == 0)
 {
  write_stderr(("%s: PID file \"%s\" does not exist\n"), progname, pid_file);
  write_stderr(("Is server running?\n"));
  exit(1);
 }
 else if (pid < 0)
 {
  pid = -pid;
  write_stderr(("%s: cannot stop server; " "single-user server is running (PID: %ld)\n"),

      progname, pid);
  exit(1);
 }

 if (kill((pid_t) pid, sig) != 0)
 {
  write_stderr(("%s: could not send stop signal (PID: %ld): %s\n"), progname, pid,
      strerror((*__error())));
  exit(1);
 }

 if (!do_wait)
 {
  print_msg(("server shutting down\n"));
  return;
 }
 else
 {






  if (shutdown_mode == SMART_MODE &&
   stat(backup_file, &statbuf) == 0 &&
   stat(recovery_file, &statbuf) != 0)
  {
   print_msg(("WARNING: online backup mode is active\n" "Shutdown will not complete until pg_stop_backup() is called.\n\n"));

  }

  print_msg(("waiting for server to shut down..."));

  for (cnt = 0; cnt < wait_seconds; cnt++)
  {
   if ((pid = get_pgpid()) != 0)
   {
    print_msg(".");
    pg_usleep(1000000);
   }
   else
    break;
  }

  if (pid != 0)
  {
   print_msg((" failed\n"));

   write_stderr(("%s: server does not shut down\n"), progname);
   if (shutdown_mode == SMART_MODE)
    write_stderr(("HINT: The \"-m fast\" option immediately disconnects sessions rather than\n" "waiting for session-initiated disconnection.\n"));

   exit(1);
  }
  print_msg((" done\n"));

  print_msg(("server stopped\n"));
 }
}






static void
do_restart(void)
{
 int cnt;
 pgpid_t pid;
 struct stat statbuf;

 pid = get_pgpid();

 if (pid == 0)
 {
  write_stderr(("%s: PID file \"%s\" does not exist\n"),
      progname, pid_file);
  write_stderr(("Is server running?\n"));
  write_stderr(("starting server anyway\n"));
  do_start();
  return;
 }
 else if (pid < 0)
 {
  pid = -pid;
  if (postmaster_is_alive((pid_t) pid))
  {
   write_stderr(("%s: cannot restart server; " "single-user server is running (PID: %ld)\n"),

       progname, pid);
   write_stderr(("Please terminate the single-user server and try again.\n"));
   exit(1);
  }
 }

 if (postmaster_is_alive((pid_t) pid))
 {
  if (kill((pid_t) pid, sig) != 0)
  {
   write_stderr(("%s: could not send stop signal (PID: %ld): %s\n"), progname, pid,
       strerror((*__error())));
   exit(1);
  }







  if (shutdown_mode == SMART_MODE &&
   stat(backup_file, &statbuf) == 0 &&
   stat(recovery_file, &statbuf) != 0)
  {
   print_msg(("WARNING: online backup mode is active\n" "Shutdown will not complete until pg_stop_backup() is called.\n\n"));

  }

  print_msg(("waiting for server to shut down..."));



  for (cnt = 0; cnt < wait_seconds; cnt++)
  {
   if ((pid = get_pgpid()) != 0)
   {
    print_msg(".");
    pg_usleep(1000000);
   }
   else
    break;
  }

  if (pid != 0)
  {
   print_msg((" failed\n"));

   write_stderr(("%s: server does not shut down\n"), progname);
   if (shutdown_mode == SMART_MODE)
    write_stderr(("HINT: The \"-m fast\" option immediately disconnects sessions rather than\n" "waiting for session-initiated disconnection.\n"));

   exit(1);
  }

  print_msg((" done\n"));
  print_msg(("server stopped\n"));
 }
 else
 {
  write_stderr(("%s: old server process (PID: %ld) seems to be gone\n"),
      progname, pid);
  write_stderr(("starting server anyway\n"));
 }

 do_start();
}

static void
do_reload(void)
{
 pgpid_t pid;

 pid = get_pgpid();
 if (pid == 0)
 {
  write_stderr(("%s: PID file \"%s\" does not exist\n"), progname, pid_file);
  write_stderr(("Is server running?\n"));
  exit(1);
 }
 else if (pid < 0)
 {
  pid = -pid;
  write_stderr(("%s: cannot reload server; " "single-user server is running (PID: %ld)\n"),

      progname, pid);
  write_stderr(("Please terminate the single-user server and try again.\n"));
  exit(1);
 }

 if (kill((pid_t) pid, sig) != 0)
 {
  write_stderr(("%s: could not send reload signal (PID: %ld): %s\n"),
      progname, pid, strerror((*__error())));
  exit(1);
 }

 print_msg(("server signaled\n"));
}






static void
do_promote(void)
{
 FILE *prmfile;
 pgpid_t pid;
 struct stat statbuf;

 pid = get_pgpid();

 if (pid == 0)
 {
  write_stderr(("%s: PID file \"%s\" does not exist\n"), progname, pid_file);
  write_stderr(("Is server running?\n"));
  exit(1);
 }
 else if (pid < 0)
 {
  pid = -pid;
  write_stderr(("%s: cannot promote server; " "single-user server is running (PID: %ld)\n"),

      progname, pid);
  exit(1);
 }


 if (stat(recovery_file, &statbuf) != 0)
 {
  write_stderr(("%s: cannot promote server; " "server is not in standby mode\n"),

      progname);
  exit(1);
 }

 if ((prmfile = fopen(promote_file, "w")) == ((void *)0))
 {
  write_stderr(("%s: could not create promote signal file \"%s\": %s\n"),
      progname, promote_file, strerror((*__error())));
  exit(1);
 }
 if (fclose(prmfile))
 {
  write_stderr(("%s: could not write promote signal file \"%s\": %s\n"),
      progname, promote_file, strerror((*__error())));
  exit(1);
 }

 sig = 30;
 if (kill((pid_t) pid, sig) != 0)
 {
  write_stderr(("%s: could not send promote signal (PID: %ld): %s\n"),
      progname, pid, strerror((*__error())));
  if (unlink(promote_file) != 0)
   write_stderr(("%s: could not remove promote signal file \"%s\": %s\n"),
       progname, promote_file, strerror((*__error())));
  exit(1);
 }

 print_msg(("server promoting\n"));
}






static bool
postmaster_is_alive(pid_t pid)
{
# 1179 "pg_ctl.c"
 if (pid == getpid())
  return ((bool) 0);

 if (pid == getppid())
  return ((bool) 0);

 if (kill(pid, 0) == 0)
  return ((bool) 1);
 return ((bool) 0);
}

static void
do_status(void)
{
 pgpid_t pid;

 pid = get_pgpid();

 if (pid != 0)
 {

  if (pid < 0)
  {
   pid = -pid;
   if (postmaster_is_alive((pid_t) pid))
   {
    printf(("%s: single-user server is running (PID: %ld)\n"),
        progname, pid);
    return;
   }
  }
  else

  {
   if (postmaster_is_alive((pid_t) pid))
   {
    char **optlines;

    printf(("%s: server is running (PID: %ld)\n"),
        progname, pid);

    optlines = readfile(postopts_file);
    if (optlines != ((void *)0))
     for (; *optlines != ((void *)0); optlines++)
      fputs(*optlines, __stdoutp);
    return;
   }
  }
 }
 printf(("%s: no server running\n"), progname);







 exit(3);
}



static void
do_kill(pgpid_t pid)
{
 if (kill((pid_t) pid, sig) != 0)
 {
  write_stderr(("%s: could not send signal %d (PID: %ld): %s\n"),
      progname, sig, pid, strerror((*__error())));
  exit(1);
 }
}
# 1777 "pg_ctl.c"
static void
do_advice(void)
{
 write_stderr(("Try \"%s --help\" for more information.\n"), progname);
}



static void
do_help(void)
{
 printf(("%s is a utility to initialize, start, stop, or control a PostgreSQL server.\n\n"), progname);
 printf(("Usage:\n"));
 printf(("  %s init[db]               [-D DATADIR] [-s] [-o \"OPTIONS\"]\n"), progname);
 printf(("  %s start   [-w] [-t SECS] [-D DATADIR] [-s] [-l FILENAME] [-o \"OPTIONS\"]\n"), progname);
 printf(("  %s stop    [-W] [-t SECS] [-D DATADIR] [-s] [-m SHUTDOWN-MODE]\n"), progname);
 printf(("  %s restart [-w] [-t SECS] [-D DATADIR] [-s] [-m SHUTDOWN-MODE]\n" "                 [-o \"OPTIONS\"]\n"), progname);

 printf(("  %s reload  [-D DATADIR] [-s]\n"), progname);
 printf(("  %s status  [-D DATADIR]\n"), progname);
 printf(("  %s promote [-D DATADIR] [-s]\n"), progname);
 printf(("  %s kill    SIGNALNAME PID\n"), progname);






 printf(("\nCommon options:\n"));
 printf(("  -D, --pgdata=DATADIR   location of the database storage area\n"));
 printf(("  -s, --silent           only print errors, no informational messages\n"));
 printf(("  -t, --timeout=SECS     seconds to wait when using -w option\n"));
 printf(("  -V, --version          output version information, then exit\n"));
 printf(("  -w                     wait until operation completes\n"));
 printf(("  -W                     do not wait until operation completes\n"));
 printf(("  -?, --help             show this help, then exit\n"));
 printf(("(The default is to wait for shutdown, but not for start or restart.)\n\n"));
 printf(("If the -D option is omitted, the environment variable PGDATA is used.\n"));

 printf(("\nOptions for start or restart:\n"));

 printf(("  -c, --core-files       allow postgres to produce core files\n"));



 printf(("  -l, --log=FILENAME     write (or append) server log to FILENAME\n"));
 printf(("  -o OPTIONS             command line options to pass to postgres\n" "                         (PostgreSQL server executable) or initdb\n"));

 printf(("  -p PATH-TO-POSTGRES    normally not necessary\n"));
 printf(("\nOptions for stop or restart:\n"));
 printf(("  -m, --mode=MODE        MODE can be \"smart\", \"fast\", or \"immediate\"\n"));

 printf(("\nShutdown modes are:\n"));
 printf(("  smart       quit after all clients have disconnected\n"));
 printf(("  fast        quit directly, with proper shutdown\n"));
 printf(("  immediate   quit without complete shutdown; will lead to recovery on restart\n"));

 printf(("\nAllowed signal names for kill:\n"));
 printf("  ABRT HUP INT QUIT TERM USR1 USR2\n");
# 1849 "pg_ctl.c"
 printf(("\nReport bugs to <pgsql-bugs@postgresql.org>.\n"));
}



static void
set_mode(char *modeopt)
{
 if (strcmp(modeopt, "s") == 0 || strcmp(modeopt, "smart") == 0)
 {
  shutdown_mode = SMART_MODE;
  sig = 15;
 }
 else if (strcmp(modeopt, "f") == 0 || strcmp(modeopt, "fast") == 0)
 {
  shutdown_mode = FAST_MODE;
  sig = 2;
 }
 else if (strcmp(modeopt, "i") == 0 || strcmp(modeopt, "immediate") == 0)
 {
  shutdown_mode = IMMEDIATE_MODE;
  sig = 3;
 }
 else
 {
  write_stderr(("%s: unrecognized shutdown mode \"%s\"\n"), progname, modeopt);
  do_advice();
  exit(1);
 }
}



static void
set_sig(char *signame)
{
 if (strcmp(signame, "HUP") == 0)
  sig = 1;
 else if (strcmp(signame, "INT") == 0)
  sig = 2;
 else if (strcmp(signame, "QUIT") == 0)
  sig = 3;
 else if (strcmp(signame, "ABRT") == 0)
  sig = 6;





 else if (strcmp(signame, "TERM") == 0)
  sig = 15;
 else if (strcmp(signame, "USR1") == 0)
  sig = 30;
 else if (strcmp(signame, "USR2") == 0)
  sig = 31;
 else
 {
  write_stderr(("%s: unrecognized signal name \"%s\"\n"), progname, signame);
  do_advice();
  exit(1);
 }
}
# 1935 "pg_ctl.c"
static void
adjust_data_dir(void)
{
 char cmd[1024],
    filename[1024],
      *my_exec_path;
 FILE *fd;


 if (pg_config == ((void *)0))
  return;


 __builtin___snprintf_chk (filename, sizeof(filename), 0, __builtin_object_size (filename, 2 > 1), "%s/postgresql.conf", pg_config);
 if ((fd = fopen(filename, "r")) == ((void *)0))
  return;
 fclose(fd);


 __builtin___snprintf_chk (filename, sizeof(filename), 0, __builtin_object_size (filename, 2 > 1), "%s/PG_VERSION", pg_config);
 if ((fd = fopen(filename, "r")) != ((void *)0))
 {
  fclose(fd);
  return;
 }




 if (exec_path == ((void *)0))
  my_exec_path = find_other_exec_or_die(argv0, "postgres", "postgres (PostgreSQL) " "9.2.4" "\n");
 else
  my_exec_path = xstrdup(exec_path);

 __builtin___snprintf_chk (cmd, 1024, 0, __builtin_object_size (cmd, 2 > 1), "" "\"%s\" %s%s -C data_directory" "", my_exec_path, pgdata_opt ? pgdata_opt : "", post_opts ? post_opts : "");



 fd = popen(cmd, "r");
 if (fd == ((void *)0) || fgets(filename, sizeof(filename), fd) == ((void *)0))
 {
  write_stderr(("%s: could not determine the data directory using command \"%s\"\n"), progname, cmd);
  exit(1);
 }
 pclose(fd);
 free(my_exec_path);


 if (strchr(filename, '\n') != ((void *)0))
  *strchr(filename, '\n') = '\0';

 free(pg_data);
 pg_data = xstrdup(filename);
 canonicalize_path(pg_data);
}


int
main(int argc, char **argv)
{
 static struct option long_options[] = {
  {"help", 0, ((void *)0), '?'},
  {"version", 0, ((void *)0), 'V'},
  {"log", 1, ((void *)0), 'l'},
  {"mode", 1, ((void *)0), 'm'},
  {"pgdata", 1, ((void *)0), 'D'},
  {"silent", 0, ((void *)0), 's'},
  {"timeout", 1, ((void *)0), 't'},
  {"core-files", 0, ((void *)0), 'c'},
  {((void *)0), 0, ((void *)0), 0}
 };

 int option_index;
 int c;
 pgpid_t killproc = 0;





 progname = get_progname(argv[0]);
 set_pglocale_pgservice(argv[0], ("pg_ctl" "-" "9.2"));
 start_time = time(((void *)0));





 argv0 = argv[0];

 umask(0000070 | 0000007);


 if (argc > 1)
 {
  if (strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "--help") == 0 ||
   strcmp(argv[1], "-?") == 0)
  {
   do_help();
   exit(0);
  }
  else if (strcmp(argv[1], "-V") == 0 || strcmp(argv[1], "--version") == 0)
  {
   puts("pg_ctl (PostgreSQL) " "9.2.4");
   exit(0);
  }
 }





 if (geteuid() == 0)
 {
  write_stderr(("%s: cannot be run as root\n" "Please log in (using, e.g., \"su\") as the " "(unprivileged) user that will\n" "own the server process.\n"),



      progname);
  exit(1);
 }
# 2064 "pg_ctl.c"
 optind = 1;


 while (optind < argc)
 {
  while ((c = getopt_long(argc, argv, "cD:l:m:N:o:p:P:sS:t:U:wW", long_options, &option_index)) != -1)
  {
   switch (c)
   {
    case 'D':
     {
      char *pgdata_D;
      char *env_var = pg_malloc(strlen(optarg) + 8);

      pgdata_D = xstrdup(optarg);
      canonicalize_path(pgdata_D);
      __builtin___snprintf_chk (env_var, strlen(optarg) + 8, 0, __builtin_object_size (env_var, 2 > 1), "PGDATA=%s", pgdata_D);

      putenv(env_var);






      pgdata_opt = pg_malloc(strlen(pgdata_D) + 7);
      __builtin___snprintf_chk (pgdata_opt, strlen(pgdata_D) + 7, 0, __builtin_object_size (pgdata_opt, 2 > 1), "-D \"%s\" ", pgdata_D);


      break;
     }
    case 'l':
     log_file = xstrdup(optarg);
     break;
    case 'm':
     set_mode(optarg);
     break;
    case 'N':
     register_servicename = xstrdup(optarg);
     break;
    case 'o':
     post_opts = xstrdup(optarg);
     break;
    case 'p':
     exec_path = xstrdup(optarg);
     break;
    case 'P':
     register_password = xstrdup(optarg);
     break;
    case 's':
     silent_mode = ((bool) 1);
     break;
    case 'S':



     write_stderr(("%s: -S option not supported on this platform\n"),
         progname);
     exit(1);

     break;
    case 't':
     wait_seconds = atoi(optarg);
     break;
    case 'U':
     if (strchr(optarg, '\\'))
      register_username = xstrdup(optarg);
     else

     {
      register_username = malloc(strlen(optarg) + 3);
      if (!register_username)
      {
       write_stderr(("%s: out of memory\n"), progname);
       exit(1);
      }
      ((__builtin_object_size (register_username, 0) != (size_t) -1) ? __builtin___strcpy_chk (register_username, ".\\", __builtin_object_size (register_username, 2 > 1)) : __inline_strcpy_chk (register_username, ".\\"));
      ((__builtin_object_size (register_username, 0) != (size_t) -1) ? __builtin___strcat_chk (register_username, optarg, __builtin_object_size (register_username, 2 > 1)) : __inline_strcat_chk (register_username, optarg));
     }
     break;
    case 'w':
     do_wait = ((bool) 1);
     wait_set = ((bool) 1);
     break;
    case 'W':
     do_wait = ((bool) 0);
     wait_set = ((bool) 1);
     break;
    case 'c':
     allow_core_files = ((bool) 1);
     break;
    default:

     do_advice();
     exit(1);
   }
  }


  if (optind < argc)
  {
   if (ctl_command != NO_COMMAND)
   {
    write_stderr(("%s: too many command-line arguments (first is \"%s\")\n"), progname, argv[optind]);
    do_advice();
    exit(1);
   }

   if (strcmp(argv[optind], "init") == 0
    || strcmp(argv[optind], "initdb") == 0)
    ctl_command = INIT_COMMAND;
   else if (strcmp(argv[optind], "start") == 0)
    ctl_command = START_COMMAND;
   else if (strcmp(argv[optind], "stop") == 0)
    ctl_command = STOP_COMMAND;
   else if (strcmp(argv[optind], "restart") == 0)
    ctl_command = RESTART_COMMAND;
   else if (strcmp(argv[optind], "reload") == 0)
    ctl_command = RELOAD_COMMAND;
   else if (strcmp(argv[optind], "status") == 0)
    ctl_command = STATUS_COMMAND;
   else if (strcmp(argv[optind], "promote") == 0)
    ctl_command = PROMOTE_COMMAND;
   else if (strcmp(argv[optind], "kill") == 0)
   {
    if (argc - optind < 3)
    {
     write_stderr(("%s: missing arguments for kill mode\n"), progname);
     do_advice();
     exit(1);
    }
    ctl_command = KILL_COMMAND;
    set_sig(argv[++optind]);
    killproc = atol(argv[++optind]);
   }
# 2207 "pg_ctl.c"
   else
   {
    write_stderr(("%s: unrecognized operation mode \"%s\"\n"), progname, argv[optind]);
    do_advice();
    exit(1);
   }
   optind++;
  }
 }

 if (ctl_command == NO_COMMAND)
 {
  write_stderr(("%s: no operation specified\n"), progname);
  do_advice();
  exit(1);
 }


 pg_config = getenv("PGDATA");
 if (pg_config)
 {
  pg_config = xstrdup(pg_config);
  canonicalize_path(pg_config);
  pg_data = xstrdup(pg_config);
 }


 adjust_data_dir();


 if (pg_config == ((void *)0) &&
  ctl_command != KILL_COMMAND && ctl_command != UNREGISTER_COMMAND)
 {
  write_stderr(("%s: no database directory specified and environment variable PGDATA unset\n"),
      progname);
  do_advice();
  exit(1);
 }

 if (!wait_set)
 {
  switch (ctl_command)
  {
   case RESTART_COMMAND:
   case START_COMMAND:
    do_wait = ((bool) 0);
    break;
   case STOP_COMMAND:
    do_wait = ((bool) 1);
    break;
   default:
    break;
  }
 }

 if (ctl_command == RELOAD_COMMAND)
 {
  sig = 1;
  do_wait = ((bool) 0);
 }

 if (pg_data)
 {
  __builtin___snprintf_chk (postopts_file, 1024, 0, __builtin_object_size (postopts_file, 2 > 1), "%s/postmaster.opts", pg_data);
  __builtin___snprintf_chk (pid_file, 1024, 0, __builtin_object_size (pid_file, 2 > 1), "%s/postmaster.pid", pg_data);
  __builtin___snprintf_chk (backup_file, 1024, 0, __builtin_object_size (backup_file, 2 > 1), "%s/backup_label", pg_data);
  __builtin___snprintf_chk (recovery_file, 1024, 0, __builtin_object_size (recovery_file, 2 > 1), "%s/recovery.conf", pg_data);
  __builtin___snprintf_chk (promote_file, 1024, 0, __builtin_object_size (promote_file, 2 > 1), "%s/promote", pg_data);
 }

 switch (ctl_command)
 {
  case INIT_COMMAND:
   do_init();
   break;
  case STATUS_COMMAND:
   do_status();
   break;
  case START_COMMAND:
   do_start();
   break;
  case STOP_COMMAND:
   do_stop();
   break;
  case RESTART_COMMAND:
   do_restart();
   break;
  case RELOAD_COMMAND:
   do_reload();
   break;
  case PROMOTE_COMMAND:
   do_promote();
   break;
  case KILL_COMMAND:
   do_kill(killproc);
   break;
# 2314 "pg_ctl.c"
  default:
   break;
 }

 exit(0);
}

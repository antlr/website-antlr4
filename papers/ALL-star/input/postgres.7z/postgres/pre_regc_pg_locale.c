# 1 "regc_pg_locale.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "regc_pg_locale.c"
# 18 "regc_pg_locale.c"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_collation.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_collation.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/genbki.h" 1
# 49 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/genbki.h"
typedef int aclitem;
typedef int pg_node_tree;
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_collation.h" 2
# 32 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_collation.h"
typedef struct FormData_pg_collation
{
 NameData collname;
 Oid collnamespace;
 Oid collowner;
 int4 collencoding;
 NameData collcollate;
 NameData collctype;
} FormData_pg_collation;






typedef FormData_pg_collation *Form_pg_collation;
# 66 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_collation.h"
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
# 19 "regc_pg_locale.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/pg_locale.h" 1
# 15 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/pg_locale.h"
# 1 "/usr/include/locale.h" 1 3 4
# 40 "/usr/include/locale.h" 3 4
# 1 "/usr/include/_locale.h" 1 3 4
# 40 "/usr/include/_locale.h" 3 4
# 1 "/usr/include/sys/cdefs.h" 1 3 4
# 417 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 418 "/usr/include/sys/cdefs.h" 2 3 4
# 494 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_posix_availability.h" 1 3 4
# 495 "/usr/include/sys/cdefs.h" 2 3 4
# 41 "/usr/include/_locale.h" 2 3 4
# 1 "/usr/include/_types.h" 1 3 4
# 27 "/usr/include/_types.h" 3 4
# 1 "/usr/include/sys/_types.h" 1 3 4
# 33 "/usr/include/sys/_types.h" 3 4
# 1 "/usr/include/machine/_types.h" 1 3 4
# 32 "/usr/include/machine/_types.h" 3 4
# 1 "/usr/include/i386/_types.h" 1 3 4
# 37 "/usr/include/i386/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 70 "/usr/include/i386/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;


typedef long int __darwin_ptrdiff_t;





typedef long unsigned int __darwin_size_t;





typedef __builtin_va_list __darwin_va_list;





typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 33 "/usr/include/machine/_types.h" 2 3 4
# 34 "/usr/include/sys/_types.h" 2 3 4
# 58 "/usr/include/sys/_types.h" 3 4
struct __darwin_pthread_handler_rec
{
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};
struct _opaque_pthread_attr_t { long __sig; char __opaque[56]; };
struct _opaque_pthread_cond_t { long __sig; char __opaque[40]; };
struct _opaque_pthread_condattr_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_mutex_t { long __sig; char __opaque[56]; };
struct _opaque_pthread_mutexattr_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_once_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_rwlock_t { long __sig; char __opaque[192]; };
struct _opaque_pthread_rwlockattr_t { long __sig; char __opaque[16]; };
struct _opaque_pthread_t { long __sig; struct __darwin_pthread_handler_rec *__cleanup_stack; char __opaque[1168]; };
# 94 "/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef struct _opaque_pthread_attr_t
   __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t
   __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t
   __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t
   __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t
   __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t
   __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t
   __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t
   __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t
   *__darwin_pthread_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];
# 28 "/usr/include/_types.h" 2 3 4
# 39 "/usr/include/_types.h" 3 4
typedef int __darwin_nl_item;
typedef int __darwin_wctrans_t;

typedef __uint32_t __darwin_wctype_t;
# 42 "/usr/include/_locale.h" 2 3 4

struct lconv {
 char *decimal_point;
 char *thousands_sep;
 char *grouping;
 char *int_curr_symbol;
 char *currency_symbol;
 char *mon_decimal_point;
 char *mon_thousands_sep;
 char *mon_grouping;
 char *positive_sign;
 char *negative_sign;
 char int_frac_digits;
 char frac_digits;
 char p_cs_precedes;
 char p_sep_by_space;
 char n_cs_precedes;
 char n_sep_by_space;
 char p_sign_posn;
 char n_sign_posn;
 char int_p_cs_precedes;
 char int_n_cs_precedes;
 char int_p_sep_by_space;
 char int_n_sep_by_space;
 char int_p_sign_posn;
 char int_n_sign_posn;
};






struct lconv *localeconv(void);

# 41 "/usr/include/locale.h" 2 3 4
# 52 "/usr/include/locale.h" 3 4

char *setlocale(int, const char *);

# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/pg_locale.h" 2




# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/bitmapset.h" 1
# 29 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/bitmapset.h"
typedef uint32 bitmapword;
typedef int32 signedbitmapword;

typedef struct Bitmapset
{
 int nwords;
 bitmapword words[1];
} Bitmapset;



typedef enum
{
 BMS_EQUAL,
 BMS_SUBSET1,
 BMS_SUBSET2,
 BMS_DIFFERENT
} BMS_Comparison;


typedef enum
{
 BMS_EMPTY_SET,
 BMS_SINGLETON,
 BMS_MULTIPLE
} BMS_Membership;






extern Bitmapset *bms_copy(const Bitmapset *a);
extern bool bms_equal(const Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_make_singleton(int x);
extern void bms_free(Bitmapset *a);

extern Bitmapset *bms_union(const Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_intersect(const Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_difference(const Bitmapset *a, const Bitmapset *b);
extern bool bms_is_subset(const Bitmapset *a, const Bitmapset *b);
extern BMS_Comparison bms_subset_compare(const Bitmapset *a, const Bitmapset *b);
extern bool bms_is_member(int x, const Bitmapset *a);
extern bool bms_overlap(const Bitmapset *a, const Bitmapset *b);
extern bool bms_nonempty_difference(const Bitmapset *a, const Bitmapset *b);
extern int bms_singleton_member(const Bitmapset *a);
extern int bms_num_members(const Bitmapset *a);


extern BMS_Membership bms_membership(const Bitmapset *a);
extern bool bms_is_empty(const Bitmapset *a);



extern Bitmapset *bms_add_member(Bitmapset *a, int x);
extern Bitmapset *bms_del_member(Bitmapset *a, int x);
extern Bitmapset *bms_add_members(Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_int_members(Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_del_members(Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_join(Bitmapset *a, Bitmapset *b);


extern int bms_first_member(Bitmapset *a);


extern uint32 bms_hash_value(const Bitmapset *a);
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h"
typedef int16 AttrNumber;
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 1
# 40 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h" 1
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum NodeTag
{
 T_Invalid = 0,




 T_IndexInfo = 10,
 T_ExprContext,
 T_ProjectionInfo,
 T_JunkFilter,
 T_ResultRelInfo,
 T_EState,
 T_TupleTableSlot,




 T_Plan = 100,
 T_Result,
 T_ModifyTable,
 T_Append,
 T_MergeAppend,
 T_RecursiveUnion,
 T_BitmapAnd,
 T_BitmapOr,
 T_Scan,
 T_SeqScan,
 T_IndexScan,
 T_IndexOnlyScan,
 T_BitmapIndexScan,
 T_BitmapHeapScan,
 T_TidScan,
 T_SubqueryScan,
 T_FunctionScan,
 T_ValuesScan,
 T_CteScan,
 T_WorkTableScan,
 T_ForeignScan,
 T_Join,
 T_NestLoop,
 T_MergeJoin,
 T_HashJoin,
 T_Material,
 T_Sort,
 T_Group,
 T_Agg,
 T_WindowAgg,
 T_Unique,
 T_Hash,
 T_SetOp,
 T_LockRows,
 T_Limit,

 T_NestLoopParam,
 T_PlanRowMark,
 T_PlanInvalItem,






 T_PlanState = 200,
 T_ResultState,
 T_ModifyTableState,
 T_AppendState,
 T_MergeAppendState,
 T_RecursiveUnionState,
 T_BitmapAndState,
 T_BitmapOrState,
 T_ScanState,
 T_SeqScanState,
 T_IndexScanState,
 T_IndexOnlyScanState,
 T_BitmapIndexScanState,
 T_BitmapHeapScanState,
 T_TidScanState,
 T_SubqueryScanState,
 T_FunctionScanState,
 T_ValuesScanState,
 T_CteScanState,
 T_WorkTableScanState,
 T_ForeignScanState,
 T_JoinState,
 T_NestLoopState,
 T_MergeJoinState,
 T_HashJoinState,
 T_MaterialState,
 T_SortState,
 T_GroupState,
 T_AggState,
 T_WindowAggState,
 T_UniqueState,
 T_HashState,
 T_SetOpState,
 T_LockRowsState,
 T_LimitState,




 T_Alias = 300,
 T_RangeVar,
 T_Expr,
 T_Var,
 T_Const,
 T_Param,
 T_Aggref,
 T_WindowFunc,
 T_ArrayRef,
 T_FuncExpr,
 T_NamedArgExpr,
 T_OpExpr,
 T_DistinctExpr,
 T_NullIfExpr,
 T_ScalarArrayOpExpr,
 T_BoolExpr,
 T_SubLink,
 T_SubPlan,
 T_AlternativeSubPlan,
 T_FieldSelect,
 T_FieldStore,
 T_RelabelType,
 T_CoerceViaIO,
 T_ArrayCoerceExpr,
 T_ConvertRowtypeExpr,
 T_CollateExpr,
 T_CaseExpr,
 T_CaseWhen,
 T_CaseTestExpr,
 T_ArrayExpr,
 T_RowExpr,
 T_RowCompareExpr,
 T_CoalesceExpr,
 T_MinMaxExpr,
 T_XmlExpr,
 T_NullTest,
 T_BooleanTest,
 T_CoerceToDomain,
 T_CoerceToDomainValue,
 T_SetToDefault,
 T_CurrentOfExpr,
 T_TargetEntry,
 T_RangeTblRef,
 T_JoinExpr,
 T_FromExpr,
 T_IntoClause,







 T_ExprState = 400,
 T_GenericExprState,
 T_AggrefExprState,
 T_WindowFuncExprState,
 T_ArrayRefExprState,
 T_FuncExprState,
 T_ScalarArrayOpExprState,
 T_BoolExprState,
 T_SubPlanState,
 T_AlternativeSubPlanState,
 T_FieldSelectState,
 T_FieldStoreState,
 T_CoerceViaIOState,
 T_ArrayCoerceExprState,
 T_ConvertRowtypeExprState,
 T_CaseExprState,
 T_CaseWhenState,
 T_ArrayExprState,
 T_RowExprState,
 T_RowCompareExprState,
 T_CoalesceExprState,
 T_MinMaxExprState,
 T_XmlExprState,
 T_NullTestState,
 T_CoerceToDomainState,
 T_DomainConstraintState,
 T_WholeRowVarExprState,




 T_PlannerInfo = 500,
 T_PlannerGlobal,
 T_RelOptInfo,
 T_IndexOptInfo,
 T_ParamPathInfo,
 T_Path,
 T_IndexPath,
 T_BitmapHeapPath,
 T_BitmapAndPath,
 T_BitmapOrPath,
 T_NestPath,
 T_MergePath,
 T_HashPath,
 T_TidPath,
 T_ForeignPath,
 T_AppendPath,
 T_MergeAppendPath,
 T_ResultPath,
 T_MaterialPath,
 T_UniquePath,
 T_EquivalenceClass,
 T_EquivalenceMember,
 T_PathKey,
 T_RestrictInfo,
 T_PlaceHolderVar,
 T_SpecialJoinInfo,
 T_AppendRelInfo,
 T_PlaceHolderInfo,
 T_MinMaxAggInfo,
 T_PlannerParamItem,




 T_MemoryContext = 600,
 T_AllocSetContext,




 T_Value = 650,
 T_Integer,
 T_Float,
 T_String,
 T_BitString,
 T_Null,




 T_List,
 T_IntList,
 T_OidList,




 T_Query = 700,
 T_PlannedStmt,
 T_InsertStmt,
 T_DeleteStmt,
 T_UpdateStmt,
 T_SelectStmt,
 T_AlterTableStmt,
 T_AlterTableCmd,
 T_AlterDomainStmt,
 T_SetOperationStmt,
 T_GrantStmt,
 T_GrantRoleStmt,
 T_AlterDefaultPrivilegesStmt,
 T_ClosePortalStmt,
 T_ClusterStmt,
 T_CopyStmt,
 T_CreateStmt,
 T_DefineStmt,
 T_DropStmt,
 T_TruncateStmt,
 T_CommentStmt,
 T_FetchStmt,
 T_IndexStmt,
 T_CreateFunctionStmt,
 T_AlterFunctionStmt,
 T_DoStmt,
 T_RenameStmt,
 T_RuleStmt,
 T_NotifyStmt,
 T_ListenStmt,
 T_UnlistenStmt,
 T_TransactionStmt,
 T_ViewStmt,
 T_LoadStmt,
 T_CreateDomainStmt,
 T_CreatedbStmt,
 T_DropdbStmt,
 T_VacuumStmt,
 T_ExplainStmt,
 T_CreateTableAsStmt,
 T_CreateSeqStmt,
 T_AlterSeqStmt,
 T_VariableSetStmt,
 T_VariableShowStmt,
 T_DiscardStmt,
 T_CreateTrigStmt,
 T_CreatePLangStmt,
 T_CreateRoleStmt,
 T_AlterRoleStmt,
 T_DropRoleStmt,
 T_LockStmt,
 T_ConstraintsSetStmt,
 T_ReindexStmt,
 T_CheckPointStmt,
 T_CreateSchemaStmt,
 T_AlterDatabaseStmt,
 T_AlterDatabaseSetStmt,
 T_AlterRoleSetStmt,
 T_CreateConversionStmt,
 T_CreateCastStmt,
 T_CreateOpClassStmt,
 T_CreateOpFamilyStmt,
 T_AlterOpFamilyStmt,
 T_PrepareStmt,
 T_ExecuteStmt,
 T_DeallocateStmt,
 T_DeclareCursorStmt,
 T_CreateTableSpaceStmt,
 T_DropTableSpaceStmt,
 T_AlterObjectSchemaStmt,
 T_AlterOwnerStmt,
 T_DropOwnedStmt,
 T_ReassignOwnedStmt,
 T_CompositeTypeStmt,
 T_CreateEnumStmt,
 T_CreateRangeStmt,
 T_AlterEnumStmt,
 T_AlterTSDictionaryStmt,
 T_AlterTSConfigurationStmt,
 T_CreateFdwStmt,
 T_AlterFdwStmt,
 T_CreateForeignServerStmt,
 T_AlterForeignServerStmt,
 T_CreateUserMappingStmt,
 T_AlterUserMappingStmt,
 T_DropUserMappingStmt,
 T_AlterTableSpaceOptionsStmt,
 T_SecLabelStmt,
 T_CreateForeignTableStmt,
 T_CreateExtensionStmt,
 T_AlterExtensionStmt,
 T_AlterExtensionContentsStmt,




 T_A_Expr = 900,
 T_ColumnRef,
 T_ParamRef,
 T_A_Const,
 T_FuncCall,
 T_A_Star,
 T_A_Indices,
 T_A_Indirection,
 T_A_ArrayExpr,
 T_ResTarget,
 T_TypeCast,
 T_CollateClause,
 T_SortBy,
 T_WindowDef,
 T_RangeSubselect,
 T_RangeFunction,
 T_TypeName,
 T_ColumnDef,
 T_IndexElem,
 T_Constraint,
 T_DefElem,
 T_RangeTblEntry,
 T_SortGroupClause,
 T_WindowClause,
 T_PrivGrantee,
 T_FuncWithArgs,
 T_AccessPriv,
 T_CreateOpClassItem,
 T_TableLikeClause,
 T_FunctionParameter,
 T_LockingClause,
 T_RowMarkClause,
 T_XmlSerialize,
 T_WithClause,
 T_CommonTableExpr,




 T_IdentifySystemCmd,
 T_BaseBackupCmd,
 T_StartReplicationCmd,
# 416 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
 T_TriggerData = 950,
 T_ReturnSetInfo,
 T_WindowObjectData,
 T_TIDBitmap,
 T_InlineCodeBlock,
 T_FdwRoutine
} NodeTag;







typedef struct Node
{
 NodeTag type;
} Node;
# 491 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
extern char *nodeToString(const void *obj);




extern void *stringToNode(char *str);




extern void *copyObject(const void *obj);




extern bool equal(const void *a, const void *b);
# 517 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef double Selectivity;
typedef double Cost;
# 527 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum CmdType
{
 CMD_UNKNOWN,
 CMD_SELECT,
 CMD_UPDATE,
 CMD_INSERT,
 CMD_DELETE,
 CMD_UTILITY,

 CMD_NOTHING

} CmdType;
# 551 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum JoinType
{




 JOIN_INNER,
 JOIN_LEFT,
 JOIN_FULL,
 JOIN_RIGHT,
# 571 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
 JOIN_SEMI,
 JOIN_ANTI,





 JOIN_UNIQUE_OUTER,
 JOIN_UNIQUE_INNER




} JoinType;
# 41 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 2


typedef struct ListCell ListCell;

typedef struct List
{
 NodeTag type;
 int length;
 ListCell *head;
 ListCell *tail;
} List;

struct ListCell
{
 union
 {
  void *ptr_value;
  int int_value;
  Oid oid_value;
 } data;
 ListCell *next;
};
# 98 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
extern ListCell *list_head(const List *l);
extern ListCell *list_tail(List *l);
extern int list_length(const List *l);
# 194 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
extern List *lappend(List *list, void *datum);
extern List *lappend_int(List *list, int datum);
extern List *lappend_oid(List *list, Oid datum);

extern ListCell *lappend_cell(List *list, ListCell *prev, void *datum);
extern ListCell *lappend_cell_int(List *list, ListCell *prev, int datum);
extern ListCell *lappend_cell_oid(List *list, ListCell *prev, Oid datum);

extern List *lcons(void *datum, List *list);
extern List *lcons_int(int datum, List *list);
extern List *lcons_oid(Oid datum, List *list);

extern List *list_concat(List *list1, List *list2);
extern List *list_truncate(List *list, int new_size);

extern void *list_nth(const List *list, int n);
extern int list_nth_int(const List *list, int n);
extern Oid list_nth_oid(const List *list, int n);

extern bool list_member(const List *list, const void *datum);
extern bool list_member_ptr(const List *list, const void *datum);
extern bool list_member_int(const List *list, int datum);
extern bool list_member_oid(const List *list, Oid datum);

extern List *list_delete(List *list, void *datum);
extern List *list_delete_ptr(List *list, void *datum);
extern List *list_delete_int(List *list, int datum);
extern List *list_delete_oid(List *list, Oid datum);
extern List *list_delete_first(List *list);
extern List *list_delete_cell(List *list, ListCell *cell, ListCell *prev);

extern List *list_union(const List *list1, const List *list2);
extern List *list_union_ptr(const List *list1, const List *list2);
extern List *list_union_int(const List *list1, const List *list2);
extern List *list_union_oid(const List *list1, const List *list2);

extern List *list_intersection(const List *list1, const List *list2);



extern List *list_difference(const List *list1, const List *list2);
extern List *list_difference_ptr(const List *list1, const List *list2);
extern List *list_difference_int(const List *list1, const List *list2);
extern List *list_difference_oid(const List *list1, const List *list2);

extern List *list_append_unique(List *list, void *datum);
extern List *list_append_unique_ptr(List *list, void *datum);
extern List *list_append_unique_int(List *list, int datum);
extern List *list_append_unique_oid(List *list, Oid datum);

extern List *list_concat_unique(List *list1, List *list2);
extern List *list_concat_unique_ptr(List *list1, List *list2);
extern List *list_concat_unique_int(List *list1, List *list2);
extern List *list_concat_unique_oid(List *list1, List *list2);

extern void list_free(List *list);
extern void list_free_deep(List *list);

extern List *list_copy(const List *list);
extern List *list_copy_tail(const List *list, int nskip);
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 2
# 38 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Alias
{
 NodeTag type;
 char *aliasname;
 List *colnames;
} Alias;

typedef enum InhOption
{
 INH_NO,
 INH_YES,
 INH_DEFAULT
} InhOption;


typedef enum OnCommitAction
{
 ONCOMMIT_NOOP,
 ONCOMMIT_PRESERVE_ROWS,
 ONCOMMIT_DELETE_ROWS,
 ONCOMMIT_DROP
} OnCommitAction;
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RangeVar
{
 NodeTag type;
 char *catalogname;
 char *schemaname;
 char *relname;
 InhOption inhOpt;

 char relpersistence;
 Alias *alias;
 int location;
} RangeVar;




typedef struct IntoClause
{
 NodeTag type;

 RangeVar *rel;
 List *colNames;
 List *options;
 OnCommitAction onCommit;
 char *tableSpaceName;
 bool skipData;
} IntoClause;
# 111 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Expr
{
 NodeTag type;
} Expr;
# 138 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Var
{
 Expr xpr;
 Index varno;

 AttrNumber varattno;

 Oid vartype;
 int32 vartypmod;
 Oid varcollid;
 Index varlevelsup;


 Index varnoold;
 AttrNumber varoattno;
 int location;
} Var;




typedef struct Const
{
 Expr xpr;
 Oid consttype;
 int32 consttypmod;
 Oid constcollid;
 int constlen;
 Datum constvalue;
 bool constisnull;

 bool constbyval;



 int location;
} Const;
# 201 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum ParamKind
{
 PARAM_EXTERN,
 PARAM_EXEC,
 PARAM_SUBLINK
} ParamKind;

typedef struct Param
{
 Expr xpr;
 ParamKind paramkind;
 int paramid;
 Oid paramtype;
 int32 paramtypmod;
 Oid paramcollid;
 int location;
} Param;
# 234 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Aggref
{
 Expr xpr;
 Oid aggfnoid;
 Oid aggtype;
 Oid aggcollid;
 Oid inputcollid;
 List *args;
 List *aggorder;
 List *aggdistinct;
 bool aggstar;
 Index agglevelsup;
 int location;
} Aggref;




typedef struct WindowFunc
{
 Expr xpr;
 Oid winfnoid;
 Oid wintype;
 Oid wincollid;
 Oid inputcollid;
 List *args;
 Index winref;
 bool winstar;
 bool winagg;
 int location;
} WindowFunc;
# 288 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ArrayRef
{
 Expr xpr;
 Oid refarraytype;
 Oid refelemtype;
 int32 reftypmod;
 Oid refcollid;
 List *refupperindexpr;

 List *reflowerindexpr;

 Expr *refexpr;

 Expr *refassgnexpr;

} ArrayRef;







typedef enum CoercionContext
{
 COERCION_IMPLICIT,
 COERCION_ASSIGNMENT,
 COERCION_EXPLICIT
} CoercionContext;
# 327 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum CoercionForm
{
 COERCE_EXPLICIT_CALL,
 COERCE_EXPLICIT_CAST,
 COERCE_IMPLICIT_CAST,
 COERCE_DONTCARE
} CoercionForm;




typedef struct FuncExpr
{
 Expr xpr;
 Oid funcid;
 Oid funcresulttype;
 bool funcretset;
 CoercionForm funcformat;
 Oid funccollid;
 Oid inputcollid;
 List *args;
 int location;
} FuncExpr;
# 365 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct NamedArgExpr
{
 Expr xpr;
 Expr *arg;
 char *name;
 int argnumber;
 int location;
} NamedArgExpr;
# 383 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct OpExpr
{
 Expr xpr;
 Oid opno;
 Oid opfuncid;
 Oid opresulttype;
 bool opretset;
 Oid opcollid;
 Oid inputcollid;
 List *args;
 int location;
} OpExpr;
# 406 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef OpExpr DistinctExpr;







typedef OpExpr NullIfExpr;
# 426 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ScalarArrayOpExpr
{
 Expr xpr;
 Oid opno;
 Oid opfuncid;
 bool useOr;
 Oid inputcollid;
 List *args;
 int location;
} ScalarArrayOpExpr;
# 448 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum BoolExprType
{
 AND_EXPR, OR_EXPR, NOT_EXPR
} BoolExprType;

typedef struct BoolExpr
{
 Expr xpr;
 BoolExprType boolop;
 List *args;
 int location;
} BoolExpr;
# 504 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum SubLinkType
{
 EXISTS_SUBLINK,
 ALL_SUBLINK,
 ANY_SUBLINK,
 ROWCOMPARE_SUBLINK,
 EXPR_SUBLINK,
 ARRAY_SUBLINK,
 CTE_SUBLINK
} SubLinkType;


typedef struct SubLink
{
 Expr xpr;
 SubLinkType subLinkType;
 Node *testexpr;
 List *operName;
 Node *subselect;
 int location;
} SubLink;
# 564 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct SubPlan
{
 Expr xpr;

 SubLinkType subLinkType;

 Node *testexpr;
 List *paramIds;

 int plan_id;

 char *plan_name;

 Oid firstColType;
 int32 firstColTypmod;
 Oid firstColCollation;


 bool useHashTable;

 bool unknownEqFalse;




 List *setParam;

 List *parParam;
 List *args;

 Cost startup_cost;
 Cost per_call_cost;
} SubPlan;
# 606 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct AlternativeSubPlan
{
 Expr xpr;
 List *subplans;
} AlternativeSubPlan;
# 621 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct FieldSelect
{
 Expr xpr;
 Expr *arg;
 AttrNumber fieldnum;
 Oid resulttype;

 int32 resulttypmod;
 Oid resultcollid;
} FieldSelect;
# 647 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct FieldStore
{
 Expr xpr;
 Expr *arg;
 List *newvals;
 List *fieldnums;
 Oid resulttype;

} FieldStore;
# 670 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RelabelType
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;
 int32 resulttypmod;
 Oid resultcollid;
 CoercionForm relabelformat;
 int location;
} RelabelType;
# 690 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CoerceViaIO
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;

 Oid resultcollid;
 CoercionForm coerceformat;
 int location;
} CoerceViaIO;
# 713 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ArrayCoerceExpr
{
 Expr xpr;
 Expr *arg;
 Oid elemfuncid;
 Oid resulttype;
 int32 resulttypmod;
 Oid resultcollid;
 bool isExplicit;
 CoercionForm coerceformat;
 int location;
} ArrayCoerceExpr;
# 738 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ConvertRowtypeExpr
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;

 CoercionForm convertformat;
 int location;
} ConvertRowtypeExpr;
# 755 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CollateExpr
{
 Expr xpr;
 Expr *arg;
 Oid collOid;
 int location;
} CollateExpr;
# 785 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CaseExpr
{
 Expr xpr;
 Oid casetype;
 Oid casecollid;
 Expr *arg;
 List *args;
 Expr *defresult;
 int location;
} CaseExpr;




typedef struct CaseWhen
{
 Expr xpr;
 Expr *expr;
 Expr *result;
 int location;
} CaseWhen;
# 815 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CaseTestExpr
{
 Expr xpr;
 Oid typeId;
 int32 typeMod;
 Oid collation;
} CaseTestExpr;
# 831 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ArrayExpr
{
 Expr xpr;
 Oid array_typeid;
 Oid array_collid;
 Oid element_typeid;
 List *elements;
 bool multidims;
 int location;
} ArrayExpr;
# 865 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RowExpr
{
 Expr xpr;
 List *args;
 Oid row_typeid;
# 880 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
 CoercionForm row_format;
 List *colnames;
 int location;
} RowExpr;
# 899 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum RowCompareType
{

 ROWCOMPARE_LT = 1,
 ROWCOMPARE_LE = 2,
 ROWCOMPARE_EQ = 3,
 ROWCOMPARE_GE = 4,
 ROWCOMPARE_GT = 5,
 ROWCOMPARE_NE = 6
} RowCompareType;

typedef struct RowCompareExpr
{
 Expr xpr;
 RowCompareType rctype;
 List *opnos;
 List *opfamilies;
 List *inputcollids;
 List *largs;
 List *rargs;
} RowCompareExpr;




typedef struct CoalesceExpr
{
 Expr xpr;
 Oid coalescetype;
 Oid coalescecollid;
 List *args;
 int location;
} CoalesceExpr;




typedef enum MinMaxOp
{
 IS_GREATEST,
 IS_LEAST
} MinMaxOp;

typedef struct MinMaxExpr
{
 Expr xpr;
 Oid minmaxtype;
 Oid minmaxcollid;
 Oid inputcollid;
 MinMaxOp op;
 List *args;
 int location;
} MinMaxExpr;
# 965 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum XmlExprOp
{
 IS_XMLCONCAT,
 IS_XMLELEMENT,
 IS_XMLFOREST,
 IS_XMLPARSE,
 IS_XMLPI,
 IS_XMLROOT,
 IS_XMLSERIALIZE,
 IS_DOCUMENT
} XmlExprOp;

typedef enum
{
 XMLOPTION_DOCUMENT,
 XMLOPTION_CONTENT
} XmlOptionType;

typedef struct XmlExpr
{
 Expr xpr;
 XmlExprOp op;
 char *name;
 List *named_args;
 List *arg_names;
 List *args;
 XmlOptionType xmloption;
 Oid type;
 int32 typmod;
 int location;
} XmlExpr;
# 1008 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum NullTestType
{
 IS_NULL, IS_NOT_NULL
} NullTestType;

typedef struct NullTest
{
 Expr xpr;
 Expr *arg;
 NullTestType nulltesttype;
 bool argisrow;
} NullTest;
# 1030 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum BoolTestType
{
 IS_TRUE, IS_NOT_TRUE, IS_FALSE, IS_NOT_FALSE, IS_UNKNOWN, IS_NOT_UNKNOWN
} BoolTestType;

typedef struct BooleanTest
{
 Expr xpr;
 Expr *arg;
 BoolTestType booltesttype;
} BooleanTest;
# 1051 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CoerceToDomain
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;
 int32 resulttypmod;
 Oid resultcollid;
 CoercionForm coercionformat;
 int location;
} CoerceToDomain;
# 1071 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CoerceToDomainValue
{
 Expr xpr;
 Oid typeId;
 int32 typeMod;
 Oid collation;
 int location;
} CoerceToDomainValue;
# 1087 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct SetToDefault
{
 Expr xpr;
 Oid typeId;
 int32 typeMod;
 Oid collation;
 int location;
} SetToDefault;
# 1108 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CurrentOfExpr
{
 Expr xpr;
 Index cvarno;
 char *cursor_name;
 int cursor_param;
} CurrentOfExpr;
# 1170 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct TargetEntry
{
 Expr xpr;
 Expr *expr;
 AttrNumber resno;
 char *resname;
 Index ressortgroupref;

 Oid resorigtbl;
 AttrNumber resorigcol;
 bool resjunk;

} TargetEntry;
# 1222 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RangeTblRef
{
 NodeTag type;
 int rtindex;
} RangeTblRef;
# 1251 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct JoinExpr
{
 NodeTag type;
 JoinType jointype;
 bool isNatural;
 Node *larg;
 Node *rarg;
 List *usingClause;
 Node *quals;
 Alias *alias;
 int rtindex;
} JoinExpr;
# 1273 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct FromExpr
{
 NodeTag type;
 List *fromlist;
 Node *quals;
} FromExpr;
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/value.h" 1
# 42 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/value.h"
typedef struct Value
{
 NodeTag type;
 union ValUnion
 {
  long ival;
  char *str;
 } val;
} Value;





extern Value *makeInteger(long i);
extern Value *makeFloat(char *numericStr);
extern Value *makeString(char *str);
extern Value *makeBitString(char *str);
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 2


typedef enum QuerySource
{
 QSRC_ORIGINAL,
 QSRC_PARSER,
 QSRC_INSTEAD_RULE,
 QSRC_QUAL_INSTEAD_RULE,
 QSRC_NON_INSTEAD_RULE
} QuerySource;


typedef enum SortByDir
{
 SORTBY_DEFAULT,
 SORTBY_ASC,
 SORTBY_DESC,
 SORTBY_USING
} SortByDir;

typedef enum SortByNulls
{
 SORTBY_NULLS_DEFAULT,
 SORTBY_NULLS_FIRST,
 SORTBY_NULLS_LAST
} SortByNulls;
# 60 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef uint32 AclMode;
# 98 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct Query
{
 NodeTag type;

 CmdType commandType;

 QuerySource querySource;

 uint32 queryId;

 bool canSetTag;

 Node *utilityStmt;


 int resultRelation;


 bool hasAggs;
 bool hasWindowFuncs;
 bool hasSubLinks;
 bool hasDistinctOn;
 bool hasRecursive;
 bool hasModifyingCTE;
 bool hasForUpdate;

 List *cteList;

 List *rtable;
 FromExpr *jointree;

 List *targetList;

 List *returningList;

 List *groupClause;

 Node *havingQual;

 List *windowClause;

 List *distinctClause;

 List *sortClause;

 Node *limitOffset;
 Node *limitCount;

 List *rowMarks;

 Node *setOperations;


 List *constraintDeps;

} Query;
# 177 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct TypeName
{
 NodeTag type;
 List *names;
 Oid typeOid;
 bool setof;
 bool pct_type;
 List *typmods;
 int32 typemod;
 List *arrayBounds;
 int location;
} TypeName;
# 203 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ColumnRef
{
 NodeTag type;
 List *fields;
 int location;
} ColumnRef;




typedef struct ParamRef
{
 NodeTag type;
 int number;
 int location;
} ParamRef;




typedef enum A_Expr_Kind
{
 AEXPR_OP,
 AEXPR_AND,
 AEXPR_OR,
 AEXPR_NOT,
 AEXPR_OP_ANY,
 AEXPR_OP_ALL,
 AEXPR_DISTINCT,
 AEXPR_NULLIF,
 AEXPR_OF,
 AEXPR_IN
} A_Expr_Kind;

typedef struct A_Expr
{
 NodeTag type;
 A_Expr_Kind kind;
 List *name;
 Node *lexpr;
 Node *rexpr;
 int location;
} A_Expr;




typedef struct A_Const
{
 NodeTag type;
 Value val;
 int location;
} A_Const;




typedef struct TypeCast
{
 NodeTag type;
 Node *arg;
 TypeName *typeName;
 int location;
} TypeCast;




typedef struct CollateClause
{
 NodeTag type;
 Node *arg;
 List *collname;
 int location;
} CollateClause;
# 289 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct FuncCall
{
 NodeTag type;
 List *funcname;
 List *args;
 List *agg_order;
 bool agg_star;
 bool agg_distinct;
 bool func_variadic;
 struct WindowDef *over;
 int location;
} FuncCall;







typedef struct A_Star
{
 NodeTag type;
} A_Star;




typedef struct A_Indices
{
 NodeTag type;
 Node *lidx;
 Node *uidx;
} A_Indices;
# 338 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct A_Indirection
{
 NodeTag type;
 Node *arg;
 List *indirection;
} A_Indirection;




typedef struct A_ArrayExpr
{
 NodeTag type;
 List *elements;
 int location;
} A_ArrayExpr;
# 373 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ResTarget
{
 NodeTag type;
 char *name;
 List *indirection;
 Node *val;
 int location;
} ResTarget;




typedef struct SortBy
{
 NodeTag type;
 Node *node;
 SortByDir sortby_dir;
 SortByNulls sortby_nulls;
 List *useOp;
 int location;
} SortBy;
# 403 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct WindowDef
{
 NodeTag type;
 char *name;
 char *refname;
 List *partitionClause;
 List *orderClause;
 int frameOptions;
 Node *startOffset;
 Node *endOffset;
 int location;
} WindowDef;
# 451 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct RangeSubselect
{
 NodeTag type;
 Node *subquery;
 Alias *alias;
} RangeSubselect;




typedef struct RangeFunction
{
 NodeTag type;
 Node *funccallnode;
 Alias *alias;
 List *coldeflist;

} RangeFunction;
# 488 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ColumnDef
{
 NodeTag type;
 char *colname;
 TypeName *typeName;
 int inhcount;
 bool is_local;
 bool is_not_null;
 bool is_from_type;
 char storage;
 Node *raw_default;
 Node *cooked_default;
 CollateClause *collClause;
 Oid collOid;
 List *constraints;
 List *fdwoptions;
} ColumnDef;




typedef struct TableLikeClause
{
 NodeTag type;
 RangeVar *relation;
 bits32 options;
} TableLikeClause;

typedef enum TableLikeOption
{
 CREATE_TABLE_LIKE_DEFAULTS = 1 << 0,
 CREATE_TABLE_LIKE_CONSTRAINTS = 1 << 1,
 CREATE_TABLE_LIKE_INDEXES = 1 << 2,
 CREATE_TABLE_LIKE_STORAGE = 1 << 3,
 CREATE_TABLE_LIKE_COMMENTS = 1 << 4,
 CREATE_TABLE_LIKE_ALL = 0x7FFFFFFF
} TableLikeOption;
# 533 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct IndexElem
{
 NodeTag type;
 char *name;
 Node *expr;
 char *indexcolname;
 List *collation;
 List *opclass;
 SortByDir ordering;
 SortByNulls nulls_ordering;
} IndexElem;
# 555 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum DefElemAction
{
 DEFELEM_UNSPEC,
 DEFELEM_SET,
 DEFELEM_ADD,
 DEFELEM_DROP
} DefElemAction;

typedef struct DefElem
{
 NodeTag type;
 char *defnamespace;
 char *defname;
 Node *arg;
 DefElemAction defaction;
} DefElem;
# 580 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct LockingClause
{
 NodeTag type;
 List *lockedRels;
 bool forUpdate;
 bool noWait;
} LockingClause;




typedef struct XmlSerialize
{
 NodeTag type;
 XmlOptionType xmloption;
 Node *expr;
 TypeName *typeName;
 int location;
} XmlSerialize;
# 677 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum RTEKind
{
 RTE_RELATION,
 RTE_SUBQUERY,
 RTE_JOIN,
 RTE_FUNCTION,
 RTE_VALUES,
 RTE_CTE
} RTEKind;

typedef struct RangeTblEntry
{
 NodeTag type;

 RTEKind rtekind;
# 702 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 Oid relid;
 char relkind;




 Query *subquery;
 bool security_barrier;
# 722 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 JoinType jointype;
 List *joinaliasvars;
# 733 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 Node *funcexpr;
 List *funccoltypes;
 List *funccoltypmods;
 List *funccolcollations;




 List *values_lists;
 List *values_collations;




 char *ctename;
 Index ctelevelsup;
 bool self_reference;
 List *ctecoltypes;
 List *ctecoltypmods;
 List *ctecolcollations;




 Alias *alias;
 Alias *eref;
 bool inh;
 bool inFromCl;
 AclMode requiredPerms;
 Oid checkAsUser;
 Bitmapset *selectedCols;
 Bitmapset *modifiedCols;
} RangeTblEntry;
# 825 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct SortGroupClause
{
 NodeTag type;
 Index tleSortGroupRef;
 Oid eqop;
 Oid sortop;
 bool nulls_first;
 bool hashable;
} SortGroupClause;
# 849 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct WindowClause
{
 NodeTag type;
 char *name;
 char *refname;
 List *partitionClause;
 List *orderClause;
 int frameOptions;
 Node *startOffset;
 Node *endOffset;
 Index winref;
 bool copiedOrder;
} WindowClause;
# 875 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct RowMarkClause
{
 NodeTag type;
 Index rti;
 bool forUpdate;
 bool noWait;
 bool pushedDown;
} RowMarkClause;
# 891 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct WithClause
{
 NodeTag type;
 List *ctes;
 bool recursive;
 int location;
} WithClause;







typedef struct CommonTableExpr
{
 NodeTag type;
 char *ctename;
 List *aliascolnames;

 Node *ctequery;
 int location;

 bool cterecursive;
 int cterefcount;

 List *ctecolnames;
 List *ctecoltypes;
 List *ctecoltypmods;
 List *ctecolcollations;
} CommonTableExpr;
# 943 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct InsertStmt
{
 NodeTag type;
 RangeVar *relation;
 List *cols;
 Node *selectStmt;
 List *returningList;
 WithClause *withClause;
} InsertStmt;





typedef struct DeleteStmt
{
 NodeTag type;
 RangeVar *relation;
 List *usingClause;
 Node *whereClause;
 List *returningList;
 WithClause *withClause;
} DeleteStmt;





typedef struct UpdateStmt
{
 NodeTag type;
 RangeVar *relation;
 List *targetList;
 Node *whereClause;
 List *fromClause;
 List *returningList;
 WithClause *withClause;
} UpdateStmt;
# 995 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum SetOperation
{
 SETOP_NONE = 0,
 SETOP_UNION,
 SETOP_INTERSECT,
 SETOP_EXCEPT
} SetOperation;

typedef struct SelectStmt
{
 NodeTag type;




 List *distinctClause;

 IntoClause *intoClause;
 List *targetList;
 List *fromClause;
 Node *whereClause;
 List *groupClause;
 Node *havingClause;
 List *windowClause;
 WithClause *withClause;
# 1029 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 List *valuesLists;





 List *sortClause;
 Node *limitOffset;
 Node *limitCount;
 List *lockingClause;




 SetOperation op;
 bool all;
 struct SelectStmt *larg;
 struct SelectStmt *rarg;

} SelectStmt;
# 1070 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct SetOperationStmt
{
 NodeTag type;
 SetOperation op;
 bool all;
 Node *larg;
 Node *rarg;



 List *colTypes;
 List *colTypmods;
 List *colCollations;
 List *groupClauses;

} SetOperationStmt;
# 1105 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum ObjectType
{
 OBJECT_AGGREGATE,
 OBJECT_ATTRIBUTE,
 OBJECT_CAST,
 OBJECT_COLUMN,
 OBJECT_CONSTRAINT,
 OBJECT_COLLATION,
 OBJECT_CONVERSION,
 OBJECT_DATABASE,
 OBJECT_DOMAIN,
 OBJECT_EXTENSION,
 OBJECT_FDW,
 OBJECT_FOREIGN_SERVER,
 OBJECT_FOREIGN_TABLE,
 OBJECT_FUNCTION,
 OBJECT_INDEX,
 OBJECT_LANGUAGE,
 OBJECT_LARGEOBJECT,
 OBJECT_OPCLASS,
 OBJECT_OPERATOR,
 OBJECT_OPFAMILY,
 OBJECT_ROLE,
 OBJECT_RULE,
 OBJECT_SCHEMA,
 OBJECT_SEQUENCE,
 OBJECT_TABLE,
 OBJECT_TABLESPACE,
 OBJECT_TRIGGER,
 OBJECT_TSCONFIGURATION,
 OBJECT_TSDICTIONARY,
 OBJECT_TSPARSER,
 OBJECT_TSTEMPLATE,
 OBJECT_TYPE,
 OBJECT_VIEW
} ObjectType;
# 1150 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CreateSchemaStmt
{
 NodeTag type;
 char *schemaname;
 char *authid;
 List *schemaElts;
} CreateSchemaStmt;

typedef enum DropBehavior
{
 DROP_RESTRICT,
 DROP_CASCADE
} DropBehavior;





typedef struct AlterTableStmt
{
 NodeTag type;
 RangeVar *relation;
 List *cmds;
 ObjectType relkind;
 bool missing_ok;
} AlterTableStmt;

typedef enum AlterTableType
{
 AT_AddColumn,
 AT_AddColumnRecurse,
 AT_AddColumnToView,
 AT_ColumnDefault,
 AT_DropNotNull,
 AT_SetNotNull,
 AT_SetStatistics,
 AT_SetOptions,
 AT_ResetOptions,
 AT_SetStorage,
 AT_DropColumn,
 AT_DropColumnRecurse,
 AT_AddIndex,
 AT_ReAddIndex,
 AT_AddConstraint,
 AT_AddConstraintRecurse,
 AT_ValidateConstraint,
 AT_ValidateConstraintRecurse,
 AT_ProcessedConstraint,

 AT_AddIndexConstraint,
 AT_DropConstraint,
 AT_DropConstraintRecurse,
 AT_AlterColumnType,
 AT_AlterColumnGenericOptions,
 AT_ChangeOwner,
 AT_ClusterOn,
 AT_DropCluster,
 AT_AddOids,
 AT_AddOidsRecurse,
 AT_DropOids,
 AT_SetTableSpace,
 AT_SetRelOptions,
 AT_ResetRelOptions,
 AT_ReplaceRelOptions,
 AT_EnableTrig,
 AT_EnableAlwaysTrig,
 AT_EnableReplicaTrig,
 AT_DisableTrig,
 AT_EnableTrigAll,
 AT_DisableTrigAll,
 AT_EnableTrigUser,
 AT_DisableTrigUser,
 AT_EnableRule,
 AT_EnableAlwaysRule,
 AT_EnableReplicaRule,
 AT_DisableRule,
 AT_AddInherit,
 AT_DropInherit,
 AT_AddOf,
 AT_DropOf,
 AT_GenericOptions,

 AT_ReAddConstraint
} AlterTableType;

typedef struct AlterTableCmd
{
 NodeTag type;
 AlterTableType subtype;
 char *name;

 Node *def;

 DropBehavior behavior;
 bool missing_ok;
} AlterTableCmd;
# 1255 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct AlterDomainStmt
{
 NodeTag type;
 char subtype;







 List *typeName;
 char *name;
 Node *def;
 DropBehavior behavior;
 bool missing_ok;
} AlterDomainStmt;






typedef enum GrantTargetType
{
 ACL_TARGET_OBJECT,
 ACL_TARGET_ALL_IN_SCHEMA,
 ACL_TARGET_DEFAULTS
} GrantTargetType;

typedef enum GrantObjectType
{
 ACL_OBJECT_COLUMN,
 ACL_OBJECT_RELATION,
 ACL_OBJECT_SEQUENCE,
 ACL_OBJECT_DATABASE,
 ACL_OBJECT_DOMAIN,
 ACL_OBJECT_FDW,
 ACL_OBJECT_FOREIGN_SERVER,
 ACL_OBJECT_FUNCTION,
 ACL_OBJECT_LANGUAGE,
 ACL_OBJECT_LARGEOBJECT,
 ACL_OBJECT_NAMESPACE,
 ACL_OBJECT_TABLESPACE,
 ACL_OBJECT_TYPE
} GrantObjectType;

typedef struct GrantStmt
{
 NodeTag type;
 bool is_grant;
 GrantTargetType targtype;
 GrantObjectType objtype;
 List *objects;

 List *privileges;

 List *grantees;
 bool grant_option;
 DropBehavior behavior;
} GrantStmt;

typedef struct PrivGrantee
{
 NodeTag type;
 char *rolname;
} PrivGrantee;






typedef struct FuncWithArgs
{
 NodeTag type;
 List *funcname;
 List *funcargs;
} FuncWithArgs;
# 1342 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct AccessPriv
{
 NodeTag type;
 char *priv_name;
 List *cols;
} AccessPriv;
# 1358 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct GrantRoleStmt
{
 NodeTag type;
 List *granted_roles;
 List *grantee_roles;
 bool is_grant;
 bool admin_opt;
 char *grantor;
 DropBehavior behavior;
} GrantRoleStmt;





typedef struct AlterDefaultPrivilegesStmt
{
 NodeTag type;
 List *options;
 GrantStmt *action;
} AlterDefaultPrivilegesStmt;
# 1388 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CopyStmt
{
 NodeTag type;
 RangeVar *relation;
 Node *query;
 List *attlist;

 bool is_from;
 char *filename;
 List *options;
} CopyStmt;
# 1407 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum
{
 VAR_SET_VALUE,
 VAR_SET_DEFAULT,
 VAR_SET_CURRENT,
 VAR_SET_MULTI,
 VAR_RESET,
 VAR_RESET_ALL
} VariableSetKind;

typedef struct VariableSetStmt
{
 NodeTag type;
 VariableSetKind kind;
 char *name;
 List *args;
 bool is_local;
} VariableSetStmt;





typedef struct VariableShowStmt
{
 NodeTag type;
 char *name;
} VariableShowStmt;
# 1447 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CreateStmt
{
 NodeTag type;
 RangeVar *relation;
 List *tableElts;
 List *inhRelations;

 TypeName *ofTypename;
 List *constraints;
 List *options;
 OnCommitAction oncommit;
 char *tablespacename;
 bool if_not_exists;
} CreateStmt;
# 1493 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum ConstrType
{
 CONSTR_NULL,
 CONSTR_NOTNULL,
 CONSTR_DEFAULT,
 CONSTR_CHECK,
 CONSTR_PRIMARY,
 CONSTR_UNIQUE,
 CONSTR_EXCLUSION,
 CONSTR_FOREIGN,
 CONSTR_ATTR_DEFERRABLE,
 CONSTR_ATTR_NOT_DEFERRABLE,
 CONSTR_ATTR_DEFERRED,
 CONSTR_ATTR_IMMEDIATE
} ConstrType;
# 1521 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct Constraint
{
 NodeTag type;
 ConstrType contype;


 char *conname;
 bool deferrable;
 bool initdeferred;
 int location;


 bool is_no_inherit;
 Node *raw_expr;
 char *cooked_expr;


 List *keys;


 List *exclusions;


 List *options;
 char *indexname;
 char *indexspace;

 char *access_method;
 Node *where_clause;


 RangeVar *pktable;
 List *fk_attrs;
 List *pk_attrs;
 char fk_matchtype;
 char fk_upd_action;
 char fk_del_action;
 List *old_conpfeqop;


 bool skip_validation;
 bool initially_valid;
} Constraint;






typedef struct CreateTableSpaceStmt
{
 NodeTag type;
 char *tablespacename;
 char *owner;
 char *location;
} CreateTableSpaceStmt;

typedef struct DropTableSpaceStmt
{
 NodeTag type;
 char *tablespacename;
 bool missing_ok;
} DropTableSpaceStmt;

typedef struct AlterTableSpaceOptionsStmt
{
 NodeTag type;
 char *tablespacename;
 List *options;
 bool isReset;
} AlterTableSpaceOptionsStmt;






typedef struct CreateExtensionStmt
{
 NodeTag type;
 char *extname;
 bool if_not_exists;
 List *options;
} CreateExtensionStmt;


typedef struct AlterExtensionStmt
{
 NodeTag type;
 char *extname;
 List *options;
} AlterExtensionStmt;

typedef struct AlterExtensionContentsStmt
{
 NodeTag type;
 char *extname;
 int action;
 ObjectType objtype;
 List *objname;
 List *objargs;
} AlterExtensionContentsStmt;






typedef struct CreateFdwStmt
{
 NodeTag type;
 char *fdwname;
 List *func_options;
 List *options;
} CreateFdwStmt;

typedef struct AlterFdwStmt
{
 NodeTag type;
 char *fdwname;
 List *func_options;
 List *options;
} AlterFdwStmt;






typedef struct CreateForeignServerStmt
{
 NodeTag type;
 char *servername;
 char *servertype;
 char *version;
 char *fdwname;
 List *options;
} CreateForeignServerStmt;

typedef struct AlterForeignServerStmt
{
 NodeTag type;
 char *servername;
 char *version;
 List *options;
 bool has_version;
} AlterForeignServerStmt;






typedef struct CreateForeignTableStmt
{
 CreateStmt base;
 char *servername;
 List *options;
} CreateForeignTableStmt;






typedef struct CreateUserMappingStmt
{
 NodeTag type;
 char *username;
 char *servername;
 List *options;
} CreateUserMappingStmt;

typedef struct AlterUserMappingStmt
{
 NodeTag type;
 char *username;
 char *servername;
 List *options;
} AlterUserMappingStmt;

typedef struct DropUserMappingStmt
{
 NodeTag type;
 char *username;
 char *servername;
 bool missing_ok;
} DropUserMappingStmt;





typedef struct CreateTrigStmt
{
 NodeTag type;
 char *trigname;
 RangeVar *relation;
 List *funcname;
 List *args;
 bool row;

 int16 timing;

 int16 events;
 List *columns;
 Node *whenClause;
 bool isconstraint;

 bool deferrable;
 bool initdeferred;
 RangeVar *constrrel;
} CreateTrigStmt;





typedef struct CreatePLangStmt
{
 NodeTag type;
 bool replace;
 char *plname;
 List *plhandler;
 List *plinline;
 List *plvalidator;
 bool pltrusted;
} CreatePLangStmt;
# 1759 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum RoleStmtType
{
 ROLESTMT_ROLE,
 ROLESTMT_USER,
 ROLESTMT_GROUP
} RoleStmtType;

typedef struct CreateRoleStmt
{
 NodeTag type;
 RoleStmtType stmt_type;
 char *role;
 List *options;
} CreateRoleStmt;

typedef struct AlterRoleStmt
{
 NodeTag type;
 char *role;
 List *options;
 int action;
} AlterRoleStmt;

typedef struct AlterRoleSetStmt
{
 NodeTag type;
 char *role;
 char *database;
 VariableSetStmt *setstmt;
} AlterRoleSetStmt;

typedef struct DropRoleStmt
{
 NodeTag type;
 List *roles;
 bool missing_ok;
} DropRoleStmt;






typedef struct CreateSeqStmt
{
 NodeTag type;
 RangeVar *sequence;
 List *options;
 Oid ownerId;
} CreateSeqStmt;

typedef struct AlterSeqStmt
{
 NodeTag type;
 RangeVar *sequence;
 List *options;
 bool missing_ok;
} AlterSeqStmt;





typedef struct DefineStmt
{
 NodeTag type;
 ObjectType kind;
 bool oldstyle;
 List *defnames;
 List *args;
 List *definition;
} DefineStmt;





typedef struct CreateDomainStmt
{
 NodeTag type;
 List *domainname;
 TypeName *typeName;
 CollateClause *collClause;
 List *constraints;
} CreateDomainStmt;





typedef struct CreateOpClassStmt
{
 NodeTag type;
 List *opclassname;
 List *opfamilyname;
 char *amname;
 TypeName *datatype;
 List *items;
 bool isDefault;
} CreateOpClassStmt;





typedef struct CreateOpClassItem
{
 NodeTag type;
 int itemtype;

 List *name;
 List *args;
 int number;
 List *order_family;
 List *class_args;

 TypeName *storedtype;
} CreateOpClassItem;





typedef struct CreateOpFamilyStmt
{
 NodeTag type;
 List *opfamilyname;
 char *amname;
} CreateOpFamilyStmt;





typedef struct AlterOpFamilyStmt
{
 NodeTag type;
 List *opfamilyname;
 char *amname;
 bool isDrop;
 List *items;
} AlterOpFamilyStmt;






typedef struct DropStmt
{
 NodeTag type;
 List *objects;
 List *arguments;
 ObjectType removeType;
 DropBehavior behavior;
 bool missing_ok;
 bool concurrent;
} DropStmt;





typedef struct TruncateStmt
{
 NodeTag type;
 List *relations;
 bool restart_seqs;
 DropBehavior behavior;
} TruncateStmt;





typedef struct CommentStmt
{
 NodeTag type;
 ObjectType objtype;
 List *objname;
 List *objargs;
 char *comment;
} CommentStmt;





typedef struct SecLabelStmt
{
 NodeTag type;
 ObjectType objtype;
 List *objname;
 List *objargs;
 char *provider;
 char *label;
} SecLabelStmt;
# 1975 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct DeclareCursorStmt
{
 NodeTag type;
 char *portalname;
 int options;
 Node *query;
} DeclareCursorStmt;





typedef struct ClosePortalStmt
{
 NodeTag type;
 char *portalname;

} ClosePortalStmt;





typedef enum FetchDirection
{

 FETCH_FORWARD,
 FETCH_BACKWARD,

 FETCH_ABSOLUTE,
 FETCH_RELATIVE
} FetchDirection;



typedef struct FetchStmt
{
 NodeTag type;
 FetchDirection direction;
 long howMany;
 char *portalname;
 bool ismove;
} FetchStmt;
# 2030 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct IndexStmt
{
 NodeTag type;
 char *idxname;
 RangeVar *relation;
 char *accessMethod;
 char *tableSpace;
 List *indexParams;
 List *options;
 Node *whereClause;
 List *excludeOpNames;
 char *idxcomment;
 Oid indexOid;
 Oid oldNode;
 bool unique;
 bool primary;
 bool isconstraint;
 bool deferrable;
 bool initdeferred;
 bool concurrent;
} IndexStmt;





typedef struct CreateFunctionStmt
{
 NodeTag type;
 bool replace;
 List *funcname;
 List *parameters;
 TypeName *returnType;
 List *options;
 List *withClause;
} CreateFunctionStmt;

typedef enum FunctionParameterMode
{

 FUNC_PARAM_IN = 'i',
 FUNC_PARAM_OUT = 'o',
 FUNC_PARAM_INOUT = 'b',
 FUNC_PARAM_VARIADIC = 'v',
 FUNC_PARAM_TABLE = 't'
} FunctionParameterMode;

typedef struct FunctionParameter
{
 NodeTag type;
 char *name;
 TypeName *argType;
 FunctionParameterMode mode;
 Node *defexpr;
} FunctionParameter;

typedef struct AlterFunctionStmt
{
 NodeTag type;
 FuncWithArgs *func;
 List *actions;
} AlterFunctionStmt;







typedef struct DoStmt
{
 NodeTag type;
 List *args;
} DoStmt;

typedef struct InlineCodeBlock
{
 NodeTag type;
 char *source_text;
 Oid langOid;
 bool langIsTrusted;
} InlineCodeBlock;





typedef struct RenameStmt
{
 NodeTag type;
 ObjectType renameType;
 ObjectType relationType;
 RangeVar *relation;
 List *object;
 List *objarg;
 char *subname;

 char *newname;
 DropBehavior behavior;
 bool missing_ok;
} RenameStmt;





typedef struct AlterObjectSchemaStmt
{
 NodeTag type;
 ObjectType objectType;
 RangeVar *relation;
 List *object;
 List *objarg;
 char *addname;
 char *newschema;
 bool missing_ok;
} AlterObjectSchemaStmt;





typedef struct AlterOwnerStmt
{
 NodeTag type;
 ObjectType objectType;
 RangeVar *relation;
 List *object;
 List *objarg;
 char *addname;
 char *newowner;
} AlterOwnerStmt;






typedef struct RuleStmt
{
 NodeTag type;
 RangeVar *relation;
 char *rulename;
 Node *whereClause;
 CmdType event;
 bool instead;
 List *actions;
 bool replace;
} RuleStmt;





typedef struct NotifyStmt
{
 NodeTag type;
 char *conditionname;
 char *payload;
} NotifyStmt;





typedef struct ListenStmt
{
 NodeTag type;
 char *conditionname;
} ListenStmt;





typedef struct UnlistenStmt
{
 NodeTag type;
 char *conditionname;
} UnlistenStmt;





typedef enum TransactionStmtKind
{
 TRANS_STMT_BEGIN,
 TRANS_STMT_START,
 TRANS_STMT_COMMIT,
 TRANS_STMT_ROLLBACK,
 TRANS_STMT_SAVEPOINT,
 TRANS_STMT_RELEASE,
 TRANS_STMT_ROLLBACK_TO,
 TRANS_STMT_PREPARE,
 TRANS_STMT_COMMIT_PREPARED,
 TRANS_STMT_ROLLBACK_PREPARED
} TransactionStmtKind;

typedef struct TransactionStmt
{
 NodeTag type;
 TransactionStmtKind kind;
 List *options;
 char *gid;
} TransactionStmt;





typedef struct CompositeTypeStmt
{
 NodeTag type;
 RangeVar *typevar;
 List *coldeflist;
} CompositeTypeStmt;





typedef struct CreateEnumStmt
{
 NodeTag type;
 List *typeName;
 List *vals;
} CreateEnumStmt;





typedef struct CreateRangeStmt
{
 NodeTag type;
 List *typeName;
 List *params;
} CreateRangeStmt;





typedef struct AlterEnumStmt
{
 NodeTag type;
 List *typeName;
 char *newVal;
 char *newValNeighbor;
 bool newValIsAfter;
} AlterEnumStmt;





typedef struct ViewStmt
{
 NodeTag type;
 RangeVar *view;
 List *aliases;
 Node *query;
 bool replace;
 List *options;
} ViewStmt;





typedef struct LoadStmt
{
 NodeTag type;
 char *filename;
} LoadStmt;





typedef struct CreatedbStmt
{
 NodeTag type;
 char *dbname;
 List *options;
} CreatedbStmt;





typedef struct AlterDatabaseStmt
{
 NodeTag type;
 char *dbname;
 List *options;
} AlterDatabaseStmt;

typedef struct AlterDatabaseSetStmt
{
 NodeTag type;
 char *dbname;
 VariableSetStmt *setstmt;
} AlterDatabaseSetStmt;





typedef struct DropdbStmt
{
 NodeTag type;
 char *dbname;
 bool missing_ok;
} DropdbStmt;





typedef struct ClusterStmt
{
 NodeTag type;
 RangeVar *relation;
 char *indexname;
 bool verbose;
} ClusterStmt;
# 2369 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum VacuumOption
{
 VACOPT_VACUUM = 1 << 0,
 VACOPT_ANALYZE = 1 << 1,
 VACOPT_VERBOSE = 1 << 2,
 VACOPT_FREEZE = 1 << 3,
 VACOPT_FULL = 1 << 4,
 VACOPT_NOWAIT = 1 << 5
} VacuumOption;

typedef struct VacuumStmt
{
 NodeTag type;
 int options;
 int freeze_min_age;
 int freeze_table_age;
 RangeVar *relation;
 List *va_cols;
} VacuumStmt;
# 2397 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ExplainStmt
{
 NodeTag type;
 Node *query;
 List *options;
} ExplainStmt;
# 2415 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CreateTableAsStmt
{
 NodeTag type;
 Node *query;
 IntoClause *into;
 bool is_select_into;
} CreateTableAsStmt;





typedef struct CheckPointStmt
{
 NodeTag type;
} CheckPointStmt;






typedef enum DiscardMode
{
 DISCARD_ALL,
 DISCARD_PLANS,
 DISCARD_TEMP
} DiscardMode;

typedef struct DiscardStmt
{
 NodeTag type;
 DiscardMode target;
} DiscardStmt;





typedef struct LockStmt
{
 NodeTag type;
 List *relations;
 int mode;
 bool nowait;
} LockStmt;





typedef struct ConstraintsSetStmt
{
 NodeTag type;
 List *constraints;
 bool deferred;
} ConstraintsSetStmt;





typedef struct ReindexStmt
{
 NodeTag type;
 ObjectType kind;
 RangeVar *relation;
 const char *name;
 bool do_system;
 bool do_user;
} ReindexStmt;





typedef struct CreateConversionStmt
{
 NodeTag type;
 List *conversion_name;
 char *for_encoding_name;
 char *to_encoding_name;
 List *func_name;
 bool def;
} CreateConversionStmt;





typedef struct CreateCastStmt
{
 NodeTag type;
 TypeName *sourcetype;
 TypeName *targettype;
 FuncWithArgs *func;
 CoercionContext context;
 bool inout;
} CreateCastStmt;





typedef struct PrepareStmt
{
 NodeTag type;
 char *name;
 List *argtypes;
 Node *query;
} PrepareStmt;







typedef struct ExecuteStmt
{
 NodeTag type;
 char *name;
 List *params;
} ExecuteStmt;






typedef struct DeallocateStmt
{
 NodeTag type;
 char *name;

} DeallocateStmt;




typedef struct DropOwnedStmt
{
 NodeTag type;
 List *roles;
 DropBehavior behavior;
} DropOwnedStmt;




typedef struct ReassignOwnedStmt
{
 NodeTag type;
 List *roles;
 char *newrole;
} ReassignOwnedStmt;




typedef struct AlterTSDictionaryStmt
{
 NodeTag type;
 List *dictname;
 List *options;
} AlterTSDictionaryStmt;




typedef struct AlterTSConfigurationStmt
{
 NodeTag type;
 List *cfgname;





 List *tokentype;
 List *dicts;
 bool override;
 bool replace;
 bool missing_ok;
} AlterTSConfigurationStmt;
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h" 1
# 70 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h" 1
# 36 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
typedef struct FormData_pg_attribute
{
 Oid attrelid;
 NameData attname;
# 48 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 Oid atttypid;
# 57 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int4 attstattarget;





 int2 attlen;
# 78 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int2 attnum;





 int4 attndims;
# 93 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int4 attcacheoff;







 int4 atttypmod;





 bool attbyval;
# 122 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 char attstorage;





 char attalign;


 bool attnotnull;


 bool atthasdef;


 bool attisdropped;


 bool attislocal;


 int4 attinhcount;


 Oid attcollation;
# 160 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
} FormData_pg_attribute;
# 176 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
typedef FormData_pg_attribute *Form_pg_attribute;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 2


typedef struct attrDefault
{
 AttrNumber adnum;
 char *adbin;
} AttrDefault;

typedef struct constrCheck
{
 char *ccname;
 char *ccbin;
 bool ccvalid;
 bool ccnoinherit;
} ConstrCheck;


typedef struct tupleConstr
{
 AttrDefault *defval;
 ConstrCheck *check;
 uint16 num_defval;
 uint16 num_check;
 bool has_not_null;
} TupleConstr;
# 71 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
typedef struct tupleDesc
{
 int natts;
 Form_pg_attribute *attrs;

 TupleConstr *constr;
 Oid tdtypeid;
 int32 tdtypmod;
 bool tdhasoid;
 int tdrefcount;
} *TupleDesc;


extern TupleDesc CreateTemplateTupleDesc(int natts, bool hasoid);

extern TupleDesc CreateTupleDesc(int natts, bool hasoid,
    Form_pg_attribute *attrs);

extern TupleDesc CreateTupleDescCopy(TupleDesc tupdesc);

extern TupleDesc CreateTupleDescCopyConstr(TupleDesc tupdesc);

extern void FreeTupleDesc(TupleDesc tupdesc);

extern void IncrTupleDescRefCount(TupleDesc tupdesc);
extern void DecrTupleDescRefCount(TupleDesc tupdesc);
# 110 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
extern bool equalTupleDescs(TupleDesc tupdesc1, TupleDesc tupdesc2);

extern void TupleDescInitEntry(TupleDesc desc,
       AttrNumber attributeNumber,
       const char *attributeName,
       Oid oidtypeid,
       int32 typmod,
       int attdim);

extern void TupleDescInitEntryCollation(TupleDesc desc,
       AttrNumber attributeNumber,
       Oid collationid);

extern TupleDesc BuildDescForRelation(List *schema);

extern TupleDesc BuildDescFromLists(List *names, List *types, List *typmods, List *collations);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupmacs.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h" 1
# 15 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
# 1 "/usr/include/fcntl.h" 1 3 4
# 23 "/usr/include/fcntl.h" 3 4
# 1 "/usr/include/sys/fcntl.h" 1 3 4
# 80 "/usr/include/sys/fcntl.h" 3 4
# 1 "/usr/include/Availability.h" 1 3 4
# 141 "/usr/include/Availability.h" 3 4
# 1 "/usr/include/AvailabilityInternal.h" 1 3 4
# 142 "/usr/include/Availability.h" 2 3 4
# 81 "/usr/include/sys/fcntl.h" 2 3 4




typedef __darwin_size_t size_t;



typedef __darwin_mode_t mode_t;




typedef __darwin_off_t off_t;




typedef __darwin_pid_t pid_t;
# 339 "/usr/include/sys/fcntl.h" 3 4
struct flock {
 off_t l_start;
 off_t l_len;
 pid_t l_pid;
 short l_type;
 short l_whence;
};
# 355 "/usr/include/sys/fcntl.h" 3 4
struct radvisory {
       off_t ra_offset;
       int ra_count;
};
# 367 "/usr/include/sys/fcntl.h" 3 4
typedef struct fsignatures {
 off_t fs_file_start;
 void *fs_blob_start;
 size_t fs_blob_size;
} fsignatures_t;
# 381 "/usr/include/sys/fcntl.h" 3 4
typedef struct fstore {
 unsigned int fst_flags;
 int fst_posmode;
 off_t fst_offset;
 off_t fst_length;
 off_t fst_bytesalloc;
} fstore_t;



typedef struct fbootstraptransfer {
  off_t fbt_offset;
  size_t fbt_length;
  void *fbt_buffer;
} fbootstraptransfer_t;
# 419 "/usr/include/sys/fcntl.h" 3 4
#pragma pack(4)

struct log2phys {
 unsigned int l2p_flags;
 off_t l2p_contigbytes;


 off_t l2p_devoffset;


};

#pragma pack()
# 442 "/usr/include/sys/fcntl.h" 3 4
struct _filesec;
typedef struct _filesec *filesec_t;


typedef enum {
 FILESEC_OWNER = 1,
 FILESEC_GROUP = 2,
 FILESEC_UUID = 3,
 FILESEC_MODE = 4,
 FILESEC_ACL = 5,
 FILESEC_GRPUUID = 6,


 FILESEC_ACL_RAW = 100,
 FILESEC_ACL_ALLOCSIZE = 101
} filesec_property_t;






int open(const char *, int, ...) __asm("_" "open" );
int creat(const char *, mode_t) __asm("_" "creat" );
int fcntl(int, int, ...) __asm("_" "fcntl" );


int openx_np(const char *, int, filesec_t);
int flock(int, int);
filesec_t filesec_init(void);
filesec_t filesec_dup(filesec_t);
void filesec_free(filesec_t);
int filesec_get_property(filesec_t, filesec_property_t, void *);
int filesec_query_property(filesec_t, filesec_property_t, int *);
int filesec_set_property(filesec_t, filesec_property_t, const void *);
int filesec_unset_property(filesec_t, filesec_property_t) __attribute__((visibility("default")));




# 23 "/usr/include/fcntl.h" 2 3 4
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h" 2
# 32 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
typedef struct XLogRecPtr
{
 uint32 xlogid;
 uint32 xrecoff;
} XLogRecPtr;
# 84 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
typedef uint32 TimeLineID;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/item.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/item.h"
typedef Pointer Item;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h"
typedef struct ItemIdData
{
 unsigned lp_off:15,
    lp_flags:2,
    lp_len:15;
} ItemIdData;

typedef ItemIdData *ItemId;
# 46 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h"
typedef uint16 ItemOffset;
typedef uint16 ItemLength;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h" 2






typedef uint16 OffsetNumber;
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 2
# 73 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef Pointer Page;
# 82 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef uint16 LocationIndex;
# 122 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef struct PageHeaderData
{

 XLogRecPtr pd_lsn;

 uint16 pd_tli;

 uint16 pd_flags;
 LocationIndex pd_lower;
 LocationIndex pd_upper;
 LocationIndex pd_special;
 uint16 pd_pagesize_version;
 TransactionId pd_prune_xid;
 ItemIdData pd_linp[1];
} PageHeaderData;

typedef PageHeaderData *PageHeader;
# 370 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
extern void PageInit(Page page, Size pageSize, Size specialSize);
extern bool PageHeaderIsValid(PageHeader page);
extern OffsetNumber PageAddItem(Page page, Item item, Size size,
   OffsetNumber offsetNumber, bool overwrite, bool is_heap);
extern Page PageGetTempPage(Page page);
extern Page PageGetTempPageCopy(Page page);
extern Page PageGetTempPageCopySpecial(Page page);
extern void PageRestoreTempPage(Page tempPage, Page oldPage);
extern void PageRepairFragmentation(Page page);
extern Size PageGetFreeSpace(Page page);
extern Size PageGetExactFreeSpace(Page page);
extern Size PageGetHeapFreeSpace(Page page);
extern void PageIndexTupleDelete(Page page, OffsetNumber offset);
extern void PageIndexMultiDelete(Page page, OffsetNumber *itemnos, int nitems);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h" 1
# 31 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h"
typedef uint32 BlockNumber;
# 53 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h"
typedef struct BlockIdData
{
 uint16 bi_hi;
 uint16 bi_lo;
} BlockIdData;

typedef BlockIdData *BlockId;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h" 2
# 37 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
typedef struct ItemPointerData
{
 BlockIdData ip_blkid;
 OffsetNumber ip_posid;
}




ItemPointerData;




typedef ItemPointerData *ItemPointer;
# 143 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
extern bool ItemPointerEquals(ItemPointer pointer1, ItemPointer pointer2);
extern int32 ItemPointerCompare(ItemPointer arg1, ItemPointer arg2);
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/backendid.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/backendid.h"
typedef int BackendId;



extern PGDLLIMPORT BackendId MyBackendId;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h" 2







typedef enum ForkNumber
{
 InvalidForkNumber = -1,
 MAIN_FORKNUM = 0,
 FSM_FORKNUM,
 VISIBILITYMAP_FORKNUM,
 INIT_FORKNUM





} ForkNumber;
# 77 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
typedef struct RelFileNode
{
 Oid spcNode;
 Oid dbNode;
 Oid relNode;
} RelFileNode;
# 92 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
typedef struct RelFileNodeBackend
{
 RelFileNode node;
 BackendId backend;
} RelFileNodeBackend;
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 107 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct HeapTupleFields
{
 TransactionId t_xmin;
 TransactionId t_xmax;

 union
 {
  CommandId t_cid;
  TransactionId t_xvac;
 } t_field3;
} HeapTupleFields;

typedef struct DatumTupleFields
{
 int32 datum_len_;

 int32 datum_typmod;

 Oid datum_typeid;





} DatumTupleFields;

typedef struct HeapTupleHeaderData
{
 union
 {
  HeapTupleFields t_heap;
  DatumTupleFields t_datum;
 } t_choice;

 ItemPointerData t_ctid;



 uint16 t_infomask2;

 uint16 t_infomask;

 uint8 t_hoff;



 bits8 t_bits[1];


} HeapTupleHeaderData;

typedef HeapTupleHeaderData *HeapTupleHeader;
# 461 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct MinimalTupleData
{
 uint32 t_len;

 char mt_padding[((offsetof(HeapTupleHeaderData, t_infomask2) - sizeof(uint32)) % MAXIMUM_ALIGNOF)];



 uint16 t_infomask2;

 uint16 t_infomask;

 uint8 t_hoff;



 bits8 t_bits[1];


} MinimalTupleData;

typedef MinimalTupleData *MinimalTuple;
# 517 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct HeapTupleData
{
 uint32 t_len;
 ItemPointerData t_self;
 Oid t_tableOid;
 HeapTupleHeader t_data;
} HeapTupleData;

typedef HeapTupleData *HeapTuple;
# 621 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heaptid
{
 RelFileNode node;
 ItemPointerData tid;
} xl_heaptid;




typedef struct xl_heap_delete
{
 xl_heaptid target;
 bool all_visible_cleared;
} xl_heap_delete;
# 646 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_header
{
 uint16 t_infomask2;
 uint16 t_infomask;
 uint8 t_hoff;
} xl_heap_header;




typedef struct xl_heap_insert
{
 xl_heaptid target;
 bool all_visible_cleared;

} xl_heap_insert;
# 671 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_multi_insert
{
 RelFileNode node;
 BlockNumber blkno;
 bool all_visible_cleared;
 uint16 ntuples;
 OffsetNumber offsets[1];


} xl_heap_multi_insert;



typedef struct xl_multi_insert_tuple
{
 uint16 datalen;
 uint16 t_infomask2;
 uint16 t_infomask;
 uint8 t_hoff;

} xl_multi_insert_tuple;




typedef struct xl_heap_update
{
 xl_heaptid target;
 ItemPointerData newtid;
 bool all_visible_cleared;
 bool new_all_visible_cleared;

} xl_heap_update;
# 718 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_clean
{
 RelFileNode node;
 BlockNumber block;
 TransactionId latestRemovedXid;
 uint16 nredirected;
 uint16 ndead;

} xl_heap_clean;
# 735 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_cleanup_info
{
 RelFileNode node;
 TransactionId latestRemovedXid;
} xl_heap_cleanup_info;





typedef struct xl_heap_newpage
{
 RelFileNode node;
 ForkNumber forknum;
 BlockNumber blkno;

} xl_heap_newpage;




typedef struct xl_heap_lock
{
 xl_heaptid target;
 TransactionId locking_xid;
 bool xid_is_mxact;
 bool shared_lock;
} xl_heap_lock;




typedef struct xl_heap_inplace
{
 xl_heaptid target;

} xl_heap_inplace;




typedef struct xl_heap_freeze
{
 RelFileNode node;
 BlockNumber block;
 TransactionId cutoff_xid;

} xl_heap_freeze;




typedef struct xl_heap_visible
{
 RelFileNode node;
 BlockNumber block;
 TransactionId cutoff_xid;
} xl_heap_visible;



extern void HeapTupleHeaderAdvanceLatestRemovedXid(HeapTupleHeader tuple,
            TransactionId *latestRemovedXid);


extern CommandId HeapTupleHeaderGetCmin(HeapTupleHeader tup);
extern CommandId HeapTupleHeaderGetCmax(HeapTupleHeader tup);
extern void HeapTupleHeaderAdjustCmax(HeapTupleHeader tup,
        CommandId *cmax,
        bool *iscombo);
# 890 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
extern Size heap_compute_data_size(TupleDesc tupleDesc,
        Datum *values, bool *isnull);
extern void heap_fill_tuple(TupleDesc tupleDesc,
    Datum *values, bool *isnull,
    char *data, Size data_size,
    uint16 *infomask, bits8 *bit);
extern bool heap_attisnull(HeapTuple tup, int attnum);
extern Datum nocachegetattr(HeapTuple tup, int attnum,
      TupleDesc att);
extern Datum heap_getsysattr(HeapTuple tup, int attnum, TupleDesc tupleDesc,
    bool *isnull);
extern HeapTuple heap_copytuple(HeapTuple tuple);
extern void heap_copytuple_with_tuple(HeapTuple src, HeapTuple dest);
extern HeapTuple heap_form_tuple(TupleDesc tupleDescriptor,
    Datum *values, bool *isnull);
extern HeapTuple heap_modify_tuple(HeapTuple tuple,
      TupleDesc tupleDesc,
      Datum *replValues,
      bool *replIsnull,
      bool *doReplace);
extern void heap_deform_tuple(HeapTuple tuple, TupleDesc tupleDesc,
      Datum *values, bool *isnull);


extern HeapTuple heap_formtuple(TupleDesc tupleDescriptor,
      Datum *values, char *nulls);
extern HeapTuple heap_modifytuple(HeapTuple tuple,
     TupleDesc tupleDesc,
     Datum *replValues,
     char *replNulls,
     char *replActions);
extern void heap_deformtuple(HeapTuple tuple, TupleDesc tupleDesc,
     Datum *values, char *nulls);
extern void heap_freetuple(HeapTuple htup);
extern MinimalTuple heap_form_minimal_tuple(TupleDesc tupleDescriptor,
      Datum *values, bool *isnull);
extern void heap_free_minimal_tuple(MinimalTuple mtup);
extern MinimalTuple heap_copy_minimal_tuple(MinimalTuple mtup);
extern HeapTuple heap_tuple_from_minimal_tuple(MinimalTuple mtup);
extern MinimalTuple minimal_tuple_from_heap_tuple(HeapTuple htup);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h"
typedef int Buffer;
# 44 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h"
typedef struct BufferAccessStrategyData *BufferAccessStrategy;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 2
# 112 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
typedef struct TupleTableSlot
{
 NodeTag type;
 bool tts_isempty;
 bool tts_shouldFree;
 bool tts_shouldFreeMin;
 bool tts_slow;
 HeapTuple tts_tuple;
 TupleDesc tts_tupleDescriptor;
 MemoryContext tts_mcxt;
 Buffer tts_buffer;
 int tts_nvalid;
 Datum *tts_values;
 bool *tts_isnull;
 MinimalTuple tts_mintuple;
 HeapTupleData tts_minhdr;
 long tts_off;
} TupleTableSlot;
# 141 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
extern TupleTableSlot *MakeTupleTableSlot(void);
extern TupleTableSlot *ExecAllocTableSlot(List **tupleTable);
extern void ExecResetTupleTable(List *tupleTable, bool shouldFree);
extern TupleTableSlot *MakeSingleTupleTableSlot(TupleDesc tupdesc);
extern void ExecDropSingleTupleTableSlot(TupleTableSlot *slot);
extern void ExecSetSlotDescriptor(TupleTableSlot *slot, TupleDesc tupdesc);
extern TupleTableSlot *ExecStoreTuple(HeapTuple tuple,
      TupleTableSlot *slot,
      Buffer buffer,
      bool shouldFree);
extern TupleTableSlot *ExecStoreMinimalTuple(MinimalTuple mtup,
       TupleTableSlot *slot,
       bool shouldFree);
extern TupleTableSlot *ExecClearTuple(TupleTableSlot *slot);
extern TupleTableSlot *ExecStoreVirtualTuple(TupleTableSlot *slot);
extern TupleTableSlot *ExecStoreAllNullTuple(TupleTableSlot *slot);
extern HeapTuple ExecCopySlotTuple(TupleTableSlot *slot);
extern MinimalTuple ExecCopySlotMinimalTuple(TupleTableSlot *slot);
extern HeapTuple ExecFetchSlotTuple(TupleTableSlot *slot);
extern MinimalTuple ExecFetchSlotMinimalTuple(TupleTableSlot *slot);
extern Datum ExecFetchSlotTupleDatum(TupleTableSlot *slot);
extern HeapTuple ExecMaterializeSlot(TupleTableSlot *slot);
extern TupleTableSlot *ExecCopySlot(TupleTableSlot *dstslot,
    TupleTableSlot *srcslot);


extern Datum slot_getattr(TupleTableSlot *slot, int attnum, bool *isnull);
extern void slot_getallattrs(TupleTableSlot *slot);
extern void slot_getsomeattrs(TupleTableSlot *slot, int attnum);
extern bool slot_attisnull(TupleTableSlot *slot, int attnum);
# 71 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h" 2
# 86 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h"
typedef enum
{
 DestNone,
 DestDebug,
 DestRemote,
 DestRemoteExecute,
 DestSPI,
 DestTuplestore,
 DestIntoRel,
 DestCopyOut,
 DestSQLFunction
} CommandDest;
# 108 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h"
typedef struct _DestReceiver DestReceiver;

struct _DestReceiver
{

 void (*receiveSlot) (TupleTableSlot *slot,
           DestReceiver *self);

 void (*rStartup) (DestReceiver *self,
           int operation,
           TupleDesc typeinfo);
 void (*rShutdown) (DestReceiver *self);

 void (*rDestroy) (DestReceiver *self);

 CommandDest mydest;

};

extern DestReceiver *None_Receiver;



extern void BeginCommand(const char *commandTag, CommandDest dest);
extern DestReceiver *CreateDestReceiver(CommandDest dest);
extern void EndCommand(const char *commandTag, CommandDest dest);



extern void NullCommand(CommandDest dest);
extern void ReadyForQuery(CommandDest dest);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h" 1
# 59 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h"
# 1 "./fmgr.h" 1
# 22 "./fmgr.h"
typedef struct Node *fmNodePtr;


typedef struct StringInfoData *fmStringInfo;
# 34 "./fmgr.h"
typedef struct FunctionCallInfoData *FunctionCallInfo;

typedef Datum (*PGFunction) (FunctionCallInfo fcinfo);
# 49 "./fmgr.h"
typedef struct FmgrInfo
{
 PGFunction fn_addr;
 Oid fn_oid;
 short fn_nargs;

 bool fn_strict;
 bool fn_retset;
 unsigned char fn_stats;
 void *fn_extra;
 MemoryContext fn_mcxt;
 fmNodePtr fn_expr;
} FmgrInfo;




typedef struct FunctionCallInfoData
{
 FmgrInfo *flinfo;
 fmNodePtr context;
 fmNodePtr resultinfo;
 Oid fncollation;
 bool isnull;
 short nargs;
 Datum arg[FUNC_MAX_ARGS];
 bool argnull[FUNC_MAX_ARGS];
} FunctionCallInfoData;





extern void fmgr_info(Oid functionId, FmgrInfo *finfo);






extern void fmgr_info_cxt(Oid functionId, FmgrInfo *finfo,
     MemoryContext mcxt);
# 99 "./fmgr.h"
extern void fmgr_info_copy(FmgrInfo *dstinfo, FmgrInfo *srcinfo,
      MemoryContext destcxt);
# 187 "./fmgr.h"
extern struct varlena *pg_detoast_datum(struct varlena * datum);
extern struct varlena *pg_detoast_datum_copy(struct varlena * datum);
extern struct varlena *pg_detoast_datum_slice(struct varlena * datum,
        int32 first, int32 count);
extern struct varlena *pg_detoast_datum_packed(struct varlena * datum);
# 332 "./fmgr.h"
typedef struct
{
 int api_version;

} Pg_finfo_record;


typedef const Pg_finfo_record *(*PGFInfoFunction) (void);
# 383 "./fmgr.h"
typedef struct
{
 int len;
 int version;
 int funcmaxargs;
 int indexmaxkeys;
 int namedatalen;
 int float4byval;
 int float8byval;
} Pg_magic_struct;
# 410 "./fmgr.h"
typedef const Pg_magic_struct *(*PGModuleMagicFunction) (void);
# 435 "./fmgr.h"
extern Datum DirectFunctionCall1Coll(PGFunction func, Oid collation,
      Datum arg1);
extern Datum DirectFunctionCall2Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2);
extern Datum DirectFunctionCall3Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3);
extern Datum DirectFunctionCall4Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4);
extern Datum DirectFunctionCall5Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5);
extern Datum DirectFunctionCall6Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6);
extern Datum DirectFunctionCall7Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7);
extern Datum DirectFunctionCall8Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8);
extern Datum DirectFunctionCall9Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8,
      Datum arg9);





extern Datum FunctionCall1Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1);
extern Datum FunctionCall2Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2);
extern Datum FunctionCall3Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3);
extern Datum FunctionCall4Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4);
extern Datum FunctionCall5Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5);
extern Datum FunctionCall6Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6);
extern Datum FunctionCall7Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7);
extern Datum FunctionCall8Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8);
extern Datum FunctionCall9Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8,
      Datum arg9);







extern Datum OidFunctionCall0Coll(Oid functionId, Oid collation);
extern Datum OidFunctionCall1Coll(Oid functionId, Oid collation,
      Datum arg1);
extern Datum OidFunctionCall2Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2);
extern Datum OidFunctionCall3Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3);
extern Datum OidFunctionCall4Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4);
extern Datum OidFunctionCall5Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5);
extern Datum OidFunctionCall6Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6);
extern Datum OidFunctionCall7Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7);
extern Datum OidFunctionCall8Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8);
extern Datum OidFunctionCall9Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8,
      Datum arg9);
# 602 "./fmgr.h"
extern Datum InputFunctionCall(FmgrInfo *flinfo, char *str,
      Oid typioparam, int32 typmod);
extern Datum OidInputFunctionCall(Oid functionId, char *str,
      Oid typioparam, int32 typmod);
extern char *OutputFunctionCall(FmgrInfo *flinfo, Datum val);
extern char *OidOutputFunctionCall(Oid functionId, Datum val);
extern Datum ReceiveFunctionCall(FmgrInfo *flinfo, fmStringInfo buf,
     Oid typioparam, int32 typmod);
extern Datum OidReceiveFunctionCall(Oid functionId, fmStringInfo buf,
        Oid typioparam, int32 typmod);
extern bytea *SendFunctionCall(FmgrInfo *flinfo, Datum val);
extern bytea *OidSendFunctionCall(Oid functionId, Datum val);





extern const Pg_finfo_record *fetch_finfo_record(void *filehandle, char *funcname);
extern void clear_external_function_hash(void *filehandle);
extern Oid fmgr_internal_function(const char *proname);
extern Oid get_fn_expr_rettype(FmgrInfo *flinfo);
extern Oid get_fn_expr_argtype(FmgrInfo *flinfo, int argnum);
extern Oid get_call_expr_argtype(fmNodePtr expr, int argnum);
extern bool get_fn_expr_arg_stable(FmgrInfo *flinfo, int argnum);
extern bool get_call_expr_arg_stable(fmNodePtr expr, int argnum);




extern char *Dynamic_library_path;

extern PGFunction load_external_function(char *filename, char *funcname,
        bool signalNotFound, void **filehandle);
extern PGFunction lookup_external_function(void *filehandle, char *funcname);
extern void load_file(const char *filename, bool restricted);
extern void **find_rendezvous_variable(const char *varName);
# 650 "./fmgr.h"
extern int AggCheckCallContext(FunctionCallInfo fcinfo,
     MemoryContext *aggcontext);
# 662 "./fmgr.h"
typedef enum FmgrHookEventType
{
 FHET_START,
 FHET_END,
 FHET_ABORT
} FmgrHookEventType;

typedef bool (*needs_fmgr_hook_type) (Oid fn_oid);

typedef void (*fmgr_hook_type) (FmgrHookEventType event,
           FmgrInfo *flinfo, Datum *arg);

extern PGDLLIMPORT needs_fmgr_hook_type needs_fmgr_hook;
extern PGDLLIMPORT fmgr_hook_type fmgr_hook;
# 693 "./fmgr.h"
extern char *fmgr(Oid procedureId,...);
# 60 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h" 2
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h"
typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
} ArrayType;




typedef struct ArrayBuildState
{
 MemoryContext mcontext;
 Datum *dvalues;
 bool *dnulls;
 int alen;
 int nelems;
 Oid element_type;
 int16 typlen;
 bool typbyval;
 char typalign;
} ArrayBuildState;




typedef struct ArrayMetaState
{
 Oid element_type;
 int16 typlen;
 bool typbyval;
 char typalign;
 char typdelim;
 Oid typioparam;
 Oid typiofunc;
 FmgrInfo proc;
} ArrayMetaState;




typedef struct ArrayMapState
{
 ArrayMetaState inp_extra;
 ArrayMetaState ret_extra;
} ArrayMapState;


typedef struct ArrayIteratorData *ArrayIterator;
# 182 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h"
extern bool Array_nulls;




extern Datum array_in(FunctionCallInfo fcinfo);
extern Datum array_out(FunctionCallInfo fcinfo);
extern Datum array_recv(FunctionCallInfo fcinfo);
extern Datum array_send(FunctionCallInfo fcinfo);
extern Datum array_eq(FunctionCallInfo fcinfo);
extern Datum array_ne(FunctionCallInfo fcinfo);
extern Datum array_lt(FunctionCallInfo fcinfo);
extern Datum array_gt(FunctionCallInfo fcinfo);
extern Datum array_le(FunctionCallInfo fcinfo);
extern Datum array_ge(FunctionCallInfo fcinfo);
extern Datum btarraycmp(FunctionCallInfo fcinfo);
extern Datum hash_array(FunctionCallInfo fcinfo);
extern Datum arrayoverlap(FunctionCallInfo fcinfo);
extern Datum arraycontains(FunctionCallInfo fcinfo);
extern Datum arraycontained(FunctionCallInfo fcinfo);
extern Datum array_ndims(FunctionCallInfo fcinfo);
extern Datum array_dims(FunctionCallInfo fcinfo);
extern Datum array_lower(FunctionCallInfo fcinfo);
extern Datum array_upper(FunctionCallInfo fcinfo);
extern Datum array_length(FunctionCallInfo fcinfo);
extern Datum array_larger(FunctionCallInfo fcinfo);
extern Datum array_smaller(FunctionCallInfo fcinfo);
extern Datum generate_subscripts(FunctionCallInfo fcinfo);
extern Datum generate_subscripts_nodir(FunctionCallInfo fcinfo);
extern Datum array_fill(FunctionCallInfo fcinfo);
extern Datum array_fill_with_lower_bounds(FunctionCallInfo fcinfo);
extern Datum array_unnest(FunctionCallInfo fcinfo);

extern Datum array_ref(ArrayType *array, int nSubscripts, int *indx,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign,
    bool *isNull);
extern ArrayType *array_set(ArrayType *array, int nSubscripts, int *indx,
    Datum dataValue, bool isNull,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign);
extern ArrayType *array_get_slice(ArrayType *array, int nSubscripts,
    int *upperIndx, int *lowerIndx,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign);
extern ArrayType *array_set_slice(ArrayType *array, int nSubscripts,
    int *upperIndx, int *lowerIndx,
    ArrayType *srcArray, bool isNull,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign);

extern Datum array_map(FunctionCallInfo fcinfo, Oid inpType, Oid retType,
    ArrayMapState *amstate);

extern void array_bitmap_copy(bits8 *destbitmap, int destoffset,
      const bits8 *srcbitmap, int srcoffset,
      int nitems);

extern ArrayType *construct_array(Datum *elems, int nelems,
    Oid elmtype,
    int elmlen, bool elmbyval, char elmalign);
extern ArrayType *construct_md_array(Datum *elems,
       bool *nulls,
       int ndims,
       int *dims,
       int *lbs,
       Oid elmtype, int elmlen, bool elmbyval, char elmalign);
extern ArrayType *construct_empty_array(Oid elmtype);
extern void deconstruct_array(ArrayType *array,
      Oid elmtype,
      int elmlen, bool elmbyval, char elmalign,
      Datum **elemsp, bool **nullsp, int *nelemsp);
extern bool array_contains_nulls(ArrayType *array);
extern ArrayBuildState *accumArrayResult(ArrayBuildState *astate,
     Datum dvalue, bool disnull,
     Oid element_type,
     MemoryContext rcontext);
extern Datum makeArrayResult(ArrayBuildState *astate,
    MemoryContext rcontext);
extern Datum makeMdArrayResult(ArrayBuildState *astate, int ndims,
      int *dims, int *lbs, MemoryContext rcontext, bool release);

extern ArrayIterator array_create_iterator(ArrayType *arr, int slice_ndim);
extern bool array_iterate(ArrayIterator iterator, Datum *value, bool *isnull);
extern void array_free_iterator(ArrayIterator iterator);





extern int ArrayGetOffset(int n, const int *dim, const int *lb, const int *indx);
extern int ArrayGetOffset0(int n, const int *tup, const int *scale);
extern int ArrayGetNItems(int ndim, const int *dims);
extern void mda_get_range(int n, int *span, const int *st, const int *endp);
extern void mda_get_prod(int n, const int *range, int *prod);
extern void mda_get_offset_values(int n, int *dist, const int *prod, const int *span);
extern int mda_next_tuple(int n, int *curr, const int *span);
extern int32 *ArrayGetIntegerTypmods(ArrayType *arr, int *n);




extern Datum array_push(FunctionCallInfo fcinfo);
extern Datum array_cat(FunctionCallInfo fcinfo);

extern ArrayType *create_singleton_array(FunctionCallInfo fcinfo,
        Oid element_type,
        Datum element,
        bool isNull,
        int ndims);

extern Datum array_agg_transfn(FunctionCallInfo fcinfo);
extern Datum array_agg_finalfn(FunctionCallInfo fcinfo);




extern Datum array_typanalyze(FunctionCallInfo fcinfo);
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 2
# 51 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
typedef enum
{
 PGC_INTERNAL,
 PGC_POSTMASTER,
 PGC_SIGHUP,
 PGC_BACKEND,
 PGC_SUSET,
 PGC_USERSET
} GucContext;
# 83 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
typedef enum
{
 PGC_S_DEFAULT,
 PGC_S_DYNAMIC_DEFAULT,
 PGC_S_ENV_VAR,
 PGC_S_FILE,
 PGC_S_ARGV,
 PGC_S_DATABASE,
 PGC_S_USER,
 PGC_S_DATABASE_USER,
 PGC_S_CLIENT,
 PGC_S_OVERRIDE,
 PGC_S_INTERACTIVE,
 PGC_S_TEST,
 PGC_S_SESSION
} GucSource;





typedef struct ConfigVariable
{
 char *name;
 char *value;
 char *filename;
 int sourceline;
 struct ConfigVariable *next;
} ConfigVariable;

extern bool ParseConfigFile(const char *config_file, const char *calling_file,
    bool strict, int depth, int elevel,
    ConfigVariable **head_p, ConfigVariable **tail_p);
extern bool ParseConfigFp(FILE *fp, const char *config_file,
     int depth, int elevel,
     ConfigVariable **head_p, ConfigVariable **tail_p);
extern void FreeConfigVariables(ConfigVariable *list);






struct config_enum_entry
{
 const char *name;
 int val;
 bool hidden;
};




typedef bool (*GucBoolCheckHook) (bool *newval, void **extra, GucSource source);
typedef bool (*GucIntCheckHook) (int *newval, void **extra, GucSource source);
typedef bool (*GucRealCheckHook) (double *newval, void **extra, GucSource source);
typedef bool (*GucStringCheckHook) (char **newval, void **extra, GucSource source);
typedef bool (*GucEnumCheckHook) (int *newval, void **extra, GucSource source);

typedef void (*GucBoolAssignHook) (bool newval, void *extra);
typedef void (*GucIntAssignHook) (int newval, void *extra);
typedef void (*GucRealAssignHook) (double newval, void *extra);
typedef void (*GucStringAssignHook) (const char *newval, void *extra);
typedef void (*GucEnumAssignHook) (int newval, void *extra);

typedef const char *(*GucShowHook) (void);




typedef enum
{

 GUC_ACTION_SET,
 GUC_ACTION_LOCAL,
 GUC_ACTION_SAVE
} GucAction;
# 190 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
extern bool log_duration;
extern bool Debug_print_plan;
extern bool Debug_print_parse;
extern bool Debug_print_rewritten;
extern bool Debug_pretty_print;

extern bool log_parser_stats;
extern bool log_planner_stats;
extern bool log_executor_stats;
extern bool log_statement_stats;
extern bool log_btree_build_stats;

extern PGDLLIMPORT bool check_function_bodies;
extern bool default_with_oids;
extern bool SQL_inheritance;

extern int log_min_error_statement;
extern int log_min_messages;
extern int client_min_messages;
extern int log_min_duration_statement;
extern int log_temp_files;

extern int temp_file_limit;

extern int num_temp_buffers;

extern char *data_directory;
extern char *ConfigFileName;
extern char *HbaFileName;
extern char *IdentFileName;
extern char *external_pid_file;

extern char *application_name;

extern int tcp_keepalives_idle;
extern int tcp_keepalives_interval;
extern int tcp_keepalives_count;




extern void SetConfigOption(const char *name, const char *value,
    GucContext context, GucSource source);

extern void DefineCustomBoolVariable(
       const char *name,
       const char *short_desc,
       const char *long_desc,
       bool *valueAddr,
       bool bootValue,
       GucContext context,
       int flags,
       GucBoolCheckHook check_hook,
       GucBoolAssignHook assign_hook,
       GucShowHook show_hook);

extern void DefineCustomIntVariable(
      const char *name,
      const char *short_desc,
      const char *long_desc,
      int *valueAddr,
      int bootValue,
      int minValue,
      int maxValue,
      GucContext context,
      int flags,
      GucIntCheckHook check_hook,
      GucIntAssignHook assign_hook,
      GucShowHook show_hook);

extern void DefineCustomRealVariable(
       const char *name,
       const char *short_desc,
       const char *long_desc,
       double *valueAddr,
       double bootValue,
       double minValue,
       double maxValue,
       GucContext context,
       int flags,
       GucRealCheckHook check_hook,
       GucRealAssignHook assign_hook,
       GucShowHook show_hook);

extern void DefineCustomStringVariable(
         const char *name,
         const char *short_desc,
         const char *long_desc,
         char **valueAddr,
         const char *bootValue,
         GucContext context,
         int flags,
         GucStringCheckHook check_hook,
         GucStringAssignHook assign_hook,
         GucShowHook show_hook);

extern void DefineCustomEnumVariable(
       const char *name,
       const char *short_desc,
       const char *long_desc,
       int *valueAddr,
       int bootValue,
       const struct config_enum_entry * options,
       GucContext context,
       int flags,
       GucEnumCheckHook check_hook,
       GucEnumAssignHook assign_hook,
       GucShowHook show_hook);

extern void EmitWarningsOnPlaceholders(const char *className);

extern const char *GetConfigOption(const char *name, bool missing_ok,
    bool restrict_superuser);
extern const char *GetConfigOptionResetString(const char *name);
extern void ProcessConfigFile(GucContext context);
extern void InitializeGUCOptions(void);
extern bool SelectConfigFiles(const char *userDoption, const char *progname);
extern void ResetAllOptions(void);
extern void AtStart_GUC(void);
extern int NewGUCNestLevel(void);
extern void AtEOXact_GUC(bool isCommit, int nestLevel);
extern void BeginReportingGUCOptions(void);
extern void ParseLongOption(const char *string, char **name, char **value);
extern bool parse_int(const char *value, int *result, int flags,
    const char **hintmsg);
extern bool parse_real(const char *value, double *result);
extern int set_config_option(const char *name, const char *value,
      GucContext context, GucSource source,
      GucAction action, bool changeVal, int elevel);
extern char *GetConfigOptionByName(const char *name, const char **varname);
extern void GetConfigOptionByNum(int varnum, const char **values, bool *noshow);
extern int GetNumConfigOptions(void);

extern void SetPGVariable(const char *name, List *args, bool is_local);
extern void GetPGVariable(const char *name, DestReceiver *dest);
extern TupleDesc GetPGVariableResultDesc(const char *name);

extern void ExecSetVariableStmt(VariableSetStmt *stmt);
extern char *ExtractSetVariableArgs(VariableSetStmt *stmt);

extern void ProcessGUCArray(ArrayType *array,
    GucContext context, GucSource source, GucAction action);
extern ArrayType *GUCArrayAdd(ArrayType *array, const char *name, const char *value);
extern ArrayType *GUCArrayDelete(ArrayType *array, const char *name);
extern ArrayType *GUCArrayReset(ArrayType *array);
# 343 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
extern PGDLLIMPORT char *GUC_check_errmsg_string;
extern PGDLLIMPORT char *GUC_check_errdetail_string;
extern PGDLLIMPORT char *GUC_check_errhint_string;

extern void GUC_check_errcode(int sqlerrcode);
# 369 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
extern bool check_default_tablespace(char **newval, void **extra, GucSource source);
extern bool check_temp_tablespaces(char **newval, void **extra, GucSource source);
extern void assign_temp_tablespaces(const char *newval, void *extra);


extern bool check_search_path(char **newval, void **extra, GucSource source);
extern void assign_search_path(const char *newval, void *extra);


extern bool check_wal_buffers(int *newval, void **extra, GucSource source);
extern void assign_xlog_sync_method(int new_sync_method, void *extra);
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/pg_locale.h" 2



extern char *locale_messages;
extern char *locale_monetary;
extern char *locale_numeric;
extern char *locale_time;


extern char *localized_abbrev_days[];
extern char *localized_full_days[];
extern char *localized_abbrev_months[];
extern char *localized_full_months[];


extern bool check_locale_messages(char **newval, void **extra, GucSource source);
extern void assign_locale_messages(const char *newval, void *extra);
extern bool check_locale_monetary(char **newval, void **extra, GucSource source);
extern void assign_locale_monetary(const char *newval, void *extra);
extern bool check_locale_numeric(char **newval, void **extra, GucSource source);
extern void assign_locale_numeric(const char *newval, void *extra);
extern bool check_locale_time(char **newval, void **extra, GucSource source);
extern void assign_locale_time(const char *newval, void *extra);

extern bool check_locale(int category, const char *locale, char **canonname);
extern char *pg_perm_setlocale(int category, const char *locale);

extern bool lc_collate_is_c(Oid collation);
extern bool lc_ctype_is_c(Oid collation);





extern struct lconv *PGLC_localeconv(void);

extern void cache_locale_time(void);
# 70 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/pg_locale.h"
typedef int pg_locale_t;


extern pg_locale_t pg_newlocale_from_collation(Oid collid);
# 20 "regc_pg_locale.c" 2
# 65 "regc_pg_locale.c"
typedef enum
{
 PG_REGEX_LOCALE_C,
 PG_REGEX_LOCALE_WIDE,
 PG_REGEX_LOCALE_1BYTE,
 PG_REGEX_LOCALE_WIDE_L,
 PG_REGEX_LOCALE_1BYTE_L
} PG_Locale_Strategy;

static PG_Locale_Strategy pg_regex_strategy;
static pg_locale_t pg_regex_locale;
static Oid pg_regex_collation;
# 91 "regc_pg_locale.c"
static const unsigned char pg_char_properties[128] = {
            0,
           0,
           0,
           0,
           0,
           0,
           0,
           0,
           0,
           0x80,
           0x80,
           0x80,
           0x80,
           0x80,
           0,
           0,
           0,
           0,
           0,
           0,
           0,
           0,
           0,
           0,
           0,
           0,
           0,
           0,
           0,
           0,
           0,
           0,
        0x20 | 0x80,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x01 | 0x10 | 0x20,
           0x01 | 0x10 | 0x20,
           0x01 | 0x10 | 0x20,
           0x01 | 0x10 | 0x20,
           0x01 | 0x10 | 0x20,
           0x01 | 0x10 | 0x20,
           0x01 | 0x10 | 0x20,
           0x01 | 0x10 | 0x20,
           0x01 | 0x10 | 0x20,
           0x01 | 0x10 | 0x20,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x02 | 0x04 | 0x10 | 0x20,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x02 | 0x08 | 0x10 | 0x20,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
           0x10 | 0x20 | 0x40,
            0
};
# 230 "regc_pg_locale.c"
void
pg_set_regex_collation(Oid collation)
{
 if (lc_ctype_is_c(collation))
 {

  pg_regex_strategy = PG_REGEX_LOCALE_C;
  pg_regex_locale = 0;
  pg_regex_collation = 950;
 }
 else
 {
  if (collation == 100)
   pg_regex_locale = 0;
  else if (OidIsValid(collation))
  {





   pg_regex_locale = pg_newlocale_from_collation(collation);
  }
  else
  {




   ereport(ERROR,
     (errcode(ERRCODE_INDETERMINATE_COLLATION),
      errmsg("could not determine which collation to use for regular expression"),
      errhint("Use the COLLATE clause to set the collation explicitly.")));
  }
# 275 "regc_pg_locale.c"
  {
   if (pg_regex_locale)
    pg_regex_strategy = PG_REGEX_LOCALE_1BYTE_L;
   else
    pg_regex_strategy = PG_REGEX_LOCALE_1BYTE;
  }

  pg_regex_collation = collation;
 }
}

static int
pg_wc_isdigit(pg_wchar c)
{
 switch (pg_regex_strategy)
 {
  case PG_REGEX_LOCALE_C:
   return (c <= (pg_wchar) 127 &&
     (pg_char_properties[c] & 0x01));
  case PG_REGEX_LOCALE_WIDE:





  case PG_REGEX_LOCALE_1BYTE:
   return (c <= (pg_wchar) UCHAR_MAX &&
     isdigit((unsigned char) c));
  case PG_REGEX_LOCALE_WIDE_L:





  case PG_REGEX_LOCALE_1BYTE_L:




   break;
 }
 return 0;
}

static int
pg_wc_isalpha(pg_wchar c)
{
 switch (pg_regex_strategy)
 {
  case PG_REGEX_LOCALE_C:
   return (c <= (pg_wchar) 127 &&
     (pg_char_properties[c] & 0x02));
  case PG_REGEX_LOCALE_WIDE:





  case PG_REGEX_LOCALE_1BYTE:
   return (c <= (pg_wchar) UCHAR_MAX &&
     isalpha((unsigned char) c));
  case PG_REGEX_LOCALE_WIDE_L:





  case PG_REGEX_LOCALE_1BYTE_L:




   break;
 }
 return 0;
}

static int
pg_wc_isalnum(pg_wchar c)
{
 switch (pg_regex_strategy)
 {
  case PG_REGEX_LOCALE_C:
   return (c <= (pg_wchar) 127 &&
     (pg_char_properties[c] & (0x01 | 0x02)));
  case PG_REGEX_LOCALE_WIDE:





  case PG_REGEX_LOCALE_1BYTE:
   return (c <= (pg_wchar) UCHAR_MAX &&
     isalnum((unsigned char) c));
  case PG_REGEX_LOCALE_WIDE_L:





  case PG_REGEX_LOCALE_1BYTE_L:




   break;
 }
 return 0;
}

static int
pg_wc_isupper(pg_wchar c)
{
 switch (pg_regex_strategy)
 {
  case PG_REGEX_LOCALE_C:
   return (c <= (pg_wchar) 127 &&
     (pg_char_properties[c] & 0x04));
  case PG_REGEX_LOCALE_WIDE:





  case PG_REGEX_LOCALE_1BYTE:
   return (c <= (pg_wchar) UCHAR_MAX &&
     isupper((unsigned char) c));
  case PG_REGEX_LOCALE_WIDE_L:





  case PG_REGEX_LOCALE_1BYTE_L:




   break;
 }
 return 0;
}

static int
pg_wc_islower(pg_wchar c)
{
 switch (pg_regex_strategy)
 {
  case PG_REGEX_LOCALE_C:
   return (c <= (pg_wchar) 127 &&
     (pg_char_properties[c] & 0x08));
  case PG_REGEX_LOCALE_WIDE:





  case PG_REGEX_LOCALE_1BYTE:
   return (c <= (pg_wchar) UCHAR_MAX &&
     islower((unsigned char) c));
  case PG_REGEX_LOCALE_WIDE_L:





  case PG_REGEX_LOCALE_1BYTE_L:




   break;
 }
 return 0;
}

static int
pg_wc_isgraph(pg_wchar c)
{
 switch (pg_regex_strategy)
 {
  case PG_REGEX_LOCALE_C:
   return (c <= (pg_wchar) 127 &&
     (pg_char_properties[c] & 0x10));
  case PG_REGEX_LOCALE_WIDE:





  case PG_REGEX_LOCALE_1BYTE:
   return (c <= (pg_wchar) UCHAR_MAX &&
     isgraph((unsigned char) c));
  case PG_REGEX_LOCALE_WIDE_L:





  case PG_REGEX_LOCALE_1BYTE_L:




   break;
 }
 return 0;
}

static int
pg_wc_isprint(pg_wchar c)
{
 switch (pg_regex_strategy)
 {
  case PG_REGEX_LOCALE_C:
   return (c <= (pg_wchar) 127 &&
     (pg_char_properties[c] & 0x20));
  case PG_REGEX_LOCALE_WIDE:





  case PG_REGEX_LOCALE_1BYTE:
   return (c <= (pg_wchar) UCHAR_MAX &&
     isprint((unsigned char) c));
  case PG_REGEX_LOCALE_WIDE_L:





  case PG_REGEX_LOCALE_1BYTE_L:




   break;
 }
 return 0;
}

static int
pg_wc_ispunct(pg_wchar c)
{
 switch (pg_regex_strategy)
 {
  case PG_REGEX_LOCALE_C:
   return (c <= (pg_wchar) 127 &&
     (pg_char_properties[c] & 0x40));
  case PG_REGEX_LOCALE_WIDE:





  case PG_REGEX_LOCALE_1BYTE:
   return (c <= (pg_wchar) UCHAR_MAX &&
     ispunct((unsigned char) c));
  case PG_REGEX_LOCALE_WIDE_L:





  case PG_REGEX_LOCALE_1BYTE_L:




   break;
 }
 return 0;
}

static int
pg_wc_isspace(pg_wchar c)
{
 switch (pg_regex_strategy)
 {
  case PG_REGEX_LOCALE_C:
   return (c <= (pg_wchar) 127 &&
     (pg_char_properties[c] & 0x80));
  case PG_REGEX_LOCALE_WIDE:





  case PG_REGEX_LOCALE_1BYTE:
   return (c <= (pg_wchar) UCHAR_MAX &&
     isspace((unsigned char) c));
  case PG_REGEX_LOCALE_WIDE_L:





  case PG_REGEX_LOCALE_1BYTE_L:




   break;
 }
 return 0;
}

static pg_wchar
pg_wc_toupper(pg_wchar c)
{
 switch (pg_regex_strategy)
 {
  case PG_REGEX_LOCALE_C:
   if (c <= (pg_wchar) 127)
    return pg_ascii_toupper((unsigned char) c);
   return c;
  case PG_REGEX_LOCALE_WIDE:

   if (c <= (pg_wchar) 127)
    return pg_ascii_toupper((unsigned char) c);





  case PG_REGEX_LOCALE_1BYTE:

   if (c <= (pg_wchar) 127)
    return pg_ascii_toupper((unsigned char) c);
   if (c <= (pg_wchar) UCHAR_MAX)
    return toupper((unsigned char) c);
   return c;
  case PG_REGEX_LOCALE_WIDE_L:





  case PG_REGEX_LOCALE_1BYTE_L:




   return c;
 }
 return 0;
}

static pg_wchar
pg_wc_tolower(pg_wchar c)
{
 switch (pg_regex_strategy)
 {
  case PG_REGEX_LOCALE_C:
   if (c <= (pg_wchar) 127)
    return pg_ascii_tolower((unsigned char) c);
   return c;
  case PG_REGEX_LOCALE_WIDE:

   if (c <= (pg_wchar) 127)
    return pg_ascii_tolower((unsigned char) c);





  case PG_REGEX_LOCALE_1BYTE:

   if (c <= (pg_wchar) 127)
    return pg_ascii_tolower((unsigned char) c);
   if (c <= (pg_wchar) UCHAR_MAX)
    return tolower((unsigned char) c);
   return c;
  case PG_REGEX_LOCALE_WIDE_L:





  case PG_REGEX_LOCALE_1BYTE_L:




   return c;
 }
 return 0;
}
# 679 "regc_pg_locale.c"
typedef int (*pg_wc_probefunc) (pg_wchar c);

typedef struct pg_ctype_cache
{
 pg_wc_probefunc probefunc;
 Oid collation;
 struct cvec cv;
 struct pg_ctype_cache *next;
} pg_ctype_cache;

static pg_ctype_cache *pg_ctype_cache_list = ((void *)0);




static bool
store_match(pg_ctype_cache *pcc, pg_wchar chr1, int nchrs)
{
 chr *newchrs;

 if (nchrs > 1)
 {
  if (pcc->cv.nranges >= pcc->cv.rangespace)
  {
   pcc->cv.rangespace *= 2;
   newchrs = (chr *) realloc(pcc->cv.ranges,
           pcc->cv.rangespace * sizeof(chr) * 2);
   if (newchrs == ((void *)0))
    return false;
   pcc->cv.ranges = newchrs;
  }
  pcc->cv.ranges[pcc->cv.nranges * 2] = chr1;
  pcc->cv.ranges[pcc->cv.nranges * 2 + 1] = chr1 + nchrs - 1;
  pcc->cv.nranges++;
 }
 else
 {
  assert(nchrs == 1);
  if (pcc->cv.nchrs >= pcc->cv.chrspace)
  {
   pcc->cv.chrspace *= 2;
   newchrs = (chr *) realloc(pcc->cv.chrs,
           pcc->cv.chrspace * sizeof(chr));
   if (newchrs == ((void *)0))
    return false;
   pcc->cv.chrs = newchrs;
  }
  pcc->cv.chrs[pcc->cv.nchrs++] = chr1;
 }
 return true;
}
# 738 "regc_pg_locale.c"
static struct cvec *
pg_ctype_get_cache(pg_wc_probefunc probefunc)
{
 pg_ctype_cache *pcc;
 pg_wchar max_chr;
 pg_wchar cur_chr;
 int nmatches;
 chr *newchrs;




 for (pcc = pg_ctype_cache_list; pcc != ((void *)0); pcc = pcc->next)
 {
  if (pcc->probefunc == probefunc &&
   pcc->collation == pg_regex_collation)
   return &pcc->cv;
 }




 pcc = (pg_ctype_cache *) malloc(sizeof(pg_ctype_cache));
 if (pcc == ((void *)0))
  return ((void *)0);
 pcc->probefunc = probefunc;
 pcc->collation = pg_regex_collation;
 pcc->cv.nchrs = 0;
 pcc->cv.chrspace = 128;
 pcc->cv.chrs = (chr *) malloc(pcc->cv.chrspace * sizeof(chr));
 pcc->cv.nranges = 0;
 pcc->cv.rangespace = 64;
 pcc->cv.ranges = (chr *) malloc(pcc->cv.rangespace * sizeof(chr) * 2);
 if (pcc->cv.chrs == ((void *)0) || pcc->cv.ranges == ((void *)0))
  goto out_of_memory;
# 786 "regc_pg_locale.c"
 switch (pg_regex_strategy)
 {
  case PG_REGEX_LOCALE_C:
   max_chr = (pg_wchar) 127;
   break;
  case PG_REGEX_LOCALE_WIDE:
  case PG_REGEX_LOCALE_WIDE_L:
   max_chr = (pg_wchar) 0x7FF;
   break;
  case PG_REGEX_LOCALE_1BYTE:
  case PG_REGEX_LOCALE_1BYTE_L:
   max_chr = (pg_wchar) UCHAR_MAX;
   break;
  default:
   max_chr = 0;
   break;
 }




 nmatches = 0;

 for (cur_chr = 0; cur_chr <= max_chr; cur_chr++)
 {
  if ((*probefunc) (cur_chr))
   nmatches++;
  else if (nmatches > 0)
  {
   if (!store_match(pcc, cur_chr - nmatches, nmatches))
    goto out_of_memory;
   nmatches = 0;
  }
 }

 if (nmatches > 0)
  if (!store_match(pcc, cur_chr - nmatches, nmatches))
   goto out_of_memory;




 if (pcc->cv.nchrs == 0)
 {
  free(pcc->cv.chrs);
  pcc->cv.chrs = ((void *)0);
  pcc->cv.chrspace = 0;
 }
 else if (pcc->cv.nchrs < pcc->cv.chrspace)
 {
  newchrs = (chr *) realloc(pcc->cv.chrs,
          pcc->cv.nchrs * sizeof(chr));
  if (newchrs == ((void *)0))
   goto out_of_memory;
  pcc->cv.chrs = newchrs;
  pcc->cv.chrspace = pcc->cv.nchrs;
 }
 if (pcc->cv.nranges == 0)
 {
  free(pcc->cv.ranges);
  pcc->cv.ranges = ((void *)0);
  pcc->cv.rangespace = 0;
 }
 else if (pcc->cv.nranges < pcc->cv.rangespace)
 {
  newchrs = (chr *) realloc(pcc->cv.ranges,
          pcc->cv.nranges * sizeof(chr) * 2);
  if (newchrs == ((void *)0))
   goto out_of_memory;
  pcc->cv.ranges = newchrs;
  pcc->cv.rangespace = pcc->cv.nranges;
 }




 pcc->next = pg_ctype_cache_list;
 pg_ctype_cache_list = pcc;

 return &pcc->cv;




out_of_memory:
 if (pcc->cv.chrs)
  free(pcc->cv.chrs);
 if (pcc->cv.ranges)
  free(pcc->cv.ranges);
 free(pcc);

 return ((void *)0);
}

# 1 "regc_color.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "regc_color.c"
# 48 "regc_color.c"
static void
initcm(struct vars * v,
    struct colormap * cm)
{
 int i;
 int j;
 union tree *t;
 union tree *nextt;
 struct colordesc *cd;

 cm->magic = CMMAGIC;
 cm->v = v;

 cm->ncds = NINLINECDS;
 cm->cd = cm->cdspace;
 cm->max = 0;
 cm->free = 0;

 cd = cm->cd;
 cd->sub = NOSUB;
 cd->arcs = NULL;
 cd->firstchr = CHR_MIN;
 cd->nchrs = CHR_MAX - CHR_MIN + 1;
 cd->flags = 0;


 for (t = &cm->tree[0], j = NBYTS - 1; j > 0; t = nextt, j--)
 {
  nextt = t + 1;
  for (i = BYTTAB - 1; i >= 0; i--)
   t->tptr[i] = nextt;
 }

 t = &cm->tree[NBYTS - 1];
 for (i = BYTTAB - 1; i >= 0; i--)
  t->tcolor[i] = WHITE;
 cd->block = t;
}




static void
freecm(struct colormap * cm)
{
 size_t i;
 union tree *cb;

 cm->magic = 0;
 if (NBYTS > 1)
  cmtreefree(cm, cm->tree, 0);
 for (i = 1; i <= cm->max; i++)
  if (!UNUSEDCOLOR(&cm->cd[i]))
  {
   cb = cm->cd[i].block;
   if (cb != NULL)
    FREE(cb);
  }
 if (cm->cd != cm->cdspace)
  FREE(cm->cd);
}




static void
cmtreefree(struct colormap * cm,
     union tree * tree,
     int level)
{
 int i;
 union tree *t;
 union tree *fillt = &cm->tree[level + 1];
 union tree *cb;

 assert(level < NBYTS - 1);
 for (i = BYTTAB - 1; i >= 0; i--)
 {
  t = tree->tptr[i];
  assert(t != NULL);
  if (t != fillt)
  {
   if (level < NBYTS - 2)
   {
    cmtreefree(cm, t, level + 1);
    FREE(t);
   }
   else
   {
    cb = cm->cd[t->tcolor[0]].block;
    if (t != cb)
     FREE(t);
   }
  }
 }
}




static color
setcolor(struct colormap * cm,
   chr c,
   pcolor co)
{
 uchr uc = c;
 int shift;
 int level;
 int b;
 int bottom;
 union tree *t;
 union tree *newt;
 union tree *fillt;
 union tree *lastt;
 union tree *cb;
 color prev;

 assert(cm->magic == CMMAGIC);
 if (VISERR(cm->v) || co == COLORLESS)
  return COLORLESS;

 t = cm->tree;
 for (level = 0, shift = BYTBITS * (NBYTS - 1); shift > 0;
   level++, shift -= BYTBITS)
 {
  b = (uc >> shift) & BYTMASK;
  lastt = t;
  t = lastt->tptr[b];
  assert(t != NULL);
  fillt = &cm->tree[level + 1];
  bottom = (shift <= BYTBITS) ? 1 : 0;
  cb = (bottom) ? cm->cd[t->tcolor[0]].block : fillt;
  if (t == fillt || t == cb)
  {
   newt = (union tree *) MALLOC((bottom) ?
        sizeof(struct colors) : sizeof(struct ptrs));
   if (newt == NULL)
   {
    VERR(cm->v, (REG_ESPACE));
    return COLORLESS;
   }
   if (bottom)
    memcpy(VS(newt->tcolor), VS(t->tcolor),
        BYTTAB * sizeof(color));
   else
    memcpy(VS(newt->tptr), VS(t->tptr),
        BYTTAB * sizeof(union tree *));
   t = newt;
   lastt->tptr[b] = t;
  }
 }

 b = uc & BYTMASK;
 prev = t->tcolor[b];
 t->tcolor[b] = (color) co;
 return prev;
}




static color
maxcolor(struct colormap * cm)
{
 if (VISERR(cm->v))
  return COLORLESS;

 return (color) cm->max;
}





static color
newcolor(struct colormap * cm)
{
 struct colordesc *cd;
 size_t n;

 if (VISERR(cm->v))
  return COLORLESS;

 if (cm->free != 0)
 {
  assert(cm->free > 0);
  assert((size_t) cm->free < cm->ncds);
  cd = &cm->cd[cm->free];
  assert(UNUSEDCOLOR(cd));
  assert(cd->arcs == NULL);
  cm->free = cd->sub;
 }
 else if (cm->max < cm->ncds - 1)
 {
  cm->max++;
  cd = &cm->cd[cm->max];
 }
 else
 {

  struct colordesc *newCd;

  n = cm->ncds * 2;
  if (cm->cd == cm->cdspace)
  {
   newCd = (struct colordesc *) MALLOC(n * sizeof(struct colordesc));
   if (newCd != NULL)
    memcpy(VS(newCd), VS(cm->cdspace), cm->ncds *
        sizeof(struct colordesc));
  }
  else
   newCd = (struct colordesc *)
    REALLOC(cm->cd, n * sizeof(struct colordesc));
  if (newCd == NULL)
  {
   VERR(cm->v, (REG_ESPACE));
   return COLORLESS;
  }
  cm->cd = newCd;
  cm->ncds = n;
  assert(cm->max < cm->ncds - 1);
  cm->max++;
  cd = &cm->cd[cm->max];
 }

 cd->nchrs = 0;
 cd->sub = NOSUB;
 cd->arcs = NULL;
 cd->firstchr = CHR_MIN;
 cd->flags = 0;
 cd->block = NULL;

 return (color) (cd - cm->cd);
}




static void
freecolor(struct colormap * cm,
    pcolor co)
{
 struct colordesc *cd = &cm->cd[co];
 color pco,
    nco;

 assert(co >= 0);
 if (co == WHITE)
  return;

 assert(cd->arcs == NULL);
 assert(cd->sub == NOSUB);
 assert(cd->nchrs == 0);
 cd->flags = FREECOL;
 if (cd->block != NULL)
 {
  FREE(cd->block);
  cd->block = NULL;
 }

 if ((size_t) co == cm->max)
 {
  while (cm->max > WHITE && UNUSEDCOLOR(&cm->cd[cm->max]))
   cm->max--;
  assert(cm->free >= 0);
  while ((size_t) cm->free > cm->max)
   cm->free = cm->cd[cm->free].sub;
  if (cm->free > 0)
  {
   assert(cm->free < cm->max);
   pco = cm->free;
   nco = cm->cd[pco].sub;
   while (nco > 0)
    if ((size_t) nco > cm->max)
    {

     nco = cm->cd[nco].sub;
     cm->cd[pco].sub = nco;
    }
    else
    {
     assert(nco < cm->max);
     pco = nco;
     nco = cm->cd[pco].sub;
    }
  }
 }
 else
 {
  cd->sub = cm->free;
  cm->free = (color) (cd - cm->cd);
 }
}




static color
pseudocolor(struct colormap * cm)
{
 color co;

 co = newcolor(cm);
 if (VISERR(cm->v))
  return COLORLESS;
 cm->cd[co].nchrs = 1;
 cm->cd[co].flags = PSEUDO;
 return co;
}




static color
subcolor(struct colormap * cm, chr c)
{
 color co;
 color sco;

 co = GETCOLOR(cm, c);
 sco = newsub(cm, co);
 if (VISERR(cm->v))
  return COLORLESS;
 assert(sco != COLORLESS);

 if (co == sco)
  return co;
 cm->cd[co].nchrs--;
 if (cm->cd[sco].nchrs == 0)
  cm->cd[sco].firstchr = c;
 cm->cd[sco].nchrs++;
 setcolor(cm, c, sco);
 return sco;
}




static color
newsub(struct colormap * cm,
    pcolor co)
{
 color sco;

 sco = cm->cd[co].sub;
 if (sco == NOSUB)
 {
  if (cm->cd[co].nchrs == 1)
   return co;
  sco = newcolor(cm);
  if (sco == COLORLESS)
  {
   assert(VISERR(cm->v));
   return COLORLESS;
  }
  cm->cd[co].sub = sco;
  cm->cd[sco].sub = sco;
 }
 assert(sco != NOSUB);

 return sco;
}




static void
subrange(struct vars * v,
   chr from,
   chr to,
   struct state * lp,
   struct state * rp)
{
 uchr uf;
 int i;

 assert(from <= to);


 uf = (uchr) from;
 i = (int) (((uf + BYTTAB - 1) & (uchr) ~BYTMASK) - uf);
 for (; from <= to && i > 0; i--, from++)
  newarc(v->nfa, PLAIN, subcolor(v->cm, from), lp, rp);
 if (from > to)
  return;


 for (; to - from >= BYTTAB; from += BYTTAB)
  subblock(v, from, lp, rp);


 for (; from <= to; from++)
  newarc(v->nfa, PLAIN, subcolor(v->cm, from), lp, rp);
}
# 451 "regc_color.c"
static void
subblock(struct vars * v,
   chr start,
   struct state * lp,
   struct state * rp)
{
 uchr uc = start;
 struct colormap *cm = v->cm;
 int shift;
 int level;
 int i;
 int b;
 union tree *t;
 union tree *cb;
 union tree *fillt;
 union tree *lastt;
 int previ;
 int ndone;
 color co;
 color sco;

 assert((uc % BYTTAB) == 0);


 t = cm->tree;
 fillt = NULL;
 for (level = 0, shift = BYTBITS * (NBYTS - 1); shift > 0;
   level++, shift -= BYTBITS)
 {
  b = (uc >> shift) & BYTMASK;
  lastt = t;
  t = lastt->tptr[b];
  assert(t != NULL);
  fillt = &cm->tree[level + 1];
  if (t == fillt && shift > BYTBITS)
  {
   t = (union tree *) MALLOC(sizeof(struct ptrs));
   if (t == NULL)
   {
    VERR(cm->v, (REG_ESPACE));
    return;
   }
   memcpy(VS(t->tptr), VS(fillt->tptr),
       BYTTAB * sizeof(union tree *));
   lastt->tptr[b] = t;
  }
 }


 co = t->tcolor[0];
 cb = cm->cd[co].block;
 if (t == fillt || t == cb)
 {

  sco = newsub(cm, co);
  t = cm->cd[sco].block;
  if (t == NULL)
  {
   t = (union tree *) MALLOC(sizeof(struct colors));
   if (t == NULL)
   {
    VERR(cm->v, (REG_ESPACE));
    return;
   }
   for (i = 0; i < BYTTAB; i++)
    t->tcolor[i] = sco;
   cm->cd[sco].block = t;
  }

  lastt->tptr[b] = t;
  newarc(v->nfa, PLAIN, sco, lp, rp);
  cm->cd[co].nchrs -= BYTTAB;
  cm->cd[sco].nchrs += BYTTAB;
  return;
 }


 i = 0;
 while (i < BYTTAB)
 {
  co = t->tcolor[i];
  sco = newsub(cm, co);
  newarc(v->nfa, PLAIN, sco, lp, rp);
  previ = i;
  do
  {
   t->tcolor[i++] = sco;
  } while (i < BYTTAB && t->tcolor[i] == co);
  ndone = i - previ;
  cm->cd[co].nchrs -= ndone;
  cm->cd[sco].nchrs += ndone;
 }
}




static void
okcolors(struct nfa * nfa,
   struct colormap * cm)
{
 struct colordesc *cd;
 struct colordesc *end = CDEND(cm);
 struct colordesc *scd;
 struct arc *a;
 color co;
 color sco;

 for (cd = cm->cd, co = 0; cd < end; cd++, co++)
 {
  sco = cd->sub;
  if (UNUSEDCOLOR(cd) || sco == NOSUB)
  {

  }
  else if (sco == co)
  {

  }
  else if (cd->nchrs == 0)
  {

   cd->sub = NOSUB;
   scd = &cm->cd[sco];
   assert(scd->nchrs > 0);
   assert(scd->sub == sco);
   scd->sub = NOSUB;
   while ((a = cd->arcs) != NULL)
   {
    assert(a->co == co);
    uncolorchain(cm, a);
    a->co = sco;
    colorchain(cm, a);
   }
   freecolor(cm, co);
  }
  else
  {

   cd->sub = NOSUB;
   scd = &cm->cd[sco];
   assert(scd->nchrs > 0);
   assert(scd->sub == sco);
   scd->sub = NOSUB;
   for (a = cd->arcs; a != NULL; a = a->colorchain)
   {
    assert(a->co == co);
    newarc(nfa, a->type, sco, a->from, a->to);
   }
  }
 }
}




static void
colorchain(struct colormap * cm,
     struct arc * a)
{
 struct colordesc *cd = &cm->cd[a->co];

 if (cd->arcs != NULL)
  cd->arcs->colorchainRev = a;
 a->colorchain = cd->arcs;
 a->colorchainRev = NULL;
 cd->arcs = a;
}




static void
uncolorchain(struct colormap * cm,
    struct arc * a)
{
 struct colordesc *cd = &cm->cd[a->co];
 struct arc *aa = a->colorchainRev;

 if (aa == NULL)
 {
  assert(cd->arcs == a);
  cd->arcs = a->colorchain;
 }
 else
 {
  assert(aa->colorchain == a);
  aa->colorchain = a->colorchain;
 }
 if (a->colorchain != NULL)
  a->colorchain->colorchainRev = aa;
 a->colorchain = NULL;
 a->colorchainRev = NULL;
}




static void
rainbow(struct nfa * nfa,
  struct colormap * cm,
  int type,
  pcolor but,
  struct state * from,
  struct state * to)
{
 struct colordesc *cd;
 struct colordesc *end = CDEND(cm);
 color co;

 for (cd = cm->cd, co = 0; cd < end && !VISERR(cm->v); cd++, co++)
  if (!UNUSEDCOLOR(cd) && cd->sub != co && co != but &&
   !(cd->flags & PSEUDO))
   newarc(nfa, type, co, from, to);
}






static void
colorcomplement(struct nfa * nfa,
    struct colormap * cm,
    int type,
    struct state * of,

    struct state * from,
    struct state * to)
{
 struct colordesc *cd;
 struct colordesc *end = CDEND(cm);
 color co;

 assert(of != from);
 for (cd = cm->cd, co = 0; cd < end && !VISERR(cm->v); cd++, co++)
  if (!UNUSEDCOLOR(cd) && !(cd->flags & PSEUDO))
   if (findarc(of, PLAIN, co) == NULL)
    newarc(nfa, type, co, from, to);
}

# 1 "stem_ISO_8859_1_dutch.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "stem_ISO_8859_1_dutch.c"



# 1 "header.h" 1

# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 1 3 4






# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/syslimits.h" 1 3 4
# 8 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 2 3 4







# 1 "/usr/include/limits.h" 1 3 4
# 63 "/usr/include/limits.h" 3 4
# 1 "/usr/include/sys/cdefs.h" 1 3 4
# 417 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 418 "/usr/include/sys/cdefs.h" 2 3 4
# 494 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_posix_availability.h" 1 3 4
# 495 "/usr/include/sys/cdefs.h" 2 3 4
# 64 "/usr/include/limits.h" 2 3 4
# 1 "/usr/include/machine/limits.h" 1 3 4





# 1 "/usr/include/i386/limits.h" 1 3 4
# 40 "/usr/include/i386/limits.h" 3 4
# 1 "/usr/include/i386/_limits.h" 1 3 4
# 41 "/usr/include/i386/limits.h" 2 3 4
# 7 "/usr/include/machine/limits.h" 2 3 4
# 65 "/usr/include/limits.h" 2 3 4
# 1 "/usr/include/sys/syslimits.h" 1 3 4
# 66 "/usr/include/limits.h" 2 3 4
# 16 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 2 3 4
# 3 "header.h" 2

# 1 "api.h" 1

typedef unsigned char symbol;
# 14 "api.h"
struct SN_env {
    symbol * p;
    int c; int l; int lb; int bra; int ket;
    symbol * * S;
    int * I;
    unsigned char * B;
};

extern struct SN_env * SN_create_env(int S_size, int I_size, int B_size);
extern void SN_close_env(struct SN_env * z, int S_size);

extern int SN_set_current(struct SN_env * z, int size, const symbol * s);
# 5 "header.h" 2
# 15 "header.h"
struct among
{ int s_size;
    const symbol * s;
    int substring_i;
    int result;
    int (* function)(struct SN_env *);
};

extern symbol * create_s(void);
extern void lose_s(symbol * p);

extern int skip_utf8(const symbol * p, int c, int lb, int l, int n);

extern int in_grouping_U(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);
extern int in_grouping_b_U(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);
extern int out_grouping_U(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);
extern int out_grouping_b_U(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);

extern int in_grouping(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);
extern int in_grouping_b(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);
extern int out_grouping(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);
extern int out_grouping_b(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);

extern int eq_s(struct SN_env * z, int s_size, const symbol * s);
extern int eq_s_b(struct SN_env * z, int s_size, const symbol * s);
extern int eq_v(struct SN_env * z, const symbol * p);
extern int eq_v_b(struct SN_env * z, const symbol * p);

extern int find_among(struct SN_env * z, const struct among * v, int v_size);
extern int find_among_b(struct SN_env * z, const struct among * v, int v_size);

extern int replace_s(struct SN_env * z, int c_bra, int c_ket, int s_size, const symbol * s, int * adjustment);
extern int slice_from_s(struct SN_env * z, int s_size, const symbol * s);
extern int slice_from_v(struct SN_env * z, const symbol * p);
extern int slice_del(struct SN_env * z);

extern int insert_s(struct SN_env * z, int bra, int ket, int s_size, const symbol * s);
extern int insert_v(struct SN_env * z, int bra, int ket, const symbol * p);

extern symbol * slice_to(struct SN_env * z, symbol * p);
extern symbol * assign_to(struct SN_env * z, symbol * p);

extern void debug(struct SN_env * z, int number, int line_count);
# 5 "stem_ISO_8859_1_dutch.c" 2




extern int dutch_ISO_8859_1_stem(struct SN_env * z);



static int r_standard_suffix(struct SN_env * z);
static int r_undouble(struct SN_env * z);
static int r_R2(struct SN_env * z);
static int r_R1(struct SN_env * z);
static int r_mark_regions(struct SN_env * z);
static int r_en_ending(struct SN_env * z);
static int r_e_ending(struct SN_env * z);
static int r_postlude(struct SN_env * z);
static int r_prelude(struct SN_env * z);





extern struct SN_env * dutch_ISO_8859_1_create_env(void);
extern void dutch_ISO_8859_1_close_env(struct SN_env * z);





static const symbol s_0_1[1] = { 0xE1 };
static const symbol s_0_2[1] = { 0xE4 };
static const symbol s_0_3[1] = { 0xE9 };
static const symbol s_0_4[1] = { 0xEB };
static const symbol s_0_5[1] = { 0xED };
static const symbol s_0_6[1] = { 0xEF };
static const symbol s_0_7[1] = { 0xF3 };
static const symbol s_0_8[1] = { 0xF6 };
static const symbol s_0_9[1] = { 0xFA };
static const symbol s_0_10[1] = { 0xFC };

static const struct among a_0[11] =
{
         { 0, 0, -1, 6, 0},
         { 1, s_0_1, 0, 1, 0},
         { 1, s_0_2, 0, 1, 0},
         { 1, s_0_3, 0, 2, 0},
         { 1, s_0_4, 0, 2, 0},
         { 1, s_0_5, 0, 3, 0},
         { 1, s_0_6, 0, 3, 0},
         { 1, s_0_7, 0, 4, 0},
         { 1, s_0_8, 0, 4, 0},
         { 1, s_0_9, 0, 5, 0},
         { 1, s_0_10, 0, 5, 0}
};

static const symbol s_1_1[1] = { 'I' };
static const symbol s_1_2[1] = { 'Y' };

static const struct among a_1[3] =
{
         { 0, 0, -1, 3, 0},
         { 1, s_1_1, 0, 2, 0},
         { 1, s_1_2, 0, 1, 0}
};

static const symbol s_2_0[2] = { 'd', 'd' };
static const symbol s_2_1[2] = { 'k', 'k' };
static const symbol s_2_2[2] = { 't', 't' };

static const struct among a_2[3] =
{
         { 2, s_2_0, -1, -1, 0},
         { 2, s_2_1, -1, -1, 0},
         { 2, s_2_2, -1, -1, 0}
};

static const symbol s_3_0[3] = { 'e', 'n', 'e' };
static const symbol s_3_1[2] = { 's', 'e' };
static const symbol s_3_2[2] = { 'e', 'n' };
static const symbol s_3_3[5] = { 'h', 'e', 'd', 'e', 'n' };
static const symbol s_3_4[1] = { 's' };

static const struct among a_3[5] =
{
         { 3, s_3_0, -1, 2, 0},
         { 2, s_3_1, -1, 3, 0},
         { 2, s_3_2, -1, 2, 0},
         { 5, s_3_3, 2, 1, 0},
         { 1, s_3_4, -1, 3, 0}
};

static const symbol s_4_0[3] = { 'e', 'n', 'd' };
static const symbol s_4_1[2] = { 'i', 'g' };
static const symbol s_4_2[3] = { 'i', 'n', 'g' };
static const symbol s_4_3[4] = { 'l', 'i', 'j', 'k' };
static const symbol s_4_4[4] = { 'b', 'a', 'a', 'r' };
static const symbol s_4_5[3] = { 'b', 'a', 'r' };

static const struct among a_4[6] =
{
         { 3, s_4_0, -1, 1, 0},
         { 2, s_4_1, -1, 2, 0},
         { 3, s_4_2, -1, 1, 0},
         { 4, s_4_3, -1, 3, 0},
         { 4, s_4_4, -1, 4, 0},
         { 3, s_4_5, -1, 5, 0}
};

static const symbol s_5_0[2] = { 'a', 'a' };
static const symbol s_5_1[2] = { 'e', 'e' };
static const symbol s_5_2[2] = { 'o', 'o' };
static const symbol s_5_3[2] = { 'u', 'u' };

static const struct among a_5[4] =
{
         { 2, s_5_0, -1, -1, 0},
         { 2, s_5_1, -1, -1, 0},
         { 2, s_5_2, -1, -1, 0},
         { 2, s_5_3, -1, -1, 0}
};

static const unsigned char g_v[] = { 17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128 };

static const unsigned char g_v_I[] = { 1, 0, 0, 17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128 };

static const unsigned char g_v_j[] = { 17, 67, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128 };

static const symbol s_0[] = { 'a' };
static const symbol s_1[] = { 'e' };
static const symbol s_2[] = { 'i' };
static const symbol s_3[] = { 'o' };
static const symbol s_4[] = { 'u' };
static const symbol s_5[] = { 'y' };
static const symbol s_6[] = { 'Y' };
static const symbol s_7[] = { 'i' };
static const symbol s_8[] = { 'I' };
static const symbol s_9[] = { 'y' };
static const symbol s_10[] = { 'Y' };
static const symbol s_11[] = { 'y' };
static const symbol s_12[] = { 'i' };
static const symbol s_13[] = { 'e' };
static const symbol s_14[] = { 'g', 'e', 'm' };
static const symbol s_15[] = { 'h', 'e', 'i', 'd' };
static const symbol s_16[] = { 'h', 'e', 'i', 'd' };
static const symbol s_17[] = { 'c' };
static const symbol s_18[] = { 'e', 'n' };
static const symbol s_19[] = { 'i', 'g' };
static const symbol s_20[] = { 'e' };
static const symbol s_21[] = { 'e' };

static int r_prelude(struct SN_env * z) {
    int among_var;
    { int c_test = z->c;
        while(1) {
            int c1 = z->c;
            z->bra = z->c;
            if (z->c >= z->l || z->p[z->c + 0] >> 5 != 7 || !((340306450 >> (z->p[z->c + 0] & 0x1f)) & 1)) among_var = 6; else
            among_var = find_among(z, a_0, 11);
            if (!(among_var)) goto lab0;
            z->ket = z->c;
            switch(among_var) {
                case 0: goto lab0;
                case 1:
                    { int ret = slice_from_s(z, 1, s_0);
                        if (ret < 0) return ret;
                    }
                    break;
                case 2:
                    { int ret = slice_from_s(z, 1, s_1);
                        if (ret < 0) return ret;
                    }
                    break;
                case 3:
                    { int ret = slice_from_s(z, 1, s_2);
                        if (ret < 0) return ret;
                    }
                    break;
                case 4:
                    { int ret = slice_from_s(z, 1, s_3);
                        if (ret < 0) return ret;
                    }
                    break;
                case 5:
                    { int ret = slice_from_s(z, 1, s_4);
                        if (ret < 0) return ret;
                    }
                    break;
                case 6:
                    if (z->c >= z->l) goto lab0;
                    z->c++;
                    break;
            }
            continue;
        lab0:
            z->c = c1;
            break;
        }
        z->c = c_test;
    }
    { int c_keep = z->c;
        z->bra = z->c;
        if (!(eq_s(z, 1, s_5))) { z->c = c_keep; goto lab1; }
        z->ket = z->c;
        { int ret = slice_from_s(z, 1, s_6);
            if (ret < 0) return ret;
        }
    lab1:
        ;
    }
    while(1) {
        int c2 = z->c;
        while(1) {
            int c3 = z->c;
            if (in_grouping(z, g_v, 97, 232, 0)) goto lab3;
            z->bra = z->c;
            { int c4 = z->c;
                if (!(eq_s(z, 1, s_7))) goto lab5;
                z->ket = z->c;
                if (in_grouping(z, g_v, 97, 232, 0)) goto lab5;
                { int ret = slice_from_s(z, 1, s_8);
                    if (ret < 0) return ret;
                }
                goto lab4;
            lab5:
                z->c = c4;
                if (!(eq_s(z, 1, s_9))) goto lab3;
                z->ket = z->c;
                { int ret = slice_from_s(z, 1, s_10);
                    if (ret < 0) return ret;
                }
            }
        lab4:
            z->c = c3;
            break;
        lab3:
            z->c = c3;
            if (z->c >= z->l) goto lab2;
            z->c++;
        }
        continue;
    lab2:
        z->c = c2;
        break;
    }
    return 1;
}

static int r_mark_regions(struct SN_env * z) {
    z->I[0] = z->l;
    z->I[1] = z->l;
    {
        int ret = out_grouping(z, g_v, 97, 232, 1);
        if (ret < 0) return 0;
        z->c += ret;
    }
    {
        int ret = in_grouping(z, g_v, 97, 232, 1);
        if (ret < 0) return 0;
        z->c += ret;
    }
    z->I[0] = z->c;

    if (!(z->I[0] < 3)) goto lab0;
    z->I[0] = 3;
lab0:
    {
        int ret = out_grouping(z, g_v, 97, 232, 1);
        if (ret < 0) return 0;
        z->c += ret;
    }
    {
        int ret = in_grouping(z, g_v, 97, 232, 1);
        if (ret < 0) return 0;
        z->c += ret;
    }
    z->I[1] = z->c;
    return 1;
}

static int r_postlude(struct SN_env * z) {
    int among_var;
    while(1) {
        int c1 = z->c;
        z->bra = z->c;
        if (z->c >= z->l || (z->p[z->c + 0] != 73 && z->p[z->c + 0] != 89)) among_var = 3; else
        among_var = find_among(z, a_1, 3);
        if (!(among_var)) goto lab0;
        z->ket = z->c;
        switch(among_var) {
            case 0: goto lab0;
            case 1:
                { int ret = slice_from_s(z, 1, s_11);
                    if (ret < 0) return ret;
                }
                break;
            case 2:
                { int ret = slice_from_s(z, 1, s_12);
                    if (ret < 0) return ret;
                }
                break;
            case 3:
                if (z->c >= z->l) goto lab0;
                z->c++;
                break;
        }
        continue;
    lab0:
        z->c = c1;
        break;
    }
    return 1;
}

static int r_R1(struct SN_env * z) {
    if (!(z->I[0] <= z->c)) return 0;
    return 1;
}

static int r_R2(struct SN_env * z) {
    if (!(z->I[1] <= z->c)) return 0;
    return 1;
}

static int r_undouble(struct SN_env * z) {
    { int m_test = z->l - z->c;
        if (z->c - 1 <= z->lb || z->p[z->c - 1] >> 5 != 3 || !((1050640 >> (z->p[z->c - 1] & 0x1f)) & 1)) return 0;
        if (!(find_among_b(z, a_2, 3))) return 0;
        z->c = z->l - m_test;
    }
    z->ket = z->c;
    if (z->c <= z->lb) return 0;
    z->c--;
    z->bra = z->c;
    { int ret = slice_del(z);
        if (ret < 0) return ret;
    }
    return 1;
}

static int r_e_ending(struct SN_env * z) {
    z->B[0] = 0;
    z->ket = z->c;
    if (!(eq_s_b(z, 1, s_13))) return 0;
    z->bra = z->c;
    { int ret = r_R1(z);
        if (ret == 0) return 0;
        if (ret < 0) return ret;
    }
    { int m_test = z->l - z->c;
        if (out_grouping_b(z, g_v, 97, 232, 0)) return 0;
        z->c = z->l - m_test;
    }
    { int ret = slice_del(z);
        if (ret < 0) return ret;
    }
    z->B[0] = 1;
    { int ret = r_undouble(z);
        if (ret == 0) return 0;
        if (ret < 0) return ret;
    }
    return 1;
}

static int r_en_ending(struct SN_env * z) {
    { int ret = r_R1(z);
        if (ret == 0) return 0;
        if (ret < 0) return ret;
    }
    { int m1 = z->l - z->c; (void)m1;
        if (out_grouping_b(z, g_v, 97, 232, 0)) return 0;
        z->c = z->l - m1;
        { int m2 = z->l - z->c; (void)m2;
            if (!(eq_s_b(z, 3, s_14))) goto lab0;
            return 0;
        lab0:
            z->c = z->l - m2;
        }
    }
    { int ret = slice_del(z);
        if (ret < 0) return ret;
    }
    { int ret = r_undouble(z);
        if (ret == 0) return 0;
        if (ret < 0) return ret;
    }
    return 1;
}

static int r_standard_suffix(struct SN_env * z) {
    int among_var;
    { int m1 = z->l - z->c; (void)m1;
        z->ket = z->c;
        if (z->c <= z->lb || z->p[z->c - 1] >> 5 != 3 || !((540704 >> (z->p[z->c - 1] & 0x1f)) & 1)) goto lab0;
        among_var = find_among_b(z, a_3, 5);
        if (!(among_var)) goto lab0;
        z->bra = z->c;
        switch(among_var) {
            case 0: goto lab0;
            case 1:
                { int ret = r_R1(z);
                    if (ret == 0) goto lab0;
                    if (ret < 0) return ret;
                }
                { int ret = slice_from_s(z, 4, s_15);
                    if (ret < 0) return ret;
                }
                break;
            case 2:
                { int ret = r_en_ending(z);
                    if (ret == 0) goto lab0;
                    if (ret < 0) return ret;
                }
                break;
            case 3:
                { int ret = r_R1(z);
                    if (ret == 0) goto lab0;
                    if (ret < 0) return ret;
                }
                if (out_grouping_b(z, g_v_j, 97, 232, 0)) goto lab0;
                { int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                break;
        }
    lab0:
        z->c = z->l - m1;
    }
    { int m2 = z->l - z->c; (void)m2;
        { int ret = r_e_ending(z);
            if (ret == 0) goto lab1;
            if (ret < 0) return ret;
        }
    lab1:
        z->c = z->l - m2;
    }
    { int m3 = z->l - z->c; (void)m3;
        z->ket = z->c;
        if (!(eq_s_b(z, 4, s_16))) goto lab2;
        z->bra = z->c;
        { int ret = r_R2(z);
            if (ret == 0) goto lab2;
            if (ret < 0) return ret;
        }
        { int m4 = z->l - z->c; (void)m4;
            if (!(eq_s_b(z, 1, s_17))) goto lab3;
            goto lab2;
        lab3:
            z->c = z->l - m4;
        }
        { int ret = slice_del(z);
            if (ret < 0) return ret;
        }
        z->ket = z->c;
        if (!(eq_s_b(z, 2, s_18))) goto lab2;
        z->bra = z->c;
        { int ret = r_en_ending(z);
            if (ret == 0) goto lab2;
            if (ret < 0) return ret;
        }
    lab2:
        z->c = z->l - m3;
    }
    { int m5 = z->l - z->c; (void)m5;
        z->ket = z->c;
        if (z->c - 1 <= z->lb || z->p[z->c - 1] >> 5 != 3 || !((264336 >> (z->p[z->c - 1] & 0x1f)) & 1)) goto lab4;
        among_var = find_among_b(z, a_4, 6);
        if (!(among_var)) goto lab4;
        z->bra = z->c;
        switch(among_var) {
            case 0: goto lab4;
            case 1:
                { int ret = r_R2(z);
                    if (ret == 0) goto lab4;
                    if (ret < 0) return ret;
                }
                { int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                { int m6 = z->l - z->c; (void)m6;
                    z->ket = z->c;
                    if (!(eq_s_b(z, 2, s_19))) goto lab6;
                    z->bra = z->c;
                    { int ret = r_R2(z);
                        if (ret == 0) goto lab6;
                        if (ret < 0) return ret;
                    }
                    { int m7 = z->l - z->c; (void)m7;
                        if (!(eq_s_b(z, 1, s_20))) goto lab7;
                        goto lab6;
                    lab7:
                        z->c = z->l - m7;
                    }
                    { int ret = slice_del(z);
                        if (ret < 0) return ret;
                    }
                    goto lab5;
                lab6:
                    z->c = z->l - m6;
                    { int ret = r_undouble(z);
                        if (ret == 0) goto lab4;
                        if (ret < 0) return ret;
                    }
                }
            lab5:
                break;
            case 2:
                { int ret = r_R2(z);
                    if (ret == 0) goto lab4;
                    if (ret < 0) return ret;
                }
                { int m8 = z->l - z->c; (void)m8;
                    if (!(eq_s_b(z, 1, s_21))) goto lab8;
                    goto lab4;
                lab8:
                    z->c = z->l - m8;
                }
                { int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                break;
            case 3:
                { int ret = r_R2(z);
                    if (ret == 0) goto lab4;
                    if (ret < 0) return ret;
                }
                { int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                { int ret = r_e_ending(z);
                    if (ret == 0) goto lab4;
                    if (ret < 0) return ret;
                }
                break;
            case 4:
                { int ret = r_R2(z);
                    if (ret == 0) goto lab4;
                    if (ret < 0) return ret;
                }
                { int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                break;
            case 5:
                { int ret = r_R2(z);
                    if (ret == 0) goto lab4;
                    if (ret < 0) return ret;
                }
                if (!(z->B[0])) goto lab4;
                { int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                break;
        }
    lab4:
        z->c = z->l - m5;
    }
    { int m9 = z->l - z->c; (void)m9;
        if (out_grouping_b(z, g_v_I, 73, 232, 0)) goto lab9;
        { int m_test = z->l - z->c;
            if (z->c - 1 <= z->lb || z->p[z->c - 1] >> 5 != 3 || !((2129954 >> (z->p[z->c - 1] & 0x1f)) & 1)) goto lab9;
            if (!(find_among_b(z, a_5, 4))) goto lab9;
            if (out_grouping_b(z, g_v, 97, 232, 0)) goto lab9;
            z->c = z->l - m_test;
        }
        z->ket = z->c;
        if (z->c <= z->lb) goto lab9;
        z->c--;
        z->bra = z->c;
        { int ret = slice_del(z);
            if (ret < 0) return ret;
        }
    lab9:
        z->c = z->l - m9;
    }
    return 1;
}

extern int dutch_ISO_8859_1_stem(struct SN_env * z) {
    { int c1 = z->c;
        { int ret = r_prelude(z);
            if (ret == 0) goto lab0;
            if (ret < 0) return ret;
        }
    lab0:
        z->c = c1;
    }
    { int c2 = z->c;
        { int ret = r_mark_regions(z);
            if (ret == 0) goto lab1;
            if (ret < 0) return ret;
        }
    lab1:
        z->c = c2;
    }
    z->lb = z->c; z->c = z->l;

    { int m3 = z->l - z->c; (void)m3;
        { int ret = r_standard_suffix(z);
            if (ret == 0) goto lab2;
            if (ret < 0) return ret;
        }
    lab2:
        z->c = z->l - m3;
    }
    z->c = z->lb;
    { int c4 = z->c;
        { int ret = r_postlude(z);
            if (ret == 0) goto lab3;
            if (ret < 0) return ret;
        }
    lab3:
        z->c = c4;
    }
    return 1;
}

extern struct SN_env * dutch_ISO_8859_1_create_env(void) { return SN_create_env(0, 2, 1); }

extern void dutch_ISO_8859_1_close_env(struct SN_env * z) { SN_close_env(z, 0); }

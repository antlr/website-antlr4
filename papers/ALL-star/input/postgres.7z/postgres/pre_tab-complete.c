# 1 "tab-complete.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "tab-complete.c"
# 44 "tab-complete.c"
# 1 "postgres_fe.h" 1
# 25 "postgres_fe.h"
# 1 "c.h" 1
# 53 "c.h"
# 1 "pg_config.h" 1
# 54 "c.h" 2
# 1 "pg_config_manual.h" 1
# 55 "c.h" 2


# 1 "pg_config_os.h" 1
# 58 "c.h" 2

# 1 "postgres_ext.h" 1
# 29 "postgres_ext.h"
typedef unsigned int Oid;
# 60 "c.h" 2







# 1 "/usr/include/stdio.h" 1 3 4
# 64 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/sys/cdefs.h" 1 3 4
# 417 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 418 "/usr/include/sys/cdefs.h" 2 3 4
# 494 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_posix_availability.h" 1 3 4
# 495 "/usr/include/sys/cdefs.h" 2 3 4
# 65 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/Availability.h" 1 3 4
# 141 "/usr/include/Availability.h" 3 4
# 1 "/usr/include/AvailabilityInternal.h" 1 3 4
# 142 "/usr/include/Availability.h" 2 3 4
# 66 "/usr/include/stdio.h" 2 3 4

# 1 "/usr/include/_types.h" 1 3 4
# 27 "/usr/include/_types.h" 3 4
# 1 "/usr/include/sys/_types.h" 1 3 4
# 33 "/usr/include/sys/_types.h" 3 4
# 1 "/usr/include/machine/_types.h" 1 3 4
# 32 "/usr/include/machine/_types.h" 3 4
# 1 "/usr/include/i386/_types.h" 1 3 4
# 37 "/usr/include/i386/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 70 "/usr/include/i386/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;


typedef long int __darwin_ptrdiff_t;





typedef long unsigned int __darwin_size_t;





typedef __builtin_va_list __darwin_va_list;





typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 33 "/usr/include/machine/_types.h" 2 3 4
# 34 "/usr/include/sys/_types.h" 2 3 4
# 58 "/usr/include/sys/_types.h" 3 4
struct __darwin_pthread_handler_rec
{
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};
struct _opaque_pthread_attr_t { long __sig; char __opaque[56]; };
struct _opaque_pthread_cond_t { long __sig; char __opaque[40]; };
struct _opaque_pthread_condattr_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_mutex_t { long __sig; char __opaque[56]; };
struct _opaque_pthread_mutexattr_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_once_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_rwlock_t { long __sig; char __opaque[192]; };
struct _opaque_pthread_rwlockattr_t { long __sig; char __opaque[16]; };
struct _opaque_pthread_t { long __sig; struct __darwin_pthread_handler_rec *__cleanup_stack; char __opaque[1168]; };
# 94 "/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef struct _opaque_pthread_attr_t
   __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t
   __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t
   __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t
   __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t
   __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t
   __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t
   __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t
   __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t
   *__darwin_pthread_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];
# 28 "/usr/include/_types.h" 2 3 4
# 39 "/usr/include/_types.h" 3 4
typedef int __darwin_nl_item;
typedef int __darwin_wctrans_t;

typedef __uint32_t __darwin_wctype_t;
# 68 "/usr/include/stdio.h" 2 3 4





typedef __darwin_va_list va_list;




typedef __darwin_size_t size_t;






typedef __darwin_off_t fpos_t;
# 96 "/usr/include/stdio.h" 3 4
struct __sbuf {
 unsigned char *_base;
 int _size;
};


struct __sFILEX;
# 130 "/usr/include/stdio.h" 3 4
typedef struct __sFILE {
 unsigned char *_p;
 int _r;
 int _w;
 short _flags;
 short _file;
 struct __sbuf _bf;
 int _lbfsize;


 void *_cookie;
 int (*_close)(void *);
 int (*_read) (void *, char *, int);
 fpos_t (*_seek) (void *, fpos_t, int);
 int (*_write)(void *, const char *, int);


 struct __sbuf _ub;
 struct __sFILEX *_extra;
 int _ur;


 unsigned char _ubuf[3];
 unsigned char _nbuf[1];


 struct __sbuf _lb;


 int _blksize;
 fpos_t _offset;
} FILE;


extern FILE *__stdinp;
extern FILE *__stdoutp;
extern FILE *__stderrp;

# 238 "/usr/include/stdio.h" 3 4

void clearerr(FILE *);
int fclose(FILE *);
int feof(FILE *);
int ferror(FILE *);
int fflush(FILE *);
int fgetc(FILE *);
int fgetpos(FILE * , fpos_t *);
char *fgets(char * , int, FILE *);



FILE *fopen(const char * , const char * ) __asm("_" "fopen" );

int fprintf(FILE * , const char * , ...) __attribute__((__format__ (__printf__, 2, 3)));
int fputc(int, FILE *);
int fputs(const char * , FILE * ) __asm("_" "fputs" );
size_t fread(void * , size_t, size_t, FILE * );
FILE *freopen(const char * , const char * ,
                 FILE * ) __asm("_" "freopen" );
int fscanf(FILE * , const char * , ...) __attribute__((__format__ (__scanf__, 2, 3)));
int fseek(FILE *, long, int);
int fsetpos(FILE *, const fpos_t *);
long ftell(FILE *);
size_t fwrite(const void * , size_t, size_t, FILE * ) __asm("_" "fwrite" );
int getc(FILE *);
int getchar(void);
char *gets(char *);
void perror(const char *);
int printf(const char * , ...) __attribute__((__format__ (__printf__, 1, 2)));
int putc(int, FILE *);
int putchar(int);
int puts(const char *);
int remove(const char *);
int rename (const char *, const char *);
void rewind(FILE *);
int scanf(const char * , ...) __attribute__((__format__ (__scanf__, 1, 2)));
void setbuf(FILE * , char * );
int setvbuf(FILE * , char * , int, size_t);
int sprintf(char * , const char * , ...) __attribute__((__format__ (__printf__, 2, 3)));
int sscanf(const char * , const char * , ...) __attribute__((__format__ (__scanf__, 2, 3)));
FILE *tmpfile(void);
char *tmpnam(char *);
int ungetc(int, FILE *);
int vfprintf(FILE * , const char * , va_list) __attribute__((__format__ (__printf__, 2, 0)));
int vprintf(const char * , va_list) __attribute__((__format__ (__printf__, 1, 0)));
int vsprintf(char * , const char * , va_list) __attribute__((__format__ (__printf__, 2, 0)));

# 296 "/usr/include/stdio.h" 3 4




char *ctermid(char *);





FILE *fdopen(int, const char *) __asm("_" "fdopen" );

int fileno(FILE *);

# 318 "/usr/include/stdio.h" 3 4

int pclose(FILE *);



FILE *popen(const char *, const char *) __asm("_" "popen" );


# 340 "/usr/include/stdio.h" 3 4

int __srget(FILE *);
int __svfscanf(FILE *, const char *, va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int __swbuf(int, FILE *);








static __inline int __sputc(int _c, FILE *_p) {
 if (--_p->_w >= 0 || (_p->_w >= _p->_lbfsize && (char)_c != '\n'))
  return (*_p->_p++ = _c);
 else
  return (__swbuf(_c, _p));
}
# 377 "/usr/include/stdio.h" 3 4

void flockfile(FILE *);
int ftrylockfile(FILE *);
void funlockfile(FILE *);
int getc_unlocked(FILE *);
int getchar_unlocked(void);
int putc_unlocked(int, FILE *);
int putchar_unlocked(int);



int getw(FILE *);
int putw(int, FILE *);


char *tempnam(const char *, const char *) __asm("_" "tempnam" );

# 414 "/usr/include/stdio.h" 3 4
typedef __darwin_off_t off_t;



int fseeko(FILE *, off_t, int);
off_t ftello(FILE *);





int snprintf(char * , size_t, const char * , ...) __attribute__((__format__ (__printf__, 3, 4)));
int vfscanf(FILE * , const char * , va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int vscanf(const char * , va_list) __attribute__((__format__ (__scanf__, 1, 0)));
int vsnprintf(char * , size_t, const char * , va_list) __attribute__((__format__ (__printf__, 3, 0)));
int vsscanf(const char * , const char * , va_list) __attribute__((__format__ (__scanf__, 2, 0)));

# 442 "/usr/include/stdio.h" 3 4
typedef __darwin_ssize_t ssize_t;



int dprintf(int, const char * , ...) __attribute__((__format__ (__printf__, 2, 3))) __attribute__((visibility("default")));
int vdprintf(int, const char * , va_list) __attribute__((__format__ (__printf__, 2, 0))) __attribute__((visibility("default")));
ssize_t getdelim(char ** , size_t * , int, FILE * ) __attribute__((visibility("default")));
ssize_t getline(char ** , size_t * , FILE * ) __attribute__((visibility("default")));









extern const int sys_nerr;
extern const char *const sys_errlist[];

int asprintf(char **, const char *, ...) __attribute__((__format__ (__printf__, 2, 3)));
char *ctermid_r(char *);
char *fgetln(FILE *, size_t *);
const char *fmtcheck(const char *, const char *);
int fpurge(FILE *);
void setbuffer(FILE *, char *, int);
int setlinebuf(FILE *);
int vasprintf(char **, const char *, va_list) __attribute__((__format__ (__printf__, 2, 0)));
FILE *zopen(const char *, const char *, int);





FILE *funopen(const void *,
                 int (*)(void *, char *, int),
                 int (*)(void *, const char *, int),
                 fpos_t (*)(void *, fpos_t, int),
                 int (*)(void *));

# 499 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/secure/_stdio.h" 1 3 4
# 31 "/usr/include/secure/_stdio.h" 3 4
# 1 "/usr/include/secure/_common.h" 1 3 4
# 32 "/usr/include/secure/_stdio.h" 2 3 4
# 45 "/usr/include/secure/_stdio.h" 3 4
extern int __sprintf_chk (char * , int, size_t,
     const char * , ...)
  ;




extern int __snprintf_chk (char * , size_t, int, size_t,
      const char * , ...)
  ;





extern int __vsprintf_chk (char * , int, size_t,
      const char * , va_list)
  ;




extern int __vsnprintf_chk (char * , size_t, int, size_t,
       const char * , va_list)
  ;
# 500 "/usr/include/stdio.h" 2 3 4
# 68 "c.h" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 65 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/sys/wait.h" 1 3 4
# 79 "/usr/include/sys/wait.h" 3 4
typedef enum {
 P_ALL,
 P_PID,
 P_PGID
} idtype_t;






typedef __darwin_pid_t pid_t;




typedef __darwin_id_t id_t;
# 116 "/usr/include/sys/wait.h" 3 4
# 1 "/usr/include/sys/signal.h" 1 3 4
# 73 "/usr/include/sys/signal.h" 3 4
# 1 "/usr/include/sys/appleapiopts.h" 1 3 4
# 74 "/usr/include/sys/signal.h" 2 3 4







# 1 "/usr/include/machine/signal.h" 1 3 4
# 32 "/usr/include/machine/signal.h" 3 4
# 1 "/usr/include/i386/signal.h" 1 3 4
# 39 "/usr/include/i386/signal.h" 3 4
typedef int sig_atomic_t;
# 55 "/usr/include/i386/signal.h" 3 4
# 1 "/usr/include/i386/_structs.h" 1 3 4
# 56 "/usr/include/i386/signal.h" 2 3 4
# 33 "/usr/include/machine/signal.h" 2 3 4
# 82 "/usr/include/sys/signal.h" 2 3 4
# 148 "/usr/include/sys/signal.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 57 "/usr/include/sys/_structs.h" 3 4
# 1 "/usr/include/machine/_structs.h" 1 3 4
# 29 "/usr/include/machine/_structs.h" 3 4
# 1 "/usr/include/i386/_structs.h" 1 3 4
# 38 "/usr/include/i386/_structs.h" 3 4
# 1 "/usr/include/mach/i386/_structs.h" 1 3 4
# 43 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_thread_state
{
    unsigned int __eax;
    unsigned int __ebx;
    unsigned int __ecx;
    unsigned int __edx;
    unsigned int __edi;
    unsigned int __esi;
    unsigned int __ebp;
    unsigned int __esp;
    unsigned int __ss;
    unsigned int __eflags;
    unsigned int __eip;
    unsigned int __cs;
    unsigned int __ds;
    unsigned int __es;
    unsigned int __fs;
    unsigned int __gs;
};
# 89 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_fp_control
{
    unsigned short __invalid :1,
        __denorm :1,
    __zdiv :1,
    __ovrfl :1,
    __undfl :1,
    __precis :1,
      :2,
    __pc :2,





    __rc :2,






             :1,
      :3;
};
typedef struct __darwin_fp_control __darwin_fp_control_t;
# 147 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_fp_status
{
    unsigned short __invalid :1,
        __denorm :1,
    __zdiv :1,
    __ovrfl :1,
    __undfl :1,
    __precis :1,
    __stkflt :1,
    __errsumm :1,
    __c0 :1,
    __c1 :1,
    __c2 :1,
    __tos :3,
    __c3 :1,
    __busy :1;
};
typedef struct __darwin_fp_status __darwin_fp_status_t;
# 191 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_mmst_reg
{
 char __mmst_reg[10];
 char __mmst_rsrv[6];
};
# 210 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_xmm_reg
{
 char __xmm_reg[16];
};
# 232 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_float_state
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;
 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;
 __uint16_t __fpu_rsrv2;
 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;
 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 char __fpu_rsrv4[14*16];
 int __fpu_reserved1;
};


struct __darwin_i386_avx_state
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;
 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;
 __uint16_t __fpu_rsrv2;
 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;
 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 char __fpu_rsrv4[14*16];
 int __fpu_reserved1;
 char __avx_reserved1[64];
 struct __darwin_xmm_reg __fpu_ymmh0;
 struct __darwin_xmm_reg __fpu_ymmh1;
 struct __darwin_xmm_reg __fpu_ymmh2;
 struct __darwin_xmm_reg __fpu_ymmh3;
 struct __darwin_xmm_reg __fpu_ymmh4;
 struct __darwin_xmm_reg __fpu_ymmh5;
 struct __darwin_xmm_reg __fpu_ymmh6;
 struct __darwin_xmm_reg __fpu_ymmh7;
};
# 402 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_exception_state
{
 __uint16_t __trapno;
 __uint16_t __cpu;
 __uint32_t __err;
 __uint32_t __faultvaddr;
};
# 422 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_debug_state32
{
 unsigned int __dr0;
 unsigned int __dr1;
 unsigned int __dr2;
 unsigned int __dr3;
 unsigned int __dr4;
 unsigned int __dr5;
 unsigned int __dr6;
 unsigned int __dr7;
};
# 454 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_thread_state64
{
 __uint64_t __rax;
 __uint64_t __rbx;
 __uint64_t __rcx;
 __uint64_t __rdx;
 __uint64_t __rdi;
 __uint64_t __rsi;
 __uint64_t __rbp;
 __uint64_t __rsp;
 __uint64_t __r8;
 __uint64_t __r9;
 __uint64_t __r10;
 __uint64_t __r11;
 __uint64_t __r12;
 __uint64_t __r13;
 __uint64_t __r14;
 __uint64_t __r15;
 __uint64_t __rip;
 __uint64_t __rflags;
 __uint64_t __cs;
 __uint64_t __fs;
 __uint64_t __gs;
};
# 509 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_float_state64
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;


 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;

 __uint16_t __fpu_rsrv2;


 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;

 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 struct __darwin_xmm_reg __fpu_xmm8;
 struct __darwin_xmm_reg __fpu_xmm9;
 struct __darwin_xmm_reg __fpu_xmm10;
 struct __darwin_xmm_reg __fpu_xmm11;
 struct __darwin_xmm_reg __fpu_xmm12;
 struct __darwin_xmm_reg __fpu_xmm13;
 struct __darwin_xmm_reg __fpu_xmm14;
 struct __darwin_xmm_reg __fpu_xmm15;
 char __fpu_rsrv4[6*16];
 int __fpu_reserved1;
};


struct __darwin_x86_avx_state64
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;


 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;

 __uint16_t __fpu_rsrv2;


 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;

 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 struct __darwin_xmm_reg __fpu_xmm8;
 struct __darwin_xmm_reg __fpu_xmm9;
 struct __darwin_xmm_reg __fpu_xmm10;
 struct __darwin_xmm_reg __fpu_xmm11;
 struct __darwin_xmm_reg __fpu_xmm12;
 struct __darwin_xmm_reg __fpu_xmm13;
 struct __darwin_xmm_reg __fpu_xmm14;
 struct __darwin_xmm_reg __fpu_xmm15;
 char __fpu_rsrv4[6*16];
 int __fpu_reserved1;
 char __avx_reserved1[64];
 struct __darwin_xmm_reg __fpu_ymmh0;
 struct __darwin_xmm_reg __fpu_ymmh1;
 struct __darwin_xmm_reg __fpu_ymmh2;
 struct __darwin_xmm_reg __fpu_ymmh3;
 struct __darwin_xmm_reg __fpu_ymmh4;
 struct __darwin_xmm_reg __fpu_ymmh5;
 struct __darwin_xmm_reg __fpu_ymmh6;
 struct __darwin_xmm_reg __fpu_ymmh7;
 struct __darwin_xmm_reg __fpu_ymmh8;
 struct __darwin_xmm_reg __fpu_ymmh9;
 struct __darwin_xmm_reg __fpu_ymmh10;
 struct __darwin_xmm_reg __fpu_ymmh11;
 struct __darwin_xmm_reg __fpu_ymmh12;
 struct __darwin_xmm_reg __fpu_ymmh13;
 struct __darwin_xmm_reg __fpu_ymmh14;
 struct __darwin_xmm_reg __fpu_ymmh15;
};
# 751 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_exception_state64
{
    __uint16_t __trapno;
    __uint16_t __cpu;
    __uint32_t __err;
    __uint64_t __faultvaddr;
};
# 771 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_debug_state64
{
 __uint64_t __dr0;
 __uint64_t __dr1;
 __uint64_t __dr2;
 __uint64_t __dr3;
 __uint64_t __dr4;
 __uint64_t __dr5;
 __uint64_t __dr6;
 __uint64_t __dr7;
};
# 39 "/usr/include/i386/_structs.h" 2 3 4
# 48 "/usr/include/i386/_structs.h" 3 4
struct __darwin_mcontext32
{
 struct __darwin_i386_exception_state __es;
 struct __darwin_i386_thread_state __ss;
 struct __darwin_i386_float_state __fs;
};


struct __darwin_mcontext_avx32
{
 struct __darwin_i386_exception_state __es;
 struct __darwin_i386_thread_state __ss;
 struct __darwin_i386_avx_state __fs;
};
# 86 "/usr/include/i386/_structs.h" 3 4
struct __darwin_mcontext64
{
 struct __darwin_x86_exception_state64 __es;
 struct __darwin_x86_thread_state64 __ss;
 struct __darwin_x86_float_state64 __fs;
};


struct __darwin_mcontext_avx64
{
 struct __darwin_x86_exception_state64 __es;
 struct __darwin_x86_thread_state64 __ss;
 struct __darwin_x86_avx_state64 __fs;
};
# 127 "/usr/include/i386/_structs.h" 3 4
typedef struct __darwin_mcontext64 *mcontext_t;
# 30 "/usr/include/machine/_structs.h" 2 3 4
# 58 "/usr/include/sys/_structs.h" 2 3 4
# 75 "/usr/include/sys/_structs.h" 3 4
struct __darwin_sigaltstack
{
 void *ss_sp;
 __darwin_size_t ss_size;
 int ss_flags;
};
# 128 "/usr/include/sys/_structs.h" 3 4
struct __darwin_ucontext
{
 int uc_onstack;
 __darwin_sigset_t uc_sigmask;
 struct __darwin_sigaltstack uc_stack;
 struct __darwin_ucontext *uc_link;
 __darwin_size_t uc_mcsize;
 struct __darwin_mcontext64 *uc_mcontext;



};
# 218 "/usr/include/sys/_structs.h" 3 4
typedef struct __darwin_sigaltstack stack_t;
# 227 "/usr/include/sys/_structs.h" 3 4
typedef struct __darwin_ucontext ucontext_t;
# 149 "/usr/include/sys/signal.h" 2 3 4
# 157 "/usr/include/sys/signal.h" 3 4
typedef __darwin_pthread_attr_t pthread_attr_t;




typedef __darwin_sigset_t sigset_t;
# 172 "/usr/include/sys/signal.h" 3 4
typedef __darwin_uid_t uid_t;


union sigval {

 int sival_int;
 void *sival_ptr;
};





struct sigevent {
 int sigev_notify;
 int sigev_signo;
 union sigval sigev_value;
 void (*sigev_notify_function)(union sigval);
 pthread_attr_t *sigev_notify_attributes;
};


typedef struct __siginfo {
 int si_signo;
 int si_errno;
 int si_code;
 pid_t si_pid;
 uid_t si_uid;
 int si_status;
 void *si_addr;
 union sigval si_value;
 long si_band;
 unsigned long __pad[7];
} siginfo_t;
# 286 "/usr/include/sys/signal.h" 3 4
union __sigaction_u {
 void (*__sa_handler)(int);
 void (*__sa_sigaction)(int, struct __siginfo *,
         void *);
};


struct __sigaction {
 union __sigaction_u __sigaction_u;
 void (*sa_tramp)(void *, int, int, siginfo_t *, void *);
 sigset_t sa_mask;
 int sa_flags;
};




struct sigaction {
 union __sigaction_u __sigaction_u;
 sigset_t sa_mask;
 int sa_flags;
};
# 348 "/usr/include/sys/signal.h" 3 4
typedef void (*sig_t)(int);
# 365 "/usr/include/sys/signal.h" 3 4
struct sigvec {
 void (*sv_handler)(int);
 int sv_mask;
 int sv_flags;
};
# 384 "/usr/include/sys/signal.h" 3 4
struct sigstack {
 char *ss_sp;
 int ss_onstack;
};
# 406 "/usr/include/sys/signal.h" 3 4

void (*signal(int, void (*)(int)))(int);

# 117 "/usr/include/sys/wait.h" 2 3 4
# 1 "/usr/include/sys/resource.h" 1 3 4
# 77 "/usr/include/sys/resource.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 100 "/usr/include/sys/_structs.h" 3 4
struct timeval
{
 __darwin_time_t tv_sec;
 __darwin_suseconds_t tv_usec;
};
# 78 "/usr/include/sys/resource.h" 2 3 4
# 89 "/usr/include/sys/resource.h" 3 4
typedef __uint64_t rlim_t;
# 151 "/usr/include/sys/resource.h" 3 4
struct rusage {
 struct timeval ru_utime;
 struct timeval ru_stime;
# 162 "/usr/include/sys/resource.h" 3 4
 long ru_maxrss;

 long ru_ixrss;
 long ru_idrss;
 long ru_isrss;
 long ru_minflt;
 long ru_majflt;
 long ru_nswap;
 long ru_inblock;
 long ru_oublock;
 long ru_msgsnd;
 long ru_msgrcv;
 long ru_nsignals;
 long ru_nvcsw;
 long ru_nivcsw;


};
# 222 "/usr/include/sys/resource.h" 3 4
struct rlimit {
 rlim_t rlim_cur;
 rlim_t rlim_max;
};
# 244 "/usr/include/sys/resource.h" 3 4

int getpriority(int, id_t);

int getiopolicy_np(int, int) __attribute__((visibility("default")));

int getrlimit(int, struct rlimit *) __asm("_" "getrlimit" );
int getrusage(int, struct rusage *);
int setpriority(int, id_t, int);

int setiopolicy_np(int, int, int) __attribute__((visibility("default")));

int setrlimit(int, const struct rlimit *) __asm("_" "setrlimit" );

# 118 "/usr/include/sys/wait.h" 2 3 4
# 193 "/usr/include/sys/wait.h" 3 4
# 1 "/usr/include/machine/endian.h" 1 3 4
# 35 "/usr/include/machine/endian.h" 3 4
# 1 "/usr/include/i386/endian.h" 1 3 4
# 99 "/usr/include/i386/endian.h" 3 4
# 1 "/usr/include/sys/_endian.h" 1 3 4
# 124 "/usr/include/sys/_endian.h" 3 4
# 1 "/usr/include/libkern/_OSByteOrder.h" 1 3 4
# 66 "/usr/include/libkern/_OSByteOrder.h" 3 4
# 1 "/usr/include/libkern/i386/_OSByteOrder.h" 1 3 4
# 44 "/usr/include/libkern/i386/_OSByteOrder.h" 3 4
static __inline__
__uint16_t
_OSSwapInt16(
    __uint16_t _data
)
{
    return ((_data << 8) | (_data >> 8));
}

static __inline__
__uint32_t
_OSSwapInt32(
    __uint32_t _data
)
{

    return __builtin_bswap32(_data);




}


static __inline__
__uint64_t
_OSSwapInt64(
    __uint64_t _data
)
{
    return __builtin_bswap64(_data);
}
# 67 "/usr/include/libkern/_OSByteOrder.h" 2 3 4
# 125 "/usr/include/sys/_endian.h" 2 3 4
# 100 "/usr/include/i386/endian.h" 2 3 4
# 36 "/usr/include/machine/endian.h" 2 3 4
# 194 "/usr/include/sys/wait.h" 2 3 4







union wait {
 int w_status;



 struct {

  unsigned int w_Termsig:7,
    w_Coredump:1,
    w_Retcode:8,
    w_Filler:16;







 } w_T;





 struct {

  unsigned int w_Stopval:8,
    w_Stopsig:8,
    w_Filler:16;






 } w_S;
};
# 254 "/usr/include/sys/wait.h" 3 4

pid_t wait(int *) __asm("_" "wait" );
pid_t waitpid(pid_t, int *, int) __asm("_" "waitpid" );

int waitid(idtype_t, id_t, siginfo_t *, int) __asm("_" "waitid" );


pid_t wait3(int *, int, struct rusage *);
pid_t wait4(pid_t, int *, int, struct rusage *);


# 66 "/usr/include/stdlib.h" 2 3 4

# 1 "/usr/include/alloca.h" 1 3 4
# 35 "/usr/include/alloca.h" 3 4

void *alloca(size_t);

# 68 "/usr/include/stdlib.h" 2 3 4
# 81 "/usr/include/stdlib.h" 3 4
typedef __darwin_ct_rune_t ct_rune_t;




typedef __darwin_rune_t rune_t;






typedef __darwin_wchar_t wchar_t;



typedef struct {
 int quot;
 int rem;
} div_t;

typedef struct {
 long quot;
 long rem;
} ldiv_t;


typedef struct {
 long long quot;
 long long rem;
} lldiv_t;
# 134 "/usr/include/stdlib.h" 3 4
extern int __mb_cur_max;
# 144 "/usr/include/stdlib.h" 3 4

void abort(void) __attribute__((__noreturn__));
int abs(int) __attribute__((__const__));
int atexit(void (*)(void));
double atof(const char *);
int atoi(const char *);
long atol(const char *);

long long
  atoll(const char *);

void *bsearch(const void *, const void *, size_t,
     size_t, int (*)(const void *, const void *));
void *calloc(size_t, size_t);
div_t div(int, int) __attribute__((__const__));
void exit(int) __attribute__((__noreturn__));
void free(void *);
char *getenv(const char *);
long labs(long) __attribute__((__const__));
ldiv_t ldiv(long, long) __attribute__((__const__));

long long
  llabs(long long);
lldiv_t lldiv(long long, long long);

void *malloc(size_t);
int mblen(const char *, size_t);
size_t mbstowcs(wchar_t * , const char * , size_t);
int mbtowc(wchar_t * , const char * , size_t);
int posix_memalign(void **, size_t, size_t) __attribute__((visibility("default")));
void qsort(void *, size_t, size_t,
     int (*)(const void *, const void *));
int rand(void);
void *realloc(void *, size_t);
void srand(unsigned);
double strtod(const char *, char **) __asm("_" "strtod" );
float strtof(const char *, char **) __asm("_" "strtof" );
long strtol(const char *, char **, int);
long double
  strtold(const char *, char **) ;

long long
  strtoll(const char *, char **, int);

unsigned long
  strtoul(const char *, char **, int);

unsigned long long
  strtoull(const char *, char **, int);

int system(const char *) __asm("_" "system" );
size_t wcstombs(char * , const wchar_t * , size_t);
int wctomb(char *, wchar_t);


void _Exit(int) __attribute__((__noreturn__));
long a64l(const char *);
double drand48(void);
char *ecvt(double, int, int *, int *);
double erand48(unsigned short[3]);
char *fcvt(double, int, int *, int *);
char *gcvt(double, int, char *);
int getsubopt(char **, char * const *, char **);
int grantpt(int);

char *initstate(unsigned, char *, size_t);



long jrand48(unsigned short[3]);
char *l64a(long);
void lcong48(unsigned short[7]);
long lrand48(void);
char *mktemp(char *);
int mkstemp(char *);
long mrand48(void);
long nrand48(unsigned short[3]);
int posix_openpt(int);
char *ptsname(int);
int putenv(char *) __asm("_" "putenv" );
long random(void);
int rand_r(unsigned *);

char *realpath(const char * , char * ) __asm("_" "realpath" "$DARWIN_EXTSN");



unsigned short
 *seed48(unsigned short[3]);
int setenv(const char *, const char *, int) __asm("_" "setenv" );

void setkey(const char *) __asm("_" "setkey" );



char *setstate(const char *);
void srand48(long);

void srandom(unsigned);



int unlockpt(int);

int unsetenv(const char *) __asm("_" "unsetenv" );






# 1 "/usr/include/machine/types.h" 1 3 4
# 35 "/usr/include/machine/types.h" 3 4
# 1 "/usr/include/i386/types.h" 1 3 4
# 70 "/usr/include/i386/types.h" 3 4
# 1 "/usr/include/i386/_types.h" 1 3 4
# 71 "/usr/include/i386/types.h" 2 3 4







typedef signed char int8_t;

typedef unsigned char u_int8_t;


typedef short int16_t;

typedef unsigned short u_int16_t;


typedef int int32_t;

typedef unsigned int u_int32_t;


typedef long long int64_t;

typedef unsigned long long u_int64_t;


typedef int64_t register_t;






typedef __darwin_intptr_t intptr_t;



typedef unsigned long uintptr_t;




typedef u_int64_t user_addr_t;
typedef u_int64_t user_size_t;
typedef int64_t user_ssize_t;
typedef int64_t user_long_t;
typedef u_int64_t user_ulong_t;
typedef int64_t user_time_t;
typedef int64_t user_off_t;







typedef u_int64_t syscall_arg_t;
# 36 "/usr/include/machine/types.h" 2 3 4
# 256 "/usr/include/stdlib.h" 2 3 4


typedef __darwin_dev_t dev_t;




typedef __darwin_mode_t mode_t;



u_int32_t
  arc4random(void);
void arc4random_addrandom(unsigned char * , int );
void arc4random_buf(void * , size_t ) __attribute__((visibility("default")));
void arc4random_stir(void);
u_int32_t
  arc4random_uniform(u_int32_t ) __attribute__((visibility("default")));

int atexit_b(void (^)(void)) __attribute__((visibility("default")));
void *bsearch_b(const void *, const void *, size_t,
     size_t, int (^)(const void *, const void *)) __attribute__((visibility("default")));



char *cgetcap(char *, const char *, int);
int cgetclose(void);
int cgetent(char **, char **, const char *);
int cgetfirst(char **, char **);
int cgetmatch(const char *, const char *);
int cgetnext(char **, char **);
int cgetnum(char *, const char *, long *);
int cgetset(const char *);
int cgetstr(char *, const char *, char **);
int cgetustr(char *, const char *, char **);

int daemon(int, int) __asm("_" "daemon" "$1050") __attribute__((deprecated,visibility("default")));
char *devname(dev_t, mode_t);
char *devname_r(dev_t, mode_t, char *buf, int len);
char *getbsize(int *, long *);
int getloadavg(double [], int);
const char
 *getprogname(void);

int heapsort(void *, size_t, size_t,
     int (*)(const void *, const void *));

int heapsort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

int mergesort(void *, size_t, size_t,
     int (*)(const void *, const void *));

int mergesort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void psort(void *, size_t, size_t,
     int (*)(const void *, const void *)) __attribute__((visibility("default")));

void psort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void psort_r(void *, size_t, size_t, void *,
     int (*)(void *, const void *, const void *)) __attribute__((visibility("default")));

void qsort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void qsort_r(void *, size_t, size_t, void *,
     int (*)(void *, const void *, const void *));
int radixsort(const unsigned char **, int, const unsigned char *,
     unsigned);
void setprogname(const char *);
int sradixsort(const unsigned char **, int, const unsigned char *,
     unsigned);
void sranddev(void);
void srandomdev(void);
void *reallocf(void *, size_t);

long long
  strtoq(const char *, char **, int);
unsigned long long
  strtouq(const char *, char **, int);

extern char *suboptarg;
void *valloc(size_t);







# 69 "c.h" 2
# 1 "/usr/include/string.h" 1 3 4
# 79 "/usr/include/string.h" 3 4

void *memchr(const void *, int, size_t);
int memcmp(const void *, const void *, size_t);
void *memcpy(void *, const void *, size_t);
void *memmove(void *, const void *, size_t);
void *memset(void *, int, size_t);
char *strcat(char *, const char *);
char *strchr(const char *, int);
int strcmp(const char *, const char *);
int strcoll(const char *, const char *);
char *strcpy(char *, const char *);
size_t strcspn(const char *, const char *);
char *strerror(int) __asm("_" "strerror" );
size_t strlen(const char *);
char *strncat(char *, const char *, size_t);
int strncmp(const char *, const char *, size_t);
char *strncpy(char *, const char *, size_t);
char *strpbrk(const char *, const char *);
char *strrchr(const char *, int);
size_t strspn(const char *, const char *);
char *strstr(const char *, const char *);
char *strtok(char *, const char *);
size_t strxfrm(char *, const char *, size_t);

# 113 "/usr/include/string.h" 3 4

char *strtok_r(char *, const char *, char **);

# 125 "/usr/include/string.h" 3 4

int strerror_r(int, char *, size_t);
char *strdup(const char *);
void *memccpy(void *, const void *, int, size_t);

# 139 "/usr/include/string.h" 3 4

char *stpcpy(char *, const char *);
char *stpncpy(char *, const char *, size_t) __attribute__((visibility("default")));
char *strndup(const char *, size_t) __attribute__((visibility("default")));
size_t strnlen(const char *, size_t) __attribute__((visibility("default")));
char *strsignal(int sig);

# 158 "/usr/include/string.h" 3 4

void *memmem(const void *, size_t, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern4(void *, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern8(void *, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern16(void *, const void *, size_t) __attribute__((visibility("default")));

char *strcasestr(const char *, const char *);
char *strnstr(const char *, const char *, size_t);
size_t strlcat(char *, const char *, size_t);
size_t strlcpy(char *, const char *, size_t);
void strmode(int, char *);
char *strsep(char **, const char *);


void swab(const void * , void * , ssize_t);







# 1 "/usr/include/strings.h" 1 3 4
# 71 "/usr/include/strings.h" 3 4



int bcmp(const void *, const void *, size_t) ;
void bcopy(const void *, void *, size_t) ;
void bzero(void *, size_t) ;
char *index(const char *, int) ;
char *rindex(const char *, int) ;


int ffs(int);
int strcasecmp(const char *, const char *);
int strncasecmp(const char *, const char *, size_t);





int ffsl(long) __attribute__((visibility("default")));
int fls(int) __attribute__((visibility("default")));
int flsl(long) __attribute__((visibility("default")));


# 1 "/usr/include/string.h" 1 3 4
# 95 "/usr/include/strings.h" 2 3 4
# 181 "/usr/include/string.h" 2 3 4
# 190 "/usr/include/string.h" 3 4
# 1 "/usr/include/secure/_string.h" 1 3 4
# 58 "/usr/include/secure/_string.h" 3 4
static __inline void *
__inline_memcpy_chk (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memcpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 0));
}






static __inline void *
__inline_memmove_chk (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memmove_chk (__dest, __src, __len, __builtin_object_size (__dest, 0));
}






static __inline void *
__inline_memset_chk (void *__dest, int __val, size_t __len)
{
  return __builtin___memset_chk (__dest, __val, __len, __builtin_object_size (__dest, 0));
}






static __inline char *
__inline_strcpy_chk (char * __dest, const char * __src)
{
  return __builtin___strcpy_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_stpcpy_chk (char *__dest, const char *__src)
{
  return __builtin___stpcpy_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}






static __inline char *
__inline_stpncpy_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___stpncpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_strncpy_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___strncpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}






static __inline char *
__inline_strcat_chk (char * __dest, const char * __src)
{
  return __builtin___strcat_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_strncat_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___strncat_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}
# 191 "/usr/include/string.h" 2 3 4
# 70 "c.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stddef.h" 1 3 4
# 152 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 71 "c.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stdarg.h" 1 3 4
# 43 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 72 "c.h" 2

# 1 "./strings.h" 1
char *s1,
     *s2,
     *s3,
     *s4,
     *s5,
     *s6;
# 74 "c.h" 2


# 1 "/usr/include/stdint.h" 1 3 4
# 40 "/usr/include/stdint.h" 3 4
typedef unsigned char uint8_t;




typedef unsigned short uint16_t;




typedef unsigned int uint32_t;




typedef unsigned long long uint64_t;



typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;
# 97 "/usr/include/stdint.h" 3 4
typedef long int intmax_t;
# 106 "/usr/include/stdint.h" 3 4
typedef long unsigned int uintmax_t;
# 77 "c.h" 2

# 1 "/usr/include/sys/types.h" 1 3 4
# 84 "/usr/include/sys/types.h" 3 4
typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned int u_int;

typedef unsigned long u_long;


typedef unsigned short ushort;
typedef unsigned int uint;


typedef u_int64_t u_quad_t;
typedef int64_t quad_t;
typedef quad_t * qaddr_t;

typedef char * caddr_t;
typedef int32_t daddr_t;






typedef u_int32_t fixpt_t;


typedef __darwin_blkcnt_t blkcnt_t;




typedef __darwin_blksize_t blksize_t;




typedef __darwin_gid_t gid_t;





typedef __uint32_t in_addr_t;




typedef __uint16_t in_port_t;



typedef __darwin_ino_t ino_t;





typedef __darwin_ino64_t ino64_t;






typedef __int32_t key_t;
# 157 "/usr/include/sys/types.h" 3 4
typedef __uint16_t nlink_t;
# 176 "/usr/include/sys/types.h" 3 4
typedef int32_t segsz_t;
typedef int32_t swblk_t;
# 223 "/usr/include/sys/types.h" 3 4
typedef __darwin_clock_t clock_t;
# 240 "/usr/include/sys/types.h" 3 4
typedef __darwin_time_t time_t;




typedef __darwin_useconds_t useconds_t;




typedef __darwin_suseconds_t suseconds_t;
# 260 "/usr/include/sys/types.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 183 "/usr/include/sys/_structs.h" 3 4

typedef struct fd_set {
 __int32_t fds_bits[((((1024) % ((sizeof(__int32_t) * 8))) == 0) ? ((1024) / ((sizeof(__int32_t) * 8))) : (((1024) / ((sizeof(__int32_t) * 8))) + 1))];
} fd_set;



static __inline int
__darwin_fd_isset(int _n, const struct fd_set *_p)
{
 return (_p->fds_bits[_n/(sizeof(__int32_t) * 8)] & (1<<(_n % (sizeof(__int32_t) * 8))));
}
# 261 "/usr/include/sys/types.h" 2 3 4




typedef __int32_t fd_mask;
# 322 "/usr/include/sys/types.h" 3 4
typedef __darwin_pthread_cond_t pthread_cond_t;



typedef __darwin_pthread_condattr_t pthread_condattr_t;



typedef __darwin_pthread_mutex_t pthread_mutex_t;



typedef __darwin_pthread_mutexattr_t pthread_mutexattr_t;



typedef __darwin_pthread_once_t pthread_once_t;



typedef __darwin_pthread_rwlock_t pthread_rwlock_t;



typedef __darwin_pthread_rwlockattr_t pthread_rwlockattr_t;



typedef __darwin_pthread_t pthread_t;






typedef __darwin_pthread_key_t pthread_key_t;





typedef __darwin_fsblkcnt_t fsblkcnt_t;




typedef __darwin_fsfilcnt_t fsfilcnt_t;
# 79 "c.h" 2

# 1 "/usr/include/errno.h" 1 3 4
# 23 "/usr/include/errno.h" 3 4
# 1 "/usr/include/sys/errno.h" 1 3 4
# 74 "/usr/include/sys/errno.h" 3 4

extern int * __error(void);


# 24 "/usr/include/errno.h" 2 3 4
# 81 "c.h" 2
# 91 "c.h"
# 1 "/usr/include/locale.h" 1 3 4
# 40 "/usr/include/locale.h" 3 4
# 1 "/usr/include/_locale.h" 1 3 4
# 43 "/usr/include/_locale.h" 3 4
struct lconv {
 char *decimal_point;
 char *thousands_sep;
 char *grouping;
 char *int_curr_symbol;
 char *currency_symbol;
 char *mon_decimal_point;
 char *mon_thousands_sep;
 char *mon_grouping;
 char *positive_sign;
 char *negative_sign;
 char int_frac_digits;
 char frac_digits;
 char p_cs_precedes;
 char p_sep_by_space;
 char n_cs_precedes;
 char n_sep_by_space;
 char p_sign_posn;
 char n_sign_posn;
 char int_p_cs_precedes;
 char int_n_cs_precedes;
 char int_p_sep_by_space;
 char int_n_sep_by_space;
 char int_p_sign_posn;
 char int_n_sign_posn;
};






struct lconv *localeconv(void);

# 41 "/usr/include/locale.h" 2 3 4
# 52 "/usr/include/locale.h" 3 4

char *setlocale(int, const char *);

# 92 "c.h" 2
# 181 "c.h"
typedef char bool;
# 193 "c.h"
typedef bool *BoolPtr;
# 224 "c.h"
typedef char *Pointer;
# 233 "c.h"
typedef signed char int8;
typedef signed short int16;
typedef signed int int32;
# 245 "c.h"
typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;






typedef uint8 bits8;
typedef uint16 bits16;
typedef uint32 bits32;
# 265 "c.h"
typedef long int int64;


typedef unsigned long int uint64;
# 308 "c.h"
typedef size_t Size;
# 317 "c.h"
typedef unsigned int Index;
# 327 "c.h"
typedef signed int Offset;




typedef int16 int2;
typedef int32 int4;
typedef float float4;
typedef double float8;
# 348 "c.h"
typedef Oid regproc;
typedef regproc RegProcedure;

typedef uint32 TransactionId;

typedef uint32 LocalTransactionId;

typedef uint32 SubTransactionId;





typedef TransactionId MultiXactId;

typedef uint32 MultiXactOffset;

typedef uint32 CommandId;







typedef struct
{
 int indx[6];
} IntArray;
# 391 "c.h"
struct varlena
{
 char vl_len_[4];
 char vl_dat[1];
};
# 404 "c.h"
typedef struct varlena bytea;
typedef struct varlena text;
typedef struct varlena BpChar;
typedef struct varlena VarChar;
# 419 "c.h"
typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
 int dim1;
 int lbound1;
 int2 values[1];
} int2vector;

typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
 int dim1;
 int lbound1;
 Oid values[1];
} oidvector;





typedef struct nameData
{
 char data[64];
} NameData;
typedef NameData *Name;
# 829 "c.h"
extern int fdatasync(int fildes);
# 860 "c.h"
# 1 "port.h" 1
# 16 "port.h"
# 1 "/usr/include/ctype.h" 1 3 4
# 69 "/usr/include/ctype.h" 3 4
# 1 "/usr/include/runetype.h" 1 3 4
# 70 "/usr/include/runetype.h" 3 4
typedef __darwin_wint_t wint_t;
# 81 "/usr/include/runetype.h" 3 4
typedef struct {
 __darwin_rune_t __min;
 __darwin_rune_t __max;
 __darwin_rune_t __map;
 __uint32_t *__types;
} _RuneEntry;

typedef struct {
 int __nranges;
 _RuneEntry *__ranges;
} _RuneRange;

typedef struct {
 char __name[14];
 __uint32_t __mask;
} _RuneCharClass;

typedef struct {
 char __magic[8];
 char __encoding[32];

 __darwin_rune_t (*__sgetrune)(const char *, __darwin_size_t, char const **);
 int (*__sputrune)(__darwin_rune_t, char *, __darwin_size_t, char **);
 __darwin_rune_t __invalid_rune;

 __uint32_t __runetype[(1 <<8 )];
 __darwin_rune_t __maplower[(1 <<8 )];
 __darwin_rune_t __mapupper[(1 <<8 )];






 _RuneRange __runetype_ext;
 _RuneRange __maplower_ext;
 _RuneRange __mapupper_ext;

 void *__variable;
 int __variable_len;




 int __ncharclasses;
 _RuneCharClass *__charclasses;
} _RuneLocale;




extern _RuneLocale _DefaultRuneLocale;
extern _RuneLocale *_CurrentRuneLocale;

# 70 "/usr/include/ctype.h" 2 3 4
# 145 "/usr/include/ctype.h" 3 4

unsigned long ___runetype(__darwin_ct_rune_t);
__darwin_ct_rune_t ___tolower(__darwin_ct_rune_t);
__darwin_ct_rune_t ___toupper(__darwin_ct_rune_t);


static __inline int
isascii(int _c)
{
 return ((_c & ~0x7F) == 0);
}
# 164 "/usr/include/ctype.h" 3 4

int __maskrune(__darwin_ct_rune_t, unsigned long);



static __inline int
__istype(__darwin_ct_rune_t _c, unsigned long _f)
{



 return (isascii(_c) ? !!(_DefaultRuneLocale.__runetype[_c] & _f)
  : !!__maskrune(_c, _f));

}

static __inline __darwin_ct_rune_t
__isctype(__darwin_ct_rune_t _c, unsigned long _f)
{



 return (_c < 0 || _c >= (1 <<8 )) ? 0 :
  !!(_DefaultRuneLocale.__runetype[_c] & _f);

}
# 204 "/usr/include/ctype.h" 3 4

__darwin_ct_rune_t __toupper(__darwin_ct_rune_t);
__darwin_ct_rune_t __tolower(__darwin_ct_rune_t);



static __inline int
__wcwidth(__darwin_ct_rune_t _c)
{
 unsigned int _x;

 if (_c == 0)
  return (0);
 _x = (unsigned int)__maskrune(_c, 0xe0000000L|0x00040000L);
 if ((_x & 0xe0000000L) != 0)
  return ((_x & 0xe0000000L) >> 30);
 return ((_x & 0x00040000L) != 0 ? 1 : -1);
}






static __inline int
isalnum(int _c)
{
 return (__istype(_c, 0x00000100L|0x00000400L));
}

static __inline int
isalpha(int _c)
{
 return (__istype(_c, 0x00000100L));
}

static __inline int
isblank(int _c)
{
 return (__istype(_c, 0x00020000L));
}

static __inline int
iscntrl(int _c)
{
 return (__istype(_c, 0x00000200L));
}


static __inline int
isdigit(int _c)
{
 return (__isctype(_c, 0x00000400L));
}

static __inline int
isgraph(int _c)
{
 return (__istype(_c, 0x00000800L));
}

static __inline int
islower(int _c)
{
 return (__istype(_c, 0x00001000L));
}

static __inline int
isprint(int _c)
{
 return (__istype(_c, 0x00040000L));
}

static __inline int
ispunct(int _c)
{
 return (__istype(_c, 0x00002000L));
}

static __inline int
isspace(int _c)
{
 return (__istype(_c, 0x00004000L));
}

static __inline int
isupper(int _c)
{
 return (__istype(_c, 0x00008000L));
}


static __inline int
isxdigit(int _c)
{
 return (__isctype(_c, 0x00010000L));
}

static __inline int
toascii(int _c)
{
 return (_c & 0x7F);
}

static __inline int
tolower(int _c)
{
        return (__tolower(_c));
}

static __inline int
toupper(int _c)
{
        return (__toupper(_c));
}


static __inline int
digittoint(int _c)
{
 return (__maskrune(_c, 0x0F));
}

static __inline int
ishexnumber(int _c)
{
 return (__istype(_c, 0x00010000L));
}

static __inline int
isideogram(int _c)
{
 return (__istype(_c, 0x00080000L));
}

static __inline int
isnumber(int _c)
{
 return (__istype(_c, 0x00000400L));
}

static __inline int
isphonogram(int _c)
{
 return (__istype(_c, 0x00200000L));
}

static __inline int
isrune(int _c)
{
 return (__istype(_c, 0xFFFFFFF0L));
}

static __inline int
isspecial(int _c)
{
 return (__istype(_c, 0x00100000L));
}
# 17 "port.h" 2
# 1 "./netdb.h" 1
# 18 "port.h" 2
# 1 "./pwd.h" 1
# 19 "port.h" 2



typedef int pgsocket;
# 32 "port.h"
extern bool pg_set_noblock(pgsocket sock);
extern bool pg_set_block(pgsocket sock);



extern bool has_drive_prefix(const char *filename);
extern char *first_dir_separator(const char *filename);
extern char *last_dir_separator(const char *filename);
extern char *first_path_var_separator(const char *pathlist);
extern void join_path_components(char *ret_path,
      const char *head, const char *tail);
extern void canonicalize_path(char *path);
extern void make_native_path(char *path);
extern bool path_contains_parent_reference(const char *path);
extern bool path_is_relative_and_below_cwd(const char *path);
extern bool path_is_prefix_of_path(const char *path1, const char *path2);
extern const char *get_progname(const char *argv0);
extern void get_share_path(const char *my_exec_path, char *ret_path);
extern void get_etc_path(const char *my_exec_path, char *ret_path);
extern void get_include_path(const char *my_exec_path, char *ret_path);
extern void get_pkginclude_path(const char *my_exec_path, char *ret_path);
extern void get_includeserver_path(const char *my_exec_path, char *ret_path);
extern void get_lib_path(const char *my_exec_path, char *ret_path);
extern void get_pkglib_path(const char *my_exec_path, char *ret_path);
extern void get_locale_path(const char *my_exec_path, char *ret_path);
extern void get_doc_path(const char *my_exec_path, char *ret_path);
extern void get_html_path(const char *my_exec_path, char *ret_path);
extern void get_man_path(const char *my_exec_path, char *ret_path);
extern bool get_home_path(char *ret_path);
extern void get_parent_directory(char *path);


extern char **pgfnames(const char *path);
extern void pgfnames_cleanup(char **filenames);
# 92 "port.h"
extern void set_pglocale_pgservice(const char *argv0, const char *app);


extern int find_my_exec(const char *argv0, char *retpath);
extern int find_other_exec(const char *argv0, const char *target,
    const char *versionstr, char *retpath);
# 149 "port.h"
extern void pg_usleep(long microsec);


extern int pg_strcasecmp(const char *s1, const char *s2);
extern int pg_strncasecmp(const char *s1, const char *s2, size_t n);
extern unsigned char pg_toupper(unsigned char ch);
extern unsigned char pg_tolower(unsigned char ch);
extern unsigned char pg_ascii_toupper(unsigned char ch);
extern unsigned char pg_ascii_tolower(unsigned char ch);
# 247 "port.h"
extern char *simple_prompt(const char *prompt, int maxlen, bool echo);







extern int pclose_check(FILE *stream);
# 300 "port.h"
extern bool rmtree(const char *path, bool rmtopdir);
# 372 "port.h"
extern double pg_erand48(unsigned short xseed[3]);
extern long pg_lrand48(void);
extern void pg_srand48(long seed);
# 428 "port.h"
extern char *pqStrerror(int errnum, char *strerrbuf, size_t buflen);


extern int pqGetpwuid(uid_t uid, struct passwd * resultbuf, char *buffer,
     size_t buflen, struct passwd ** result);


extern int pqGethostbyname(const char *name,
    struct hostent * resultbuf,
    char *buffer, size_t buflen,
    struct hostent ** result,
    int *herrno);

extern void pg_qsort(void *base, size_t nel, size_t elsize,
   int (*cmp) (const void *, const void *));



typedef int (*qsort_arg_comparator) (const void *a, const void *b, void *arg);

extern void qsort_arg(void *base, size_t nel, size_t elsize,
    qsort_arg_comparator cmp, void *arg);


extern int pg_get_encoding_from_locale(const char *ctype, bool write_message);


extern char *inet_net_ntop(int af, const void *src, int bits,
     char *dst, size_t size);


extern int pg_check_dir(const char *dir);


extern int pg_mkdir_p(char *path, int omode);
# 861 "c.h" 2
# 26 "postgres_fe.h" 2
# 45 "tab-complete.c" 2
# 1 "tab-complete.h" 1
# 13 "tab-complete.h"
void initialize_readline(void);
# 46 "tab-complete.c" 2
# 1 "input.h" 1
# 21 "input.h"
# 1 "/usr/include/readline/readline.h" 1 3 4
# 40 "/usr/include/readline/readline.h" 3 4
typedef int Function(const char *, int);
typedef void VFunction(void);
typedef void VCPFunction(char *);
typedef char *CPFunction(const char *, int);
typedef char **CPPFunction(const char *, int, int);
typedef char *rl_compentry_func_t(const char *, int);
typedef int rl_command_func_t(int, int);


typedef struct {
 int length;
} HISTORY_STATE;

typedef void *histdata_t;

typedef struct _hist_entry {
 const char *line;
 histdata_t data;
} HIST_ENTRY;

typedef struct _keymap_entry {
 char type;



 Function *function;
} KEYMAP_ENTRY;



typedef KEYMAP_ENTRY KEYMAP_ENTRY_ARRAY[256];
typedef KEYMAP_ENTRY *Keymap;





# 1 "/usr/include/sys/ioctl.h" 1 3 4
# 72 "/usr/include/sys/ioctl.h" 3 4
# 1 "/usr/include/sys/ttycom.h" 1 3 4
# 72 "/usr/include/sys/ttycom.h" 3 4
# 1 "/usr/include/sys/ioccom.h" 1 3 4
# 73 "/usr/include/sys/ttycom.h" 2 3 4
# 83 "/usr/include/sys/ttycom.h" 3 4
struct winsize {
 unsigned short ws_row;
 unsigned short ws_col;
 unsigned short ws_xpixel;
 unsigned short ws_ypixel;
};
# 73 "/usr/include/sys/ioctl.h" 2 3 4






struct ttysize {
 unsigned short ts_lines;
 unsigned short ts_cols;
 unsigned short ts_xxx;
 unsigned short ts_yyy;
};





# 1 "/usr/include/sys/filio.h" 1 3 4
# 91 "/usr/include/sys/ioctl.h" 2 3 4
# 1 "/usr/include/sys/sockio.h" 1 3 4
# 92 "/usr/include/sys/ioctl.h" 2 3 4





int ioctl(int, unsigned long, ...);

# 78 "/usr/include/readline/readline.h" 2 3 4

# 1 "/usr/include/sys/ttydefaults.h" 1 3 4
# 80 "/usr/include/readline/readline.h" 2 3 4
# 99 "/usr/include/readline/readline.h" 3 4
extern const char *rl_library_version;
extern int rl_readline_version;
extern char *rl_readline_name;
extern FILE *rl_instream;
extern FILE *rl_outstream;
extern char *rl_line_buffer;
extern int rl_point, rl_end;
extern int history_base, history_length;
extern int max_input_history;
extern char *rl_basic_word_break_characters;
extern char *rl_completer_word_break_characters;
extern char *rl_completer_quote_characters;
extern Function *rl_completion_entry_function;
extern CPPFunction *rl_attempted_completion_function;
extern int rl_attempted_completion_over;
extern int rl_completion_type;
extern int rl_completion_query_items;
extern char *rl_special_prefixes;
extern int rl_completion_append_character;
extern int rl_inhibit_completion;
extern Function *rl_pre_input_hook;
extern Function *rl_startup_hook;
extern char *rl_terminal_name;
extern int rl_already_prompted;
extern char *rl_prompt;



extern KEYMAP_ENTRY_ARRAY emacs_standard_keymap,
   emacs_meta_keymap,
   emacs_ctlx_keymap;
extern int rl_filename_completion_desired;
extern int rl_ignore_completion_duplicates;
extern int (*rl_getc_function)(FILE *);
extern VFunction *rl_redisplay_function;
extern VFunction *rl_completion_display_matches_hook;
extern VFunction *rl_prep_term_function;
extern VFunction *rl_deprep_term_function;
extern int readline_echoing_p;
extern int _rl_print_completions_horizontally;


char *readline(const char *);
int rl_initialize(void);

void using_history(void);
int add_history(const char *);
void clear_history(void);
void stifle_history(int);
int unstifle_history(void);
int history_is_stifled(void);
int where_history(void);
HIST_ENTRY *current_history(void);
HIST_ENTRY *history_get(int);
HIST_ENTRY *remove_history(int);

HIST_ENTRY *replace_history_entry(int, const char *, histdata_t);
int history_total_bytes(void);
int history_set_pos(int);
HIST_ENTRY *previous_history(void);
HIST_ENTRY *next_history(void);
int history_search(const char *, int);
int history_search_prefix(const char *, int);
int history_search_pos(const char *, int, int);
int read_history(const char *);
int write_history(const char *);
int history_truncate_file (const char *, int);
int history_expand(char *, char **);
char **history_tokenize(const char *);
const char *get_history_event(const char *, int *, int);
char *history_arg_extract(int, int, const char *);

char *tilde_expand(char *);
char *filename_completion_function(const char *, int);
char *username_completion_function(const char *, int);
int rl_complete(int, int);
int rl_read_key(void);
char **completion_matches(const char *, CPFunction *);
void rl_display_match_list(char **, int, int);

int rl_insert(int, int);
int rl_insert_text(const char *);
void rl_reset_terminal(const char *);
int rl_bind_key(int, rl_command_func_t *);
int rl_newline(int, int);
void rl_callback_read_char(void);
void rl_callback_handler_install(const char *, VCPFunction *);
void rl_callback_handler_remove(void);
void rl_redisplay(void);
int rl_get_previous_history(int, int);
void rl_prep_terminal(int);
void rl_deprep_terminal(void);
int rl_read_init_file(const char *);
int rl_parse_and_bind(const char *);
int rl_variable_bind(const char *, const char *);
void rl_stuff_char(int);
int rl_add_defun(const char *, Function *, int);
HISTORY_STATE *history_get_history_state(void);
void rl_get_screen_size(int *, int *);
void rl_set_screen_size(int, int);
char *rl_filename_completion_function (const char *, int);
int _rl_abort_internal(void);
int _rl_qsort_string_compare(char **, char **);
char **rl_completion_matches(const char *, rl_compentry_func_t *);
void rl_forced_update_display(void);
int rl_set_prompt(const char *);




int rl_kill_text(int, int);
Keymap rl_get_keymap(void);
void rl_set_keymap(Keymap);
Keymap rl_make_bare_keymap(void);
int rl_generic_bind(int, const char *, const char *, Keymap);
int rl_bind_key_in_map(int, rl_command_func_t *, Keymap);
void rl_cleanup_after_signal(void);
void rl_free_line_state(void);
# 22 "input.h" 2

# 1 "/usr/include/readline/history.h" 1 3 4
# 24 "input.h" 2
# 38 "input.h"
# 1 "pqexpbuffer.h" 1
# 44 "pqexpbuffer.h"
typedef struct PQExpBufferData
{
 char *data;
 size_t len;
 size_t maxlen;
} PQExpBufferData;

typedef PQExpBufferData *PQExpBuffer;
# 96 "pqexpbuffer.h"
extern PQExpBuffer createPQExpBuffer(void);






extern void initPQExpBuffer(PQExpBuffer str);
# 121 "pqexpbuffer.h"
extern void destroyPQExpBuffer(PQExpBuffer str);
extern void termPQExpBuffer(PQExpBuffer str);







extern void resetPQExpBuffer(PQExpBuffer str);
# 140 "pqexpbuffer.h"
extern int enlargePQExpBuffer(PQExpBuffer str, size_t needed);
# 149 "pqexpbuffer.h"
extern void
printfPQExpBuffer(PQExpBuffer str, const char *fmt,...)

__attribute__((format(printf, 2, 3)));
# 161 "pqexpbuffer.h"
extern void
appendPQExpBuffer(PQExpBuffer str, const char *fmt,...)

__attribute__((format(printf, 2, 3)));






extern void appendPQExpBufferStr(PQExpBuffer str, const char *data);






extern void appendPQExpBufferChar(PQExpBuffer str, char ch);






extern void appendBinaryPQExpBuffer(PQExpBuffer str,
      const char *data, size_t datalen);
# 39 "input.h" 2


char *gets_interactive(const char *prompt);
char *gets_fromFile(FILE *source);

void initializeInput(int flags);
bool saveHistory(char *fname, int max_lines, bool appendFlag, bool encodeFlag);

void pg_append_history(const char *s, PQExpBuffer history_buf);
void pg_send_history(PQExpBuffer history_buf);
# 47 "tab-complete.c" 2





# 1 "libpq-fe.h" 1
# 47 "libpq-fe.h"
typedef enum
{
 CONNECTION_OK,
 CONNECTION_BAD,






 CONNECTION_STARTED,
 CONNECTION_MADE,
 CONNECTION_AWAITING_RESPONSE,

 CONNECTION_AUTH_OK,

 CONNECTION_SETENV,
 CONNECTION_SSL_STARTUP,
 CONNECTION_NEEDED
} ConnStatusType;

typedef enum
{
 PGRES_POLLING_FAILED = 0,
 PGRES_POLLING_READING,
 PGRES_POLLING_WRITING,
 PGRES_POLLING_OK,
 PGRES_POLLING_ACTIVE

} PostgresPollingStatusType;

typedef enum
{
 PGRES_EMPTY_QUERY = 0,
 PGRES_COMMAND_OK,


 PGRES_TUPLES_OK,


 PGRES_COPY_OUT,
 PGRES_COPY_IN,
 PGRES_BAD_RESPONSE,

 PGRES_NONFATAL_ERROR,
 PGRES_FATAL_ERROR,
 PGRES_COPY_BOTH,
 PGRES_SINGLE_TUPLE
} ExecStatusType;

typedef enum
{
 PQTRANS_IDLE,
 PQTRANS_ACTIVE,
 PQTRANS_INTRANS,
 PQTRANS_INERROR,
 PQTRANS_UNKNOWN
} PGTransactionStatusType;

typedef enum
{
 PQERRORS_TERSE,
 PQERRORS_DEFAULT,
 PQERRORS_VERBOSE
} PGVerbosity;

typedef enum
{
 PQPING_OK,
 PQPING_REJECT,
 PQPING_NO_RESPONSE,
 PQPING_NO_ATTEMPT
} PGPing;




typedef struct pg_conn PGconn;






typedef struct pg_result PGresult;





typedef struct pg_cancel PGcancel;







typedef struct pgNotify
{
 char *relname;
 int be_pid;
 char *extra;

 struct pgNotify *next;
} PGnotify;


typedef void (*PQnoticeReceiver) (void *arg, const PGresult *res);
typedef void (*PQnoticeProcessor) (void *arg, const char *message);


typedef char pqbool;

typedef struct _PQprintOpt
{
 pqbool header;
 pqbool align;
 pqbool standard;
 pqbool html3;
 pqbool expanded;
 pqbool pager;
 char *fieldSep;
 char *tableOpt;
 char *caption;
 char **fieldName;

} PQprintOpt;
# 185 "libpq-fe.h"
typedef struct _PQconninfoOption
{
 char *keyword;
 char *envvar;
 char *compiled;
 char *val;
 char *label;
 char *dispchar;




 int dispsize;
} PQconninfoOption;





typedef struct
{
 int len;
 int isint;
 union
 {
  int *ptr;
  int integer;
 } u;
} PQArgBlock;





typedef struct pgresAttDesc
{
 char *name;
 Oid tableid;
 int columnid;
 int format;
 Oid typid;
 int typlen;
 int atttypmod;
} PGresAttDesc;
# 239 "libpq-fe.h"
extern PGconn *PQconnectStart(const char *conninfo);
extern PGconn *PQconnectStartParams(const char *const * keywords,
      const char *const * values, int expand_dbname);
extern PostgresPollingStatusType PQconnectPoll(PGconn *conn);


extern PGconn *PQconnectdb(const char *conninfo);
extern PGconn *PQconnectdbParams(const char *const * keywords,
      const char *const * values, int expand_dbname);
extern PGconn *PQsetdbLogin(const char *pghost, const char *pgport,
    const char *pgoptions, const char *pgtty,
    const char *dbName,
    const char *login, const char *pwd);





extern void PQfinish(PGconn *conn);


extern PQconninfoOption *PQconndefaults(void);


extern PQconninfoOption *PQconninfoParse(const char *conninfo, char **errmsg);


extern void PQconninfoFree(PQconninfoOption *connOptions);






extern int PQresetStart(PGconn *conn);
extern PostgresPollingStatusType PQresetPoll(PGconn *conn);


extern void PQreset(PGconn *conn);


extern PGcancel *PQgetCancel(PGconn *conn);


extern void PQfreeCancel(PGcancel *cancel);


extern int PQcancel(PGcancel *cancel, char *errbuf, int errbufsize);


extern int PQrequestCancel(PGconn *conn);


extern char *PQdb(const PGconn *conn);
extern char *PQuser(const PGconn *conn);
extern char *PQpass(const PGconn *conn);
extern char *PQhost(const PGconn *conn);
extern char *PQport(const PGconn *conn);
extern char *PQtty(const PGconn *conn);
extern char *PQoptions(const PGconn *conn);
extern ConnStatusType PQstatus(const PGconn *conn);
extern PGTransactionStatusType PQtransactionStatus(const PGconn *conn);
extern const char *PQparameterStatus(const PGconn *conn,
      const char *paramName);
extern int PQprotocolVersion(const PGconn *conn);
extern int PQserverVersion(const PGconn *conn);
extern char *PQerrorMessage(const PGconn *conn);
extern int PQsocket(const PGconn *conn);
extern int PQbackendPID(const PGconn *conn);
extern int PQconnectionNeedsPassword(const PGconn *conn);
extern int PQconnectionUsedPassword(const PGconn *conn);
extern int PQclientEncoding(const PGconn *conn);
extern int PQsetClientEncoding(PGconn *conn, const char *encoding);



extern void *PQgetssl(PGconn *conn);


extern void PQinitSSL(int do_init);


extern void PQinitOpenSSL(int do_ssl, int do_crypto);


extern PGVerbosity PQsetErrorVerbosity(PGconn *conn, PGVerbosity verbosity);


extern void PQtrace(PGconn *conn, FILE *debug_port);
extern void PQuntrace(PGconn *conn);


extern PQnoticeReceiver PQsetNoticeReceiver(PGconn *conn,
     PQnoticeReceiver proc,
     void *arg);
extern PQnoticeProcessor PQsetNoticeProcessor(PGconn *conn,
      PQnoticeProcessor proc,
      void *arg);
# 345 "libpq-fe.h"
typedef void (*pgthreadlock_t) (int acquire);

extern pgthreadlock_t PQregisterThreadLock(pgthreadlock_t newhandler);




extern PGresult *PQexec(PGconn *conn, const char *query);
extern PGresult *PQexecParams(PGconn *conn,
    const char *command,
    int nParams,
    const Oid *paramTypes,
    const char *const * paramValues,
    const int *paramLengths,
    const int *paramFormats,
    int resultFormat);
extern PGresult *PQprepare(PGconn *conn, const char *stmtName,
    const char *query, int nParams,
    const Oid *paramTypes);
extern PGresult *PQexecPrepared(PGconn *conn,
      const char *stmtName,
      int nParams,
      const char *const * paramValues,
      const int *paramLengths,
      const int *paramFormats,
      int resultFormat);


extern int PQsendQuery(PGconn *conn, const char *query);
extern int PQsendQueryParams(PGconn *conn,
      const char *command,
      int nParams,
      const Oid *paramTypes,
      const char *const * paramValues,
      const int *paramLengths,
      const int *paramFormats,
      int resultFormat);
extern int PQsendPrepare(PGconn *conn, const char *stmtName,
     const char *query, int nParams,
     const Oid *paramTypes);
extern int PQsendQueryPrepared(PGconn *conn,
     const char *stmtName,
     int nParams,
     const char *const * paramValues,
     const int *paramLengths,
     const int *paramFormats,
     int resultFormat);
extern int PQsetSingleRowMode(PGconn *conn);
extern PGresult *PQgetResult(PGconn *conn);


extern int PQisBusy(PGconn *conn);
extern int PQconsumeInput(PGconn *conn);


extern PGnotify *PQnotifies(PGconn *conn);


extern int PQputCopyData(PGconn *conn, const char *buffer, int nbytes);
extern int PQputCopyEnd(PGconn *conn, const char *errormsg);
extern int PQgetCopyData(PGconn *conn, char **buffer, int async);


extern int PQgetline(PGconn *conn, char *string, int length);
extern int PQputline(PGconn *conn, const char *string);
extern int PQgetlineAsync(PGconn *conn, char *buffer, int bufsize);
extern int PQputnbytes(PGconn *conn, const char *buffer, int nbytes);
extern int PQendcopy(PGconn *conn);


extern int PQsetnonblocking(PGconn *conn, int arg);
extern int PQisnonblocking(const PGconn *conn);
extern int PQisthreadsafe(void);
extern PGPing PQping(const char *conninfo);
extern PGPing PQpingParams(const char *const * keywords,
    const char *const * values, int expand_dbname);


extern int PQflush(PGconn *conn);





extern PGresult *PQfn(PGconn *conn,
  int fnid,
  int *result_buf,
  int *result_len,
  int result_is_int,
  const PQArgBlock *args,
  int nargs);


extern ExecStatusType PQresultStatus(const PGresult *res);
extern char *PQresStatus(ExecStatusType status);
extern char *PQresultErrorMessage(const PGresult *res);
extern char *PQresultErrorField(const PGresult *res, int fieldcode);
extern int PQntuples(const PGresult *res);
extern int PQnfields(const PGresult *res);
extern int PQbinaryTuples(const PGresult *res);
extern char *PQfname(const PGresult *res, int field_num);
extern int PQfnumber(const PGresult *res, const char *field_name);
extern Oid PQftable(const PGresult *res, int field_num);
extern int PQftablecol(const PGresult *res, int field_num);
extern int PQfformat(const PGresult *res, int field_num);
extern Oid PQftype(const PGresult *res, int field_num);
extern int PQfsize(const PGresult *res, int field_num);
extern int PQfmod(const PGresult *res, int field_num);
extern char *PQcmdStatus(PGresult *res);
extern char *PQoidStatus(const PGresult *res);
extern Oid PQoidValue(const PGresult *res);
extern char *PQcmdTuples(PGresult *res);
extern char *PQgetvalue(const PGresult *res, int tup_num, int field_num);
extern int PQgetlength(const PGresult *res, int tup_num, int field_num);
extern int PQgetisnull(const PGresult *res, int tup_num, int field_num);
extern int PQnparams(const PGresult *res);
extern Oid PQparamtype(const PGresult *res, int param_num);


extern PGresult *PQdescribePrepared(PGconn *conn, const char *stmt);
extern PGresult *PQdescribePortal(PGconn *conn, const char *portal);
extern int PQsendDescribePrepared(PGconn *conn, const char *stmt);
extern int PQsendDescribePortal(PGconn *conn, const char *portal);


extern void PQclear(PGresult *res);


extern void PQfreemem(void *ptr);
# 483 "libpq-fe.h"
extern PGresult *PQmakeEmptyPGresult(PGconn *conn, ExecStatusType status);
extern PGresult *PQcopyResult(const PGresult *src, int flags);
extern int PQsetResultAttrs(PGresult *res, int numAttributes, PGresAttDesc *attDescs);
extern void *PQresultAlloc(PGresult *res, size_t nBytes);
extern int PQsetvalue(PGresult *res, int tup_num, int field_num, char *value, int len);


extern size_t PQescapeStringConn(PGconn *conn,
       char *to, const char *from, size_t length,
       int *error);
extern char *PQescapeLiteral(PGconn *conn, const char *str, size_t len);
extern char *PQescapeIdentifier(PGconn *conn, const char *str, size_t len);
extern unsigned char *PQescapeByteaConn(PGconn *conn,
      const unsigned char *from, size_t from_length,
      size_t *to_length);
extern unsigned char *PQunescapeBytea(const unsigned char *strtext,
    size_t *retbuflen);


extern size_t PQescapeString(char *to, const char *from, size_t length);
extern unsigned char *PQescapeBytea(const unsigned char *from, size_t from_length,
     size_t *to_length);





extern void
PQprint(FILE *fout,
  const PGresult *res,
  const PQprintOpt *ps);




extern void
PQdisplayTuples(const PGresult *res,
    FILE *fp,
    int fillAlign,
    const char *fieldSep,
    int printHeader,
    int quiet);

extern void
PQprintTuples(const PGresult *res,
     FILE *fout,
     int printAttName,
     int terseOutput,
     int width);





extern int lo_open(PGconn *conn, Oid lobjId, int mode);
extern int lo_close(PGconn *conn, int fd);
extern int lo_read(PGconn *conn, int fd, char *buf, size_t len);
extern int lo_write(PGconn *conn, int fd, const char *buf, size_t len);
extern int lo_lseek(PGconn *conn, int fd, int offset, int whence);
extern Oid lo_creat(PGconn *conn, int mode);
extern Oid lo_create(PGconn *conn, Oid lobjId);
extern int lo_tell(PGconn *conn, int fd);
extern int lo_truncate(PGconn *conn, int fd, size_t len);
extern int lo_unlink(PGconn *conn, Oid lobjId);
extern Oid lo_import(PGconn *conn, const char *filename);
extern Oid lo_import_with_oid(PGconn *conn, const char *filename, Oid lobjId);
extern int lo_export(PGconn *conn, Oid lobjId, const char *filename);




extern int PQlibVersion(void);


extern int PQmblen(const char *s, int encoding);


extern int PQdsplen(const char *s, int encoding);


extern int PQenv2encoding(void);



extern char *PQencryptPassword(const char *passwd, const char *user);



extern int pg_char_to_encoding(const char *name);
extern const char *pg_encoding_to_char(int encoding);
extern int pg_valid_server_encoding_id(int encoding);
# 53 "tab-complete.c" 2

# 1 "common.h" 1
# 13 "common.h"
# 1 "getopt_long.h" 1
# 13 "getopt_long.h"
# 1 "/usr/include/getopt.h" 1 3 4
# 44 "/usr/include/getopt.h" 3 4
# 1 "./unistd.h" 1 3 4
# 45 "/usr/include/getopt.h" 2 3 4
# 54 "/usr/include/getopt.h" 3 4
struct option {

 const char *name;




 int has_arg;

 int *flag;

 int val;
};


int getopt_long(int, char * const *, const char *,
 const struct option *, int *);
int getopt_long_only(int, char * const *, const char *,
 const struct option *, int *);


int getopt(int, char * const [], const char *) __asm("_" "getopt" );

extern char *optarg;
extern int optind, opterr, optopt;



extern int optreset;


# 14 "getopt_long.h" 2



extern int opterr;
extern int optind;
extern int optopt;
extern char *optarg;
# 14 "common.h" 2


enum trivalue
{
 TRI_DEFAULT,
 TRI_NO,
 TRI_YES
};

typedef void (*help_handler) (const char *progname);

extern const char *get_user_name(const char *progname);

extern void handle_help_version_opts(int argc, char *argv[],
       const char *fixed_progname,
       help_handler hlp);

extern PGconn *connectDatabase(const char *dbname, const char *pghost,
    const char *pgport, const char *pguser,
    enum trivalue prompt_password, const char *progname,
    bool fail_ok);

extern PGconn *connectMaintenanceDatabase(const char *maintenance_db,
      const char *pghost, const char *pgport, const char *pguser,
      enum trivalue prompt_password, const char *progname);

extern PGresult *executeQuery(PGconn *conn, const char *query,
    const char *progname, bool echo);

extern void executeCommand(PGconn *conn, const char *query,
      const char *progname, bool echo);

extern bool executeMaintenanceCommand(PGconn *conn, const char *query,
        bool echo);

extern bool yesno_prompt(const char *question);

extern void setup_cancel_handler(void);

extern char *pg_strdup(const char *string);
# 55 "tab-complete.c" 2
# 1 "settings.h" 1
# 12 "settings.h"
# 1 "variables.h" 1
# 23 "variables.h"
typedef void (*VariableAssignHook) (const char *newval);

struct _variable
{
 char *name;
 char *value;
 VariableAssignHook assign_hook;
 struct _variable *next;
};

typedef struct _variable *VariableSpace;

VariableSpace CreateVariableSpace(void);
const char *GetVariable(VariableSpace space, const char *name);

bool ParseVariableBool(const char *val);
int ParseVariableNum(const char *val,
     int defaultval,
     int faultval,
     bool allowtrail);
int GetVariableNum(VariableSpace space,
      const char *name,
      int defaultval,
      int faultval,
      bool allowtrail);

void PrintVariables(VariableSpace space);

bool SetVariable(VariableSpace space, const char *name, const char *value);
bool SetVariableAssignHook(VariableSpace space, const char *name, VariableAssignHook hook);
bool SetVariableBool(VariableSpace space, const char *name);
bool DeleteVariable(VariableSpace space, const char *name);
# 13 "settings.h" 2
# 1 "print.h" 1
# 17 "print.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h"
typedef int16 AttrNumber;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/genbki.h" 1
# 49 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/genbki.h"
typedef int aclitem;
typedef int pg_node_tree;
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h" 2
# 36 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
typedef struct FormData_pg_attribute
{
 Oid attrelid;
 NameData attname;
# 48 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 Oid atttypid;
# 57 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int4 attstattarget;





 int2 attlen;
# 78 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int2 attnum;





 int4 attndims;
# 93 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int4 attcacheoff;







 int4 atttypmod;





 bool attbyval;
# 122 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 char attstorage;





 char attalign;


 bool attnotnull;


 bool atthasdef;


 bool attisdropped;


 bool attislocal;


 int4 attinhcount;


 Oid attcollation;
# 160 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
} FormData_pg_attribute;
# 176 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
typedef FormData_pg_attribute *Form_pg_attribute;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 1
# 40 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h" 1
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum NodeTag
{
 T_Invalid = 0,




 T_IndexInfo = 10,
 T_ExprContext,
 T_ProjectionInfo,
 T_JunkFilter,
 T_ResultRelInfo,
 T_EState,
 T_TupleTableSlot,




 T_Plan = 100,
 T_Result,
 T_ModifyTable,
 T_Append,
 T_MergeAppend,
 T_RecursiveUnion,
 T_BitmapAnd,
 T_BitmapOr,
 T_Scan,
 T_SeqScan,
 T_IndexScan,
 T_IndexOnlyScan,
 T_BitmapIndexScan,
 T_BitmapHeapScan,
 T_TidScan,
 T_SubqueryScan,
 T_FunctionScan,
 T_ValuesScan,
 T_CteScan,
 T_WorkTableScan,
 T_ForeignScan,
 T_Join,
 T_NestLoop,
 T_MergeJoin,
 T_HashJoin,
 T_Material,
 T_Sort,
 T_Group,
 T_Agg,
 T_WindowAgg,
 T_Unique,
 T_Hash,
 T_SetOp,
 T_LockRows,
 T_Limit,

 T_NestLoopParam,
 T_PlanRowMark,
 T_PlanInvalItem,






 T_PlanState = 200,
 T_ResultState,
 T_ModifyTableState,
 T_AppendState,
 T_MergeAppendState,
 T_RecursiveUnionState,
 T_BitmapAndState,
 T_BitmapOrState,
 T_ScanState,
 T_SeqScanState,
 T_IndexScanState,
 T_IndexOnlyScanState,
 T_BitmapIndexScanState,
 T_BitmapHeapScanState,
 T_TidScanState,
 T_SubqueryScanState,
 T_FunctionScanState,
 T_ValuesScanState,
 T_CteScanState,
 T_WorkTableScanState,
 T_ForeignScanState,
 T_JoinState,
 T_NestLoopState,
 T_MergeJoinState,
 T_HashJoinState,
 T_MaterialState,
 T_SortState,
 T_GroupState,
 T_AggState,
 T_WindowAggState,
 T_UniqueState,
 T_HashState,
 T_SetOpState,
 T_LockRowsState,
 T_LimitState,




 T_Alias = 300,
 T_RangeVar,
 T_Expr,
 T_Var,
 T_Const,
 T_Param,
 T_Aggref,
 T_WindowFunc,
 T_ArrayRef,
 T_FuncExpr,
 T_NamedArgExpr,
 T_OpExpr,
 T_DistinctExpr,
 T_NullIfExpr,
 T_ScalarArrayOpExpr,
 T_BoolExpr,
 T_SubLink,
 T_SubPlan,
 T_AlternativeSubPlan,
 T_FieldSelect,
 T_FieldStore,
 T_RelabelType,
 T_CoerceViaIO,
 T_ArrayCoerceExpr,
 T_ConvertRowtypeExpr,
 T_CollateExpr,
 T_CaseExpr,
 T_CaseWhen,
 T_CaseTestExpr,
 T_ArrayExpr,
 T_RowExpr,
 T_RowCompareExpr,
 T_CoalesceExpr,
 T_MinMaxExpr,
 T_XmlExpr,
 T_NullTest,
 T_BooleanTest,
 T_CoerceToDomain,
 T_CoerceToDomainValue,
 T_SetToDefault,
 T_CurrentOfExpr,
 T_TargetEntry,
 T_RangeTblRef,
 T_JoinExpr,
 T_FromExpr,
 T_IntoClause,







 T_ExprState = 400,
 T_GenericExprState,
 T_AggrefExprState,
 T_WindowFuncExprState,
 T_ArrayRefExprState,
 T_FuncExprState,
 T_ScalarArrayOpExprState,
 T_BoolExprState,
 T_SubPlanState,
 T_AlternativeSubPlanState,
 T_FieldSelectState,
 T_FieldStoreState,
 T_CoerceViaIOState,
 T_ArrayCoerceExprState,
 T_ConvertRowtypeExprState,
 T_CaseExprState,
 T_CaseWhenState,
 T_ArrayExprState,
 T_RowExprState,
 T_RowCompareExprState,
 T_CoalesceExprState,
 T_MinMaxExprState,
 T_XmlExprState,
 T_NullTestState,
 T_CoerceToDomainState,
 T_DomainConstraintState,
 T_WholeRowVarExprState,




 T_PlannerInfo = 500,
 T_PlannerGlobal,
 T_RelOptInfo,
 T_IndexOptInfo,
 T_ParamPathInfo,
 T_Path,
 T_IndexPath,
 T_BitmapHeapPath,
 T_BitmapAndPath,
 T_BitmapOrPath,
 T_NestPath,
 T_MergePath,
 T_HashPath,
 T_TidPath,
 T_ForeignPath,
 T_AppendPath,
 T_MergeAppendPath,
 T_ResultPath,
 T_MaterialPath,
 T_UniquePath,
 T_EquivalenceClass,
 T_EquivalenceMember,
 T_PathKey,
 T_RestrictInfo,
 T_PlaceHolderVar,
 T_SpecialJoinInfo,
 T_AppendRelInfo,
 T_PlaceHolderInfo,
 T_MinMaxAggInfo,
 T_PlannerParamItem,




 T_MemoryContext = 600,
 T_AllocSetContext,




 T_Value = 650,
 T_Integer,
 T_Float,
 T_String,
 T_BitString,
 T_Null,




 T_List,
 T_IntList,
 T_OidList,




 T_Query = 700,
 T_PlannedStmt,
 T_InsertStmt,
 T_DeleteStmt,
 T_UpdateStmt,
 T_SelectStmt,
 T_AlterTableStmt,
 T_AlterTableCmd,
 T_AlterDomainStmt,
 T_SetOperationStmt,
 T_GrantStmt,
 T_GrantRoleStmt,
 T_AlterDefaultPrivilegesStmt,
 T_ClosePortalStmt,
 T_ClusterStmt,
 T_CopyStmt,
 T_CreateStmt,
 T_DefineStmt,
 T_DropStmt,
 T_TruncateStmt,
 T_CommentStmt,
 T_FetchStmt,
 T_IndexStmt,
 T_CreateFunctionStmt,
 T_AlterFunctionStmt,
 T_DoStmt,
 T_RenameStmt,
 T_RuleStmt,
 T_NotifyStmt,
 T_ListenStmt,
 T_UnlistenStmt,
 T_TransactionStmt,
 T_ViewStmt,
 T_LoadStmt,
 T_CreateDomainStmt,
 T_CreatedbStmt,
 T_DropdbStmt,
 T_VacuumStmt,
 T_ExplainStmt,
 T_CreateTableAsStmt,
 T_CreateSeqStmt,
 T_AlterSeqStmt,
 T_VariableSetStmt,
 T_VariableShowStmt,
 T_DiscardStmt,
 T_CreateTrigStmt,
 T_CreatePLangStmt,
 T_CreateRoleStmt,
 T_AlterRoleStmt,
 T_DropRoleStmt,
 T_LockStmt,
 T_ConstraintsSetStmt,
 T_ReindexStmt,
 T_CheckPointStmt,
 T_CreateSchemaStmt,
 T_AlterDatabaseStmt,
 T_AlterDatabaseSetStmt,
 T_AlterRoleSetStmt,
 T_CreateConversionStmt,
 T_CreateCastStmt,
 T_CreateOpClassStmt,
 T_CreateOpFamilyStmt,
 T_AlterOpFamilyStmt,
 T_PrepareStmt,
 T_ExecuteStmt,
 T_DeallocateStmt,
 T_DeclareCursorStmt,
 T_CreateTableSpaceStmt,
 T_DropTableSpaceStmt,
 T_AlterObjectSchemaStmt,
 T_AlterOwnerStmt,
 T_DropOwnedStmt,
 T_ReassignOwnedStmt,
 T_CompositeTypeStmt,
 T_CreateEnumStmt,
 T_CreateRangeStmt,
 T_AlterEnumStmt,
 T_AlterTSDictionaryStmt,
 T_AlterTSConfigurationStmt,
 T_CreateFdwStmt,
 T_AlterFdwStmt,
 T_CreateForeignServerStmt,
 T_AlterForeignServerStmt,
 T_CreateUserMappingStmt,
 T_AlterUserMappingStmt,
 T_DropUserMappingStmt,
 T_AlterTableSpaceOptionsStmt,
 T_SecLabelStmt,
 T_CreateForeignTableStmt,
 T_CreateExtensionStmt,
 T_AlterExtensionStmt,
 T_AlterExtensionContentsStmt,




 T_A_Expr = 900,
 T_ColumnRef,
 T_ParamRef,
 T_A_Const,
 T_FuncCall,
 T_A_Star,
 T_A_Indices,
 T_A_Indirection,
 T_A_ArrayExpr,
 T_ResTarget,
 T_TypeCast,
 T_CollateClause,
 T_SortBy,
 T_WindowDef,
 T_RangeSubselect,
 T_RangeFunction,
 T_TypeName,
 T_ColumnDef,
 T_IndexElem,
 T_Constraint,
 T_DefElem,
 T_RangeTblEntry,
 T_SortGroupClause,
 T_WindowClause,
 T_PrivGrantee,
 T_FuncWithArgs,
 T_AccessPriv,
 T_CreateOpClassItem,
 T_TableLikeClause,
 T_FunctionParameter,
 T_LockingClause,
 T_RowMarkClause,
 T_XmlSerialize,
 T_WithClause,
 T_CommonTableExpr,




 T_IdentifySystemCmd,
 T_BaseBackupCmd,
 T_StartReplicationCmd,
# 416 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
 T_TriggerData = 950,
 T_ReturnSetInfo,
 T_WindowObjectData,
 T_TIDBitmap,
 T_InlineCodeBlock,
 T_FdwRoutine
} NodeTag;







typedef struct Node
{
 NodeTag type;
} Node;
# 491 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
extern char *nodeToString(const void *obj);




extern void *stringToNode(char *str);




extern void *copyObject(const void *obj);




extern bool equal(const void *a, const void *b);
# 517 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef double Selectivity;
typedef double Cost;
# 527 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum CmdType
{
 CMD_UNKNOWN,
 CMD_SELECT,
 CMD_UPDATE,
 CMD_INSERT,
 CMD_DELETE,
 CMD_UTILITY,

 CMD_NOTHING

} CmdType;
# 551 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum JoinType
{




 JOIN_INNER,
 JOIN_LEFT,
 JOIN_FULL,
 JOIN_RIGHT,
# 571 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
 JOIN_SEMI,
 JOIN_ANTI,





 JOIN_UNIQUE_OUTER,
 JOIN_UNIQUE_INNER




} JoinType;
# 41 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 2


typedef struct ListCell ListCell;

typedef struct List
{
 NodeTag type;
 int length;
 ListCell *head;
 ListCell *tail;
} List;

struct ListCell
{
 union
 {
  void *ptr_value;
  int int_value;
  Oid oid_value;
 } data;
 ListCell *next;
};
# 79 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
static inline ListCell *
list_head(const List *l)
{
 return l ? l->head : ((void *)0);
}

static inline ListCell *
list_tail(List *l)
{
 return l ? l->tail : ((void *)0);
}

static inline int
list_length(const List *l)
{
 return l ? l->length : 0;
}
# 194 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
extern List *lappend(List *list, void *datum);
extern List *lappend_int(List *list, int datum);
extern List *lappend_oid(List *list, Oid datum);

extern ListCell *lappend_cell(List *list, ListCell *prev, void *datum);
extern ListCell *lappend_cell_int(List *list, ListCell *prev, int datum);
extern ListCell *lappend_cell_oid(List *list, ListCell *prev, Oid datum);

extern List *lcons(void *datum, List *list);
extern List *lcons_int(int datum, List *list);
extern List *lcons_oid(Oid datum, List *list);

extern List *list_concat(List *list1, List *list2);
extern List *list_truncate(List *list, int new_size);

extern void *list_nth(const List *list, int n);
extern int list_nth_int(const List *list, int n);
extern Oid list_nth_oid(const List *list, int n);

extern bool list_member(const List *list, const void *datum);
extern bool list_member_ptr(const List *list, const void *datum);
extern bool list_member_int(const List *list, int datum);
extern bool list_member_oid(const List *list, Oid datum);

extern List *list_delete(List *list, void *datum);
extern List *list_delete_ptr(List *list, void *datum);
extern List *list_delete_int(List *list, int datum);
extern List *list_delete_oid(List *list, Oid datum);
extern List *list_delete_first(List *list);
extern List *list_delete_cell(List *list, ListCell *cell, ListCell *prev);

extern List *list_union(const List *list1, const List *list2);
extern List *list_union_ptr(const List *list1, const List *list2);
extern List *list_union_int(const List *list1, const List *list2);
extern List *list_union_oid(const List *list1, const List *list2);

extern List *list_intersection(const List *list1, const List *list2);



extern List *list_difference(const List *list1, const List *list2);
extern List *list_difference_ptr(const List *list1, const List *list2);
extern List *list_difference_int(const List *list1, const List *list2);
extern List *list_difference_oid(const List *list1, const List *list2);

extern List *list_append_unique(List *list, void *datum);
extern List *list_append_unique_ptr(List *list, void *datum);
extern List *list_append_unique_int(List *list, int datum);
extern List *list_append_unique_oid(List *list, Oid datum);

extern List *list_concat_unique(List *list1, List *list2);
extern List *list_concat_unique_ptr(List *list1, List *list2);
extern List *list_concat_unique_int(List *list1, List *list2);
extern List *list_concat_unique_oid(List *list1, List *list2);

extern void list_free(List *list);
extern void list_free_deep(List *list);

extern List *list_copy(const List *list);
extern List *list_copy_tail(const List *list, int nskip);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 2


typedef struct attrDefault
{
 AttrNumber adnum;
 char *adbin;
} AttrDefault;

typedef struct constrCheck
{
 char *ccname;
 char *ccbin;
 bool ccvalid;
 bool ccnoinherit;
} ConstrCheck;


typedef struct tupleConstr
{
 AttrDefault *defval;
 ConstrCheck *check;
 uint16 num_defval;
 uint16 num_check;
 bool has_not_null;
} TupleConstr;
# 71 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
typedef struct tupleDesc
{
 int natts;
 Form_pg_attribute *attrs;

 TupleConstr *constr;
 Oid tdtypeid;
 int32 tdtypmod;
 bool tdhasoid;
 int tdrefcount;
} *TupleDesc;


extern TupleDesc CreateTemplateTupleDesc(int natts, bool hasoid);

extern TupleDesc CreateTupleDesc(int natts, bool hasoid,
    Form_pg_attribute *attrs);

extern TupleDesc CreateTupleDescCopy(TupleDesc tupdesc);

extern TupleDesc CreateTupleDescCopyConstr(TupleDesc tupdesc);

extern void FreeTupleDesc(TupleDesc tupdesc);

extern void IncrTupleDescRefCount(TupleDesc tupdesc);
extern void DecrTupleDescRefCount(TupleDesc tupdesc);
# 110 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
extern bool equalTupleDescs(TupleDesc tupdesc1, TupleDesc tupdesc2);

extern void TupleDescInitEntry(TupleDesc desc,
       AttrNumber attributeNumber,
       const char *attributeName,
       Oid oidtypeid,
       int32 typmod,
       int attdim);

extern void TupleDescInitEntryCollation(TupleDesc desc,
       AttrNumber attributeNumber,
       Oid collationid);

extern TupleDesc BuildDescForRelation(List *schema);

extern TupleDesc BuildDescFromLists(List *names, List *types, List *typmods, List *collations);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupmacs.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h" 1
# 15 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
# 1 "/usr/include/fcntl.h" 1 3 4
# 23 "/usr/include/fcntl.h" 3 4
# 1 "/usr/include/sys/fcntl.h" 1 3 4
# 339 "/usr/include/sys/fcntl.h" 3 4
struct flock {
 off_t l_start;
 off_t l_len;
 pid_t l_pid;
 short l_type;
 short l_whence;
};
# 355 "/usr/include/sys/fcntl.h" 3 4
struct radvisory {
       off_t ra_offset;
       int ra_count;
};
# 367 "/usr/include/sys/fcntl.h" 3 4
typedef struct fsignatures {
 off_t fs_file_start;
 void *fs_blob_start;
 size_t fs_blob_size;
} fsignatures_t;
# 381 "/usr/include/sys/fcntl.h" 3 4
typedef struct fstore {
 unsigned int fst_flags;
 int fst_posmode;
 off_t fst_offset;
 off_t fst_length;
 off_t fst_bytesalloc;
} fstore_t;



typedef struct fbootstraptransfer {
  off_t fbt_offset;
  size_t fbt_length;
  void *fbt_buffer;
} fbootstraptransfer_t;
# 419 "/usr/include/sys/fcntl.h" 3 4
#pragma pack(4)

struct log2phys {
 unsigned int l2p_flags;
 off_t l2p_contigbytes;


 off_t l2p_devoffset;


};

#pragma pack()
# 442 "/usr/include/sys/fcntl.h" 3 4
struct _filesec;
typedef struct _filesec *filesec_t;


typedef enum {
 FILESEC_OWNER = 1,
 FILESEC_GROUP = 2,
 FILESEC_UUID = 3,
 FILESEC_MODE = 4,
 FILESEC_ACL = 5,
 FILESEC_GRPUUID = 6,


 FILESEC_ACL_RAW = 100,
 FILESEC_ACL_ALLOCSIZE = 101
} filesec_property_t;






int open(const char *, int, ...) __asm("_" "open" );
int creat(const char *, mode_t) __asm("_" "creat" );
int fcntl(int, int, ...) __asm("_" "fcntl" );


int openx_np(const char *, int, filesec_t);
int flock(int, int);
filesec_t filesec_init(void);
filesec_t filesec_dup(filesec_t);
void filesec_free(filesec_t);
int filesec_get_property(filesec_t, filesec_property_t, void *);
int filesec_query_property(filesec_t, filesec_property_t, int *);
int filesec_set_property(filesec_t, filesec_property_t, const void *);
int filesec_unset_property(filesec_t, filesec_property_t) __attribute__((visibility("default")));




# 23 "/usr/include/fcntl.h" 2 3 4
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h" 2
# 32 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
typedef struct XLogRecPtr
{
 uint32 xlogid;
 uint32 xrecoff;
} XLogRecPtr;
# 84 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
typedef uint32 TimeLineID;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/item.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/item.h"
typedef Pointer Item;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h"
typedef struct ItemIdData
{
 unsigned lp_off:15,
    lp_flags:2,
    lp_len:15;
} ItemIdData;

typedef ItemIdData *ItemId;
# 46 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h"
typedef uint16 ItemOffset;
typedef uint16 ItemLength;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h" 2






typedef uint16 OffsetNumber;
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 2
# 73 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef Pointer Page;
# 82 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef uint16 LocationIndex;
# 122 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef struct PageHeaderData
{

 XLogRecPtr pd_lsn;

 uint16 pd_tli;

 uint16 pd_flags;
 LocationIndex pd_lower;
 LocationIndex pd_upper;
 LocationIndex pd_special;
 uint16 pd_pagesize_version;
 TransactionId pd_prune_xid;
 ItemIdData pd_linp[1];
} PageHeaderData;

typedef PageHeaderData *PageHeader;
# 370 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
extern void PageInit(Page page, Size pageSize, Size specialSize);
extern bool PageHeaderIsValid(PageHeader page);
extern OffsetNumber PageAddItem(Page page, Item item, Size size,
   OffsetNumber offsetNumber, bool overwrite, bool is_heap);
extern Page PageGetTempPage(Page page);
extern Page PageGetTempPageCopy(Page page);
extern Page PageGetTempPageCopySpecial(Page page);
extern void PageRestoreTempPage(Page tempPage, Page oldPage);
extern void PageRepairFragmentation(Page page);
extern Size PageGetFreeSpace(Page page);
extern Size PageGetExactFreeSpace(Page page);
extern Size PageGetHeapFreeSpace(Page page);
extern void PageIndexTupleDelete(Page page, OffsetNumber offset);
extern void PageIndexMultiDelete(Page page, OffsetNumber *itemnos, int nitems);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h" 1
# 31 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h"
typedef uint32 BlockNumber;
# 53 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h"
typedef struct BlockIdData
{
 uint16 bi_hi;
 uint16 bi_lo;
} BlockIdData;

typedef BlockIdData *BlockId;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h" 2
# 37 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
typedef struct ItemPointerData
{
 BlockIdData ip_blkid;
 OffsetNumber ip_posid;
}




ItemPointerData;




typedef ItemPointerData *ItemPointer;
# 143 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
extern bool ItemPointerEquals(ItemPointer pointer1, ItemPointer pointer2);
extern int32 ItemPointerCompare(ItemPointer arg1, ItemPointer arg2);
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/backendid.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/backendid.h"
typedef int BackendId;



extern BackendId MyBackendId;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h" 2







typedef enum ForkNumber
{
 InvalidForkNumber = -1,
 MAIN_FORKNUM = 0,
 FSM_FORKNUM,
 VISIBILITYMAP_FORKNUM,
 INIT_FORKNUM





} ForkNumber;
# 77 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
typedef struct RelFileNode
{
 Oid spcNode;
 Oid dbNode;
 Oid relNode;
} RelFileNode;
# 92 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
typedef struct RelFileNodeBackend
{
 RelFileNode node;
 BackendId backend;
} RelFileNodeBackend;
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 107 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct HeapTupleFields
{
 TransactionId t_xmin;
 TransactionId t_xmax;

 union
 {
  CommandId t_cid;
  TransactionId t_xvac;
 } t_field3;
} HeapTupleFields;

typedef struct DatumTupleFields
{
 int32 datum_len_;

 int32 datum_typmod;

 Oid datum_typeid;





} DatumTupleFields;

typedef struct HeapTupleHeaderData
{
 union
 {
  HeapTupleFields t_heap;
  DatumTupleFields t_datum;
 } t_choice;

 ItemPointerData t_ctid;



 uint16 t_infomask2;

 uint16 t_infomask;

 uint8 t_hoff;



 bits8 t_bits[1];


} HeapTupleHeaderData;

typedef HeapTupleHeaderData *HeapTupleHeader;
# 461 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct MinimalTupleData
{
 uint32 t_len;

 char mt_padding[((__builtin_offsetof (HeapTupleHeaderData, t_infomask2) - sizeof(uint32)) % 8)];



 uint16 t_infomask2;

 uint16 t_infomask;

 uint8 t_hoff;



 bits8 t_bits[1];


} MinimalTupleData;

typedef MinimalTupleData *MinimalTuple;
# 517 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct HeapTupleData
{
 uint32 t_len;
 ItemPointerData t_self;
 Oid t_tableOid;
 HeapTupleHeader t_data;
} HeapTupleData;

typedef HeapTupleData *HeapTuple;
# 621 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heaptid
{
 RelFileNode node;
 ItemPointerData tid;
} xl_heaptid;




typedef struct xl_heap_delete
{
 xl_heaptid target;
 bool all_visible_cleared;
} xl_heap_delete;
# 646 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_header
{
 uint16 t_infomask2;
 uint16 t_infomask;
 uint8 t_hoff;
} xl_heap_header;




typedef struct xl_heap_insert
{
 xl_heaptid target;
 bool all_visible_cleared;

} xl_heap_insert;
# 671 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_multi_insert
{
 RelFileNode node;
 BlockNumber blkno;
 bool all_visible_cleared;
 uint16 ntuples;
 OffsetNumber offsets[1];


} xl_heap_multi_insert;



typedef struct xl_multi_insert_tuple
{
 uint16 datalen;
 uint16 t_infomask2;
 uint16 t_infomask;
 uint8 t_hoff;

} xl_multi_insert_tuple;




typedef struct xl_heap_update
{
 xl_heaptid target;
 ItemPointerData newtid;
 bool all_visible_cleared;
 bool new_all_visible_cleared;

} xl_heap_update;
# 718 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_clean
{
 RelFileNode node;
 BlockNumber block;
 TransactionId latestRemovedXid;
 uint16 nredirected;
 uint16 ndead;

} xl_heap_clean;
# 735 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_cleanup_info
{
 RelFileNode node;
 TransactionId latestRemovedXid;
} xl_heap_cleanup_info;





typedef struct xl_heap_newpage
{
 RelFileNode node;
 ForkNumber forknum;
 BlockNumber blkno;

} xl_heap_newpage;




typedef struct xl_heap_lock
{
 xl_heaptid target;
 TransactionId locking_xid;
 bool xid_is_mxact;
 bool shared_lock;
} xl_heap_lock;




typedef struct xl_heap_inplace
{
 xl_heaptid target;

} xl_heap_inplace;




typedef struct xl_heap_freeze
{
 RelFileNode node;
 BlockNumber block;
 TransactionId cutoff_xid;

} xl_heap_freeze;




typedef struct xl_heap_visible
{
 RelFileNode node;
 BlockNumber block;
 TransactionId cutoff_xid;
} xl_heap_visible;



extern void HeapTupleHeaderAdvanceLatestRemovedXid(HeapTupleHeader tuple,
            TransactionId *latestRemovedXid);


extern CommandId HeapTupleHeaderGetCmin(HeapTupleHeader tup);
extern CommandId HeapTupleHeaderGetCmax(HeapTupleHeader tup);
extern void HeapTupleHeaderAdjustCmax(HeapTupleHeader tup,
        CommandId *cmax,
        bool *iscombo);
# 890 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
extern Size heap_compute_data_size(TupleDesc tupleDesc,
        Datum *values, bool *isnull);
extern void heap_fill_tuple(TupleDesc tupleDesc,
    Datum *values, bool *isnull,
    char *data, Size data_size,
    uint16 *infomask, bits8 *bit);
extern bool heap_attisnull(HeapTuple tup, int attnum);
extern Datum nocachegetattr(HeapTuple tup, int attnum,
      TupleDesc att);
extern Datum heap_getsysattr(HeapTuple tup, int attnum, TupleDesc tupleDesc,
    bool *isnull);
extern HeapTuple heap_copytuple(HeapTuple tuple);
extern void heap_copytuple_with_tuple(HeapTuple src, HeapTuple dest);
extern HeapTuple heap_form_tuple(TupleDesc tupleDescriptor,
    Datum *values, bool *isnull);
extern HeapTuple heap_modify_tuple(HeapTuple tuple,
      TupleDesc tupleDesc,
      Datum *replValues,
      bool *replIsnull,
      bool *doReplace);
extern void heap_deform_tuple(HeapTuple tuple, TupleDesc tupleDesc,
      Datum *values, bool *isnull);


extern HeapTuple heap_formtuple(TupleDesc tupleDescriptor,
      Datum *values, char *nulls);
extern HeapTuple heap_modifytuple(HeapTuple tuple,
     TupleDesc tupleDesc,
     Datum *replValues,
     char *replNulls,
     char *replActions);
extern void heap_deformtuple(HeapTuple tuple, TupleDesc tupleDesc,
     Datum *values, char *nulls);
extern void heap_freetuple(HeapTuple htup);
extern MinimalTuple heap_form_minimal_tuple(TupleDesc tupleDescriptor,
      Datum *values, bool *isnull);
extern void heap_free_minimal_tuple(MinimalTuple mtup);
extern MinimalTuple heap_copy_minimal_tuple(MinimalTuple mtup);
extern HeapTuple heap_tuple_from_minimal_tuple(MinimalTuple mtup);
extern MinimalTuple minimal_tuple_from_heap_tuple(HeapTuple htup);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h"
typedef int Buffer;
# 44 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h"
typedef struct BufferAccessStrategyData *BufferAccessStrategy;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 2
# 112 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
typedef struct TupleTableSlot
{
 NodeTag type;
 bool tts_isempty;
 bool tts_shouldFree;
 bool tts_shouldFreeMin;
 bool tts_slow;
 HeapTuple tts_tuple;
 TupleDesc tts_tupleDescriptor;
 MemoryContext tts_mcxt;
 Buffer tts_buffer;
 int tts_nvalid;
 Datum *tts_values;
 bool *tts_isnull;
 MinimalTuple tts_mintuple;
 HeapTupleData tts_minhdr;
 long tts_off;
} TupleTableSlot;
# 141 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
extern TupleTableSlot *MakeTupleTableSlot(void);
extern TupleTableSlot *ExecAllocTableSlot(List **tupleTable);
extern void ExecResetTupleTable(List *tupleTable, bool shouldFree);
extern TupleTableSlot *MakeSingleTupleTableSlot(TupleDesc tupdesc);
extern void ExecDropSingleTupleTableSlot(TupleTableSlot *slot);
extern void ExecSetSlotDescriptor(TupleTableSlot *slot, TupleDesc tupdesc);
extern TupleTableSlot *ExecStoreTuple(HeapTuple tuple,
      TupleTableSlot *slot,
      Buffer buffer,
      bool shouldFree);
extern TupleTableSlot *ExecStoreMinimalTuple(MinimalTuple mtup,
       TupleTableSlot *slot,
       bool shouldFree);
extern TupleTableSlot *ExecClearTuple(TupleTableSlot *slot);
extern TupleTableSlot *ExecStoreVirtualTuple(TupleTableSlot *slot);
extern TupleTableSlot *ExecStoreAllNullTuple(TupleTableSlot *slot);
extern HeapTuple ExecCopySlotTuple(TupleTableSlot *slot);
extern MinimalTuple ExecCopySlotMinimalTuple(TupleTableSlot *slot);
extern HeapTuple ExecFetchSlotTuple(TupleTableSlot *slot);
extern MinimalTuple ExecFetchSlotMinimalTuple(TupleTableSlot *slot);
extern Datum ExecFetchSlotTupleDatum(TupleTableSlot *slot);
extern HeapTuple ExecMaterializeSlot(TupleTableSlot *slot);
extern TupleTableSlot *ExecCopySlot(TupleTableSlot *dstslot,
    TupleTableSlot *srcslot);


extern Datum slot_getattr(TupleTableSlot *slot, int attnum, bool *isnull);
extern void slot_getallattrs(TupleTableSlot *slot);
extern void slot_getsomeattrs(TupleTableSlot *slot, int attnum);
extern bool slot_attisnull(TupleTableSlot *slot, int attnum);
# 18 "print.h" 2




extern void print(const void *obj);
extern void pprint(const void *obj);
extern void elog_node_display(int lev, const char *title,
      const void *obj, bool pretty);
extern char *format_node_dump(const char *dump);
extern char *pretty_format_node_dump(const char *dump);
extern void print_rt(const List *rtable);
extern void print_expr(const Node *expr, const List *rtable);
extern void print_pathkeys(const List *pathkeys, const List *rtable);
extern void print_tl(const List *tlist, const List *rtable);
extern void print_slot(TupleTableSlot *slot);
# 14 "settings.h" 2
# 30 "settings.h"
typedef enum
{
 PSQL_ECHO_NONE,
 PSQL_ECHO_QUERIES,
 PSQL_ECHO_ALL
} PSQL_ECHO;

typedef enum
{
 PSQL_ECHO_HIDDEN_OFF,
 PSQL_ECHO_HIDDEN_ON,
 PSQL_ECHO_HIDDEN_NOEXEC
} PSQL_ECHO_HIDDEN;

typedef enum
{
 PSQL_ERROR_ROLLBACK_OFF,
 PSQL_ERROR_ROLLBACK_INTERACTIVE,
 PSQL_ERROR_ROLLBACK_ON
} PSQL_ERROR_ROLLBACK;

typedef enum
{
 hctl_none = 0,
 hctl_ignorespace = 1,
 hctl_ignoredups = 2,
 hctl_ignoreboth = hctl_ignorespace | hctl_ignoredups
} HistControl;

enum trivalue
{
 TRI_DEFAULT,
 TRI_NO,
 TRI_YES
};

typedef struct _psqlSettings
{
 PGconn *db;
 int encoding;
 FILE *queryFout;
 bool queryFoutPipe;

 printQueryOpt popt;

 char *gfname;

 bool notty;

 enum trivalue getPassword;
 FILE *cur_cmd_source;

 bool cur_cmd_interactive;
 int sversion;
 const char *progname;
 char *inputfile;
 char *dirname;

 uint64 lineno;

 bool timing;

 FILE *logfile;

 VariableSpace vars;






 bool autocommit;
 bool on_error_stop;
 bool quiet;
 bool singleline;
 bool singlestep;
 int fetch_count;
 PSQL_ECHO echo;
 PSQL_ECHO_HIDDEN echo_hidden;
 PSQL_ERROR_ROLLBACK on_error_rollback;
 HistControl histcontrol;
 const char *prompt1;
 const char *prompt2;
 const char *prompt3;
 PGVerbosity verbosity;
} PsqlSettings;

extern PsqlSettings pset;
# 56 "tab-complete.c" 2
# 1 "stringutils.h" 1
# 13 "stringutils.h"
extern char *strtokx(const char *s,
  const char *whitespace,
  const char *delim,
  const char *quote,
  char escape,
  bool e_strings,
  bool del_quotes,
  int encoding);

extern char *quote_if_needed(const char *source, const char *entails_quote,
    char quote, char escape, int encoding);
# 57 "tab-complete.c" 2
# 79 "tab-complete.c"
typedef struct SchemaQuery
{




 const char *catname;







 const char *selcondition;





 const char *viscondition;





 const char *namespace;





 const char *result;





 const char *qualresult;
} SchemaQuery;





static int completion_max_records;





static const char *completion_charp;
static const char *const * completion_charpp;
static const char *completion_info_charp;
static const char *completion_info_charp2;
static const SchemaQuery *completion_squery;
static bool completion_case_sensitive;
# 209 "tab-complete.c"
static const SchemaQuery Query_for_list_of_aggregates = {

 "pg_catalog.pg_proc p",

 "p.proisagg",

 "pg_catalog.pg_function_is_visible(p.oid)",

 "p.pronamespace",

 "pg_catalog.quote_ident(p.proname)",

 ((void *)0)
};

static const SchemaQuery Query_for_list_of_datatypes = {

 "pg_catalog.pg_type t",

 "(t.typrelid = 0 "
 " OR (SELECT c.relkind = 'c' FROM pg_catalog.pg_class c WHERE c.oid = t.typrelid)) "
 "AND t.typname !~ '^_'",

 "pg_catalog.pg_type_is_visible(t.oid)",

 "t.typnamespace",

 "pg_catalog.format_type(t.oid, NULL)",

 "pg_catalog.quote_ident(t.typname)"
};

static const SchemaQuery Query_for_list_of_domains = {

 "pg_catalog.pg_type t",

 "t.typtype = 'd'",

 "pg_catalog.pg_type_is_visible(t.oid)",

 "t.typnamespace",

 "pg_catalog.quote_ident(t.typname)",

 ((void *)0)
};

static const SchemaQuery Query_for_list_of_functions = {

 "pg_catalog.pg_proc p",

 ((void *)0),

 "pg_catalog.pg_function_is_visible(p.oid)",

 "p.pronamespace",

 "pg_catalog.quote_ident(p.proname)",

 ((void *)0)
};

static const SchemaQuery Query_for_list_of_indexes = {

 "pg_catalog.pg_class c",

 "c.relkind IN ('i')",

 "pg_catalog.pg_table_is_visible(c.oid)",

 "c.relnamespace",

 "pg_catalog.quote_ident(c.relname)",

 ((void *)0)
};

static const SchemaQuery Query_for_list_of_sequences = {

 "pg_catalog.pg_class c",

 "c.relkind IN ('S')",

 "pg_catalog.pg_table_is_visible(c.oid)",

 "c.relnamespace",

 "pg_catalog.quote_ident(c.relname)",

 ((void *)0)
};

static const SchemaQuery Query_for_list_of_foreign_tables = {

 "pg_catalog.pg_class c",

 "c.relkind IN ('f')",

 "pg_catalog.pg_table_is_visible(c.oid)",

 "c.relnamespace",

 "pg_catalog.quote_ident(c.relname)",

 ((void *)0)
};

static const SchemaQuery Query_for_list_of_tables = {

 "pg_catalog.pg_class c",

 "c.relkind IN ('r')",

 "pg_catalog.pg_table_is_visible(c.oid)",

 "c.relnamespace",

 "pg_catalog.quote_ident(c.relname)",

 ((void *)0)
};




static const SchemaQuery Query_for_list_of_insertables = {

 "pg_catalog.pg_class c",

 "(c.relkind = 'r' OR (c.relkind = 'v' AND c.relhastriggers AND EXISTS "
 "(SELECT 1 FROM pg_catalog.pg_trigger t WHERE t.tgrelid = c.oid AND t.tgtype & (1 << 2) <> 0)))",

 "pg_catalog.pg_table_is_visible(c.oid)",

 "c.relnamespace",

 "pg_catalog.quote_ident(c.relname)",

 ((void *)0)
};

static const SchemaQuery Query_for_list_of_deletables = {

 "pg_catalog.pg_class c",

 "(c.relkind = 'r' OR (c.relkind = 'v' AND c.relhastriggers AND EXISTS "
 "(SELECT 1 FROM pg_catalog.pg_trigger t WHERE t.tgrelid = c.oid AND t.tgtype & (1 << 3) <> 0)))",

 "pg_catalog.pg_table_is_visible(c.oid)",

 "c.relnamespace",

 "pg_catalog.quote_ident(c.relname)",

 ((void *)0)
};

static const SchemaQuery Query_for_list_of_updatables = {

 "pg_catalog.pg_class c",

 "(c.relkind = 'r' OR (c.relkind = 'v' AND c.relhastriggers AND EXISTS "
 "(SELECT 1 FROM pg_catalog.pg_trigger t WHERE t.tgrelid = c.oid AND t.tgtype & (1 << 4) <> 0)))",

 "pg_catalog.pg_table_is_visible(c.oid)",

 "c.relnamespace",

 "pg_catalog.quote_ident(c.relname)",

 ((void *)0)
};

static const SchemaQuery Query_for_list_of_relations = {

 "pg_catalog.pg_class c",

 ((void *)0),

 "pg_catalog.pg_table_is_visible(c.oid)",

 "c.relnamespace",

 "pg_catalog.quote_ident(c.relname)",

 ((void *)0)
};

static const SchemaQuery Query_for_list_of_tsvf = {

 "pg_catalog.pg_class c",

 "c.relkind IN ('r', 'S', 'v', 'f')",

 "pg_catalog.pg_table_is_visible(c.oid)",

 "c.relnamespace",

 "pg_catalog.quote_ident(c.relname)",

 ((void *)0)
};

static const SchemaQuery Query_for_list_of_tf = {

 "pg_catalog.pg_class c",

 "c.relkind IN ('r', 'f')",

 "pg_catalog.pg_table_is_visible(c.oid)",

 "c.relnamespace",

 "pg_catalog.quote_ident(c.relname)",

 ((void *)0)
};

static const SchemaQuery Query_for_list_of_views = {

 "pg_catalog.pg_class c",

 "c.relkind IN ('v')",

 "pg_catalog.pg_table_is_visible(c.oid)",

 "c.relnamespace",

 "pg_catalog.quote_ident(c.relname)",

 ((void *)0)
};
# 626 "tab-complete.c"
typedef struct
{
 const char *name;
 const char *query;
 const SchemaQuery *squery;
 const bits32 flags;
} pgsql_thing_t;





static const pgsql_thing_t words_after_create[] = {
 {"AGGREGATE", ((void *)0), &Query_for_list_of_aggregates},
 {"CAST", ((void *)0), ((void *)0)},

 {"COLLATION", "SELECT pg_catalog.quote_ident(collname) FROM pg_catalog.pg_collation WHERE collencoding IN (-1, pg_catalog.pg_char_to_encoding(pg_catalog.getdatabaseencoding())) AND substring(pg_catalog.quote_ident(collname),1,%d)='%s'"},





 {"CONFIGURATION", "SELECT pg_catalog.quote_ident(cfgname) FROM pg_catalog.pg_ts_config "" WHERE substring(pg_catalog.quote_ident(cfgname),1,%d)='%s'", ((void *)0), ((1 << 0) | (1 << 1))},
 {"CONVERSION", "SELECT pg_catalog.quote_ident(conname) FROM pg_catalog.pg_conversion WHERE substring(pg_catalog.quote_ident(conname),1,%d)='%s'"},
 {"DATABASE", "SELECT pg_catalog.quote_ident(datname) FROM pg_catalog.pg_database "" WHERE substring(pg_catalog.quote_ident(datname),1,%d)='%s'"},
 {"DICTIONARY", "SELECT pg_catalog.quote_ident(dictname) FROM pg_catalog.pg_ts_dict "" WHERE substring(pg_catalog.quote_ident(dictname),1,%d)='%s'", ((void *)0), ((1 << 0) | (1 << 1))},
 {"DOMAIN", ((void *)0), &Query_for_list_of_domains},
 {"EXTENSION", " SELECT pg_catalog.quote_ident(extname) ""   FROM pg_catalog.pg_extension ""  WHERE substring(pg_catalog.quote_ident(extname),1,%d)='%s'"},
 {"FOREIGN DATA WRAPPER", ((void *)0), ((void *)0)},
 {"FOREIGN TABLE", ((void *)0), ((void *)0)},
 {"FUNCTION", ((void *)0), &Query_for_list_of_functions},
 {"GROUP", " SELECT pg_catalog.quote_ident(rolname) ""   FROM pg_catalog.pg_roles ""  WHERE substring(pg_catalog.quote_ident(rolname),1,%d)='%s'"},
 {"LANGUAGE", "SELECT pg_catalog.quote_ident(lanname) ""  FROM pg_catalog.pg_language "" WHERE lanname != 'internal' ""   AND substring(pg_catalog.quote_ident(lanname),1,%d)='%s'"},
 {"INDEX", ((void *)0), &Query_for_list_of_indexes},
 {"OPERATOR", ((void *)0), ((void *)0)},

 {"OWNED", ((void *)0), ((void *)0), (1 << 0)},
 {"PARSER", "SELECT pg_catalog.quote_ident(prsname) FROM pg_catalog.pg_ts_parser "" WHERE substring(pg_catalog.quote_ident(prsname),1,%d)='%s'", ((void *)0), ((1 << 0) | (1 << 1))},
 {"ROLE", " SELECT pg_catalog.quote_ident(rolname) ""   FROM pg_catalog.pg_roles ""  WHERE substring(pg_catalog.quote_ident(rolname),1,%d)='%s'"},
 {"RULE", "SELECT pg_catalog.quote_ident(rulename) FROM pg_catalog.pg_rules WHERE substring(pg_catalog.quote_ident(rulename),1,%d)='%s'"},
 {"SCHEMA", "SELECT pg_catalog.quote_ident(nspname) FROM pg_catalog.pg_namespace "" WHERE substring(pg_catalog.quote_ident(nspname),1,%d)='%s'"},
 {"SEQUENCE", ((void *)0), &Query_for_list_of_sequences},
 {"SERVER", " SELECT pg_catalog.quote_ident(srvname) ""   FROM pg_catalog.pg_foreign_server ""  WHERE substring(pg_catalog.quote_ident(srvname),1,%d)='%s'"},
 {"TABLE", ((void *)0), &Query_for_list_of_tables},
 {"TABLESPACE", "SELECT pg_catalog.quote_ident(spcname) FROM pg_catalog.pg_tablespace "" WHERE substring(pg_catalog.quote_ident(spcname),1,%d)='%s'"},
 {"TEMP", ((void *)0), ((void *)0), (1 << 1)},
 {"TEMPLATE", "SELECT pg_catalog.quote_ident(tmplname) FROM pg_catalog.pg_ts_template "" WHERE substring(pg_catalog.quote_ident(tmplname),1,%d)='%s'", ((void *)0), ((1 << 0) | (1 << 1))},
 {"TEXT SEARCH", ((void *)0), ((void *)0)},
 {"TRIGGER", "SELECT pg_catalog.quote_ident(tgname) FROM pg_catalog.pg_trigger WHERE substring(pg_catalog.quote_ident(tgname),1,%d)='%s'"},
 {"TYPE", ((void *)0), &Query_for_list_of_datatypes},
 {"UNIQUE", ((void *)0), ((void *)0), (1 << 1)},
 {"UNLOGGED", ((void *)0), ((void *)0), (1 << 1)},

 {"USER", " SELECT pg_catalog.quote_ident(rolname) ""   FROM pg_catalog.pg_roles ""  WHERE substring(pg_catalog.quote_ident(rolname),1,%d)='%s'"},
 {"USER MAPPING FOR", ((void *)0), ((void *)0)},
 {"VIEW", ((void *)0), &Query_for_list_of_views},
 {((void *)0)}
};



static char **psql_completion(char *text, int start, int end);
static char *create_command_generator(const char *text, int state);
static char *drop_command_generator(const char *text, int state);
static char *complete_from_query(const char *text, int state);
static char *complete_from_schema_query(const char *text, int state);
static char *_complete_from_query(int is_schema_query,
      const char *text, int state);
static char *complete_from_list(const char *text, int state);
static char *complete_from_const(const char *text, int state);
static char **complete_from_variables(char *text,
      const char *prefix, const char *suffix);
static char *complete_from_files(const char *text, int state);

static char *pg_strdup_keyword_case(const char *s, const char *ref);
static PGresult *exec_query(const char *query);

static void get_previous_words(int point, char **previous_words, int nwords);
# 714 "tab-complete.c"
void
initialize_readline(void)
{
 rl_readline_name = (char *) pset.progname;
 rl_attempted_completion_function = (void *) psql_completion;

 rl_basic_word_break_characters = "\t\n@$><=;|&{() ";

 completion_max_records = 1000;





}
# 739 "tab-complete.c"
static char **
psql_completion(char *text, int start, int end)
{

 char **matches = ((void *)0);


 char *previous_words[6];
# 756 "tab-complete.c"
 static const char *const sql_commands[] = {
  "ABORT", "ALTER", "ANALYZE", "BEGIN", "CHECKPOINT", "CLOSE", "CLUSTER",
  "COMMENT", "COMMIT", "COPY", "CREATE", "DEALLOCATE", "DECLARE",
  "DELETE FROM", "DISCARD", "DO", "DROP", "END", "EXECUTE", "EXPLAIN", "FETCH",
  "GRANT", "INSERT", "LISTEN", "LOAD", "LOCK", "MOVE", "NOTIFY", "PREPARE",
  "REASSIGN", "REINDEX", "RELEASE", "RESET", "REVOKE", "ROLLBACK",
  "SAVEPOINT", "SECURITY LABEL", "SELECT", "SET", "SHOW", "START",
  "TABLE", "TRUNCATE", "UNLISTEN", "UPDATE", "VACUUM", "VALUES", "WITH",
  ((void *)0)
 };

 static const char *const backslash_commands[] = {
  "\\a", "\\connect", "\\conninfo", "\\C", "\\cd", "\\copy", "\\copyright",
  "\\d", "\\da", "\\db", "\\dc", "\\dC", "\\dd", "\\dD", "\\des", "\\det", "\\deu", "\\dew", "\\df",
  "\\dF", "\\dFd", "\\dFp", "\\dFt", "\\dg", "\\di", "\\dl", "\\dL",
  "\\dn", "\\do", "\\dp", "\\drds", "\\ds", "\\dS", "\\dt", "\\dT", "\\dv", "\\du",
  "\\e", "\\echo", "\\ef", "\\encoding",
  "\\f", "\\g", "\\h", "\\help", "\\H", "\\i", "\\ir", "\\l",
  "\\lo_import", "\\lo_export", "\\lo_list", "\\lo_unlink",
  "\\o", "\\p", "\\password", "\\prompt", "\\pset", "\\q", "\\qecho", "\\r",
  "\\set", "\\sf", "\\t", "\\T",
  "\\timing", "\\unset", "\\x", "\\w", "\\z", "\\!", ((void *)0)
 };

 (void) end;


 rl_completion_append_character = ' ';



 completion_charp = ((void *)0);
 completion_charpp = ((void *)0);
 completion_info_charp = ((void *)0);
 completion_info_charp2 = ((void *)0);






 get_previous_words(start, previous_words, (sizeof (previous_words) / sizeof ((previous_words)[0])));


 if (text[0] == '\\')
  do { completion_charpp = backslash_commands; completion_case_sensitive = ((bool) 1); matches = rl_completion_matches(text, complete_from_list); } while (0);


 else if (text[0] == ':' && text[1] != ':')
 {
  if (text[1] == '\'')
   matches = complete_from_variables(text, ":'", "'");
  else if (text[1] == '"')
   matches = complete_from_variables(text, ":\"", "\"");
  else
   matches = complete_from_variables(text, ":", "");
 }


 else if ((previous_words[0])[0] == '\0')
  do { completion_charpp = sql_commands; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);



 else if (pg_strcasecmp((previous_words[0]), "CREATE") == 0)
  matches = rl_completion_matches(text, create_command_generator);



 else if (pg_strcasecmp((previous_words[0]), "DROP") == 0 &&
    (previous_words[1])[0] == '\0')
  matches = rl_completion_matches(text, drop_command_generator);







 else if (pg_strcasecmp((previous_words[0]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "TABLE") != 0)
 {
  static const char *const list_ALTER[] =
  {"AGGREGATE", "COLLATION", "CONVERSION", "DATABASE", "DEFAULT PRIVILEGES", "DOMAIN",
   "EXTENSION", "FOREIGN DATA WRAPPER", "FOREIGN TABLE", "FUNCTION",
   "GROUP", "INDEX", "LANGUAGE", "LARGE OBJECT", "OPERATOR",
   "ROLE", "SCHEMA", "SERVER", "SEQUENCE", "TABLE",
   "TABLESPACE", "TEXT SEARCH", "TRIGGER", "TYPE",
  "USER", "USER MAPPING FOR", "VIEW", ((void *)0)};

  do { completion_charpp = list_ALTER; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    (pg_strcasecmp((previous_words[1]), "AGGREGATE") == 0 ||
     pg_strcasecmp((previous_words[1]), "FUNCTION") == 0))
  do { completion_charp = "("; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);

 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    (pg_strcasecmp((previous_words[2]), "AGGREGATE") == 0 ||
     pg_strcasecmp((previous_words[2]), "FUNCTION") == 0))
 {
  if ((previous_words[0])[strlen((previous_words[0])) - 1] == ')')
  {
   static const char *const list_ALTERAGG[] =
   {"OWNER TO", "RENAME TO", "SET SCHEMA", ((void *)0)};

   do { completion_charpp = list_ALTERAGG; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
  }
  else
  {
   char *tmp_buf = malloc(strlen(" SELECT pg_catalog.oidvectortypes(proargtypes)||')' ""   FROM pg_catalog.pg_proc ""  WHERE proname='%s'") + strlen((previous_words[1])));

   __builtin___sprintf_chk (tmp_buf, 0, __builtin_object_size (tmp_buf, 2 > 1), " SELECT pg_catalog.oidvectortypes(proargtypes)||')' ""   FROM pg_catalog.pg_proc ""  WHERE proname='%s'", (previous_words[1]));
   do { completion_charp = tmp_buf; matches = rl_completion_matches(text, complete_from_query); } while (0);
   free(tmp_buf);
  }
 }


 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[1]), "SCHEMA") == 0)
 {
  static const char *const list_ALTERGEN[] =
  {"OWNER TO", "RENAME TO", ((void *)0)};

  do { completion_charpp = list_ALTERGEN; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[1]), "COLLATION") == 0)
 {
  static const char *const list_ALTERGEN[] =
  {"OWNER TO", "RENAME TO", "SET SCHEMA", ((void *)0)};

  do { completion_charpp = list_ALTERGEN; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[1]), "CONVERSION") == 0)
 {
  static const char *const list_ALTERGEN[] =
  {"OWNER TO", "RENAME TO", "SET SCHEMA", ((void *)0)};

  do { completion_charpp = list_ALTERGEN; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[1]), "DATABASE") == 0)
 {
  static const char *const list_ALTERDATABASE[] =
  {"RESET", "SET", "OWNER TO", "RENAME TO", "CONNECTION LIMIT", ((void *)0)};

  do { completion_charpp = list_ALTERDATABASE; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[1]), "EXTENSION") == 0)
 {
  static const char *const list_ALTEREXTENSION[] =
  {"ADD", "DROP", "UPDATE", "SET SCHEMA", ((void *)0)};

  do { completion_charpp = list_ALTEREXTENSION; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[1]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[0]), "FOREIGN") == 0)
 {
  static const char *const list_ALTER_FOREIGN[] =
  {"DATA WRAPPER", "TABLE", ((void *)0)};

  do { completion_charpp = list_ALTER_FOREIGN; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[4]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[3]), "FOREIGN") == 0 &&
    pg_strcasecmp((previous_words[2]), "DATA") == 0 &&
    pg_strcasecmp((previous_words[1]), "WRAPPER") == 0)
 {
  static const char *const list_ALTER_FDW[] =
  {"HANDLER", "VALIDATOR", "OPTIONS", "OWNER TO", ((void *)0)};

  do { completion_charpp = list_ALTER_FDW; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "FOREIGN") == 0 &&
    pg_strcasecmp((previous_words[1]), "TABLE") == 0)
 {
  static const char *const list_ALTER_FOREIGN_TABLE[] =
  {"ALTER", "DROP", "RENAME", "OWNER TO", "SET SCHEMA", ((void *)0)};

  do { completion_charpp = list_ALTER_FOREIGN_TABLE; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[1]), "INDEX") == 0)
 {
  static const char *const list_ALTERINDEX[] =
  {"OWNER TO", "RENAME TO", "SET", "RESET", ((void *)0)};

  do { completion_charpp = list_ALTERINDEX; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "INDEX") == 0 &&
    pg_strcasecmp((previous_words[0]), "SET") == 0)
 {
  static const char *const list_ALTERINDEXSET[] =
  {"(", "TABLESPACE", ((void *)0)};

  do { completion_charpp = list_ALTERINDEXSET; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "INDEX") == 0 &&
    pg_strcasecmp((previous_words[0]), "RESET") == 0)
  do { completion_charp = "("; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);

 else if (pg_strcasecmp((previous_words[4]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[3]), "INDEX") == 0 &&
    (pg_strcasecmp((previous_words[1]), "SET") == 0 ||
     pg_strcasecmp((previous_words[1]), "RESET") == 0) &&
    pg_strcasecmp((previous_words[0]), "(") == 0)
 {
  static const char *const list_INDEXOPTIONS[] =
  {"fillfactor", "fastupdate", ((void *)0)};

  do { completion_charpp = list_INDEXOPTIONS; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[1]), "LANGUAGE") == 0)
 {
  static const char *const list_ALTERLANGUAGE[] =
  {"OWNER TO", "RENAME TO", ((void *)0)};

  do { completion_charpp = list_ALTERLANGUAGE; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "LARGE") == 0 &&
    pg_strcasecmp((previous_words[1]), "OBJECT") == 0)
 {
  static const char *const list_ALTERLARGEOBJECT[] =
  {"OWNER TO", ((void *)0)};

  do { completion_charpp = list_ALTERLARGEOBJECT; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    !(pg_strcasecmp((previous_words[1]), "USER") == 0 && pg_strcasecmp((previous_words[0]), "MAPPING") == 0) &&
    (pg_strcasecmp((previous_words[1]), "USER") == 0 ||
     pg_strcasecmp((previous_words[1]), "ROLE") == 0))
 {
  static const char *const list_ALTERUSER[] =
  {"CONNECTION LIMIT", "CREATEDB", "CREATEROLE", "CREATEUSER",
   "ENCRYPTED", "INHERIT", "LOGIN", "NOCREATEDB", "NOCREATEROLE",
   "NOCREATEUSER", "NOINHERIT", "NOLOGIN", "NOREPLICATION",
   "NOSUPERUSER", "RENAME TO", "REPLICATION", "RESET", "SET",
  "SUPERUSER", "UNENCRYPTED", "VALID UNTIL", "WITH", ((void *)0)};

  do { completion_charpp = list_ALTERUSER; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if ((pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
     (pg_strcasecmp((previous_words[2]), "USER") == 0 ||
      pg_strcasecmp((previous_words[2]), "ROLE") == 0) &&
     pg_strcasecmp((previous_words[0]), "WITH") == 0))
 {

  static const char *const list_ALTERUSER_WITH[] =
  {"CONNECTION LIMIT", "CREATEDB", "CREATEROLE", "CREATEUSER",
   "ENCRYPTED", "INHERIT", "LOGIN", "NOCREATEDB", "NOCREATEROLE",
   "NOCREATEUSER", "NOINHERIT", "NOLOGIN", "NOREPLICATION",
   "NOSUPERUSER", "RENAME TO", "REPLICATION", "RESET", "SET",
  "SUPERUSER", "UNENCRYPTED", "VALID UNTIL", ((void *)0)};

  do { completion_charpp = list_ALTERUSER_WITH; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    (pg_strcasecmp((previous_words[2]), "ROLE") == 0 || pg_strcasecmp((previous_words[2]), "USER") == 0) &&
    (pg_strcasecmp((previous_words[0]), "ENCRYPTED") == 0 || pg_strcasecmp((previous_words[0]), "UNENCRYPTED") == 0))
 {
  do { completion_charp = "PASSWORD"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 }

 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[1]), "DEFAULT") == 0 &&
    pg_strcasecmp((previous_words[0]), "PRIVILEGES") == 0)
 {
  static const char *const list_ALTER_DEFAULT_PRIVILEGES[] =
  {"FOR ROLE", "FOR USER", "IN SCHEMA", ((void *)0)};

  do { completion_charpp = list_ALTER_DEFAULT_PRIVILEGES; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "DEFAULT") == 0 &&
    pg_strcasecmp((previous_words[1]), "PRIVILEGES") == 0 &&
    pg_strcasecmp((previous_words[0]), "FOR") == 0)
 {
  static const char *const list_ALTER_DEFAULT_PRIVILEGES_FOR[] =
  {"ROLE", "USER", ((void *)0)};

  do { completion_charpp = list_ALTER_DEFAULT_PRIVILEGES_FOR; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[4]), "DEFAULT") == 0 &&
    pg_strcasecmp((previous_words[3]), "PRIVILEGES") == 0 &&
    (pg_strcasecmp((previous_words[2]), "FOR") == 0 ||
     pg_strcasecmp((previous_words[2]), "IN") == 0))
 {
  static const char *const list_ALTER_DEFAULT_PRIVILEGES_REST[] =
  {"GRANT", "REVOKE", ((void *)0)};

  do { completion_charpp = list_ALTER_DEFAULT_PRIVILEGES_REST; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[1]), "DOMAIN") == 0)
 {
  static const char *const list_ALTERDOMAIN[] =
  {"ADD", "DROP", "OWNER TO", "RENAME", "SET", "VALIDATE CONSTRAINT", ((void *)0)};

  do { completion_charpp = list_ALTERDOMAIN; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "DOMAIN") == 0 &&
    pg_strcasecmp((previous_words[0]), "DROP") == 0)
 {
  static const char *const list_ALTERDOMAIN2[] =
  {"CONSTRAINT", "DEFAULT", "NOT NULL", ((void *)0)};

  do { completion_charpp = list_ALTERDOMAIN2; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "DOMAIN") == 0 &&
    pg_strcasecmp((previous_words[0]), "RENAME") == 0)
 {
  static const char *const list_ALTERDOMAIN[] =
  {"CONSTRAINT", "TO", ((void *)0)};

  do { completion_charpp = list_ALTERDOMAIN; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[4]), "DOMAIN") == 0 &&
    pg_strcasecmp((previous_words[2]), "RENAME") == 0 &&
    pg_strcasecmp((previous_words[1]), "CONSTRAINT") == 0)
  do { completion_charp = "TO"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);


 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "DOMAIN") == 0 &&
    pg_strcasecmp((previous_words[0]), "SET") == 0)
 {
  static const char *const list_ALTERDOMAIN3[] =
  {"DEFAULT", "NOT NULL", "SCHEMA", ((void *)0)};

  do { completion_charpp = list_ALTERDOMAIN3; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[1]), "SEQUENCE") == 0)
 {
  static const char *const list_ALTERSEQUENCE[] =
  {"INCREMENT", "MINVALUE", "MAXVALUE", "RESTART", "NO", "CACHE", "CYCLE",
  "SET SCHEMA", "OWNED BY", "OWNER TO", "RENAME TO", ((void *)0)};

  do { completion_charpp = list_ALTERSEQUENCE; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "SEQUENCE") == 0 &&
    pg_strcasecmp((previous_words[0]), "NO") == 0)
 {
  static const char *const list_ALTERSEQUENCE2[] =
  {"MINVALUE", "MAXVALUE", "CYCLE", ((void *)0)};

  do { completion_charpp = list_ALTERSEQUENCE2; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[1]), "SERVER") == 0)
 {
  static const char *const list_ALTER_SERVER[] =
  {"VERSION", "OPTIONS", "OWNER TO", ((void *)0)};

  do { completion_charpp = list_ALTER_SERVER; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[1]), "VIEW") == 0)
 {
  static const char *const list_ALTERVIEW[] =
  {"ALTER COLUMN", "OWNER TO", "RENAME TO", "SET SCHEMA", ((void *)0)};

  do { completion_charpp = list_ALTERVIEW; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[1]), "TRIGGER") == 0)
  do { completion_charp = "ON"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);

 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "TRIGGER") == 0)
 {
  completion_info_charp = (previous_words[1]);
  do { completion_charp = "SELECT pg_catalog.quote_ident(relname) ""  FROM pg_catalog.pg_class"" WHERE (%d = pg_catalog.length('%s'))""   AND oid IN ""       (SELECT tgrelid FROM pg_catalog.pg_trigger ""         WHERE pg_catalog.quote_ident(tgname)='%s')"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 }




 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "TRIGGER") == 0 &&
    pg_strcasecmp((previous_words[0]), "ON") == 0)
  do { completion_squery = &(Query_for_list_of_tables); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);


 else if (pg_strcasecmp((previous_words[3]), "TRIGGER") == 0 &&
    pg_strcasecmp((previous_words[1]), "ON") == 0)
  do { completion_charp = "RENAME TO"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);




 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[1]), "TABLE") == 0)
 {
  static const char *const list_ALTER2[] =
  {"ADD", "ALTER", "CLUSTER ON", "DISABLE", "DROP", "ENABLE", "INHERIT",
   "NO INHERIT", "RENAME", "RESET", "OWNER TO", "SET",
  "VALIDATE CONSTRAINT", ((void *)0)};

  do { completion_charpp = list_ALTER2; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "TABLE") == 0 &&
    pg_strcasecmp((previous_words[0]), "ENABLE") == 0)
 {
  static const char *const list_ALTERENABLE[] =
  {"ALWAYS", "REPLICA", "RULE", "TRIGGER", ((void *)0)};

  do { completion_charpp = list_ALTERENABLE; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
 else if (pg_strcasecmp((previous_words[3]), "TABLE") == 0 &&
    pg_strcasecmp((previous_words[1]), "ENABLE") == 0 &&
    (pg_strcasecmp((previous_words[0]), "REPLICA") == 0 ||
     pg_strcasecmp((previous_words[0]), "ALWAYS") == 0))
 {
  static const char *const list_ALTERENABLE2[] =
  {"RULE", "TRIGGER", ((void *)0)};

  do { completion_charpp = list_ALTERENABLE2; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "TABLE") == 0 &&
    pg_strcasecmp((previous_words[0]), "DISABLE") == 0)
 {
  static const char *const list_ALTERDISABLE[] =
  {"RULE", "TRIGGER", ((void *)0)};

  do { completion_charpp = list_ALTERDISABLE; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "TABLE") == 0 &&
    pg_strcasecmp((previous_words[0]), "ALTER") == 0)
  do { char *_completion_schema; char *_completion_table; _completion_schema = strtokx((previous_words[1]), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); (void) strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); _completion_table = strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); if (_completion_table == ((void *)0)) { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c "" WHERE c.oid = a.attrelid ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"'='%s') ""   AND pg_catalog.pg_table_is_visible(c.oid)" " UNION SELECT 'COLUMN'"; completion_info_charp = (previous_words[1]); } else { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c, pg_catalog.pg_namespace n "" WHERE c.oid = a.attrelid ""   AND n.oid = c.relnamespace ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"' ='%s') ""   AND (pg_catalog.quote_ident(nspname)='%s' ""        OR '\"' || nspname || '\"' ='%s') " " UNION SELECT 'COLUMN'"; completion_info_charp = _completion_table; completion_info_charp2 = _completion_schema; } matches = rl_completion_matches(text, complete_from_query); } while (0);


 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "TABLE") == 0 &&
    pg_strcasecmp((previous_words[0]), "RENAME") == 0)
  do { char *_completion_schema; char *_completion_table; _completion_schema = strtokx((previous_words[1]), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); (void) strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); _completion_table = strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); if (_completion_table == ((void *)0)) { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c "" WHERE c.oid = a.attrelid ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"'='%s') ""   AND pg_catalog.pg_table_is_visible(c.oid)" " UNION SELECT 'COLUMN' UNION SELECT 'CONSTRAINT' UNION SELECT 'TO'"; completion_info_charp = (previous_words[1]); } else { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c, pg_catalog.pg_namespace n "" WHERE c.oid = a.attrelid ""   AND n.oid = c.relnamespace ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"' ='%s') ""   AND (pg_catalog.quote_ident(nspname)='%s' ""        OR '\"' || nspname || '\"' ='%s') " " UNION SELECT 'COLUMN' UNION SELECT 'CONSTRAINT' UNION SELECT 'TO'"; completion_info_charp = _completion_table; completion_info_charp2 = _completion_schema; } matches = rl_completion_matches(text, complete_from_query); } while (0);





 else if (pg_strcasecmp((previous_words[3]), "TABLE") == 0 &&
    (pg_strcasecmp((previous_words[1]), "ALTER") == 0 ||
     pg_strcasecmp((previous_words[1]), "RENAME") == 0) &&
    pg_strcasecmp((previous_words[0]), "COLUMN") == 0)
  do { char *_completion_schema; char *_completion_table; _completion_schema = strtokx((previous_words[2]), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); (void) strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); _completion_table = strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); if (_completion_table == ((void *)0)) { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c "" WHERE c.oid = a.attrelid ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"'='%s') ""   AND pg_catalog.pg_table_is_visible(c.oid)" ""; completion_info_charp = (previous_words[2]); } else { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c, pg_catalog.pg_namespace n "" WHERE c.oid = a.attrelid ""   AND n.oid = c.relnamespace ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"' ='%s') ""   AND (pg_catalog.quote_ident(nspname)='%s' ""        OR '\"' || nspname || '\"' ='%s') " ""; completion_info_charp = _completion_table; completion_info_charp2 = _completion_schema; } matches = rl_completion_matches(text, complete_from_query); } while (0);


 else if (pg_strcasecmp((previous_words[3]), "TABLE") == 0 &&
    pg_strcasecmp((previous_words[1]), "RENAME") == 0 &&
    pg_strcasecmp((previous_words[0]), "CONSTRAINT") != 0 &&
    pg_strcasecmp((previous_words[0]), "TO") != 0)
  do { completion_charp = "TO"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);


 else if (pg_strcasecmp((previous_words[4]), "TABLE") == 0 &&
    pg_strcasecmp((previous_words[2]), "RENAME") == 0 &&
    (pg_strcasecmp((previous_words[1]), "COLUMN") == 0 ||
     pg_strcasecmp((previous_words[1]), "CONSTRAINT") == 0) &&
    pg_strcasecmp((previous_words[0]), "TO") != 0)
  do { completion_charp = "TO"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);


 else if (pg_strcasecmp((previous_words[2]), "TABLE") == 0 &&
    pg_strcasecmp((previous_words[0]), "DROP") == 0)
 {
  static const char *const list_TABLEDROP[] =
  {"COLUMN", "CONSTRAINT", ((void *)0)};

  do { completion_charpp = list_TABLEDROP; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[3]), "TABLE") == 0 &&
    pg_strcasecmp((previous_words[1]), "DROP") == 0 &&
    pg_strcasecmp((previous_words[0]), "COLUMN") == 0)
  do { char *_completion_schema; char *_completion_table; _completion_schema = strtokx((previous_words[2]), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); (void) strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); _completion_table = strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); if (_completion_table == ((void *)0)) { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c "" WHERE c.oid = a.attrelid ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"'='%s') ""   AND pg_catalog.pg_table_is_visible(c.oid)" ""; completion_info_charp = (previous_words[2]); } else { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c, pg_catalog.pg_namespace n "" WHERE c.oid = a.attrelid ""   AND n.oid = c.relnamespace ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"' ='%s') ""   AND (pg_catalog.quote_ident(nspname)='%s' ""        OR '\"' || nspname || '\"' ='%s') " ""; completion_info_charp = _completion_table; completion_info_charp2 = _completion_schema; } matches = rl_completion_matches(text, complete_from_query); } while (0);

 else if ((pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
     pg_strcasecmp((previous_words[1]), "COLUMN") == 0) ||
    (pg_strcasecmp((previous_words[3]), "TABLE") == 0 &&
     pg_strcasecmp((previous_words[1]), "ALTER") == 0))
 {
  static const char *const list_COLUMNALTER[] =
  {"TYPE", "SET", "RESET", "DROP", ((void *)0)};

  do { completion_charpp = list_COLUMNALTER; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (((pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
      pg_strcasecmp((previous_words[2]), "COLUMN") == 0) ||
     (pg_strcasecmp((previous_words[4]), "TABLE") == 0 &&
      pg_strcasecmp((previous_words[2]), "ALTER") == 0)) &&
    pg_strcasecmp((previous_words[0]), "SET") == 0)
 {
  static const char *const list_COLUMNSET[] =
  {"(", "DEFAULT", "NOT NULL", "STATISTICS", "STORAGE", ((void *)0)};

  do { completion_charpp = list_COLUMNSET; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (((pg_strcasecmp((previous_words[4]), "ALTER") == 0 &&
      pg_strcasecmp((previous_words[3]), "COLUMN") == 0) ||
     pg_strcasecmp((previous_words[3]), "ALTER") == 0) &&
    pg_strcasecmp((previous_words[1]), "SET") == 0 &&
    pg_strcasecmp((previous_words[0]), "(") == 0)
 {
  static const char *const list_COLUMNOPTIONS[] =
  {"n_distinct", "n_distinct_inherited", ((void *)0)};

  do { completion_charpp = list_COLUMNOPTIONS; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (((pg_strcasecmp((previous_words[4]), "ALTER") == 0 &&
      pg_strcasecmp((previous_words[3]), "COLUMN") == 0) ||
     pg_strcasecmp((previous_words[3]), "ALTER") == 0) &&
    pg_strcasecmp((previous_words[1]), "SET") == 0 &&
    pg_strcasecmp((previous_words[0]), "STORAGE") == 0)
 {
  static const char *const list_COLUMNSTORAGE[] =
  {"PLAIN", "EXTERNAL", "EXTENDED", "MAIN", ((void *)0)};

  do { completion_charpp = list_COLUMNSTORAGE; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (((pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
      pg_strcasecmp((previous_words[2]), "COLUMN") == 0) ||
     (pg_strcasecmp((previous_words[4]), "TABLE") == 0 &&
      pg_strcasecmp((previous_words[2]), "ALTER") == 0)) &&
    pg_strcasecmp((previous_words[0]), "DROP") == 0)
 {
  static const char *const list_COLUMNDROP[] =
  {"DEFAULT", "NOT NULL", ((void *)0)};

  do { completion_charpp = list_COLUMNDROP; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
 else if (pg_strcasecmp((previous_words[2]), "TABLE") == 0 &&
    pg_strcasecmp((previous_words[0]), "CLUSTER") == 0)
  do { completion_charp = "ON"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 else if (pg_strcasecmp((previous_words[3]), "TABLE") == 0 &&
    pg_strcasecmp((previous_words[1]), "CLUSTER") == 0 &&
    pg_strcasecmp((previous_words[0]), "ON") == 0)
 {
  completion_info_charp = (previous_words[2]);
  do { completion_charp = "SELECT pg_catalog.quote_ident(c2.relname) ""  FROM pg_catalog.pg_class c1, pg_catalog.pg_class c2, pg_catalog.pg_index i"" WHERE c1.oid=i.indrelid and i.indexrelid=c2.oid""       and (%d = pg_catalog.length('%s'))""       and pg_catalog.quote_ident(c1.relname)='%s'""       and pg_catalog.pg_table_is_visible(c2.oid)"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 }

 else if (pg_strcasecmp((previous_words[2]), "TABLE") == 0 &&
    pg_strcasecmp((previous_words[0]), "SET") == 0)
 {
  static const char *const list_TABLESET[] =
  {"(", "WITHOUT", "TABLESPACE", "SCHEMA", ((void *)0)};

  do { completion_charpp = list_TABLESET; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[3]), "TABLE") == 0 &&
    pg_strcasecmp((previous_words[1]), "SET") == 0 &&
    pg_strcasecmp((previous_words[0]), "TABLESPACE") == 0)
  do { completion_charp = "SELECT pg_catalog.quote_ident(spcname) FROM pg_catalog.pg_tablespace "" WHERE substring(pg_catalog.quote_ident(spcname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);

 else if (pg_strcasecmp((previous_words[3]), "TABLE") == 0 &&
    pg_strcasecmp((previous_words[1]), "SET") == 0 &&
    pg_strcasecmp((previous_words[0]), "WITHOUT") == 0)
 {
  static const char *const list_TABLESET2[] =
  {"CLUSTER", "OIDS", ((void *)0)};

  do { completion_charpp = list_TABLESET2; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[2]), "TABLE") == 0 &&
    pg_strcasecmp((previous_words[0]), "RESET") == 0)
  do { completion_charp = "("; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);

 else if (pg_strcasecmp((previous_words[3]), "TABLE") == 0 &&
    (pg_strcasecmp((previous_words[1]), "SET") == 0 ||
     pg_strcasecmp((previous_words[1]), "RESET") == 0) &&
    pg_strcasecmp((previous_words[0]), "(") == 0)
 {
  static const char *const list_TABLEOPTIONS[] =
  {
   "autovacuum_analyze_scale_factor",
   "autovacuum_analyze_threshold",
   "autovacuum_enabled",
   "autovacuum_freeze_max_age",
   "autovacuum_freeze_min_age",
   "autovacuum_freeze_table_age",
   "autovacuum_vacuum_cost_delay",
   "autovacuum_vacuum_cost_limit",
   "autovacuum_vacuum_scale_factor",
   "autovacuum_vacuum_threshold",
   "fillfactor",
   "toast.autovacuum_enabled",
   "toast.autovacuum_freeze_max_age",
   "toast.autovacuum_freeze_min_age",
   "toast.autovacuum_freeze_table_age",
   "toast.autovacuum_vacuum_cost_delay",
   "toast.autovacuum_vacuum_cost_limit",
   "toast.autovacuum_vacuum_scale_factor",
   "toast.autovacuum_vacuum_threshold",
   ((void *)0)
  };

  do { completion_charpp = list_TABLEOPTIONS; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[1]), "TABLESPACE") == 0)
 {
  static const char *const list_ALTERTSPC[] =
  {"RENAME TO", "OWNER TO", "SET", "RESET", ((void *)0)};

  do { completion_charpp = list_ALTERTSPC; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "TABLESPACE") == 0 &&
    (pg_strcasecmp((previous_words[0]), "SET") == 0 ||
     pg_strcasecmp((previous_words[0]), "RESET") == 0))
  do { completion_charp = "("; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);

 else if (pg_strcasecmp((previous_words[4]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[3]), "TABLESPACE") == 0 &&
    (pg_strcasecmp((previous_words[1]), "SET") == 0 ||
     pg_strcasecmp((previous_words[1]), "RESET") == 0) &&
    pg_strcasecmp((previous_words[0]), "(") == 0)
 {
  static const char *const list_TABLESPACEOPTIONS[] =
  {"seq_page_cost", "random_page_cost", ((void *)0)};

  do { completion_charpp = list_TABLESPACEOPTIONS; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[1]), "TEXT") == 0 &&
    pg_strcasecmp((previous_words[0]), "SEARCH") == 0)
 {
  static const char *const list_ALTERTEXTSEARCH[] =
  {"CONFIGURATION", "DICTIONARY", "PARSER", "TEMPLATE", ((void *)0)};

  do { completion_charpp = list_ALTERTEXTSEARCH; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
 else if (pg_strcasecmp((previous_words[4]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[3]), "TEXT") == 0 &&
    pg_strcasecmp((previous_words[2]), "SEARCH") == 0 &&
    (pg_strcasecmp((previous_words[1]), "TEMPLATE") == 0 ||
     pg_strcasecmp((previous_words[1]), "PARSER") == 0))
 {
  static const char *const list_ALTERTEXTSEARCH2[] =
  {"RENAME TO", "SET SCHEMA", ((void *)0)};

  do { completion_charpp = list_ALTERTEXTSEARCH2; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[4]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[3]), "TEXT") == 0 &&
    pg_strcasecmp((previous_words[2]), "SEARCH") == 0 &&
    pg_strcasecmp((previous_words[1]), "DICTIONARY") == 0)
 {
  static const char *const list_ALTERTEXTSEARCH3[] =
  {"OWNER TO", "RENAME TO", "SET SCHEMA", ((void *)0)};

  do { completion_charpp = list_ALTERTEXTSEARCH3; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[4]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[3]), "TEXT") == 0 &&
    pg_strcasecmp((previous_words[2]), "SEARCH") == 0 &&
    pg_strcasecmp((previous_words[1]), "CONFIGURATION") == 0)
 {
  static const char *const list_ALTERTEXTSEARCH4[] =
  {"ADD MAPPING FOR", "ALTER MAPPING", "DROP MAPPING FOR", "OWNER TO", "RENAME TO", "SET SCHEMA", ((void *)0)};

  do { completion_charpp = list_ALTERTEXTSEARCH4; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[1]), "TYPE") == 0)
 {
  static const char *const list_ALTERTYPE[] =
  {"ADD ATTRIBUTE", "ADD VALUE", "ALTER ATTRIBUTE", "DROP ATTRIBUTE",
  "OWNER TO", "RENAME", "SET SCHEMA", ((void *)0)};

  do { completion_charpp = list_ALTERTYPE; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "TYPE") == 0 &&
    pg_strcasecmp((previous_words[0]), "ADD") == 0)
 {
  static const char *const list_ALTERTYPE[] =
  {"ATTRIBUTE", "VALUE", ((void *)0)};

  do { completion_charpp = list_ALTERTYPE; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "TYPE") == 0 &&
    pg_strcasecmp((previous_words[0]), "RENAME") == 0)
 {
  static const char *const list_ALTERTYPE[] =
  {"ATTRIBUTE", "TO", ((void *)0)};

  do { completion_charpp = list_ALTERTYPE; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[4]), "TYPE") == 0 &&
    pg_strcasecmp((previous_words[2]), "RENAME") == 0 &&
    pg_strcasecmp((previous_words[1]), "ATTRIBUTE") == 0)
  do { completion_charp = "TO"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);





 else if (pg_strcasecmp((previous_words[3]), "TYPE") == 0 &&
    (pg_strcasecmp((previous_words[1]), "ALTER") == 0 ||
     pg_strcasecmp((previous_words[1]), "DROP") == 0 ||
     pg_strcasecmp((previous_words[1]), "RENAME") == 0) &&
    pg_strcasecmp((previous_words[0]), "ATTRIBUTE") == 0)
  do { char *_completion_schema; char *_completion_table; _completion_schema = strtokx((previous_words[2]), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); (void) strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); _completion_table = strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); if (_completion_table == ((void *)0)) { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c "" WHERE c.oid = a.attrelid ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"'='%s') ""   AND pg_catalog.pg_table_is_visible(c.oid)" ""; completion_info_charp = (previous_words[2]); } else { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c, pg_catalog.pg_namespace n "" WHERE c.oid = a.attrelid ""   AND n.oid = c.relnamespace ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"' ='%s') ""   AND (pg_catalog.quote_ident(nspname)='%s' ""        OR '\"' || nspname || '\"' ='%s') " ""; completion_info_charp = _completion_table; completion_info_charp2 = _completion_schema; } matches = rl_completion_matches(text, complete_from_query); } while (0);

 else if ((pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
     pg_strcasecmp((previous_words[1]), "ATTRIBUTE") == 0))
 {
  do { completion_charp = "TYPE"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 }

 else if (pg_strcasecmp((previous_words[2]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[1]), "GROUP") == 0)
 {
  static const char *const list_ALTERGROUP[] =
  {"ADD USER", "DROP USER", "RENAME TO", ((void *)0)};

  do { completion_charpp = list_ALTERGROUP; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[3]), "ALTER") == 0 &&
    pg_strcasecmp((previous_words[2]), "GROUP") == 0 &&
    (pg_strcasecmp((previous_words[0]), "ADD") == 0 ||
     pg_strcasecmp((previous_words[0]), "DROP") == 0))
  do { completion_charp = "USER"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);

 else if (pg_strcasecmp((previous_words[3]), "GROUP") == 0 &&
    (pg_strcasecmp((previous_words[1]), "ADD") == 0 ||
     pg_strcasecmp((previous_words[1]), "DROP") == 0) &&
    pg_strcasecmp((previous_words[0]), "USER") == 0)
  do { completion_charp = " SELECT pg_catalog.quote_ident(rolname) ""   FROM pg_catalog.pg_roles ""  WHERE substring(pg_catalog.quote_ident(rolname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);


 else if (pg_strcasecmp((previous_words[0]), "BEGIN") == 0 ||
    pg_strcasecmp((previous_words[0]), "END") == 0 ||
    pg_strcasecmp((previous_words[0]), "ABORT") == 0)
 {
  static const char *const list_TRANS[] =
  {"WORK", "TRANSACTION", ((void *)0)};

  do { completion_charpp = list_TRANS; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[0]), "COMMIT") == 0)
 {
  static const char *const list_COMMIT[] =
  {"WORK", "TRANSACTION", "PREPARED", ((void *)0)};

  do { completion_charpp = list_COMMIT; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[0]), "RELEASE") == 0)
  do { completion_charp = "SAVEPOINT"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);

 else if (pg_strcasecmp((previous_words[0]), "ROLLBACK") == 0)
 {
  static const char *const list_TRANS[] =
  {"WORK", "TRANSACTION", "TO SAVEPOINT", "PREPARED", ((void *)0)};

  do { completion_charpp = list_TRANS; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }





 else if (pg_strcasecmp((previous_words[0]), "CLUSTER") == 0 &&
    pg_strcasecmp((previous_words[1]), "WITHOUT") != 0)
  do { completion_squery = &(Query_for_list_of_tables); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);

 else if (pg_strcasecmp((previous_words[1]), "CLUSTER") == 0 &&
    pg_strcasecmp((previous_words[0]), "ON") != 0)
 {
  do { completion_charp = "USING"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 }




 else if (pg_strcasecmp((previous_words[2]), "CLUSTER") == 0 &&
    pg_strcasecmp((previous_words[0]), "USING") == 0)
 {
  completion_info_charp = (previous_words[1]);
  do { completion_charp = "SELECT pg_catalog.quote_ident(c2.relname) ""  FROM pg_catalog.pg_class c1, pg_catalog.pg_class c2, pg_catalog.pg_index i"" WHERE c1.oid=i.indrelid and i.indexrelid=c2.oid""       and (%d = pg_catalog.length('%s'))""       and pg_catalog.quote_ident(c1.relname)='%s'""       and pg_catalog.pg_table_is_visible(c2.oid)"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 }


 else if (pg_strcasecmp((previous_words[0]), "COMMENT") == 0)
  do { completion_charp = "ON"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 else if (pg_strcasecmp((previous_words[1]), "COMMENT") == 0 &&
    pg_strcasecmp((previous_words[0]), "ON") == 0)
 {
  static const char *const list_COMMENT[] =
  {"CAST", "COLLATION", "CONVERSION", "DATABASE", "EXTENSION",
   "FOREIGN DATA WRAPPER", "FOREIGN TABLE",
   "SERVER", "INDEX", "LANGUAGE", "RULE", "SCHEMA", "SEQUENCE",
   "TABLE", "TYPE", "VIEW", "COLUMN", "AGGREGATE", "FUNCTION",
   "OPERATOR", "TRIGGER", "CONSTRAINT", "DOMAIN", "LARGE OBJECT",
  "TABLESPACE", "TEXT SEARCH", "ROLE", ((void *)0)};

  do { completion_charpp = list_COMMENT; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
 else if (pg_strcasecmp((previous_words[2]), "COMMENT") == 0 &&
    pg_strcasecmp((previous_words[1]), "ON") == 0 &&
    pg_strcasecmp((previous_words[0]), "FOREIGN") == 0)
 {
  static const char *const list_TRANS2[] =
  {"DATA WRAPPER", "TABLE", ((void *)0)};

  do { completion_charpp = list_TRANS2; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
 else if (pg_strcasecmp((previous_words[3]), "COMMENT") == 0 &&
    pg_strcasecmp((previous_words[2]), "ON") == 0 &&
    pg_strcasecmp((previous_words[1]), "TEXT") == 0 &&
    pg_strcasecmp((previous_words[0]), "SEARCH") == 0)
 {
  static const char *const list_TRANS2[] =
  {"CONFIGURATION", "DICTIONARY", "PARSER", "TEMPLATE", ((void *)0)};

  do { completion_charpp = list_TRANS2; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
 else if ((pg_strcasecmp((previous_words[3]), "COMMENT") == 0 &&
     pg_strcasecmp((previous_words[2]), "ON") == 0) ||
    (pg_strcasecmp((previous_words[4]), "COMMENT") == 0 &&
     pg_strcasecmp((previous_words[3]), "ON") == 0) ||
    (pg_strcasecmp((previous_words[5]), "COMMENT") == 0 &&
     pg_strcasecmp((previous_words[4]), "ON") == 0))
  do { completion_charp = "IS"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);







 else if (pg_strcasecmp((previous_words[0]), "COPY") == 0 ||
    pg_strcasecmp((previous_words[0]), "\\copy") == 0 ||
    (pg_strcasecmp((previous_words[1]), "COPY") == 0 &&
     pg_strcasecmp((previous_words[0]), "BINARY") == 0))
  do { completion_squery = &(Query_for_list_of_tables); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);

 else if (pg_strcasecmp((previous_words[1]), "COPY") == 0 ||
    pg_strcasecmp((previous_words[1]), "\\copy") == 0 ||
    pg_strcasecmp((previous_words[1]), "BINARY") == 0)
 {
  static const char *const list_FROMTO[] =
  {"FROM", "TO", ((void *)0)};

  do { completion_charpp = list_FROMTO; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if ((pg_strcasecmp((previous_words[2]), "COPY") == 0 ||
     pg_strcasecmp((previous_words[2]), "\\copy") == 0 ||
     pg_strcasecmp((previous_words[2]), "BINARY") == 0) &&
    (pg_strcasecmp((previous_words[0]), "FROM") == 0 ||
     pg_strcasecmp((previous_words[0]), "TO") == 0))
 {
  completion_charp = "";
  matches = rl_completion_matches(text, complete_from_files);
 }


 else if ((pg_strcasecmp((previous_words[3]), "COPY") == 0 ||
     pg_strcasecmp((previous_words[3]), "\\copy") == 0 ||
     pg_strcasecmp((previous_words[3]), "BINARY") == 0) &&
    (pg_strcasecmp((previous_words[1]), "FROM") == 0 ||
     pg_strcasecmp((previous_words[1]), "TO") == 0))
 {
  static const char *const list_COPY[] =
  {"BINARY", "OIDS", "DELIMITER", "NULL", "CSV", "ENCODING", ((void *)0)};

  do { completion_charpp = list_COPY; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[0]), "CSV") == 0 &&
    (pg_strcasecmp((previous_words[2]), "FROM") == 0 ||
     pg_strcasecmp((previous_words[2]), "TO") == 0))
 {
  static const char *const list_CSV[] =
  {"HEADER", "QUOTE", "ESCAPE", "FORCE QUOTE", "FORCE NOT NULL", ((void *)0)};

  do { completion_charpp = list_CSV; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[2]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[1]), "DATABASE") == 0)
 {
  static const char *const list_DATABASE[] =
  {"OWNER", "TEMPLATE", "ENCODING", "TABLESPACE", "CONNECTION LIMIT",
  ((void *)0)};

  do { completion_charpp = list_DATABASE; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[3]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[2]), "DATABASE") == 0 &&
    pg_strcasecmp((previous_words[0]), "TEMPLATE") == 0)
  do { completion_charp = "SELECT pg_catalog.quote_ident(datname) FROM pg_catalog.pg_database "" WHERE substring(pg_catalog.quote_ident(datname),1,%d)='%s' AND datistemplate"; matches = rl_completion_matches(text, complete_from_query); } while (0);



 else if (pg_strcasecmp((previous_words[1]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[0]), "EXTENSION") == 0)
  do { completion_charp = " SELECT pg_catalog.quote_ident(name) ""   FROM pg_catalog.pg_available_extensions ""  WHERE substring(pg_catalog.quote_ident(name),1,%d)='%s' AND installed_version IS NULL"; matches = rl_completion_matches(text, complete_from_query); } while (0);

 else if (pg_strcasecmp((previous_words[2]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[1]), "EXTENSION") == 0)
  do { completion_charp = "WITH SCHEMA"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);


 else if (pg_strcasecmp((previous_words[1]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[0]), "FOREIGN") == 0)
 {
  static const char *const list_CREATE_FOREIGN[] =
  {"DATA WRAPPER", "TABLE", ((void *)0)};

  do { completion_charpp = list_CREATE_FOREIGN; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[4]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[3]), "FOREIGN") == 0 &&
    pg_strcasecmp((previous_words[2]), "DATA") == 0 &&
    pg_strcasecmp((previous_words[1]), "WRAPPER") == 0)
 {
  static const char *const list_CREATE_FOREIGN_DATA_WRAPPER[] =
  {"HANDLER", "VALIDATOR", ((void *)0)};

  do { completion_charpp = list_CREATE_FOREIGN_DATA_WRAPPER; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }



 else if (pg_strcasecmp((previous_words[1]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[0]), "UNIQUE") == 0)
  do { completion_charp = "INDEX"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);

 else if (pg_strcasecmp((previous_words[0]), "INDEX") == 0 &&
    (pg_strcasecmp((previous_words[1]), "CREATE") == 0 ||
     pg_strcasecmp((previous_words[1]), "UNIQUE") == 0))
  do { completion_squery = &(Query_for_list_of_indexes); completion_charp = " UNION SELECT 'ON'" " UNION SELECT 'CONCURRENTLY'"; matches = rl_completion_matches(text, complete_from_schema_query); } while (0);



 else if ((pg_strcasecmp((previous_words[2]), "INDEX") == 0 ||
     pg_strcasecmp((previous_words[1]), "INDEX") == 0 ||
     pg_strcasecmp((previous_words[1]), "CONCURRENTLY") == 0) &&
    pg_strcasecmp((previous_words[0]), "ON") == 0)
  do { completion_squery = &(Query_for_list_of_tables); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);

 else if ((pg_strcasecmp((previous_words[2]), "INDEX") == 0 ||
     pg_strcasecmp((previous_words[1]), "INDEX") == 0) &&
    pg_strcasecmp((previous_words[0]), "CONCURRENTLY") == 0)
  do { completion_charp = "ON"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);

 else if ((pg_strcasecmp((previous_words[2]), "CREATE") == 0 ||
     pg_strcasecmp((previous_words[2]), "UNIQUE") == 0) &&
    pg_strcasecmp((previous_words[1]), "INDEX") == 0)
 {
  static const char *const list_CREATE_INDEX[] =
  {"CONCURRENTLY", "ON", ((void *)0)};

  do { completion_charpp = list_CREATE_INDEX; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }





 else if ((pg_strcasecmp((previous_words[3]), "INDEX") == 0 ||
     pg_strcasecmp((previous_words[2]), "INDEX") == 0 ||
     pg_strcasecmp((previous_words[2]), "CONCURRENTLY") == 0) &&
    pg_strcasecmp((previous_words[1]), "ON") == 0)
 {
  static const char *const list_CREATE_INDEX2[] =
  {"(", "USING", ((void *)0)};

  do { completion_charpp = list_CREATE_INDEX2; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
 else if ((pg_strcasecmp((previous_words[4]), "INDEX") == 0 ||
     pg_strcasecmp((previous_words[3]), "INDEX") == 0 ||
     pg_strcasecmp((previous_words[3]), "CONCURRENTLY") == 0) &&
    pg_strcasecmp((previous_words[2]), "ON") == 0 &&
    pg_strcasecmp((previous_words[0]), "(") == 0)
  do { char *_completion_schema; char *_completion_table; _completion_schema = strtokx((previous_words[1]), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); (void) strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); _completion_table = strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); if (_completion_table == ((void *)0)) { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c "" WHERE c.oid = a.attrelid ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"'='%s') ""   AND pg_catalog.pg_table_is_visible(c.oid)" ""; completion_info_charp = (previous_words[1]); } else { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c, pg_catalog.pg_namespace n "" WHERE c.oid = a.attrelid ""   AND n.oid = c.relnamespace ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"' ='%s') ""   AND (pg_catalog.quote_ident(nspname)='%s' ""        OR '\"' || nspname || '\"' ='%s') " ""; completion_info_charp = _completion_table; completion_info_charp2 = _completion_schema; } matches = rl_completion_matches(text, complete_from_query); } while (0);

 else if (pg_strcasecmp((previous_words[4]), "ON") == 0 &&
    pg_strcasecmp((previous_words[2]), "USING") == 0 &&
    pg_strcasecmp((previous_words[0]), "(") == 0)
  do { char *_completion_schema; char *_completion_table; _completion_schema = strtokx((previous_words[3]), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); (void) strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); _completion_table = strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); if (_completion_table == ((void *)0)) { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c "" WHERE c.oid = a.attrelid ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"'='%s') ""   AND pg_catalog.pg_table_is_visible(c.oid)" ""; completion_info_charp = (previous_words[3]); } else { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c, pg_catalog.pg_namespace n "" WHERE c.oid = a.attrelid ""   AND n.oid = c.relnamespace ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"' ='%s') ""   AND (pg_catalog.quote_ident(nspname)='%s' ""        OR '\"' || nspname || '\"' ='%s') " ""; completion_info_charp = _completion_table; completion_info_charp2 = _completion_schema; } matches = rl_completion_matches(text, complete_from_query); } while (0);

 else if (pg_strcasecmp((previous_words[0]), "USING") == 0)
  do { completion_charp = " SELECT pg_catalog.quote_ident(amname) ""   FROM pg_catalog.pg_am ""  WHERE substring(pg_catalog.quote_ident(amname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 else if (pg_strcasecmp((previous_words[3]), "ON") == 0 &&
    pg_strcasecmp((previous_words[1]), "USING") == 0)
  do { completion_charp = "("; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);



 else if (pg_strcasecmp((previous_words[2]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[1]), "RULE") == 0)
  do { completion_charp = "AS"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);

 else if (pg_strcasecmp((previous_words[3]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[2]), "RULE") == 0 &&
    pg_strcasecmp((previous_words[0]), "AS") == 0)
  do { completion_charp = "ON"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);

 else if (pg_strcasecmp((previous_words[3]), "RULE") == 0 &&
    pg_strcasecmp((previous_words[1]), "AS") == 0 &&
    pg_strcasecmp((previous_words[0]), "ON") == 0)
 {
  static const char *const rule_events[] =
  {"SELECT", "UPDATE", "INSERT", "DELETE", ((void *)0)};

  do { completion_charpp = rule_events; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[2]), "AS") == 0 &&
    pg_strcasecmp((previous_words[1]), "ON") == 0 &&
    (pg_toupper((unsigned char) (previous_words[0])[4]) == 'T' ||
     pg_toupper((unsigned char) (previous_words[0])[5]) == 'T'))
  do { completion_charp = "TO"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);

 else if (pg_strcasecmp((previous_words[3]), "AS") == 0 &&
    pg_strcasecmp((previous_words[2]), "ON") == 0 &&
    pg_strcasecmp((previous_words[0]), "TO") == 0)
  do { completion_squery = &(Query_for_list_of_tables); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);


 else if (pg_strcasecmp((previous_words[2]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[1]), "SERVER") == 0)
 {
  static const char *const list_CREATE_SERVER[] =
  {"TYPE", "VERSION", "FOREIGN DATA WRAPPER", ((void *)0)};

  do { completion_charpp = list_CREATE_SERVER; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }



 else if (pg_strcasecmp((previous_words[1]), "CREATE") == 0 &&
    (pg_strcasecmp((previous_words[0]), "TEMP") == 0 ||
     pg_strcasecmp((previous_words[0]), "TEMPORARY") == 0))
 {
  static const char *const list_TEMP[] =
  {"SEQUENCE", "TABLE", "VIEW", ((void *)0)};

  do { completion_charpp = list_TEMP; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[1]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[0]), "UNLOGGED") == 0)
 {
  do { completion_charp = "TABLE"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 }


 else if (pg_strcasecmp((previous_words[2]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[1]), "TABLESPACE") == 0)
 {
  static const char *const list_CREATETABLESPACE[] =
  {"OWNER", "LOCATION", ((void *)0)};

  do { completion_charpp = list_CREATETABLESPACE; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[4]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[3]), "TABLESPACE") == 0 &&
    pg_strcasecmp((previous_words[1]), "OWNER") == 0)
 {
  do { completion_charp = "LOCATION"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 }


 else if (pg_strcasecmp((previous_words[2]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[1]), "TEXT") == 0 &&
    pg_strcasecmp((previous_words[0]), "SEARCH") == 0)
 {
  static const char *const list_CREATETEXTSEARCH[] =
  {"CONFIGURATION", "DICTIONARY", "PARSER", "TEMPLATE", ((void *)0)};

  do { completion_charpp = list_CREATETEXTSEARCH; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
 else if (pg_strcasecmp((previous_words[3]), "TEXT") == 0 &&
    pg_strcasecmp((previous_words[2]), "SEARCH") == 0 &&
    pg_strcasecmp((previous_words[1]), "CONFIGURATION") == 0)
  do { completion_charp = "("; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);



 else if (pg_strcasecmp((previous_words[2]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[1]), "TRIGGER") == 0)
 {
  static const char *const list_CREATETRIGGER[] =
  {"BEFORE", "AFTER", "INSTEAD OF", ((void *)0)};

  do { completion_charpp = list_CREATETRIGGER; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[3]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[2]), "TRIGGER") == 0 &&
    (pg_strcasecmp((previous_words[0]), "BEFORE") == 0 ||
     pg_strcasecmp((previous_words[0]), "AFTER") == 0))
 {
  static const char *const list_CREATETRIGGER_EVENTS[] =
  {"INSERT", "DELETE", "UPDATE", "TRUNCATE", ((void *)0)};

  do { completion_charpp = list_CREATETRIGGER_EVENTS; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[4]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[3]), "TRIGGER") == 0 &&
    pg_strcasecmp((previous_words[1]), "INSTEAD") == 0 &&
    pg_strcasecmp((previous_words[0]), "OF") == 0)
 {
  static const char *const list_CREATETRIGGER_EVENTS[] =
  {"INSERT", "DELETE", "UPDATE", ((void *)0)};

  do { completion_charpp = list_CREATETRIGGER_EVENTS; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if ((pg_strcasecmp((previous_words[4]), "CREATE") == 0 &&
     pg_strcasecmp((previous_words[3]), "TRIGGER") == 0 &&
     (pg_strcasecmp((previous_words[1]), "BEFORE") == 0 ||
      pg_strcasecmp((previous_words[1]), "AFTER") == 0)) ||
    (pg_strcasecmp((previous_words[4]), "TRIGGER") == 0 &&
     pg_strcasecmp((previous_words[2]), "INSTEAD") == 0 &&
     pg_strcasecmp((previous_words[1]), "OF") == 0))
 {
  static const char *const list_CREATETRIGGER2[] =
  {"ON", "OR", ((void *)0)};

  do { completion_charpp = list_CREATETRIGGER2; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }





 else if (pg_strcasecmp((previous_words[4]), "TRIGGER") == 0 &&
    (pg_strcasecmp((previous_words[2]), "BEFORE") == 0 ||
     pg_strcasecmp((previous_words[2]), "AFTER") == 0) &&
    pg_strcasecmp((previous_words[0]), "ON") == 0)
  do { completion_squery = &(Query_for_list_of_tables); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);

 else if (pg_strcasecmp((previous_words[3]), "INSTEAD") == 0 &&
    pg_strcasecmp((previous_words[2]), "OF") == 0 &&
    pg_strcasecmp((previous_words[0]), "ON") == 0)
  do { completion_squery = &(Query_for_list_of_views); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);

 else if (pg_strcasecmp((previous_words[0]), "EXECUTE") == 0 &&
    (previous_words[1])[0] != '\0')
  do { completion_charp = "PROCEDURE"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);


 else if (pg_strcasecmp((previous_words[2]), "CREATE") == 0 &&
    !(pg_strcasecmp((previous_words[1]), "USER") == 0 && pg_strcasecmp((previous_words[0]), "MAPPING") == 0) &&
    (pg_strcasecmp((previous_words[1]), "ROLE") == 0 ||
     pg_strcasecmp((previous_words[1]), "GROUP") == 0 || pg_strcasecmp((previous_words[1]), "USER") == 0))
 {
  static const char *const list_CREATEROLE[] =
  {"ADMIN", "CONNECTION LIMIT", "CREATEDB", "CREATEROLE", "CREATEUSER",
   "ENCRYPTED", "IN", "INHERIT", "LOGIN", "NOCREATEDB",
   "NOCREATEROLE", "NOCREATEUSER", "NOINHERIT", "NOLOGIN",
   "NOREPLICATION", "NOSUPERUSER", "REPLICATION", "ROLE",
  "SUPERUSER", "SYSID", "UNENCRYPTED", "VALID UNTIL", "WITH", ((void *)0)};

  do { completion_charpp = list_CREATEROLE; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if ((pg_strcasecmp((previous_words[3]), "CREATE") == 0 &&
     (pg_strcasecmp((previous_words[2]), "ROLE") == 0 ||
      pg_strcasecmp((previous_words[2]), "GROUP") == 0 ||
      pg_strcasecmp((previous_words[2]), "USER") == 0) &&
     pg_strcasecmp((previous_words[0]), "WITH") == 0))
 {

  static const char *const list_CREATEROLE_WITH[] =
  {"ADMIN", "CONNECTION LIMIT", "CREATEDB", "CREATEROLE", "CREATEUSER",
   "ENCRYPTED", "IN", "INHERIT", "LOGIN", "NOCREATEDB",
   "NOCREATEROLE", "NOCREATEUSER", "NOINHERIT", "NOLOGIN",
   "NOREPLICATION", "NOSUPERUSER", "REPLICATION", "ROLE",
  "SUPERUSER", "SYSID", "UNENCRYPTED", "VALID UNTIL", ((void *)0)};

  do { completion_charpp = list_CREATEROLE_WITH; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }





 else if (pg_strcasecmp((previous_words[3]), "CREATE") == 0 &&
    (pg_strcasecmp((previous_words[2]), "ROLE") == 0 ||
     pg_strcasecmp((previous_words[2]), "GROUP") == 0 || pg_strcasecmp((previous_words[2]), "USER") == 0) &&
    (pg_strcasecmp((previous_words[0]), "ENCRYPTED") == 0 || pg_strcasecmp((previous_words[0]), "UNENCRYPTED") == 0))
 {
  do { completion_charp = "PASSWORD"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 }

 else if (pg_strcasecmp((previous_words[3]), "CREATE") == 0 &&
    (pg_strcasecmp((previous_words[2]), "ROLE") == 0 ||
     pg_strcasecmp((previous_words[2]), "GROUP") == 0 || pg_strcasecmp((previous_words[2]), "USER") == 0) &&
    pg_strcasecmp((previous_words[0]), "IN") == 0)
 {
  static const char *const list_CREATEROLE3[] =
  {"GROUP", "ROLE", ((void *)0)};

  do { completion_charpp = list_CREATEROLE3; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }



 else if (pg_strcasecmp((previous_words[2]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[1]), "VIEW") == 0)
  do { completion_charp = "AS"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);

 else if (pg_strcasecmp((previous_words[3]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[2]), "VIEW") == 0 &&
    pg_strcasecmp((previous_words[0]), "AS") == 0)
  do { completion_charp = "SELECT"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);


 else if (pg_strcasecmp((previous_words[1]), "DECLARE") == 0)
 {
  static const char *const list_DECLARE[] =
  {"BINARY", "INSENSITIVE", "SCROLL", "NO SCROLL", "CURSOR", ((void *)0)};

  do { completion_charpp = list_DECLARE; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[0]), "CURSOR") == 0)
 {
  static const char *const list_DECLARECURSOR[] =
  {"WITH HOLD", "WITHOUT HOLD", "FOR", ((void *)0)};

  do { completion_charpp = list_DECLARECURSOR; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
# 2084 "tab-complete.c"
 else if (pg_strcasecmp((previous_words[0]), "DELETE") == 0 &&
    !(pg_strcasecmp((previous_words[1]), "ON") == 0 ||
      pg_strcasecmp((previous_words[1]), "GRANT") == 0 ||
      pg_strcasecmp((previous_words[1]), "BEFORE") == 0 ||
      pg_strcasecmp((previous_words[1]), "AFTER") == 0))
  do { completion_charp = "FROM"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);

 else if (pg_strcasecmp((previous_words[1]), "DELETE") == 0 &&
    pg_strcasecmp((previous_words[0]), "FROM") == 0)
  do { completion_squery = &(Query_for_list_of_deletables); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);

 else if (pg_strcasecmp((previous_words[2]), "DELETE") == 0 &&
    pg_strcasecmp((previous_words[1]), "FROM") == 0)
 {
  static const char *const list_DELETE[] =
  {"USING", "WHERE", "SET", ((void *)0)};

  do { completion_charpp = list_DELETE; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }



 else if (pg_strcasecmp((previous_words[0]), "DISCARD") == 0)
 {
  static const char *const list_DISCARD[] =
  {"ALL", "PLANS", "TEMP", ((void *)0)};

  do { completion_charpp = list_DISCARD; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }






 else if (pg_strcasecmp((previous_words[0]), "DO") == 0)
 {
  static const char *const list_DO[] =
  {"LANGUAGE", ((void *)0)};

  do { completion_charpp = list_DO; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }



 else if (pg_strcasecmp((previous_words[2]), "DROP") == 0 &&
    pg_strcasecmp((previous_words[1]), "AGGREGATE") == 0)
  do { completion_charp = "("; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);


 else if ((pg_strcasecmp((previous_words[2]), "DROP") == 0 &&
     (pg_strcasecmp((previous_words[1]), "COLLATION") == 0 ||
      pg_strcasecmp((previous_words[1]), "CONVERSION") == 0 ||
      pg_strcasecmp((previous_words[1]), "DOMAIN") == 0 ||
      pg_strcasecmp((previous_words[1]), "EXTENSION") == 0 ||
      pg_strcasecmp((previous_words[1]), "FUNCTION") == 0 ||
      pg_strcasecmp((previous_words[1]), "INDEX") == 0 ||
      pg_strcasecmp((previous_words[1]), "LANGUAGE") == 0 ||
      pg_strcasecmp((previous_words[1]), "SCHEMA") == 0 ||
      pg_strcasecmp((previous_words[1]), "SEQUENCE") == 0 ||
      pg_strcasecmp((previous_words[1]), "SERVER") == 0 ||
      pg_strcasecmp((previous_words[1]), "TABLE") == 0 ||
      pg_strcasecmp((previous_words[1]), "TYPE") == 0 ||
      pg_strcasecmp((previous_words[1]), "VIEW") == 0)) ||
    (pg_strcasecmp((previous_words[3]), "DROP") == 0 &&
     pg_strcasecmp((previous_words[2]), "AGGREGATE") == 0 &&
     (previous_words[0])[strlen((previous_words[0])) - 1] == ')') ||
    (pg_strcasecmp((previous_words[4]), "DROP") == 0 &&
     pg_strcasecmp((previous_words[3]), "FOREIGN") == 0 &&
     pg_strcasecmp((previous_words[2]), "DATA") == 0 &&
     pg_strcasecmp((previous_words[1]), "WRAPPER") == 0) ||
    (pg_strcasecmp((previous_words[4]), "DROP") == 0 &&
     pg_strcasecmp((previous_words[3]), "TEXT") == 0 &&
     pg_strcasecmp((previous_words[2]), "SEARCH") == 0 &&
     (pg_strcasecmp((previous_words[1]), "CONFIGURATION") == 0 ||
      pg_strcasecmp((previous_words[1]), "DICTIONARY") == 0 ||
      pg_strcasecmp((previous_words[1]), "PARSER") == 0 ||
      pg_strcasecmp((previous_words[1]), "TEMPLATE") == 0))
  )
 {
  if (pg_strcasecmp((previous_words[2]), "DROP") == 0 &&
   pg_strcasecmp((previous_words[1]), "FUNCTION") == 0)
  {
   do { completion_charp = "("; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
  }
  else
  {
   static const char *const list_DROPCR[] =
   {"CASCADE", "RESTRICT", ((void *)0)};

   do { completion_charpp = list_DROPCR; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
  }
 }
 else if (pg_strcasecmp((previous_words[1]), "DROP") == 0 &&
    pg_strcasecmp((previous_words[0]), "FOREIGN") == 0)
 {
  static const char *const drop_CREATE_FOREIGN[] =
  {"DATA WRAPPER", "TABLE", ((void *)0)};

  do { completion_charpp = drop_CREATE_FOREIGN; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
 else if (pg_strcasecmp((previous_words[3]), "DROP") == 0 &&
    (pg_strcasecmp((previous_words[2]), "AGGREGATE") == 0 ||
     pg_strcasecmp((previous_words[2]), "FUNCTION") == 0) &&
    pg_strcasecmp((previous_words[0]), "(") == 0)
 {
  char *tmp_buf = malloc(strlen(" SELECT pg_catalog.oidvectortypes(proargtypes)||')' ""   FROM pg_catalog.pg_proc ""  WHERE proname='%s'") + strlen((previous_words[1])));

  __builtin___sprintf_chk (tmp_buf, 0, __builtin_object_size (tmp_buf, 2 > 1), " SELECT pg_catalog.oidvectortypes(proargtypes)||')' ""   FROM pg_catalog.pg_proc ""  WHERE proname='%s'", (previous_words[1]));
  do { completion_charp = tmp_buf; matches = rl_completion_matches(text, complete_from_query); } while (0);
  free(tmp_buf);
 }

 else if (pg_strcasecmp((previous_words[1]), "DROP") == 0 &&
    pg_strcasecmp((previous_words[0]), "OWNED") == 0)
  do { completion_charp = "BY"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 else if (pg_strcasecmp((previous_words[2]), "DROP") == 0 &&
    pg_strcasecmp((previous_words[1]), "OWNED") == 0 &&
    pg_strcasecmp((previous_words[0]), "BY") == 0)
  do { completion_charp = " SELECT pg_catalog.quote_ident(rolname) ""   FROM pg_catalog.pg_roles ""  WHERE substring(pg_catalog.quote_ident(rolname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 else if (pg_strcasecmp((previous_words[2]), "DROP") == 0 &&
    pg_strcasecmp((previous_words[1]), "TEXT") == 0 &&
    pg_strcasecmp((previous_words[0]), "SEARCH") == 0)
 {

  static const char *const list_ALTERTEXTSEARCH[] =
  {"CONFIGURATION", "DICTIONARY", "PARSER", "TEMPLATE", ((void *)0)};

  do { completion_charpp = list_ALTERTEXTSEARCH; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[0]), "EXECUTE") == 0 &&
    (previous_words[1])[0] == '\0')
  do { completion_charp = " SELECT pg_catalog.quote_ident(name) ""   FROM pg_catalog.pg_prepared_statements ""  WHERE substring(pg_catalog.quote_ident(name),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);






 else if (pg_strcasecmp((previous_words[0]), "EXPLAIN") == 0)
 {
  static const char *const list_EXPLAIN[] =
  {"SELECT", "INSERT", "DELETE", "UPDATE", "DECLARE", "ANALYZE", "VERBOSE", ((void *)0)};

  do { completion_charpp = list_EXPLAIN; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
 else if (pg_strcasecmp((previous_words[1]), "EXPLAIN") == 0 &&
    pg_strcasecmp((previous_words[0]), "ANALYZE") == 0)
 {
  static const char *const list_EXPLAIN[] =
  {"SELECT", "INSERT", "DELETE", "UPDATE", "DECLARE", "VERBOSE", ((void *)0)};

  do { completion_charpp = list_EXPLAIN; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
 else if ((pg_strcasecmp((previous_words[1]), "EXPLAIN") == 0 &&
     pg_strcasecmp((previous_words[0]), "VERBOSE") == 0) ||
    (pg_strcasecmp((previous_words[2]), "EXPLAIN") == 0 &&
     pg_strcasecmp((previous_words[1]), "ANALYZE") == 0 &&
     pg_strcasecmp((previous_words[0]), "VERBOSE") == 0))
 {
  static const char *const list_EXPLAIN[] =
  {"SELECT", "INSERT", "DELETE", "UPDATE", "DECLARE", ((void *)0)};

  do { completion_charpp = list_EXPLAIN; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }



 else if (pg_strcasecmp((previous_words[0]), "FETCH") == 0 ||
    pg_strcasecmp((previous_words[0]), "MOVE") == 0)
 {
  static const char *const list_FETCH1[] =
  {"ABSOLUTE", "BACKWARD", "FORWARD", "RELATIVE", ((void *)0)};

  do { completion_charpp = list_FETCH1; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[1]), "FETCH") == 0 ||
    pg_strcasecmp((previous_words[1]), "MOVE") == 0)
 {
  static const char *const list_FETCH2[] =
  {"ALL", "NEXT", "PRIOR", ((void *)0)};

  do { completion_charpp = list_FETCH2; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }






 else if (pg_strcasecmp((previous_words[2]), "FETCH") == 0 ||
    pg_strcasecmp((previous_words[2]), "MOVE") == 0)
 {
  static const char *const list_FROMIN[] =
  {"FROM", "IN", ((void *)0)};

  do { completion_charpp = list_FROMIN; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }



 else if (pg_strcasecmp((previous_words[3]), "CREATE") != 0 &&
    pg_strcasecmp((previous_words[2]), "FOREIGN") == 0 &&
    pg_strcasecmp((previous_words[1]), "DATA") == 0 &&
    pg_strcasecmp((previous_words[0]), "WRAPPER") == 0)
  do { completion_charp = " SELECT pg_catalog.quote_ident(fdwname) ""   FROM pg_catalog.pg_foreign_data_wrapper ""  WHERE substring(pg_catalog.quote_ident(fdwname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);


 else if (pg_strcasecmp((previous_words[2]), "CREATE") != 0 &&
    pg_strcasecmp((previous_words[1]), "FOREIGN") == 0 &&
    pg_strcasecmp((previous_words[0]), "TABLE") == 0)
  do { completion_squery = &(Query_for_list_of_foreign_tables); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);



 else if (pg_strcasecmp((previous_words[0]), "GRANT") == 0 ||
    pg_strcasecmp((previous_words[0]), "REVOKE") == 0)
 {
  do { completion_charp = " SELECT pg_catalog.quote_ident(rolname) ""   FROM pg_catalog.pg_roles ""  WHERE substring(pg_catalog.quote_ident(rolname),1,%d)='%s'" " UNION SELECT 'SELECT'" " UNION SELECT 'INSERT'" " UNION SELECT 'UPDATE'" " UNION SELECT 'DELETE'" " UNION SELECT 'TRUNCATE'" " UNION SELECT 'REFERENCES'" " UNION SELECT 'TRIGGER'" " UNION SELECT 'CREATE'" " UNION SELECT 'CONNECT'" " UNION SELECT 'TEMPORARY'" " UNION SELECT 'EXECUTE'" " UNION SELECT 'USAGE'" " UNION SELECT 'ALL'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
# 2319 "tab-complete.c"
 }





 else if (pg_strcasecmp((previous_words[1]), "GRANT") == 0 ||
    pg_strcasecmp((previous_words[1]), "REVOKE") == 0)
 {
  if (pg_strcasecmp((previous_words[0]), "SELECT") == 0
   || pg_strcasecmp((previous_words[0]), "INSERT") == 0
   || pg_strcasecmp((previous_words[0]), "UPDATE") == 0
   || pg_strcasecmp((previous_words[0]), "DELETE") == 0
   || pg_strcasecmp((previous_words[0]), "TRUNCATE") == 0
   || pg_strcasecmp((previous_words[0]), "REFERENCES") == 0
   || pg_strcasecmp((previous_words[0]), "TRIGGER") == 0
   || pg_strcasecmp((previous_words[0]), "CREATE") == 0
   || pg_strcasecmp((previous_words[0]), "CONNECT") == 0
   || pg_strcasecmp((previous_words[0]), "TEMPORARY") == 0
   || pg_strcasecmp((previous_words[0]), "TEMP") == 0
   || pg_strcasecmp((previous_words[0]), "EXECUTE") == 0
   || pg_strcasecmp((previous_words[0]), "USAGE") == 0
   || pg_strcasecmp((previous_words[0]), "ALL") == 0)
   do { completion_charp = "ON"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
  else
  {
   if (pg_strcasecmp((previous_words[1]), "GRANT") == 0)
    do { completion_charp = "TO"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
   else
    do { completion_charp = "FROM"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
  }
 }
# 2363 "tab-complete.c"
 else if ((pg_strcasecmp((previous_words[2]), "GRANT") == 0 ||
     pg_strcasecmp((previous_words[2]), "REVOKE") == 0) &&
    pg_strcasecmp((previous_words[0]), "ON") == 0)
  do { completion_squery = &(Query_for_list_of_tsvf); completion_charp = " UNION SELECT 'DATABASE'" " UNION SELECT 'DOMAIN'" " UNION SELECT 'FOREIGN DATA WRAPPER'" " UNION SELECT 'FOREIGN SERVER'" " UNION SELECT 'FUNCTION'" " UNION SELECT 'LANGUAGE'" " UNION SELECT 'LARGE OBJECT'" " UNION SELECT 'SCHEMA'" " UNION SELECT 'TABLESPACE'" " UNION SELECT 'TYPE'"; matches = rl_completion_matches(text, complete_from_schema_query); } while (0);
# 2377 "tab-complete.c"
 else if ((pg_strcasecmp((previous_words[3]), "GRANT") == 0 ||
     pg_strcasecmp((previous_words[3]), "REVOKE") == 0) &&
    pg_strcasecmp((previous_words[1]), "ON") == 0 &&
    pg_strcasecmp((previous_words[0]), "FOREIGN") == 0)
 {
  static const char *const list_privilege_foreign[] =
  {"DATA WRAPPER", "SERVER", ((void *)0)};

  do { completion_charpp = list_privilege_foreign; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if ((pg_strcasecmp((previous_words[3]), "GRANT") == 0 ||
     pg_strcasecmp((previous_words[3]), "REVOKE") == 0) &&
    pg_strcasecmp((previous_words[1]), "ON") == 0)
 {
  if (pg_strcasecmp((previous_words[0]), "DATABASE") == 0)
   do { completion_charp = "SELECT pg_catalog.quote_ident(datname) FROM pg_catalog.pg_database "" WHERE substring(pg_catalog.quote_ident(datname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
  else if (pg_strcasecmp((previous_words[0]), "DOMAIN") == 0)
   do { completion_squery = &(Query_for_list_of_domains); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);
  else if (pg_strcasecmp((previous_words[0]), "FUNCTION") == 0)
   do { completion_squery = &(Query_for_list_of_functions); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);
  else if (pg_strcasecmp((previous_words[0]), "LANGUAGE") == 0)
   do { completion_charp = "SELECT pg_catalog.quote_ident(lanname) ""  FROM pg_catalog.pg_language "" WHERE lanname != 'internal' ""   AND substring(pg_catalog.quote_ident(lanname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
  else if (pg_strcasecmp((previous_words[0]), "SCHEMA") == 0)
   do { completion_charp = "SELECT pg_catalog.quote_ident(nspname) FROM pg_catalog.pg_namespace "" WHERE substring(pg_catalog.quote_ident(nspname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
  else if (pg_strcasecmp((previous_words[0]), "TABLESPACE") == 0)
   do { completion_charp = "SELECT pg_catalog.quote_ident(spcname) FROM pg_catalog.pg_tablespace "" WHERE substring(pg_catalog.quote_ident(spcname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
  else if (pg_strcasecmp((previous_words[0]), "TYPE") == 0)
   do { completion_squery = &(Query_for_list_of_datatypes); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);
  else if (pg_strcasecmp((previous_words[3]), "GRANT") == 0)
   do { completion_charp = "TO"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
  else
   do { completion_charp = "FROM"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 }


 else if (pg_strcasecmp((previous_words[4]), "GRANT") == 0 &&
    pg_strcasecmp((previous_words[2]), "ON") == 0)
 {
  if (pg_strcasecmp((previous_words[0]), "TO") == 0)
   do { completion_charp = " SELECT pg_catalog.quote_ident(rolname) ""   FROM pg_catalog.pg_roles ""  WHERE substring(pg_catalog.quote_ident(rolname),1,%d)='%s'"" UNION ALL SELECT 'PUBLIC'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
  else
   do { completion_charp = "TO"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 }
 else if (pg_strcasecmp((previous_words[4]), "REVOKE") == 0 &&
    pg_strcasecmp((previous_words[2]), "ON") == 0)
 {
  if (pg_strcasecmp((previous_words[0]), "FROM") == 0)
   do { completion_charp = " SELECT pg_catalog.quote_ident(rolname) ""   FROM pg_catalog.pg_roles ""  WHERE substring(pg_catalog.quote_ident(rolname),1,%d)='%s'"" UNION ALL SELECT 'PUBLIC'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
  else
   do { completion_charp = "FROM"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 }


 else if (pg_strcasecmp((previous_words[2]), "GRANT") == 0 &&
    pg_strcasecmp((previous_words[0]), "TO") == 0)
 {
  do { completion_charp = " SELECT pg_catalog.quote_ident(rolname) ""   FROM pg_catalog.pg_roles ""  WHERE substring(pg_catalog.quote_ident(rolname),1,%d)='%s'"" UNION ALL SELECT 'PUBLIC'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 }
 else if (pg_strcasecmp((previous_words[2]), "REVOKE") == 0 &&
    pg_strcasecmp((previous_words[0]), "FROM") == 0)
 {
  do { completion_charp = " SELECT pg_catalog.quote_ident(rolname) ""   FROM pg_catalog.pg_roles ""  WHERE substring(pg_catalog.quote_ident(rolname),1,%d)='%s'"" UNION ALL SELECT 'PUBLIC'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 }


 else if (pg_strcasecmp((previous_words[2]), "FROM") == 0 &&
    pg_strcasecmp((previous_words[0]), "GROUP") == 0)
  do { completion_charp = "BY"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);



 else if (pg_strcasecmp((previous_words[0]), "INSERT") == 0)
  do { completion_charp = "INTO"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);

 else if (pg_strcasecmp((previous_words[1]), "INSERT") == 0 &&
    pg_strcasecmp((previous_words[0]), "INTO") == 0)
  do { completion_squery = &(Query_for_list_of_insertables); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);

 else if (pg_strcasecmp((previous_words[3]), "INSERT") == 0 &&
    pg_strcasecmp((previous_words[2]), "INTO") == 0 &&
    pg_strcasecmp((previous_words[0]), "(") == 0)
  do { char *_completion_schema; char *_completion_table; _completion_schema = strtokx((previous_words[1]), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); (void) strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); _completion_table = strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); if (_completion_table == ((void *)0)) { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c "" WHERE c.oid = a.attrelid ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"'='%s') ""   AND pg_catalog.pg_table_is_visible(c.oid)" ""; completion_info_charp = (previous_words[1]); } else { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c, pg_catalog.pg_namespace n "" WHERE c.oid = a.attrelid ""   AND n.oid = c.relnamespace ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"' ='%s') ""   AND (pg_catalog.quote_ident(nspname)='%s' ""        OR '\"' || nspname || '\"' ='%s') " ""; completion_info_charp = _completion_table; completion_info_charp2 = _completion_schema; } matches = rl_completion_matches(text, complete_from_query); } while (0);





 else if (pg_strcasecmp((previous_words[2]), "INSERT") == 0 &&
    pg_strcasecmp((previous_words[1]), "INTO") == 0)
 {
  static const char *const list_INSERT[] =
  {"(", "DEFAULT VALUES", "SELECT", "TABLE", "VALUES", ((void *)0)};

  do { completion_charpp = list_INSERT; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }





 else if (pg_strcasecmp((previous_words[3]), "INSERT") == 0 &&
    pg_strcasecmp((previous_words[2]), "INTO") == 0 &&
    (previous_words[0])[strlen((previous_words[0])) - 1] == ')')
 {
  static const char *const list_INSERT[] =
  {"SELECT", "TABLE", "VALUES", ((void *)0)};

  do { completion_charpp = list_INSERT; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[0]), "VALUES") == 0 &&
    pg_strcasecmp((previous_words[1]), "DEFAULT") != 0)
  do { completion_charp = "("; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);



 else if (pg_strcasecmp((previous_words[0]), "LOCK") == 0)
  do { completion_squery = &(Query_for_list_of_tables); completion_charp = " UNION SELECT 'TABLE'"; matches = rl_completion_matches(text, complete_from_schema_query); } while (0);

 else if (pg_strcasecmp((previous_words[0]), "TABLE") == 0 &&
    pg_strcasecmp((previous_words[1]), "LOCK") == 0)
  do { completion_squery = &(Query_for_list_of_tables); completion_charp = ""; matches = rl_completion_matches(text, complete_from_schema_query); } while (0);




 else if ((pg_strcasecmp((previous_words[1]), "LOCK") == 0 &&
     pg_strcasecmp((previous_words[0]), "TABLE") != 0) ||
    (pg_strcasecmp((previous_words[1]), "TABLE") == 0 &&
     pg_strcasecmp((previous_words[2]), "LOCK") == 0))
  do { completion_charp = "IN"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);


 else if (pg_strcasecmp((previous_words[0]), "IN") == 0 &&
    (pg_strcasecmp((previous_words[2]), "LOCK") == 0 ||
     (pg_strcasecmp((previous_words[2]), "TABLE") == 0 &&
      pg_strcasecmp((previous_words[3]), "LOCK") == 0)))
 {
  static const char *const lock_modes[] =
  {"ACCESS SHARE MODE",
   "ROW SHARE MODE", "ROW EXCLUSIVE MODE",
   "SHARE UPDATE EXCLUSIVE MODE", "SHARE MODE",
   "SHARE ROW EXCLUSIVE MODE",
  "EXCLUSIVE MODE", "ACCESS EXCLUSIVE MODE", ((void *)0)};

  do { completion_charpp = lock_modes; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }


 else if (pg_strcasecmp((previous_words[0]), "NOTIFY") == 0)
  do { completion_charp = "SELECT pg_catalog.quote_ident(channel) FROM pg_catalog.pg_listening_channels() AS channel WHERE substring(pg_catalog.quote_ident(channel),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);


 else if (pg_strcasecmp((previous_words[0]), "OPTIONS") == 0)
  do { completion_charp = "("; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);


 else if (pg_strcasecmp((previous_words[1]), "OWNER") == 0 &&
    pg_strcasecmp((previous_words[0]), "TO") == 0)
  do { completion_charp = " SELECT pg_catalog.quote_ident(rolname) ""   FROM pg_catalog.pg_roles ""  WHERE substring(pg_catalog.quote_ident(rolname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);


 else if (pg_strcasecmp((previous_words[2]), "FROM") == 0 &&
    pg_strcasecmp((previous_words[0]), "ORDER") == 0)
  do { completion_charp = "BY"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 else if (pg_strcasecmp((previous_words[3]), "FROM") == 0 &&
    pg_strcasecmp((previous_words[1]), "ORDER") == 0 &&
    pg_strcasecmp((previous_words[0]), "BY") == 0)
  do { char *_completion_schema; char *_completion_table; _completion_schema = strtokx((previous_words[2]), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); (void) strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); _completion_table = strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); if (_completion_table == ((void *)0)) { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c "" WHERE c.oid = a.attrelid ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"'='%s') ""   AND pg_catalog.pg_table_is_visible(c.oid)" ""; completion_info_charp = (previous_words[2]); } else { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c, pg_catalog.pg_namespace n "" WHERE c.oid = a.attrelid ""   AND n.oid = c.relnamespace ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"' ='%s') ""   AND (pg_catalog.quote_ident(nspname)='%s' ""        OR '\"' || nspname || '\"' ='%s') " ""; completion_info_charp = _completion_table; completion_info_charp2 = _completion_schema; } matches = rl_completion_matches(text, complete_from_query); } while (0);


 else if (pg_strcasecmp((previous_words[0]), "AS") == 0 &&
    pg_strcasecmp((previous_words[2]), "PREPARE") == 0)
 {
  static const char *const list_PREPARE[] =
  {"SELECT", "UPDATE", "INSERT", "DELETE", ((void *)0)};

  do { completion_charpp = list_PREPARE; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }







 else if (pg_strcasecmp((previous_words[0]), "REASSIGN") == 0)
  do { completion_charp = "OWNED"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 else if (pg_strcasecmp((previous_words[0]), "OWNED") == 0 &&
    pg_strcasecmp((previous_words[1]), "REASSIGN") == 0)
  do { completion_charp = "BY"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 else if (pg_strcasecmp((previous_words[0]), "BY") == 0 &&
    pg_strcasecmp((previous_words[1]), "OWNED") == 0 &&
    pg_strcasecmp((previous_words[2]), "REASSIGN") == 0)
  do { completion_charp = " SELECT pg_catalog.quote_ident(rolname) ""   FROM pg_catalog.pg_roles ""  WHERE substring(pg_catalog.quote_ident(rolname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 else if (pg_strcasecmp((previous_words[1]), "BY") == 0 &&
    pg_strcasecmp((previous_words[2]), "OWNED") == 0 &&
    pg_strcasecmp((previous_words[3]), "REASSIGN") == 0)
  do { completion_charp = "TO"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 else if (pg_strcasecmp((previous_words[0]), "TO") == 0 &&
    pg_strcasecmp((previous_words[2]), "BY") == 0 &&
    pg_strcasecmp((previous_words[3]), "OWNED") == 0 &&
    pg_strcasecmp((previous_words[4]), "REASSIGN") == 0)
  do { completion_charp = " SELECT pg_catalog.quote_ident(rolname) ""   FROM pg_catalog.pg_roles ""  WHERE substring(pg_catalog.quote_ident(rolname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);


 else if (pg_strcasecmp((previous_words[0]), "REINDEX") == 0)
 {
  static const char *const list_REINDEX[] =
  {"TABLE", "INDEX", "SYSTEM", "DATABASE", ((void *)0)};

  do { completion_charpp = list_REINDEX; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
 else if (pg_strcasecmp((previous_words[1]), "REINDEX") == 0)
 {
  if (pg_strcasecmp((previous_words[0]), "TABLE") == 0)
   do { completion_squery = &(Query_for_list_of_tables); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);
  else if (pg_strcasecmp((previous_words[0]), "INDEX") == 0)
   do { completion_squery = &(Query_for_list_of_indexes); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);
  else if (pg_strcasecmp((previous_words[0]), "SYSTEM") == 0 ||
     pg_strcasecmp((previous_words[0]), "DATABASE") == 0)
   do { completion_charp = "SELECT pg_catalog.quote_ident(datname) FROM pg_catalog.pg_database "" WHERE substring(pg_catalog.quote_ident(datname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 }


 else if (pg_strcasecmp((previous_words[0]), "SECURITY") == 0)
  do { completion_charp = "LABEL"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 else if (pg_strcasecmp((previous_words[1]), "SECURITY") == 0 &&
    pg_strcasecmp((previous_words[0]), "LABEL") == 0)
 {
  static const char *const list_SECURITY_LABEL_preposition[] =
  {"ON", "FOR"};

  do { completion_charpp = list_SECURITY_LABEL_preposition; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
 else if (pg_strcasecmp((previous_words[3]), "SECURITY") == 0 &&
    pg_strcasecmp((previous_words[2]), "LABEL") == 0 &&
    pg_strcasecmp((previous_words[1]), "FOR") == 0)
  do { completion_charp = "ON"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 else if ((pg_strcasecmp((previous_words[2]), "SECURITY") == 0 &&
     pg_strcasecmp((previous_words[1]), "LABEL") == 0 &&
     pg_strcasecmp((previous_words[0]), "ON") == 0) ||
    (pg_strcasecmp((previous_words[4]), "SECURITY") == 0 &&
     pg_strcasecmp((previous_words[3]), "LABEL") == 0 &&
     pg_strcasecmp((previous_words[2]), "FOR") == 0 &&
     pg_strcasecmp((previous_words[0]), "ON") == 0))
 {
  static const char *const list_SECURITY_LABEL[] =
  {"LANGUAGE", "SCHEMA", "SEQUENCE", "TABLE", "TYPE", "VIEW", "COLUMN",
   "AGGREGATE", "FUNCTION", "DOMAIN", "LARGE OBJECT",
  ((void *)0)};

  do { completion_charpp = list_SECURITY_LABEL; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
 else if (pg_strcasecmp((previous_words[4]), "SECURITY") == 0 &&
    pg_strcasecmp((previous_words[3]), "LABEL") == 0 &&
    pg_strcasecmp((previous_words[2]), "ON") == 0)
  do { completion_charp = "IS"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);






 else if ((pg_strcasecmp((previous_words[0]), "SET") == 0 &&
     pg_strcasecmp((previous_words[2]), "UPDATE") != 0) ||
    pg_strcasecmp((previous_words[0]), "RESET") == 0)
  do { completion_charp = "SELECT name FROM "" (SELECT pg_catalog.lower(name) AS name FROM pg_catalog.pg_settings ""  WHERE context IN ('user', 'superuser') ""  UNION ALL SELECT 'constraints' ""  UNION ALL SELECT 'transaction' ""  UNION ALL SELECT 'session' ""  UNION ALL SELECT 'role' ""  UNION ALL SELECT 'tablespace' ""  UNION ALL SELECT 'all') ss "" WHERE substring(name,1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 else if (pg_strcasecmp((previous_words[0]), "SHOW") == 0)
  do { completion_charp = "SELECT name FROM "" (SELECT pg_catalog.lower(name) AS name FROM pg_catalog.pg_settings ""  UNION ALL SELECT 'session authorization' ""  UNION ALL SELECT 'all') ss "" WHERE substring(name,1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);

 else if ((pg_strcasecmp((previous_words[1]), "SET") == 0 &&
     pg_strcasecmp((previous_words[0]), "TRANSACTION") == 0)
    || (pg_strcasecmp((previous_words[1]), "START") == 0
     && pg_strcasecmp((previous_words[0]), "TRANSACTION") == 0)
    || (pg_strcasecmp((previous_words[1]), "BEGIN") == 0
     && pg_strcasecmp((previous_words[0]), "WORK") == 0)
    || (pg_strcasecmp((previous_words[1]), "BEGIN") == 0
     && pg_strcasecmp((previous_words[0]), "TRANSACTION") == 0)
    || (pg_strcasecmp((previous_words[3]), "SESSION") == 0
     && pg_strcasecmp((previous_words[2]), "CHARACTERISTICS") == 0
     && pg_strcasecmp((previous_words[1]), "AS") == 0
     && pg_strcasecmp((previous_words[0]), "TRANSACTION") == 0))
 {
  static const char *const my_list[] =
  {"ISOLATION LEVEL", "READ", ((void *)0)};

  do { completion_charpp = my_list; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
 else if ((pg_strcasecmp((previous_words[2]), "SET") == 0
     || pg_strcasecmp((previous_words[2]), "BEGIN") == 0
     || pg_strcasecmp((previous_words[2]), "START") == 0
     || (pg_strcasecmp((previous_words[3]), "CHARACTERISTICS") == 0
      && pg_strcasecmp((previous_words[2]), "AS") == 0))
    && (pg_strcasecmp((previous_words[1]), "TRANSACTION") == 0
     || pg_strcasecmp((previous_words[1]), "WORK") == 0)
    && pg_strcasecmp((previous_words[0]), "ISOLATION") == 0)
  do { completion_charp = "LEVEL"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 else if ((pg_strcasecmp((previous_words[3]), "SET") == 0
     || pg_strcasecmp((previous_words[3]), "BEGIN") == 0
     || pg_strcasecmp((previous_words[3]), "START") == 0
     || pg_strcasecmp((previous_words[3]), "AS") == 0)
    && (pg_strcasecmp((previous_words[2]), "TRANSACTION") == 0
     || pg_strcasecmp((previous_words[2]), "WORK") == 0)
    && pg_strcasecmp((previous_words[1]), "ISOLATION") == 0
    && pg_strcasecmp((previous_words[0]), "LEVEL") == 0)
 {
  static const char *const my_list[] =
  {"READ", "REPEATABLE", "SERIALIZABLE", ((void *)0)};

  do { completion_charpp = my_list; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
 else if ((pg_strcasecmp((previous_words[3]), "TRANSACTION") == 0 ||
     pg_strcasecmp((previous_words[3]), "WORK") == 0) &&
    pg_strcasecmp((previous_words[2]), "ISOLATION") == 0 &&
    pg_strcasecmp((previous_words[1]), "LEVEL") == 0 &&
    pg_strcasecmp((previous_words[0]), "READ") == 0)
 {
  static const char *const my_list[] =
  {"UNCOMMITTED", "COMMITTED", ((void *)0)};

  do { completion_charpp = my_list; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
 else if ((pg_strcasecmp((previous_words[3]), "TRANSACTION") == 0 ||
     pg_strcasecmp((previous_words[3]), "WORK") == 0) &&
    pg_strcasecmp((previous_words[2]), "ISOLATION") == 0 &&
    pg_strcasecmp((previous_words[1]), "LEVEL") == 0 &&
    pg_strcasecmp((previous_words[0]), "REPEATABLE") == 0)
  do { completion_charp = "READ"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 else if ((pg_strcasecmp((previous_words[2]), "SET") == 0 ||
     pg_strcasecmp((previous_words[2]), "BEGIN") == 0 ||
     pg_strcasecmp((previous_words[2]), "START") == 0 ||
     pg_strcasecmp((previous_words[2]), "AS") == 0) &&
    (pg_strcasecmp((previous_words[1]), "TRANSACTION") == 0 ||
     pg_strcasecmp((previous_words[1]), "WORK") == 0) &&
    pg_strcasecmp((previous_words[0]), "READ") == 0)
 {
  static const char *const my_list[] =
  {"ONLY", "WRITE", ((void *)0)};

  do { completion_charpp = my_list; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[2]), "SET") == 0 &&
    pg_strcasecmp((previous_words[1]), "CONSTRAINTS") == 0)
 {
  static const char *const constraint_list[] =
  {"DEFERRED", "IMMEDIATE", ((void *)0)};

  do { completion_charpp = constraint_list; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[1]), "SET") == 0 &&
    pg_strcasecmp((previous_words[0]), "ROLE") == 0)
  do { completion_charp = " SELECT pg_catalog.quote_ident(rolname) ""   FROM pg_catalog.pg_roles ""  WHERE substring(pg_catalog.quote_ident(rolname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);

 else if (pg_strcasecmp((previous_words[1]), "SET") == 0 &&
    pg_strcasecmp((previous_words[0]), "SESSION") == 0)
 {
  static const char *const my_list[] =
  {"AUTHORIZATION", "CHARACTERISTICS AS TRANSACTION", ((void *)0)};

  do { completion_charpp = my_list; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }

 else if (pg_strcasecmp((previous_words[2]), "SET") == 0
    && pg_strcasecmp((previous_words[1]), "SESSION") == 0
    && pg_strcasecmp((previous_words[0]), "AUTHORIZATION") == 0)
  do { completion_charp = " SELECT pg_catalog.quote_ident(rolname) ""   FROM pg_catalog.pg_roles ""  WHERE substring(pg_catalog.quote_ident(rolname),1,%d)='%s'" " UNION SELECT 'DEFAULT'"; matches = rl_completion_matches(text, complete_from_query); } while (0);

 else if (pg_strcasecmp((previous_words[1]), "RESET") == 0 &&
    pg_strcasecmp((previous_words[0]), "SESSION") == 0)
  do { completion_charp = "AUTHORIZATION"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);

 else if (pg_strcasecmp((previous_words[1]), "SET") == 0 &&
    pg_strcasecmp((previous_words[3]), "UPDATE") != 0 &&
    pg_strcasecmp((previous_words[0]), "TABLESPACE") != 0 &&
    pg_strcasecmp((previous_words[0]), "SCHEMA") != 0 &&
    (previous_words[0])[strlen((previous_words[0])) - 1] != ')' &&
    pg_strcasecmp((previous_words[3]), "DOMAIN") != 0)
  do { completion_charp = "TO"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);

 else if (pg_strcasecmp((previous_words[2]), "SET") == 0 &&
    (pg_strcasecmp((previous_words[0]), "TO") == 0 || strcmp((previous_words[0]), "=") == 0))
 {
  if (pg_strcasecmp((previous_words[1]), "DateStyle") == 0)
  {
   static const char *const my_list[] =
   {"ISO", "SQL", "Postgres", "German",
    "YMD", "DMY", "MDY",
    "US", "European", "NonEuropean",
   "DEFAULT", ((void *)0)};

   do { completion_charpp = my_list; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
  }
  else if (pg_strcasecmp((previous_words[1]), "IntervalStyle") == 0)
  {
   static const char *const my_list[] =
   {"postgres", "postgres_verbose", "sql_standard", "iso_8601", ((void *)0)};

   do { completion_charpp = my_list; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
  }
  else if (pg_strcasecmp((previous_words[1]), "GEQO") == 0)
  {
   static const char *const my_list[] =
   {"ON", "OFF", "DEFAULT", ((void *)0)};

   do { completion_charpp = my_list; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
  }
  else
  {
   static const char *const my_list[] =
   {"DEFAULT", ((void *)0)};

   do { completion_charpp = my_list; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
  }
 }


 else if (pg_strcasecmp((previous_words[0]), "START") == 0)
  do { completion_charp = "TRANSACTION"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);


 else if (pg_strcasecmp((previous_words[0]), "TABLE") == 0 &&
    (previous_words[1])[0] == '\0')
  do { completion_squery = &(Query_for_list_of_relations); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);


 else if (pg_strcasecmp((previous_words[0]), "TRUNCATE") == 0)
  do { completion_squery = &(Query_for_list_of_tables); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);


 else if (pg_strcasecmp((previous_words[0]), "UNLISTEN") == 0)
  do { completion_charp = "SELECT pg_catalog.quote_ident(channel) FROM pg_catalog.pg_listening_channels() AS channel WHERE substring(pg_catalog.quote_ident(channel),1,%d)='%s' UNION SELECT '*'"; matches = rl_completion_matches(text, complete_from_query); } while (0);



 else if (pg_strcasecmp((previous_words[0]), "UPDATE") == 0)
  do { completion_squery = &(Query_for_list_of_updatables); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);

 else if (pg_strcasecmp((previous_words[1]), "UPDATE") == 0)
  do { completion_charp = "SET"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);






 else if (pg_strcasecmp((previous_words[0]), "SET") == 0)
  do { char *_completion_schema; char *_completion_table; _completion_schema = strtokx((previous_words[1]), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); (void) strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); _completion_table = strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); if (_completion_table == ((void *)0)) { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c "" WHERE c.oid = a.attrelid ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"'='%s') ""   AND pg_catalog.pg_table_is_visible(c.oid)" ""; completion_info_charp = (previous_words[1]); } else { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c, pg_catalog.pg_namespace n "" WHERE c.oid = a.attrelid ""   AND n.oid = c.relnamespace ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"' ='%s') ""   AND (pg_catalog.quote_ident(nspname)='%s' ""        OR '\"' || nspname || '\"' ='%s') " ""; completion_info_charp = _completion_table; completion_info_charp2 = _completion_schema; } matches = rl_completion_matches(text, complete_from_query); } while (0);


 else if (pg_strcasecmp((previous_words[1]), "SET") == 0 &&
    pg_strcasecmp((previous_words[3]), "UPDATE") == 0)
  do { completion_charp = "="; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);


 else if ((pg_strcasecmp((previous_words[2]), "ALTER") == 0 ||
     pg_strcasecmp((previous_words[2]), "CREATE") == 0 ||
     pg_strcasecmp((previous_words[2]), "DROP") == 0) &&
    pg_strcasecmp((previous_words[1]), "USER") == 0 &&
    pg_strcasecmp((previous_words[0]), "MAPPING") == 0)
  do { completion_charp = "FOR"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);
 else if (pg_strcasecmp((previous_words[3]), "CREATE") == 0 &&
    pg_strcasecmp((previous_words[2]), "USER") == 0 &&
    pg_strcasecmp((previous_words[1]), "MAPPING") == 0 &&
    pg_strcasecmp((previous_words[0]), "FOR") == 0)
  do { completion_charp = " SELECT pg_catalog.quote_ident(rolname) ""   FROM pg_catalog.pg_roles ""  WHERE substring(pg_catalog.quote_ident(rolname),1,%d)='%s'" " UNION SELECT 'CURRENT_USER'" " UNION SELECT 'PUBLIC'" " UNION SELECT 'USER'"; matches = rl_completion_matches(text, complete_from_query); } while (0);



 else if ((pg_strcasecmp((previous_words[3]), "ALTER") == 0 ||
     pg_strcasecmp((previous_words[3]), "DROP") == 0) &&
    pg_strcasecmp((previous_words[2]), "USER") == 0 &&
    pg_strcasecmp((previous_words[1]), "MAPPING") == 0 &&
    pg_strcasecmp((previous_words[0]), "FOR") == 0)
  do { completion_charp = " SELECT pg_catalog.quote_ident(usename) ""   FROM pg_catalog.pg_user_mappings ""  WHERE substring(pg_catalog.quote_ident(usename),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 else if ((pg_strcasecmp((previous_words[4]), "CREATE") == 0 ||
     pg_strcasecmp((previous_words[4]), "ALTER") == 0 ||
     pg_strcasecmp((previous_words[4]), "DROP") == 0) &&
    pg_strcasecmp((previous_words[3]), "USER") == 0 &&
    pg_strcasecmp((previous_words[2]), "MAPPING") == 0 &&
    pg_strcasecmp((previous_words[1]), "FOR") == 0)
  do { completion_charp = "SERVER"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);





 else if (pg_strcasecmp((previous_words[0]), "VACUUM") == 0)
  do { completion_squery = &(Query_for_list_of_tables); completion_charp = " UNION SELECT 'FULL'" " UNION SELECT 'FREEZE'" " UNION SELECT 'ANALYZE'" " UNION SELECT 'VERBOSE'"; matches = rl_completion_matches(text, complete_from_schema_query); } while (0);




 else if (pg_strcasecmp((previous_words[1]), "VACUUM") == 0 &&
    (pg_strcasecmp((previous_words[0]), "FULL") == 0 ||
     pg_strcasecmp((previous_words[0]), "FREEZE") == 0))
  do { completion_squery = &(Query_for_list_of_tables); completion_charp = " UNION SELECT 'ANALYZE'" " UNION SELECT 'VERBOSE'"; matches = rl_completion_matches(text, complete_from_schema_query); } while (0);


 else if (pg_strcasecmp((previous_words[2]), "VACUUM") == 0 &&
    pg_strcasecmp((previous_words[0]), "ANALYZE") == 0 &&
    (pg_strcasecmp((previous_words[1]), "FULL") == 0 ||
     pg_strcasecmp((previous_words[1]), "FREEZE") == 0))
  do { completion_squery = &(Query_for_list_of_tables); completion_charp = " UNION SELECT 'VERBOSE'"; matches = rl_completion_matches(text, complete_from_schema_query); } while (0);

 else if (pg_strcasecmp((previous_words[2]), "VACUUM") == 0 &&
    pg_strcasecmp((previous_words[0]), "VERBOSE") == 0 &&
    (pg_strcasecmp((previous_words[1]), "FULL") == 0 ||
     pg_strcasecmp((previous_words[1]), "FREEZE") == 0))
  do { completion_squery = &(Query_for_list_of_tables); completion_charp = " UNION SELECT 'ANALYZE'"; matches = rl_completion_matches(text, complete_from_schema_query); } while (0);

 else if (pg_strcasecmp((previous_words[1]), "VACUUM") == 0 &&
    pg_strcasecmp((previous_words[0]), "VERBOSE") == 0)
  do { completion_squery = &(Query_for_list_of_tables); completion_charp = " UNION SELECT 'ANALYZE'"; matches = rl_completion_matches(text, complete_from_schema_query); } while (0);

 else if (pg_strcasecmp((previous_words[1]), "VACUUM") == 0 &&
    pg_strcasecmp((previous_words[0]), "ANALYZE") == 0)
  do { completion_squery = &(Query_for_list_of_tables); completion_charp = " UNION SELECT 'VERBOSE'"; matches = rl_completion_matches(text, complete_from_schema_query); } while (0);

 else if ((pg_strcasecmp((previous_words[0]), "ANALYZE") == 0 &&
     pg_strcasecmp((previous_words[1]), "VERBOSE") == 0) ||
    (pg_strcasecmp((previous_words[0]), "VERBOSE") == 0 &&
     pg_strcasecmp((previous_words[1]), "ANALYZE") == 0))
  do { completion_squery = &(Query_for_list_of_tables); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);







 else if (pg_strcasecmp((previous_words[0]), "WITH") == 0 &&
    (previous_words[1])[0] == '\0')
  do { completion_charp = "RECURSIVE"; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);



 else if (pg_strcasecmp((previous_words[0]), "ANALYZE") == 0)
  do { completion_squery = &(Query_for_list_of_tf); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);



 else if (pg_strcasecmp((previous_words[0]), "WHERE") == 0)
  do { char *_completion_schema; char *_completion_table; _completion_schema = strtokx((previous_words[1]), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); (void) strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); _completion_table = strtokx(((void *)0), " \t\n\r", ".", "\"", 0, ((bool) 0), ((bool) 0), pset.encoding); if (_completion_table == ((void *)0)) { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c "" WHERE c.oid = a.attrelid ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"'='%s') ""   AND pg_catalog.pg_table_is_visible(c.oid)" ""; completion_info_charp = (previous_words[1]); } else { completion_charp = "SELECT pg_catalog.quote_ident(attname) ""  FROM pg_catalog.pg_attribute a, pg_catalog.pg_class c, pg_catalog.pg_namespace n "" WHERE c.oid = a.attrelid ""   AND n.oid = c.relnamespace ""   AND a.attnum > 0 ""   AND NOT a.attisdropped ""   AND substring(pg_catalog.quote_ident(attname),1,%d)='%s' ""   AND (pg_catalog.quote_ident(relname)='%s' ""        OR '\"' || relname || '\"' ='%s') ""   AND (pg_catalog.quote_ident(nspname)='%s' ""        OR '\"' || nspname || '\"' ='%s') " ""; completion_info_charp = _completion_table; completion_info_charp2 = _completion_schema; } matches = rl_completion_matches(text, complete_from_query); } while (0);



 else if (pg_strcasecmp((previous_words[0]), "FROM") == 0 &&
    pg_strcasecmp((previous_words[2]), "COPY") != 0 &&
    pg_strcasecmp((previous_words[2]), "\\copy") != 0)
  do { completion_squery = &(Query_for_list_of_tsvf); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);


 else if (pg_strcasecmp((previous_words[0]), "JOIN") == 0)
  do { completion_squery = &(Query_for_list_of_tsvf); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);



 else if (strcmp((previous_words[0]), "\\connect") == 0 || strcmp((previous_words[0]), "\\c") == 0)
  do { completion_charp = "SELECT pg_catalog.quote_ident(datname) FROM pg_catalog.pg_database "" WHERE substring(pg_catalog.quote_ident(datname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);

 else if (strncmp((previous_words[0]), "\\da", strlen("\\da")) == 0)
  do { completion_squery = &(Query_for_list_of_aggregates); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);
 else if (strncmp((previous_words[0]), "\\db", strlen("\\db")) == 0)
  do { completion_charp = "SELECT pg_catalog.quote_ident(spcname) FROM pg_catalog.pg_tablespace "" WHERE substring(pg_catalog.quote_ident(spcname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 else if (strncmp((previous_words[0]), "\\dD", strlen("\\dD")) == 0)
  do { completion_squery = &(Query_for_list_of_domains); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);
 else if (strncmp((previous_words[0]), "\\des", strlen("\\des")) == 0)
  do { completion_charp = " SELECT pg_catalog.quote_ident(srvname) ""   FROM pg_catalog.pg_foreign_server ""  WHERE substring(pg_catalog.quote_ident(srvname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 else if (strncmp((previous_words[0]), "\\deu", strlen("\\deu")) == 0)
  do { completion_charp = " SELECT pg_catalog.quote_ident(usename) ""   FROM pg_catalog.pg_user_mappings ""  WHERE substring(pg_catalog.quote_ident(usename),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 else if (strncmp((previous_words[0]), "\\dew", strlen("\\dew")) == 0)
  do { completion_charp = " SELECT pg_catalog.quote_ident(fdwname) ""   FROM pg_catalog.pg_foreign_data_wrapper ""  WHERE substring(pg_catalog.quote_ident(fdwname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);

 else if (strncmp((previous_words[0]), "\\df", strlen("\\df")) == 0)
  do { completion_squery = &(Query_for_list_of_functions); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);
 else if (strncmp((previous_words[0]), "\\dFd", strlen("\\dFd")) == 0)
  do { completion_charp = "SELECT pg_catalog.quote_ident(dictname) FROM pg_catalog.pg_ts_dict "" WHERE substring(pg_catalog.quote_ident(dictname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 else if (strncmp((previous_words[0]), "\\dFp", strlen("\\dFp")) == 0)
  do { completion_charp = "SELECT pg_catalog.quote_ident(prsname) FROM pg_catalog.pg_ts_parser "" WHERE substring(pg_catalog.quote_ident(prsname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 else if (strncmp((previous_words[0]), "\\dFt", strlen("\\dFt")) == 0)
  do { completion_charp = "SELECT pg_catalog.quote_ident(tmplname) FROM pg_catalog.pg_ts_template "" WHERE substring(pg_catalog.quote_ident(tmplname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);

 else if (strncmp((previous_words[0]), "\\dF", strlen("\\dF")) == 0)
  do { completion_charp = "SELECT pg_catalog.quote_ident(cfgname) FROM pg_catalog.pg_ts_config "" WHERE substring(pg_catalog.quote_ident(cfgname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);

 else if (strncmp((previous_words[0]), "\\di", strlen("\\di")) == 0)
  do { completion_squery = &(Query_for_list_of_indexes); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);
 else if (strncmp((previous_words[0]), "\\dL", strlen("\\dL")) == 0)
  do { completion_charp = "SELECT pg_catalog.quote_ident(lanname) ""  FROM pg_catalog.pg_language "" WHERE lanname != 'internal' ""   AND substring(pg_catalog.quote_ident(lanname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 else if (strncmp((previous_words[0]), "\\dn", strlen("\\dn")) == 0)
  do { completion_charp = "SELECT pg_catalog.quote_ident(nspname) FROM pg_catalog.pg_namespace "" WHERE substring(pg_catalog.quote_ident(nspname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 else if (strncmp((previous_words[0]), "\\dp", strlen("\\dp")) == 0
    || strncmp((previous_words[0]), "\\z", strlen("\\z")) == 0)
  do { completion_squery = &(Query_for_list_of_tsvf); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);
 else if (strncmp((previous_words[0]), "\\ds", strlen("\\ds")) == 0)
  do { completion_squery = &(Query_for_list_of_sequences); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);
 else if (strncmp((previous_words[0]), "\\dt", strlen("\\dt")) == 0)
  do { completion_squery = &(Query_for_list_of_tables); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);
 else if (strncmp((previous_words[0]), "\\dT", strlen("\\dT")) == 0)
  do { completion_squery = &(Query_for_list_of_datatypes); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);
 else if (strncmp((previous_words[0]), "\\du", strlen("\\du")) == 0
    || (strncmp((previous_words[0]), "\\dg", strlen("\\dg")) == 0))
  do { completion_charp = " SELECT pg_catalog.quote_ident(rolname) ""   FROM pg_catalog.pg_roles ""  WHERE substring(pg_catalog.quote_ident(rolname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 else if (strncmp((previous_words[0]), "\\dv", strlen("\\dv")) == 0)
  do { completion_squery = &(Query_for_list_of_views); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);


 else if (strncmp((previous_words[0]), "\\d", strlen("\\d")) == 0)
  do { completion_squery = &(Query_for_list_of_relations); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);

 else if (strcmp((previous_words[0]), "\\ef") == 0)
  do { completion_squery = &(Query_for_list_of_functions); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);

 else if (strcmp((previous_words[0]), "\\encoding") == 0)
  do { completion_charp = " SELECT DISTINCT pg_catalog.pg_encoding_to_char(conforencoding) ""   FROM pg_catalog.pg_conversion ""  WHERE substring(pg_catalog.pg_encoding_to_char(conforencoding),1,%d)=UPPER('%s')"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 else if (strcmp((previous_words[0]), "\\h") == 0 || strcmp((previous_words[0]), "\\help") == 0)
  do { completion_charpp = sql_commands; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_list); } while (0);
 else if (strcmp((previous_words[0]), "\\password") == 0)
  do { completion_charp = " SELECT pg_catalog.quote_ident(rolname) ""   FROM pg_catalog.pg_roles ""  WHERE substring(pg_catalog.quote_ident(rolname),1,%d)='%s'"; matches = rl_completion_matches(text, complete_from_query); } while (0);
 else if (strcmp((previous_words[0]), "\\pset") == 0)
 {
  static const char *const my_list[] =
  {"format", "border", "expanded",
   "null", "fieldsep", "tuples_only", "title", "tableattr",
  "linestyle", "pager", "recordsep", ((void *)0)};

  do { completion_charpp = my_list; completion_case_sensitive = ((bool) 1); matches = rl_completion_matches(text, complete_from_list); } while (0);
 }
 else if (strcmp((previous_words[1]), "\\pset") == 0)
 {
  if (strcmp((previous_words[0]), "format") == 0)
  {
   static const char *const my_list[] =
   {"unaligned", "aligned", "wrapped", "html", "latex",
   "troff-ms", ((void *)0)};

   do { completion_charpp = my_list; completion_case_sensitive = ((bool) 1); matches = rl_completion_matches(text, complete_from_list); } while (0);
  }
  else if (strcmp((previous_words[0]), "linestyle") == 0)
  {
   static const char *const my_list[] =
   {"ascii", "old-ascii", "unicode", ((void *)0)};

   do { completion_charpp = my_list; completion_case_sensitive = ((bool) 1); matches = rl_completion_matches(text, complete_from_list); } while (0);
  }
 }
 else if (strcmp((previous_words[0]), "\\set") == 0)
 {
  matches = complete_from_variables(text, "", "");
 }
 else if (strcmp((previous_words[0]), "\\sf") == 0 || strcmp((previous_words[0]), "\\sf+") == 0)
  do { completion_squery = &(Query_for_list_of_functions); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);
 else if (strcmp((previous_words[0]), "\\cd") == 0 ||
    strcmp((previous_words[0]), "\\e") == 0 || strcmp((previous_words[0]), "\\edit") == 0 ||
    strcmp((previous_words[0]), "\\g") == 0 ||
    strcmp((previous_words[0]), "\\i") == 0 || strcmp((previous_words[0]), "\\include") == 0 ||
    strcmp((previous_words[0]), "\\ir") == 0 || strcmp((previous_words[0]), "\\include_relative") == 0 ||
    strcmp((previous_words[0]), "\\o") == 0 || strcmp((previous_words[0]), "\\out") == 0 ||
    strcmp((previous_words[0]), "\\s") == 0 ||
    strcmp((previous_words[0]), "\\w") == 0 || strcmp((previous_words[0]), "\\write") == 0
  )
 {
  completion_charp = "\\";
  matches = rl_completion_matches(text, complete_from_files);
 }






 else
 {
  int i;

  for (i = 0; words_after_create[i].name; i++)
  {
   if (pg_strcasecmp((previous_words[0]), words_after_create[i].name) == 0)
   {
    if (words_after_create[i].query)
     do { completion_charp = words_after_create[i].query; matches = rl_completion_matches(text, complete_from_query); } while (0);
    else if (words_after_create[i].squery)
     do { completion_squery = &(*words_after_create[i].squery); completion_charp = ((void *)0); matches = rl_completion_matches(text, complete_from_schema_query); } while (0);

    break;
   }
  }
 }






 if (matches == ((void *)0))
 {
  do { completion_charp = ""; completion_case_sensitive = ((bool) 0); matches = rl_completion_matches(text, complete_from_const); } while (0);

  rl_completion_append_character = '\0';

 }


 {
  int i;

  for (i = 0; i < (sizeof (previous_words) / sizeof ((previous_words)[0])); i++)
   free(previous_words[i]);
 }


 return matches;
}
# 3116 "tab-complete.c"
static char *
create_or_drop_command_generator(const char *text, int state, bits32 excluded)
{
 static int list_index,
    string_length;
 const char *name;


 if (state == 0)
 {
  list_index = 0;
  string_length = strlen(text);
 }


 while ((name = words_after_create[list_index++].name))
 {
  if ((pg_strncasecmp(name, text, string_length) == 0) &&
   !(words_after_create[list_index - 1].flags & excluded))
   return pg_strdup_keyword_case(name, text);
 }

 return ((void *)0);
}





static char *
create_command_generator(const char *text, int state)
{
 return create_or_drop_command_generator(text, state, (1 << 0));
}




static char *
drop_command_generator(const char *text, int state)
{
 return create_or_drop_command_generator(text, state, (1 << 1));
}



static char *
complete_from_query(const char *text, int state)
{
 return _complete_from_query(0, text, state);
}

static char *
complete_from_schema_query(const char *text, int state)
{
 return _complete_from_query(1, text, state);
}
# 3196 "tab-complete.c"
static char *
_complete_from_query(int is_schema_query, const char *text, int state)
{
 static int list_index,
    string_length;
 static PGresult *result = ((void *)0);





 if (state == 0)
 {
  PQExpBufferData query_buffer;
  char *e_text;
  char *e_info_charp;
  char *e_info_charp2;

  list_index = 0;
  string_length = strlen(text);


  PQclear(result);
  result = ((void *)0);


  e_text = pg_malloc(string_length * 2 + 1);
  PQescapeString(e_text, text, string_length);

  if (completion_info_charp)
  {
   size_t charp_len;

   charp_len = strlen(completion_info_charp);
   e_info_charp = pg_malloc(charp_len * 2 + 1);
   PQescapeString(e_info_charp, completion_info_charp,
         charp_len);
  }
  else
   e_info_charp = ((void *)0);

  if (completion_info_charp2)
  {
   size_t charp_len;

   charp_len = strlen(completion_info_charp2);
   e_info_charp2 = pg_malloc(charp_len * 2 + 1);
   PQescapeString(e_info_charp2, completion_info_charp2,
         charp_len);
  }
  else
   e_info_charp2 = ((void *)0);

  initPQExpBuffer(&query_buffer);

  if (is_schema_query)
  {

   const char *qualresult = completion_squery->qualresult;

   if (qualresult == ((void *)0))
    qualresult = completion_squery->result;


   appendPQExpBuffer(&query_buffer, "SELECT %s FROM %s WHERE ",
         completion_squery->result,
         completion_squery->catname);
   if (completion_squery->selcondition)
    appendPQExpBuffer(&query_buffer, "%s AND ",
          completion_squery->selcondition);
   appendPQExpBuffer(&query_buffer, "substring(%s,1,%d)='%s'",
         completion_squery->result,
         string_length, e_text);
   appendPQExpBuffer(&query_buffer, " AND %s",
         completion_squery->viscondition);







   if (strcmp(completion_squery->catname,
        "pg_catalog.pg_class c") == 0 &&
    strncmp(text, "pg_", 3) !=0)
   {
    appendPQExpBuffer(&query_buffer,
          " AND c.relnamespace <> (SELECT oid FROM"
       " pg_catalog.pg_namespace WHERE nspname = 'pg_catalog')");
   }





   appendPQExpBuffer(&query_buffer, "\nUNION\n"
         "SELECT pg_catalog.quote_ident(n.nspname) || '.' "
         "FROM pg_catalog.pg_namespace n "
         "WHERE substring(pg_catalog.quote_ident(n.nspname) || '.',1,%d)='%s'",
         string_length, e_text);
   appendPQExpBuffer(&query_buffer,
         " AND (SELECT pg_catalog.count(*)"
         " FROM pg_catalog.pg_namespace"
   " WHERE substring(pg_catalog.quote_ident(nspname) || '.',1,%d) ="
         " substring('%s',1,pg_catalog.length(pg_catalog.quote_ident(nspname))+1)) > 1",
         string_length, e_text);





   appendPQExpBuffer(&query_buffer, "\nUNION\n"
      "SELECT pg_catalog.quote_ident(n.nspname) || '.' || %s "
         "FROM %s, pg_catalog.pg_namespace n "
         "WHERE %s = n.oid AND ",
         qualresult,
         completion_squery->catname,
         completion_squery->namespace);
   if (completion_squery->selcondition)
    appendPQExpBuffer(&query_buffer, "%s AND ",
          completion_squery->selcondition);
   appendPQExpBuffer(&query_buffer, "substring(pg_catalog.quote_ident(n.nspname) || '.' || %s,1,%d)='%s'",
         qualresult,
         string_length, e_text);





   appendPQExpBuffer(&query_buffer,
   " AND substring(pg_catalog.quote_ident(n.nspname) || '.',1,%d) ="
         " substring('%s',1,pg_catalog.length(pg_catalog.quote_ident(n.nspname))+1)",
         string_length, e_text);
   appendPQExpBuffer(&query_buffer,
         " AND (SELECT pg_catalog.count(*)"
         " FROM pg_catalog.pg_namespace"
   " WHERE substring(pg_catalog.quote_ident(nspname) || '.',1,%d) ="
         " substring('%s',1,pg_catalog.length(pg_catalog.quote_ident(nspname))+1)) = 1",
         string_length, e_text);


   if (completion_charp)
    appendPQExpBuffer(&query_buffer, "\n%s", completion_charp);
  }
  else
  {

   appendPQExpBuffer(&query_buffer, completion_charp,
         string_length, e_text,
         e_info_charp, e_info_charp,
         e_info_charp2, e_info_charp2);
  }


  appendPQExpBuffer(&query_buffer, "\nLIMIT %d",
        completion_max_records);

  result = exec_query(query_buffer.data);

  termPQExpBuffer(&query_buffer);
  free(e_text);
  if (e_info_charp)
   free(e_info_charp);
  if (e_info_charp2)
   free(e_info_charp2);
 }


 if (result && PQresultStatus(result) == PGRES_TUPLES_OK)
 {
  const char *item;

  while (list_index < PQntuples(result) &&
      (item = PQgetvalue(result, list_index++, 0)))
   if (pg_strncasecmp(text, item, string_length) == 0)
    return pg_strdup(item);
 }


 PQclear(result);
 result = ((void *)0);
 return ((void *)0);
}







static char *
complete_from_list(const char *text, int state)
{
 static int string_length,
    list_index,
    matches;
 static bool casesensitive;
 const char *item;


 psql_assert(completion_charpp);


 if (state == 0)
 {
  list_index = 0;
  string_length = strlen(text);
  casesensitive = completion_case_sensitive;
  matches = 0;
 }

 while ((item = completion_charpp[list_index++]))
 {

  if (casesensitive && strncmp(text, item, string_length) == 0)
  {
   matches++;
   return pg_strdup(item);
  }


  if (!casesensitive && pg_strncasecmp(text, item, string_length) == 0)
  {
   if (completion_case_sensitive)
    return pg_strdup(item);
   else





    return pg_strdup_keyword_case(item, text);
  }
 }





 if (casesensitive && matches == 0)
 {
  casesensitive = ((bool) 0);
  list_index = 0;
  state++;
  return complete_from_list(text, state);
 }


 return ((void *)0);
}
# 3455 "tab-complete.c"
static char *
complete_from_const(const char *text, int state)
{
 psql_assert(completion_charp);
 if (state == 0)
 {
  if (completion_case_sensitive)
   return pg_strdup(completion_charp);
  else





   return pg_strdup_keyword_case(completion_charp, text);
 }
 else
  return ((void *)0);
}







static char **
complete_from_variables(char *text, const char *prefix, const char *suffix)
{
 char **matches;
 int overhead = strlen(prefix) + strlen(suffix) + 1;
 char **varnames;
 int nvars = 0;
 int maxvars = 100;
 int i;
 struct _variable *ptr;

 varnames = (char **) pg_malloc((maxvars + 1) * sizeof(char *));

 for (ptr = pset.vars->next; ptr; ptr = ptr->next)
 {
  char *buffer;

  if (nvars >= maxvars)
  {
   maxvars *= 2;
   varnames = (char **) realloc(varnames,
           (maxvars + 1) * sizeof(char *));
   if (!varnames)
   {
    psql_error("out of memory\n");
    exit(1);
   }
  }

  buffer = (char *) pg_malloc(strlen(ptr->name) + overhead);
  __builtin___sprintf_chk (buffer, 0, __builtin_object_size (buffer, 2 > 1), "%s%s%s", prefix, ptr->name, suffix);
  varnames[nvars++] = buffer;
 }

 varnames[nvars] = ((void *)0);
 do { completion_charpp = (const char *const *) varnames; completion_case_sensitive = ((bool) 1); matches = rl_completion_matches(text, complete_from_list); } while (0);

 for (i = 0; i < nvars; i++)
  free(varnames[i]);
 free(varnames);

 return matches;
}







static char *
complete_from_files(const char *text, int state)
{
 static const char *unquoted_text;
 char *unquoted_match;
 char *ret = ((void *)0);

 if (state == 0)
 {

  unquoted_text = strtokx(text, "", ((void *)0), "'", *completion_charp,
        ((bool) 0), ((bool) 1), pset.encoding);

  if (!unquoted_text)
  {
   psql_assert(!*text);
   unquoted_text = text;
  }
 }

 unquoted_match = rl_filename_completion_function(unquoted_text, state);
 if (unquoted_match)
 {







  ret = quote_if_needed(unquoted_match, " \t\r\n\"`",
         '\'', *completion_charp, pset.encoding);
  if (ret)
   free(unquoted_match);
  else
   ret = unquoted_match;
 }

 return ret;
}
# 3580 "tab-complete.c"
static char *
pg_strdup_keyword_case(const char *s, const char *ref)
{
 char *ret,
      *p;
 unsigned char first = ref[0];
 int tocase;
 const char *varval;

 varval = GetVariable(pset.vars, "COMP_KEYWORD_CASE");
 if (!varval)
  tocase = 0;
 else if (strcmp(varval, "lower") == 0)
  tocase = -2;
 else if (strcmp(varval, "preserve-lower") == 0)
  tocase = -1;
 else if (strcmp(varval, "preserve-upper") == 0)
  tocase = +1;
 else if (strcmp(varval, "upper") == 0)
  tocase = +2;
 else
  tocase = 0;


 if (tocase == 0)
  tocase = +1;

 ret = pg_strdup(s);

 if (tocase == -2
  || ((tocase == -1 || tocase == +1) && islower(first))
  || (tocase == -1 && !isalpha(first))
  )
  for (p = ret; *p; p++)
   *p = pg_tolower((unsigned char) *p);
 else
  for (p = ret; *p; p++)
   *p = pg_toupper((unsigned char) *p);

 return ret;
}






static PGresult *
exec_query(const char *query)
{
 PGresult *result;

 if (query == ((void *)0) || !pset.db || PQstatus(pset.db) != CONNECTION_OK)
  return ((void *)0);

 result = PQexec(pset.db, query);

 if (PQresultStatus(result) != PGRES_TUPLES_OK)
 {




  PQclear(result);
  result = ((void *)0);
 }

 return result;
}
# 3657 "tab-complete.c"
static void
get_previous_words(int point, char **previous_words, int nwords)
{
 const char *buf = rl_line_buffer;
 int i;


 for (i = point - 1; i >= 0; i--)
  if (strchr("\t\n@$><=;|&{() ", buf[i]))
   break;
 point = i;

 while (nwords-- > 0)
 {
  int start,
     end;
  char *s;


  end = -1;
  for (i = point; i >= 0; i--)
  {
   if (!isspace((unsigned char) buf[i]))
   {
    end = i;
    break;
   }
  }





  if (end < 0)
  {
   point = end;
   s = pg_strdup("");
  }
  else
  {






   bool inquotes = ((bool) 0);
   int parentheses = 0;

   for (start = end; start > 0; start--)
   {
    if (buf[start] == '"')
     inquotes = !inquotes;
    if (!inquotes)
    {
     if (buf[start] == ')')
      parentheses++;
     else if (buf[start] == '(')
     {
      if (--parentheses <= 0)
       break;
     }
     else if (parentheses == 0 &&
        strchr("\t\n@$><=;|&{() ", buf[start - 1]))
      break;
    }
   }

   point = start - 1;


   s = pg_malloc(end - start + 2);
   strlcpy(s, &buf[start], end - start + 2);
  }

  *previous_words++ = s;
 }
}

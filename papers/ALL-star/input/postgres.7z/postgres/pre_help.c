# 1 "help.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "help.c"







# 1 "postgres_fe.h" 1
# 25 "postgres_fe.h"
# 1 "c.h" 1
# 53 "c.h"
# 1 "pg_config.h" 1
# 54 "c.h" 2
# 1 "pg_config_manual.h" 1
# 55 "c.h" 2


# 1 "pg_config_os.h" 1
# 58 "c.h" 2

# 1 "postgres_ext.h" 1
# 29 "postgres_ext.h"
typedef unsigned int Oid;
# 60 "c.h" 2







# 1 "/usr/include/stdio.h" 1 3 4
# 64 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/sys/cdefs.h" 1 3 4
# 417 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 418 "/usr/include/sys/cdefs.h" 2 3 4
# 494 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_posix_availability.h" 1 3 4
# 495 "/usr/include/sys/cdefs.h" 2 3 4
# 65 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/Availability.h" 1 3 4
# 141 "/usr/include/Availability.h" 3 4
# 1 "/usr/include/AvailabilityInternal.h" 1 3 4
# 142 "/usr/include/Availability.h" 2 3 4
# 66 "/usr/include/stdio.h" 2 3 4

# 1 "/usr/include/_types.h" 1 3 4
# 27 "/usr/include/_types.h" 3 4
# 1 "/usr/include/sys/_types.h" 1 3 4
# 33 "/usr/include/sys/_types.h" 3 4
# 1 "/usr/include/machine/_types.h" 1 3 4
# 32 "/usr/include/machine/_types.h" 3 4
# 1 "/usr/include/i386/_types.h" 1 3 4
# 37 "/usr/include/i386/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 70 "/usr/include/i386/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;


typedef long int __darwin_ptrdiff_t;





typedef long unsigned int __darwin_size_t;





typedef __builtin_va_list __darwin_va_list;





typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 33 "/usr/include/machine/_types.h" 2 3 4
# 34 "/usr/include/sys/_types.h" 2 3 4
# 58 "/usr/include/sys/_types.h" 3 4
struct __darwin_pthread_handler_rec
{
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};
struct _opaque_pthread_attr_t { long __sig; char __opaque[56]; };
struct _opaque_pthread_cond_t { long __sig; char __opaque[40]; };
struct _opaque_pthread_condattr_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_mutex_t { long __sig; char __opaque[56]; };
struct _opaque_pthread_mutexattr_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_once_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_rwlock_t { long __sig; char __opaque[192]; };
struct _opaque_pthread_rwlockattr_t { long __sig; char __opaque[16]; };
struct _opaque_pthread_t { long __sig; struct __darwin_pthread_handler_rec *__cleanup_stack; char __opaque[1168]; };
# 94 "/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef struct _opaque_pthread_attr_t
   __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t
   __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t
   __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t
   __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t
   __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t
   __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t
   __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t
   __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t
   *__darwin_pthread_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];
# 28 "/usr/include/_types.h" 2 3 4
# 39 "/usr/include/_types.h" 3 4
typedef int __darwin_nl_item;
typedef int __darwin_wctrans_t;

typedef __uint32_t __darwin_wctype_t;
# 68 "/usr/include/stdio.h" 2 3 4





typedef __darwin_va_list va_list;




typedef __darwin_size_t size_t;






typedef __darwin_off_t fpos_t;
# 96 "/usr/include/stdio.h" 3 4
struct __sbuf {
 unsigned char *_base;
 int _size;
};


struct __sFILEX;
# 130 "/usr/include/stdio.h" 3 4
typedef struct __sFILE {
 unsigned char *_p;
 int _r;
 int _w;
 short _flags;
 short _file;
 struct __sbuf _bf;
 int _lbfsize;


 void *_cookie;
 int (*_close)(void *);
 int (*_read) (void *, char *, int);
 fpos_t (*_seek) (void *, fpos_t, int);
 int (*_write)(void *, const char *, int);


 struct __sbuf _ub;
 struct __sFILEX *_extra;
 int _ur;


 unsigned char _ubuf[3];
 unsigned char _nbuf[1];


 struct __sbuf _lb;


 int _blksize;
 fpos_t _offset;
} FILE;


extern FILE *__stdinp;
extern FILE *__stdoutp;
extern FILE *__stderrp;

# 238 "/usr/include/stdio.h" 3 4

void clearerr(FILE *);
int fclose(FILE *);
int feof(FILE *);
int ferror(FILE *);
int fflush(FILE *);
int fgetc(FILE *);
int fgetpos(FILE * , fpos_t *);
char *fgets(char * , int, FILE *);



FILE *fopen(const char * , const char * ) __asm("_" "fopen" );

int fprintf(FILE * , const char * , ...) __attribute__((__format__ (__printf__, 2, 3)));
int fputc(int, FILE *);
int fputs(const char * , FILE * ) __asm("_" "fputs" );
size_t fread(void * , size_t, size_t, FILE * );
FILE *freopen(const char * , const char * ,
                 FILE * ) __asm("_" "freopen" );
int fscanf(FILE * , const char * , ...) __attribute__((__format__ (__scanf__, 2, 3)));
int fseek(FILE *, long, int);
int fsetpos(FILE *, const fpos_t *);
long ftell(FILE *);
size_t fwrite(const void * , size_t, size_t, FILE * ) __asm("_" "fwrite" );
int getc(FILE *);
int getchar(void);
char *gets(char *);
void perror(const char *);
int printf(const char * , ...) __attribute__((__format__ (__printf__, 1, 2)));
int putc(int, FILE *);
int putchar(int);
int puts(const char *);
int remove(const char *);
int rename (const char *, const char *);
void rewind(FILE *);
int scanf(const char * , ...) __attribute__((__format__ (__scanf__, 1, 2)));
void setbuf(FILE * , char * );
int setvbuf(FILE * , char * , int, size_t);
int sprintf(char * , const char * , ...) __attribute__((__format__ (__printf__, 2, 3)));
int sscanf(const char * , const char * , ...) __attribute__((__format__ (__scanf__, 2, 3)));
FILE *tmpfile(void);
char *tmpnam(char *);
int ungetc(int, FILE *);
int vfprintf(FILE * , const char * , va_list) __attribute__((__format__ (__printf__, 2, 0)));
int vprintf(const char * , va_list) __attribute__((__format__ (__printf__, 1, 0)));
int vsprintf(char * , const char * , va_list) __attribute__((__format__ (__printf__, 2, 0)));

# 296 "/usr/include/stdio.h" 3 4




char *ctermid(char *);





FILE *fdopen(int, const char *) __asm("_" "fdopen" );

int fileno(FILE *);

# 318 "/usr/include/stdio.h" 3 4

int pclose(FILE *);



FILE *popen(const char *, const char *) __asm("_" "popen" );


# 340 "/usr/include/stdio.h" 3 4

int __srget(FILE *);
int __svfscanf(FILE *, const char *, va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int __swbuf(int, FILE *);








static __inline int __sputc(int _c, FILE *_p) {
 if (--_p->_w >= 0 || (_p->_w >= _p->_lbfsize && (char)_c != '\n'))
  return (*_p->_p++ = _c);
 else
  return (__swbuf(_c, _p));
}
# 377 "/usr/include/stdio.h" 3 4

void flockfile(FILE *);
int ftrylockfile(FILE *);
void funlockfile(FILE *);
int getc_unlocked(FILE *);
int getchar_unlocked(void);
int putc_unlocked(int, FILE *);
int putchar_unlocked(int);



int getw(FILE *);
int putw(int, FILE *);


char *tempnam(const char *, const char *) __asm("_" "tempnam" );

# 414 "/usr/include/stdio.h" 3 4
typedef __darwin_off_t off_t;



int fseeko(FILE *, off_t, int);
off_t ftello(FILE *);





int snprintf(char * , size_t, const char * , ...) __attribute__((__format__ (__printf__, 3, 4)));
int vfscanf(FILE * , const char * , va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int vscanf(const char * , va_list) __attribute__((__format__ (__scanf__, 1, 0)));
int vsnprintf(char * , size_t, const char * , va_list) __attribute__((__format__ (__printf__, 3, 0)));
int vsscanf(const char * , const char * , va_list) __attribute__((__format__ (__scanf__, 2, 0)));

# 442 "/usr/include/stdio.h" 3 4
typedef __darwin_ssize_t ssize_t;



int dprintf(int, const char * , ...) __attribute__((__format__ (__printf__, 2, 3))) __attribute__((visibility("default")));
int vdprintf(int, const char * , va_list) __attribute__((__format__ (__printf__, 2, 0))) __attribute__((visibility("default")));
ssize_t getdelim(char ** , size_t * , int, FILE * ) __attribute__((visibility("default")));
ssize_t getline(char ** , size_t * , FILE * ) __attribute__((visibility("default")));









extern const int sys_nerr;
extern const char *const sys_errlist[];

int asprintf(char **, const char *, ...) __attribute__((__format__ (__printf__, 2, 3)));
char *ctermid_r(char *);
char *fgetln(FILE *, size_t *);
const char *fmtcheck(const char *, const char *);
int fpurge(FILE *);
void setbuffer(FILE *, char *, int);
int setlinebuf(FILE *);
int vasprintf(char **, const char *, va_list) __attribute__((__format__ (__printf__, 2, 0)));
FILE *zopen(const char *, const char *, int);





FILE *funopen(const void *,
                 int (*)(void *, char *, int),
                 int (*)(void *, const char *, int),
                 fpos_t (*)(void *, fpos_t, int),
                 int (*)(void *));

# 499 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/secure/_stdio.h" 1 3 4
# 31 "/usr/include/secure/_stdio.h" 3 4
# 1 "/usr/include/secure/_common.h" 1 3 4
# 32 "/usr/include/secure/_stdio.h" 2 3 4
# 45 "/usr/include/secure/_stdio.h" 3 4
extern int __sprintf_chk (char * , int, size_t,
     const char * , ...)
  ;




extern int __snprintf_chk (char * , size_t, int, size_t,
      const char * , ...)
  ;





extern int __vsprintf_chk (char * , int, size_t,
      const char * , va_list)
  ;




extern int __vsnprintf_chk (char * , size_t, int, size_t,
       const char * , va_list)
  ;
# 500 "/usr/include/stdio.h" 2 3 4
# 68 "c.h" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 65 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/sys/wait.h" 1 3 4
# 79 "/usr/include/sys/wait.h" 3 4
typedef enum {
 P_ALL,
 P_PID,
 P_PGID
} idtype_t;






typedef __darwin_pid_t pid_t;




typedef __darwin_id_t id_t;
# 116 "/usr/include/sys/wait.h" 3 4
# 1 "/usr/include/sys/signal.h" 1 3 4
# 73 "/usr/include/sys/signal.h" 3 4
# 1 "/usr/include/sys/appleapiopts.h" 1 3 4
# 74 "/usr/include/sys/signal.h" 2 3 4







# 1 "/usr/include/machine/signal.h" 1 3 4
# 32 "/usr/include/machine/signal.h" 3 4
# 1 "/usr/include/i386/signal.h" 1 3 4
# 39 "/usr/include/i386/signal.h" 3 4
typedef int sig_atomic_t;
# 55 "/usr/include/i386/signal.h" 3 4
# 1 "/usr/include/i386/_structs.h" 1 3 4
# 56 "/usr/include/i386/signal.h" 2 3 4
# 33 "/usr/include/machine/signal.h" 2 3 4
# 82 "/usr/include/sys/signal.h" 2 3 4
# 148 "/usr/include/sys/signal.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 57 "/usr/include/sys/_structs.h" 3 4
# 1 "/usr/include/machine/_structs.h" 1 3 4
# 29 "/usr/include/machine/_structs.h" 3 4
# 1 "/usr/include/i386/_structs.h" 1 3 4
# 38 "/usr/include/i386/_structs.h" 3 4
# 1 "/usr/include/mach/i386/_structs.h" 1 3 4
# 43 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_thread_state
{
    unsigned int __eax;
    unsigned int __ebx;
    unsigned int __ecx;
    unsigned int __edx;
    unsigned int __edi;
    unsigned int __esi;
    unsigned int __ebp;
    unsigned int __esp;
    unsigned int __ss;
    unsigned int __eflags;
    unsigned int __eip;
    unsigned int __cs;
    unsigned int __ds;
    unsigned int __es;
    unsigned int __fs;
    unsigned int __gs;
};
# 89 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_fp_control
{
    unsigned short __invalid :1,
        __denorm :1,
    __zdiv :1,
    __ovrfl :1,
    __undfl :1,
    __precis :1,
      :2,
    __pc :2,





    __rc :2,






             :1,
      :3;
};
typedef struct __darwin_fp_control __darwin_fp_control_t;
# 147 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_fp_status
{
    unsigned short __invalid :1,
        __denorm :1,
    __zdiv :1,
    __ovrfl :1,
    __undfl :1,
    __precis :1,
    __stkflt :1,
    __errsumm :1,
    __c0 :1,
    __c1 :1,
    __c2 :1,
    __tos :3,
    __c3 :1,
    __busy :1;
};
typedef struct __darwin_fp_status __darwin_fp_status_t;
# 191 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_mmst_reg
{
 char __mmst_reg[10];
 char __mmst_rsrv[6];
};
# 210 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_xmm_reg
{
 char __xmm_reg[16];
};
# 232 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_float_state
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;
 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;
 __uint16_t __fpu_rsrv2;
 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;
 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 char __fpu_rsrv4[14*16];
 int __fpu_reserved1;
};


struct __darwin_i386_avx_state
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;
 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;
 __uint16_t __fpu_rsrv2;
 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;
 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 char __fpu_rsrv4[14*16];
 int __fpu_reserved1;
 char __avx_reserved1[64];
 struct __darwin_xmm_reg __fpu_ymmh0;
 struct __darwin_xmm_reg __fpu_ymmh1;
 struct __darwin_xmm_reg __fpu_ymmh2;
 struct __darwin_xmm_reg __fpu_ymmh3;
 struct __darwin_xmm_reg __fpu_ymmh4;
 struct __darwin_xmm_reg __fpu_ymmh5;
 struct __darwin_xmm_reg __fpu_ymmh6;
 struct __darwin_xmm_reg __fpu_ymmh7;
};
# 402 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_exception_state
{
 __uint16_t __trapno;
 __uint16_t __cpu;
 __uint32_t __err;
 __uint32_t __faultvaddr;
};
# 422 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_debug_state32
{
 unsigned int __dr0;
 unsigned int __dr1;
 unsigned int __dr2;
 unsigned int __dr3;
 unsigned int __dr4;
 unsigned int __dr5;
 unsigned int __dr6;
 unsigned int __dr7;
};
# 454 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_thread_state64
{
 __uint64_t __rax;
 __uint64_t __rbx;
 __uint64_t __rcx;
 __uint64_t __rdx;
 __uint64_t __rdi;
 __uint64_t __rsi;
 __uint64_t __rbp;
 __uint64_t __rsp;
 __uint64_t __r8;
 __uint64_t __r9;
 __uint64_t __r10;
 __uint64_t __r11;
 __uint64_t __r12;
 __uint64_t __r13;
 __uint64_t __r14;
 __uint64_t __r15;
 __uint64_t __rip;
 __uint64_t __rflags;
 __uint64_t __cs;
 __uint64_t __fs;
 __uint64_t __gs;
};
# 509 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_float_state64
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;


 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;

 __uint16_t __fpu_rsrv2;


 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;

 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 struct __darwin_xmm_reg __fpu_xmm8;
 struct __darwin_xmm_reg __fpu_xmm9;
 struct __darwin_xmm_reg __fpu_xmm10;
 struct __darwin_xmm_reg __fpu_xmm11;
 struct __darwin_xmm_reg __fpu_xmm12;
 struct __darwin_xmm_reg __fpu_xmm13;
 struct __darwin_xmm_reg __fpu_xmm14;
 struct __darwin_xmm_reg __fpu_xmm15;
 char __fpu_rsrv4[6*16];
 int __fpu_reserved1;
};


struct __darwin_x86_avx_state64
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;


 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;

 __uint16_t __fpu_rsrv2;


 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;

 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 struct __darwin_xmm_reg __fpu_xmm8;
 struct __darwin_xmm_reg __fpu_xmm9;
 struct __darwin_xmm_reg __fpu_xmm10;
 struct __darwin_xmm_reg __fpu_xmm11;
 struct __darwin_xmm_reg __fpu_xmm12;
 struct __darwin_xmm_reg __fpu_xmm13;
 struct __darwin_xmm_reg __fpu_xmm14;
 struct __darwin_xmm_reg __fpu_xmm15;
 char __fpu_rsrv4[6*16];
 int __fpu_reserved1;
 char __avx_reserved1[64];
 struct __darwin_xmm_reg __fpu_ymmh0;
 struct __darwin_xmm_reg __fpu_ymmh1;
 struct __darwin_xmm_reg __fpu_ymmh2;
 struct __darwin_xmm_reg __fpu_ymmh3;
 struct __darwin_xmm_reg __fpu_ymmh4;
 struct __darwin_xmm_reg __fpu_ymmh5;
 struct __darwin_xmm_reg __fpu_ymmh6;
 struct __darwin_xmm_reg __fpu_ymmh7;
 struct __darwin_xmm_reg __fpu_ymmh8;
 struct __darwin_xmm_reg __fpu_ymmh9;
 struct __darwin_xmm_reg __fpu_ymmh10;
 struct __darwin_xmm_reg __fpu_ymmh11;
 struct __darwin_xmm_reg __fpu_ymmh12;
 struct __darwin_xmm_reg __fpu_ymmh13;
 struct __darwin_xmm_reg __fpu_ymmh14;
 struct __darwin_xmm_reg __fpu_ymmh15;
};
# 751 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_exception_state64
{
    __uint16_t __trapno;
    __uint16_t __cpu;
    __uint32_t __err;
    __uint64_t __faultvaddr;
};
# 771 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_debug_state64
{
 __uint64_t __dr0;
 __uint64_t __dr1;
 __uint64_t __dr2;
 __uint64_t __dr3;
 __uint64_t __dr4;
 __uint64_t __dr5;
 __uint64_t __dr6;
 __uint64_t __dr7;
};
# 39 "/usr/include/i386/_structs.h" 2 3 4
# 48 "/usr/include/i386/_structs.h" 3 4
struct __darwin_mcontext32
{
 struct __darwin_i386_exception_state __es;
 struct __darwin_i386_thread_state __ss;
 struct __darwin_i386_float_state __fs;
};


struct __darwin_mcontext_avx32
{
 struct __darwin_i386_exception_state __es;
 struct __darwin_i386_thread_state __ss;
 struct __darwin_i386_avx_state __fs;
};
# 86 "/usr/include/i386/_structs.h" 3 4
struct __darwin_mcontext64
{
 struct __darwin_x86_exception_state64 __es;
 struct __darwin_x86_thread_state64 __ss;
 struct __darwin_x86_float_state64 __fs;
};


struct __darwin_mcontext_avx64
{
 struct __darwin_x86_exception_state64 __es;
 struct __darwin_x86_thread_state64 __ss;
 struct __darwin_x86_avx_state64 __fs;
};
# 127 "/usr/include/i386/_structs.h" 3 4
typedef struct __darwin_mcontext64 *mcontext_t;
# 30 "/usr/include/machine/_structs.h" 2 3 4
# 58 "/usr/include/sys/_structs.h" 2 3 4
# 75 "/usr/include/sys/_structs.h" 3 4
struct __darwin_sigaltstack
{
 void *ss_sp;
 __darwin_size_t ss_size;
 int ss_flags;
};
# 128 "/usr/include/sys/_structs.h" 3 4
struct __darwin_ucontext
{
 int uc_onstack;
 __darwin_sigset_t uc_sigmask;
 struct __darwin_sigaltstack uc_stack;
 struct __darwin_ucontext *uc_link;
 __darwin_size_t uc_mcsize;
 struct __darwin_mcontext64 *uc_mcontext;



};
# 218 "/usr/include/sys/_structs.h" 3 4
typedef struct __darwin_sigaltstack stack_t;
# 227 "/usr/include/sys/_structs.h" 3 4
typedef struct __darwin_ucontext ucontext_t;
# 149 "/usr/include/sys/signal.h" 2 3 4
# 157 "/usr/include/sys/signal.h" 3 4
typedef __darwin_pthread_attr_t pthread_attr_t;




typedef __darwin_sigset_t sigset_t;
# 172 "/usr/include/sys/signal.h" 3 4
typedef __darwin_uid_t uid_t;


union sigval {

 int sival_int;
 void *sival_ptr;
};





struct sigevent {
 int sigev_notify;
 int sigev_signo;
 union sigval sigev_value;
 void (*sigev_notify_function)(union sigval);
 pthread_attr_t *sigev_notify_attributes;
};


typedef struct __siginfo {
 int si_signo;
 int si_errno;
 int si_code;
 pid_t si_pid;
 uid_t si_uid;
 int si_status;
 void *si_addr;
 union sigval si_value;
 long si_band;
 unsigned long __pad[7];
} siginfo_t;
# 286 "/usr/include/sys/signal.h" 3 4
union __sigaction_u {
 void (*__sa_handler)(int);
 void (*__sa_sigaction)(int, struct __siginfo *,
         void *);
};


struct __sigaction {
 union __sigaction_u __sigaction_u;
 void (*sa_tramp)(void *, int, int, siginfo_t *, void *);
 sigset_t sa_mask;
 int sa_flags;
};




struct sigaction {
 union __sigaction_u __sigaction_u;
 sigset_t sa_mask;
 int sa_flags;
};
# 348 "/usr/include/sys/signal.h" 3 4
typedef void (*sig_t)(int);
# 365 "/usr/include/sys/signal.h" 3 4
struct sigvec {
 void (*sv_handler)(int);
 int sv_mask;
 int sv_flags;
};
# 384 "/usr/include/sys/signal.h" 3 4
struct sigstack {
 char *ss_sp;
 int ss_onstack;
};
# 406 "/usr/include/sys/signal.h" 3 4

void (*signal(int, void (*)(int)))(int);

# 117 "/usr/include/sys/wait.h" 2 3 4
# 1 "/usr/include/sys/resource.h" 1 3 4
# 77 "/usr/include/sys/resource.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 100 "/usr/include/sys/_structs.h" 3 4
struct timeval
{
 __darwin_time_t tv_sec;
 __darwin_suseconds_t tv_usec;
};
# 78 "/usr/include/sys/resource.h" 2 3 4
# 89 "/usr/include/sys/resource.h" 3 4
typedef __uint64_t rlim_t;
# 151 "/usr/include/sys/resource.h" 3 4
struct rusage {
 struct timeval ru_utime;
 struct timeval ru_stime;
# 162 "/usr/include/sys/resource.h" 3 4
 long ru_maxrss;

 long ru_ixrss;
 long ru_idrss;
 long ru_isrss;
 long ru_minflt;
 long ru_majflt;
 long ru_nswap;
 long ru_inblock;
 long ru_oublock;
 long ru_msgsnd;
 long ru_msgrcv;
 long ru_nsignals;
 long ru_nvcsw;
 long ru_nivcsw;


};
# 222 "/usr/include/sys/resource.h" 3 4
struct rlimit {
 rlim_t rlim_cur;
 rlim_t rlim_max;
};
# 244 "/usr/include/sys/resource.h" 3 4

int getpriority(int, id_t);

int getiopolicy_np(int, int) __attribute__((visibility("default")));

int getrlimit(int, struct rlimit *) __asm("_" "getrlimit" );
int getrusage(int, struct rusage *);
int setpriority(int, id_t, int);

int setiopolicy_np(int, int, int) __attribute__((visibility("default")));

int setrlimit(int, const struct rlimit *) __asm("_" "setrlimit" );

# 118 "/usr/include/sys/wait.h" 2 3 4
# 193 "/usr/include/sys/wait.h" 3 4
# 1 "/usr/include/machine/endian.h" 1 3 4
# 35 "/usr/include/machine/endian.h" 3 4
# 1 "/usr/include/i386/endian.h" 1 3 4
# 99 "/usr/include/i386/endian.h" 3 4
# 1 "/usr/include/sys/_endian.h" 1 3 4
# 124 "/usr/include/sys/_endian.h" 3 4
# 1 "/usr/include/libkern/_OSByteOrder.h" 1 3 4
# 66 "/usr/include/libkern/_OSByteOrder.h" 3 4
# 1 "/usr/include/libkern/i386/_OSByteOrder.h" 1 3 4
# 44 "/usr/include/libkern/i386/_OSByteOrder.h" 3 4
static __inline__
__uint16_t
_OSSwapInt16(
    __uint16_t _data
)
{
    return ((_data << 8) | (_data >> 8));
}

static __inline__
__uint32_t
_OSSwapInt32(
    __uint32_t _data
)
{

    return __builtin_bswap32(_data);




}


static __inline__
__uint64_t
_OSSwapInt64(
    __uint64_t _data
)
{
    return __builtin_bswap64(_data);
}
# 67 "/usr/include/libkern/_OSByteOrder.h" 2 3 4
# 125 "/usr/include/sys/_endian.h" 2 3 4
# 100 "/usr/include/i386/endian.h" 2 3 4
# 36 "/usr/include/machine/endian.h" 2 3 4
# 194 "/usr/include/sys/wait.h" 2 3 4







union wait {
 int w_status;



 struct {

  unsigned int w_Termsig:7,
    w_Coredump:1,
    w_Retcode:8,
    w_Filler:16;







 } w_T;





 struct {

  unsigned int w_Stopval:8,
    w_Stopsig:8,
    w_Filler:16;






 } w_S;
};
# 254 "/usr/include/sys/wait.h" 3 4

pid_t wait(int *) __asm("_" "wait" );
pid_t waitpid(pid_t, int *, int) __asm("_" "waitpid" );

int waitid(idtype_t, id_t, siginfo_t *, int) __asm("_" "waitid" );


pid_t wait3(int *, int, struct rusage *);
pid_t wait4(pid_t, int *, int, struct rusage *);


# 66 "/usr/include/stdlib.h" 2 3 4

# 1 "/usr/include/alloca.h" 1 3 4
# 35 "/usr/include/alloca.h" 3 4

void *alloca(size_t);

# 68 "/usr/include/stdlib.h" 2 3 4
# 81 "/usr/include/stdlib.h" 3 4
typedef __darwin_ct_rune_t ct_rune_t;




typedef __darwin_rune_t rune_t;






typedef __darwin_wchar_t wchar_t;



typedef struct {
 int quot;
 int rem;
} div_t;

typedef struct {
 long quot;
 long rem;
} ldiv_t;


typedef struct {
 long long quot;
 long long rem;
} lldiv_t;
# 134 "/usr/include/stdlib.h" 3 4
extern int __mb_cur_max;
# 144 "/usr/include/stdlib.h" 3 4

void abort(void) __attribute__((__noreturn__));
int abs(int) __attribute__((__const__));
int atexit(void (*)(void));
double atof(const char *);
int atoi(const char *);
long atol(const char *);

long long
  atoll(const char *);

void *bsearch(const void *, const void *, size_t,
     size_t, int (*)(const void *, const void *));
void *calloc(size_t, size_t);
div_t div(int, int) __attribute__((__const__));
void exit(int) __attribute__((__noreturn__));
void free(void *);
char *getenv(const char *);
long labs(long) __attribute__((__const__));
ldiv_t ldiv(long, long) __attribute__((__const__));

long long
  llabs(long long);
lldiv_t lldiv(long long, long long);

void *malloc(size_t);
int mblen(const char *, size_t);
size_t mbstowcs(wchar_t * , const char * , size_t);
int mbtowc(wchar_t * , const char * , size_t);
int posix_memalign(void **, size_t, size_t) __attribute__((visibility("default")));
void qsort(void *, size_t, size_t,
     int (*)(const void *, const void *));
int rand(void);
void *realloc(void *, size_t);
void srand(unsigned);
double strtod(const char *, char **) __asm("_" "strtod" );
float strtof(const char *, char **) __asm("_" "strtof" );
long strtol(const char *, char **, int);
long double
  strtold(const char *, char **) ;

long long
  strtoll(const char *, char **, int);

unsigned long
  strtoul(const char *, char **, int);

unsigned long long
  strtoull(const char *, char **, int);

int system(const char *) __asm("_" "system" );
size_t wcstombs(char * , const wchar_t * , size_t);
int wctomb(char *, wchar_t);


void _Exit(int) __attribute__((__noreturn__));
long a64l(const char *);
double drand48(void);
char *ecvt(double, int, int *, int *);
double erand48(unsigned short[3]);
char *fcvt(double, int, int *, int *);
char *gcvt(double, int, char *);
int getsubopt(char **, char * const *, char **);
int grantpt(int);

char *initstate(unsigned, char *, size_t);



long jrand48(unsigned short[3]);
char *l64a(long);
void lcong48(unsigned short[7]);
long lrand48(void);
char *mktemp(char *);
int mkstemp(char *);
long mrand48(void);
long nrand48(unsigned short[3]);
int posix_openpt(int);
char *ptsname(int);
int putenv(char *) __asm("_" "putenv" );
long random(void);
int rand_r(unsigned *);

char *realpath(const char * , char * ) __asm("_" "realpath" "$DARWIN_EXTSN");



unsigned short
 *seed48(unsigned short[3]);
int setenv(const char *, const char *, int) __asm("_" "setenv" );

void setkey(const char *) __asm("_" "setkey" );



char *setstate(const char *);
void srand48(long);

void srandom(unsigned);



int unlockpt(int);

int unsetenv(const char *) __asm("_" "unsetenv" );






# 1 "/usr/include/machine/types.h" 1 3 4
# 35 "/usr/include/machine/types.h" 3 4
# 1 "/usr/include/i386/types.h" 1 3 4
# 70 "/usr/include/i386/types.h" 3 4
# 1 "/usr/include/i386/_types.h" 1 3 4
# 71 "/usr/include/i386/types.h" 2 3 4







typedef signed char int8_t;

typedef unsigned char u_int8_t;


typedef short int16_t;

typedef unsigned short u_int16_t;


typedef int int32_t;

typedef unsigned int u_int32_t;


typedef long long int64_t;

typedef unsigned long long u_int64_t;


typedef int64_t register_t;






typedef __darwin_intptr_t intptr_t;



typedef unsigned long uintptr_t;




typedef u_int64_t user_addr_t;
typedef u_int64_t user_size_t;
typedef int64_t user_ssize_t;
typedef int64_t user_long_t;
typedef u_int64_t user_ulong_t;
typedef int64_t user_time_t;
typedef int64_t user_off_t;







typedef u_int64_t syscall_arg_t;
# 36 "/usr/include/machine/types.h" 2 3 4
# 256 "/usr/include/stdlib.h" 2 3 4


typedef __darwin_dev_t dev_t;




typedef __darwin_mode_t mode_t;



u_int32_t
  arc4random(void);
void arc4random_addrandom(unsigned char * , int );
void arc4random_buf(void * , size_t ) __attribute__((visibility("default")));
void arc4random_stir(void);
u_int32_t
  arc4random_uniform(u_int32_t ) __attribute__((visibility("default")));

int atexit_b(void (^)(void)) __attribute__((visibility("default")));
void *bsearch_b(const void *, const void *, size_t,
     size_t, int (^)(const void *, const void *)) __attribute__((visibility("default")));



char *cgetcap(char *, const char *, int);
int cgetclose(void);
int cgetent(char **, char **, const char *);
int cgetfirst(char **, char **);
int cgetmatch(const char *, const char *);
int cgetnext(char **, char **);
int cgetnum(char *, const char *, long *);
int cgetset(const char *);
int cgetstr(char *, const char *, char **);
int cgetustr(char *, const char *, char **);

int daemon(int, int) __asm("_" "daemon" "$1050") __attribute__((deprecated,visibility("default")));
char *devname(dev_t, mode_t);
char *devname_r(dev_t, mode_t, char *buf, int len);
char *getbsize(int *, long *);
int getloadavg(double [], int);
const char
 *getprogname(void);

int heapsort(void *, size_t, size_t,
     int (*)(const void *, const void *));

int heapsort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

int mergesort(void *, size_t, size_t,
     int (*)(const void *, const void *));

int mergesort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void psort(void *, size_t, size_t,
     int (*)(const void *, const void *)) __attribute__((visibility("default")));

void psort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void psort_r(void *, size_t, size_t, void *,
     int (*)(void *, const void *, const void *)) __attribute__((visibility("default")));

void qsort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void qsort_r(void *, size_t, size_t, void *,
     int (*)(void *, const void *, const void *));
int radixsort(const unsigned char **, int, const unsigned char *,
     unsigned);
void setprogname(const char *);
int sradixsort(const unsigned char **, int, const unsigned char *,
     unsigned);
void sranddev(void);
void srandomdev(void);
void *reallocf(void *, size_t);

long long
  strtoq(const char *, char **, int);
unsigned long long
  strtouq(const char *, char **, int);

extern char *suboptarg;
void *valloc(size_t);







# 69 "c.h" 2
# 1 "/usr/include/string.h" 1 3 4
# 79 "/usr/include/string.h" 3 4

void *memchr(const void *, int, size_t);
int memcmp(const void *, const void *, size_t);
void *memcpy(void *, const void *, size_t);
void *memmove(void *, const void *, size_t);
void *memset(void *, int, size_t);
char *strcat(char *, const char *);
char *strchr(const char *, int);
int strcmp(const char *, const char *);
int strcoll(const char *, const char *);
char *strcpy(char *, const char *);
size_t strcspn(const char *, const char *);
char *strerror(int) __asm("_" "strerror" );
size_t strlen(const char *);
char *strncat(char *, const char *, size_t);
int strncmp(const char *, const char *, size_t);
char *strncpy(char *, const char *, size_t);
char *strpbrk(const char *, const char *);
char *strrchr(const char *, int);
size_t strspn(const char *, const char *);
char *strstr(const char *, const char *);
char *strtok(char *, const char *);
size_t strxfrm(char *, const char *, size_t);

# 113 "/usr/include/string.h" 3 4

char *strtok_r(char *, const char *, char **);

# 125 "/usr/include/string.h" 3 4

int strerror_r(int, char *, size_t);
char *strdup(const char *);
void *memccpy(void *, const void *, int, size_t);

# 139 "/usr/include/string.h" 3 4

char *stpcpy(char *, const char *);
char *stpncpy(char *, const char *, size_t) __attribute__((visibility("default")));
char *strndup(const char *, size_t) __attribute__((visibility("default")));
size_t strnlen(const char *, size_t) __attribute__((visibility("default")));
char *strsignal(int sig);

# 158 "/usr/include/string.h" 3 4

void *memmem(const void *, size_t, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern4(void *, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern8(void *, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern16(void *, const void *, size_t) __attribute__((visibility("default")));

char *strcasestr(const char *, const char *);
char *strnstr(const char *, const char *, size_t);
size_t strlcat(char *, const char *, size_t);
size_t strlcpy(char *, const char *, size_t);
void strmode(int, char *);
char *strsep(char **, const char *);


void swab(const void * , void * , ssize_t);







# 1 "/usr/include/strings.h" 1 3 4
# 71 "/usr/include/strings.h" 3 4



int bcmp(const void *, const void *, size_t) ;
void bcopy(const void *, void *, size_t) ;
void bzero(void *, size_t) ;
char *index(const char *, int) ;
char *rindex(const char *, int) ;


int ffs(int);
int strcasecmp(const char *, const char *);
int strncasecmp(const char *, const char *, size_t);





int ffsl(long) __attribute__((visibility("default")));
int fls(int) __attribute__((visibility("default")));
int flsl(long) __attribute__((visibility("default")));


# 1 "/usr/include/string.h" 1 3 4
# 95 "/usr/include/strings.h" 2 3 4
# 181 "/usr/include/string.h" 2 3 4
# 190 "/usr/include/string.h" 3 4
# 1 "/usr/include/secure/_string.h" 1 3 4
# 58 "/usr/include/secure/_string.h" 3 4
static __inline void *
__inline_memcpy_chk (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memcpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 0));
}






static __inline void *
__inline_memmove_chk (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memmove_chk (__dest, __src, __len, __builtin_object_size (__dest, 0));
}






static __inline void *
__inline_memset_chk (void *__dest, int __val, size_t __len)
{
  return __builtin___memset_chk (__dest, __val, __len, __builtin_object_size (__dest, 0));
}






static __inline char *
__inline_strcpy_chk (char * __dest, const char * __src)
{
  return __builtin___strcpy_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_stpcpy_chk (char *__dest, const char *__src)
{
  return __builtin___stpcpy_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}






static __inline char *
__inline_stpncpy_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___stpncpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_strncpy_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___strncpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}






static __inline char *
__inline_strcat_chk (char * __dest, const char * __src)
{
  return __builtin___strcat_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_strncat_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___strncat_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}
# 191 "/usr/include/string.h" 2 3 4
# 70 "c.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stddef.h" 1 3 4
# 152 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 71 "c.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stdarg.h" 1 3 4
# 43 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 72 "c.h" 2

# 1 "./strings.h" 1
char *s1,
     *s2,
     *s3,
     *s4,
     *s5,
     *s6;
# 74 "c.h" 2


# 1 "/usr/include/stdint.h" 1 3 4
# 40 "/usr/include/stdint.h" 3 4
typedef unsigned char uint8_t;




typedef unsigned short uint16_t;




typedef unsigned int uint32_t;




typedef unsigned long long uint64_t;



typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;
# 97 "/usr/include/stdint.h" 3 4
typedef long int intmax_t;
# 106 "/usr/include/stdint.h" 3 4
typedef long unsigned int uintmax_t;
# 77 "c.h" 2

# 1 "/usr/include/sys/types.h" 1 3 4
# 84 "/usr/include/sys/types.h" 3 4
typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned int u_int;

typedef unsigned long u_long;


typedef unsigned short ushort;
typedef unsigned int uint;


typedef u_int64_t u_quad_t;
typedef int64_t quad_t;
typedef quad_t * qaddr_t;

typedef char * caddr_t;
typedef int32_t daddr_t;






typedef u_int32_t fixpt_t;


typedef __darwin_blkcnt_t blkcnt_t;




typedef __darwin_blksize_t blksize_t;




typedef __darwin_gid_t gid_t;





typedef __uint32_t in_addr_t;




typedef __uint16_t in_port_t;



typedef __darwin_ino_t ino_t;





typedef __darwin_ino64_t ino64_t;






typedef __int32_t key_t;
# 157 "/usr/include/sys/types.h" 3 4
typedef __uint16_t nlink_t;
# 176 "/usr/include/sys/types.h" 3 4
typedef int32_t segsz_t;
typedef int32_t swblk_t;
# 223 "/usr/include/sys/types.h" 3 4
typedef __darwin_clock_t clock_t;
# 240 "/usr/include/sys/types.h" 3 4
typedef __darwin_time_t time_t;




typedef __darwin_useconds_t useconds_t;




typedef __darwin_suseconds_t suseconds_t;
# 260 "/usr/include/sys/types.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 183 "/usr/include/sys/_structs.h" 3 4

typedef struct fd_set {
 __int32_t fds_bits[((((1024) % ((sizeof(__int32_t) * 8))) == 0) ? ((1024) / ((sizeof(__int32_t) * 8))) : (((1024) / ((sizeof(__int32_t) * 8))) + 1))];
} fd_set;



static __inline int
__darwin_fd_isset(int _n, const struct fd_set *_p)
{
 return (_p->fds_bits[_n/(sizeof(__int32_t) * 8)] & (1<<(_n % (sizeof(__int32_t) * 8))));
}
# 261 "/usr/include/sys/types.h" 2 3 4




typedef __int32_t fd_mask;
# 322 "/usr/include/sys/types.h" 3 4
typedef __darwin_pthread_cond_t pthread_cond_t;



typedef __darwin_pthread_condattr_t pthread_condattr_t;



typedef __darwin_pthread_mutex_t pthread_mutex_t;



typedef __darwin_pthread_mutexattr_t pthread_mutexattr_t;



typedef __darwin_pthread_once_t pthread_once_t;



typedef __darwin_pthread_rwlock_t pthread_rwlock_t;



typedef __darwin_pthread_rwlockattr_t pthread_rwlockattr_t;



typedef __darwin_pthread_t pthread_t;






typedef __darwin_pthread_key_t pthread_key_t;





typedef __darwin_fsblkcnt_t fsblkcnt_t;




typedef __darwin_fsfilcnt_t fsfilcnt_t;
# 79 "c.h" 2

# 1 "/usr/include/errno.h" 1 3 4
# 23 "/usr/include/errno.h" 3 4
# 1 "/usr/include/sys/errno.h" 1 3 4
# 74 "/usr/include/sys/errno.h" 3 4

extern int * __error(void);


# 24 "/usr/include/errno.h" 2 3 4
# 81 "c.h" 2
# 91 "c.h"
# 1 "/usr/include/locale.h" 1 3 4
# 40 "/usr/include/locale.h" 3 4
# 1 "/usr/include/_locale.h" 1 3 4
# 43 "/usr/include/_locale.h" 3 4
struct lconv {
 char *decimal_point;
 char *thousands_sep;
 char *grouping;
 char *int_curr_symbol;
 char *currency_symbol;
 char *mon_decimal_point;
 char *mon_thousands_sep;
 char *mon_grouping;
 char *positive_sign;
 char *negative_sign;
 char int_frac_digits;
 char frac_digits;
 char p_cs_precedes;
 char p_sep_by_space;
 char n_cs_precedes;
 char n_sep_by_space;
 char p_sign_posn;
 char n_sign_posn;
 char int_p_cs_precedes;
 char int_n_cs_precedes;
 char int_p_sep_by_space;
 char int_n_sep_by_space;
 char int_p_sign_posn;
 char int_n_sign_posn;
};






struct lconv *localeconv(void);

# 41 "/usr/include/locale.h" 2 3 4
# 52 "/usr/include/locale.h" 3 4

char *setlocale(int, const char *);

# 92 "c.h" 2
# 181 "c.h"
typedef char bool;
# 193 "c.h"
typedef bool *BoolPtr;
# 224 "c.h"
typedef char *Pointer;
# 233 "c.h"
typedef signed char int8;
typedef signed short int16;
typedef signed int int32;
# 245 "c.h"
typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;






typedef uint8 bits8;
typedef uint16 bits16;
typedef uint32 bits32;
# 265 "c.h"
typedef long int int64;


typedef unsigned long int uint64;
# 308 "c.h"
typedef size_t Size;
# 317 "c.h"
typedef unsigned int Index;
# 327 "c.h"
typedef signed int Offset;




typedef int16 int2;
typedef int32 int4;
typedef float float4;
typedef double float8;
# 348 "c.h"
typedef Oid regproc;
typedef regproc RegProcedure;

typedef uint32 TransactionId;

typedef uint32 LocalTransactionId;

typedef uint32 SubTransactionId;





typedef TransactionId MultiXactId;

typedef uint32 MultiXactOffset;

typedef uint32 CommandId;







typedef struct
{
 int indx[6];
} IntArray;
# 391 "c.h"
struct varlena
{
 char vl_len_[4];
 char vl_dat[1];
};
# 404 "c.h"
typedef struct varlena bytea;
typedef struct varlena text;
typedef struct varlena BpChar;
typedef struct varlena VarChar;
# 419 "c.h"
typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
 int dim1;
 int lbound1;
 int2 values[1];
} int2vector;

typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
 int dim1;
 int lbound1;
 Oid values[1];
} oidvector;





typedef struct nameData
{
 char data[64];
} NameData;
typedef NameData *Name;
# 829 "c.h"
extern int fdatasync(int fildes);
# 860 "c.h"
# 1 "port.h" 1
# 16 "port.h"
# 1 "/usr/include/ctype.h" 1 3 4
# 69 "/usr/include/ctype.h" 3 4
# 1 "/usr/include/runetype.h" 1 3 4
# 70 "/usr/include/runetype.h" 3 4
typedef __darwin_wint_t wint_t;
# 81 "/usr/include/runetype.h" 3 4
typedef struct {
 __darwin_rune_t __min;
 __darwin_rune_t __max;
 __darwin_rune_t __map;
 __uint32_t *__types;
} _RuneEntry;

typedef struct {
 int __nranges;
 _RuneEntry *__ranges;
} _RuneRange;

typedef struct {
 char __name[14];
 __uint32_t __mask;
} _RuneCharClass;

typedef struct {
 char __magic[8];
 char __encoding[32];

 __darwin_rune_t (*__sgetrune)(const char *, __darwin_size_t, char const **);
 int (*__sputrune)(__darwin_rune_t, char *, __darwin_size_t, char **);
 __darwin_rune_t __invalid_rune;

 __uint32_t __runetype[(1 <<8 )];
 __darwin_rune_t __maplower[(1 <<8 )];
 __darwin_rune_t __mapupper[(1 <<8 )];






 _RuneRange __runetype_ext;
 _RuneRange __maplower_ext;
 _RuneRange __mapupper_ext;

 void *__variable;
 int __variable_len;




 int __ncharclasses;
 _RuneCharClass *__charclasses;
} _RuneLocale;




extern _RuneLocale _DefaultRuneLocale;
extern _RuneLocale *_CurrentRuneLocale;

# 70 "/usr/include/ctype.h" 2 3 4
# 145 "/usr/include/ctype.h" 3 4

unsigned long ___runetype(__darwin_ct_rune_t);
__darwin_ct_rune_t ___tolower(__darwin_ct_rune_t);
__darwin_ct_rune_t ___toupper(__darwin_ct_rune_t);


static __inline int
isascii(int _c)
{
 return ((_c & ~0x7F) == 0);
}
# 164 "/usr/include/ctype.h" 3 4

int __maskrune(__darwin_ct_rune_t, unsigned long);



static __inline int
__istype(__darwin_ct_rune_t _c, unsigned long _f)
{



 return (isascii(_c) ? !!(_DefaultRuneLocale.__runetype[_c] & _f)
  : !!__maskrune(_c, _f));

}

static __inline __darwin_ct_rune_t
__isctype(__darwin_ct_rune_t _c, unsigned long _f)
{



 return (_c < 0 || _c >= (1 <<8 )) ? 0 :
  !!(_DefaultRuneLocale.__runetype[_c] & _f);

}
# 204 "/usr/include/ctype.h" 3 4

__darwin_ct_rune_t __toupper(__darwin_ct_rune_t);
__darwin_ct_rune_t __tolower(__darwin_ct_rune_t);



static __inline int
__wcwidth(__darwin_ct_rune_t _c)
{
 unsigned int _x;

 if (_c == 0)
  return (0);
 _x = (unsigned int)__maskrune(_c, 0xe0000000L|0x00040000L);
 if ((_x & 0xe0000000L) != 0)
  return ((_x & 0xe0000000L) >> 30);
 return ((_x & 0x00040000L) != 0 ? 1 : -1);
}






static __inline int
isalnum(int _c)
{
 return (__istype(_c, 0x00000100L|0x00000400L));
}

static __inline int
isalpha(int _c)
{
 return (__istype(_c, 0x00000100L));
}

static __inline int
isblank(int _c)
{
 return (__istype(_c, 0x00020000L));
}

static __inline int
iscntrl(int _c)
{
 return (__istype(_c, 0x00000200L));
}


static __inline int
isdigit(int _c)
{
 return (__isctype(_c, 0x00000400L));
}

static __inline int
isgraph(int _c)
{
 return (__istype(_c, 0x00000800L));
}

static __inline int
islower(int _c)
{
 return (__istype(_c, 0x00001000L));
}

static __inline int
isprint(int _c)
{
 return (__istype(_c, 0x00040000L));
}

static __inline int
ispunct(int _c)
{
 return (__istype(_c, 0x00002000L));
}

static __inline int
isspace(int _c)
{
 return (__istype(_c, 0x00004000L));
}

static __inline int
isupper(int _c)
{
 return (__istype(_c, 0x00008000L));
}


static __inline int
isxdigit(int _c)
{
 return (__isctype(_c, 0x00010000L));
}

static __inline int
toascii(int _c)
{
 return (_c & 0x7F);
}

static __inline int
tolower(int _c)
{
        return (__tolower(_c));
}

static __inline int
toupper(int _c)
{
        return (__toupper(_c));
}


static __inline int
digittoint(int _c)
{
 return (__maskrune(_c, 0x0F));
}

static __inline int
ishexnumber(int _c)
{
 return (__istype(_c, 0x00010000L));
}

static __inline int
isideogram(int _c)
{
 return (__istype(_c, 0x00080000L));
}

static __inline int
isnumber(int _c)
{
 return (__istype(_c, 0x00000400L));
}

static __inline int
isphonogram(int _c)
{
 return (__istype(_c, 0x00200000L));
}

static __inline int
isrune(int _c)
{
 return (__istype(_c, 0xFFFFFFF0L));
}

static __inline int
isspecial(int _c)
{
 return (__istype(_c, 0x00100000L));
}
# 17 "port.h" 2
# 1 "./netdb.h" 1
# 18 "port.h" 2
# 1 "./pwd.h" 1
# 19 "port.h" 2



typedef int pgsocket;
# 32 "port.h"
extern bool pg_set_noblock(pgsocket sock);
extern bool pg_set_block(pgsocket sock);



extern bool has_drive_prefix(const char *filename);
extern char *first_dir_separator(const char *filename);
extern char *last_dir_separator(const char *filename);
extern char *first_path_var_separator(const char *pathlist);
extern void join_path_components(char *ret_path,
      const char *head, const char *tail);
extern void canonicalize_path(char *path);
extern void make_native_path(char *path);
extern bool path_contains_parent_reference(const char *path);
extern bool path_is_relative_and_below_cwd(const char *path);
extern bool path_is_prefix_of_path(const char *path1, const char *path2);
extern const char *get_progname(const char *argv0);
extern void get_share_path(const char *my_exec_path, char *ret_path);
extern void get_etc_path(const char *my_exec_path, char *ret_path);
extern void get_include_path(const char *my_exec_path, char *ret_path);
extern void get_pkginclude_path(const char *my_exec_path, char *ret_path);
extern void get_includeserver_path(const char *my_exec_path, char *ret_path);
extern void get_lib_path(const char *my_exec_path, char *ret_path);
extern void get_pkglib_path(const char *my_exec_path, char *ret_path);
extern void get_locale_path(const char *my_exec_path, char *ret_path);
extern void get_doc_path(const char *my_exec_path, char *ret_path);
extern void get_html_path(const char *my_exec_path, char *ret_path);
extern void get_man_path(const char *my_exec_path, char *ret_path);
extern bool get_home_path(char *ret_path);
extern void get_parent_directory(char *path);


extern char **pgfnames(const char *path);
extern void pgfnames_cleanup(char **filenames);
# 92 "port.h"
extern void set_pglocale_pgservice(const char *argv0, const char *app);


extern int find_my_exec(const char *argv0, char *retpath);
extern int find_other_exec(const char *argv0, const char *target,
    const char *versionstr, char *retpath);
# 149 "port.h"
extern void pg_usleep(long microsec);


extern int pg_strcasecmp(const char *s1, const char *s2);
extern int pg_strncasecmp(const char *s1, const char *s2, size_t n);
extern unsigned char pg_toupper(unsigned char ch);
extern unsigned char pg_tolower(unsigned char ch);
extern unsigned char pg_ascii_toupper(unsigned char ch);
extern unsigned char pg_ascii_tolower(unsigned char ch);
# 247 "port.h"
extern char *simple_prompt(const char *prompt, int maxlen, bool echo);







extern int pclose_check(FILE *stream);
# 300 "port.h"
extern bool rmtree(const char *path, bool rmtopdir);
# 372 "port.h"
extern double pg_erand48(unsigned short xseed[3]);
extern long pg_lrand48(void);
extern void pg_srand48(long seed);
# 428 "port.h"
extern char *pqStrerror(int errnum, char *strerrbuf, size_t buflen);


extern int pqGetpwuid(uid_t uid, struct passwd * resultbuf, char *buffer,
     size_t buflen, struct passwd ** result);


extern int pqGethostbyname(const char *name,
    struct hostent * resultbuf,
    char *buffer, size_t buflen,
    struct hostent ** result,
    int *herrno);

extern void pg_qsort(void *base, size_t nel, size_t elsize,
   int (*cmp) (const void *, const void *));



typedef int (*qsort_arg_comparator) (const void *a, const void *b, void *arg);

extern void qsort_arg(void *base, size_t nel, size_t elsize,
    qsort_arg_comparator cmp, void *arg);


extern int pg_get_encoding_from_locale(const char *ctype, bool write_message);


extern char *inet_net_ntop(int af, const void *src, int bits,
     char *dst, size_t size);


extern int pg_check_dir(const char *dir);


extern int pg_mkdir_p(char *path, int omode);
# 861 "c.h" 2
# 26 "postgres_fe.h" 2
# 9 "help.c" 2



# 1 "./pwd.h" 1
# 13 "help.c" 2


# 1 "./unistd.h" 1
# 16 "help.c" 2





# 1 "/usr/include/sys/ioctl.h" 1 3 4
# 72 "/usr/include/sys/ioctl.h" 3 4
# 1 "/usr/include/sys/ttycom.h" 1 3 4
# 72 "/usr/include/sys/ttycom.h" 3 4
# 1 "/usr/include/sys/ioccom.h" 1 3 4
# 73 "/usr/include/sys/ttycom.h" 2 3 4
# 83 "/usr/include/sys/ttycom.h" 3 4
struct winsize {
 unsigned short ws_row;
 unsigned short ws_col;
 unsigned short ws_xpixel;
 unsigned short ws_ypixel;
};
# 73 "/usr/include/sys/ioctl.h" 2 3 4






struct ttysize {
 unsigned short ts_lines;
 unsigned short ts_cols;
 unsigned short ts_xxx;
 unsigned short ts_yyy;
};





# 1 "/usr/include/sys/filio.h" 1 3 4
# 91 "/usr/include/sys/ioctl.h" 2 3 4
# 1 "/usr/include/sys/sockio.h" 1 3 4
# 92 "/usr/include/sys/ioctl.h" 2 3 4





int ioctl(int, unsigned long, ...);

# 22 "help.c" 2



# 1 "/usr/include/termios.h" 1 3 4
# 27 "/usr/include/termios.h" 3 4
# 1 "/usr/include/sys/termios.h" 1 3 4
# 265 "/usr/include/sys/termios.h" 3 4
typedef unsigned long tcflag_t;
typedef unsigned char cc_t;
typedef unsigned long speed_t;

struct termios {
 tcflag_t c_iflag;
 tcflag_t c_oflag;
 tcflag_t c_cflag;
 tcflag_t c_lflag;
 cc_t c_cc[20];
 speed_t c_ispeed;
 speed_t c_ospeed;
};
# 332 "/usr/include/sys/termios.h" 3 4

speed_t cfgetispeed(const struct termios *);
speed_t cfgetospeed(const struct termios *);
int cfsetispeed(struct termios *, speed_t);
int cfsetospeed(struct termios *, speed_t);
int tcgetattr(int, struct termios *);
int tcsetattr(int, int, const struct termios *);
int tcdrain(int) __asm("_" "tcdrain" );
int tcflow(int, int);
int tcflush(int, int);
int tcsendbreak(int, int);


void cfmakeraw(struct termios *);
int cfsetspeed(struct termios *, speed_t);


# 367 "/usr/include/sys/termios.h" 3 4
# 1 "/usr/include/sys/ttydefaults.h" 1 3 4
# 368 "/usr/include/sys/termios.h" 2 3 4
# 28 "/usr/include/termios.h" 2 3 4








pid_t tcgetsid(int);

# 26 "help.c" 2


# 1 "common.h" 1
# 12 "common.h"
# 1 "libpq-fe.h" 1
# 47 "libpq-fe.h"
typedef enum
{
 CONNECTION_OK,
 CONNECTION_BAD,






 CONNECTION_STARTED,
 CONNECTION_MADE,
 CONNECTION_AWAITING_RESPONSE,

 CONNECTION_AUTH_OK,

 CONNECTION_SETENV,
 CONNECTION_SSL_STARTUP,
 CONNECTION_NEEDED
} ConnStatusType;

typedef enum
{
 PGRES_POLLING_FAILED = 0,
 PGRES_POLLING_READING,
 PGRES_POLLING_WRITING,
 PGRES_POLLING_OK,
 PGRES_POLLING_ACTIVE

} PostgresPollingStatusType;

typedef enum
{
 PGRES_EMPTY_QUERY = 0,
 PGRES_COMMAND_OK,


 PGRES_TUPLES_OK,


 PGRES_COPY_OUT,
 PGRES_COPY_IN,
 PGRES_BAD_RESPONSE,

 PGRES_NONFATAL_ERROR,
 PGRES_FATAL_ERROR,
 PGRES_COPY_BOTH,
 PGRES_SINGLE_TUPLE
} ExecStatusType;

typedef enum
{
 PQTRANS_IDLE,
 PQTRANS_ACTIVE,
 PQTRANS_INTRANS,
 PQTRANS_INERROR,
 PQTRANS_UNKNOWN
} PGTransactionStatusType;

typedef enum
{
 PQERRORS_TERSE,
 PQERRORS_DEFAULT,
 PQERRORS_VERBOSE
} PGVerbosity;

typedef enum
{
 PQPING_OK,
 PQPING_REJECT,
 PQPING_NO_RESPONSE,
 PQPING_NO_ATTEMPT
} PGPing;




typedef struct pg_conn PGconn;






typedef struct pg_result PGresult;





typedef struct pg_cancel PGcancel;







typedef struct pgNotify
{
 char *relname;
 int be_pid;
 char *extra;

 struct pgNotify *next;
} PGnotify;


typedef void (*PQnoticeReceiver) (void *arg, const PGresult *res);
typedef void (*PQnoticeProcessor) (void *arg, const char *message);


typedef char pqbool;

typedef struct _PQprintOpt
{
 pqbool header;
 pqbool align;
 pqbool standard;
 pqbool html3;
 pqbool expanded;
 pqbool pager;
 char *fieldSep;
 char *tableOpt;
 char *caption;
 char **fieldName;

} PQprintOpt;
# 185 "libpq-fe.h"
typedef struct _PQconninfoOption
{
 char *keyword;
 char *envvar;
 char *compiled;
 char *val;
 char *label;
 char *dispchar;




 int dispsize;
} PQconninfoOption;





typedef struct
{
 int len;
 int isint;
 union
 {
  int *ptr;
  int integer;
 } u;
} PQArgBlock;





typedef struct pgresAttDesc
{
 char *name;
 Oid tableid;
 int columnid;
 int format;
 Oid typid;
 int typlen;
 int atttypmod;
} PGresAttDesc;
# 239 "libpq-fe.h"
extern PGconn *PQconnectStart(const char *conninfo);
extern PGconn *PQconnectStartParams(const char *const * keywords,
      const char *const * values, int expand_dbname);
extern PostgresPollingStatusType PQconnectPoll(PGconn *conn);


extern PGconn *PQconnectdb(const char *conninfo);
extern PGconn *PQconnectdbParams(const char *const * keywords,
      const char *const * values, int expand_dbname);
extern PGconn *PQsetdbLogin(const char *pghost, const char *pgport,
    const char *pgoptions, const char *pgtty,
    const char *dbName,
    const char *login, const char *pwd);





extern void PQfinish(PGconn *conn);


extern PQconninfoOption *PQconndefaults(void);


extern PQconninfoOption *PQconninfoParse(const char *conninfo, char **errmsg);


extern void PQconninfoFree(PQconninfoOption *connOptions);






extern int PQresetStart(PGconn *conn);
extern PostgresPollingStatusType PQresetPoll(PGconn *conn);


extern void PQreset(PGconn *conn);


extern PGcancel *PQgetCancel(PGconn *conn);


extern void PQfreeCancel(PGcancel *cancel);


extern int PQcancel(PGcancel *cancel, char *errbuf, int errbufsize);


extern int PQrequestCancel(PGconn *conn);


extern char *PQdb(const PGconn *conn);
extern char *PQuser(const PGconn *conn);
extern char *PQpass(const PGconn *conn);
extern char *PQhost(const PGconn *conn);
extern char *PQport(const PGconn *conn);
extern char *PQtty(const PGconn *conn);
extern char *PQoptions(const PGconn *conn);
extern ConnStatusType PQstatus(const PGconn *conn);
extern PGTransactionStatusType PQtransactionStatus(const PGconn *conn);
extern const char *PQparameterStatus(const PGconn *conn,
      const char *paramName);
extern int PQprotocolVersion(const PGconn *conn);
extern int PQserverVersion(const PGconn *conn);
extern char *PQerrorMessage(const PGconn *conn);
extern int PQsocket(const PGconn *conn);
extern int PQbackendPID(const PGconn *conn);
extern int PQconnectionNeedsPassword(const PGconn *conn);
extern int PQconnectionUsedPassword(const PGconn *conn);
extern int PQclientEncoding(const PGconn *conn);
extern int PQsetClientEncoding(PGconn *conn, const char *encoding);



extern void *PQgetssl(PGconn *conn);


extern void PQinitSSL(int do_init);


extern void PQinitOpenSSL(int do_ssl, int do_crypto);


extern PGVerbosity PQsetErrorVerbosity(PGconn *conn, PGVerbosity verbosity);


extern void PQtrace(PGconn *conn, FILE *debug_port);
extern void PQuntrace(PGconn *conn);


extern PQnoticeReceiver PQsetNoticeReceiver(PGconn *conn,
     PQnoticeReceiver proc,
     void *arg);
extern PQnoticeProcessor PQsetNoticeProcessor(PGconn *conn,
      PQnoticeProcessor proc,
      void *arg);
# 345 "libpq-fe.h"
typedef void (*pgthreadlock_t) (int acquire);

extern pgthreadlock_t PQregisterThreadLock(pgthreadlock_t newhandler);




extern PGresult *PQexec(PGconn *conn, const char *query);
extern PGresult *PQexecParams(PGconn *conn,
    const char *command,
    int nParams,
    const Oid *paramTypes,
    const char *const * paramValues,
    const int *paramLengths,
    const int *paramFormats,
    int resultFormat);
extern PGresult *PQprepare(PGconn *conn, const char *stmtName,
    const char *query, int nParams,
    const Oid *paramTypes);
extern PGresult *PQexecPrepared(PGconn *conn,
      const char *stmtName,
      int nParams,
      const char *const * paramValues,
      const int *paramLengths,
      const int *paramFormats,
      int resultFormat);


extern int PQsendQuery(PGconn *conn, const char *query);
extern int PQsendQueryParams(PGconn *conn,
      const char *command,
      int nParams,
      const Oid *paramTypes,
      const char *const * paramValues,
      const int *paramLengths,
      const int *paramFormats,
      int resultFormat);
extern int PQsendPrepare(PGconn *conn, const char *stmtName,
     const char *query, int nParams,
     const Oid *paramTypes);
extern int PQsendQueryPrepared(PGconn *conn,
     const char *stmtName,
     int nParams,
     const char *const * paramValues,
     const int *paramLengths,
     const int *paramFormats,
     int resultFormat);
extern int PQsetSingleRowMode(PGconn *conn);
extern PGresult *PQgetResult(PGconn *conn);


extern int PQisBusy(PGconn *conn);
extern int PQconsumeInput(PGconn *conn);


extern PGnotify *PQnotifies(PGconn *conn);


extern int PQputCopyData(PGconn *conn, const char *buffer, int nbytes);
extern int PQputCopyEnd(PGconn *conn, const char *errormsg);
extern int PQgetCopyData(PGconn *conn, char **buffer, int async);


extern int PQgetline(PGconn *conn, char *string, int length);
extern int PQputline(PGconn *conn, const char *string);
extern int PQgetlineAsync(PGconn *conn, char *buffer, int bufsize);
extern int PQputnbytes(PGconn *conn, const char *buffer, int nbytes);
extern int PQendcopy(PGconn *conn);


extern int PQsetnonblocking(PGconn *conn, int arg);
extern int PQisnonblocking(const PGconn *conn);
extern int PQisthreadsafe(void);
extern PGPing PQping(const char *conninfo);
extern PGPing PQpingParams(const char *const * keywords,
    const char *const * values, int expand_dbname);


extern int PQflush(PGconn *conn);





extern PGresult *PQfn(PGconn *conn,
  int fnid,
  int *result_buf,
  int *result_len,
  int result_is_int,
  const PQArgBlock *args,
  int nargs);


extern ExecStatusType PQresultStatus(const PGresult *res);
extern char *PQresStatus(ExecStatusType status);
extern char *PQresultErrorMessage(const PGresult *res);
extern char *PQresultErrorField(const PGresult *res, int fieldcode);
extern int PQntuples(const PGresult *res);
extern int PQnfields(const PGresult *res);
extern int PQbinaryTuples(const PGresult *res);
extern char *PQfname(const PGresult *res, int field_num);
extern int PQfnumber(const PGresult *res, const char *field_name);
extern Oid PQftable(const PGresult *res, int field_num);
extern int PQftablecol(const PGresult *res, int field_num);
extern int PQfformat(const PGresult *res, int field_num);
extern Oid PQftype(const PGresult *res, int field_num);
extern int PQfsize(const PGresult *res, int field_num);
extern int PQfmod(const PGresult *res, int field_num);
extern char *PQcmdStatus(PGresult *res);
extern char *PQoidStatus(const PGresult *res);
extern Oid PQoidValue(const PGresult *res);
extern char *PQcmdTuples(PGresult *res);
extern char *PQgetvalue(const PGresult *res, int tup_num, int field_num);
extern int PQgetlength(const PGresult *res, int tup_num, int field_num);
extern int PQgetisnull(const PGresult *res, int tup_num, int field_num);
extern int PQnparams(const PGresult *res);
extern Oid PQparamtype(const PGresult *res, int param_num);


extern PGresult *PQdescribePrepared(PGconn *conn, const char *stmt);
extern PGresult *PQdescribePortal(PGconn *conn, const char *portal);
extern int PQsendDescribePrepared(PGconn *conn, const char *stmt);
extern int PQsendDescribePortal(PGconn *conn, const char *portal);


extern void PQclear(PGresult *res);


extern void PQfreemem(void *ptr);
# 483 "libpq-fe.h"
extern PGresult *PQmakeEmptyPGresult(PGconn *conn, ExecStatusType status);
extern PGresult *PQcopyResult(const PGresult *src, int flags);
extern int PQsetResultAttrs(PGresult *res, int numAttributes, PGresAttDesc *attDescs);
extern void *PQresultAlloc(PGresult *res, size_t nBytes);
extern int PQsetvalue(PGresult *res, int tup_num, int field_num, char *value, int len);


extern size_t PQescapeStringConn(PGconn *conn,
       char *to, const char *from, size_t length,
       int *error);
extern char *PQescapeLiteral(PGconn *conn, const char *str, size_t len);
extern char *PQescapeIdentifier(PGconn *conn, const char *str, size_t len);
extern unsigned char *PQescapeByteaConn(PGconn *conn,
      const unsigned char *from, size_t from_length,
      size_t *to_length);
extern unsigned char *PQunescapeBytea(const unsigned char *strtext,
    size_t *retbuflen);


extern size_t PQescapeString(char *to, const char *from, size_t length);
extern unsigned char *PQescapeBytea(const unsigned char *from, size_t from_length,
     size_t *to_length);





extern void
PQprint(FILE *fout,
  const PGresult *res,
  const PQprintOpt *ps);




extern void
PQdisplayTuples(const PGresult *res,
    FILE *fp,
    int fillAlign,
    const char *fieldSep,
    int printHeader,
    int quiet);

extern void
PQprintTuples(const PGresult *res,
     FILE *fout,
     int printAttName,
     int terseOutput,
     int width);





extern int lo_open(PGconn *conn, Oid lobjId, int mode);
extern int lo_close(PGconn *conn, int fd);
extern int lo_read(PGconn *conn, int fd, char *buf, size_t len);
extern int lo_write(PGconn *conn, int fd, const char *buf, size_t len);
extern int lo_lseek(PGconn *conn, int fd, int offset, int whence);
extern Oid lo_creat(PGconn *conn, int mode);
extern Oid lo_create(PGconn *conn, Oid lobjId);
extern int lo_tell(PGconn *conn, int fd);
extern int lo_truncate(PGconn *conn, int fd, size_t len);
extern int lo_unlink(PGconn *conn, Oid lobjId);
extern Oid lo_import(PGconn *conn, const char *filename);
extern Oid lo_import_with_oid(PGconn *conn, const char *filename, Oid lobjId);
extern int lo_export(PGconn *conn, Oid lobjId, const char *filename);




extern int PQlibVersion(void);


extern int PQmblen(const char *s, int encoding);


extern int PQdsplen(const char *s, int encoding);


extern int PQenv2encoding(void);



extern char *PQencryptPassword(const char *passwd, const char *user);



extern int pg_char_to_encoding(const char *name);
extern const char *pg_encoding_to_char(int encoding);
extern int pg_valid_server_encoding_id(int encoding);
# 13 "common.h" 2
# 1 "getopt_long.h" 1
# 13 "getopt_long.h"
# 1 "/usr/include/getopt.h" 1 3 4
# 44 "/usr/include/getopt.h" 3 4
# 1 "./unistd.h" 1 3 4
# 45 "/usr/include/getopt.h" 2 3 4
# 54 "/usr/include/getopt.h" 3 4
struct option {

 const char *name;




 int has_arg;

 int *flag;

 int val;
};


int getopt_long(int, char * const *, const char *,
 const struct option *, int *);
int getopt_long_only(int, char * const *, const char *,
 const struct option *, int *);


int getopt(int, char * const [], const char *) __asm("_" "getopt" );

extern char *optarg;
extern int optind, opterr, optopt;



extern int optreset;


# 14 "getopt_long.h" 2



extern int opterr;
extern int optind;
extern int optopt;
extern char *optarg;
# 14 "common.h" 2
# 1 "pqexpbuffer.h" 1
# 44 "pqexpbuffer.h"
typedef struct PQExpBufferData
{
 char *data;
 size_t len;
 size_t maxlen;
} PQExpBufferData;

typedef PQExpBufferData *PQExpBuffer;
# 96 "pqexpbuffer.h"
extern PQExpBuffer createPQExpBuffer(void);






extern void initPQExpBuffer(PQExpBuffer str);
# 121 "pqexpbuffer.h"
extern void destroyPQExpBuffer(PQExpBuffer str);
extern void termPQExpBuffer(PQExpBuffer str);







extern void resetPQExpBuffer(PQExpBuffer str);
# 140 "pqexpbuffer.h"
extern int enlargePQExpBuffer(PQExpBuffer str, size_t needed);
# 149 "pqexpbuffer.h"
extern void
printfPQExpBuffer(PQExpBuffer str, const char *fmt,...)

__attribute__((format(printf, 2, 3)));
# 161 "pqexpbuffer.h"
extern void
appendPQExpBuffer(PQExpBuffer str, const char *fmt,...)

__attribute__((format(printf, 2, 3)));






extern void appendPQExpBufferStr(PQExpBuffer str, const char *data);






extern void appendPQExpBufferChar(PQExpBuffer str, char ch);






extern void appendBinaryPQExpBuffer(PQExpBuffer str,
      const char *data, size_t datalen);
# 15 "common.h" 2

enum trivalue
{
 TRI_DEFAULT,
 TRI_NO,
 TRI_YES
};

typedef void (*help_handler) (const char *progname);

extern const char *get_user_name(const char *progname);

extern void handle_help_version_opts(int argc, char *argv[],
       const char *fixed_progname,
       help_handler hlp);

extern PGconn *connectDatabase(const char *dbname, const char *pghost,
    const char *pgport, const char *pguser,
    enum trivalue prompt_password, const char *progname,
    bool fail_ok);

extern PGconn *connectMaintenanceDatabase(const char *maintenance_db,
      const char *pghost, const char *pgport, const char *pguser,
      enum trivalue prompt_password, const char *progname);

extern PGresult *executeQuery(PGconn *conn, const char *query,
    const char *progname, bool echo);

extern void executeCommand(PGconn *conn, const char *query,
      const char *progname, bool echo);

extern bool executeMaintenanceCommand(PGconn *conn, const char *query,
        bool echo);

extern bool yesno_prompt(const char *question);

extern void setup_cancel_handler(void);

extern char *pg_strdup(const char *string);
# 29 "help.c" 2
# 1 "help.h" 1
# 11 "help.h"
void usage(void);

void slashUsage(unsigned short int pager);

void helpSQL(const char *topic, unsigned short int pager);

void print_copyright(void);
# 30 "help.c" 2
# 1 "input.h" 1
# 21 "input.h"
# 1 "/usr/include/readline/readline.h" 1 3 4
# 40 "/usr/include/readline/readline.h" 3 4
typedef int Function(const char *, int);
typedef void VFunction(void);
typedef void VCPFunction(char *);
typedef char *CPFunction(const char *, int);
typedef char **CPPFunction(const char *, int, int);
typedef char *rl_compentry_func_t(const char *, int);
typedef int rl_command_func_t(int, int);


typedef struct {
 int length;
} HISTORY_STATE;

typedef void *histdata_t;

typedef struct _hist_entry {
 const char *line;
 histdata_t data;
} HIST_ENTRY;

typedef struct _keymap_entry {
 char type;



 Function *function;
} KEYMAP_ENTRY;



typedef KEYMAP_ENTRY KEYMAP_ENTRY_ARRAY[256];
typedef KEYMAP_ENTRY *Keymap;
# 99 "/usr/include/readline/readline.h" 3 4
extern const char *rl_library_version;
extern int rl_readline_version;
extern char *rl_readline_name;
extern FILE *rl_instream;
extern FILE *rl_outstream;
extern char *rl_line_buffer;
extern int rl_point, rl_end;
extern int history_base, history_length;
extern int max_input_history;
extern char *rl_basic_word_break_characters;
extern char *rl_completer_word_break_characters;
extern char *rl_completer_quote_characters;
extern Function *rl_completion_entry_function;
extern CPPFunction *rl_attempted_completion_function;
extern int rl_attempted_completion_over;
extern int rl_completion_type;
extern int rl_completion_query_items;
extern char *rl_special_prefixes;
extern int rl_completion_append_character;
extern int rl_inhibit_completion;
extern Function *rl_pre_input_hook;
extern Function *rl_startup_hook;
extern char *rl_terminal_name;
extern int rl_already_prompted;
extern char *rl_prompt;



extern KEYMAP_ENTRY_ARRAY emacs_standard_keymap,
   emacs_meta_keymap,
   emacs_ctlx_keymap;
extern int rl_filename_completion_desired;
extern int rl_ignore_completion_duplicates;
extern int (*rl_getc_function)(FILE *);
extern VFunction *rl_redisplay_function;
extern VFunction *rl_completion_display_matches_hook;
extern VFunction *rl_prep_term_function;
extern VFunction *rl_deprep_term_function;
extern int readline_echoing_p;
extern int _rl_print_completions_horizontally;


char *readline(const char *);
int rl_initialize(void);

void using_history(void);
int add_history(const char *);
void clear_history(void);
void stifle_history(int);
int unstifle_history(void);
int history_is_stifled(void);
int where_history(void);
HIST_ENTRY *current_history(void);
HIST_ENTRY *history_get(int);
HIST_ENTRY *remove_history(int);

HIST_ENTRY *replace_history_entry(int, const char *, histdata_t);
int history_total_bytes(void);
int history_set_pos(int);
HIST_ENTRY *previous_history(void);
HIST_ENTRY *next_history(void);
int history_search(const char *, int);
int history_search_prefix(const char *, int);
int history_search_pos(const char *, int, int);
int read_history(const char *);
int write_history(const char *);
int history_truncate_file (const char *, int);
int history_expand(char *, char **);
char **history_tokenize(const char *);
const char *get_history_event(const char *, int *, int);
char *history_arg_extract(int, int, const char *);

char *tilde_expand(char *);
char *filename_completion_function(const char *, int);
char *username_completion_function(const char *, int);
int rl_complete(int, int);
int rl_read_key(void);
char **completion_matches(const char *, CPFunction *);
void rl_display_match_list(char **, int, int);

int rl_insert(int, int);
int rl_insert_text(const char *);
void rl_reset_terminal(const char *);
int rl_bind_key(int, rl_command_func_t *);
int rl_newline(int, int);
void rl_callback_read_char(void);
void rl_callback_handler_install(const char *, VCPFunction *);
void rl_callback_handler_remove(void);
void rl_redisplay(void);
int rl_get_previous_history(int, int);
void rl_prep_terminal(int);
void rl_deprep_terminal(void);
int rl_read_init_file(const char *);
int rl_parse_and_bind(const char *);
int rl_variable_bind(const char *, const char *);
void rl_stuff_char(int);
int rl_add_defun(const char *, Function *, int);
HISTORY_STATE *history_get_history_state(void);
void rl_get_screen_size(int *, int *);
void rl_set_screen_size(int, int);
char *rl_filename_completion_function (const char *, int);
int _rl_abort_internal(void);
int _rl_qsort_string_compare(char **, char **);
char **rl_completion_matches(const char *, rl_compentry_func_t *);
void rl_forced_update_display(void);
int rl_set_prompt(const char *);




int rl_kill_text(int, int);
Keymap rl_get_keymap(void);
void rl_set_keymap(Keymap);
Keymap rl_make_bare_keymap(void);
int rl_generic_bind(int, const char *, const char *, Keymap);
int rl_bind_key_in_map(int, rl_command_func_t *, Keymap);
void rl_cleanup_after_signal(void);
void rl_free_line_state(void);
# 22 "input.h" 2

# 1 "/usr/include/readline/history.h" 1 3 4
# 24 "input.h" 2
# 41 "input.h"
char *gets_interactive(const char *prompt);
char *gets_fromFile(FILE *source);

void initializeInput(int flags);
bool saveHistory(char *fname, int max_lines, bool appendFlag, bool encodeFlag);

void pg_append_history(const char *s, PQExpBuffer history_buf);
void pg_send_history(PQExpBuffer history_buf);
# 31 "help.c" 2
# 1 "settings.h" 1
# 12 "settings.h"
# 1 "variables.h" 1
# 23 "variables.h"
typedef void (*VariableAssignHook) (const char *newval);

struct _variable
{
 char *name;
 char *value;
 VariableAssignHook assign_hook;
 struct _variable *next;
};

typedef struct _variable *VariableSpace;

VariableSpace CreateVariableSpace(void);
const char *GetVariable(VariableSpace space, const char *name);

bool ParseVariableBool(const char *val);
int ParseVariableNum(const char *val,
     int defaultval,
     int faultval,
     bool allowtrail);
int GetVariableNum(VariableSpace space,
      const char *name,
      int defaultval,
      int faultval,
      bool allowtrail);

void PrintVariables(VariableSpace space);

bool SetVariable(VariableSpace space, const char *name, const char *value);
bool SetVariableAssignHook(VariableSpace space, const char *name, VariableAssignHook hook);
bool SetVariableBool(VariableSpace space, const char *name);
bool DeleteVariable(VariableSpace space, const char *name);
# 13 "settings.h" 2
# 1 "print.h" 1
# 17 "print.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h"
typedef int16 AttrNumber;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/genbki.h" 1
# 49 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/genbki.h"
typedef int aclitem;
typedef int pg_node_tree;
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h" 2
# 36 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
typedef struct FormData_pg_attribute
{
 Oid attrelid;
 NameData attname;
# 48 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 Oid atttypid;
# 57 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int4 attstattarget;





 int2 attlen;
# 78 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int2 attnum;





 int4 attndims;
# 93 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int4 attcacheoff;







 int4 atttypmod;





 bool attbyval;
# 122 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 char attstorage;





 char attalign;


 bool attnotnull;


 bool atthasdef;


 bool attisdropped;


 bool attislocal;


 int4 attinhcount;


 Oid attcollation;
# 160 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
} FormData_pg_attribute;
# 176 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
typedef FormData_pg_attribute *Form_pg_attribute;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 1
# 40 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h" 1
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum NodeTag
{
 T_Invalid = 0,




 T_IndexInfo = 10,
 T_ExprContext,
 T_ProjectionInfo,
 T_JunkFilter,
 T_ResultRelInfo,
 T_EState,
 T_TupleTableSlot,




 T_Plan = 100,
 T_Result,
 T_ModifyTable,
 T_Append,
 T_MergeAppend,
 T_RecursiveUnion,
 T_BitmapAnd,
 T_BitmapOr,
 T_Scan,
 T_SeqScan,
 T_IndexScan,
 T_IndexOnlyScan,
 T_BitmapIndexScan,
 T_BitmapHeapScan,
 T_TidScan,
 T_SubqueryScan,
 T_FunctionScan,
 T_ValuesScan,
 T_CteScan,
 T_WorkTableScan,
 T_ForeignScan,
 T_Join,
 T_NestLoop,
 T_MergeJoin,
 T_HashJoin,
 T_Material,
 T_Sort,
 T_Group,
 T_Agg,
 T_WindowAgg,
 T_Unique,
 T_Hash,
 T_SetOp,
 T_LockRows,
 T_Limit,

 T_NestLoopParam,
 T_PlanRowMark,
 T_PlanInvalItem,






 T_PlanState = 200,
 T_ResultState,
 T_ModifyTableState,
 T_AppendState,
 T_MergeAppendState,
 T_RecursiveUnionState,
 T_BitmapAndState,
 T_BitmapOrState,
 T_ScanState,
 T_SeqScanState,
 T_IndexScanState,
 T_IndexOnlyScanState,
 T_BitmapIndexScanState,
 T_BitmapHeapScanState,
 T_TidScanState,
 T_SubqueryScanState,
 T_FunctionScanState,
 T_ValuesScanState,
 T_CteScanState,
 T_WorkTableScanState,
 T_ForeignScanState,
 T_JoinState,
 T_NestLoopState,
 T_MergeJoinState,
 T_HashJoinState,
 T_MaterialState,
 T_SortState,
 T_GroupState,
 T_AggState,
 T_WindowAggState,
 T_UniqueState,
 T_HashState,
 T_SetOpState,
 T_LockRowsState,
 T_LimitState,




 T_Alias = 300,
 T_RangeVar,
 T_Expr,
 T_Var,
 T_Const,
 T_Param,
 T_Aggref,
 T_WindowFunc,
 T_ArrayRef,
 T_FuncExpr,
 T_NamedArgExpr,
 T_OpExpr,
 T_DistinctExpr,
 T_NullIfExpr,
 T_ScalarArrayOpExpr,
 T_BoolExpr,
 T_SubLink,
 T_SubPlan,
 T_AlternativeSubPlan,
 T_FieldSelect,
 T_FieldStore,
 T_RelabelType,
 T_CoerceViaIO,
 T_ArrayCoerceExpr,
 T_ConvertRowtypeExpr,
 T_CollateExpr,
 T_CaseExpr,
 T_CaseWhen,
 T_CaseTestExpr,
 T_ArrayExpr,
 T_RowExpr,
 T_RowCompareExpr,
 T_CoalesceExpr,
 T_MinMaxExpr,
 T_XmlExpr,
 T_NullTest,
 T_BooleanTest,
 T_CoerceToDomain,
 T_CoerceToDomainValue,
 T_SetToDefault,
 T_CurrentOfExpr,
 T_TargetEntry,
 T_RangeTblRef,
 T_JoinExpr,
 T_FromExpr,
 T_IntoClause,







 T_ExprState = 400,
 T_GenericExprState,
 T_AggrefExprState,
 T_WindowFuncExprState,
 T_ArrayRefExprState,
 T_FuncExprState,
 T_ScalarArrayOpExprState,
 T_BoolExprState,
 T_SubPlanState,
 T_AlternativeSubPlanState,
 T_FieldSelectState,
 T_FieldStoreState,
 T_CoerceViaIOState,
 T_ArrayCoerceExprState,
 T_ConvertRowtypeExprState,
 T_CaseExprState,
 T_CaseWhenState,
 T_ArrayExprState,
 T_RowExprState,
 T_RowCompareExprState,
 T_CoalesceExprState,
 T_MinMaxExprState,
 T_XmlExprState,
 T_NullTestState,
 T_CoerceToDomainState,
 T_DomainConstraintState,
 T_WholeRowVarExprState,




 T_PlannerInfo = 500,
 T_PlannerGlobal,
 T_RelOptInfo,
 T_IndexOptInfo,
 T_ParamPathInfo,
 T_Path,
 T_IndexPath,
 T_BitmapHeapPath,
 T_BitmapAndPath,
 T_BitmapOrPath,
 T_NestPath,
 T_MergePath,
 T_HashPath,
 T_TidPath,
 T_ForeignPath,
 T_AppendPath,
 T_MergeAppendPath,
 T_ResultPath,
 T_MaterialPath,
 T_UniquePath,
 T_EquivalenceClass,
 T_EquivalenceMember,
 T_PathKey,
 T_RestrictInfo,
 T_PlaceHolderVar,
 T_SpecialJoinInfo,
 T_AppendRelInfo,
 T_PlaceHolderInfo,
 T_MinMaxAggInfo,
 T_PlannerParamItem,




 T_MemoryContext = 600,
 T_AllocSetContext,




 T_Value = 650,
 T_Integer,
 T_Float,
 T_String,
 T_BitString,
 T_Null,




 T_List,
 T_IntList,
 T_OidList,




 T_Query = 700,
 T_PlannedStmt,
 T_InsertStmt,
 T_DeleteStmt,
 T_UpdateStmt,
 T_SelectStmt,
 T_AlterTableStmt,
 T_AlterTableCmd,
 T_AlterDomainStmt,
 T_SetOperationStmt,
 T_GrantStmt,
 T_GrantRoleStmt,
 T_AlterDefaultPrivilegesStmt,
 T_ClosePortalStmt,
 T_ClusterStmt,
 T_CopyStmt,
 T_CreateStmt,
 T_DefineStmt,
 T_DropStmt,
 T_TruncateStmt,
 T_CommentStmt,
 T_FetchStmt,
 T_IndexStmt,
 T_CreateFunctionStmt,
 T_AlterFunctionStmt,
 T_DoStmt,
 T_RenameStmt,
 T_RuleStmt,
 T_NotifyStmt,
 T_ListenStmt,
 T_UnlistenStmt,
 T_TransactionStmt,
 T_ViewStmt,
 T_LoadStmt,
 T_CreateDomainStmt,
 T_CreatedbStmt,
 T_DropdbStmt,
 T_VacuumStmt,
 T_ExplainStmt,
 T_CreateTableAsStmt,
 T_CreateSeqStmt,
 T_AlterSeqStmt,
 T_VariableSetStmt,
 T_VariableShowStmt,
 T_DiscardStmt,
 T_CreateTrigStmt,
 T_CreatePLangStmt,
 T_CreateRoleStmt,
 T_AlterRoleStmt,
 T_DropRoleStmt,
 T_LockStmt,
 T_ConstraintsSetStmt,
 T_ReindexStmt,
 T_CheckPointStmt,
 T_CreateSchemaStmt,
 T_AlterDatabaseStmt,
 T_AlterDatabaseSetStmt,
 T_AlterRoleSetStmt,
 T_CreateConversionStmt,
 T_CreateCastStmt,
 T_CreateOpClassStmt,
 T_CreateOpFamilyStmt,
 T_AlterOpFamilyStmt,
 T_PrepareStmt,
 T_ExecuteStmt,
 T_DeallocateStmt,
 T_DeclareCursorStmt,
 T_CreateTableSpaceStmt,
 T_DropTableSpaceStmt,
 T_AlterObjectSchemaStmt,
 T_AlterOwnerStmt,
 T_DropOwnedStmt,
 T_ReassignOwnedStmt,
 T_CompositeTypeStmt,
 T_CreateEnumStmt,
 T_CreateRangeStmt,
 T_AlterEnumStmt,
 T_AlterTSDictionaryStmt,
 T_AlterTSConfigurationStmt,
 T_CreateFdwStmt,
 T_AlterFdwStmt,
 T_CreateForeignServerStmt,
 T_AlterForeignServerStmt,
 T_CreateUserMappingStmt,
 T_AlterUserMappingStmt,
 T_DropUserMappingStmt,
 T_AlterTableSpaceOptionsStmt,
 T_SecLabelStmt,
 T_CreateForeignTableStmt,
 T_CreateExtensionStmt,
 T_AlterExtensionStmt,
 T_AlterExtensionContentsStmt,




 T_A_Expr = 900,
 T_ColumnRef,
 T_ParamRef,
 T_A_Const,
 T_FuncCall,
 T_A_Star,
 T_A_Indices,
 T_A_Indirection,
 T_A_ArrayExpr,
 T_ResTarget,
 T_TypeCast,
 T_CollateClause,
 T_SortBy,
 T_WindowDef,
 T_RangeSubselect,
 T_RangeFunction,
 T_TypeName,
 T_ColumnDef,
 T_IndexElem,
 T_Constraint,
 T_DefElem,
 T_RangeTblEntry,
 T_SortGroupClause,
 T_WindowClause,
 T_PrivGrantee,
 T_FuncWithArgs,
 T_AccessPriv,
 T_CreateOpClassItem,
 T_TableLikeClause,
 T_FunctionParameter,
 T_LockingClause,
 T_RowMarkClause,
 T_XmlSerialize,
 T_WithClause,
 T_CommonTableExpr,




 T_IdentifySystemCmd,
 T_BaseBackupCmd,
 T_StartReplicationCmd,
# 416 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
 T_TriggerData = 950,
 T_ReturnSetInfo,
 T_WindowObjectData,
 T_TIDBitmap,
 T_InlineCodeBlock,
 T_FdwRoutine
} NodeTag;







typedef struct Node
{
 NodeTag type;
} Node;
# 491 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
extern char *nodeToString(const void *obj);




extern void *stringToNode(char *str);




extern void *copyObject(const void *obj);




extern bool equal(const void *a, const void *b);
# 517 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef double Selectivity;
typedef double Cost;
# 527 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum CmdType
{
 CMD_UNKNOWN,
 CMD_SELECT,
 CMD_UPDATE,
 CMD_INSERT,
 CMD_DELETE,
 CMD_UTILITY,

 CMD_NOTHING

} CmdType;
# 551 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum JoinType
{




 JOIN_INNER,
 JOIN_LEFT,
 JOIN_FULL,
 JOIN_RIGHT,
# 571 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
 JOIN_SEMI,
 JOIN_ANTI,





 JOIN_UNIQUE_OUTER,
 JOIN_UNIQUE_INNER




} JoinType;
# 41 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 2


typedef struct ListCell ListCell;

typedef struct List
{
 NodeTag type;
 int length;
 ListCell *head;
 ListCell *tail;
} List;

struct ListCell
{
 union
 {
  void *ptr_value;
  int int_value;
  Oid oid_value;
 } data;
 ListCell *next;
};
# 79 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
static inline ListCell *
list_head(const List *l)
{
 return l ? l->head : ((void *)0);
}

static inline ListCell *
list_tail(List *l)
{
 return l ? l->tail : ((void *)0);
}

static inline int
list_length(const List *l)
{
 return l ? l->length : 0;
}
# 194 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
extern List *lappend(List *list, void *datum);
extern List *lappend_int(List *list, int datum);
extern List *lappend_oid(List *list, Oid datum);

extern ListCell *lappend_cell(List *list, ListCell *prev, void *datum);
extern ListCell *lappend_cell_int(List *list, ListCell *prev, int datum);
extern ListCell *lappend_cell_oid(List *list, ListCell *prev, Oid datum);

extern List *lcons(void *datum, List *list);
extern List *lcons_int(int datum, List *list);
extern List *lcons_oid(Oid datum, List *list);

extern List *list_concat(List *list1, List *list2);
extern List *list_truncate(List *list, int new_size);

extern void *list_nth(const List *list, int n);
extern int list_nth_int(const List *list, int n);
extern Oid list_nth_oid(const List *list, int n);

extern bool list_member(const List *list, const void *datum);
extern bool list_member_ptr(const List *list, const void *datum);
extern bool list_member_int(const List *list, int datum);
extern bool list_member_oid(const List *list, Oid datum);

extern List *list_delete(List *list, void *datum);
extern List *list_delete_ptr(List *list, void *datum);
extern List *list_delete_int(List *list, int datum);
extern List *list_delete_oid(List *list, Oid datum);
extern List *list_delete_first(List *list);
extern List *list_delete_cell(List *list, ListCell *cell, ListCell *prev);

extern List *list_union(const List *list1, const List *list2);
extern List *list_union_ptr(const List *list1, const List *list2);
extern List *list_union_int(const List *list1, const List *list2);
extern List *list_union_oid(const List *list1, const List *list2);

extern List *list_intersection(const List *list1, const List *list2);



extern List *list_difference(const List *list1, const List *list2);
extern List *list_difference_ptr(const List *list1, const List *list2);
extern List *list_difference_int(const List *list1, const List *list2);
extern List *list_difference_oid(const List *list1, const List *list2);

extern List *list_append_unique(List *list, void *datum);
extern List *list_append_unique_ptr(List *list, void *datum);
extern List *list_append_unique_int(List *list, int datum);
extern List *list_append_unique_oid(List *list, Oid datum);

extern List *list_concat_unique(List *list1, List *list2);
extern List *list_concat_unique_ptr(List *list1, List *list2);
extern List *list_concat_unique_int(List *list1, List *list2);
extern List *list_concat_unique_oid(List *list1, List *list2);

extern void list_free(List *list);
extern void list_free_deep(List *list);

extern List *list_copy(const List *list);
extern List *list_copy_tail(const List *list, int nskip);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 2


typedef struct attrDefault
{
 AttrNumber adnum;
 char *adbin;
} AttrDefault;

typedef struct constrCheck
{
 char *ccname;
 char *ccbin;
 bool ccvalid;
 bool ccnoinherit;
} ConstrCheck;


typedef struct tupleConstr
{
 AttrDefault *defval;
 ConstrCheck *check;
 uint16 num_defval;
 uint16 num_check;
 bool has_not_null;
} TupleConstr;
# 71 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
typedef struct tupleDesc
{
 int natts;
 Form_pg_attribute *attrs;

 TupleConstr *constr;
 Oid tdtypeid;
 int32 tdtypmod;
 bool tdhasoid;
 int tdrefcount;
} *TupleDesc;


extern TupleDesc CreateTemplateTupleDesc(int natts, bool hasoid);

extern TupleDesc CreateTupleDesc(int natts, bool hasoid,
    Form_pg_attribute *attrs);

extern TupleDesc CreateTupleDescCopy(TupleDesc tupdesc);

extern TupleDesc CreateTupleDescCopyConstr(TupleDesc tupdesc);

extern void FreeTupleDesc(TupleDesc tupdesc);

extern void IncrTupleDescRefCount(TupleDesc tupdesc);
extern void DecrTupleDescRefCount(TupleDesc tupdesc);
# 110 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
extern bool equalTupleDescs(TupleDesc tupdesc1, TupleDesc tupdesc2);

extern void TupleDescInitEntry(TupleDesc desc,
       AttrNumber attributeNumber,
       const char *attributeName,
       Oid oidtypeid,
       int32 typmod,
       int attdim);

extern void TupleDescInitEntryCollation(TupleDesc desc,
       AttrNumber attributeNumber,
       Oid collationid);

extern TupleDesc BuildDescForRelation(List *schema);

extern TupleDesc BuildDescFromLists(List *names, List *types, List *typmods, List *collations);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupmacs.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h" 1
# 15 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
# 1 "/usr/include/fcntl.h" 1 3 4
# 23 "/usr/include/fcntl.h" 3 4
# 1 "/usr/include/sys/fcntl.h" 1 3 4
# 339 "/usr/include/sys/fcntl.h" 3 4
struct flock {
 off_t l_start;
 off_t l_len;
 pid_t l_pid;
 short l_type;
 short l_whence;
};
# 355 "/usr/include/sys/fcntl.h" 3 4
struct radvisory {
       off_t ra_offset;
       int ra_count;
};
# 367 "/usr/include/sys/fcntl.h" 3 4
typedef struct fsignatures {
 off_t fs_file_start;
 void *fs_blob_start;
 size_t fs_blob_size;
} fsignatures_t;
# 381 "/usr/include/sys/fcntl.h" 3 4
typedef struct fstore {
 unsigned int fst_flags;
 int fst_posmode;
 off_t fst_offset;
 off_t fst_length;
 off_t fst_bytesalloc;
} fstore_t;



typedef struct fbootstraptransfer {
  off_t fbt_offset;
  size_t fbt_length;
  void *fbt_buffer;
} fbootstraptransfer_t;
# 419 "/usr/include/sys/fcntl.h" 3 4
#pragma pack(4)

struct log2phys {
 unsigned int l2p_flags;
 off_t l2p_contigbytes;


 off_t l2p_devoffset;


};

#pragma pack()
# 442 "/usr/include/sys/fcntl.h" 3 4
struct _filesec;
typedef struct _filesec *filesec_t;


typedef enum {
 FILESEC_OWNER = 1,
 FILESEC_GROUP = 2,
 FILESEC_UUID = 3,
 FILESEC_MODE = 4,
 FILESEC_ACL = 5,
 FILESEC_GRPUUID = 6,


 FILESEC_ACL_RAW = 100,
 FILESEC_ACL_ALLOCSIZE = 101
} filesec_property_t;






int open(const char *, int, ...) __asm("_" "open" );
int creat(const char *, mode_t) __asm("_" "creat" );
int fcntl(int, int, ...) __asm("_" "fcntl" );


int openx_np(const char *, int, filesec_t);
int flock(int, int);
filesec_t filesec_init(void);
filesec_t filesec_dup(filesec_t);
void filesec_free(filesec_t);
int filesec_get_property(filesec_t, filesec_property_t, void *);
int filesec_query_property(filesec_t, filesec_property_t, int *);
int filesec_set_property(filesec_t, filesec_property_t, const void *);
int filesec_unset_property(filesec_t, filesec_property_t) __attribute__((visibility("default")));




# 23 "/usr/include/fcntl.h" 2 3 4
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h" 2
# 32 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
typedef struct XLogRecPtr
{
 uint32 xlogid;
 uint32 xrecoff;
} XLogRecPtr;
# 84 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
typedef uint32 TimeLineID;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/item.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/item.h"
typedef Pointer Item;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h"
typedef struct ItemIdData
{
 unsigned lp_off:15,
    lp_flags:2,
    lp_len:15;
} ItemIdData;

typedef ItemIdData *ItemId;
# 46 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h"
typedef uint16 ItemOffset;
typedef uint16 ItemLength;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h" 2






typedef uint16 OffsetNumber;
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 2
# 73 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef Pointer Page;
# 82 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef uint16 LocationIndex;
# 122 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef struct PageHeaderData
{

 XLogRecPtr pd_lsn;

 uint16 pd_tli;

 uint16 pd_flags;
 LocationIndex pd_lower;
 LocationIndex pd_upper;
 LocationIndex pd_special;
 uint16 pd_pagesize_version;
 TransactionId pd_prune_xid;
 ItemIdData pd_linp[1];
} PageHeaderData;

typedef PageHeaderData *PageHeader;
# 370 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
extern void PageInit(Page page, Size pageSize, Size specialSize);
extern bool PageHeaderIsValid(PageHeader page);
extern OffsetNumber PageAddItem(Page page, Item item, Size size,
   OffsetNumber offsetNumber, bool overwrite, bool is_heap);
extern Page PageGetTempPage(Page page);
extern Page PageGetTempPageCopy(Page page);
extern Page PageGetTempPageCopySpecial(Page page);
extern void PageRestoreTempPage(Page tempPage, Page oldPage);
extern void PageRepairFragmentation(Page page);
extern Size PageGetFreeSpace(Page page);
extern Size PageGetExactFreeSpace(Page page);
extern Size PageGetHeapFreeSpace(Page page);
extern void PageIndexTupleDelete(Page page, OffsetNumber offset);
extern void PageIndexMultiDelete(Page page, OffsetNumber *itemnos, int nitems);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h" 1
# 31 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h"
typedef uint32 BlockNumber;
# 53 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h"
typedef struct BlockIdData
{
 uint16 bi_hi;
 uint16 bi_lo;
} BlockIdData;

typedef BlockIdData *BlockId;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h" 2
# 37 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
typedef struct ItemPointerData
{
 BlockIdData ip_blkid;
 OffsetNumber ip_posid;
}




ItemPointerData;




typedef ItemPointerData *ItemPointer;
# 143 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
extern bool ItemPointerEquals(ItemPointer pointer1, ItemPointer pointer2);
extern int32 ItemPointerCompare(ItemPointer arg1, ItemPointer arg2);
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/backendid.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/backendid.h"
typedef int BackendId;



extern BackendId MyBackendId;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h" 2







typedef enum ForkNumber
{
 InvalidForkNumber = -1,
 MAIN_FORKNUM = 0,
 FSM_FORKNUM,
 VISIBILITYMAP_FORKNUM,
 INIT_FORKNUM





} ForkNumber;
# 77 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
typedef struct RelFileNode
{
 Oid spcNode;
 Oid dbNode;
 Oid relNode;
} RelFileNode;
# 92 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
typedef struct RelFileNodeBackend
{
 RelFileNode node;
 BackendId backend;
} RelFileNodeBackend;
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 107 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct HeapTupleFields
{
 TransactionId t_xmin;
 TransactionId t_xmax;

 union
 {
  CommandId t_cid;
  TransactionId t_xvac;
 } t_field3;
} HeapTupleFields;

typedef struct DatumTupleFields
{
 int32 datum_len_;

 int32 datum_typmod;

 Oid datum_typeid;





} DatumTupleFields;

typedef struct HeapTupleHeaderData
{
 union
 {
  HeapTupleFields t_heap;
  DatumTupleFields t_datum;
 } t_choice;

 ItemPointerData t_ctid;



 uint16 t_infomask2;

 uint16 t_infomask;

 uint8 t_hoff;



 bits8 t_bits[1];


} HeapTupleHeaderData;

typedef HeapTupleHeaderData *HeapTupleHeader;
# 461 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct MinimalTupleData
{
 uint32 t_len;

 char mt_padding[((__builtin_offsetof (HeapTupleHeaderData, t_infomask2) - sizeof(uint32)) % 8)];



 uint16 t_infomask2;

 uint16 t_infomask;

 uint8 t_hoff;



 bits8 t_bits[1];


} MinimalTupleData;

typedef MinimalTupleData *MinimalTuple;
# 517 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct HeapTupleData
{
 uint32 t_len;
 ItemPointerData t_self;
 Oid t_tableOid;
 HeapTupleHeader t_data;
} HeapTupleData;

typedef HeapTupleData *HeapTuple;
# 621 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heaptid
{
 RelFileNode node;
 ItemPointerData tid;
} xl_heaptid;




typedef struct xl_heap_delete
{
 xl_heaptid target;
 bool all_visible_cleared;
} xl_heap_delete;
# 646 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_header
{
 uint16 t_infomask2;
 uint16 t_infomask;
 uint8 t_hoff;
} xl_heap_header;




typedef struct xl_heap_insert
{
 xl_heaptid target;
 bool all_visible_cleared;

} xl_heap_insert;
# 671 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_multi_insert
{
 RelFileNode node;
 BlockNumber blkno;
 bool all_visible_cleared;
 uint16 ntuples;
 OffsetNumber offsets[1];


} xl_heap_multi_insert;



typedef struct xl_multi_insert_tuple
{
 uint16 datalen;
 uint16 t_infomask2;
 uint16 t_infomask;
 uint8 t_hoff;

} xl_multi_insert_tuple;




typedef struct xl_heap_update
{
 xl_heaptid target;
 ItemPointerData newtid;
 bool all_visible_cleared;
 bool new_all_visible_cleared;

} xl_heap_update;
# 718 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_clean
{
 RelFileNode node;
 BlockNumber block;
 TransactionId latestRemovedXid;
 uint16 nredirected;
 uint16 ndead;

} xl_heap_clean;
# 735 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_cleanup_info
{
 RelFileNode node;
 TransactionId latestRemovedXid;
} xl_heap_cleanup_info;





typedef struct xl_heap_newpage
{
 RelFileNode node;
 ForkNumber forknum;
 BlockNumber blkno;

} xl_heap_newpage;




typedef struct xl_heap_lock
{
 xl_heaptid target;
 TransactionId locking_xid;
 bool xid_is_mxact;
 bool shared_lock;
} xl_heap_lock;




typedef struct xl_heap_inplace
{
 xl_heaptid target;

} xl_heap_inplace;




typedef struct xl_heap_freeze
{
 RelFileNode node;
 BlockNumber block;
 TransactionId cutoff_xid;

} xl_heap_freeze;




typedef struct xl_heap_visible
{
 RelFileNode node;
 BlockNumber block;
 TransactionId cutoff_xid;
} xl_heap_visible;



extern void HeapTupleHeaderAdvanceLatestRemovedXid(HeapTupleHeader tuple,
            TransactionId *latestRemovedXid);


extern CommandId HeapTupleHeaderGetCmin(HeapTupleHeader tup);
extern CommandId HeapTupleHeaderGetCmax(HeapTupleHeader tup);
extern void HeapTupleHeaderAdjustCmax(HeapTupleHeader tup,
        CommandId *cmax,
        bool *iscombo);
# 890 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
extern Size heap_compute_data_size(TupleDesc tupleDesc,
        Datum *values, bool *isnull);
extern void heap_fill_tuple(TupleDesc tupleDesc,
    Datum *values, bool *isnull,
    char *data, Size data_size,
    uint16 *infomask, bits8 *bit);
extern bool heap_attisnull(HeapTuple tup, int attnum);
extern Datum nocachegetattr(HeapTuple tup, int attnum,
      TupleDesc att);
extern Datum heap_getsysattr(HeapTuple tup, int attnum, TupleDesc tupleDesc,
    bool *isnull);
extern HeapTuple heap_copytuple(HeapTuple tuple);
extern void heap_copytuple_with_tuple(HeapTuple src, HeapTuple dest);
extern HeapTuple heap_form_tuple(TupleDesc tupleDescriptor,
    Datum *values, bool *isnull);
extern HeapTuple heap_modify_tuple(HeapTuple tuple,
      TupleDesc tupleDesc,
      Datum *replValues,
      bool *replIsnull,
      bool *doReplace);
extern void heap_deform_tuple(HeapTuple tuple, TupleDesc tupleDesc,
      Datum *values, bool *isnull);


extern HeapTuple heap_formtuple(TupleDesc tupleDescriptor,
      Datum *values, char *nulls);
extern HeapTuple heap_modifytuple(HeapTuple tuple,
     TupleDesc tupleDesc,
     Datum *replValues,
     char *replNulls,
     char *replActions);
extern void heap_deformtuple(HeapTuple tuple, TupleDesc tupleDesc,
     Datum *values, char *nulls);
extern void heap_freetuple(HeapTuple htup);
extern MinimalTuple heap_form_minimal_tuple(TupleDesc tupleDescriptor,
      Datum *values, bool *isnull);
extern void heap_free_minimal_tuple(MinimalTuple mtup);
extern MinimalTuple heap_copy_minimal_tuple(MinimalTuple mtup);
extern HeapTuple heap_tuple_from_minimal_tuple(MinimalTuple mtup);
extern MinimalTuple minimal_tuple_from_heap_tuple(HeapTuple htup);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h"
typedef int Buffer;
# 44 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h"
typedef struct BufferAccessStrategyData *BufferAccessStrategy;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 2
# 112 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
typedef struct TupleTableSlot
{
 NodeTag type;
 bool tts_isempty;
 bool tts_shouldFree;
 bool tts_shouldFreeMin;
 bool tts_slow;
 HeapTuple tts_tuple;
 TupleDesc tts_tupleDescriptor;
 MemoryContext tts_mcxt;
 Buffer tts_buffer;
 int tts_nvalid;
 Datum *tts_values;
 bool *tts_isnull;
 MinimalTuple tts_mintuple;
 HeapTupleData tts_minhdr;
 long tts_off;
} TupleTableSlot;
# 141 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
extern TupleTableSlot *MakeTupleTableSlot(void);
extern TupleTableSlot *ExecAllocTableSlot(List **tupleTable);
extern void ExecResetTupleTable(List *tupleTable, bool shouldFree);
extern TupleTableSlot *MakeSingleTupleTableSlot(TupleDesc tupdesc);
extern void ExecDropSingleTupleTableSlot(TupleTableSlot *slot);
extern void ExecSetSlotDescriptor(TupleTableSlot *slot, TupleDesc tupdesc);
extern TupleTableSlot *ExecStoreTuple(HeapTuple tuple,
      TupleTableSlot *slot,
      Buffer buffer,
      bool shouldFree);
extern TupleTableSlot *ExecStoreMinimalTuple(MinimalTuple mtup,
       TupleTableSlot *slot,
       bool shouldFree);
extern TupleTableSlot *ExecClearTuple(TupleTableSlot *slot);
extern TupleTableSlot *ExecStoreVirtualTuple(TupleTableSlot *slot);
extern TupleTableSlot *ExecStoreAllNullTuple(TupleTableSlot *slot);
extern HeapTuple ExecCopySlotTuple(TupleTableSlot *slot);
extern MinimalTuple ExecCopySlotMinimalTuple(TupleTableSlot *slot);
extern HeapTuple ExecFetchSlotTuple(TupleTableSlot *slot);
extern MinimalTuple ExecFetchSlotMinimalTuple(TupleTableSlot *slot);
extern Datum ExecFetchSlotTupleDatum(TupleTableSlot *slot);
extern HeapTuple ExecMaterializeSlot(TupleTableSlot *slot);
extern TupleTableSlot *ExecCopySlot(TupleTableSlot *dstslot,
    TupleTableSlot *srcslot);


extern Datum slot_getattr(TupleTableSlot *slot, int attnum, bool *isnull);
extern void slot_getallattrs(TupleTableSlot *slot);
extern void slot_getsomeattrs(TupleTableSlot *slot, int attnum);
extern bool slot_attisnull(TupleTableSlot *slot, int attnum);
# 18 "print.h" 2




extern void print(const void *obj);
extern void pprint(const void *obj);
extern void elog_node_display(int lev, const char *title,
      const void *obj, bool pretty);
extern char *format_node_dump(const char *dump);
extern char *pretty_format_node_dump(const char *dump);
extern void print_rt(const List *rtable);
extern void print_expr(const Node *expr, const List *rtable);
extern void print_pathkeys(const List *pathkeys, const List *rtable);
extern void print_tl(const List *tlist, const List *rtable);
extern void print_slot(TupleTableSlot *slot);
# 14 "settings.h" 2
# 30 "settings.h"
typedef enum
{
 PSQL_ECHO_NONE,
 PSQL_ECHO_QUERIES,
 PSQL_ECHO_ALL
} PSQL_ECHO;

typedef enum
{
 PSQL_ECHO_HIDDEN_OFF,
 PSQL_ECHO_HIDDEN_ON,
 PSQL_ECHO_HIDDEN_NOEXEC
} PSQL_ECHO_HIDDEN;

typedef enum
{
 PSQL_ERROR_ROLLBACK_OFF,
 PSQL_ERROR_ROLLBACK_INTERACTIVE,
 PSQL_ERROR_ROLLBACK_ON
} PSQL_ERROR_ROLLBACK;

typedef enum
{
 hctl_none = 0,
 hctl_ignorespace = 1,
 hctl_ignoredups = 2,
 hctl_ignoreboth = hctl_ignorespace | hctl_ignoredups
} HistControl;

enum trivalue
{
 TRI_DEFAULT,
 TRI_NO,
 TRI_YES
};

typedef struct _psqlSettings
{
 PGconn *db;
 int encoding;
 FILE *queryFout;
 bool queryFoutPipe;

 printQueryOpt popt;

 char *gfname;

 bool notty;

 enum trivalue getPassword;
 FILE *cur_cmd_source;

 bool cur_cmd_interactive;
 int sversion;
 const char *progname;
 char *inputfile;
 char *dirname;

 uint64 lineno;

 bool timing;

 FILE *logfile;

 VariableSpace vars;






 bool autocommit;
 bool on_error_stop;
 bool quiet;
 bool singleline;
 bool singlestep;
 int fetch_count;
 PSQL_ECHO echo;
 PSQL_ECHO_HIDDEN echo_hidden;
 PSQL_ERROR_ROLLBACK on_error_rollback;
 HistControl histcontrol;
 const char *prompt1;
 const char *prompt2;
 const char *prompt3;
 PGVerbosity verbosity;
} PsqlSettings;

extern PsqlSettings pset;
# 32 "help.c" 2
# 1 "sql_help.h" 1
# 18 "sql_help.h"
struct _helpStruct
{
 const char *cmd;
 const char *help;
 void (*syntaxfunc)(PQExpBuffer);
 int nl_count;
};

extern void sql_help_ABORT(PQExpBuffer buf);
extern void sql_help_ALTER_AGGREGATE(PQExpBuffer buf);
extern void sql_help_ALTER_COLLATION(PQExpBuffer buf);
extern void sql_help_ALTER_CONVERSION(PQExpBuffer buf);
extern void sql_help_ALTER_DATABASE(PQExpBuffer buf);
extern void sql_help_ALTER_DEFAULT_PRIVILEGES(PQExpBuffer buf);
extern void sql_help_ALTER_DOMAIN(PQExpBuffer buf);
extern void sql_help_ALTER_EXTENSION(PQExpBuffer buf);
extern void sql_help_ALTER_FOREIGN_DATA_WRAPPER(PQExpBuffer buf);
extern void sql_help_ALTER_FOREIGN_TABLE(PQExpBuffer buf);
extern void sql_help_ALTER_FUNCTION(PQExpBuffer buf);
extern void sql_help_ALTER_GROUP(PQExpBuffer buf);
extern void sql_help_ALTER_INDEX(PQExpBuffer buf);
extern void sql_help_ALTER_LANGUAGE(PQExpBuffer buf);
extern void sql_help_ALTER_LARGE_OBJECT(PQExpBuffer buf);
extern void sql_help_ALTER_OPERATOR(PQExpBuffer buf);
extern void sql_help_ALTER_OPERATOR_CLASS(PQExpBuffer buf);
extern void sql_help_ALTER_OPERATOR_FAMILY(PQExpBuffer buf);
extern void sql_help_ALTER_ROLE(PQExpBuffer buf);
extern void sql_help_ALTER_SCHEMA(PQExpBuffer buf);
extern void sql_help_ALTER_SEQUENCE(PQExpBuffer buf);
extern void sql_help_ALTER_SERVER(PQExpBuffer buf);
extern void sql_help_ALTER_TABLE(PQExpBuffer buf);
extern void sql_help_ALTER_TABLESPACE(PQExpBuffer buf);
extern void sql_help_ALTER_TEXT_SEARCH_CONFIGURATION(PQExpBuffer buf);
extern void sql_help_ALTER_TEXT_SEARCH_DICTIONARY(PQExpBuffer buf);
extern void sql_help_ALTER_TEXT_SEARCH_PARSER(PQExpBuffer buf);
extern void sql_help_ALTER_TEXT_SEARCH_TEMPLATE(PQExpBuffer buf);
extern void sql_help_ALTER_TRIGGER(PQExpBuffer buf);
extern void sql_help_ALTER_TYPE(PQExpBuffer buf);
extern void sql_help_ALTER_USER(PQExpBuffer buf);
extern void sql_help_ALTER_USER_MAPPING(PQExpBuffer buf);
extern void sql_help_ALTER_VIEW(PQExpBuffer buf);
extern void sql_help_ANALYZE(PQExpBuffer buf);
extern void sql_help_BEGIN(PQExpBuffer buf);
extern void sql_help_CHECKPOINT(PQExpBuffer buf);
extern void sql_help_CLOSE(PQExpBuffer buf);
extern void sql_help_CLUSTER(PQExpBuffer buf);
extern void sql_help_COMMENT(PQExpBuffer buf);
extern void sql_help_COMMIT(PQExpBuffer buf);
extern void sql_help_COMMIT_PREPARED(PQExpBuffer buf);
extern void sql_help_COPY(PQExpBuffer buf);
extern void sql_help_CREATE_AGGREGATE(PQExpBuffer buf);
extern void sql_help_CREATE_CAST(PQExpBuffer buf);
extern void sql_help_CREATE_COLLATION(PQExpBuffer buf);
extern void sql_help_CREATE_CONVERSION(PQExpBuffer buf);
extern void sql_help_CREATE_DATABASE(PQExpBuffer buf);
extern void sql_help_CREATE_DOMAIN(PQExpBuffer buf);
extern void sql_help_CREATE_EXTENSION(PQExpBuffer buf);
extern void sql_help_CREATE_FOREIGN_DATA_WRAPPER(PQExpBuffer buf);
extern void sql_help_CREATE_FOREIGN_TABLE(PQExpBuffer buf);
extern void sql_help_CREATE_FUNCTION(PQExpBuffer buf);
extern void sql_help_CREATE_GROUP(PQExpBuffer buf);
extern void sql_help_CREATE_INDEX(PQExpBuffer buf);
extern void sql_help_CREATE_LANGUAGE(PQExpBuffer buf);
extern void sql_help_CREATE_OPERATOR(PQExpBuffer buf);
extern void sql_help_CREATE_OPERATOR_CLASS(PQExpBuffer buf);
extern void sql_help_CREATE_OPERATOR_FAMILY(PQExpBuffer buf);
extern void sql_help_CREATE_ROLE(PQExpBuffer buf);
extern void sql_help_CREATE_RULE(PQExpBuffer buf);
extern void sql_help_CREATE_SCHEMA(PQExpBuffer buf);
extern void sql_help_CREATE_SEQUENCE(PQExpBuffer buf);
extern void sql_help_CREATE_SERVER(PQExpBuffer buf);
extern void sql_help_CREATE_TABLE(PQExpBuffer buf);
extern void sql_help_CREATE_TABLE_AS(PQExpBuffer buf);
extern void sql_help_CREATE_TABLESPACE(PQExpBuffer buf);
extern void sql_help_CREATE_TEXT_SEARCH_CONFIGURATION(PQExpBuffer buf);
extern void sql_help_CREATE_TEXT_SEARCH_DICTIONARY(PQExpBuffer buf);
extern void sql_help_CREATE_TEXT_SEARCH_PARSER(PQExpBuffer buf);
extern void sql_help_CREATE_TEXT_SEARCH_TEMPLATE(PQExpBuffer buf);
extern void sql_help_CREATE_TRIGGER(PQExpBuffer buf);
extern void sql_help_CREATE_TYPE(PQExpBuffer buf);
extern void sql_help_CREATE_USER(PQExpBuffer buf);
extern void sql_help_CREATE_USER_MAPPING(PQExpBuffer buf);
extern void sql_help_CREATE_VIEW(PQExpBuffer buf);
extern void sql_help_DEALLOCATE(PQExpBuffer buf);
extern void sql_help_DECLARE(PQExpBuffer buf);
extern void sql_help_DELETE(PQExpBuffer buf);
extern void sql_help_DISCARD(PQExpBuffer buf);
extern void sql_help_DO(PQExpBuffer buf);
extern void sql_help_DROP_AGGREGATE(PQExpBuffer buf);
extern void sql_help_DROP_CAST(PQExpBuffer buf);
extern void sql_help_DROP_COLLATION(PQExpBuffer buf);
extern void sql_help_DROP_CONVERSION(PQExpBuffer buf);
extern void sql_help_DROP_DATABASE(PQExpBuffer buf);
extern void sql_help_DROP_DOMAIN(PQExpBuffer buf);
extern void sql_help_DROP_EXTENSION(PQExpBuffer buf);
extern void sql_help_DROP_FOREIGN_DATA_WRAPPER(PQExpBuffer buf);
extern void sql_help_DROP_FOREIGN_TABLE(PQExpBuffer buf);
extern void sql_help_DROP_FUNCTION(PQExpBuffer buf);
extern void sql_help_DROP_GROUP(PQExpBuffer buf);
extern void sql_help_DROP_INDEX(PQExpBuffer buf);
extern void sql_help_DROP_LANGUAGE(PQExpBuffer buf);
extern void sql_help_DROP_OPERATOR(PQExpBuffer buf);
extern void sql_help_DROP_OPERATOR_CLASS(PQExpBuffer buf);
extern void sql_help_DROP_OPERATOR_FAMILY(PQExpBuffer buf);
extern void sql_help_DROP_OWNED(PQExpBuffer buf);
extern void sql_help_DROP_ROLE(PQExpBuffer buf);
extern void sql_help_DROP_RULE(PQExpBuffer buf);
extern void sql_help_DROP_SCHEMA(PQExpBuffer buf);
extern void sql_help_DROP_SEQUENCE(PQExpBuffer buf);
extern void sql_help_DROP_SERVER(PQExpBuffer buf);
extern void sql_help_DROP_TABLE(PQExpBuffer buf);
extern void sql_help_DROP_TABLESPACE(PQExpBuffer buf);
extern void sql_help_DROP_TEXT_SEARCH_CONFIGURATION(PQExpBuffer buf);
extern void sql_help_DROP_TEXT_SEARCH_DICTIONARY(PQExpBuffer buf);
extern void sql_help_DROP_TEXT_SEARCH_PARSER(PQExpBuffer buf);
extern void sql_help_DROP_TEXT_SEARCH_TEMPLATE(PQExpBuffer buf);
extern void sql_help_DROP_TRIGGER(PQExpBuffer buf);
extern void sql_help_DROP_TYPE(PQExpBuffer buf);
extern void sql_help_DROP_USER(PQExpBuffer buf);
extern void sql_help_DROP_USER_MAPPING(PQExpBuffer buf);
extern void sql_help_DROP_VIEW(PQExpBuffer buf);
extern void sql_help_END(PQExpBuffer buf);
extern void sql_help_EXECUTE(PQExpBuffer buf);
extern void sql_help_EXPLAIN(PQExpBuffer buf);
extern void sql_help_FETCH(PQExpBuffer buf);
extern void sql_help_GRANT(PQExpBuffer buf);
extern void sql_help_INSERT(PQExpBuffer buf);
extern void sql_help_LISTEN(PQExpBuffer buf);
extern void sql_help_LOAD(PQExpBuffer buf);
extern void sql_help_LOCK(PQExpBuffer buf);
extern void sql_help_MOVE(PQExpBuffer buf);
extern void sql_help_NOTIFY(PQExpBuffer buf);
extern void sql_help_PREPARE(PQExpBuffer buf);
extern void sql_help_PREPARE_TRANSACTION(PQExpBuffer buf);
extern void sql_help_REASSIGN_OWNED(PQExpBuffer buf);
extern void sql_help_REINDEX(PQExpBuffer buf);
extern void sql_help_RELEASE_SAVEPOINT(PQExpBuffer buf);
extern void sql_help_RESET(PQExpBuffer buf);
extern void sql_help_REVOKE(PQExpBuffer buf);
extern void sql_help_ROLLBACK(PQExpBuffer buf);
extern void sql_help_ROLLBACK_PREPARED(PQExpBuffer buf);
extern void sql_help_ROLLBACK_TO_SAVEPOINT(PQExpBuffer buf);
extern void sql_help_SAVEPOINT(PQExpBuffer buf);
extern void sql_help_SECURITY_LABEL(PQExpBuffer buf);
extern void sql_help_SELECT(PQExpBuffer buf);
extern void sql_help_SELECT_INTO(PQExpBuffer buf);
extern void sql_help_SET(PQExpBuffer buf);
extern void sql_help_SET_CONSTRAINTS(PQExpBuffer buf);
extern void sql_help_SET_ROLE(PQExpBuffer buf);
extern void sql_help_SET_SESSION_AUTHORIZATION(PQExpBuffer buf);
extern void sql_help_SET_TRANSACTION(PQExpBuffer buf);
extern void sql_help_SHOW(PQExpBuffer buf);
extern void sql_help_START_TRANSACTION(PQExpBuffer buf);
extern void sql_help_TABLE(PQExpBuffer buf);
extern void sql_help_TRUNCATE(PQExpBuffer buf);
extern void sql_help_UNLISTEN(PQExpBuffer buf);
extern void sql_help_UPDATE(PQExpBuffer buf);
extern void sql_help_VACUUM(PQExpBuffer buf);
extern void sql_help_VALUES(PQExpBuffer buf);
extern void sql_help_WITH(PQExpBuffer buf);


static const struct _helpStruct QL_HELP[] = {
    { "ABORT",
      ("abort the current transaction"),
      sql_help_ABORT,
      0 },

    { "ALTER AGGREGATE",
      ("change the definition of an aggregate function"),
      sql_help_ALTER_AGGREGATE,
      2 },

    { "ALTER COLLATION",
      ("change the definition of a collation"),
      sql_help_ALTER_COLLATION,
      2 },

    { "ALTER CONVERSION",
      ("change the definition of a conversion"),
      sql_help_ALTER_CONVERSION,
      2 },

    { "ALTER DATABASE",
      ("change a database"),
      sql_help_ALTER_DATABASE,
      15 },

    { "ALTER DEFAULT PRIVILEGES",
      ("define default access privileges"),
      sql_help_ALTER_DEFAULT_PRIVILEGES,
      49 },

    { "ALTER DOMAIN",
      ("change the definition of a domain"),
      sql_help_ALTER_DOMAIN,
      17 },

    { "ALTER EXTENSION",
      ("change the definition of an extension"),
      sql_help_ALTER_EXTENSION,
      28 },

    { "ALTER FOREIGN DATA WRAPPER",
      ("change the definition of a foreign-data wrapper"),
      sql_help_ALTER_FOREIGN_DATA_WRAPPER,
      5 },

    { "ALTER FOREIGN TABLE",
      ("change the definition of a foreign table"),
      sql_help_ALTER_FOREIGN_TABLE,
      20 },

    { "ALTER FUNCTION",
      ("change the definition of a function"),
      sql_help_ALTER_FUNCTION,
      19 },

    { "ALTER GROUP",
      ("change role name or membership"),
      sql_help_ALTER_GROUP,
      3 },

    { "ALTER INDEX",
      ("change the definition of an index"),
      sql_help_ALTER_INDEX,
      3 },

    { "ALTER LANGUAGE",
      ("change the definition of a procedural language"),
      sql_help_ALTER_LANGUAGE,
      1 },

    { "ALTER LARGE OBJECT",
      ("change the definition of a large object"),
      sql_help_ALTER_LARGE_OBJECT,
      0 },

    { "ALTER OPERATOR",
      ("change the definition of an operator"),
      sql_help_ALTER_OPERATOR,
      1 },

    { "ALTER OPERATOR CLASS",
      ("change the definition of an operator class"),
      sql_help_ALTER_OPERATOR_CLASS,
      2 },

    { "ALTER OPERATOR FAMILY",
      ("change the definition of an operator family"),
      sql_help_ALTER_OPERATOR_FAMILY,
      10 },

    { "ALTER ROLE",
      ("change a database role"),
      sql_help_ALTER_ROLE,
      20 },

    { "ALTER SCHEMA",
      ("change the definition of a schema"),
      sql_help_ALTER_SCHEMA,
      1 },

    { "ALTER SEQUENCE",
      ("change the definition of a sequence generator"),
      sql_help_ALTER_SEQUENCE,
      8 },

    { "ALTER SERVER",
      ("change the definition of a foreign server"),
      sql_help_ALTER_SERVER,
      3 },

    { "ALTER TABLE",
      ("change the definition of a table"),
      sql_help_ALTER_TABLE,
      52 },

    { "ALTER TABLESPACE",
      ("change the definition of a tablespace"),
      sql_help_ALTER_TABLESPACE,
      3 },

    { "ALTER TEXT SEARCH CONFIGURATION",
      ("change the definition of a text search configuration"),
      sql_help_ALTER_TEXT_SEARCH_CONFIGURATION,
      12 },

    { "ALTER TEXT SEARCH DICTIONARY",
      ("change the definition of a text search dictionary"),
      sql_help_ALTER_TEXT_SEARCH_DICTIONARY,
      5 },

    { "ALTER TEXT SEARCH PARSER",
      ("change the definition of a text search parser"),
      sql_help_ALTER_TEXT_SEARCH_PARSER,
      1 },

    { "ALTER TEXT SEARCH TEMPLATE",
      ("change the definition of a text search template"),
      sql_help_ALTER_TEXT_SEARCH_TEMPLATE,
      1 },

    { "ALTER TRIGGER",
      ("change the definition of a trigger"),
      sql_help_ALTER_TRIGGER,
      0 },

    { "ALTER TYPE",
      ("change the definition of a type"),
      sql_help_ALTER_TYPE,
      11 },

    { "ALTER USER",
      ("change a database role"),
      sql_help_ALTER_USER,
      20 },

    { "ALTER USER MAPPING",
      ("change the definition of a user mapping"),
      sql_help_ALTER_USER_MAPPING,
      2 },

    { "ALTER VIEW",
      ("change the definition of a view"),
      sql_help_ALTER_VIEW,
      6 },

    { "ANALYZE",
      ("collect statistics about a database"),
      sql_help_ANALYZE,
      0 },

    { "BEGIN",
      ("start a transaction block"),
      sql_help_BEGIN,
      6 },

    { "CHECKPOINT",
      ("force a transaction log checkpoint"),
      sql_help_CHECKPOINT,
      0 },

    { "CLOSE",
      ("close a cursor"),
      sql_help_CLOSE,
      0 },

    { "CLUSTER",
      ("cluster a table according to an index"),
      sql_help_CLUSTER,
      1 },

    { "COMMENT",
      ("define or change the comment of an object"),
      sql_help_COMMENT,
      34 },

    { "COMMIT",
      ("commit the current transaction"),
      sql_help_COMMIT,
      0 },

    { "COMMIT PREPARED",
      ("commit a transaction that was earlier prepared for two-phase commit"),
      sql_help_COMMIT_PREPARED,
      0 },

    { "COPY",
      ("copy data between a file and a table"),
      sql_help_COPY,
      19 },

    { "CREATE AGGREGATE",
      ("define a new aggregate function"),
      sql_help_CREATE_AGGREGATE,
      17 },

    { "CREATE CAST",
      ("define a new cast"),
      sql_help_CREATE_CAST,
      10 },

    { "CREATE COLLATION",
      ("define a new collation"),
      sql_help_CREATE_COLLATION,
      5 },

    { "CREATE CONVERSION",
      ("define a new encoding conversion"),
      sql_help_CREATE_CONVERSION,
      1 },

    { "CREATE DATABASE",
      ("create a new database"),
      sql_help_CREATE_DATABASE,
      7 },

    { "CREATE DOMAIN",
      ("define a new domain"),
      sql_help_CREATE_DOMAIN,
      8 },

    { "CREATE EXTENSION",
      ("install an extension"),
      sql_help_CREATE_EXTENSION,
      3 },

    { "CREATE FOREIGN DATA WRAPPER",
      ("define a new foreign-data wrapper"),
      sql_help_CREATE_FOREIGN_DATA_WRAPPER,
      3 },

    { "CREATE FOREIGN TABLE",
      ("define a new foreign table"),
      sql_help_CREATE_FOREIGN_TABLE,
      5 },

    { "CREATE FUNCTION",
      ("define a new function"),
      sql_help_CREATE_FUNCTION,
      15 },

    { "CREATE GROUP",
      ("define a new database role"),
      sql_help_CREATE_GROUP,
      17 },

    { "CREATE INDEX",
      ("define a new index"),
      sql_help_CREATE_INDEX,
      4 },

    { "CREATE LANGUAGE",
      ("define a new procedural language"),
      sql_help_CREATE_LANGUAGE,
      2 },

    { "CREATE OPERATOR",
      ("define a new operator"),
      sql_help_CREATE_OPERATOR,
      6 },

    { "CREATE OPERATOR CLASS",
      ("define a new operator class"),
      sql_help_CREATE_OPERATOR_CLASS,
      5 },

    { "CREATE OPERATOR FAMILY",
      ("define a new operator family"),
      sql_help_CREATE_OPERATOR_FAMILY,
      0 },

    { "CREATE ROLE",
      ("define a new database role"),
      sql_help_CREATE_ROLE,
      19 },

    { "CREATE RULE",
      ("define a new rewrite rule"),
      sql_help_CREATE_RULE,
      2 },

    { "CREATE SCHEMA",
      ("define a new schema"),
      sql_help_CREATE_SCHEMA,
      1 },

    { "CREATE SEQUENCE",
      ("define a new sequence generator"),
      sql_help_CREATE_SEQUENCE,
      3 },

    { "CREATE SERVER",
      ("define a new foreign server"),
      sql_help_CREATE_SERVER,
      2 },

    { "CREATE TABLE",
      ("define a new table"),
      sql_help_CREATE_TABLE,
      56 },

    { "CREATE TABLE AS",
      ("define a new table from the results of a query"),
      sql_help_CREATE_TABLE_AS,
      6 },

    { "CREATE TABLESPACE",
      ("define a new tablespace"),
      sql_help_CREATE_TABLESPACE,
      0 },

    { "CREATE TEXT SEARCH CONFIGURATION",
      ("define a new text search configuration"),
      sql_help_CREATE_TEXT_SEARCH_CONFIGURATION,
      3 },

    { "CREATE TEXT SEARCH DICTIONARY",
      ("define a new text search dictionary"),
      sql_help_CREATE_TEXT_SEARCH_DICTIONARY,
      3 },

    { "CREATE TEXT SEARCH PARSER",
      ("define a new text search parser"),
      sql_help_CREATE_TEXT_SEARCH_PARSER,
      6 },

    { "CREATE TEXT SEARCH TEMPLATE",
      ("define a new text search template"),
      sql_help_CREATE_TEXT_SEARCH_TEMPLATE,
      3 },

    { "CREATE TRIGGER",
      ("define a new trigger"),
      sql_help_CREATE_TRIGGER,
      13 },

    { "CREATE TYPE",
      ("define a new data type"),
      sql_help_CREATE_TYPE,
      35 },

    { "CREATE USER",
      ("define a new database role"),
      sql_help_CREATE_USER,
      19 },

    { "CREATE USER MAPPING",
      ("define a new mapping of a user to a foreign server"),
      sql_help_CREATE_USER_MAPPING,
      2 },

    { "CREATE VIEW",
      ("define a new view"),
      sql_help_CREATE_VIEW,
      2 },

    { "DEALLOCATE",
      ("deallocate a prepared statement"),
      sql_help_DEALLOCATE,
      0 },

    { "DECLARE",
      ("define a cursor"),
      sql_help_DECLARE,
      1 },

    { "DELETE",
      ("delete rows of a table"),
      sql_help_DELETE,
      4 },

    { "DISCARD",
      ("discard session state"),
      sql_help_DISCARD,
      0 },

    { "DO",
      ("execute an anonymous code block"),
      sql_help_DO,
      0 },

    { "DROP AGGREGATE",
      ("remove an aggregate function"),
      sql_help_DROP_AGGREGATE,
      0 },

    { "DROP CAST",
      ("remove a cast"),
      sql_help_DROP_CAST,
      0 },

    { "DROP COLLATION",
      ("remove a collation"),
      sql_help_DROP_COLLATION,
      0 },

    { "DROP CONVERSION",
      ("remove a conversion"),
      sql_help_DROP_CONVERSION,
      0 },

    { "DROP DATABASE",
      ("remove a database"),
      sql_help_DROP_DATABASE,
      0 },

    { "DROP DOMAIN",
      ("remove a domain"),
      sql_help_DROP_DOMAIN,
      0 },

    { "DROP EXTENSION",
      ("remove an extension"),
      sql_help_DROP_EXTENSION,
      0 },

    { "DROP FOREIGN DATA WRAPPER",
      ("remove a foreign-data wrapper"),
      sql_help_DROP_FOREIGN_DATA_WRAPPER,
      0 },

    { "DROP FOREIGN TABLE",
      ("remove a foreign table"),
      sql_help_DROP_FOREIGN_TABLE,
      0 },

    { "DROP FUNCTION",
      ("remove a function"),
      sql_help_DROP_FUNCTION,
      1 },

    { "DROP GROUP",
      ("remove a database role"),
      sql_help_DROP_GROUP,
      0 },

    { "DROP INDEX",
      ("remove an index"),
      sql_help_DROP_INDEX,
      0 },

    { "DROP LANGUAGE",
      ("remove a procedural language"),
      sql_help_DROP_LANGUAGE,
      0 },

    { "DROP OPERATOR",
      ("remove an operator"),
      sql_help_DROP_OPERATOR,
      0 },

    { "DROP OPERATOR CLASS",
      ("remove an operator class"),
      sql_help_DROP_OPERATOR_CLASS,
      0 },

    { "DROP OPERATOR FAMILY",
      ("remove an operator family"),
      sql_help_DROP_OPERATOR_FAMILY,
      0 },

    { "DROP OWNED",
      ("remove database objects owned by a database role"),
      sql_help_DROP_OWNED,
      0 },

    { "DROP ROLE",
      ("remove a database role"),
      sql_help_DROP_ROLE,
      0 },

    { "DROP RULE",
      ("remove a rewrite rule"),
      sql_help_DROP_RULE,
      0 },

    { "DROP SCHEMA",
      ("remove a schema"),
      sql_help_DROP_SCHEMA,
      0 },

    { "DROP SEQUENCE",
      ("remove a sequence"),
      sql_help_DROP_SEQUENCE,
      0 },

    { "DROP SERVER",
      ("remove a foreign server descriptor"),
      sql_help_DROP_SERVER,
      0 },

    { "DROP TABLE",
      ("remove a table"),
      sql_help_DROP_TABLE,
      0 },

    { "DROP TABLESPACE",
      ("remove a tablespace"),
      sql_help_DROP_TABLESPACE,
      0 },

    { "DROP TEXT SEARCH CONFIGURATION",
      ("remove a text search configuration"),
      sql_help_DROP_TEXT_SEARCH_CONFIGURATION,
      0 },

    { "DROP TEXT SEARCH DICTIONARY",
      ("remove a text search dictionary"),
      sql_help_DROP_TEXT_SEARCH_DICTIONARY,
      0 },

    { "DROP TEXT SEARCH PARSER",
      ("remove a text search parser"),
      sql_help_DROP_TEXT_SEARCH_PARSER,
      0 },

    { "DROP TEXT SEARCH TEMPLATE",
      ("remove a text search template"),
      sql_help_DROP_TEXT_SEARCH_TEMPLATE,
      0 },

    { "DROP TRIGGER",
      ("remove a trigger"),
      sql_help_DROP_TRIGGER,
      0 },

    { "DROP TYPE",
      ("remove a data type"),
      sql_help_DROP_TYPE,
      0 },

    { "DROP USER",
      ("remove a database role"),
      sql_help_DROP_USER,
      0 },

    { "DROP USER MAPPING",
      ("remove a user mapping for a foreign server"),
      sql_help_DROP_USER_MAPPING,
      0 },

    { "DROP VIEW",
      ("remove a view"),
      sql_help_DROP_VIEW,
      0 },

    { "END",
      ("commit the current transaction"),
      sql_help_END,
      0 },

    { "EXECUTE",
      ("execute a prepared statement"),
      sql_help_EXECUTE,
      0 },

    { "EXPLAIN",
      ("show the execution plan of a statement"),
      sql_help_EXPLAIN,
      10 },

    { "FETCH",
      ("retrieve rows from a query using a cursor"),
      sql_help_FETCH,
      17 },

    { "GRANT",
      ("define access privileges"),
      sql_help_GRANT,
      58 },

    { "INSERT",
      ("create new rows in a table"),
      sql_help_INSERT,
      3 },

    { "LISTEN",
      ("listen for a notification"),
      sql_help_LISTEN,
      0 },

    { "LOAD",
      ("load a shared library file"),
      sql_help_LOAD,
      0 },

    { "LOCK",
      ("lock a table"),
      sql_help_LOCK,
      5 },

    { "MOVE",
      ("position a cursor"),
      sql_help_MOVE,
      17 },

    { "NOTIFY",
      ("generate a notification"),
      sql_help_NOTIFY,
      0 },

    { "PREPARE",
      ("prepare a statement for execution"),
      sql_help_PREPARE,
      0 },

    { "PREPARE TRANSACTION",
      ("prepare the current transaction for two-phase commit"),
      sql_help_PREPARE_TRANSACTION,
      0 },

    { "REASSIGN OWNED",
      ("change the ownership of database objects owned by a database role"),
      sql_help_REASSIGN_OWNED,
      0 },

    { "REINDEX",
      ("rebuild indexes"),
      sql_help_REINDEX,
      0 },

    { "RELEASE SAVEPOINT",
      ("destroy a previously defined savepoint"),
      sql_help_RELEASE_SAVEPOINT,
      0 },

    { "RESET",
      ("restore the value of a run-time parameter to the default value"),
      sql_help_RESET,
      1 },

    { "REVOKE",
      ("remove access privileges"),
      sql_help_REVOKE,
      86 },

    { "ROLLBACK",
      ("abort the current transaction"),
      sql_help_ROLLBACK,
      0 },

    { "ROLLBACK PREPARED",
      ("cancel a transaction that was earlier prepared for two-phase commit"),
      sql_help_ROLLBACK_PREPARED,
      0 },

    { "ROLLBACK TO SAVEPOINT",
      ("roll back to a savepoint"),
      sql_help_ROLLBACK_TO_SAVEPOINT,
      0 },

    { "SAVEPOINT",
      ("define a new savepoint within the current transaction"),
      sql_help_SAVEPOINT,
      0 },

    { "SECURITY LABEL",
      ("define or change a security label applied to an object"),
      sql_help_SECURITY_LABEL,
      17 },

    { "SELECT",
      ("retrieve rows from a table or view"),
      sql_help_SELECT,
      28 },

    { "SELECT INTO",
      ("define a new table from the results of a query"),
      sql_help_SELECT_INTO,
      14 },

    { "SET",
      ("change a run-time parameter"),
      sql_help_SET,
      1 },

    { "SET CONSTRAINTS",
      ("set constraint check timing for the current transaction"),
      sql_help_SET_CONSTRAINTS,
      0 },

    { "SET ROLE",
      ("set the current user identifier of the current session"),
      sql_help_SET_ROLE,
      2 },

    { "SET SESSION AUTHORIZATION",
      ("set the session user identifier and the current user identifier of the current session"),
      sql_help_SET_SESSION_AUTHORIZATION,
      2 },

    { "SET TRANSACTION",
      ("set the characteristics of the current transaction"),
      sql_help_SET_TRANSACTION,
      8 },

    { "SHOW",
      ("show the value of a run-time parameter"),
      sql_help_SHOW,
      1 },

    { "START TRANSACTION",
      ("start a transaction block"),
      sql_help_START_TRANSACTION,
      6 },

    { "TABLE",
      ("retrieve rows from a table or view"),
      sql_help_TABLE,
      28 },

    { "TRUNCATE",
      ("empty a table or set of tables"),
      sql_help_TRUNCATE,
      1 },

    { "UNLISTEN",
      ("stop listening for a notification"),
      sql_help_UNLISTEN,
      0 },

    { "UPDATE",
      ("update rows of a table"),
      sql_help_UPDATE,
      6 },

    { "VACUUM",
      ("garbage-collect and optionally analyze a database"),
      sql_help_VACUUM,
      2 },

    { "VALUES",
      ("compute a set of rows"),
      sql_help_VALUES,
      4 },

    { "WITH",
      ("retrieve rows from a table or view"),
      sql_help_WITH,
      28 },


    { ((void *)0), ((void *)0), ((void *)0) }
};
# 33 "help.c" 2
# 50 "help.c"
void
usage(void)
{
 const char *env;
 const char *user;


 struct passwd *pw = ((void *)0);



 user = getenv("PGUSER");
 if (!user)
 {

  pw = getpwuid(geteuid());
  if (pw)
   user = pw->pw_name;
  else
  {
   psql_error("could not get current user name: %s\n", strerror((*__error())));
   exit(1);
  }







 }

 printf(("psql is the PostgreSQL interactive terminal.\n\n"));
 printf(("Usage:\n"));
 printf(("  psql [OPTION]... [DBNAME [USERNAME]]\n\n"));

 printf(("General options:\n"));

 env = getenv("PGDATABASE");
 if (!env)
  env = user;
 printf(("  -c, --command=COMMAND    run only single command (SQL or internal) and exit\n"));
 printf(("  -d, --dbname=DBNAME      database name to connect to (default: \"%s\")\n"), env);
 printf(("  -f, --file=FILENAME      execute commands from file, then exit\n"));
 printf(("  -l, --list               list available databases, then exit\n"));
 printf(("  -v, --set=, --variable=NAME=VALUE\n" "                           set psql variable NAME to VALUE\n"));

 printf(("  -V, --version            output version information, then exit\n"));
 printf(("  -X, --no-psqlrc          do not read startup file (~/.psqlrc)\n"));
 printf(("  -1 (\"one\"), --single-transaction\n" "                           execute command file as a single transaction\n"));

 printf(("  -?, --help               show this help, then exit\n"));

 printf(("\nInput and output options:\n"));
 printf(("  -a, --echo-all           echo all input from script\n"));
 printf(("  -e, --echo-queries       echo commands sent to server\n"));
 printf(("  -E, --echo-hidden        display queries that internal commands generate\n"));
 printf(("  -L, --log-file=FILENAME  send session log to file\n"));
 printf(("  -n, --no-readline        disable enhanced command line editing (readline)\n"));
 printf(("  -o, --output=FILENAME    send query results to file (or |pipe)\n"));
 printf(("  -q, --quiet              run quietly (no messages, only query output)\n"));
 printf(("  -s, --single-step        single-step mode (confirm each query)\n"));
 printf(("  -S, --single-line        single-line mode (end of line terminates SQL command)\n"));

 printf(("\nOutput format options:\n"));
 printf(("  -A, --no-align           unaligned table output mode\n"));
 printf(("  -F, --field-separator=STRING\n" "                           set field separator (default: \"%s\")\n"),

     "|");
 printf(("  -H, --html               HTML table output mode\n"));
 printf(("  -P, --pset=VAR[=ARG]     set printing option VAR to ARG (see \\pset command)\n"));
 printf(("  -R, --record-separator=STRING\n" "                           set record separator (default: newline)\n"));

 printf(("  -t, --tuples-only        print rows only\n"));
 printf(("  -T, --table-attr=TEXT    set HTML table tag attributes (e.g., width, border)\n"));
 printf(("  -x, --expanded           turn on expanded table output\n"));
 printf(("  -z, --field-separator-zero\n" "                           set field separator to zero byte\n"));

 printf(("  -0, --record-separator-zero\n" "                           set record separator to zero byte\n"));


 printf(("\nConnection options:\n"));

 env = getenv("PGHOST");
 printf(("  -h, --host=HOSTNAME      database server host or socket directory (default: \"%s\")\n"),
     env ? env : ("local socket"));

 env = getenv("PGPORT");
 printf(("  -p, --port=PORT          database server port (default: \"%s\")\n"),
     env ? env : "5432");

 env = getenv("PGUSER");
 if (!env)
  env = user;
 printf(("  -U, --username=USERNAME  database user name (default: \"%s\")\n"), env);
 printf(("  -w, --no-password        never prompt for password\n"));
 printf(("  -W, --password           force password prompt (should happen automatically)\n"));

 printf(("\nFor more information, type \"\\?\" (for internal commands) or \"\\help\" (for SQL\n" "commands) from within psql, or consult the psql section in the PostgreSQL\n" "documentation.\n\n"));


 printf(("Report bugs to <pgsql-bugs@postgresql.org>.\n"));
}







void
slashUsage(unsigned short int pager)
{
 FILE *output;
 char *currdb;

 currdb = PQdb(pset.db);
 if (currdb == ((void *)0))
  currdb = "";

 output = PageOutput(94, pager);



 fprintf(output, ("General\n"));
 fprintf(output, ("  \\copyright             show PostgreSQL usage and distribution terms\n"));
 fprintf(output, ("  \\g [FILE] or ;         execute query (and send results to file or |pipe)\n"));
 fprintf(output, ("  \\h [NAME]              help on syntax of SQL commands, * for all commands\n"));
 fprintf(output, ("  \\q                     quit psql\n"));
 fprintf(output, "\n");

 fprintf(output, ("Query Buffer\n"));
 fprintf(output, ("  \\e [FILE] [LINE]       edit the query buffer (or file) with external editor\n"));
 fprintf(output, ("  \\ef [FUNCNAME [LINE]]  edit function definition with external editor\n"));
 fprintf(output, ("  \\p                     show the contents of the query buffer\n"));
 fprintf(output, ("  \\r                     reset (clear) the query buffer\n"));

 fprintf(output, ("  \\s [FILE]              display history or save it to file\n"));

 fprintf(output, ("  \\w FILE                write query buffer to file\n"));
 fprintf(output, "\n");

 fprintf(output, ("Input/Output\n"));
 fprintf(output, ("  \\copy ...              perform SQL COPY with data stream to the client host\n"));
 fprintf(output, ("  \\echo [STRING]         write string to standard output\n"));
 fprintf(output, ("  \\i FILE                execute commands from file\n"));
 fprintf(output, ("  \\ir FILE               as \\i, but relative to location of current script\n"));
 fprintf(output, ("  \\o [FILE]              send all query results to file or |pipe\n"));
 fprintf(output, ("  \\qecho [STRING]        write string to query output stream (see \\o)\n"));
 fprintf(output, "\n");

 fprintf(output, ("Informational\n"));
 fprintf(output, ("  (options: S = show system objects, + = additional detail)\n"));
 fprintf(output, ("  \\d[S+]                 list tables, views, and sequences\n"));
 fprintf(output, ("  \\d[S+]  NAME           describe table, view, sequence, or index\n"));
 fprintf(output, ("  \\da[S]  [PATTERN]      list aggregates\n"));
 fprintf(output, ("  \\db[+]  [PATTERN]      list tablespaces\n"));
 fprintf(output, ("  \\dc[S+] [PATTERN]      list conversions\n"));
 fprintf(output, ("  \\dC[+]  [PATTERN]      list casts\n"));
 fprintf(output, ("  \\dd[S]  [PATTERN]      show object descriptions not displayed elsewhere\n"));
 fprintf(output, ("  \\ddp    [PATTERN]      list default privileges\n"));
 fprintf(output, ("  \\dD[S+] [PATTERN]      list domains\n"));
 fprintf(output, ("  \\det[+] [PATTERN]      list foreign tables\n"));
 fprintf(output, ("  \\des[+] [PATTERN]      list foreign servers\n"));
 fprintf(output, ("  \\deu[+] [PATTERN]      list user mappings\n"));
 fprintf(output, ("  \\dew[+] [PATTERN]      list foreign-data wrappers\n"));
 fprintf(output, ("  \\df[antw][S+] [PATRN]  list [only agg/normal/trigger/window] functions\n"));
 fprintf(output, ("  \\dF[+]  [PATTERN]      list text search configurations\n"));
 fprintf(output, ("  \\dFd[+] [PATTERN]      list text search dictionaries\n"));
 fprintf(output, ("  \\dFp[+] [PATTERN]      list text search parsers\n"));
 fprintf(output, ("  \\dFt[+] [PATTERN]      list text search templates\n"));
 fprintf(output, ("  \\dg[+]  [PATTERN]      list roles\n"));
 fprintf(output, ("  \\di[S+] [PATTERN]      list indexes\n"));
 fprintf(output, ("  \\dl                    list large objects, same as \\lo_list\n"));
 fprintf(output, ("  \\dL[S+] [PATTERN]      list procedural languages\n"));
 fprintf(output, ("  \\dn[S+] [PATTERN]      list schemas\n"));
 fprintf(output, ("  \\do[S]  [PATTERN]      list operators\n"));
 fprintf(output, ("  \\dO[S+] [PATTERN]      list collations\n"));
 fprintf(output, ("  \\dp     [PATTERN]      list table, view, and sequence access privileges\n"));
 fprintf(output, ("  \\drds [PATRN1 [PATRN2]] list per-database role settings\n"));
 fprintf(output, ("  \\ds[S+] [PATTERN]      list sequences\n"));
 fprintf(output, ("  \\dt[S+] [PATTERN]      list tables\n"));
 fprintf(output, ("  \\dT[S+] [PATTERN]      list data types\n"));
 fprintf(output, ("  \\du[+]  [PATTERN]      list roles\n"));
 fprintf(output, ("  \\dv[S+] [PATTERN]      list views\n"));
 fprintf(output, ("  \\dE[S+] [PATTERN]      list foreign tables\n"));
 fprintf(output, ("  \\dx[+]  [PATTERN]      list extensions\n"));
 fprintf(output, ("  \\l[+]                  list all databases\n"));
 fprintf(output, ("  \\sf[+] FUNCNAME        show a function's definition\n"));
 fprintf(output, ("  \\z      [PATTERN]      same as \\dp\n"));
 fprintf(output, "\n");

 fprintf(output, ("Formatting\n"));
 fprintf(output, ("  \\a                     toggle between unaligned and aligned output mode\n"));
 fprintf(output, ("  \\C [STRING]            set table title, or unset if none\n"));
 fprintf(output, ("  \\f [STRING]            show or set field separator for unaligned query output\n"));
 fprintf(output, ("  \\H                     toggle HTML output mode (currently %s)\n"),
   (pset.popt.topt.format == PRINT_HTML ? ("on") : ("off")));
 fprintf(output, ("  \\pset NAME [VALUE]     set table output option\n" "                         (NAME := {format|border|expanded|fieldsep|fieldsep_zero|footer|null|\n" "                         numericlocale|recordsep|recordsep_zero|tuples_only|title|tableattr|pager})\n"));


 fprintf(output, ("  \\t [on|off]            show only rows (currently %s)\n"),
   (pset.popt.topt.tuples_only ? ("on") : ("off")));
 fprintf(output, ("  \\T [STRING]            set HTML <table> tag attributes, or unset if none\n"));
 fprintf(output, ("  \\x [on|off|auto]       toggle expanded output (currently %s)\n"),
  pset.popt.topt.expanded == 2 ? "auto" : (pset.popt.topt.expanded ? ("on") : ("off")));
 fprintf(output, "\n");

 fprintf(output, ("Connection\n"));
 fprintf(output, ("  \\c[onnect] [DBNAME|- USER|- HOST|- PORT|-]\n" "                         connect to new database (currently \"%s\")\n"),

   currdb);
 fprintf(output, ("  \\encoding [ENCODING]   show or set client encoding\n"));
 fprintf(output, ("  \\password [USERNAME]   securely change the password for a user\n"));
 fprintf(output, ("  \\conninfo              display information about current connection\n"));
 fprintf(output, "\n");

 fprintf(output, ("Operating System\n"));
 fprintf(output, ("  \\cd [DIR]              change the current working directory\n"));
 fprintf(output, ("  \\setenv NAME [VALUE]   set or unset environment variable\n"));
 fprintf(output, ("  \\timing [on|off]       toggle timing of commands (currently %s)\n"),
   (pset.timing ? ("on") : ("off")));
 fprintf(output, ("  \\! [COMMAND]           execute command in shell or start interactive shell\n"));
 fprintf(output, "\n");

 fprintf(output, ("Variables\n"));
 fprintf(output, ("  \\prompt [TEXT] NAME    prompt user to set internal variable\n"));
 fprintf(output, ("  \\set [NAME [VALUE]]    set internal variable, or list all if no parameters\n"));
 fprintf(output, ("  \\unset NAME            unset (delete) internal variable\n"));
 fprintf(output, "\n");

 fprintf(output, ("Large Objects\n"));
 fprintf(output, ("  \\lo_export LOBOID FILE\n" "  \\lo_import FILE [COMMENT]\n" "  \\lo_list\n" "  \\lo_unlink LOBOID      large object operations\n"));




 ClosePager(output);
}
# 297 "help.c"
void
helpSQL(const char *topic, unsigned short int pager)
{


 if (!topic || strlen(topic) == 0)
 {

  int screen_width;
  int ncolumns;
  int nrows;
  FILE *output;
  int i;
  int j;


  struct winsize screen_size;

  if (ioctl(fileno(__stdoutp), ((__uint32_t)0x40000000 | ((sizeof(struct winsize) & 0x1fff) << 16) | ((('t')) << 8) | ((104))), &screen_size) == -1)
   screen_width = 80;
  else
   screen_width = screen_size.ws_col;




  ncolumns = (screen_width - 3) / (32 + 1);
  ncolumns = ((ncolumns) > (1) ? (ncolumns) : (1));
  nrows = (152 + (ncolumns - 1)) / ncolumns;

  output = PageOutput(nrows + 1, pager);

  fputs(("Available help:\n"), output);

  for (i = 0; i < nrows; i++)
  {
   fprintf(output, "  ");
   for (j = 0; j < ncolumns - 1; j++)
    fprintf(output, "%-*s",
      32 + 1,
      ((QL_HELP[i + j * nrows].cmd) ? (QL_HELP[i + j * nrows].cmd) : ""));
   if (i + j * nrows < 152)
    fprintf(output, "%s",
      ((QL_HELP[i + j * nrows].cmd) ? (QL_HELP[i + j * nrows].cmd) : ""));
   fputc('\n', output);
  }

  ClosePager(output);
 }
 else
 {
  int i,
     j,
     x = 0;
  bool help_found = ((bool) 0);
  FILE *output = ((void *)0);
  size_t len,
     wordlen;
  int nl_count = 0;





  len = strlen(topic);

  for (x = 1; x <= 3; x++)
  {
   if (x > 1)

   {
    wordlen = j = 1;
    while (topic[j] != ' ' && j++ < len)
     wordlen++;
    if (x == 2)
    {
     j++;
     while (topic[j] != ' ' && j++ <= len)
      wordlen++;
    }
    if (wordlen >= len)
    {
     if (!output)
      output = PageOutput(nl_count, pager);
     break;
    }
    len = wordlen;
   }


   for (i = 0; QL_HELP[i].cmd; i++)
   {
    if (pg_strncasecmp(topic, QL_HELP[i].cmd, len) == 0 ||
     strcmp(topic, "*") == 0)
    {
     nl_count += 5 + QL_HELP[i].nl_count;


     if (pg_strcasecmp(topic, QL_HELP[i].cmd) == 0)
      break;
    }
   }

   if (!output)
    output = PageOutput(nl_count, pager);

   for (i = 0; QL_HELP[i].cmd; i++)
   {
    if (pg_strncasecmp(topic, QL_HELP[i].cmd, len) == 0 ||
     strcmp(topic, "*") == 0)
    {
     PQExpBufferData buffer;

     initPQExpBuffer(&buffer);
     QL_HELP[i].syntaxfunc(&buffer);
     help_found = ((bool) 1);
     fprintf(output, ("Command:     %s\n" "Description: %s\n" "Syntax:\n%s\n\n"),


       QL_HELP[i].cmd,
       (QL_HELP[i].help),
       buffer.data);

     if (pg_strcasecmp(topic, QL_HELP[i].cmd) == 0)
      break;
    }
   }
   if (help_found)
    break;
  }

  if (!help_found)
   fprintf(output, ("No help available for \"%s\".\nTry \\h with no arguments to see available help.\n"), topic);

  ClosePager(output);
 }
}



void
print_copyright(void)
{
 puts(
   "PostgreSQL Database Management System\n"
   "(formerly known as Postgres, then as Postgres95)\n\n"
   "Portions Copyright (c) 1996-2012, PostgreSQL Global Development Group\n\n"
   "Portions Copyright (c) 1994, The Regents of the University of California\n\n"
 "Permission to use, copy, modify, and distribute this software and its\n"
   "documentation for any purpose, without fee, and without a written agreement\n"
  "is hereby granted, provided that the above copyright notice and this\n"
    "paragraph and the following two paragraphs appear in all copies.\n\n"
   "IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR\n"
   "DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING\n"
   "LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS\n"
   "DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE\n"
   "POSSIBILITY OF SUCH DAMAGE.\n\n"
   "THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,\n"
   "INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY\n"
   "AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS\n"
   "ON AN \"AS IS\" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATIONS TO\n"
 "PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.\n"
  );
}

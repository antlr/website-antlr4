# 1 "stem_ISO_8859_1_german.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "stem_ISO_8859_1_german.c"



# 1 "header.h" 1

# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 1 3 4






# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/syslimits.h" 1 3 4
# 8 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 2 3 4







# 1 "/usr/include/limits.h" 1 3 4
# 63 "/usr/include/limits.h" 3 4
# 1 "/usr/include/sys/cdefs.h" 1 3 4
# 417 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 418 "/usr/include/sys/cdefs.h" 2 3 4
# 494 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_posix_availability.h" 1 3 4
# 495 "/usr/include/sys/cdefs.h" 2 3 4
# 64 "/usr/include/limits.h" 2 3 4
# 1 "/usr/include/machine/limits.h" 1 3 4





# 1 "/usr/include/i386/limits.h" 1 3 4
# 40 "/usr/include/i386/limits.h" 3 4
# 1 "/usr/include/i386/_limits.h" 1 3 4
# 41 "/usr/include/i386/limits.h" 2 3 4
# 7 "/usr/include/machine/limits.h" 2 3 4
# 65 "/usr/include/limits.h" 2 3 4
# 1 "/usr/include/sys/syslimits.h" 1 3 4
# 66 "/usr/include/limits.h" 2 3 4
# 16 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 2 3 4
# 3 "header.h" 2

# 1 "api.h" 1

typedef unsigned char symbol;
# 14 "api.h"
struct SN_env {
    symbol * p;
    int c; int l; int lb; int bra; int ket;
    symbol * * S;
    int * I;
    unsigned char * B;
};

extern struct SN_env * SN_create_env(int S_size, int I_size, int B_size);
extern void SN_close_env(struct SN_env * z, int S_size);

extern int SN_set_current(struct SN_env * z, int size, const symbol * s);
# 5 "header.h" 2
# 15 "header.h"
struct among
{ int s_size;
    const symbol * s;
    int substring_i;
    int result;
    int (* function)(struct SN_env *);
};

extern symbol * create_s(void);
extern void lose_s(symbol * p);

extern int skip_utf8(const symbol * p, int c, int lb, int l, int n);

extern int in_grouping_U(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);
extern int in_grouping_b_U(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);
extern int out_grouping_U(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);
extern int out_grouping_b_U(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);

extern int in_grouping(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);
extern int in_grouping_b(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);
extern int out_grouping(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);
extern int out_grouping_b(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);

extern int eq_s(struct SN_env * z, int s_size, const symbol * s);
extern int eq_s_b(struct SN_env * z, int s_size, const symbol * s);
extern int eq_v(struct SN_env * z, const symbol * p);
extern int eq_v_b(struct SN_env * z, const symbol * p);

extern int find_among(struct SN_env * z, const struct among * v, int v_size);
extern int find_among_b(struct SN_env * z, const struct among * v, int v_size);

extern int replace_s(struct SN_env * z, int c_bra, int c_ket, int s_size, const symbol * s, int * adjustment);
extern int slice_from_s(struct SN_env * z, int s_size, const symbol * s);
extern int slice_from_v(struct SN_env * z, const symbol * p);
extern int slice_del(struct SN_env * z);

extern int insert_s(struct SN_env * z, int bra, int ket, int s_size, const symbol * s);
extern int insert_v(struct SN_env * z, int bra, int ket, const symbol * p);

extern symbol * slice_to(struct SN_env * z, symbol * p);
extern symbol * assign_to(struct SN_env * z, symbol * p);

extern void debug(struct SN_env * z, int number, int line_count);
# 5 "stem_ISO_8859_1_german.c" 2




extern int german_ISO_8859_1_stem(struct SN_env * z);



static int r_standard_suffix(struct SN_env * z);
static int r_R2(struct SN_env * z);
static int r_R1(struct SN_env * z);
static int r_mark_regions(struct SN_env * z);
static int r_postlude(struct SN_env * z);
static int r_prelude(struct SN_env * z);





extern struct SN_env * german_ISO_8859_1_create_env(void);
extern void german_ISO_8859_1_close_env(struct SN_env * z);





static const symbol s_0_1[1] = { 'U' };
static const symbol s_0_2[1] = { 'Y' };
static const symbol s_0_3[1] = { 0xE4 };
static const symbol s_0_4[1] = { 0xF6 };
static const symbol s_0_5[1] = { 0xFC };

static const struct among a_0[6] =
{
         { 0, 0, -1, 6, 0},
         { 1, s_0_1, 0, 2, 0},
         { 1, s_0_2, 0, 1, 0},
         { 1, s_0_3, 0, 3, 0},
         { 1, s_0_4, 0, 4, 0},
         { 1, s_0_5, 0, 5, 0}
};

static const symbol s_1_0[1] = { 'e' };
static const symbol s_1_1[2] = { 'e', 'm' };
static const symbol s_1_2[2] = { 'e', 'n' };
static const symbol s_1_3[3] = { 'e', 'r', 'n' };
static const symbol s_1_4[2] = { 'e', 'r' };
static const symbol s_1_5[1] = { 's' };
static const symbol s_1_6[2] = { 'e', 's' };

static const struct among a_1[7] =
{
         { 1, s_1_0, -1, 1, 0},
         { 2, s_1_1, -1, 1, 0},
         { 2, s_1_2, -1, 1, 0},
         { 3, s_1_3, -1, 1, 0},
         { 2, s_1_4, -1, 1, 0},
         { 1, s_1_5, -1, 2, 0},
         { 2, s_1_6, 5, 1, 0}
};

static const symbol s_2_0[2] = { 'e', 'n' };
static const symbol s_2_1[2] = { 'e', 'r' };
static const symbol s_2_2[2] = { 's', 't' };
static const symbol s_2_3[3] = { 'e', 's', 't' };

static const struct among a_2[4] =
{
         { 2, s_2_0, -1, 1, 0},
         { 2, s_2_1, -1, 1, 0},
         { 2, s_2_2, -1, 2, 0},
         { 3, s_2_3, 2, 1, 0}
};

static const symbol s_3_0[2] = { 'i', 'g' };
static const symbol s_3_1[4] = { 'l', 'i', 'c', 'h' };

static const struct among a_3[2] =
{
         { 2, s_3_0, -1, 1, 0},
         { 4, s_3_1, -1, 1, 0}
};

static const symbol s_4_0[3] = { 'e', 'n', 'd' };
static const symbol s_4_1[2] = { 'i', 'g' };
static const symbol s_4_2[3] = { 'u', 'n', 'g' };
static const symbol s_4_3[4] = { 'l', 'i', 'c', 'h' };
static const symbol s_4_4[4] = { 'i', 's', 'c', 'h' };
static const symbol s_4_5[2] = { 'i', 'k' };
static const symbol s_4_6[4] = { 'h', 'e', 'i', 't' };
static const symbol s_4_7[4] = { 'k', 'e', 'i', 't' };

static const struct among a_4[8] =
{
         { 3, s_4_0, -1, 1, 0},
         { 2, s_4_1, -1, 2, 0},
         { 3, s_4_2, -1, 1, 0},
         { 4, s_4_3, -1, 3, 0},
         { 4, s_4_4, -1, 2, 0},
         { 2, s_4_5, -1, 2, 0},
         { 4, s_4_6, -1, 3, 0},
         { 4, s_4_7, -1, 4, 0}
};

static const unsigned char g_v[] = { 17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 32, 8 };

static const unsigned char g_s_ending[] = { 117, 30, 5 };

static const unsigned char g_st_ending[] = { 117, 30, 4 };

static const symbol s_0[] = { 0xDF };
static const symbol s_1[] = { 's', 's' };
static const symbol s_2[] = { 'u' };
static const symbol s_3[] = { 'U' };
static const symbol s_4[] = { 'y' };
static const symbol s_5[] = { 'Y' };
static const symbol s_6[] = { 'y' };
static const symbol s_7[] = { 'u' };
static const symbol s_8[] = { 'a' };
static const symbol s_9[] = { 'o' };
static const symbol s_10[] = { 'u' };
static const symbol s_11[] = { 'i', 'g' };
static const symbol s_12[] = { 'e' };
static const symbol s_13[] = { 'e' };
static const symbol s_14[] = { 'e', 'r' };
static const symbol s_15[] = { 'e', 'n' };

static int r_prelude(struct SN_env * z) {
    { int c_test = z->c;
        while(1) {
            int c1 = z->c;
            { int c2 = z->c;
                z->bra = z->c;
                if (!(eq_s(z, 1, s_0))) goto lab2;
                z->ket = z->c;
                { int ret = slice_from_s(z, 2, s_1);
                    if (ret < 0) return ret;
                }
                goto lab1;
            lab2:
                z->c = c2;
                if (z->c >= z->l) goto lab0;
                z->c++;
            }
        lab1:
            continue;
        lab0:
            z->c = c1;
            break;
        }
        z->c = c_test;
    }
    while(1) {
        int c3 = z->c;
        while(1) {
            int c4 = z->c;
            if (in_grouping(z, g_v, 97, 252, 0)) goto lab4;
            z->bra = z->c;
            { int c5 = z->c;
                if (!(eq_s(z, 1, s_2))) goto lab6;
                z->ket = z->c;
                if (in_grouping(z, g_v, 97, 252, 0)) goto lab6;
                { int ret = slice_from_s(z, 1, s_3);
                    if (ret < 0) return ret;
                }
                goto lab5;
            lab6:
                z->c = c5;
                if (!(eq_s(z, 1, s_4))) goto lab4;
                z->ket = z->c;
                if (in_grouping(z, g_v, 97, 252, 0)) goto lab4;
                { int ret = slice_from_s(z, 1, s_5);
                    if (ret < 0) return ret;
                }
            }
        lab5:
            z->c = c4;
            break;
        lab4:
            z->c = c4;
            if (z->c >= z->l) goto lab3;
            z->c++;
        }
        continue;
    lab3:
        z->c = c3;
        break;
    }
    return 1;
}

static int r_mark_regions(struct SN_env * z) {
    z->I[0] = z->l;
    z->I[1] = z->l;
    { int c_test = z->c;
        { int ret = z->c + 3;
            if (0 > ret || ret > z->l) return 0;
            z->c = ret;
        }
        z->I[2] = z->c;
        z->c = c_test;
    }
    {
        int ret = out_grouping(z, g_v, 97, 252, 1);
        if (ret < 0) return 0;
        z->c += ret;
    }
    {
        int ret = in_grouping(z, g_v, 97, 252, 1);
        if (ret < 0) return 0;
        z->c += ret;
    }
    z->I[0] = z->c;

    if (!(z->I[0] < z->I[2])) goto lab0;
    z->I[0] = z->I[2];
lab0:
    {
        int ret = out_grouping(z, g_v, 97, 252, 1);
        if (ret < 0) return 0;
        z->c += ret;
    }
    {
        int ret = in_grouping(z, g_v, 97, 252, 1);
        if (ret < 0) return 0;
        z->c += ret;
    }
    z->I[1] = z->c;
    return 1;
}

static int r_postlude(struct SN_env * z) {
    int among_var;
    while(1) {
        int c1 = z->c;
        z->bra = z->c;
        among_var = find_among(z, a_0, 6);
        if (!(among_var)) goto lab0;
        z->ket = z->c;
        switch(among_var) {
            case 0: goto lab0;
            case 1:
                { int ret = slice_from_s(z, 1, s_6);
                    if (ret < 0) return ret;
                }
                break;
            case 2:
                { int ret = slice_from_s(z, 1, s_7);
                    if (ret < 0) return ret;
                }
                break;
            case 3:
                { int ret = slice_from_s(z, 1, s_8);
                    if (ret < 0) return ret;
                }
                break;
            case 4:
                { int ret = slice_from_s(z, 1, s_9);
                    if (ret < 0) return ret;
                }
                break;
            case 5:
                { int ret = slice_from_s(z, 1, s_10);
                    if (ret < 0) return ret;
                }
                break;
            case 6:
                if (z->c >= z->l) goto lab0;
                z->c++;
                break;
        }
        continue;
    lab0:
        z->c = c1;
        break;
    }
    return 1;
}

static int r_R1(struct SN_env * z) {
    if (!(z->I[0] <= z->c)) return 0;
    return 1;
}

static int r_R2(struct SN_env * z) {
    if (!(z->I[1] <= z->c)) return 0;
    return 1;
}

static int r_standard_suffix(struct SN_env * z) {
    int among_var;
    { int m1 = z->l - z->c; (void)m1;
        z->ket = z->c;
        if (z->c <= z->lb || z->p[z->c - 1] >> 5 != 3 || !((811040 >> (z->p[z->c - 1] & 0x1f)) & 1)) goto lab0;
        among_var = find_among_b(z, a_1, 7);
        if (!(among_var)) goto lab0;
        z->bra = z->c;
        { int ret = r_R1(z);
            if (ret == 0) goto lab0;
            if (ret < 0) return ret;
        }
        switch(among_var) {
            case 0: goto lab0;
            case 1:
                { int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                break;
            case 2:
                if (in_grouping_b(z, g_s_ending, 98, 116, 0)) goto lab0;
                { int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                break;
        }
    lab0:
        z->c = z->l - m1;
    }
    { int m2 = z->l - z->c; (void)m2;
        z->ket = z->c;
        if (z->c - 1 <= z->lb || z->p[z->c - 1] >> 5 != 3 || !((1327104 >> (z->p[z->c - 1] & 0x1f)) & 1)) goto lab1;
        among_var = find_among_b(z, a_2, 4);
        if (!(among_var)) goto lab1;
        z->bra = z->c;
        { int ret = r_R1(z);
            if (ret == 0) goto lab1;
            if (ret < 0) return ret;
        }
        switch(among_var) {
            case 0: goto lab1;
            case 1:
                { int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                break;
            case 2:
                if (in_grouping_b(z, g_st_ending, 98, 116, 0)) goto lab1;
                { int ret = z->c - 3;
                    if (z->lb > ret || ret > z->l) goto lab1;
                    z->c = ret;
                }
                { int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                break;
        }
    lab1:
        z->c = z->l - m2;
    }
    { int m3 = z->l - z->c; (void)m3;
        z->ket = z->c;
        if (z->c - 1 <= z->lb || z->p[z->c - 1] >> 5 != 3 || !((1051024 >> (z->p[z->c - 1] & 0x1f)) & 1)) goto lab2;
        among_var = find_among_b(z, a_4, 8);
        if (!(among_var)) goto lab2;
        z->bra = z->c;
        { int ret = r_R2(z);
            if (ret == 0) goto lab2;
            if (ret < 0) return ret;
        }
        switch(among_var) {
            case 0: goto lab2;
            case 1:
                { int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                { int m_keep = z->l - z->c;
                    z->ket = z->c;
                    if (!(eq_s_b(z, 2, s_11))) { z->c = z->l - m_keep; goto lab3; }
                    z->bra = z->c;
                    { int m4 = z->l - z->c; (void)m4;
                        if (!(eq_s_b(z, 1, s_12))) goto lab4;
                        { z->c = z->l - m_keep; goto lab3; }
                    lab4:
                        z->c = z->l - m4;
                    }
                    { int ret = r_R2(z);
                        if (ret == 0) { z->c = z->l - m_keep; goto lab3; }
                        if (ret < 0) return ret;
                    }
                    { int ret = slice_del(z);
                        if (ret < 0) return ret;
                    }
                lab3:
                    ;
                }
                break;
            case 2:
                { int m5 = z->l - z->c; (void)m5;
                    if (!(eq_s_b(z, 1, s_13))) goto lab5;
                    goto lab2;
                lab5:
                    z->c = z->l - m5;
                }
                { int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                break;
            case 3:
                { int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                { int m_keep = z->l - z->c;
                    z->ket = z->c;
                    { int m6 = z->l - z->c; (void)m6;
                        if (!(eq_s_b(z, 2, s_14))) goto lab8;
                        goto lab7;
                    lab8:
                        z->c = z->l - m6;
                        if (!(eq_s_b(z, 2, s_15))) { z->c = z->l - m_keep; goto lab6; }
                    }
                lab7:
                    z->bra = z->c;
                    { int ret = r_R1(z);
                        if (ret == 0) { z->c = z->l - m_keep; goto lab6; }
                        if (ret < 0) return ret;
                    }
                    { int ret = slice_del(z);
                        if (ret < 0) return ret;
                    }
                lab6:
                    ;
                }
                break;
            case 4:
                { int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                { int m_keep = z->l - z->c;
                    z->ket = z->c;
                    if (z->c - 1 <= z->lb || (z->p[z->c - 1] != 103 && z->p[z->c - 1] != 104)) { z->c = z->l - m_keep; goto lab9; }
                    among_var = find_among_b(z, a_3, 2);
                    if (!(among_var)) { z->c = z->l - m_keep; goto lab9; }
                    z->bra = z->c;
                    { int ret = r_R2(z);
                        if (ret == 0) { z->c = z->l - m_keep; goto lab9; }
                        if (ret < 0) return ret;
                    }
                    switch(among_var) {
                        case 0: { z->c = z->l - m_keep; goto lab9; }
                        case 1:
                            { int ret = slice_del(z);
                                if (ret < 0) return ret;
                            }
                            break;
                    }
                lab9:
                    ;
                }
                break;
        }
    lab2:
        z->c = z->l - m3;
    }
    return 1;
}

extern int german_ISO_8859_1_stem(struct SN_env * z) {
    { int c1 = z->c;
        { int ret = r_prelude(z);
            if (ret == 0) goto lab0;
            if (ret < 0) return ret;
        }
    lab0:
        z->c = c1;
    }
    { int c2 = z->c;
        { int ret = r_mark_regions(z);
            if (ret == 0) goto lab1;
            if (ret < 0) return ret;
        }
    lab1:
        z->c = c2;
    }
    z->lb = z->c; z->c = z->l;

    { int m3 = z->l - z->c; (void)m3;
        { int ret = r_standard_suffix(z);
            if (ret == 0) goto lab2;
            if (ret < 0) return ret;
        }
    lab2:
        z->c = z->l - m3;
    }
    z->c = z->lb;
    { int c4 = z->c;
        { int ret = r_postlude(z);
            if (ret == 0) goto lab3;
            if (ret < 0) return ret;
        }
    lab3:
        z->c = c4;
    }
    return 1;
}

extern struct SN_env * german_ISO_8859_1_create_env(void) { return SN_create_env(0, 3, 0); }

extern void german_ISO_8859_1_close_env(struct SN_env * z) { SN_close_env(z, 0); }

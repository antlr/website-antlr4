# 1 "tablespace.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "tablespace.c"
# 47 "tablespace.c"
# 1 "postgres.h" 1
# 47 "postgres.h"
# 1 "c.h" 1
# 53 "c.h"
# 1 "pg_config.h" 1
# 54 "c.h" 2
# 1 "pg_config_manual.h" 1
# 55 "c.h" 2


# 1 "pg_config_os.h" 1
# 58 "c.h" 2

# 1 "postgres_ext.h" 1
# 29 "postgres_ext.h"
typedef unsigned int Oid;
# 60 "c.h" 2







# 1 "/usr/include/stdio.h" 1 3 4
# 64 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/sys/cdefs.h" 1 3 4
# 417 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 418 "/usr/include/sys/cdefs.h" 2 3 4
# 494 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_posix_availability.h" 1 3 4
# 495 "/usr/include/sys/cdefs.h" 2 3 4
# 65 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/Availability.h" 1 3 4
# 141 "/usr/include/Availability.h" 3 4
# 1 "/usr/include/AvailabilityInternal.h" 1 3 4
# 142 "/usr/include/Availability.h" 2 3 4
# 66 "/usr/include/stdio.h" 2 3 4

# 1 "/usr/include/_types.h" 1 3 4
# 27 "/usr/include/_types.h" 3 4
# 1 "/usr/include/sys/_types.h" 1 3 4
# 33 "/usr/include/sys/_types.h" 3 4
# 1 "/usr/include/machine/_types.h" 1 3 4
# 32 "/usr/include/machine/_types.h" 3 4
# 1 "/usr/include/i386/_types.h" 1 3 4
# 37 "/usr/include/i386/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 70 "/usr/include/i386/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;


typedef long int __darwin_ptrdiff_t;





typedef long unsigned int __darwin_size_t;





typedef __builtin_va_list __darwin_va_list;





typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 33 "/usr/include/machine/_types.h" 2 3 4
# 34 "/usr/include/sys/_types.h" 2 3 4
# 58 "/usr/include/sys/_types.h" 3 4
struct __darwin_pthread_handler_rec
{
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};
struct _opaque_pthread_attr_t { long __sig; char __opaque[56]; };
struct _opaque_pthread_cond_t { long __sig; char __opaque[40]; };
struct _opaque_pthread_condattr_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_mutex_t { long __sig; char __opaque[56]; };
struct _opaque_pthread_mutexattr_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_once_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_rwlock_t { long __sig; char __opaque[192]; };
struct _opaque_pthread_rwlockattr_t { long __sig; char __opaque[16]; };
struct _opaque_pthread_t { long __sig; struct __darwin_pthread_handler_rec *__cleanup_stack; char __opaque[1168]; };
# 94 "/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef struct _opaque_pthread_attr_t
   __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t
   __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t
   __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t
   __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t
   __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t
   __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t
   __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t
   __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t
   *__darwin_pthread_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];
# 28 "/usr/include/_types.h" 2 3 4
# 39 "/usr/include/_types.h" 3 4
typedef int __darwin_nl_item;
typedef int __darwin_wctrans_t;

typedef __uint32_t __darwin_wctype_t;
# 68 "/usr/include/stdio.h" 2 3 4





typedef __darwin_va_list va_list;




typedef __darwin_size_t size_t;






typedef __darwin_off_t fpos_t;
# 96 "/usr/include/stdio.h" 3 4
struct __sbuf {
 unsigned char *_base;
 int _size;
};


struct __sFILEX;
# 130 "/usr/include/stdio.h" 3 4
typedef struct __sFILE {
 unsigned char *_p;
 int _r;
 int _w;
 short _flags;
 short _file;
 struct __sbuf _bf;
 int _lbfsize;


 void *_cookie;
 int (*_close)(void *);
 int (*_read) (void *, char *, int);
 fpos_t (*_seek) (void *, fpos_t, int);
 int (*_write)(void *, const char *, int);


 struct __sbuf _ub;
 struct __sFILEX *_extra;
 int _ur;


 unsigned char _ubuf[3];
 unsigned char _nbuf[1];


 struct __sbuf _lb;


 int _blksize;
 fpos_t _offset;
} FILE;


extern FILE *__stdinp;
extern FILE *__stdoutp;
extern FILE *__stderrp;

# 238 "/usr/include/stdio.h" 3 4

void clearerr(FILE *);
int fclose(FILE *);
int feof(FILE *);
int ferror(FILE *);
int fflush(FILE *);
int fgetc(FILE *);
int fgetpos(FILE * , fpos_t *);
char *fgets(char * , int, FILE *);



FILE *fopen(const char * , const char * ) __asm("_" "fopen" );

int fprintf(FILE * , const char * , ...) __attribute__((__format__ (__printf__, 2, 3)));
int fputc(int, FILE *);
int fputs(const char * , FILE * ) __asm("_" "fputs" );
size_t fread(void * , size_t, size_t, FILE * );
FILE *freopen(const char * , const char * ,
                 FILE * ) __asm("_" "freopen" );
int fscanf(FILE * , const char * , ...) __attribute__((__format__ (__scanf__, 2, 3)));
int fseek(FILE *, long, int);
int fsetpos(FILE *, const fpos_t *);
long ftell(FILE *);
size_t fwrite(const void * , size_t, size_t, FILE * ) __asm("_" "fwrite" );
int getc(FILE *);
int getchar(void);
char *gets(char *);
void perror(const char *);
int printf(const char * , ...) __attribute__((__format__ (__printf__, 1, 2)));
int putc(int, FILE *);
int putchar(int);
int puts(const char *);
int remove(const char *);
int rename (const char *, const char *);
void rewind(FILE *);
int scanf(const char * , ...) __attribute__((__format__ (__scanf__, 1, 2)));
void setbuf(FILE * , char * );
int setvbuf(FILE * , char * , int, size_t);
int sprintf(char * , const char * , ...) __attribute__((__format__ (__printf__, 2, 3)));
int sscanf(const char * , const char * , ...) __attribute__((__format__ (__scanf__, 2, 3)));
FILE *tmpfile(void);
char *tmpnam(char *);
int ungetc(int, FILE *);
int vfprintf(FILE * , const char * , va_list) __attribute__((__format__ (__printf__, 2, 0)));
int vprintf(const char * , va_list) __attribute__((__format__ (__printf__, 1, 0)));
int vsprintf(char * , const char * , va_list) __attribute__((__format__ (__printf__, 2, 0)));

# 296 "/usr/include/stdio.h" 3 4




char *ctermid(char *);





FILE *fdopen(int, const char *) __asm("_" "fdopen" );

int fileno(FILE *);

# 318 "/usr/include/stdio.h" 3 4

int pclose(FILE *);



FILE *popen(const char *, const char *) __asm("_" "popen" );


# 340 "/usr/include/stdio.h" 3 4

int __srget(FILE *);
int __svfscanf(FILE *, const char *, va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int __swbuf(int, FILE *);








static __inline int __sputc(int _c, FILE *_p) {
 if (--_p->_w >= 0 || (_p->_w >= _p->_lbfsize && (char)_c != '\n'))
  return (*_p->_p++ = _c);
 else
  return (__swbuf(_c, _p));
}
# 377 "/usr/include/stdio.h" 3 4

void flockfile(FILE *);
int ftrylockfile(FILE *);
void funlockfile(FILE *);
int getc_unlocked(FILE *);
int getchar_unlocked(void);
int putc_unlocked(int, FILE *);
int putchar_unlocked(int);



int getw(FILE *);
int putw(int, FILE *);


char *tempnam(const char *, const char *) __asm("_" "tempnam" );

# 414 "/usr/include/stdio.h" 3 4
typedef __darwin_off_t off_t;



int fseeko(FILE *, off_t, int);
off_t ftello(FILE *);





int snprintf(char * , size_t, const char * , ...) __attribute__((__format__ (__printf__, 3, 4)));
int vfscanf(FILE * , const char * , va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int vscanf(const char * , va_list) __attribute__((__format__ (__scanf__, 1, 0)));
int vsnprintf(char * , size_t, const char * , va_list) __attribute__((__format__ (__printf__, 3, 0)));
int vsscanf(const char * , const char * , va_list) __attribute__((__format__ (__scanf__, 2, 0)));

# 442 "/usr/include/stdio.h" 3 4
typedef __darwin_ssize_t ssize_t;



int dprintf(int, const char * , ...) __attribute__((__format__ (__printf__, 2, 3))) __attribute__((visibility("default")));
int vdprintf(int, const char * , va_list) __attribute__((__format__ (__printf__, 2, 0))) __attribute__((visibility("default")));
ssize_t getdelim(char ** , size_t * , int, FILE * ) __attribute__((visibility("default")));
ssize_t getline(char ** , size_t * , FILE * ) __attribute__((visibility("default")));









extern const int sys_nerr;
extern const char *const sys_errlist[];

int asprintf(char **, const char *, ...) __attribute__((__format__ (__printf__, 2, 3)));
char *ctermid_r(char *);
char *fgetln(FILE *, size_t *);
const char *fmtcheck(const char *, const char *);
int fpurge(FILE *);
void setbuffer(FILE *, char *, int);
int setlinebuf(FILE *);
int vasprintf(char **, const char *, va_list) __attribute__((__format__ (__printf__, 2, 0)));
FILE *zopen(const char *, const char *, int);





FILE *funopen(const void *,
                 int (*)(void *, char *, int),
                 int (*)(void *, const char *, int),
                 fpos_t (*)(void *, fpos_t, int),
                 int (*)(void *));

# 499 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/secure/_stdio.h" 1 3 4
# 31 "/usr/include/secure/_stdio.h" 3 4
# 1 "/usr/include/secure/_common.h" 1 3 4
# 32 "/usr/include/secure/_stdio.h" 2 3 4
# 45 "/usr/include/secure/_stdio.h" 3 4
extern int __sprintf_chk (char * , int, size_t,
     const char * , ...)
  ;




extern int __snprintf_chk (char * , size_t, int, size_t,
      const char * , ...)
  ;





extern int __vsprintf_chk (char * , int, size_t,
      const char * , va_list)
  ;




extern int __vsnprintf_chk (char * , size_t, int, size_t,
       const char * , va_list)
  ;
# 500 "/usr/include/stdio.h" 2 3 4
# 68 "c.h" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 65 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/sys/wait.h" 1 3 4
# 79 "/usr/include/sys/wait.h" 3 4
typedef enum {
 P_ALL,
 P_PID,
 P_PGID
} idtype_t;






typedef __darwin_pid_t pid_t;




typedef __darwin_id_t id_t;
# 116 "/usr/include/sys/wait.h" 3 4
# 1 "/usr/include/sys/signal.h" 1 3 4
# 73 "/usr/include/sys/signal.h" 3 4
# 1 "/usr/include/sys/appleapiopts.h" 1 3 4
# 74 "/usr/include/sys/signal.h" 2 3 4







# 1 "/usr/include/machine/signal.h" 1 3 4
# 32 "/usr/include/machine/signal.h" 3 4
# 1 "/usr/include/i386/signal.h" 1 3 4
# 39 "/usr/include/i386/signal.h" 3 4
typedef int sig_atomic_t;
# 55 "/usr/include/i386/signal.h" 3 4
# 1 "/usr/include/i386/_structs.h" 1 3 4
# 56 "/usr/include/i386/signal.h" 2 3 4
# 33 "/usr/include/machine/signal.h" 2 3 4
# 82 "/usr/include/sys/signal.h" 2 3 4
# 148 "/usr/include/sys/signal.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 57 "/usr/include/sys/_structs.h" 3 4
# 1 "/usr/include/machine/_structs.h" 1 3 4
# 29 "/usr/include/machine/_structs.h" 3 4
# 1 "/usr/include/i386/_structs.h" 1 3 4
# 38 "/usr/include/i386/_structs.h" 3 4
# 1 "/usr/include/mach/i386/_structs.h" 1 3 4
# 43 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_thread_state
{
    unsigned int __eax;
    unsigned int __ebx;
    unsigned int __ecx;
    unsigned int __edx;
    unsigned int __edi;
    unsigned int __esi;
    unsigned int __ebp;
    unsigned int __esp;
    unsigned int __ss;
    unsigned int __eflags;
    unsigned int __eip;
    unsigned int __cs;
    unsigned int __ds;
    unsigned int __es;
    unsigned int __fs;
    unsigned int __gs;
};
# 89 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_fp_control
{
    unsigned short __invalid :1,
        __denorm :1,
    __zdiv :1,
    __ovrfl :1,
    __undfl :1,
    __precis :1,
      :2,
    __pc :2,





    __rc :2,






             :1,
      :3;
};
typedef struct __darwin_fp_control __darwin_fp_control_t;
# 147 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_fp_status
{
    unsigned short __invalid :1,
        __denorm :1,
    __zdiv :1,
    __ovrfl :1,
    __undfl :1,
    __precis :1,
    __stkflt :1,
    __errsumm :1,
    __c0 :1,
    __c1 :1,
    __c2 :1,
    __tos :3,
    __c3 :1,
    __busy :1;
};
typedef struct __darwin_fp_status __darwin_fp_status_t;
# 191 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_mmst_reg
{
 char __mmst_reg[10];
 char __mmst_rsrv[6];
};
# 210 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_xmm_reg
{
 char __xmm_reg[16];
};
# 232 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_float_state
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;
 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;
 __uint16_t __fpu_rsrv2;
 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;
 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 char __fpu_rsrv4[14*16];
 int __fpu_reserved1;
};


struct __darwin_i386_avx_state
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;
 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;
 __uint16_t __fpu_rsrv2;
 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;
 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 char __fpu_rsrv4[14*16];
 int __fpu_reserved1;
 char __avx_reserved1[64];
 struct __darwin_xmm_reg __fpu_ymmh0;
 struct __darwin_xmm_reg __fpu_ymmh1;
 struct __darwin_xmm_reg __fpu_ymmh2;
 struct __darwin_xmm_reg __fpu_ymmh3;
 struct __darwin_xmm_reg __fpu_ymmh4;
 struct __darwin_xmm_reg __fpu_ymmh5;
 struct __darwin_xmm_reg __fpu_ymmh6;
 struct __darwin_xmm_reg __fpu_ymmh7;
};
# 402 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_exception_state
{
 __uint16_t __trapno;
 __uint16_t __cpu;
 __uint32_t __err;
 __uint32_t __faultvaddr;
};
# 422 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_debug_state32
{
 unsigned int __dr0;
 unsigned int __dr1;
 unsigned int __dr2;
 unsigned int __dr3;
 unsigned int __dr4;
 unsigned int __dr5;
 unsigned int __dr6;
 unsigned int __dr7;
};
# 454 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_thread_state64
{
 __uint64_t __rax;
 __uint64_t __rbx;
 __uint64_t __rcx;
 __uint64_t __rdx;
 __uint64_t __rdi;
 __uint64_t __rsi;
 __uint64_t __rbp;
 __uint64_t __rsp;
 __uint64_t __r8;
 __uint64_t __r9;
 __uint64_t __r10;
 __uint64_t __r11;
 __uint64_t __r12;
 __uint64_t __r13;
 __uint64_t __r14;
 __uint64_t __r15;
 __uint64_t __rip;
 __uint64_t __rflags;
 __uint64_t __cs;
 __uint64_t __fs;
 __uint64_t __gs;
};
# 509 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_float_state64
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;


 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;

 __uint16_t __fpu_rsrv2;


 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;

 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 struct __darwin_xmm_reg __fpu_xmm8;
 struct __darwin_xmm_reg __fpu_xmm9;
 struct __darwin_xmm_reg __fpu_xmm10;
 struct __darwin_xmm_reg __fpu_xmm11;
 struct __darwin_xmm_reg __fpu_xmm12;
 struct __darwin_xmm_reg __fpu_xmm13;
 struct __darwin_xmm_reg __fpu_xmm14;
 struct __darwin_xmm_reg __fpu_xmm15;
 char __fpu_rsrv4[6*16];
 int __fpu_reserved1;
};


struct __darwin_x86_avx_state64
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;


 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;

 __uint16_t __fpu_rsrv2;


 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;

 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 struct __darwin_xmm_reg __fpu_xmm8;
 struct __darwin_xmm_reg __fpu_xmm9;
 struct __darwin_xmm_reg __fpu_xmm10;
 struct __darwin_xmm_reg __fpu_xmm11;
 struct __darwin_xmm_reg __fpu_xmm12;
 struct __darwin_xmm_reg __fpu_xmm13;
 struct __darwin_xmm_reg __fpu_xmm14;
 struct __darwin_xmm_reg __fpu_xmm15;
 char __fpu_rsrv4[6*16];
 int __fpu_reserved1;
 char __avx_reserved1[64];
 struct __darwin_xmm_reg __fpu_ymmh0;
 struct __darwin_xmm_reg __fpu_ymmh1;
 struct __darwin_xmm_reg __fpu_ymmh2;
 struct __darwin_xmm_reg __fpu_ymmh3;
 struct __darwin_xmm_reg __fpu_ymmh4;
 struct __darwin_xmm_reg __fpu_ymmh5;
 struct __darwin_xmm_reg __fpu_ymmh6;
 struct __darwin_xmm_reg __fpu_ymmh7;
 struct __darwin_xmm_reg __fpu_ymmh8;
 struct __darwin_xmm_reg __fpu_ymmh9;
 struct __darwin_xmm_reg __fpu_ymmh10;
 struct __darwin_xmm_reg __fpu_ymmh11;
 struct __darwin_xmm_reg __fpu_ymmh12;
 struct __darwin_xmm_reg __fpu_ymmh13;
 struct __darwin_xmm_reg __fpu_ymmh14;
 struct __darwin_xmm_reg __fpu_ymmh15;
};
# 751 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_exception_state64
{
    __uint16_t __trapno;
    __uint16_t __cpu;
    __uint32_t __err;
    __uint64_t __faultvaddr;
};
# 771 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_debug_state64
{
 __uint64_t __dr0;
 __uint64_t __dr1;
 __uint64_t __dr2;
 __uint64_t __dr3;
 __uint64_t __dr4;
 __uint64_t __dr5;
 __uint64_t __dr6;
 __uint64_t __dr7;
};
# 39 "/usr/include/i386/_structs.h" 2 3 4
# 48 "/usr/include/i386/_structs.h" 3 4
struct __darwin_mcontext32
{
 struct __darwin_i386_exception_state __es;
 struct __darwin_i386_thread_state __ss;
 struct __darwin_i386_float_state __fs;
};


struct __darwin_mcontext_avx32
{
 struct __darwin_i386_exception_state __es;
 struct __darwin_i386_thread_state __ss;
 struct __darwin_i386_avx_state __fs;
};
# 86 "/usr/include/i386/_structs.h" 3 4
struct __darwin_mcontext64
{
 struct __darwin_x86_exception_state64 __es;
 struct __darwin_x86_thread_state64 __ss;
 struct __darwin_x86_float_state64 __fs;
};


struct __darwin_mcontext_avx64
{
 struct __darwin_x86_exception_state64 __es;
 struct __darwin_x86_thread_state64 __ss;
 struct __darwin_x86_avx_state64 __fs;
};
# 127 "/usr/include/i386/_structs.h" 3 4
typedef struct __darwin_mcontext64 *mcontext_t;
# 30 "/usr/include/machine/_structs.h" 2 3 4
# 58 "/usr/include/sys/_structs.h" 2 3 4
# 75 "/usr/include/sys/_structs.h" 3 4
struct __darwin_sigaltstack
{
 void *ss_sp;
 __darwin_size_t ss_size;
 int ss_flags;
};
# 128 "/usr/include/sys/_structs.h" 3 4
struct __darwin_ucontext
{
 int uc_onstack;
 __darwin_sigset_t uc_sigmask;
 struct __darwin_sigaltstack uc_stack;
 struct __darwin_ucontext *uc_link;
 __darwin_size_t uc_mcsize;
 struct __darwin_mcontext64 *uc_mcontext;



};
# 218 "/usr/include/sys/_structs.h" 3 4
typedef struct __darwin_sigaltstack stack_t;
# 227 "/usr/include/sys/_structs.h" 3 4
typedef struct __darwin_ucontext ucontext_t;
# 149 "/usr/include/sys/signal.h" 2 3 4
# 157 "/usr/include/sys/signal.h" 3 4
typedef __darwin_pthread_attr_t pthread_attr_t;




typedef __darwin_sigset_t sigset_t;
# 172 "/usr/include/sys/signal.h" 3 4
typedef __darwin_uid_t uid_t;


union sigval {

 int sival_int;
 void *sival_ptr;
};





struct sigevent {
 int sigev_notify;
 int sigev_signo;
 union sigval sigev_value;
 void (*sigev_notify_function)(union sigval);
 pthread_attr_t *sigev_notify_attributes;
};


typedef struct __siginfo {
 int si_signo;
 int si_errno;
 int si_code;
 pid_t si_pid;
 uid_t si_uid;
 int si_status;
 void *si_addr;
 union sigval si_value;
 long si_band;
 unsigned long __pad[7];
} siginfo_t;
# 286 "/usr/include/sys/signal.h" 3 4
union __sigaction_u {
 void (*__sa_handler)(int);
 void (*__sa_sigaction)(int, struct __siginfo *,
         void *);
};


struct __sigaction {
 union __sigaction_u __sigaction_u;
 void (*sa_tramp)(void *, int, int, siginfo_t *, void *);
 sigset_t sa_mask;
 int sa_flags;
};




struct sigaction {
 union __sigaction_u __sigaction_u;
 sigset_t sa_mask;
 int sa_flags;
};
# 348 "/usr/include/sys/signal.h" 3 4
typedef void (*sig_t)(int);
# 365 "/usr/include/sys/signal.h" 3 4
struct sigvec {
 void (*sv_handler)(int);
 int sv_mask;
 int sv_flags;
};
# 384 "/usr/include/sys/signal.h" 3 4
struct sigstack {
 char *ss_sp;
 int ss_onstack;
};
# 406 "/usr/include/sys/signal.h" 3 4

void (*signal(int, void (*)(int)))(int);

# 117 "/usr/include/sys/wait.h" 2 3 4
# 1 "/usr/include/sys/resource.h" 1 3 4
# 77 "/usr/include/sys/resource.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 100 "/usr/include/sys/_structs.h" 3 4
struct timeval
{
 __darwin_time_t tv_sec;
 __darwin_suseconds_t tv_usec;
};
# 78 "/usr/include/sys/resource.h" 2 3 4
# 89 "/usr/include/sys/resource.h" 3 4
typedef __uint64_t rlim_t;
# 151 "/usr/include/sys/resource.h" 3 4
struct rusage {
 struct timeval ru_utime;
 struct timeval ru_stime;
# 162 "/usr/include/sys/resource.h" 3 4
 long ru_maxrss;

 long ru_ixrss;
 long ru_idrss;
 long ru_isrss;
 long ru_minflt;
 long ru_majflt;
 long ru_nswap;
 long ru_inblock;
 long ru_oublock;
 long ru_msgsnd;
 long ru_msgrcv;
 long ru_nsignals;
 long ru_nvcsw;
 long ru_nivcsw;


};
# 222 "/usr/include/sys/resource.h" 3 4
struct rlimit {
 rlim_t rlim_cur;
 rlim_t rlim_max;
};
# 244 "/usr/include/sys/resource.h" 3 4

int getpriority(int, id_t);

int getiopolicy_np(int, int) __attribute__((visibility("default")));

int getrlimit(int, struct rlimit *) __asm("_" "getrlimit" );
int getrusage(int, struct rusage *);
int setpriority(int, id_t, int);

int setiopolicy_np(int, int, int) __attribute__((visibility("default")));

int setrlimit(int, const struct rlimit *) __asm("_" "setrlimit" );

# 118 "/usr/include/sys/wait.h" 2 3 4
# 193 "/usr/include/sys/wait.h" 3 4
# 1 "/usr/include/machine/endian.h" 1 3 4
# 35 "/usr/include/machine/endian.h" 3 4
# 1 "/usr/include/i386/endian.h" 1 3 4
# 99 "/usr/include/i386/endian.h" 3 4
# 1 "/usr/include/sys/_endian.h" 1 3 4
# 124 "/usr/include/sys/_endian.h" 3 4
# 1 "/usr/include/libkern/_OSByteOrder.h" 1 3 4
# 66 "/usr/include/libkern/_OSByteOrder.h" 3 4
# 1 "/usr/include/libkern/i386/_OSByteOrder.h" 1 3 4
# 44 "/usr/include/libkern/i386/_OSByteOrder.h" 3 4
static __inline__
__uint16_t
_OSSwapInt16(
    __uint16_t _data
)
{
    return ((_data << 8) | (_data >> 8));
}

static __inline__
__uint32_t
_OSSwapInt32(
    __uint32_t _data
)
{

    return __builtin_bswap32(_data);




}


static __inline__
__uint64_t
_OSSwapInt64(
    __uint64_t _data
)
{
    return __builtin_bswap64(_data);
}
# 67 "/usr/include/libkern/_OSByteOrder.h" 2 3 4
# 125 "/usr/include/sys/_endian.h" 2 3 4
# 100 "/usr/include/i386/endian.h" 2 3 4
# 36 "/usr/include/machine/endian.h" 2 3 4
# 194 "/usr/include/sys/wait.h" 2 3 4







union wait {
 int w_status;



 struct {

  unsigned int w_Termsig:7,
    w_Coredump:1,
    w_Retcode:8,
    w_Filler:16;







 } w_T;





 struct {

  unsigned int w_Stopval:8,
    w_Stopsig:8,
    w_Filler:16;






 } w_S;
};
# 254 "/usr/include/sys/wait.h" 3 4

pid_t wait(int *) __asm("_" "wait" );
pid_t waitpid(pid_t, int *, int) __asm("_" "waitpid" );

int waitid(idtype_t, id_t, siginfo_t *, int) __asm("_" "waitid" );


pid_t wait3(int *, int, struct rusage *);
pid_t wait4(pid_t, int *, int, struct rusage *);


# 66 "/usr/include/stdlib.h" 2 3 4

# 1 "/usr/include/alloca.h" 1 3 4
# 35 "/usr/include/alloca.h" 3 4

void *alloca(size_t);

# 68 "/usr/include/stdlib.h" 2 3 4
# 81 "/usr/include/stdlib.h" 3 4
typedef __darwin_ct_rune_t ct_rune_t;




typedef __darwin_rune_t rune_t;






typedef __darwin_wchar_t wchar_t;



typedef struct {
 int quot;
 int rem;
} div_t;

typedef struct {
 long quot;
 long rem;
} ldiv_t;


typedef struct {
 long long quot;
 long long rem;
} lldiv_t;
# 134 "/usr/include/stdlib.h" 3 4
extern int __mb_cur_max;
# 144 "/usr/include/stdlib.h" 3 4

void abort(void) __attribute__((__noreturn__));
int abs(int) __attribute__((__const__));
int atexit(void (*)(void));
double atof(const char *);
int atoi(const char *);
long atol(const char *);

long long
  atoll(const char *);

void *bsearch(const void *, const void *, size_t,
     size_t, int (*)(const void *, const void *));
void *calloc(size_t, size_t);
div_t div(int, int) __attribute__((__const__));
void exit(int) __attribute__((__noreturn__));
void free(void *);
char *getenv(const char *);
long labs(long) __attribute__((__const__));
ldiv_t ldiv(long, long) __attribute__((__const__));

long long
  llabs(long long);
lldiv_t lldiv(long long, long long);

void *malloc(size_t);
int mblen(const char *, size_t);
size_t mbstowcs(wchar_t * , const char * , size_t);
int mbtowc(wchar_t * , const char * , size_t);
int posix_memalign(void **, size_t, size_t) __attribute__((visibility("default")));
void qsort(void *, size_t, size_t,
     int (*)(const void *, const void *));
int rand(void);
void *realloc(void *, size_t);
void srand(unsigned);
double strtod(const char *, char **) __asm("_" "strtod" );
float strtof(const char *, char **) __asm("_" "strtof" );
long strtol(const char *, char **, int);
long double
  strtold(const char *, char **) ;

long long
  strtoll(const char *, char **, int);

unsigned long
  strtoul(const char *, char **, int);

unsigned long long
  strtoull(const char *, char **, int);

int system(const char *) __asm("_" "system" );
size_t wcstombs(char * , const wchar_t * , size_t);
int wctomb(char *, wchar_t);


void _Exit(int) __attribute__((__noreturn__));
long a64l(const char *);
double drand48(void);
char *ecvt(double, int, int *, int *);
double erand48(unsigned short[3]);
char *fcvt(double, int, int *, int *);
char *gcvt(double, int, char *);
int getsubopt(char **, char * const *, char **);
int grantpt(int);

char *initstate(unsigned, char *, size_t);



long jrand48(unsigned short[3]);
char *l64a(long);
void lcong48(unsigned short[7]);
long lrand48(void);
char *mktemp(char *);
int mkstemp(char *);
long mrand48(void);
long nrand48(unsigned short[3]);
int posix_openpt(int);
char *ptsname(int);
int putenv(char *) __asm("_" "putenv" );
long random(void);
int rand_r(unsigned *);

char *realpath(const char * , char * ) __asm("_" "realpath" "$DARWIN_EXTSN");



unsigned short
 *seed48(unsigned short[3]);
int setenv(const char *, const char *, int) __asm("_" "setenv" );

void setkey(const char *) __asm("_" "setkey" );



char *setstate(const char *);
void srand48(long);

void srandom(unsigned);



int unlockpt(int);

int unsetenv(const char *) __asm("_" "unsetenv" );






# 1 "/usr/include/machine/types.h" 1 3 4
# 35 "/usr/include/machine/types.h" 3 4
# 1 "/usr/include/i386/types.h" 1 3 4
# 70 "/usr/include/i386/types.h" 3 4
# 1 "/usr/include/i386/_types.h" 1 3 4
# 71 "/usr/include/i386/types.h" 2 3 4







typedef signed char int8_t;

typedef unsigned char u_int8_t;


typedef short int16_t;

typedef unsigned short u_int16_t;


typedef int int32_t;

typedef unsigned int u_int32_t;


typedef long long int64_t;

typedef unsigned long long u_int64_t;


typedef int64_t register_t;






typedef __darwin_intptr_t intptr_t;



typedef unsigned long uintptr_t;




typedef u_int64_t user_addr_t;
typedef u_int64_t user_size_t;
typedef int64_t user_ssize_t;
typedef int64_t user_long_t;
typedef u_int64_t user_ulong_t;
typedef int64_t user_time_t;
typedef int64_t user_off_t;







typedef u_int64_t syscall_arg_t;
# 36 "/usr/include/machine/types.h" 2 3 4
# 256 "/usr/include/stdlib.h" 2 3 4


typedef __darwin_dev_t dev_t;




typedef __darwin_mode_t mode_t;



u_int32_t
  arc4random(void);
void arc4random_addrandom(unsigned char * , int );
void arc4random_buf(void * , size_t ) __attribute__((visibility("default")));
void arc4random_stir(void);
u_int32_t
  arc4random_uniform(u_int32_t ) __attribute__((visibility("default")));

int atexit_b(void (^)(void)) __attribute__((visibility("default")));
void *bsearch_b(const void *, const void *, size_t,
     size_t, int (^)(const void *, const void *)) __attribute__((visibility("default")));



char *cgetcap(char *, const char *, int);
int cgetclose(void);
int cgetent(char **, char **, const char *);
int cgetfirst(char **, char **);
int cgetmatch(const char *, const char *);
int cgetnext(char **, char **);
int cgetnum(char *, const char *, long *);
int cgetset(const char *);
int cgetstr(char *, const char *, char **);
int cgetustr(char *, const char *, char **);

int daemon(int, int) __asm("_" "daemon" "$1050") __attribute__((deprecated,visibility("default")));
char *devname(dev_t, mode_t);
char *devname_r(dev_t, mode_t, char *buf, int len);
char *getbsize(int *, long *);
int getloadavg(double [], int);
const char
 *getprogname(void);

int heapsort(void *, size_t, size_t,
     int (*)(const void *, const void *));

int heapsort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

int mergesort(void *, size_t, size_t,
     int (*)(const void *, const void *));

int mergesort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void psort(void *, size_t, size_t,
     int (*)(const void *, const void *)) __attribute__((visibility("default")));

void psort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void psort_r(void *, size_t, size_t, void *,
     int (*)(void *, const void *, const void *)) __attribute__((visibility("default")));

void qsort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void qsort_r(void *, size_t, size_t, void *,
     int (*)(void *, const void *, const void *));
int radixsort(const unsigned char **, int, const unsigned char *,
     unsigned);
void setprogname(const char *);
int sradixsort(const unsigned char **, int, const unsigned char *,
     unsigned);
void sranddev(void);
void srandomdev(void);
void *reallocf(void *, size_t);

long long
  strtoq(const char *, char **, int);
unsigned long long
  strtouq(const char *, char **, int);

extern char *suboptarg;
void *valloc(size_t);







# 69 "c.h" 2
# 1 "/usr/include/string.h" 1 3 4
# 79 "/usr/include/string.h" 3 4

void *memchr(const void *, int, size_t);
int memcmp(const void *, const void *, size_t);
void *memcpy(void *, const void *, size_t);
void *memmove(void *, const void *, size_t);
void *memset(void *, int, size_t);
char *strcat(char *, const char *);
char *strchr(const char *, int);
int strcmp(const char *, const char *);
int strcoll(const char *, const char *);
char *strcpy(char *, const char *);
size_t strcspn(const char *, const char *);
char *strerror(int) __asm("_" "strerror" );
size_t strlen(const char *);
char *strncat(char *, const char *, size_t);
int strncmp(const char *, const char *, size_t);
char *strncpy(char *, const char *, size_t);
char *strpbrk(const char *, const char *);
char *strrchr(const char *, int);
size_t strspn(const char *, const char *);
char *strstr(const char *, const char *);
char *strtok(char *, const char *);
size_t strxfrm(char *, const char *, size_t);

# 113 "/usr/include/string.h" 3 4

char *strtok_r(char *, const char *, char **);

# 125 "/usr/include/string.h" 3 4

int strerror_r(int, char *, size_t);
char *strdup(const char *);
void *memccpy(void *, const void *, int, size_t);

# 139 "/usr/include/string.h" 3 4

char *stpcpy(char *, const char *);
char *stpncpy(char *, const char *, size_t) __attribute__((visibility("default")));
char *strndup(const char *, size_t) __attribute__((visibility("default")));
size_t strnlen(const char *, size_t) __attribute__((visibility("default")));
char *strsignal(int sig);

# 158 "/usr/include/string.h" 3 4

void *memmem(const void *, size_t, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern4(void *, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern8(void *, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern16(void *, const void *, size_t) __attribute__((visibility("default")));

char *strcasestr(const char *, const char *);
char *strnstr(const char *, const char *, size_t);
size_t strlcat(char *, const char *, size_t);
size_t strlcpy(char *, const char *, size_t);
void strmode(int, char *);
char *strsep(char **, const char *);


void swab(const void * , void * , ssize_t);







# 1 "/usr/include/strings.h" 1 3 4
# 71 "/usr/include/strings.h" 3 4



int bcmp(const void *, const void *, size_t) ;
void bcopy(const void *, void *, size_t) ;
void bzero(void *, size_t) ;
char *index(const char *, int) ;
char *rindex(const char *, int) ;


int ffs(int);
int strcasecmp(const char *, const char *);
int strncasecmp(const char *, const char *, size_t);





int ffsl(long) __attribute__((visibility("default")));
int fls(int) __attribute__((visibility("default")));
int flsl(long) __attribute__((visibility("default")));


# 1 "/usr/include/string.h" 1 3 4
# 95 "/usr/include/strings.h" 2 3 4
# 181 "/usr/include/string.h" 2 3 4
# 190 "/usr/include/string.h" 3 4
# 1 "/usr/include/secure/_string.h" 1 3 4
# 58 "/usr/include/secure/_string.h" 3 4
static __inline void *
__inline_memcpy_chk (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memcpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 0));
}






static __inline void *
__inline_memmove_chk (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memmove_chk (__dest, __src, __len, __builtin_object_size (__dest, 0));
}






static __inline void *
__inline_memset_chk (void *__dest, int __val, size_t __len)
{
  return __builtin___memset_chk (__dest, __val, __len, __builtin_object_size (__dest, 0));
}






static __inline char *
__inline_strcpy_chk (char * __dest, const char * __src)
{
  return __builtin___strcpy_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_stpcpy_chk (char *__dest, const char *__src)
{
  return __builtin___stpcpy_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}






static __inline char *
__inline_stpncpy_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___stpncpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_strncpy_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___strncpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}






static __inline char *
__inline_strcat_chk (char * __dest, const char * __src)
{
  return __builtin___strcat_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_strncat_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___strncat_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}
# 191 "/usr/include/string.h" 2 3 4
# 70 "c.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stddef.h" 1 3 4
# 152 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 71 "c.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stdarg.h" 1 3 4
# 43 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 72 "c.h" 2

# 1 "./strings.h" 1
char *s1,
     *s2,
     *s3,
     *s4,
     *s5,
     *s6;
# 74 "c.h" 2


# 1 "/usr/include/stdint.h" 1 3 4
# 40 "/usr/include/stdint.h" 3 4
typedef unsigned char uint8_t;




typedef unsigned short uint16_t;




typedef unsigned int uint32_t;




typedef unsigned long long uint64_t;



typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;
# 97 "/usr/include/stdint.h" 3 4
typedef long int intmax_t;
# 106 "/usr/include/stdint.h" 3 4
typedef long unsigned int uintmax_t;
# 77 "c.h" 2

# 1 "/usr/include/sys/types.h" 1 3 4
# 84 "/usr/include/sys/types.h" 3 4
typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned int u_int;

typedef unsigned long u_long;


typedef unsigned short ushort;
typedef unsigned int uint;


typedef u_int64_t u_quad_t;
typedef int64_t quad_t;
typedef quad_t * qaddr_t;

typedef char * caddr_t;
typedef int32_t daddr_t;






typedef u_int32_t fixpt_t;


typedef __darwin_blkcnt_t blkcnt_t;




typedef __darwin_blksize_t blksize_t;




typedef __darwin_gid_t gid_t;





typedef __uint32_t in_addr_t;




typedef __uint16_t in_port_t;



typedef __darwin_ino_t ino_t;





typedef __darwin_ino64_t ino64_t;






typedef __int32_t key_t;
# 157 "/usr/include/sys/types.h" 3 4
typedef __uint16_t nlink_t;
# 176 "/usr/include/sys/types.h" 3 4
typedef int32_t segsz_t;
typedef int32_t swblk_t;
# 223 "/usr/include/sys/types.h" 3 4
typedef __darwin_clock_t clock_t;
# 240 "/usr/include/sys/types.h" 3 4
typedef __darwin_time_t time_t;




typedef __darwin_useconds_t useconds_t;




typedef __darwin_suseconds_t suseconds_t;
# 260 "/usr/include/sys/types.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 183 "/usr/include/sys/_structs.h" 3 4

typedef struct fd_set {
 __int32_t fds_bits[((((1024) % ((sizeof(__int32_t) * 8))) == 0) ? ((1024) / ((sizeof(__int32_t) * 8))) : (((1024) / ((sizeof(__int32_t) * 8))) + 1))];
} fd_set;



static __inline int
__darwin_fd_isset(int _n, const struct fd_set *_p)
{
 return (_p->fds_bits[_n/(sizeof(__int32_t) * 8)] & (1<<(_n % (sizeof(__int32_t) * 8))));
}
# 261 "/usr/include/sys/types.h" 2 3 4




typedef __int32_t fd_mask;
# 322 "/usr/include/sys/types.h" 3 4
typedef __darwin_pthread_cond_t pthread_cond_t;



typedef __darwin_pthread_condattr_t pthread_condattr_t;



typedef __darwin_pthread_mutex_t pthread_mutex_t;



typedef __darwin_pthread_mutexattr_t pthread_mutexattr_t;



typedef __darwin_pthread_once_t pthread_once_t;



typedef __darwin_pthread_rwlock_t pthread_rwlock_t;



typedef __darwin_pthread_rwlockattr_t pthread_rwlockattr_t;



typedef __darwin_pthread_t pthread_t;






typedef __darwin_pthread_key_t pthread_key_t;





typedef __darwin_fsblkcnt_t fsblkcnt_t;




typedef __darwin_fsfilcnt_t fsfilcnt_t;
# 79 "c.h" 2

# 1 "/usr/include/errno.h" 1 3 4
# 23 "/usr/include/errno.h" 3 4
# 1 "/usr/include/sys/errno.h" 1 3 4
# 74 "/usr/include/sys/errno.h" 3 4

extern int * __error(void);


# 24 "/usr/include/errno.h" 2 3 4
# 81 "c.h" 2
# 91 "c.h"
# 1 "/usr/include/locale.h" 1 3 4
# 40 "/usr/include/locale.h" 3 4
# 1 "/usr/include/_locale.h" 1 3 4
# 43 "/usr/include/_locale.h" 3 4
struct lconv {
 char *decimal_point;
 char *thousands_sep;
 char *grouping;
 char *int_curr_symbol;
 char *currency_symbol;
 char *mon_decimal_point;
 char *mon_thousands_sep;
 char *mon_grouping;
 char *positive_sign;
 char *negative_sign;
 char int_frac_digits;
 char frac_digits;
 char p_cs_precedes;
 char p_sep_by_space;
 char n_cs_precedes;
 char n_sep_by_space;
 char p_sign_posn;
 char n_sign_posn;
 char int_p_cs_precedes;
 char int_n_cs_precedes;
 char int_p_sep_by_space;
 char int_n_sep_by_space;
 char int_p_sign_posn;
 char int_n_sign_posn;
};






struct lconv *localeconv(void);

# 41 "/usr/include/locale.h" 2 3 4
# 52 "/usr/include/locale.h" 3 4

char *setlocale(int, const char *);

# 92 "c.h" 2
# 181 "c.h"
typedef char bool;
# 193 "c.h"
typedef bool *BoolPtr;
# 224 "c.h"
typedef char *Pointer;
# 233 "c.h"
typedef signed char int8;
typedef signed short int16;
typedef signed int int32;
# 245 "c.h"
typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;






typedef uint8 bits8;
typedef uint16 bits16;
typedef uint32 bits32;
# 265 "c.h"
typedef long int int64;


typedef unsigned long int uint64;
# 308 "c.h"
typedef size_t Size;
# 317 "c.h"
typedef unsigned int Index;
# 327 "c.h"
typedef signed int Offset;




typedef int16 int2;
typedef int32 int4;
typedef float float4;
typedef double float8;
# 348 "c.h"
typedef Oid regproc;
typedef regproc RegProcedure;

typedef uint32 TransactionId;

typedef uint32 LocalTransactionId;

typedef uint32 SubTransactionId;





typedef TransactionId MultiXactId;

typedef uint32 MultiXactOffset;

typedef uint32 CommandId;







typedef struct
{
 int indx[6];
} IntArray;
# 391 "c.h"
struct varlena
{
 char vl_len_[4];
 char vl_dat[1];
};
# 404 "c.h"
typedef struct varlena bytea;
typedef struct varlena text;
typedef struct varlena BpChar;
typedef struct varlena VarChar;
# 419 "c.h"
typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
 int dim1;
 int lbound1;
 int2 values[1];
} int2vector;

typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
 int dim1;
 int lbound1;
 Oid values[1];
} oidvector;





typedef struct nameData
{
 char data[64];
} NameData;
typedef NameData *Name;
# 829 "c.h"
extern int fdatasync(int fildes);
# 860 "c.h"
# 1 "port.h" 1
# 16 "port.h"
# 1 "/usr/include/ctype.h" 1 3 4
# 69 "/usr/include/ctype.h" 3 4
# 1 "/usr/include/runetype.h" 1 3 4
# 70 "/usr/include/runetype.h" 3 4
typedef __darwin_wint_t wint_t;
# 81 "/usr/include/runetype.h" 3 4
typedef struct {
 __darwin_rune_t __min;
 __darwin_rune_t __max;
 __darwin_rune_t __map;
 __uint32_t *__types;
} _RuneEntry;

typedef struct {
 int __nranges;
 _RuneEntry *__ranges;
} _RuneRange;

typedef struct {
 char __name[14];
 __uint32_t __mask;
} _RuneCharClass;

typedef struct {
 char __magic[8];
 char __encoding[32];

 __darwin_rune_t (*__sgetrune)(const char *, __darwin_size_t, char const **);
 int (*__sputrune)(__darwin_rune_t, char *, __darwin_size_t, char **);
 __darwin_rune_t __invalid_rune;

 __uint32_t __runetype[(1 <<8 )];
 __darwin_rune_t __maplower[(1 <<8 )];
 __darwin_rune_t __mapupper[(1 <<8 )];






 _RuneRange __runetype_ext;
 _RuneRange __maplower_ext;
 _RuneRange __mapupper_ext;

 void *__variable;
 int __variable_len;




 int __ncharclasses;
 _RuneCharClass *__charclasses;
} _RuneLocale;




extern _RuneLocale _DefaultRuneLocale;
extern _RuneLocale *_CurrentRuneLocale;

# 70 "/usr/include/ctype.h" 2 3 4
# 145 "/usr/include/ctype.h" 3 4

unsigned long ___runetype(__darwin_ct_rune_t);
__darwin_ct_rune_t ___tolower(__darwin_ct_rune_t);
__darwin_ct_rune_t ___toupper(__darwin_ct_rune_t);


static __inline int
isascii(int _c)
{
 return ((_c & ~0x7F) == 0);
}
# 164 "/usr/include/ctype.h" 3 4

int __maskrune(__darwin_ct_rune_t, unsigned long);



static __inline int
__istype(__darwin_ct_rune_t _c, unsigned long _f)
{



 return (isascii(_c) ? !!(_DefaultRuneLocale.__runetype[_c] & _f)
  : !!__maskrune(_c, _f));

}

static __inline __darwin_ct_rune_t
__isctype(__darwin_ct_rune_t _c, unsigned long _f)
{



 return (_c < 0 || _c >= (1 <<8 )) ? 0 :
  !!(_DefaultRuneLocale.__runetype[_c] & _f);

}
# 204 "/usr/include/ctype.h" 3 4

__darwin_ct_rune_t __toupper(__darwin_ct_rune_t);
__darwin_ct_rune_t __tolower(__darwin_ct_rune_t);



static __inline int
__wcwidth(__darwin_ct_rune_t _c)
{
 unsigned int _x;

 if (_c == 0)
  return (0);
 _x = (unsigned int)__maskrune(_c, 0xe0000000L|0x00040000L);
 if ((_x & 0xe0000000L) != 0)
  return ((_x & 0xe0000000L) >> 30);
 return ((_x & 0x00040000L) != 0 ? 1 : -1);
}






static __inline int
isalnum(int _c)
{
 return (__istype(_c, 0x00000100L|0x00000400L));
}

static __inline int
isalpha(int _c)
{
 return (__istype(_c, 0x00000100L));
}

static __inline int
isblank(int _c)
{
 return (__istype(_c, 0x00020000L));
}

static __inline int
iscntrl(int _c)
{
 return (__istype(_c, 0x00000200L));
}


static __inline int
isdigit(int _c)
{
 return (__isctype(_c, 0x00000400L));
}

static __inline int
isgraph(int _c)
{
 return (__istype(_c, 0x00000800L));
}

static __inline int
islower(int _c)
{
 return (__istype(_c, 0x00001000L));
}

static __inline int
isprint(int _c)
{
 return (__istype(_c, 0x00040000L));
}

static __inline int
ispunct(int _c)
{
 return (__istype(_c, 0x00002000L));
}

static __inline int
isspace(int _c)
{
 return (__istype(_c, 0x00004000L));
}

static __inline int
isupper(int _c)
{
 return (__istype(_c, 0x00008000L));
}


static __inline int
isxdigit(int _c)
{
 return (__isctype(_c, 0x00010000L));
}

static __inline int
toascii(int _c)
{
 return (_c & 0x7F);
}

static __inline int
tolower(int _c)
{
        return (__tolower(_c));
}

static __inline int
toupper(int _c)
{
        return (__toupper(_c));
}


static __inline int
digittoint(int _c)
{
 return (__maskrune(_c, 0x0F));
}

static __inline int
ishexnumber(int _c)
{
 return (__istype(_c, 0x00010000L));
}

static __inline int
isideogram(int _c)
{
 return (__istype(_c, 0x00080000L));
}

static __inline int
isnumber(int _c)
{
 return (__istype(_c, 0x00000400L));
}

static __inline int
isphonogram(int _c)
{
 return (__istype(_c, 0x00200000L));
}

static __inline int
isrune(int _c)
{
 return (__istype(_c, 0xFFFFFFF0L));
}

static __inline int
isspecial(int _c)
{
 return (__istype(_c, 0x00100000L));
}
# 17 "port.h" 2
# 1 "./netdb.h" 1
# 18 "port.h" 2
# 1 "./pwd.h" 1
# 19 "port.h" 2



typedef int pgsocket;
# 32 "port.h"
extern bool pg_set_noblock(pgsocket sock);
extern bool pg_set_block(pgsocket sock);



extern bool has_drive_prefix(const char *filename);
extern char *first_dir_separator(const char *filename);
extern char *last_dir_separator(const char *filename);
extern char *first_path_var_separator(const char *pathlist);
extern void join_path_components(char *ret_path,
      const char *head, const char *tail);
extern void canonicalize_path(char *path);
extern void make_native_path(char *path);
extern bool path_contains_parent_reference(const char *path);
extern bool path_is_relative_and_below_cwd(const char *path);
extern bool path_is_prefix_of_path(const char *path1, const char *path2);
extern const char *get_progname(const char *argv0);
extern void get_share_path(const char *my_exec_path, char *ret_path);
extern void get_etc_path(const char *my_exec_path, char *ret_path);
extern void get_include_path(const char *my_exec_path, char *ret_path);
extern void get_pkginclude_path(const char *my_exec_path, char *ret_path);
extern void get_includeserver_path(const char *my_exec_path, char *ret_path);
extern void get_lib_path(const char *my_exec_path, char *ret_path);
extern void get_pkglib_path(const char *my_exec_path, char *ret_path);
extern void get_locale_path(const char *my_exec_path, char *ret_path);
extern void get_doc_path(const char *my_exec_path, char *ret_path);
extern void get_html_path(const char *my_exec_path, char *ret_path);
extern void get_man_path(const char *my_exec_path, char *ret_path);
extern bool get_home_path(char *ret_path);
extern void get_parent_directory(char *path);


extern char **pgfnames(const char *path);
extern void pgfnames_cleanup(char **filenames);
# 92 "port.h"
extern void set_pglocale_pgservice(const char *argv0, const char *app);


extern int find_my_exec(const char *argv0, char *retpath);
extern int find_other_exec(const char *argv0, const char *target,
    const char *versionstr, char *retpath);
# 149 "port.h"
extern void pg_usleep(long microsec);


extern int pg_strcasecmp(const char *s1, const char *s2);
extern int pg_strncasecmp(const char *s1, const char *s2, size_t n);
extern unsigned char pg_toupper(unsigned char ch);
extern unsigned char pg_tolower(unsigned char ch);
extern unsigned char pg_ascii_toupper(unsigned char ch);
extern unsigned char pg_ascii_tolower(unsigned char ch);
# 247 "port.h"
extern char *simple_prompt(const char *prompt, int maxlen, bool echo);







extern int pclose_check(FILE *stream);
# 300 "port.h"
extern bool rmtree(const char *path, bool rmtopdir);
# 372 "port.h"
extern double pg_erand48(unsigned short xseed[3]);
extern long pg_lrand48(void);
extern void pg_srand48(long seed);
# 428 "port.h"
extern char *pqStrerror(int errnum, char *strerrbuf, size_t buflen);


extern int pqGetpwuid(uid_t uid, struct passwd * resultbuf, char *buffer,
     size_t buflen, struct passwd ** result);


extern int pqGethostbyname(const char *name,
    struct hostent * resultbuf,
    char *buffer, size_t buflen,
    struct hostent ** result,
    int *herrno);

extern void pg_qsort(void *base, size_t nel, size_t elsize,
   int (*cmp) (const void *, const void *));



typedef int (*qsort_arg_comparator) (const void *a, const void *b, void *arg);

extern void qsort_arg(void *base, size_t nel, size_t elsize,
    qsort_arg_comparator cmp, void *arg);


extern int pg_get_encoding_from_locale(const char *ctype, bool write_message);


extern char *inet_net_ntop(int af, const void *src, int bits,
     char *dst, size_t size);


extern int pg_check_dir(const char *dir);


extern int pg_mkdir_p(char *path, int omode);
# 861 "c.h" 2
# 48 "postgres.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
# 1 "/usr/include/setjmp.h" 1 3 4
# 26 "/usr/include/setjmp.h" 3 4
# 1 "/usr/include/machine/setjmp.h" 1 3 4
# 35 "/usr/include/machine/setjmp.h" 3 4
# 1 "/usr/include/i386/setjmp.h" 1 3 4
# 47 "/usr/include/i386/setjmp.h" 3 4
typedef int jmp_buf[((9 * 2) + 3 + 16)];
typedef int sigjmp_buf[((9 * 2) + 3 + 16) + 1];
# 65 "/usr/include/i386/setjmp.h" 3 4

int setjmp(jmp_buf);
void longjmp(jmp_buf, int);


int _setjmp(jmp_buf);
void _longjmp(jmp_buf, int);
int sigsetjmp(sigjmp_buf, int);
void siglongjmp(sigjmp_buf, int);



void longjmperror(void);


# 36 "/usr/include/machine/setjmp.h" 2 3 4
# 27 "/usr/include/setjmp.h" 2 3 4
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h" 2
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/errcodes.h" 1
# 70 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h" 2
# 114 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
extern bool errstart(int elevel, const char *filename, int lineno,
   const char *funcname, const char *domain);
extern void errfinish(int dummy,...);

extern int errcode(int sqlerrcode);

extern int errcode_for_file_access(void);
extern int errcode_for_socket_access(void);

extern int
errmsg(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errmsg_internal(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errmsg_plural(const char *fmt_singular, const char *fmt_plural,
     unsigned long n,...)


__attribute__((format(printf, 1, 4)))
__attribute__((format(printf, 2, 4)));

extern int
errdetail(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errdetail_internal(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errdetail_log(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errdetail_plural(const char *fmt_singular, const char *fmt_plural,
     unsigned long n,...)


__attribute__((format(printf, 1, 4)))
__attribute__((format(printf, 2, 4)));

extern int
errhint(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errcontext(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int errhidestmt(bool hide_stmt);

extern int errfunction(const char *funcname);
extern int errposition(int cursorpos);

extern int internalerrposition(int cursorpos);
extern int internalerrquery(const char *query);

extern int geterrcode(void);
extern int geterrposition(void);
extern int getinternalerrposition(void);
# 201 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
extern void elog_start(const char *filename, int lineno, const char *funcname);
extern void
elog_finish(int elevel, const char *fmt,...)


__attribute__((format(printf, 2, 3)));




extern void pre_format_elog_string(int errnumber, const char *domain);
extern char *
format_elog_string(const char *fmt,...)


__attribute__((format(printf, 1, 2)));




typedef struct ErrorContextCallback
{
 struct ErrorContextCallback *previous;
 void (*callback) (void *arg);
 void *arg;
} ErrorContextCallback;

extern ErrorContextCallback *error_context_stack;
# 296 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
extern sigjmp_buf *PG_exception_stack;
# 307 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
typedef struct ErrorData
{
 int elevel;
 bool output_to_server;
 bool output_to_client;
 bool show_funcname;
 bool hide_stmt;
 const char *filename;
 int lineno;
 const char *funcname;
 const char *domain;
 int sqlerrcode;
 char *message;
 char *detail;
 char *detail_log;
 char *hint;
 char *context;
 int cursorpos;
 int internalpos;
 char *internalquery;
 int saved_errno;
} ErrorData;

extern void EmitErrorReport(void);
extern ErrorData *CopyErrorData(void);
extern void FreeErrorData(ErrorData *edata);
extern void FlushErrorState(void);
extern void ReThrowError(ErrorData *edata) __attribute__((noreturn));
extern void pg_re_throw(void) __attribute__((noreturn));


typedef void (*emit_log_hook_type) (ErrorData *edata);
extern emit_log_hook_type emit_log_hook;




typedef enum
{
 PGERROR_TERSE,
 PGERROR_DEFAULT,
 PGERROR_VERBOSE
} PGErrorVerbosity;

extern int Log_error_verbosity;
extern char *Log_line_prefix;
extern int Log_destination;
# 362 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
extern void DebugFileOpen(void);
extern char *unpack_sql_state(int sql_state);
extern bool in_error_recursion_trouble(void);


extern void set_syslog_parameters(const char *ident, int facility);







extern void
write_stderr(const char *fmt,...)


__attribute__((format(printf, 1, 2)));
# 49 "postgres.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h" 1
# 36 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h"
typedef struct MemoryContextData *MemoryContext;






extern MemoryContext CurrentMemoryContext;




extern void *MemoryContextAlloc(MemoryContext context, Size size);
extern void *MemoryContextAllocZero(MemoryContext context, Size size);
extern void *MemoryContextAllocZeroAligned(MemoryContext context, Size size);
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h"
extern void pfree(void *pointer);

extern void *repalloc(void *pointer, Size size);
# 83 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h"
static inline MemoryContext
MemoryContextSwitchTo(MemoryContext context)
{
 MemoryContext old = CurrentMemoryContext;

 CurrentMemoryContext = context;
 return old;
}
# 100 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h"
extern char *MemoryContextStrdup(MemoryContext context, const char *string);



extern char *pnstrdup(const char *in, Size len);
# 50 "postgres.h" 2
# 67 "postgres.h"
struct varatt_external
{
 int32 va_rawsize;
 int32 va_extsize;
 Oid va_valueid;
 Oid va_toastrelid;
};
# 84 "postgres.h"
typedef union
{
 struct
 {
  uint32 va_header;
  char va_data[1];
 } va_4byte;
 struct
 {
  uint32 va_header;
  uint32 va_rawsize;
  char va_data[1];
 } va_compressed;
} varattrib_4b;

typedef struct
{
 uint8 va_header;
 char va_data[1];
} varattrib_1b;

typedef struct
{
 uint8 va_header;
 uint8 va_len_1be;
 char va_data[1];
} varattrib_1b_e;
# 302 "postgres.h"
typedef uintptr_t Datum;



typedef Datum *DatumPtr;
# 561 "postgres.h"
extern float4 DatumGetFloat4(Datum X);
# 574 "postgres.h"
extern Datum Float4GetDatum(float4 X);
# 584 "postgres.h"
extern float8 DatumGetFloat8(Datum X);
# 597 "postgres.h"
extern Datum Float8GetDatum(float8 X);
# 635 "postgres.h"
extern bool assert_enabled;
# 686 "postgres.h"
extern void ExceptionalCondition(const char *conditionName,
      const char *errorType,
    const char *fileName, int lineNumber) __attribute__((noreturn));
# 48 "tablespace.c" 2

# 1 "./unistd.h" 1
# 50 "tablespace.c" 2
# 1 "./dirent.h" 1
# 9 "./dirent.h"
struct dirent
{
 long d_ino;
 unsigned short d_reclen;
 unsigned short d_namlen;
 char d_name[MAX_PATH];
};

typedef struct DIR DIR;

DIR *opendir(const char *);
struct dirent *readdir(DIR *);
int closedir(DIR *);
# 51 "tablespace.c" 2

# 1 "/usr/include/sys/stat.h" 1 3 4
# 79 "/usr/include/sys/stat.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 88 "/usr/include/sys/_structs.h" 3 4
struct timespec
{
 __darwin_time_t tv_sec;
 long tv_nsec;
};
# 80 "/usr/include/sys/stat.h" 2 3 4
# 153 "/usr/include/sys/stat.h" 3 4
struct ostat {
 __uint16_t st_dev;
 ino_t st_ino;
 mode_t st_mode;
 nlink_t st_nlink;
 __uint16_t st_uid;
 __uint16_t st_gid;
 __uint16_t st_rdev;
 __int32_t st_size;
 struct timespec st_atimespec;
 struct timespec st_mtimespec;
 struct timespec st_ctimespec;
 __int32_t st_blksize;
 __int32_t st_blocks;
 __uint32_t st_flags;
 __uint32_t st_gen;
};
# 225 "/usr/include/sys/stat.h" 3 4
struct stat { dev_t st_dev; mode_t st_mode; nlink_t st_nlink; __darwin_ino64_t st_ino; uid_t st_uid; gid_t st_gid; dev_t st_rdev; struct timespec st_atimespec; struct timespec st_mtimespec; struct timespec st_ctimespec; struct timespec st_birthtimespec; off_t st_size; blkcnt_t st_blocks; blksize_t st_blksize; __uint32_t st_flags; __uint32_t st_gen; __int32_t st_lspare; __int64_t st_qspare[2]; };
# 264 "/usr/include/sys/stat.h" 3 4
struct stat64 { dev_t st_dev; mode_t st_mode; nlink_t st_nlink; __darwin_ino64_t st_ino; uid_t st_uid; gid_t st_gid; dev_t st_rdev; struct timespec st_atimespec; struct timespec st_mtimespec; struct timespec st_ctimespec; struct timespec st_birthtimespec; off_t st_size; blkcnt_t st_blocks; blksize_t st_blksize; __uint32_t st_flags; __uint32_t st_gen; __int32_t st_lspare; __int64_t st_qspare[2]; };
# 428 "/usr/include/sys/stat.h" 3 4


int chmod(const char *, mode_t) __asm("_" "chmod" );
int fchmod(int, mode_t) __asm("_" "fchmod" );
int fstat(int, struct stat *) __asm("_" "fstat" "$INODE64");
int lstat(const char *, struct stat *) __asm("_" "lstat" "$INODE64");
int mkdir(const char *, mode_t);
int mkfifo(const char *, mode_t);
int stat(const char *, struct stat *) __asm("_" "stat" "$INODE64");
int mknod(const char *, mode_t, dev_t);
mode_t umask(mode_t);



struct _filesec;
typedef struct _filesec *filesec_t;


int chflags(const char *, __uint32_t);
int chmodx_np(const char *, filesec_t);
int fchflags(int, __uint32_t);
int fchmodx_np(int, filesec_t);
int fstatx_np(int, struct stat *, filesec_t) __asm("_" "fstatx_np" "$INODE64");
int lchflags(const char *, __uint32_t) __attribute__((visibility("default")));
int lchmod(const char *, mode_t) __attribute__((visibility("default")));
int lstatx_np(const char *, struct stat *, filesec_t) __asm("_" "lstatx_np" "$INODE64");
int mkdirx_np(const char *, filesec_t);
int mkfifox_np(const char *, filesec_t);
int statx_np(const char *, struct stat *, filesec_t) __asm("_" "statx_np" "$INODE64");
int umaskx_np(filesec_t) __attribute__((deprecated,visibility("default")));



int fstatx64_np(int, struct stat64 *, filesec_t) __attribute__((deprecated,visibility("default")));
int lstatx64_np(const char *, struct stat64 *, filesec_t) __attribute__((deprecated,visibility("default")));
int statx64_np(const char *, struct stat64 *, filesec_t) __attribute__((deprecated,visibility("default")));
int fstat64(int, struct stat64 *) __attribute__((deprecated,visibility("default")));
int lstat64(const char *, struct stat64 *) __attribute__((deprecated,visibility("default")));
int stat64(const char *, struct stat64 *) __attribute__((deprecated,visibility("default")));




# 53 "tablespace.c" 2

# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/sdir.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/sdir.h"
typedef enum ScanDirection
{
 BackwardScanDirection = -1,
 NoMovementScanDirection = 0,
 ForwardScanDirection = 1
} ScanDirection;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/skey.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/skey.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h"
typedef int16 AttrNumber;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/skey.h" 2
# 1 "./fmgr.h" 1
# 22 "./fmgr.h"
typedef struct Node *fmNodePtr;


typedef struct StringInfoData *fmStringInfo;
# 34 "./fmgr.h"
typedef struct FunctionCallInfoData *FunctionCallInfo;

typedef Datum (*PGFunction) (FunctionCallInfo fcinfo);
# 49 "./fmgr.h"
typedef struct FmgrInfo
{
 PGFunction fn_addr;
 Oid fn_oid;
 short fn_nargs;

 bool fn_strict;
 bool fn_retset;
 unsigned char fn_stats;
 void *fn_extra;
 MemoryContext fn_mcxt;
 fmNodePtr fn_expr;
} FmgrInfo;




typedef struct FunctionCallInfoData
{
 FmgrInfo *flinfo;
 fmNodePtr context;
 fmNodePtr resultinfo;
 Oid fncollation;
 bool isnull;
 short nargs;
 Datum arg[100];
 bool argnull[100];
} FunctionCallInfoData;





extern void fmgr_info(Oid functionId, FmgrInfo *finfo);






extern void fmgr_info_cxt(Oid functionId, FmgrInfo *finfo,
     MemoryContext mcxt);
# 99 "./fmgr.h"
extern void fmgr_info_copy(FmgrInfo *dstinfo, FmgrInfo *srcinfo,
      MemoryContext destcxt);
# 187 "./fmgr.h"
extern struct varlena *pg_detoast_datum(struct varlena * datum);
extern struct varlena *pg_detoast_datum_copy(struct varlena * datum);
extern struct varlena *pg_detoast_datum_slice(struct varlena * datum,
        int32 first, int32 count);
extern struct varlena *pg_detoast_datum_packed(struct varlena * datum);
# 332 "./fmgr.h"
typedef struct
{
 int api_version;

} Pg_finfo_record;


typedef const Pg_finfo_record *(*PGFInfoFunction) (void);
# 383 "./fmgr.h"
typedef struct
{
 int len;
 int version;
 int funcmaxargs;
 int indexmaxkeys;
 int namedatalen;
 int float4byval;
 int float8byval;
} Pg_magic_struct;
# 410 "./fmgr.h"
typedef const Pg_magic_struct *(*PGModuleMagicFunction) (void);
# 435 "./fmgr.h"
extern Datum DirectFunctionCall1Coll(PGFunction func, Oid collation,
      Datum arg1);
extern Datum DirectFunctionCall2Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2);
extern Datum DirectFunctionCall3Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3);
extern Datum DirectFunctionCall4Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4);
extern Datum DirectFunctionCall5Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5);
extern Datum DirectFunctionCall6Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6);
extern Datum DirectFunctionCall7Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7);
extern Datum DirectFunctionCall8Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8);
extern Datum DirectFunctionCall9Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8,
      Datum arg9);





extern Datum FunctionCall1Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1);
extern Datum FunctionCall2Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2);
extern Datum FunctionCall3Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3);
extern Datum FunctionCall4Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4);
extern Datum FunctionCall5Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5);
extern Datum FunctionCall6Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6);
extern Datum FunctionCall7Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7);
extern Datum FunctionCall8Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8);
extern Datum FunctionCall9Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8,
      Datum arg9);







extern Datum OidFunctionCall0Coll(Oid functionId, Oid collation);
extern Datum OidFunctionCall1Coll(Oid functionId, Oid collation,
      Datum arg1);
extern Datum OidFunctionCall2Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2);
extern Datum OidFunctionCall3Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3);
extern Datum OidFunctionCall4Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4);
extern Datum OidFunctionCall5Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5);
extern Datum OidFunctionCall6Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6);
extern Datum OidFunctionCall7Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7);
extern Datum OidFunctionCall8Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8);
extern Datum OidFunctionCall9Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8,
      Datum arg9);
# 602 "./fmgr.h"
extern Datum InputFunctionCall(FmgrInfo *flinfo, char *str,
      Oid typioparam, int32 typmod);
extern Datum OidInputFunctionCall(Oid functionId, char *str,
      Oid typioparam, int32 typmod);
extern char *OutputFunctionCall(FmgrInfo *flinfo, Datum val);
extern char *OidOutputFunctionCall(Oid functionId, Datum val);
extern Datum ReceiveFunctionCall(FmgrInfo *flinfo, fmStringInfo buf,
     Oid typioparam, int32 typmod);
extern Datum OidReceiveFunctionCall(Oid functionId, fmStringInfo buf,
        Oid typioparam, int32 typmod);
extern bytea *SendFunctionCall(FmgrInfo *flinfo, Datum val);
extern bytea *OidSendFunctionCall(Oid functionId, Datum val);





extern const Pg_finfo_record *fetch_finfo_record(void *filehandle, char *funcname);
extern void clear_external_function_hash(void *filehandle);
extern Oid fmgr_internal_function(const char *proname);
extern Oid get_fn_expr_rettype(FmgrInfo *flinfo);
extern Oid get_fn_expr_argtype(FmgrInfo *flinfo, int argnum);
extern Oid get_call_expr_argtype(fmNodePtr expr, int argnum);
extern bool get_fn_expr_arg_stable(FmgrInfo *flinfo, int argnum);
extern bool get_call_expr_arg_stable(fmNodePtr expr, int argnum);




extern char *Dynamic_library_path;

extern PGFunction load_external_function(char *filename, char *funcname,
        bool signalNotFound, void **filehandle);
extern PGFunction lookup_external_function(void *filehandle, char *funcname);
extern void load_file(const char *filename, bool restricted);
extern void **find_rendezvous_variable(const char *varName);
# 650 "./fmgr.h"
extern int AggCheckCallContext(FunctionCallInfo fcinfo,
     MemoryContext *aggcontext);
# 662 "./fmgr.h"
typedef enum FmgrHookEventType
{
 FHET_START,
 FHET_END,
 FHET_ABORT
} FmgrHookEventType;

typedef bool (*needs_fmgr_hook_type) (Oid fn_oid);

typedef void (*fmgr_hook_type) (FmgrHookEventType event,
           FmgrInfo *flinfo, Datum *arg);

extern needs_fmgr_hook_type needs_fmgr_hook;
extern fmgr_hook_type fmgr_hook;
# 693 "./fmgr.h"
extern char *fmgr(Oid procedureId,...);
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/skey.h" 2







typedef uint16 StrategyNumber;
# 85 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/skey.h"
typedef struct ScanKeyData
{
 int sk_flags;
 AttrNumber sk_attno;
 StrategyNumber sk_strategy;
 Oid sk_subtype;
 Oid sk_collation;
 FmgrInfo sk_func;
 Datum sk_argument;
} ScanKeyData;

typedef ScanKeyData *ScanKey;
# 151 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/skey.h"
extern void ScanKeyInit(ScanKey entry,
   AttrNumber attributeNumber,
   StrategyNumber strategy,
   RegProcedure procedure,
   Datum argument);
extern void ScanKeyEntryInitialize(ScanKey entry,
        int flags,
        AttrNumber attributeNumber,
        StrategyNumber strategy,
        Oid subtype,
        Oid collation,
        RegProcedure procedure,
        Datum argument);
extern void ScanKeyEntryInitializeWithInfo(ScanKey entry,
          int flags,
          AttrNumber attributeNumber,
          StrategyNumber strategy,
          Oid subtype,
          Oid collation,
          FmgrInfo *finfo,
          Datum argument);
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 1
# 14 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/rmgr.h" 1
# 11 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/rmgr.h"
typedef uint8 RmgrId;
# 15 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h" 1
# 15 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
# 1 "/usr/include/fcntl.h" 1 3 4
# 23 "/usr/include/fcntl.h" 3 4
# 1 "/usr/include/sys/fcntl.h" 1 3 4
# 339 "/usr/include/sys/fcntl.h" 3 4
struct flock {
 off_t l_start;
 off_t l_len;
 pid_t l_pid;
 short l_type;
 short l_whence;
};
# 355 "/usr/include/sys/fcntl.h" 3 4
struct radvisory {
       off_t ra_offset;
       int ra_count;
};
# 367 "/usr/include/sys/fcntl.h" 3 4
typedef struct fsignatures {
 off_t fs_file_start;
 void *fs_blob_start;
 size_t fs_blob_size;
} fsignatures_t;
# 381 "/usr/include/sys/fcntl.h" 3 4
typedef struct fstore {
 unsigned int fst_flags;
 int fst_posmode;
 off_t fst_offset;
 off_t fst_length;
 off_t fst_bytesalloc;
} fstore_t;



typedef struct fbootstraptransfer {
  off_t fbt_offset;
  size_t fbt_length;
  void *fbt_buffer;
} fbootstraptransfer_t;
# 419 "/usr/include/sys/fcntl.h" 3 4
#pragma pack(4)

struct log2phys {
 unsigned int l2p_flags;
 off_t l2p_contigbytes;


 off_t l2p_devoffset;


};

#pragma pack()
# 446 "/usr/include/sys/fcntl.h" 3 4
typedef enum {
 FILESEC_OWNER = 1,
 FILESEC_GROUP = 2,
 FILESEC_UUID = 3,
 FILESEC_MODE = 4,
 FILESEC_ACL = 5,
 FILESEC_GRPUUID = 6,


 FILESEC_ACL_RAW = 100,
 FILESEC_ACL_ALLOCSIZE = 101
} filesec_property_t;






int open(const char *, int, ...) __asm("_" "open" );
int creat(const char *, mode_t) __asm("_" "creat" );
int fcntl(int, int, ...) __asm("_" "fcntl" );


int openx_np(const char *, int, filesec_t);
int flock(int, int);
filesec_t filesec_init(void);
filesec_t filesec_dup(filesec_t);
void filesec_free(filesec_t);
int filesec_get_property(filesec_t, filesec_property_t, void *);
int filesec_query_property(filesec_t, filesec_property_t, int *);
int filesec_set_property(filesec_t, filesec_property_t, const void *);
int filesec_unset_property(filesec_t, filesec_property_t) __attribute__((visibility("default")));




# 23 "/usr/include/fcntl.h" 2 3 4
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h" 2
# 32 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
typedef struct XLogRecPtr
{
 uint32 xlogid;
 uint32 xrecoff;
} XLogRecPtr;
# 84 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
typedef uint32 TimeLineID;
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h"
# 1 "/usr/include/math.h" 1 3 4
# 28 "/usr/include/math.h" 3 4
# 1 "/usr/include/architecture/i386/math.h" 1 3 4
# 49 "/usr/include/architecture/i386/math.h" 3 4
 typedef float float_t;
 typedef double double_t;
# 108 "/usr/include/architecture/i386/math.h" 3 4
extern int __math_errhandling ( void );
# 128 "/usr/include/architecture/i386/math.h" 3 4
extern int __fpclassifyf(float );
extern int __fpclassifyd(double );
extern int __fpclassify (long double);
# 163 "/usr/include/architecture/i386/math.h" 3 4
 static __inline__ int __inline_isfinitef (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isfinited (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isfinite (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_isinff (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isinfd (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isinf (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_isnanf (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnand (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnan (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_isnormalf (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnormald (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnormal (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_signbitf (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_signbitd (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_signbit (long double) __attribute__ ((always_inline));

 static __inline__ int __inline_isinff( float __x ) { return __builtin_fabsf(__x) == __builtin_inff(); }
 static __inline__ int __inline_isinfd( double __x ) { return __builtin_fabs(__x) == __builtin_inf(); }
 static __inline__ int __inline_isinf( long double __x ) { return __builtin_fabsl(__x) == __builtin_infl(); }
 static __inline__ int __inline_isfinitef( float __x ) { return __x == __x && __builtin_fabsf(__x) != __builtin_inff(); }
 static __inline__ int __inline_isfinited( double __x ) { return __x == __x && __builtin_fabs(__x) != __builtin_inf(); }
 static __inline__ int __inline_isfinite( long double __x ) { return __x == __x && __builtin_fabsl(__x) != __builtin_infl(); }
 static __inline__ int __inline_isnanf( float __x ) { return __x != __x; }
 static __inline__ int __inline_isnand( double __x ) { return __x != __x; }
 static __inline__ int __inline_isnan( long double __x ) { return __x != __x; }
 static __inline__ int __inline_signbitf( float __x ) { union{ float __f; unsigned int __u; }__u; __u.__f = __x; return (int)(__u.__u >> 31); }
 static __inline__ int __inline_signbitd( double __x ) { union{ double __f; unsigned int __u[2]; }__u; __u.__f = __x; return (int)(__u.__u[1] >> 31); }
 static __inline__ int __inline_signbit( long double __x ){ union{ long double __ld; struct{ unsigned int __m[2]; short __sexp; }__p; }__u; __u.__ld = __x; return (int) (((unsigned short) __u.__p.__sexp) >> 15); }
 static __inline__ int __inline_isnormalf( float __x ) { float fabsf = __builtin_fabsf(__x); if( __x != __x ) return 0; return fabsf < __builtin_inff() && fabsf >= 1.17549435e-38F; }
 static __inline__ int __inline_isnormald( double __x ) { double fabsf = __builtin_fabs(__x); if( __x != __x ) return 0; return fabsf < __builtin_inf() && fabsf >= 2.2250738585072014e-308; }
 static __inline__ int __inline_isnormal( long double __x ) { long double fabsf = __builtin_fabsl(__x); if( __x != __x ) return 0; return fabsf < __builtin_infl() && fabsf >= 3.36210314311209350626e-4932L; }
# 253 "/usr/include/architecture/i386/math.h" 3 4
extern double acos( double );
extern float acosf( float );

extern double asin( double );
extern float asinf( float );

extern double atan( double );
extern float atanf( float );

extern double atan2( double, double );
extern float atan2f( float, float );

extern double cos( double );
extern float cosf( float );

extern double sin( double );
extern float sinf( float );

extern double tan( double );
extern float tanf( float );

extern double acosh( double );
extern float acoshf( float );

extern double asinh( double );
extern float asinhf( float );

extern double atanh( double );
extern float atanhf( float );

extern double cosh( double );
extern float coshf( float );

extern double sinh( double );
extern float sinhf( float );

extern double tanh( double );
extern float tanhf( float );

extern double exp ( double );
extern float expf ( float );

extern double exp2 ( double );
extern float exp2f ( float );

extern double expm1 ( double );
extern float expm1f ( float );

extern double log ( double );
extern float logf ( float );

extern double log10 ( double );
extern float log10f ( float );

extern double log2 ( double );
extern float log2f ( float );

extern double log1p ( double );
extern float log1pf ( float );

extern double logb ( double );
extern float logbf ( float );

extern double modf ( double, double * );
extern float modff ( float, float * );

extern double ldexp ( double, int );
extern float ldexpf ( float, int );

extern double frexp ( double, int * );
extern float frexpf ( float, int * );

extern int ilogb ( double );
extern int ilogbf ( float );

extern double scalbn ( double, int );
extern float scalbnf ( float, int );

extern double scalbln ( double, long int );
extern float scalblnf ( float, long int );

extern double fabs( double );
extern float fabsf( float );

extern double cbrt( double );
extern float cbrtf( float );

extern double hypot ( double, double );
extern float hypotf ( float, float );

extern double pow ( double, double );
extern float powf ( float, float );

extern double sqrt( double );
extern float sqrtf( float );

extern double erf( double );
extern float erff( float );

extern double erfc( double );
extern float erfcf( float );






extern double lgamma( double );
extern float lgammaf( float );

extern double tgamma( double );
extern float tgammaf( float );

extern double ceil ( double );
extern float ceilf ( float );

extern double floor ( double );
extern float floorf ( float );

extern double nearbyint ( double );
extern float nearbyintf ( float );

extern double rint ( double );
extern float rintf ( float );

extern long int lrint ( double );
extern long int lrintf ( float );

extern double round ( double );
extern float roundf ( float );

extern long int lround ( double );
extern long int lroundf ( float );



    extern long long int llrint ( double );
    extern long long int llrintf ( float );
    extern long long int llround ( double );
    extern long long int llroundf ( float );


extern double trunc ( double );
extern float truncf ( float );

extern double fmod ( double, double );
extern float fmodf ( float, float );

extern double remainder ( double, double );
extern float remainderf ( float, float );

extern double remquo ( double, double, int * );
extern float remquof ( float, float, int * );

extern double copysign ( double, double );
extern float copysignf ( float, float );

extern double nan( const char * );
extern float nanf( const char * );

extern double nextafter ( double, double );
extern float nextafterf ( float, float );

extern double fdim ( double, double );
extern float fdimf ( float, float );

extern double fmax ( double, double );
extern float fmaxf ( float, float );

extern double fmin ( double, double );
extern float fminf ( float, float );

extern double fma ( double, double, double );
extern float fmaf ( float, float, float );

extern long double acosl(long double);
extern long double asinl(long double);
extern long double atanl(long double);
extern long double atan2l(long double, long double);
extern long double cosl(long double);
extern long double sinl(long double);
extern long double tanl(long double);
extern long double acoshl(long double);
extern long double asinhl(long double);
extern long double atanhl(long double);
extern long double coshl(long double);
extern long double sinhl(long double);
extern long double tanhl(long double);
extern long double expl(long double);
extern long double exp2l(long double);
extern long double expm1l(long double);
extern long double logl(long double);
extern long double log10l(long double);
extern long double log2l(long double);
extern long double log1pl(long double);
extern long double logbl(long double);
extern long double modfl(long double, long double *);
extern long double ldexpl(long double, int);
extern long double frexpl(long double, int *);
extern int ilogbl(long double);
extern long double scalbnl(long double, int);
extern long double scalblnl(long double, long int);
extern long double fabsl(long double);
extern long double cbrtl(long double);
extern long double hypotl(long double, long double);
extern long double powl(long double, long double);
extern long double sqrtl(long double);
extern long double erfl(long double);
extern long double erfcl(long double);






extern long double lgammal(long double);

extern long double tgammal(long double);
extern long double ceill(long double);
extern long double floorl(long double);
extern long double nearbyintl(long double);
extern long double rintl(long double);
extern long int lrintl(long double);
extern long double roundl(long double);
extern long int lroundl(long double);



    extern long long int llrintl(long double);
    extern long long int llroundl(long double);


extern long double truncl(long double);
extern long double fmodl(long double, long double);
extern long double remainderl(long double, long double);
extern long double remquol(long double, long double, int *);
extern long double copysignl(long double, long double);
extern long double nanl(const char *);
extern long double nextafterl(long double, long double);
extern double nexttoward(double, long double);
extern float nexttowardf(float, long double);
extern long double nexttowardl(long double, long double);
extern long double fdiml(long double, long double);
extern long double fmaxl(long double, long double);
extern long double fminl(long double, long double);
extern long double fmal(long double, long double, long double);
# 507 "/usr/include/architecture/i386/math.h" 3 4
extern double __inf( void );
extern float __inff( void );
extern long double __infl( void );
extern float __nan( void );


extern double j0 ( double );

extern double j1 ( double );

extern double jn ( int, double );

extern double y0 ( double );

extern double y1 ( double );

extern double yn ( int, double );

extern double scalb ( double, double );
# 543 "/usr/include/architecture/i386/math.h" 3 4
extern int signgam;
# 558 "/usr/include/architecture/i386/math.h" 3 4
extern long int rinttol ( double );


extern long int roundtol ( double );
# 570 "/usr/include/architecture/i386/math.h" 3 4
struct exception {
 int type;
 char *name;
 double arg1;
 double arg2;
 double retval;
};
# 601 "/usr/include/architecture/i386/math.h" 3 4
extern int finite ( double );


extern double gamma ( double );




extern int matherr ( struct exception * );





extern double significand ( double );






extern double drem ( double, double );
# 29 "/usr/include/math.h" 2 3 4
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 1 3 4






# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/syslimits.h" 1 3 4
# 8 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 2 3 4







# 1 "/usr/include/limits.h" 1 3 4
# 64 "/usr/include/limits.h" 3 4
# 1 "/usr/include/machine/limits.h" 1 3 4





# 1 "/usr/include/i386/limits.h" 1 3 4
# 40 "/usr/include/i386/limits.h" 3 4
# 1 "/usr/include/i386/_limits.h" 1 3 4
# 41 "/usr/include/i386/limits.h" 2 3 4
# 7 "/usr/include/machine/limits.h" 2 3 4
# 65 "/usr/include/limits.h" 2 3 4
# 1 "/usr/include/sys/syslimits.h" 1 3 4
# 66 "/usr/include/limits.h" 2 3 4
# 16 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 2 3 4
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/float.h" 1 3 4
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h" 2
# 44 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h"
typedef int64 Timestamp;
typedef int64 TimestampTz;
typedef int64 TimeOffset;
typedef int32 fsec_t;
# 56 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h"
typedef struct
{
 TimeOffset time;

 int32 day;
 int32 month;
} Interval;
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h" 1
# 35 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
typedef struct StringInfoData
{
 char *data;
 int len;
 int maxlen;
 int cursor;
} StringInfoData;

typedef StringInfoData *StringInfo;
# 72 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
extern StringInfo makeStringInfo(void);






extern void initStringInfo(StringInfo str);






extern void resetStringInfo(StringInfo str);
# 95 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
extern void
appendStringInfo(StringInfo str, const char *fmt,...)

__attribute__((format(printf, 2, 3)));
# 108 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
extern bool
appendStringInfoVA(StringInfo str, const char *fmt, va_list args)
__attribute__((format(printf, 2, 0)));






extern void appendStringInfoString(StringInfo str, const char *s);






extern void appendStringInfoChar(StringInfo str, char ch);
# 140 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
extern void appendStringInfoSpaces(StringInfo str, int count);






extern void appendBinaryStringInfo(StringInfo str,
        const char *data, int datalen);





extern void enlargeStringInfo(StringInfo str, int needed);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h"
typedef int Buffer;
# 44 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h"
typedef struct BufferAccessStrategyData *BufferAccessStrategy;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/pg_crc.h" 1
# 32 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/pg_crc.h"
typedef uint32 pg_crc32;
# 57 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/pg_crc.h"
extern const uint32 pg_crc32_table[];
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 2
# 41 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
typedef struct XLogRecord
{
 pg_crc32 xl_crc;
 XLogRecPtr xl_prev;
 TransactionId xl_xid;
 uint32 xl_tot_len;
 uint32 xl_len;
 uint8 xl_info;
 RmgrId xl_rmid;





} XLogRecord;
# 88 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
extern int sync_method;
# 120 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
typedef struct XLogRecData
{
 char *data;
 uint32 len;
 Buffer buffer;
 bool buffer_std;
 struct XLogRecData *next;
} XLogRecData;

extern TimeLineID ThisTimeLineID;
# 138 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
extern bool InRecovery;
# 161 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
typedef enum
{
 STANDBY_DISABLED,
 STANDBY_INITIALIZED,
 STANDBY_SNAPSHOT_PENDING,
 STANDBY_SNAPSHOT_READY
} HotStandbyState;

extern HotStandbyState standbyState;







typedef enum
{
 RECOVERY_TARGET_UNSET,
 RECOVERY_TARGET_XID,
 RECOVERY_TARGET_TIME,
 RECOVERY_TARGET_NAME
} RecoveryTargetType;

extern XLogRecPtr XactLastRecEnd;

extern bool reachedConsistency;


extern int CheckPointSegments;
extern int wal_keep_segments;
extern int XLOGbuffers;
extern int XLogArchiveTimeout;
extern bool XLogArchiveMode;
extern char *XLogArchiveCommand;
extern bool EnableHotStandby;
extern bool fullPageWrites;
extern bool log_checkpoints;


typedef enum WalLevel
{
 WAL_LEVEL_MINIMAL = 0,
 WAL_LEVEL_ARCHIVE,
 WAL_LEVEL_HOT_STANDBY
} WalLevel;
extern int wal_level;
# 245 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
typedef struct CheckpointStatsData
{
 TimestampTz ckpt_start_t;
 TimestampTz ckpt_write_t;
 TimestampTz ckpt_sync_t;
 TimestampTz ckpt_sync_end_t;
 TimestampTz ckpt_end_t;

 int ckpt_bufs_written;

 int ckpt_segs_added;
 int ckpt_segs_removed;
 int ckpt_segs_recycled;

 int ckpt_sync_rels;
 uint64 ckpt_longest_sync;
 uint64 ckpt_agg_sync_time;



} CheckpointStatsData;

extern CheckpointStatsData CheckpointStats;

extern XLogRecPtr XLogInsert(RmgrId rmid, uint8 info, XLogRecData *rdata);
extern void XLogFlush(XLogRecPtr RecPtr);
extern bool XLogBackgroundFlush(void);
extern bool XLogNeedsFlush(XLogRecPtr RecPtr);
extern int XLogFileInit(uint32 log, uint32 seg,
    bool *use_existent, bool use_lock);
extern int XLogFileOpen(uint32 log, uint32 seg);


extern void CheckXLogRemoved(uint32 log, uint32 seg, TimeLineID tli);
extern void XLogSetAsyncXactLSN(XLogRecPtr record);

extern Buffer RestoreBackupBlock(XLogRecPtr lsn, XLogRecord *record,
       int block_index,
       bool get_cleanup_lock, bool keep_buffer);

extern void xlog_redo(XLogRecPtr lsn, XLogRecord *record);
extern void xlog_desc(StringInfo buf, uint8 xl_info, char *rec);

extern void issue_xlog_fsync(int fd, uint32 log, uint32 seg);

extern bool RecoveryInProgress(void);
extern bool HotStandbyActive(void);
extern bool XLogInsertAllowed(void);
extern void GetXLogReceiptTime(TimestampTz *rtime, bool *fromStream);
extern XLogRecPtr GetXLogReplayRecPtr(TimeLineID *targetTLI);
extern XLogRecPtr GetStandbyFlushRecPtr(TimeLineID *targetTLI);
extern XLogRecPtr GetXLogInsertRecPtr(void);
extern XLogRecPtr GetXLogWriteRecPtr(void);
extern bool RecoveryIsPaused(void);
extern void SetRecoveryPause(bool recoveryPause);
extern TimestampTz GetLatestXTime(void);
extern TimestampTz GetCurrentChunkReplayStartTime(void);

extern void UpdateControlFile(void);
extern uint64 GetSystemIdentifier(void);
extern Size XLOGShmemSize(void);
extern void XLOGShmemInit(void);
extern void BootStrapXLOG(void);
extern void StartupXLOG(void);
extern void ShutdownXLOG(int code, Datum arg);
extern void InitXLOGAccess(void);
extern void CreateCheckPoint(int flags);
extern bool CreateRestartPoint(int flags);
extern void XLogPutNextOid(Oid nextOid);
extern XLogRecPtr XLogRestorePoint(const char *rpName);
extern void UpdateFullPageWrites(void);
extern XLogRecPtr GetRedoRecPtr(void);
extern XLogRecPtr GetInsertRecPtr(void);
extern XLogRecPtr GetFlushRecPtr(void);
extern void GetNextXidAndEpoch(TransactionId *xid, uint32 *epoch);
extern TimeLineID GetRecoveryTargetTLI(void);

extern bool CheckPromoteSignal(void);
extern void WakeupRecovery(void);
extern void SetWalWriterSleeping(bool sleeping);




extern XLogRecPtr do_pg_start_backup(const char *backupidstr, bool fast, char **labelfile);
extern XLogRecPtr do_pg_stop_backup(char *labelfile, bool waitforarchive);
extern void do_pg_abort_backup(void);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 1
# 40 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h" 1
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum NodeTag
{
 T_Invalid = 0,




 T_IndexInfo = 10,
 T_ExprContext,
 T_ProjectionInfo,
 T_JunkFilter,
 T_ResultRelInfo,
 T_EState,
 T_TupleTableSlot,




 T_Plan = 100,
 T_Result,
 T_ModifyTable,
 T_Append,
 T_MergeAppend,
 T_RecursiveUnion,
 T_BitmapAnd,
 T_BitmapOr,
 T_Scan,
 T_SeqScan,
 T_IndexScan,
 T_IndexOnlyScan,
 T_BitmapIndexScan,
 T_BitmapHeapScan,
 T_TidScan,
 T_SubqueryScan,
 T_FunctionScan,
 T_ValuesScan,
 T_CteScan,
 T_WorkTableScan,
 T_ForeignScan,
 T_Join,
 T_NestLoop,
 T_MergeJoin,
 T_HashJoin,
 T_Material,
 T_Sort,
 T_Group,
 T_Agg,
 T_WindowAgg,
 T_Unique,
 T_Hash,
 T_SetOp,
 T_LockRows,
 T_Limit,

 T_NestLoopParam,
 T_PlanRowMark,
 T_PlanInvalItem,






 T_PlanState = 200,
 T_ResultState,
 T_ModifyTableState,
 T_AppendState,
 T_MergeAppendState,
 T_RecursiveUnionState,
 T_BitmapAndState,
 T_BitmapOrState,
 T_ScanState,
 T_SeqScanState,
 T_IndexScanState,
 T_IndexOnlyScanState,
 T_BitmapIndexScanState,
 T_BitmapHeapScanState,
 T_TidScanState,
 T_SubqueryScanState,
 T_FunctionScanState,
 T_ValuesScanState,
 T_CteScanState,
 T_WorkTableScanState,
 T_ForeignScanState,
 T_JoinState,
 T_NestLoopState,
 T_MergeJoinState,
 T_HashJoinState,
 T_MaterialState,
 T_SortState,
 T_GroupState,
 T_AggState,
 T_WindowAggState,
 T_UniqueState,
 T_HashState,
 T_SetOpState,
 T_LockRowsState,
 T_LimitState,




 T_Alias = 300,
 T_RangeVar,
 T_Expr,
 T_Var,
 T_Const,
 T_Param,
 T_Aggref,
 T_WindowFunc,
 T_ArrayRef,
 T_FuncExpr,
 T_NamedArgExpr,
 T_OpExpr,
 T_DistinctExpr,
 T_NullIfExpr,
 T_ScalarArrayOpExpr,
 T_BoolExpr,
 T_SubLink,
 T_SubPlan,
 T_AlternativeSubPlan,
 T_FieldSelect,
 T_FieldStore,
 T_RelabelType,
 T_CoerceViaIO,
 T_ArrayCoerceExpr,
 T_ConvertRowtypeExpr,
 T_CollateExpr,
 T_CaseExpr,
 T_CaseWhen,
 T_CaseTestExpr,
 T_ArrayExpr,
 T_RowExpr,
 T_RowCompareExpr,
 T_CoalesceExpr,
 T_MinMaxExpr,
 T_XmlExpr,
 T_NullTest,
 T_BooleanTest,
 T_CoerceToDomain,
 T_CoerceToDomainValue,
 T_SetToDefault,
 T_CurrentOfExpr,
 T_TargetEntry,
 T_RangeTblRef,
 T_JoinExpr,
 T_FromExpr,
 T_IntoClause,







 T_ExprState = 400,
 T_GenericExprState,
 T_AggrefExprState,
 T_WindowFuncExprState,
 T_ArrayRefExprState,
 T_FuncExprState,
 T_ScalarArrayOpExprState,
 T_BoolExprState,
 T_SubPlanState,
 T_AlternativeSubPlanState,
 T_FieldSelectState,
 T_FieldStoreState,
 T_CoerceViaIOState,
 T_ArrayCoerceExprState,
 T_ConvertRowtypeExprState,
 T_CaseExprState,
 T_CaseWhenState,
 T_ArrayExprState,
 T_RowExprState,
 T_RowCompareExprState,
 T_CoalesceExprState,
 T_MinMaxExprState,
 T_XmlExprState,
 T_NullTestState,
 T_CoerceToDomainState,
 T_DomainConstraintState,
 T_WholeRowVarExprState,




 T_PlannerInfo = 500,
 T_PlannerGlobal,
 T_RelOptInfo,
 T_IndexOptInfo,
 T_ParamPathInfo,
 T_Path,
 T_IndexPath,
 T_BitmapHeapPath,
 T_BitmapAndPath,
 T_BitmapOrPath,
 T_NestPath,
 T_MergePath,
 T_HashPath,
 T_TidPath,
 T_ForeignPath,
 T_AppendPath,
 T_MergeAppendPath,
 T_ResultPath,
 T_MaterialPath,
 T_UniquePath,
 T_EquivalenceClass,
 T_EquivalenceMember,
 T_PathKey,
 T_RestrictInfo,
 T_PlaceHolderVar,
 T_SpecialJoinInfo,
 T_AppendRelInfo,
 T_PlaceHolderInfo,
 T_MinMaxAggInfo,
 T_PlannerParamItem,




 T_MemoryContext = 600,
 T_AllocSetContext,




 T_Value = 650,
 T_Integer,
 T_Float,
 T_String,
 T_BitString,
 T_Null,




 T_List,
 T_IntList,
 T_OidList,




 T_Query = 700,
 T_PlannedStmt,
 T_InsertStmt,
 T_DeleteStmt,
 T_UpdateStmt,
 T_SelectStmt,
 T_AlterTableStmt,
 T_AlterTableCmd,
 T_AlterDomainStmt,
 T_SetOperationStmt,
 T_GrantStmt,
 T_GrantRoleStmt,
 T_AlterDefaultPrivilegesStmt,
 T_ClosePortalStmt,
 T_ClusterStmt,
 T_CopyStmt,
 T_CreateStmt,
 T_DefineStmt,
 T_DropStmt,
 T_TruncateStmt,
 T_CommentStmt,
 T_FetchStmt,
 T_IndexStmt,
 T_CreateFunctionStmt,
 T_AlterFunctionStmt,
 T_DoStmt,
 T_RenameStmt,
 T_RuleStmt,
 T_NotifyStmt,
 T_ListenStmt,
 T_UnlistenStmt,
 T_TransactionStmt,
 T_ViewStmt,
 T_LoadStmt,
 T_CreateDomainStmt,
 T_CreatedbStmt,
 T_DropdbStmt,
 T_VacuumStmt,
 T_ExplainStmt,
 T_CreateTableAsStmt,
 T_CreateSeqStmt,
 T_AlterSeqStmt,
 T_VariableSetStmt,
 T_VariableShowStmt,
 T_DiscardStmt,
 T_CreateTrigStmt,
 T_CreatePLangStmt,
 T_CreateRoleStmt,
 T_AlterRoleStmt,
 T_DropRoleStmt,
 T_LockStmt,
 T_ConstraintsSetStmt,
 T_ReindexStmt,
 T_CheckPointStmt,
 T_CreateSchemaStmt,
 T_AlterDatabaseStmt,
 T_AlterDatabaseSetStmt,
 T_AlterRoleSetStmt,
 T_CreateConversionStmt,
 T_CreateCastStmt,
 T_CreateOpClassStmt,
 T_CreateOpFamilyStmt,
 T_AlterOpFamilyStmt,
 T_PrepareStmt,
 T_ExecuteStmt,
 T_DeallocateStmt,
 T_DeclareCursorStmt,
 T_CreateTableSpaceStmt,
 T_DropTableSpaceStmt,
 T_AlterObjectSchemaStmt,
 T_AlterOwnerStmt,
 T_DropOwnedStmt,
 T_ReassignOwnedStmt,
 T_CompositeTypeStmt,
 T_CreateEnumStmt,
 T_CreateRangeStmt,
 T_AlterEnumStmt,
 T_AlterTSDictionaryStmt,
 T_AlterTSConfigurationStmt,
 T_CreateFdwStmt,
 T_AlterFdwStmt,
 T_CreateForeignServerStmt,
 T_AlterForeignServerStmt,
 T_CreateUserMappingStmt,
 T_AlterUserMappingStmt,
 T_DropUserMappingStmt,
 T_AlterTableSpaceOptionsStmt,
 T_SecLabelStmt,
 T_CreateForeignTableStmt,
 T_CreateExtensionStmt,
 T_AlterExtensionStmt,
 T_AlterExtensionContentsStmt,




 T_A_Expr = 900,
 T_ColumnRef,
 T_ParamRef,
 T_A_Const,
 T_FuncCall,
 T_A_Star,
 T_A_Indices,
 T_A_Indirection,
 T_A_ArrayExpr,
 T_ResTarget,
 T_TypeCast,
 T_CollateClause,
 T_SortBy,
 T_WindowDef,
 T_RangeSubselect,
 T_RangeFunction,
 T_TypeName,
 T_ColumnDef,
 T_IndexElem,
 T_Constraint,
 T_DefElem,
 T_RangeTblEntry,
 T_SortGroupClause,
 T_WindowClause,
 T_PrivGrantee,
 T_FuncWithArgs,
 T_AccessPriv,
 T_CreateOpClassItem,
 T_TableLikeClause,
 T_FunctionParameter,
 T_LockingClause,
 T_RowMarkClause,
 T_XmlSerialize,
 T_WithClause,
 T_CommonTableExpr,




 T_IdentifySystemCmd,
 T_BaseBackupCmd,
 T_StartReplicationCmd,
# 416 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
 T_TriggerData = 950,
 T_ReturnSetInfo,
 T_WindowObjectData,
 T_TIDBitmap,
 T_InlineCodeBlock,
 T_FdwRoutine
} NodeTag;







typedef struct Node
{
 NodeTag type;
} Node;
# 491 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
extern char *nodeToString(const void *obj);




extern void *stringToNode(char *str);




extern void *copyObject(const void *obj);




extern bool equal(const void *a, const void *b);
# 517 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef double Selectivity;
typedef double Cost;
# 527 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum CmdType
{
 CMD_UNKNOWN,
 CMD_SELECT,
 CMD_UPDATE,
 CMD_INSERT,
 CMD_DELETE,
 CMD_UTILITY,

 CMD_NOTHING

} CmdType;
# 551 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum JoinType
{




 JOIN_INNER,
 JOIN_LEFT,
 JOIN_FULL,
 JOIN_RIGHT,
# 571 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
 JOIN_SEMI,
 JOIN_ANTI,





 JOIN_UNIQUE_OUTER,
 JOIN_UNIQUE_INNER




} JoinType;
# 41 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 2


typedef struct ListCell ListCell;

typedef struct List
{
 NodeTag type;
 int length;
 ListCell *head;
 ListCell *tail;
} List;

struct ListCell
{
 union
 {
  void *ptr_value;
  int int_value;
  Oid oid_value;
 } data;
 ListCell *next;
};
# 79 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
static inline ListCell *
list_head(const List *l)
{
 return l ? l->head : ((void *)0);
}

static inline ListCell *
list_tail(List *l)
{
 return l ? l->tail : ((void *)0);
}

static inline int
list_length(const List *l)
{
 return l ? l->length : 0;
}
# 194 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
extern List *lappend(List *list, void *datum);
extern List *lappend_int(List *list, int datum);
extern List *lappend_oid(List *list, Oid datum);

extern ListCell *lappend_cell(List *list, ListCell *prev, void *datum);
extern ListCell *lappend_cell_int(List *list, ListCell *prev, int datum);
extern ListCell *lappend_cell_oid(List *list, ListCell *prev, Oid datum);

extern List *lcons(void *datum, List *list);
extern List *lcons_int(int datum, List *list);
extern List *lcons_oid(Oid datum, List *list);

extern List *list_concat(List *list1, List *list2);
extern List *list_truncate(List *list, int new_size);

extern void *list_nth(const List *list, int n);
extern int list_nth_int(const List *list, int n);
extern Oid list_nth_oid(const List *list, int n);

extern bool list_member(const List *list, const void *datum);
extern bool list_member_ptr(const List *list, const void *datum);
extern bool list_member_int(const List *list, int datum);
extern bool list_member_oid(const List *list, Oid datum);

extern List *list_delete(List *list, void *datum);
extern List *list_delete_ptr(List *list, void *datum);
extern List *list_delete_int(List *list, int datum);
extern List *list_delete_oid(List *list, Oid datum);
extern List *list_delete_first(List *list);
extern List *list_delete_cell(List *list, ListCell *cell, ListCell *prev);

extern List *list_union(const List *list1, const List *list2);
extern List *list_union_ptr(const List *list1, const List *list2);
extern List *list_union_int(const List *list1, const List *list2);
extern List *list_union_oid(const List *list1, const List *list2);

extern List *list_intersection(const List *list1, const List *list2);



extern List *list_difference(const List *list1, const List *list2);
extern List *list_difference_ptr(const List *list1, const List *list2);
extern List *list_difference_int(const List *list1, const List *list2);
extern List *list_difference_oid(const List *list1, const List *list2);

extern List *list_append_unique(List *list, void *datum);
extern List *list_append_unique_ptr(List *list, void *datum);
extern List *list_append_unique_int(List *list, int datum);
extern List *list_append_unique_oid(List *list, Oid datum);

extern List *list_concat_unique(List *list1, List *list2);
extern List *list_concat_unique_ptr(List *list1, List *list2);
extern List *list_concat_unique_int(List *list1, List *list2);
extern List *list_concat_unique_oid(List *list1, List *list2);

extern void list_free(List *list);
extern void list_free_deep(List *list);

extern List *list_copy(const List *list);
extern List *list_copy_tail(const List *list, int nskip);
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 2
# 38 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Alias
{
 NodeTag type;
 char *aliasname;
 List *colnames;
} Alias;

typedef enum InhOption
{
 INH_NO,
 INH_YES,
 INH_DEFAULT
} InhOption;


typedef enum OnCommitAction
{
 ONCOMMIT_NOOP,
 ONCOMMIT_PRESERVE_ROWS,
 ONCOMMIT_DELETE_ROWS,
 ONCOMMIT_DROP
} OnCommitAction;
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RangeVar
{
 NodeTag type;
 char *catalogname;
 char *schemaname;
 char *relname;
 InhOption inhOpt;

 char relpersistence;
 Alias *alias;
 int location;
} RangeVar;




typedef struct IntoClause
{
 NodeTag type;

 RangeVar *rel;
 List *colNames;
 List *options;
 OnCommitAction onCommit;
 char *tableSpaceName;
 bool skipData;
} IntoClause;
# 111 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Expr
{
 NodeTag type;
} Expr;
# 138 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Var
{
 Expr xpr;
 Index varno;

 AttrNumber varattno;

 Oid vartype;
 int32 vartypmod;
 Oid varcollid;
 Index varlevelsup;


 Index varnoold;
 AttrNumber varoattno;
 int location;
} Var;




typedef struct Const
{
 Expr xpr;
 Oid consttype;
 int32 consttypmod;
 Oid constcollid;
 int constlen;
 Datum constvalue;
 bool constisnull;

 bool constbyval;



 int location;
} Const;
# 201 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum ParamKind
{
 PARAM_EXTERN,
 PARAM_EXEC,
 PARAM_SUBLINK
} ParamKind;

typedef struct Param
{
 Expr xpr;
 ParamKind paramkind;
 int paramid;
 Oid paramtype;
 int32 paramtypmod;
 Oid paramcollid;
 int location;
} Param;
# 234 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Aggref
{
 Expr xpr;
 Oid aggfnoid;
 Oid aggtype;
 Oid aggcollid;
 Oid inputcollid;
 List *args;
 List *aggorder;
 List *aggdistinct;
 bool aggstar;
 Index agglevelsup;
 int location;
} Aggref;




typedef struct WindowFunc
{
 Expr xpr;
 Oid winfnoid;
 Oid wintype;
 Oid wincollid;
 Oid inputcollid;
 List *args;
 Index winref;
 bool winstar;
 bool winagg;
 int location;
} WindowFunc;
# 288 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ArrayRef
{
 Expr xpr;
 Oid refarraytype;
 Oid refelemtype;
 int32 reftypmod;
 Oid refcollid;
 List *refupperindexpr;

 List *reflowerindexpr;

 Expr *refexpr;

 Expr *refassgnexpr;

} ArrayRef;







typedef enum CoercionContext
{
 COERCION_IMPLICIT,
 COERCION_ASSIGNMENT,
 COERCION_EXPLICIT
} CoercionContext;
# 327 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum CoercionForm
{
 COERCE_EXPLICIT_CALL,
 COERCE_EXPLICIT_CAST,
 COERCE_IMPLICIT_CAST,
 COERCE_DONTCARE
} CoercionForm;




typedef struct FuncExpr
{
 Expr xpr;
 Oid funcid;
 Oid funcresulttype;
 bool funcretset;
 CoercionForm funcformat;
 Oid funccollid;
 Oid inputcollid;
 List *args;
 int location;
} FuncExpr;
# 365 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct NamedArgExpr
{
 Expr xpr;
 Expr *arg;
 char *name;
 int argnumber;
 int location;
} NamedArgExpr;
# 383 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct OpExpr
{
 Expr xpr;
 Oid opno;
 Oid opfuncid;
 Oid opresulttype;
 bool opretset;
 Oid opcollid;
 Oid inputcollid;
 List *args;
 int location;
} OpExpr;
# 406 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef OpExpr DistinctExpr;







typedef OpExpr NullIfExpr;
# 426 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ScalarArrayOpExpr
{
 Expr xpr;
 Oid opno;
 Oid opfuncid;
 bool useOr;
 Oid inputcollid;
 List *args;
 int location;
} ScalarArrayOpExpr;
# 448 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum BoolExprType
{
 AND_EXPR, OR_EXPR, NOT_EXPR
} BoolExprType;

typedef struct BoolExpr
{
 Expr xpr;
 BoolExprType boolop;
 List *args;
 int location;
} BoolExpr;
# 504 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum SubLinkType
{
 EXISTS_SUBLINK,
 ALL_SUBLINK,
 ANY_SUBLINK,
 ROWCOMPARE_SUBLINK,
 EXPR_SUBLINK,
 ARRAY_SUBLINK,
 CTE_SUBLINK
} SubLinkType;


typedef struct SubLink
{
 Expr xpr;
 SubLinkType subLinkType;
 Node *testexpr;
 List *operName;
 Node *subselect;
 int location;
} SubLink;
# 564 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct SubPlan
{
 Expr xpr;

 SubLinkType subLinkType;

 Node *testexpr;
 List *paramIds;

 int plan_id;

 char *plan_name;

 Oid firstColType;
 int32 firstColTypmod;
 Oid firstColCollation;


 bool useHashTable;

 bool unknownEqFalse;




 List *setParam;

 List *parParam;
 List *args;

 Cost startup_cost;
 Cost per_call_cost;
} SubPlan;
# 606 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct AlternativeSubPlan
{
 Expr xpr;
 List *subplans;
} AlternativeSubPlan;
# 621 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct FieldSelect
{
 Expr xpr;
 Expr *arg;
 AttrNumber fieldnum;
 Oid resulttype;

 int32 resulttypmod;
 Oid resultcollid;
} FieldSelect;
# 647 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct FieldStore
{
 Expr xpr;
 Expr *arg;
 List *newvals;
 List *fieldnums;
 Oid resulttype;

} FieldStore;
# 670 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RelabelType
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;
 int32 resulttypmod;
 Oid resultcollid;
 CoercionForm relabelformat;
 int location;
} RelabelType;
# 690 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CoerceViaIO
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;

 Oid resultcollid;
 CoercionForm coerceformat;
 int location;
} CoerceViaIO;
# 713 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ArrayCoerceExpr
{
 Expr xpr;
 Expr *arg;
 Oid elemfuncid;
 Oid resulttype;
 int32 resulttypmod;
 Oid resultcollid;
 bool isExplicit;
 CoercionForm coerceformat;
 int location;
} ArrayCoerceExpr;
# 738 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ConvertRowtypeExpr
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;

 CoercionForm convertformat;
 int location;
} ConvertRowtypeExpr;
# 755 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CollateExpr
{
 Expr xpr;
 Expr *arg;
 Oid collOid;
 int location;
} CollateExpr;
# 785 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CaseExpr
{
 Expr xpr;
 Oid casetype;
 Oid casecollid;
 Expr *arg;
 List *args;
 Expr *defresult;
 int location;
} CaseExpr;




typedef struct CaseWhen
{
 Expr xpr;
 Expr *expr;
 Expr *result;
 int location;
} CaseWhen;
# 815 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CaseTestExpr
{
 Expr xpr;
 Oid typeId;
 int32 typeMod;
 Oid collation;
} CaseTestExpr;
# 831 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ArrayExpr
{
 Expr xpr;
 Oid array_typeid;
 Oid array_collid;
 Oid element_typeid;
 List *elements;
 bool multidims;
 int location;
} ArrayExpr;
# 865 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RowExpr
{
 Expr xpr;
 List *args;
 Oid row_typeid;
# 880 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
 CoercionForm row_format;
 List *colnames;
 int location;
} RowExpr;
# 899 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum RowCompareType
{

 ROWCOMPARE_LT = 1,
 ROWCOMPARE_LE = 2,
 ROWCOMPARE_EQ = 3,
 ROWCOMPARE_GE = 4,
 ROWCOMPARE_GT = 5,
 ROWCOMPARE_NE = 6
} RowCompareType;

typedef struct RowCompareExpr
{
 Expr xpr;
 RowCompareType rctype;
 List *opnos;
 List *opfamilies;
 List *inputcollids;
 List *largs;
 List *rargs;
} RowCompareExpr;




typedef struct CoalesceExpr
{
 Expr xpr;
 Oid coalescetype;
 Oid coalescecollid;
 List *args;
 int location;
} CoalesceExpr;




typedef enum MinMaxOp
{
 IS_GREATEST,
 IS_LEAST
} MinMaxOp;

typedef struct MinMaxExpr
{
 Expr xpr;
 Oid minmaxtype;
 Oid minmaxcollid;
 Oid inputcollid;
 MinMaxOp op;
 List *args;
 int location;
} MinMaxExpr;
# 965 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum XmlExprOp
{
 IS_XMLCONCAT,
 IS_XMLELEMENT,
 IS_XMLFOREST,
 IS_XMLPARSE,
 IS_XMLPI,
 IS_XMLROOT,
 IS_XMLSERIALIZE,
 IS_DOCUMENT
} XmlExprOp;

typedef enum
{
 XMLOPTION_DOCUMENT,
 XMLOPTION_CONTENT
} XmlOptionType;

typedef struct XmlExpr
{
 Expr xpr;
 XmlExprOp op;
 char *name;
 List *named_args;
 List *arg_names;
 List *args;
 XmlOptionType xmloption;
 Oid type;
 int32 typmod;
 int location;
} XmlExpr;
# 1008 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum NullTestType
{
 IS_NULL, IS_NOT_NULL
} NullTestType;

typedef struct NullTest
{
 Expr xpr;
 Expr *arg;
 NullTestType nulltesttype;
 bool argisrow;
} NullTest;
# 1030 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum BoolTestType
{
 IS_TRUE, IS_NOT_TRUE, IS_FALSE, IS_NOT_FALSE, IS_UNKNOWN, IS_NOT_UNKNOWN
} BoolTestType;

typedef struct BooleanTest
{
 Expr xpr;
 Expr *arg;
 BoolTestType booltesttype;
} BooleanTest;
# 1051 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CoerceToDomain
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;
 int32 resulttypmod;
 Oid resultcollid;
 CoercionForm coercionformat;
 int location;
} CoerceToDomain;
# 1071 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CoerceToDomainValue
{
 Expr xpr;
 Oid typeId;
 int32 typeMod;
 Oid collation;
 int location;
} CoerceToDomainValue;
# 1087 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct SetToDefault
{
 Expr xpr;
 Oid typeId;
 int32 typeMod;
 Oid collation;
 int location;
} SetToDefault;
# 1108 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CurrentOfExpr
{
 Expr xpr;
 Index cvarno;
 char *cursor_name;
 int cursor_param;
} CurrentOfExpr;
# 1170 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct TargetEntry
{
 Expr xpr;
 Expr *expr;
 AttrNumber resno;
 char *resname;
 Index ressortgroupref;

 Oid resorigtbl;
 AttrNumber resorigcol;
 bool resjunk;

} TargetEntry;
# 1222 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RangeTblRef
{
 NodeTag type;
 int rtindex;
} RangeTblRef;
# 1251 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct JoinExpr
{
 NodeTag type;
 JoinType jointype;
 bool isNatural;
 Node *larg;
 Node *rarg;
 List *usingClause;
 Node *quals;
 Alias *alias;
 int rtindex;
} JoinExpr;
# 1273 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct FromExpr
{
 NodeTag type;
 List *fromlist;
 Node *quals;
} FromExpr;
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/backendid.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/backendid.h"
typedef int BackendId;



extern BackendId MyBackendId;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lwlock.h" 1
# 47 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lwlock.h"
typedef enum LWLockId
{
 BufFreelistLock,
 ShmemIndexLock,
 OidGenLock,
 XidGenLock,
 ProcArrayLock,
 SInvalReadLock,
 SInvalWriteLock,
 WALInsertLock,
 WALWriteLock,
 ControlFileLock,
 CheckpointLock,
 CLogControlLock,
 SubtransControlLock,
 MultiXactGenLock,
 MultiXactOffsetControlLock,
 MultiXactMemberControlLock,
 RelCacheInitLock,
 CheckpointerCommLock,
 TwoPhaseStateLock,
 TablespaceCreateLock,
 BtreeVacuumLock,
 AddinShmemInitLock,
 AutovacuumLock,
 AutovacuumScheduleLock,
 SyncScanLock,
 RelationMappingLock,
 AsyncCtlLock,
 AsyncQueueLock,
 SerializableXactHashLock,
 SerializableFinishedListLock,
 SerializablePredicateLockListLock,
 OldSerXidLock,
 SyncRepLock,

 FirstBufMappingLock,
 FirstLockMgrLock = FirstBufMappingLock + 16,
 FirstPredicateLockMgrLock = FirstLockMgrLock + (1 << 4),


 NumFixedLWLocks = FirstPredicateLockMgrLock + (1 << 4),

 MaxDynamicLWLock = 1000000000
} LWLockId;


typedef enum LWLockMode
{
 LW_EXCLUSIVE,
 LW_SHARED,
 LW_WAIT_UNTIL_FREE


} LWLockMode;






extern LWLockId LWLockAssign(void);
extern void LWLockAcquire(LWLockId lockid, LWLockMode mode);
extern bool LWLockConditionalAcquire(LWLockId lockid, LWLockMode mode);
extern bool LWLockAcquireOrWait(LWLockId lockid, LWLockMode mode);
extern void LWLockRelease(LWLockId lockid);
extern void LWLockReleaseAll(void);
extern bool LWLockHeldByMe(LWLockId lockid);

extern int NumLWLocks(void);
extern Size LWLockShmemSize(void);
extern void CreateLWLocks(void);

extern void RequestAddinLWLocks(int n);
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/shmem.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/shmem.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/hsearch.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/hsearch.h"
typedef uint32 (*HashValueFunc) (const void *key, Size keysize);







typedef int (*HashCompareFunc) (const void *key1, const void *key2,
           Size keysize);






typedef void *(*HashCopyFunc) (void *dest, const void *src, Size keysize);






typedef void *(*HashAllocFunc) (Size request);






typedef struct HASHELEMENT
{
 struct HASHELEMENT *link;
 uint32 hashvalue;
} HASHELEMENT;


typedef struct HASHHDR HASHHDR;


typedef struct HTAB HTAB;



typedef struct HASHCTL
{
 long num_partitions;
 long ssize;
 long dsize;
 long max_dsize;
 long ffactor;
 Size keysize;
 Size entrysize;
 HashValueFunc hash;
 HashCompareFunc match;
 HashCopyFunc keycopy;
 HashAllocFunc alloc;
 MemoryContext hcxt;
 HASHHDR *hctl;
} HASHCTL;
# 102 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/hsearch.h"
typedef enum
{
 HASH_FIND,
 HASH_ENTER,
 HASH_REMOVE,
 HASH_ENTER_NULL
} HASHACTION;


typedef struct
{
 HTAB *hashp;
 uint32 curBucket;
 HASHELEMENT *curEntry;
} HASH_SEQ_STATUS;




extern HTAB *hash_create(const char *tabname, long nelem,
   HASHCTL *info, int flags);
extern void hash_destroy(HTAB *hashp);
extern void hash_stats(const char *where, HTAB *hashp);
extern void *hash_search(HTAB *hashp, const void *keyPtr, HASHACTION action,
   bool *foundPtr);
extern uint32 get_hash_value(HTAB *hashp, const void *keyPtr);
extern void *hash_search_with_hash_value(HTAB *hashp, const void *keyPtr,
       uint32 hashvalue, HASHACTION action,
       bool *foundPtr);
extern long hash_get_num_entries(HTAB *hashp);
extern void hash_seq_init(HASH_SEQ_STATUS *status, HTAB *hashp);
extern void *hash_seq_search(HASH_SEQ_STATUS *status);
extern void hash_seq_term(HASH_SEQ_STATUS *status);
extern void hash_freeze(HTAB *hashp);
extern Size hash_estimate_size(long num_entries, Size entrysize);
extern long hash_select_dirsize(long num_entries);
extern Size hash_get_shared_size(HASHCTL *info, int flags);
extern void AtEOXact_HashTables(bool isCommit);
extern void AtEOSubXact_HashTables(bool isCommit, int nestDepth);




extern uint32 string_hash(const void *key, Size keysize);
extern uint32 tag_hash(const void *key, Size keysize);
extern uint32 oid_hash(const void *key, Size keysize);
extern uint32 bitmap_hash(const void *key, Size keysize);
extern int bitmap_match(const void *key1, const void *key2, Size keysize);
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/shmem.h" 2



typedef struct SHM_QUEUE
{
 struct SHM_QUEUE *prev;
 struct SHM_QUEUE *next;
} SHM_QUEUE;


extern void InitShmemAccess(void *seghdr);
extern void InitShmemAllocation(void);
extern void *ShmemAlloc(Size size);
extern bool ShmemAddrIsValid(const void *addr);
extern void InitShmemIndex(void);
extern HTAB *ShmemInitHash(const char *name, long init_size, long max_size,
     HASHCTL *infoP, int hash_flags);
extern void *ShmemInitStruct(const char *name, Size size, bool *foundPtr);
extern Size add_size(Size s1, Size s2);
extern Size mul_size(Size s1, Size s2);


extern void RequestAddinShmemSpace(Size size);
# 56 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/shmem.h"
typedef struct
{
 char key[(48)];
 void *location;
 Size size;
} ShmemIndexEnt;




extern void SHMQueueInit(SHM_QUEUE *queue);
extern void SHMQueueElemInit(SHM_QUEUE *queue);
extern void SHMQueueDelete(SHM_QUEUE *queue);
extern void SHMQueueInsertBefore(SHM_QUEUE *queue, SHM_QUEUE *elem);
extern void SHMQueueInsertAfter(SHM_QUEUE *queue, SHM_QUEUE *elem);
extern Pointer SHMQueueNext(const SHM_QUEUE *queue, const SHM_QUEUE *curElem,
    Size linkOffset);
extern Pointer SHMQueuePrev(const SHM_QUEUE *queue, const SHM_QUEUE *curElem,
    Size linkOffset);
extern bool SHMQueueEmpty(const SHM_QUEUE *queue);
extern bool SHMQueueIsDetached(const SHM_QUEUE *queue);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h" 2



typedef struct PGPROC PGPROC;

typedef struct PROC_QUEUE
{
 SHM_QUEUE links;
 int size;
} PROC_QUEUE;


extern int max_locks_per_xact;
# 58 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct
{
 BackendId backendId;
 LocalTransactionId localTransactionId;

} VirtualTransactionId;
# 86 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef int LOCKMASK;
typedef int LOCKMODE;
# 116 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct LockMethodData
{
 int numLockModes;
 const LOCKMASK *conflictTab;
 const char *const * lockModeNames;
 const bool *trace_flag;
} LockMethodData;

typedef const LockMethodData *LockMethod;





typedef uint16 LOCKMETHODID;
# 165 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef enum LockTagType
{
 LOCKTAG_RELATION,

 LOCKTAG_RELATION_EXTEND,

 LOCKTAG_PAGE,

 LOCKTAG_TUPLE,

 LOCKTAG_TRANSACTION,

 LOCKTAG_VIRTUALTRANSACTION,

 LOCKTAG_OBJECT,







 LOCKTAG_USERLOCK,
 LOCKTAG_ADVISORY
} LockTagType;
# 201 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct LOCKTAG
{
 uint32 locktag_field1;
 uint32 locktag_field2;
 uint32 locktag_field3;
 uint16 locktag_field4;
 uint8 locktag_type;
 uint8 locktag_lockmethodid;
} LOCKTAG;
# 299 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct LOCK
{

 LOCKTAG tag;


 LOCKMASK grantMask;
 LOCKMASK waitMask;
 SHM_QUEUE procLocks;
 PROC_QUEUE waitProcs;
 int requested[10];
 int nRequested;
 int granted[10];
 int nGranted;
} LOCK;
# 352 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct PROCLOCKTAG
{

 LOCK *myLock;
 PGPROC *myProc;
} PROCLOCKTAG;

typedef struct PROCLOCK
{

 PROCLOCKTAG tag;


 LOCKMASK holdMask;
 LOCKMASK releaseMask;
 SHM_QUEUE lockLink;
 SHM_QUEUE procLink;
} PROCLOCK;
# 383 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct LOCALLOCKTAG
{
 LOCKTAG lock;
 LOCKMODE mode;
} LOCALLOCKTAG;

typedef struct LOCALLOCKOWNER
{






 struct ResourceOwnerData *owner;
 int64 nLocks;
} LOCALLOCKOWNER;

typedef struct LOCALLOCK
{

 LOCALLOCKTAG tag;


 LOCK *lock;
 PROCLOCK *proclock;
 uint32 hashcode;
 int64 nLocks;
 int numLockOwners;
 int maxLockOwners;
 bool holdsStrongLockCount;
 LOCALLOCKOWNER *lockOwners;
} LOCALLOCK;
# 425 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct LockInstanceData
{
 LOCKTAG locktag;
 LOCKMASK holdMask;
 LOCKMODE waitLockMode;
 BackendId backend;
 LocalTransactionId lxid;
 int pid;
 bool fastpath;
} LockInstanceData;

typedef struct LockData
{
 int nelements;
 LockInstanceData *locks;
} LockData;



typedef enum
{
 LOCKACQUIRE_NOT_AVAIL,
 LOCKACQUIRE_OK,
 LOCKACQUIRE_ALREADY_HELD
} LockAcquireResult;


typedef enum
{
 DS_NOT_YET_CHECKED,
 DS_NO_DEADLOCK,
 DS_SOFT_DEADLOCK,
 DS_HARD_DEADLOCK,
 DS_BLOCKED_BY_AUTOVACUUM

} DeadLockState;
# 478 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
extern void InitLocks(void);
extern LockMethod GetLocksMethodTable(const LOCK *lock);
extern uint32 LockTagHashCode(const LOCKTAG *locktag);
extern LockAcquireResult LockAcquire(const LOCKTAG *locktag,
   LOCKMODE lockmode,
   bool sessionLock,
   bool dontWait);
extern LockAcquireResult LockAcquireExtended(const LOCKTAG *locktag,
     LOCKMODE lockmode,
     bool sessionLock,
     bool dontWait,
     bool report_memory_error);
extern void AbortStrongLockAcquire(void);
extern bool LockRelease(const LOCKTAG *locktag,
   LOCKMODE lockmode, bool sessionLock);
extern void LockReleaseAll(LOCKMETHODID lockmethodid, bool allLocks);
extern void LockReleaseSession(LOCKMETHODID lockmethodid);
extern void LockReleaseCurrentOwner(void);
extern void LockReassignCurrentOwner(void);
extern bool LockHasWaiters(const LOCKTAG *locktag,
      LOCKMODE lockmode, bool sessionLock);
extern VirtualTransactionId *GetLockConflicts(const LOCKTAG *locktag,
     LOCKMODE lockmode);
extern void AtPrepare_Locks(void);
extern void PostPrepare_Locks(TransactionId xid);
extern int LockCheckConflicts(LockMethod lockMethodTable,
       LOCKMODE lockmode,
       LOCK *lock, PROCLOCK *proclock, PGPROC *proc);
extern void GrantLock(LOCK *lock, PROCLOCK *proclock, LOCKMODE lockmode);
extern void GrantAwaitedLock(void);
extern void RemoveFromWaitQueue(PGPROC *proc, uint32 hashcode);
extern Size LockShmemSize(void);
extern LockData *GetLockStatusData(void);

extern void ReportLockTableError(bool report);

typedef struct xl_standby_lock
{
 TransactionId xid;
 Oid dbOid;
 Oid relOid;
} xl_standby_lock;

extern xl_standby_lock *GetRunningTransactionLocks(int *nlocks);
extern const char *GetLockmodeName(LOCKMETHODID lockmethodid, LOCKMODE mode);

extern void lock_twophase_recover(TransactionId xid, uint16 info,
       void *recdata, uint32 len);
extern void lock_twophase_postcommit(TransactionId xid, uint16 info,
       void *recdata, uint32 len);
extern void lock_twophase_postabort(TransactionId xid, uint16 info,
      void *recdata, uint32 len);
extern void lock_twophase_standby_recover(TransactionId xid, uint16 info,
         void *recdata, uint32 len);

extern DeadLockState DeadLockCheck(PGPROC *proc);
extern PGPROC *GetBlockingAutoVacuumPgproc(void);
extern void DeadLockReport(void);
extern void RememberSimpleDeadLock(PGPROC *proc1,
        LOCKMODE lockmode,
        LOCK *lock,
        PGPROC *proc2);
extern void InitDeadLockChecking(void);







extern void VirtualXactLockTableInsert(VirtualTransactionId vxid);
extern void VirtualXactLockTableCleanup(void);
extern bool VirtualXactLock(VirtualTransactionId vxid, bool wait);
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/genbki.h" 1
# 49 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/genbki.h"
typedef int aclitem;
typedef int pg_node_tree;
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h" 2
# 36 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
typedef struct FormData_pg_attribute
{
 Oid attrelid;
 NameData attname;
# 48 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 Oid atttypid;
# 57 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int4 attstattarget;





 int2 attlen;
# 78 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int2 attnum;





 int4 attndims;
# 93 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int4 attcacheoff;







 int4 atttypmod;





 bool attbyval;
# 122 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 char attstorage;





 char attalign;


 bool attnotnull;


 bool atthasdef;


 bool attisdropped;


 bool attislocal;


 int4 attinhcount;


 Oid attcollation;
# 160 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
} FormData_pg_attribute;
# 176 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
typedef FormData_pg_attribute *Form_pg_attribute;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 2


typedef struct attrDefault
{
 AttrNumber adnum;
 char *adbin;
} AttrDefault;

typedef struct constrCheck
{
 char *ccname;
 char *ccbin;
 bool ccvalid;
 bool ccnoinherit;
} ConstrCheck;


typedef struct tupleConstr
{
 AttrDefault *defval;
 ConstrCheck *check;
 uint16 num_defval;
 uint16 num_check;
 bool has_not_null;
} TupleConstr;
# 71 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
typedef struct tupleDesc
{
 int natts;
 Form_pg_attribute *attrs;

 TupleConstr *constr;
 Oid tdtypeid;
 int32 tdtypmod;
 bool tdhasoid;
 int tdrefcount;
} *TupleDesc;


extern TupleDesc CreateTemplateTupleDesc(int natts, bool hasoid);

extern TupleDesc CreateTupleDesc(int natts, bool hasoid,
    Form_pg_attribute *attrs);

extern TupleDesc CreateTupleDescCopy(TupleDesc tupdesc);

extern TupleDesc CreateTupleDescCopyConstr(TupleDesc tupdesc);

extern void FreeTupleDesc(TupleDesc tupdesc);

extern void IncrTupleDescRefCount(TupleDesc tupdesc);
extern void DecrTupleDescRefCount(TupleDesc tupdesc);
# 110 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
extern bool equalTupleDescs(TupleDesc tupdesc1, TupleDesc tupdesc2);

extern void TupleDescInitEntry(TupleDesc desc,
       AttrNumber attributeNumber,
       const char *attributeName,
       Oid oidtypeid,
       int32 typmod,
       int attdim);

extern void TupleDescInitEntryCollation(TupleDesc desc,
       AttrNumber attributeNumber,
       Oid collationid);

extern TupleDesc BuildDescForRelation(List *schema);

extern TupleDesc BuildDescFromLists(List *names, List *types, List *typmods, List *collations);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/bitmapset.h" 1
# 29 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/bitmapset.h"
typedef uint32 bitmapword;
typedef int32 signedbitmapword;

typedef struct Bitmapset
{
 int nwords;
 bitmapword words[1];
} Bitmapset;



typedef enum
{
 BMS_EQUAL,
 BMS_SUBSET1,
 BMS_SUBSET2,
 BMS_DIFFERENT
} BMS_Comparison;


typedef enum
{
 BMS_EMPTY_SET,
 BMS_SINGLETON,
 BMS_MULTIPLE
} BMS_Membership;






extern Bitmapset *bms_copy(const Bitmapset *a);
extern bool bms_equal(const Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_make_singleton(int x);
extern void bms_free(Bitmapset *a);

extern Bitmapset *bms_union(const Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_intersect(const Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_difference(const Bitmapset *a, const Bitmapset *b);
extern bool bms_is_subset(const Bitmapset *a, const Bitmapset *b);
extern BMS_Comparison bms_subset_compare(const Bitmapset *a, const Bitmapset *b);
extern bool bms_is_member(int x, const Bitmapset *a);
extern bool bms_overlap(const Bitmapset *a, const Bitmapset *b);
extern bool bms_nonempty_difference(const Bitmapset *a, const Bitmapset *b);
extern int bms_singleton_member(const Bitmapset *a);
extern int bms_num_members(const Bitmapset *a);


extern BMS_Membership bms_membership(const Bitmapset *a);
extern bool bms_is_empty(const Bitmapset *a);



extern Bitmapset *bms_add_member(Bitmapset *a, int x);
extern Bitmapset *bms_del_member(Bitmapset *a, int x);
extern Bitmapset *bms_add_members(Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_int_members(Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_del_members(Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_join(Bitmapset *a, Bitmapset *b);


extern int bms_first_member(Bitmapset *a);


extern uint32 bms_hash_value(const Bitmapset *a);
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h" 2


typedef struct RelationData *Relation;







typedef Relation *RelationPtr;




extern Relation RelationIdGetRelation(Oid relationId);
extern void RelationClose(Relation relation);




extern List *RelationGetIndexList(Relation relation);
extern Oid RelationGetOidIndex(Relation relation);
extern List *RelationGetIndexExpressions(Relation relation);
extern List *RelationGetIndexPredicate(Relation relation);
extern Bitmapset *RelationGetIndexAttrBitmap(Relation relation);
extern void RelationGetExclusionInfo(Relation indexRelation,
       Oid **operators,
       Oid **procs,
       uint16 **strategies);

extern void RelationSetIndexList(Relation relation,
      List *indexIds, Oid oidIndex);

extern void RelationInitIndexAccessInfo(Relation relation);




extern void RelationCacheInitialize(void);
extern void RelationCacheInitializePhase2(void);
extern void RelationCacheInitializePhase3(void);




extern Relation RelationBuildLocalRelation(const char *relname,
         Oid relnamespace,
         TupleDesc tupDesc,
         Oid relid,
         Oid relfilenode,
         Oid reltablespace,
         bool shared_relation,
         bool mapped_relation,
         char relpersistence);




extern void RelationSetNewRelfilenode(Relation relation,
        TransactionId freezeXid);




extern void RelationForgetRelation(Oid rid);

extern void RelationCacheInvalidateEntry(Oid relationId);

extern void RelationCacheInvalidate(void);

extern void RelationCloseSmgrByOid(Oid relationId);

extern void AtEOXact_RelationCache(bool isCommit);
extern void AtEOSubXact_RelationCache(bool isCommit, SubTransactionId mySubid,
        SubTransactionId parentSubid);




extern bool RelationIdIsInInitFile(Oid relationId);
extern void RelationCacheInitFilePreInvalidate(void);
extern void RelationCacheInitFilePostInvalidate(void);
extern void RelationCacheInitFileRemove(void);


extern bool criticalRelcachesBuilt;


extern bool criticalSharedRelcachesBuilt;
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupmacs.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/item.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/item.h"
typedef Pointer Item;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h"
typedef struct ItemIdData
{
 unsigned lp_off:15,
    lp_flags:2,
    lp_len:15;
} ItemIdData;

typedef ItemIdData *ItemId;
# 46 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h"
typedef uint16 ItemOffset;
typedef uint16 ItemLength;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h" 2






typedef uint16 OffsetNumber;
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 2
# 73 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef Pointer Page;
# 82 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef uint16 LocationIndex;
# 122 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef struct PageHeaderData
{

 XLogRecPtr pd_lsn;

 uint16 pd_tli;

 uint16 pd_flags;
 LocationIndex pd_lower;
 LocationIndex pd_upper;
 LocationIndex pd_special;
 uint16 pd_pagesize_version;
 TransactionId pd_prune_xid;
 ItemIdData pd_linp[1];
} PageHeaderData;

typedef PageHeaderData *PageHeader;
# 370 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
extern void PageInit(Page page, Size pageSize, Size specialSize);
extern bool PageHeaderIsValid(PageHeader page);
extern OffsetNumber PageAddItem(Page page, Item item, Size size,
   OffsetNumber offsetNumber, bool overwrite, bool is_heap);
extern Page PageGetTempPage(Page page);
extern Page PageGetTempPageCopy(Page page);
extern Page PageGetTempPageCopySpecial(Page page);
extern void PageRestoreTempPage(Page tempPage, Page oldPage);
extern void PageRepairFragmentation(Page page);
extern Size PageGetFreeSpace(Page page);
extern Size PageGetExactFreeSpace(Page page);
extern Size PageGetHeapFreeSpace(Page page);
extern void PageIndexTupleDelete(Page page, OffsetNumber offset);
extern void PageIndexMultiDelete(Page page, OffsetNumber *itemnos, int nitems);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h" 1
# 31 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h"
typedef uint32 BlockNumber;
# 53 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h"
typedef struct BlockIdData
{
 uint16 bi_hi;
 uint16 bi_lo;
} BlockIdData;

typedef BlockIdData *BlockId;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h" 2
# 37 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
typedef struct ItemPointerData
{
 BlockIdData ip_blkid;
 OffsetNumber ip_posid;
}




ItemPointerData;




typedef ItemPointerData *ItemPointer;
# 143 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
extern bool ItemPointerEquals(ItemPointer pointer1, ItemPointer pointer2);
extern int32 ItemPointerCompare(ItemPointer arg1, ItemPointer arg2);
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h" 1
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
typedef enum ForkNumber
{
 InvalidForkNumber = -1,
 MAIN_FORKNUM = 0,
 FSM_FORKNUM,
 VISIBILITYMAP_FORKNUM,
 INIT_FORKNUM





} ForkNumber;
# 77 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
typedef struct RelFileNode
{
 Oid spcNode;
 Oid dbNode;
 Oid relNode;
} RelFileNode;
# 92 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
typedef struct RelFileNodeBackend
{
 RelFileNode node;
 BackendId backend;
} RelFileNodeBackend;
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 107 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct HeapTupleFields
{
 TransactionId t_xmin;
 TransactionId t_xmax;

 union
 {
  CommandId t_cid;
  TransactionId t_xvac;
 } t_field3;
} HeapTupleFields;

typedef struct DatumTupleFields
{
 int32 datum_len_;

 int32 datum_typmod;

 Oid datum_typeid;





} DatumTupleFields;

typedef struct HeapTupleHeaderData
{
 union
 {
  HeapTupleFields t_heap;
  DatumTupleFields t_datum;
 } t_choice;

 ItemPointerData t_ctid;



 uint16 t_infomask2;

 uint16 t_infomask;

 uint8 t_hoff;



 bits8 t_bits[1];


} HeapTupleHeaderData;

typedef HeapTupleHeaderData *HeapTupleHeader;
# 461 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct MinimalTupleData
{
 uint32 t_len;

 char mt_padding[((__builtin_offsetof (HeapTupleHeaderData, t_infomask2) - sizeof(uint32)) % 8)];



 uint16 t_infomask2;

 uint16 t_infomask;

 uint8 t_hoff;



 bits8 t_bits[1];


} MinimalTupleData;

typedef MinimalTupleData *MinimalTuple;
# 517 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct HeapTupleData
{
 uint32 t_len;
 ItemPointerData t_self;
 Oid t_tableOid;
 HeapTupleHeader t_data;
} HeapTupleData;

typedef HeapTupleData *HeapTuple;
# 621 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heaptid
{
 RelFileNode node;
 ItemPointerData tid;
} xl_heaptid;




typedef struct xl_heap_delete
{
 xl_heaptid target;
 bool all_visible_cleared;
} xl_heap_delete;
# 646 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_header
{
 uint16 t_infomask2;
 uint16 t_infomask;
 uint8 t_hoff;
} xl_heap_header;




typedef struct xl_heap_insert
{
 xl_heaptid target;
 bool all_visible_cleared;

} xl_heap_insert;
# 671 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_multi_insert
{
 RelFileNode node;
 BlockNumber blkno;
 bool all_visible_cleared;
 uint16 ntuples;
 OffsetNumber offsets[1];


} xl_heap_multi_insert;



typedef struct xl_multi_insert_tuple
{
 uint16 datalen;
 uint16 t_infomask2;
 uint16 t_infomask;
 uint8 t_hoff;

} xl_multi_insert_tuple;




typedef struct xl_heap_update
{
 xl_heaptid target;
 ItemPointerData newtid;
 bool all_visible_cleared;
 bool new_all_visible_cleared;

} xl_heap_update;
# 718 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_clean
{
 RelFileNode node;
 BlockNumber block;
 TransactionId latestRemovedXid;
 uint16 nredirected;
 uint16 ndead;

} xl_heap_clean;
# 735 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_cleanup_info
{
 RelFileNode node;
 TransactionId latestRemovedXid;
} xl_heap_cleanup_info;





typedef struct xl_heap_newpage
{
 RelFileNode node;
 ForkNumber forknum;
 BlockNumber blkno;

} xl_heap_newpage;




typedef struct xl_heap_lock
{
 xl_heaptid target;
 TransactionId locking_xid;
 bool xid_is_mxact;
 bool shared_lock;
} xl_heap_lock;




typedef struct xl_heap_inplace
{
 xl_heaptid target;

} xl_heap_inplace;




typedef struct xl_heap_freeze
{
 RelFileNode node;
 BlockNumber block;
 TransactionId cutoff_xid;

} xl_heap_freeze;




typedef struct xl_heap_visible
{
 RelFileNode node;
 BlockNumber block;
 TransactionId cutoff_xid;
} xl_heap_visible;



extern void HeapTupleHeaderAdvanceLatestRemovedXid(HeapTupleHeader tuple,
            TransactionId *latestRemovedXid);


extern CommandId HeapTupleHeaderGetCmin(HeapTupleHeader tup);
extern CommandId HeapTupleHeaderGetCmax(HeapTupleHeader tup);
extern void HeapTupleHeaderAdjustCmax(HeapTupleHeader tup,
        CommandId *cmax,
        bool *iscombo);
# 890 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
extern Size heap_compute_data_size(TupleDesc tupleDesc,
        Datum *values, bool *isnull);
extern void heap_fill_tuple(TupleDesc tupleDesc,
    Datum *values, bool *isnull,
    char *data, Size data_size,
    uint16 *infomask, bits8 *bit);
extern bool heap_attisnull(HeapTuple tup, int attnum);
extern Datum nocachegetattr(HeapTuple tup, int attnum,
      TupleDesc att);
extern Datum heap_getsysattr(HeapTuple tup, int attnum, TupleDesc tupleDesc,
    bool *isnull);
extern HeapTuple heap_copytuple(HeapTuple tuple);
extern void heap_copytuple_with_tuple(HeapTuple src, HeapTuple dest);
extern HeapTuple heap_form_tuple(TupleDesc tupleDescriptor,
    Datum *values, bool *isnull);
extern HeapTuple heap_modify_tuple(HeapTuple tuple,
      TupleDesc tupleDesc,
      Datum *replValues,
      bool *replIsnull,
      bool *doReplace);
extern void heap_deform_tuple(HeapTuple tuple, TupleDesc tupleDesc,
      Datum *values, bool *isnull);


extern HeapTuple heap_formtuple(TupleDesc tupleDescriptor,
      Datum *values, char *nulls);
extern HeapTuple heap_modifytuple(HeapTuple tuple,
     TupleDesc tupleDesc,
     Datum *replValues,
     char *replNulls,
     char *replActions);
extern void heap_deformtuple(HeapTuple tuple, TupleDesc tupleDesc,
     Datum *values, char *nulls);
extern void heap_freetuple(HeapTuple htup);
extern MinimalTuple heap_form_minimal_tuple(TupleDesc tupleDescriptor,
      Datum *values, bool *isnull);
extern void heap_free_minimal_tuple(MinimalTuple mtup);
extern MinimalTuple heap_copy_minimal_tuple(MinimalTuple mtup);
extern HeapTuple heap_tuple_from_minimal_tuple(MinimalTuple mtup);
extern MinimalTuple minimal_tuple_from_heap_tuple(HeapTuple htup);
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h" 2


typedef struct SnapshotData *Snapshot;
# 30 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h"
typedef bool (*SnapshotSatisfiesFunc) (HeapTupleHeader tuple,
             Snapshot snapshot, Buffer buffer);

typedef struct SnapshotData
{
 SnapshotSatisfiesFunc satisfies;
# 47 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h"
 TransactionId xmin;
 TransactionId xmax;
 TransactionId *xip;
 uint32 xcnt;

 int32 subxcnt;
 TransactionId *subxip;
 bool suboverflowed;
 bool takenDuringRecovery;
 bool copied;





 CommandId curcid;
 uint32 active_count;
 uint32 regd_count;
} SnapshotData;





typedef enum
{
 HeapTupleMayBeUpdated,
 HeapTupleInvisible,
 HeapTupleSelfUpdated,
 HeapTupleUpdated,
 HeapTupleBeingUpdated
} HTSU_Result;
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h" 2






typedef struct BulkInsertStateData *BulkInsertState;

typedef enum
{
 LockTupleShared,
 LockTupleExclusive
} LockTupleMode;
# 48 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h"
extern Relation relation_open(Oid relationId, LOCKMODE lockmode);
extern Relation try_relation_open(Oid relationId, LOCKMODE lockmode);
extern Relation relation_openrv(const RangeVar *relation, LOCKMODE lockmode);
extern Relation relation_openrv_extended(const RangeVar *relation,
       LOCKMODE lockmode, bool missing_ok);
extern void relation_close(Relation relation, LOCKMODE lockmode);

extern Relation heap_open(Oid relationId, LOCKMODE lockmode);
extern Relation heap_openrv(const RangeVar *relation, LOCKMODE lockmode);
extern Relation heap_openrv_extended(const RangeVar *relation,
      LOCKMODE lockmode, bool missing_ok);




typedef struct HeapScanDescData *HeapScanDesc;







extern HeapScanDesc heap_beginscan(Relation relation, Snapshot snapshot,
      int nkeys, ScanKey key);
extern HeapScanDesc heap_beginscan_strat(Relation relation, Snapshot snapshot,
      int nkeys, ScanKey key,
      bool allow_strat, bool allow_sync);
extern HeapScanDesc heap_beginscan_bm(Relation relation, Snapshot snapshot,
      int nkeys, ScanKey key);
extern void heap_rescan(HeapScanDesc scan, ScanKey key);
extern void heap_endscan(HeapScanDesc scan);
extern HeapTuple heap_getnext(HeapScanDesc scan, ScanDirection direction);

extern bool heap_fetch(Relation relation, Snapshot snapshot,
     HeapTuple tuple, Buffer *userbuf, bool keep_buf,
     Relation stats_relation);
extern bool heap_hot_search_buffer(ItemPointer tid, Relation relation,
        Buffer buffer, Snapshot snapshot, HeapTuple heapTuple,
        bool *all_dead, bool first_call);
extern bool heap_hot_search(ItemPointer tid, Relation relation,
    Snapshot snapshot, bool *all_dead);

extern void heap_get_latest_tid(Relation relation, Snapshot snapshot,
     ItemPointer tid);
extern void setLastTid(const ItemPointer tid);

extern BulkInsertState GetBulkInsertState(void);
extern void FreeBulkInsertState(BulkInsertState);

extern Oid heap_insert(Relation relation, HeapTuple tup, CommandId cid,
   int options, BulkInsertState bistate);
extern void heap_multi_insert(Relation relation, HeapTuple *tuples, int ntuples,
      CommandId cid, int options, BulkInsertState bistate);
extern HTSU_Result heap_delete(Relation relation, ItemPointer tid,
   ItemPointer ctid, TransactionId *update_xmax,
   CommandId cid, Snapshot crosscheck, bool wait);
extern HTSU_Result heap_update(Relation relation, ItemPointer otid,
   HeapTuple newtup,
   ItemPointer ctid, TransactionId *update_xmax,
   CommandId cid, Snapshot crosscheck, bool wait);
extern HTSU_Result heap_lock_tuple(Relation relation, HeapTuple tuple,
    Buffer *buffer, ItemPointer ctid,
    TransactionId *update_xmax, CommandId cid,
    LockTupleMode mode, bool nowait);
extern void heap_inplace_update(Relation relation, HeapTuple tuple);
extern bool heap_freeze_tuple(HeapTupleHeader tuple, TransactionId cutoff_xid);
extern bool heap_tuple_needs_freeze(HeapTupleHeader tuple, TransactionId cutoff_xid,
      Buffer buf);

extern Oid simple_heap_insert(Relation relation, HeapTuple tup);
extern void simple_heap_delete(Relation relation, ItemPointer tid);
extern void simple_heap_update(Relation relation, ItemPointer otid,
       HeapTuple tup);

extern void heap_markpos(HeapScanDesc scan);
extern void heap_restrpos(HeapScanDesc scan);

extern void heap_sync(Relation relation);

extern void heap_redo(XLogRecPtr lsn, XLogRecord *rptr);
extern void heap_desc(StringInfo buf, uint8 xl_info, char *rec);
extern void heap2_redo(XLogRecPtr lsn, XLogRecord *rptr);
extern void heap2_desc(StringInfo buf, uint8 xl_info, char *rec);

extern XLogRecPtr log_heap_cleanup_info(RelFileNode rnode,
       TransactionId latestRemovedXid);
extern XLogRecPtr log_heap_clean(Relation reln, Buffer buffer,
      OffsetNumber *redirected, int nredirected,
      OffsetNumber *nowdead, int ndead,
      OffsetNumber *nowunused, int nunused,
      TransactionId latestRemovedXid);
extern XLogRecPtr log_heap_freeze(Relation reln, Buffer buffer,
    TransactionId cutoff_xid,
    OffsetNumber *offsets, int offcnt);
extern XLogRecPtr log_heap_visible(RelFileNode rnode, BlockNumber block,
     Buffer vm_buffer, TransactionId cutoff_xid);
extern XLogRecPtr log_newpage(RelFileNode *rnode, ForkNumber forkNum,
   BlockNumber blk, Page page);


extern void heap_page_prune_opt(Relation relation, Buffer buffer,
     TransactionId OldestXmin);
extern int heap_page_prune(Relation relation, Buffer buffer,
    TransactionId OldestXmin,
    bool report_stats, TransactionId *latestRemovedXid);
extern void heap_page_prune_execute(Buffer buffer,
      OffsetNumber *redirected, int nredirected,
      OffsetNumber *nowdead, int ndead,
      OffsetNumber *nowunused, int nunused);
extern void heap_get_root_tuples(Page page, OffsetNumber *root_offsets);


extern void ss_report_location(Relation rel, BlockNumber location);
extern BlockNumber ss_get_location(Relation rel, BlockNumber relnblocks);
extern void SyncScanShmemInit(void);
extern Size SyncScanShmemSize(void);
# 55 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/reloptions.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/reloptions.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/reloptions.h" 2



typedef enum relopt_type
{
 RELOPT_TYPE_BOOL,
 RELOPT_TYPE_INT,
 RELOPT_TYPE_REAL,
 RELOPT_TYPE_STRING
} relopt_type;


typedef enum relopt_kind
{
 RELOPT_KIND_HEAP = (1 << 0),
 RELOPT_KIND_TOAST = (1 << 1),
 RELOPT_KIND_BTREE = (1 << 2),
 RELOPT_KIND_HASH = (1 << 3),
 RELOPT_KIND_GIN = (1 << 4),
 RELOPT_KIND_GIST = (1 << 5),
 RELOPT_KIND_ATTRIBUTE = (1 << 6),
 RELOPT_KIND_TABLESPACE = (1 << 7),
 RELOPT_KIND_SPGIST = (1 << 8),
 RELOPT_KIND_VIEW = (1 << 9),

 RELOPT_KIND_LAST_DEFAULT = RELOPT_KIND_VIEW,

 RELOPT_KIND_MAX = (1 << 30)
} relopt_kind;





typedef struct relopt_gen
{
 const char *name;

 const char *desc;
 bits32 kinds;
 int namelen;
 relopt_type type;
} relopt_gen;


typedef struct relopt_value
{
 relopt_gen *gen;
 bool isset;
 union
 {
  bool bool_val;
  int int_val;
  double real_val;
  char *string_val;
 } values;
} relopt_value;


typedef struct relopt_bool
{
 relopt_gen gen;
 bool default_val;
} relopt_bool;

typedef struct relopt_int
{
 relopt_gen gen;
 int default_val;
 int min;
 int max;
} relopt_int;

typedef struct relopt_real
{
 relopt_gen gen;
 double default_val;
 double min;
 double max;
} relopt_real;


typedef void (*validate_string_relopt) (char *value);

typedef struct relopt_string
{
 relopt_gen gen;
 int default_len;
 bool default_isnull;
 validate_string_relopt validate_cb;
 char *default_val;
} relopt_string;


typedef struct
{
 const char *optname;
 relopt_type opttype;
 int offset;
} relopt_parse_elt;
# 242 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/reloptions.h"
extern relopt_kind add_reloption_kind(void);
extern void add_bool_reloption(bits32 kinds, char *name, char *desc,
       bool default_val);
extern void add_int_reloption(bits32 kinds, char *name, char *desc,
      int default_val, int min_val, int max_val);
extern void add_real_reloption(bits32 kinds, char *name, char *desc,
       double default_val, double min_val, double max_val);
extern void add_string_reloption(bits32 kinds, char *name, char *desc,
      char *default_val, validate_string_relopt validator);

extern Datum transformRelOptions(Datum oldOptions, List *defList,
     char *namspace, char *validnsps[],
     bool ignoreOids, bool isReset);
extern List *untransformRelOptions(Datum options);
extern bytea *extractRelOptions(HeapTuple tuple, TupleDesc tupdesc,
      Oid amoptions);
extern relopt_value *parseRelOptions(Datum options, bool validate,
    relopt_kind kind, int *numrelopts);
extern void *allocateReloptStruct(Size base, relopt_value *options,
      int numoptions);
extern void fillRelOptions(void *rdopts, Size basesize,
      relopt_value *options, int numoptions,
      bool validate,
      const relopt_parse_elt *elems, int nelems);

extern bytea *default_reloptions(Datum reloptions, bool validate,
       relopt_kind kind);
extern bytea *heap_reloptions(char relkind, Datum reloptions, bool validate);
extern bytea *index_reloptions(RegProcedure amoptions, Datum reloptions,
     bool validate);
extern bytea *attribute_reloptions(Datum reloptions, bool validate);
extern bytea *tablespace_reloptions(Datum reloptions, bool validate);
# 56 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/sysattr.h" 1
# 57 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h" 1
# 30 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
extern int DefaultXactIsoLevel;
extern int XactIsoLevel;
# 44 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
extern bool DefaultXactReadOnly;
extern bool XactReadOnly;





extern bool DefaultXactDeferrable;
extern bool XactDeferrable;

typedef enum
{
 SYNCHRONOUS_COMMIT_OFF,
 SYNCHRONOUS_COMMIT_LOCAL_FLUSH,
 SYNCHRONOUS_COMMIT_REMOTE_WRITE,

 SYNCHRONOUS_COMMIT_REMOTE_FLUSH
} SyncCommitLevel;





extern int synchronous_commit;


extern bool MyXactAccessedTempRel;




typedef enum
{
 XACT_EVENT_COMMIT,
 XACT_EVENT_ABORT,
 XACT_EVENT_PREPARE
} XactEvent;

typedef void (*XactCallback) (XactEvent event, void *arg);

typedef enum
{
 SUBXACT_EVENT_START_SUB,
 SUBXACT_EVENT_COMMIT_SUB,
 SUBXACT_EVENT_ABORT_SUB
} SubXactEvent;

typedef void (*SubXactCallback) (SubXactEvent event, SubTransactionId mySubid,
         SubTransactionId parentSubid, void *arg);
# 112 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
typedef struct xl_xact_assignment
{
 TransactionId xtop;
 int nsubxacts;
 TransactionId xsub[1];
} xl_xact_assignment;



typedef struct xl_xact_commit_compact
{
 TimestampTz xact_time;
 int nsubxacts;

 TransactionId subxacts[1];
} xl_xact_commit_compact;



typedef struct xl_xact_commit
{
 TimestampTz xact_time;
 uint32 xinfo;
 int nrels;
 int nsubxacts;
 int nmsgs;
 Oid dbId;
 Oid tsId;

 RelFileNode xnodes[1];


} xl_xact_commit;
# 163 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
typedef struct xl_xact_abort
{
 TimestampTz xact_time;
 int nrels;
 int nsubxacts;

 RelFileNode xnodes[1];

} xl_xact_abort;
# 184 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
typedef struct xl_xact_commit_prepared
{
 TransactionId xid;
 xl_xact_commit crec;

} xl_xact_commit_prepared;



typedef struct xl_xact_abort_prepared
{
 TransactionId xid;
 xl_xact_abort arec;

} xl_xact_abort_prepared;
# 207 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
extern bool IsTransactionState(void);
extern bool IsAbortedTransactionBlockState(void);
extern TransactionId GetTopTransactionId(void);
extern TransactionId GetTopTransactionIdIfAny(void);
extern TransactionId GetCurrentTransactionId(void);
extern TransactionId GetCurrentTransactionIdIfAny(void);
extern TransactionId GetStableLatestTransactionId(void);
extern SubTransactionId GetCurrentSubTransactionId(void);
extern bool SubTransactionIsActive(SubTransactionId subxid);
extern CommandId GetCurrentCommandId(bool used);
extern TimestampTz GetCurrentTransactionStartTimestamp(void);
extern TimestampTz GetCurrentStatementStartTimestamp(void);
extern TimestampTz GetCurrentTransactionStopTimestamp(void);
extern void SetCurrentStatementStartTimestamp(void);
extern int GetCurrentTransactionNestLevel(void);
extern bool TransactionIdIsCurrentTransactionId(TransactionId xid);
extern void CommandCounterIncrement(void);
extern void ForceSyncCommit(void);
extern void StartTransactionCommand(void);
extern void CommitTransactionCommand(void);
extern void AbortCurrentTransaction(void);
extern void BeginTransactionBlock(void);
extern bool EndTransactionBlock(void);
extern bool PrepareTransactionBlock(char *gid);
extern void UserAbortTransactionBlock(void);
extern void ReleaseSavepoint(List *options);
extern void DefineSavepoint(char *name);
extern void RollbackToSavepoint(List *options);
extern void BeginInternalSubTransaction(char *name);
extern void ReleaseCurrentSubTransaction(void);
extern void RollbackAndReleaseCurrentSubTransaction(void);
extern bool IsSubTransaction(void);
extern bool IsTransactionBlock(void);
extern bool IsTransactionOrTransactionBlock(void);
extern char TransactionBlockStatusCode(void);
extern void AbortOutOfAnyTransaction(void);
extern void PreventTransactionChain(bool isTopLevel, const char *stmtType);
extern void RequireTransactionChain(bool isTopLevel, const char *stmtType);
extern bool IsInTransactionChain(bool isTopLevel);
extern void RegisterXactCallback(XactCallback callback, void *arg);
extern void UnregisterXactCallback(XactCallback callback, void *arg);
extern void RegisterSubXactCallback(SubXactCallback callback, void *arg);
extern void UnregisterSubXactCallback(SubXactCallback callback, void *arg);

extern int xactGetCommittedChildren(TransactionId **ptr);

extern void xact_redo(XLogRecPtr lsn, XLogRecord *record);
extern void xact_desc(StringInfo buf, uint8 xl_info, char *rec);
# 58 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/catalog.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/catalog.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/catversion.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/catalog.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_class.h" 1
# 32 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_class.h"
typedef struct FormData_pg_class
{
 NameData relname;
 Oid relnamespace;
 Oid reltype;

 Oid reloftype;

 Oid relowner;
 Oid relam;
 Oid relfilenode;


 Oid reltablespace;
 int4 relpages;
 float4 reltuples;
 int4 relallvisible;

 Oid reltoastrelid;
 Oid reltoastidxid;
 bool relhasindex;
 bool relisshared;
 char relpersistence;
 char relkind;
 int2 relnatts;






 int2 relchecks;
 bool relhasoids;
 bool relhaspkey;
 bool relhasrules;
 bool relhastriggers;
 bool relhassubclass;
 TransactionId relfrozenxid;






} FormData_pg_class;
# 87 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_class.h"
typedef FormData_pg_class *Form_pg_class;
# 133 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_class.h"
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/catalog.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/catalog.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h" 1
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/catalog.h" 2





extern const char *forkNames[];
extern ForkNumber forkname_to_number(char *forkName);
extern int forkname_chars(const char *str, ForkNumber *);

extern char *relpathbackend(RelFileNode rnode, BackendId backend,
      ForkNumber forknum);
extern char *GetDatabasePath(Oid dbNode, Oid spcNode);
# 46 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/catalog.h"
extern bool IsSystemRelation(Relation relation);
extern bool IsToastRelation(Relation relation);

extern bool IsSystemClass(Form_pg_class reltuple);
extern bool IsToastClass(Form_pg_class reltuple);

extern bool IsSystemNamespace(Oid namespaceId);
extern bool IsToastNamespace(Oid namespaceId);

extern bool IsReservedName(const char *name);

extern bool IsSharedRelation(Oid relationId);

extern Oid GetNewOid(Relation relation);
extern Oid GetNewOidWithIndex(Relation relation, Oid indexId,
       AttrNumber oidcolumn);
extern Oid GetNewRelFileNode(Oid reltablespace, Relation pg_class,
      char relpersistence);
# 59 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/dependency.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/dependency.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/objectaddress.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/objectaddress.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/bitmapset.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 1
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/value.h" 1
# 42 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/value.h"
typedef struct Value
{
 NodeTag type;
 union ValUnion
 {
  long ival;
  char *str;
 } val;
} Value;





extern Value *makeInteger(long i);
extern Value *makeFloat(char *numericStr);
extern Value *makeString(char *str);
extern Value *makeBitString(char *str);
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 2


typedef enum QuerySource
{
 QSRC_ORIGINAL,
 QSRC_PARSER,
 QSRC_INSTEAD_RULE,
 QSRC_QUAL_INSTEAD_RULE,
 QSRC_NON_INSTEAD_RULE
} QuerySource;


typedef enum SortByDir
{
 SORTBY_DEFAULT,
 SORTBY_ASC,
 SORTBY_DESC,
 SORTBY_USING
} SortByDir;

typedef enum SortByNulls
{
 SORTBY_NULLS_DEFAULT,
 SORTBY_NULLS_FIRST,
 SORTBY_NULLS_LAST
} SortByNulls;
# 60 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef uint32 AclMode;
# 98 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct Query
{
 NodeTag type;

 CmdType commandType;

 QuerySource querySource;

 uint32 queryId;

 bool canSetTag;

 Node *utilityStmt;


 int resultRelation;


 bool hasAggs;
 bool hasWindowFuncs;
 bool hasSubLinks;
 bool hasDistinctOn;
 bool hasRecursive;
 bool hasModifyingCTE;
 bool hasForUpdate;

 List *cteList;

 List *rtable;
 FromExpr *jointree;

 List *targetList;

 List *returningList;

 List *groupClause;

 Node *havingQual;

 List *windowClause;

 List *distinctClause;

 List *sortClause;

 Node *limitOffset;
 Node *limitCount;

 List *rowMarks;

 Node *setOperations;


 List *constraintDeps;

} Query;
# 177 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct TypeName
{
 NodeTag type;
 List *names;
 Oid typeOid;
 bool setof;
 bool pct_type;
 List *typmods;
 int32 typemod;
 List *arrayBounds;
 int location;
} TypeName;
# 203 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ColumnRef
{
 NodeTag type;
 List *fields;
 int location;
} ColumnRef;




typedef struct ParamRef
{
 NodeTag type;
 int number;
 int location;
} ParamRef;




typedef enum A_Expr_Kind
{
 AEXPR_OP,
 AEXPR_AND,
 AEXPR_OR,
 AEXPR_NOT,
 AEXPR_OP_ANY,
 AEXPR_OP_ALL,
 AEXPR_DISTINCT,
 AEXPR_NULLIF,
 AEXPR_OF,
 AEXPR_IN
} A_Expr_Kind;

typedef struct A_Expr
{
 NodeTag type;
 A_Expr_Kind kind;
 List *name;
 Node *lexpr;
 Node *rexpr;
 int location;
} A_Expr;




typedef struct A_Const
{
 NodeTag type;
 Value val;
 int location;
} A_Const;




typedef struct TypeCast
{
 NodeTag type;
 Node *arg;
 TypeName *typeName;
 int location;
} TypeCast;




typedef struct CollateClause
{
 NodeTag type;
 Node *arg;
 List *collname;
 int location;
} CollateClause;
# 289 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct FuncCall
{
 NodeTag type;
 List *funcname;
 List *args;
 List *agg_order;
 bool agg_star;
 bool agg_distinct;
 bool func_variadic;
 struct WindowDef *over;
 int location;
} FuncCall;







typedef struct A_Star
{
 NodeTag type;
} A_Star;




typedef struct A_Indices
{
 NodeTag type;
 Node *lidx;
 Node *uidx;
} A_Indices;
# 338 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct A_Indirection
{
 NodeTag type;
 Node *arg;
 List *indirection;
} A_Indirection;




typedef struct A_ArrayExpr
{
 NodeTag type;
 List *elements;
 int location;
} A_ArrayExpr;
# 373 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ResTarget
{
 NodeTag type;
 char *name;
 List *indirection;
 Node *val;
 int location;
} ResTarget;




typedef struct SortBy
{
 NodeTag type;
 Node *node;
 SortByDir sortby_dir;
 SortByNulls sortby_nulls;
 List *useOp;
 int location;
} SortBy;
# 403 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct WindowDef
{
 NodeTag type;
 char *name;
 char *refname;
 List *partitionClause;
 List *orderClause;
 int frameOptions;
 Node *startOffset;
 Node *endOffset;
 int location;
} WindowDef;
# 451 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct RangeSubselect
{
 NodeTag type;
 Node *subquery;
 Alias *alias;
} RangeSubselect;




typedef struct RangeFunction
{
 NodeTag type;
 Node *funccallnode;
 Alias *alias;
 List *coldeflist;

} RangeFunction;
# 488 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ColumnDef
{
 NodeTag type;
 char *colname;
 TypeName *typeName;
 int inhcount;
 bool is_local;
 bool is_not_null;
 bool is_from_type;
 char storage;
 Node *raw_default;
 Node *cooked_default;
 CollateClause *collClause;
 Oid collOid;
 List *constraints;
 List *fdwoptions;
} ColumnDef;




typedef struct TableLikeClause
{
 NodeTag type;
 RangeVar *relation;
 bits32 options;
} TableLikeClause;

typedef enum TableLikeOption
{
 CREATE_TABLE_LIKE_DEFAULTS = 1 << 0,
 CREATE_TABLE_LIKE_CONSTRAINTS = 1 << 1,
 CREATE_TABLE_LIKE_INDEXES = 1 << 2,
 CREATE_TABLE_LIKE_STORAGE = 1 << 3,
 CREATE_TABLE_LIKE_COMMENTS = 1 << 4,
 CREATE_TABLE_LIKE_ALL = 0x7FFFFFFF
} TableLikeOption;
# 533 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct IndexElem
{
 NodeTag type;
 char *name;
 Node *expr;
 char *indexcolname;
 List *collation;
 List *opclass;
 SortByDir ordering;
 SortByNulls nulls_ordering;
} IndexElem;
# 555 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum DefElemAction
{
 DEFELEM_UNSPEC,
 DEFELEM_SET,
 DEFELEM_ADD,
 DEFELEM_DROP
} DefElemAction;

typedef struct DefElem
{
 NodeTag type;
 char *defnamespace;
 char *defname;
 Node *arg;
 DefElemAction defaction;
} DefElem;
# 580 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct LockingClause
{
 NodeTag type;
 List *lockedRels;
 bool forUpdate;
 bool noWait;
} LockingClause;




typedef struct XmlSerialize
{
 NodeTag type;
 XmlOptionType xmloption;
 Node *expr;
 TypeName *typeName;
 int location;
} XmlSerialize;
# 677 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum RTEKind
{
 RTE_RELATION,
 RTE_SUBQUERY,
 RTE_JOIN,
 RTE_FUNCTION,
 RTE_VALUES,
 RTE_CTE
} RTEKind;

typedef struct RangeTblEntry
{
 NodeTag type;

 RTEKind rtekind;
# 702 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 Oid relid;
 char relkind;




 Query *subquery;
 bool security_barrier;
# 722 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 JoinType jointype;
 List *joinaliasvars;
# 733 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 Node *funcexpr;
 List *funccoltypes;
 List *funccoltypmods;
 List *funccolcollations;




 List *values_lists;
 List *values_collations;




 char *ctename;
 Index ctelevelsup;
 bool self_reference;
 List *ctecoltypes;
 List *ctecoltypmods;
 List *ctecolcollations;




 Alias *alias;
 Alias *eref;
 bool inh;
 bool inFromCl;
 AclMode requiredPerms;
 Oid checkAsUser;
 Bitmapset *selectedCols;
 Bitmapset *modifiedCols;
} RangeTblEntry;
# 825 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct SortGroupClause
{
 NodeTag type;
 Index tleSortGroupRef;
 Oid eqop;
 Oid sortop;
 bool nulls_first;
 bool hashable;
} SortGroupClause;
# 849 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct WindowClause
{
 NodeTag type;
 char *name;
 char *refname;
 List *partitionClause;
 List *orderClause;
 int frameOptions;
 Node *startOffset;
 Node *endOffset;
 Index winref;
 bool copiedOrder;
} WindowClause;
# 875 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct RowMarkClause
{
 NodeTag type;
 Index rti;
 bool forUpdate;
 bool noWait;
 bool pushedDown;
} RowMarkClause;
# 891 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct WithClause
{
 NodeTag type;
 List *ctes;
 bool recursive;
 int location;
} WithClause;







typedef struct CommonTableExpr
{
 NodeTag type;
 char *ctename;
 List *aliascolnames;

 Node *ctequery;
 int location;

 bool cterecursive;
 int cterefcount;

 List *ctecolnames;
 List *ctecoltypes;
 List *ctecoltypmods;
 List *ctecolcollations;
} CommonTableExpr;
# 943 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct InsertStmt
{
 NodeTag type;
 RangeVar *relation;
 List *cols;
 Node *selectStmt;
 List *returningList;
 WithClause *withClause;
} InsertStmt;





typedef struct DeleteStmt
{
 NodeTag type;
 RangeVar *relation;
 List *usingClause;
 Node *whereClause;
 List *returningList;
 WithClause *withClause;
} DeleteStmt;





typedef struct UpdateStmt
{
 NodeTag type;
 RangeVar *relation;
 List *targetList;
 Node *whereClause;
 List *fromClause;
 List *returningList;
 WithClause *withClause;
} UpdateStmt;
# 995 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum SetOperation
{
 SETOP_NONE = 0,
 SETOP_UNION,
 SETOP_INTERSECT,
 SETOP_EXCEPT
} SetOperation;

typedef struct SelectStmt
{
 NodeTag type;




 List *distinctClause;

 IntoClause *intoClause;
 List *targetList;
 List *fromClause;
 Node *whereClause;
 List *groupClause;
 Node *havingClause;
 List *windowClause;
 WithClause *withClause;
# 1029 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 List *valuesLists;





 List *sortClause;
 Node *limitOffset;
 Node *limitCount;
 List *lockingClause;




 SetOperation op;
 bool all;
 struct SelectStmt *larg;
 struct SelectStmt *rarg;

} SelectStmt;
# 1070 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct SetOperationStmt
{
 NodeTag type;
 SetOperation op;
 bool all;
 Node *larg;
 Node *rarg;



 List *colTypes;
 List *colTypmods;
 List *colCollations;
 List *groupClauses;

} SetOperationStmt;
# 1105 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum ObjectType
{
 OBJECT_AGGREGATE,
 OBJECT_ATTRIBUTE,
 OBJECT_CAST,
 OBJECT_COLUMN,
 OBJECT_CONSTRAINT,
 OBJECT_COLLATION,
 OBJECT_CONVERSION,
 OBJECT_DATABASE,
 OBJECT_DOMAIN,
 OBJECT_EXTENSION,
 OBJECT_FDW,
 OBJECT_FOREIGN_SERVER,
 OBJECT_FOREIGN_TABLE,
 OBJECT_FUNCTION,
 OBJECT_INDEX,
 OBJECT_LANGUAGE,
 OBJECT_LARGEOBJECT,
 OBJECT_OPCLASS,
 OBJECT_OPERATOR,
 OBJECT_OPFAMILY,
 OBJECT_ROLE,
 OBJECT_RULE,
 OBJECT_SCHEMA,
 OBJECT_SEQUENCE,
 OBJECT_TABLE,
 OBJECT_TABLESPACE,
 OBJECT_TRIGGER,
 OBJECT_TSCONFIGURATION,
 OBJECT_TSDICTIONARY,
 OBJECT_TSPARSER,
 OBJECT_TSTEMPLATE,
 OBJECT_TYPE,
 OBJECT_VIEW
} ObjectType;
# 1150 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CreateSchemaStmt
{
 NodeTag type;
 char *schemaname;
 char *authid;
 List *schemaElts;
} CreateSchemaStmt;

typedef enum DropBehavior
{
 DROP_RESTRICT,
 DROP_CASCADE
} DropBehavior;





typedef struct AlterTableStmt
{
 NodeTag type;
 RangeVar *relation;
 List *cmds;
 ObjectType relkind;
 bool missing_ok;
} AlterTableStmt;

typedef enum AlterTableType
{
 AT_AddColumn,
 AT_AddColumnRecurse,
 AT_AddColumnToView,
 AT_ColumnDefault,
 AT_DropNotNull,
 AT_SetNotNull,
 AT_SetStatistics,
 AT_SetOptions,
 AT_ResetOptions,
 AT_SetStorage,
 AT_DropColumn,
 AT_DropColumnRecurse,
 AT_AddIndex,
 AT_ReAddIndex,
 AT_AddConstraint,
 AT_AddConstraintRecurse,
 AT_ValidateConstraint,
 AT_ValidateConstraintRecurse,
 AT_ProcessedConstraint,

 AT_AddIndexConstraint,
 AT_DropConstraint,
 AT_DropConstraintRecurse,
 AT_AlterColumnType,
 AT_AlterColumnGenericOptions,
 AT_ChangeOwner,
 AT_ClusterOn,
 AT_DropCluster,
 AT_AddOids,
 AT_AddOidsRecurse,
 AT_DropOids,
 AT_SetTableSpace,
 AT_SetRelOptions,
 AT_ResetRelOptions,
 AT_ReplaceRelOptions,
 AT_EnableTrig,
 AT_EnableAlwaysTrig,
 AT_EnableReplicaTrig,
 AT_DisableTrig,
 AT_EnableTrigAll,
 AT_DisableTrigAll,
 AT_EnableTrigUser,
 AT_DisableTrigUser,
 AT_EnableRule,
 AT_EnableAlwaysRule,
 AT_EnableReplicaRule,
 AT_DisableRule,
 AT_AddInherit,
 AT_DropInherit,
 AT_AddOf,
 AT_DropOf,
 AT_GenericOptions,

 AT_ReAddConstraint
} AlterTableType;

typedef struct AlterTableCmd
{
 NodeTag type;
 AlterTableType subtype;
 char *name;

 Node *def;

 DropBehavior behavior;
 bool missing_ok;
} AlterTableCmd;
# 1255 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct AlterDomainStmt
{
 NodeTag type;
 char subtype;







 List *typeName;
 char *name;
 Node *def;
 DropBehavior behavior;
 bool missing_ok;
} AlterDomainStmt;






typedef enum GrantTargetType
{
 ACL_TARGET_OBJECT,
 ACL_TARGET_ALL_IN_SCHEMA,
 ACL_TARGET_DEFAULTS
} GrantTargetType;

typedef enum GrantObjectType
{
 ACL_OBJECT_COLUMN,
 ACL_OBJECT_RELATION,
 ACL_OBJECT_SEQUENCE,
 ACL_OBJECT_DATABASE,
 ACL_OBJECT_DOMAIN,
 ACL_OBJECT_FDW,
 ACL_OBJECT_FOREIGN_SERVER,
 ACL_OBJECT_FUNCTION,
 ACL_OBJECT_LANGUAGE,
 ACL_OBJECT_LARGEOBJECT,
 ACL_OBJECT_NAMESPACE,
 ACL_OBJECT_TABLESPACE,
 ACL_OBJECT_TYPE
} GrantObjectType;

typedef struct GrantStmt
{
 NodeTag type;
 bool is_grant;
 GrantTargetType targtype;
 GrantObjectType objtype;
 List *objects;

 List *privileges;

 List *grantees;
 bool grant_option;
 DropBehavior behavior;
} GrantStmt;

typedef struct PrivGrantee
{
 NodeTag type;
 char *rolname;
} PrivGrantee;






typedef struct FuncWithArgs
{
 NodeTag type;
 List *funcname;
 List *funcargs;
} FuncWithArgs;
# 1342 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct AccessPriv
{
 NodeTag type;
 char *priv_name;
 List *cols;
} AccessPriv;
# 1358 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct GrantRoleStmt
{
 NodeTag type;
 List *granted_roles;
 List *grantee_roles;
 bool is_grant;
 bool admin_opt;
 char *grantor;
 DropBehavior behavior;
} GrantRoleStmt;





typedef struct AlterDefaultPrivilegesStmt
{
 NodeTag type;
 List *options;
 GrantStmt *action;
} AlterDefaultPrivilegesStmt;
# 1388 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CopyStmt
{
 NodeTag type;
 RangeVar *relation;
 Node *query;
 List *attlist;

 bool is_from;
 char *filename;
 List *options;
} CopyStmt;
# 1407 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum
{
 VAR_SET_VALUE,
 VAR_SET_DEFAULT,
 VAR_SET_CURRENT,
 VAR_SET_MULTI,
 VAR_RESET,
 VAR_RESET_ALL
} VariableSetKind;

typedef struct VariableSetStmt
{
 NodeTag type;
 VariableSetKind kind;
 char *name;
 List *args;
 bool is_local;
} VariableSetStmt;





typedef struct VariableShowStmt
{
 NodeTag type;
 char *name;
} VariableShowStmt;
# 1447 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CreateStmt
{
 NodeTag type;
 RangeVar *relation;
 List *tableElts;
 List *inhRelations;

 TypeName *ofTypename;
 List *constraints;
 List *options;
 OnCommitAction oncommit;
 char *tablespacename;
 bool if_not_exists;
} CreateStmt;
# 1493 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum ConstrType
{
 CONSTR_NULL,
 CONSTR_NOTNULL,
 CONSTR_DEFAULT,
 CONSTR_CHECK,
 CONSTR_PRIMARY,
 CONSTR_UNIQUE,
 CONSTR_EXCLUSION,
 CONSTR_FOREIGN,
 CONSTR_ATTR_DEFERRABLE,
 CONSTR_ATTR_NOT_DEFERRABLE,
 CONSTR_ATTR_DEFERRED,
 CONSTR_ATTR_IMMEDIATE
} ConstrType;
# 1521 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct Constraint
{
 NodeTag type;
 ConstrType contype;


 char *conname;
 bool deferrable;
 bool initdeferred;
 int location;


 bool is_no_inherit;
 Node *raw_expr;
 char *cooked_expr;


 List *keys;


 List *exclusions;


 List *options;
 char *indexname;
 char *indexspace;

 char *access_method;
 Node *where_clause;


 RangeVar *pktable;
 List *fk_attrs;
 List *pk_attrs;
 char fk_matchtype;
 char fk_upd_action;
 char fk_del_action;
 List *old_conpfeqop;


 bool skip_validation;
 bool initially_valid;
} Constraint;






typedef struct CreateTableSpaceStmt
{
 NodeTag type;
 char *tablespacename;
 char *owner;
 char *location;
} CreateTableSpaceStmt;

typedef struct DropTableSpaceStmt
{
 NodeTag type;
 char *tablespacename;
 bool missing_ok;
} DropTableSpaceStmt;

typedef struct AlterTableSpaceOptionsStmt
{
 NodeTag type;
 char *tablespacename;
 List *options;
 bool isReset;
} AlterTableSpaceOptionsStmt;






typedef struct CreateExtensionStmt
{
 NodeTag type;
 char *extname;
 bool if_not_exists;
 List *options;
} CreateExtensionStmt;


typedef struct AlterExtensionStmt
{
 NodeTag type;
 char *extname;
 List *options;
} AlterExtensionStmt;

typedef struct AlterExtensionContentsStmt
{
 NodeTag type;
 char *extname;
 int action;
 ObjectType objtype;
 List *objname;
 List *objargs;
} AlterExtensionContentsStmt;






typedef struct CreateFdwStmt
{
 NodeTag type;
 char *fdwname;
 List *func_options;
 List *options;
} CreateFdwStmt;

typedef struct AlterFdwStmt
{
 NodeTag type;
 char *fdwname;
 List *func_options;
 List *options;
} AlterFdwStmt;






typedef struct CreateForeignServerStmt
{
 NodeTag type;
 char *servername;
 char *servertype;
 char *version;
 char *fdwname;
 List *options;
} CreateForeignServerStmt;

typedef struct AlterForeignServerStmt
{
 NodeTag type;
 char *servername;
 char *version;
 List *options;
 bool has_version;
} AlterForeignServerStmt;






typedef struct CreateForeignTableStmt
{
 CreateStmt base;
 char *servername;
 List *options;
} CreateForeignTableStmt;






typedef struct CreateUserMappingStmt
{
 NodeTag type;
 char *username;
 char *servername;
 List *options;
} CreateUserMappingStmt;

typedef struct AlterUserMappingStmt
{
 NodeTag type;
 char *username;
 char *servername;
 List *options;
} AlterUserMappingStmt;

typedef struct DropUserMappingStmt
{
 NodeTag type;
 char *username;
 char *servername;
 bool missing_ok;
} DropUserMappingStmt;





typedef struct CreateTrigStmt
{
 NodeTag type;
 char *trigname;
 RangeVar *relation;
 List *funcname;
 List *args;
 bool row;

 int16 timing;

 int16 events;
 List *columns;
 Node *whenClause;
 bool isconstraint;

 bool deferrable;
 bool initdeferred;
 RangeVar *constrrel;
} CreateTrigStmt;





typedef struct CreatePLangStmt
{
 NodeTag type;
 bool replace;
 char *plname;
 List *plhandler;
 List *plinline;
 List *plvalidator;
 bool pltrusted;
} CreatePLangStmt;
# 1759 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum RoleStmtType
{
 ROLESTMT_ROLE,
 ROLESTMT_USER,
 ROLESTMT_GROUP
} RoleStmtType;

typedef struct CreateRoleStmt
{
 NodeTag type;
 RoleStmtType stmt_type;
 char *role;
 List *options;
} CreateRoleStmt;

typedef struct AlterRoleStmt
{
 NodeTag type;
 char *role;
 List *options;
 int action;
} AlterRoleStmt;

typedef struct AlterRoleSetStmt
{
 NodeTag type;
 char *role;
 char *database;
 VariableSetStmt *setstmt;
} AlterRoleSetStmt;

typedef struct DropRoleStmt
{
 NodeTag type;
 List *roles;
 bool missing_ok;
} DropRoleStmt;






typedef struct CreateSeqStmt
{
 NodeTag type;
 RangeVar *sequence;
 List *options;
 Oid ownerId;
} CreateSeqStmt;

typedef struct AlterSeqStmt
{
 NodeTag type;
 RangeVar *sequence;
 List *options;
 bool missing_ok;
} AlterSeqStmt;





typedef struct DefineStmt
{
 NodeTag type;
 ObjectType kind;
 bool oldstyle;
 List *defnames;
 List *args;
 List *definition;
} DefineStmt;





typedef struct CreateDomainStmt
{
 NodeTag type;
 List *domainname;
 TypeName *typeName;
 CollateClause *collClause;
 List *constraints;
} CreateDomainStmt;





typedef struct CreateOpClassStmt
{
 NodeTag type;
 List *opclassname;
 List *opfamilyname;
 char *amname;
 TypeName *datatype;
 List *items;
 bool isDefault;
} CreateOpClassStmt;





typedef struct CreateOpClassItem
{
 NodeTag type;
 int itemtype;

 List *name;
 List *args;
 int number;
 List *order_family;
 List *class_args;

 TypeName *storedtype;
} CreateOpClassItem;





typedef struct CreateOpFamilyStmt
{
 NodeTag type;
 List *opfamilyname;
 char *amname;
} CreateOpFamilyStmt;





typedef struct AlterOpFamilyStmt
{
 NodeTag type;
 List *opfamilyname;
 char *amname;
 bool isDrop;
 List *items;
} AlterOpFamilyStmt;






typedef struct DropStmt
{
 NodeTag type;
 List *objects;
 List *arguments;
 ObjectType removeType;
 DropBehavior behavior;
 bool missing_ok;
 bool concurrent;
} DropStmt;





typedef struct TruncateStmt
{
 NodeTag type;
 List *relations;
 bool restart_seqs;
 DropBehavior behavior;
} TruncateStmt;





typedef struct CommentStmt
{
 NodeTag type;
 ObjectType objtype;
 List *objname;
 List *objargs;
 char *comment;
} CommentStmt;





typedef struct SecLabelStmt
{
 NodeTag type;
 ObjectType objtype;
 List *objname;
 List *objargs;
 char *provider;
 char *label;
} SecLabelStmt;
# 1975 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct DeclareCursorStmt
{
 NodeTag type;
 char *portalname;
 int options;
 Node *query;
} DeclareCursorStmt;





typedef struct ClosePortalStmt
{
 NodeTag type;
 char *portalname;

} ClosePortalStmt;





typedef enum FetchDirection
{

 FETCH_FORWARD,
 FETCH_BACKWARD,

 FETCH_ABSOLUTE,
 FETCH_RELATIVE
} FetchDirection;



typedef struct FetchStmt
{
 NodeTag type;
 FetchDirection direction;
 long howMany;
 char *portalname;
 bool ismove;
} FetchStmt;
# 2030 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct IndexStmt
{
 NodeTag type;
 char *idxname;
 RangeVar *relation;
 char *accessMethod;
 char *tableSpace;
 List *indexParams;
 List *options;
 Node *whereClause;
 List *excludeOpNames;
 char *idxcomment;
 Oid indexOid;
 Oid oldNode;
 bool unique;
 bool primary;
 bool isconstraint;
 bool deferrable;
 bool initdeferred;
 bool concurrent;
} IndexStmt;





typedef struct CreateFunctionStmt
{
 NodeTag type;
 bool replace;
 List *funcname;
 List *parameters;
 TypeName *returnType;
 List *options;
 List *withClause;
} CreateFunctionStmt;

typedef enum FunctionParameterMode
{

 FUNC_PARAM_IN = 'i',
 FUNC_PARAM_OUT = 'o',
 FUNC_PARAM_INOUT = 'b',
 FUNC_PARAM_VARIADIC = 'v',
 FUNC_PARAM_TABLE = 't'
} FunctionParameterMode;

typedef struct FunctionParameter
{
 NodeTag type;
 char *name;
 TypeName *argType;
 FunctionParameterMode mode;
 Node *defexpr;
} FunctionParameter;

typedef struct AlterFunctionStmt
{
 NodeTag type;
 FuncWithArgs *func;
 List *actions;
} AlterFunctionStmt;







typedef struct DoStmt
{
 NodeTag type;
 List *args;
} DoStmt;

typedef struct InlineCodeBlock
{
 NodeTag type;
 char *source_text;
 Oid langOid;
 bool langIsTrusted;
} InlineCodeBlock;





typedef struct RenameStmt
{
 NodeTag type;
 ObjectType renameType;
 ObjectType relationType;
 RangeVar *relation;
 List *object;
 List *objarg;
 char *subname;

 char *newname;
 DropBehavior behavior;
 bool missing_ok;
} RenameStmt;





typedef struct AlterObjectSchemaStmt
{
 NodeTag type;
 ObjectType objectType;
 RangeVar *relation;
 List *object;
 List *objarg;
 char *addname;
 char *newschema;
 bool missing_ok;
} AlterObjectSchemaStmt;





typedef struct AlterOwnerStmt
{
 NodeTag type;
 ObjectType objectType;
 RangeVar *relation;
 List *object;
 List *objarg;
 char *addname;
 char *newowner;
} AlterOwnerStmt;






typedef struct RuleStmt
{
 NodeTag type;
 RangeVar *relation;
 char *rulename;
 Node *whereClause;
 CmdType event;
 bool instead;
 List *actions;
 bool replace;
} RuleStmt;





typedef struct NotifyStmt
{
 NodeTag type;
 char *conditionname;
 char *payload;
} NotifyStmt;





typedef struct ListenStmt
{
 NodeTag type;
 char *conditionname;
} ListenStmt;





typedef struct UnlistenStmt
{
 NodeTag type;
 char *conditionname;
} UnlistenStmt;





typedef enum TransactionStmtKind
{
 TRANS_STMT_BEGIN,
 TRANS_STMT_START,
 TRANS_STMT_COMMIT,
 TRANS_STMT_ROLLBACK,
 TRANS_STMT_SAVEPOINT,
 TRANS_STMT_RELEASE,
 TRANS_STMT_ROLLBACK_TO,
 TRANS_STMT_PREPARE,
 TRANS_STMT_COMMIT_PREPARED,
 TRANS_STMT_ROLLBACK_PREPARED
} TransactionStmtKind;

typedef struct TransactionStmt
{
 NodeTag type;
 TransactionStmtKind kind;
 List *options;
 char *gid;
} TransactionStmt;





typedef struct CompositeTypeStmt
{
 NodeTag type;
 RangeVar *typevar;
 List *coldeflist;
} CompositeTypeStmt;





typedef struct CreateEnumStmt
{
 NodeTag type;
 List *typeName;
 List *vals;
} CreateEnumStmt;





typedef struct CreateRangeStmt
{
 NodeTag type;
 List *typeName;
 List *params;
} CreateRangeStmt;





typedef struct AlterEnumStmt
{
 NodeTag type;
 List *typeName;
 char *newVal;
 char *newValNeighbor;
 bool newValIsAfter;
} AlterEnumStmt;





typedef struct ViewStmt
{
 NodeTag type;
 RangeVar *view;
 List *aliases;
 Node *query;
 bool replace;
 List *options;
} ViewStmt;





typedef struct LoadStmt
{
 NodeTag type;
 char *filename;
} LoadStmt;





typedef struct CreatedbStmt
{
 NodeTag type;
 char *dbname;
 List *options;
} CreatedbStmt;





typedef struct AlterDatabaseStmt
{
 NodeTag type;
 char *dbname;
 List *options;
} AlterDatabaseStmt;

typedef struct AlterDatabaseSetStmt
{
 NodeTag type;
 char *dbname;
 VariableSetStmt *setstmt;
} AlterDatabaseSetStmt;





typedef struct DropdbStmt
{
 NodeTag type;
 char *dbname;
 bool missing_ok;
} DropdbStmt;





typedef struct ClusterStmt
{
 NodeTag type;
 RangeVar *relation;
 char *indexname;
 bool verbose;
} ClusterStmt;
# 2369 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum VacuumOption
{
 VACOPT_VACUUM = 1 << 0,
 VACOPT_ANALYZE = 1 << 1,
 VACOPT_VERBOSE = 1 << 2,
 VACOPT_FREEZE = 1 << 3,
 VACOPT_FULL = 1 << 4,
 VACOPT_NOWAIT = 1 << 5
} VacuumOption;

typedef struct VacuumStmt
{
 NodeTag type;
 int options;
 int freeze_min_age;
 int freeze_table_age;
 RangeVar *relation;
 List *va_cols;
} VacuumStmt;
# 2397 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ExplainStmt
{
 NodeTag type;
 Node *query;
 List *options;
} ExplainStmt;
# 2415 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CreateTableAsStmt
{
 NodeTag type;
 Node *query;
 IntoClause *into;
 bool is_select_into;
} CreateTableAsStmt;





typedef struct CheckPointStmt
{
 NodeTag type;
} CheckPointStmt;






typedef enum DiscardMode
{
 DISCARD_ALL,
 DISCARD_PLANS,
 DISCARD_TEMP
} DiscardMode;

typedef struct DiscardStmt
{
 NodeTag type;
 DiscardMode target;
} DiscardStmt;





typedef struct LockStmt
{
 NodeTag type;
 List *relations;
 int mode;
 bool nowait;
} LockStmt;





typedef struct ConstraintsSetStmt
{
 NodeTag type;
 List *constraints;
 bool deferred;
} ConstraintsSetStmt;





typedef struct ReindexStmt
{
 NodeTag type;
 ObjectType kind;
 RangeVar *relation;
 const char *name;
 bool do_system;
 bool do_user;
} ReindexStmt;





typedef struct CreateConversionStmt
{
 NodeTag type;
 List *conversion_name;
 char *for_encoding_name;
 char *to_encoding_name;
 List *func_name;
 bool def;
} CreateConversionStmt;





typedef struct CreateCastStmt
{
 NodeTag type;
 TypeName *sourcetype;
 TypeName *targettype;
 FuncWithArgs *func;
 CoercionContext context;
 bool inout;
} CreateCastStmt;





typedef struct PrepareStmt
{
 NodeTag type;
 char *name;
 List *argtypes;
 Node *query;
} PrepareStmt;







typedef struct ExecuteStmt
{
 NodeTag type;
 char *name;
 List *params;
} ExecuteStmt;






typedef struct DeallocateStmt
{
 NodeTag type;
 char *name;

} DeallocateStmt;




typedef struct DropOwnedStmt
{
 NodeTag type;
 List *roles;
 DropBehavior behavior;
} DropOwnedStmt;




typedef struct ReassignOwnedStmt
{
 NodeTag type;
 List *roles;
 char *newrole;
} ReassignOwnedStmt;




typedef struct AlterTSDictionaryStmt
{
 NodeTag type;
 List *dictname;
 List *options;
} AlterTSDictionaryStmt;




typedef struct AlterTSConfigurationStmt
{
 NodeTag type;
 List *cfgname;





 List *tokentype;
 List *dicts;
 bool override;
 bool replace;
 bool missing_ok;
} AlterTSConfigurationStmt;
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/objectaddress.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/objectaddress.h" 2





typedef struct ObjectAddress
{
 Oid classId;
 Oid objectId;
 int32 objectSubId;
} ObjectAddress;

extern ObjectAddress get_object_address(ObjectType objtype, List *objname,
       List *objargs, Relation *relp,
       LOCKMODE lockmode, bool missing_ok);

extern void check_object_ownership(Oid roleid,
        ObjectType objtype, ObjectAddress address,
        List *objname, List *objargs, Relation relation);

extern Oid get_object_namespace(const ObjectAddress *address);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/dependency.h" 2
# 67 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/dependency.h"
typedef enum DependencyType
{
 DEPENDENCY_NORMAL = 'n',
 DEPENDENCY_AUTO = 'a',
 DEPENDENCY_INTERNAL = 'i',
 DEPENDENCY_EXTENSION = 'e',
 DEPENDENCY_PIN = 'p'
} DependencyType;
# 102 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/dependency.h"
typedef enum SharedDependencyType
{
 SHARED_DEPENDENCY_PIN = 'p',
 SHARED_DEPENDENCY_OWNER = 'o',
 SHARED_DEPENDENCY_ACL = 'a',
 SHARED_DEPENDENCY_INVALID = 0
} SharedDependencyType;


typedef struct ObjectAddresses ObjectAddresses;





typedef enum ObjectClass
{
 OCLASS_CLASS,
 OCLASS_PROC,
 OCLASS_TYPE,
 OCLASS_CAST,
 OCLASS_COLLATION,
 OCLASS_CONSTRAINT,
 OCLASS_CONVERSION,
 OCLASS_DEFAULT,
 OCLASS_LANGUAGE,
 OCLASS_LARGEOBJECT,
 OCLASS_OPERATOR,
 OCLASS_OPCLASS,
 OCLASS_OPFAMILY,
 OCLASS_AMOP,
 OCLASS_AMPROC,
 OCLASS_REWRITE,
 OCLASS_TRIGGER,
 OCLASS_SCHEMA,
 OCLASS_TSPARSER,
 OCLASS_TSDICT,
 OCLASS_TSTEMPLATE,
 OCLASS_TSCONFIG,
 OCLASS_ROLE,
 OCLASS_DATABASE,
 OCLASS_TBLSPACE,
 OCLASS_FDW,
 OCLASS_FOREIGN_SERVER,
 OCLASS_USER_MAPPING,
 OCLASS_DEFACL,
 OCLASS_EXTENSION,
 MAX_OCLASS
} ObjectClass;







extern void performDeletion(const ObjectAddress *object,
    DropBehavior behavior, int flags);

extern void performMultipleDeletions(const ObjectAddresses *objects,
       DropBehavior behavior, int flags);

extern void deleteWhatDependsOn(const ObjectAddress *object,
     bool showNotices);

extern void recordDependencyOnExpr(const ObjectAddress *depender,
        Node *expr, List *rtable,
        DependencyType behavior);

extern void recordDependencyOnSingleRelExpr(const ObjectAddress *depender,
        Node *expr, Oid relId,
        DependencyType behavior,
        DependencyType self_behavior);

extern ObjectClass getObjectClass(const ObjectAddress *object);

extern char *getObjectDescription(const ObjectAddress *object);
extern char *getObjectDescriptionOids(Oid classid, Oid objid);

extern ObjectAddresses *new_object_addresses(void);

extern void add_exact_object_address(const ObjectAddress *object,
       ObjectAddresses *addrs);

extern bool object_address_present(const ObjectAddress *object,
        const ObjectAddresses *addrs);

extern void record_object_address_dependencies(const ObjectAddress *depender,
           ObjectAddresses *referenced,
           DependencyType behavior);

extern void free_object_addresses(ObjectAddresses *addrs);



extern void recordDependencyOn(const ObjectAddress *depender,
       const ObjectAddress *referenced,
       DependencyType behavior);

extern void recordMultipleDependencies(const ObjectAddress *depender,
         const ObjectAddress *referenced,
         int nreferenced,
         DependencyType behavior);

extern void recordDependencyOnCurrentExtension(const ObjectAddress *object,
           bool isReplace);

extern long deleteDependencyRecordsFor(Oid classId, Oid objectId,
         bool skipExtensionDeps);

extern long deleteDependencyRecordsForClass(Oid classId, Oid objectId,
        Oid refclassId, char deptype);

extern long changeDependencyFor(Oid classId, Oid objectId,
     Oid refClassId, Oid oldRefObjectId,
     Oid newRefObjectId);

extern Oid getExtensionOfObject(Oid classId, Oid objectId);

extern bool sequenceIsOwned(Oid seqId, Oid *tableId, int32 *colId);

extern void markSequenceUnowned(Oid seqId);

extern List *getOwnedSequences(Oid relid);

extern Oid get_constraint_index(Oid constraintId);

extern Oid get_index_constraint(Oid indexId);



extern void recordSharedDependencyOn(ObjectAddress *depender,
       ObjectAddress *referenced,
       SharedDependencyType deptype);

extern void deleteSharedDependencyRecordsFor(Oid classId, Oid objectId,
         int32 objectSubId);

extern void recordDependencyOnOwner(Oid classId, Oid objectId, Oid owner);

extern void changeDependencyOnOwner(Oid classId, Oid objectId,
      Oid newOwnerId);

extern void updateAclDependencies(Oid classId, Oid objectId, int32 objectSubId,
       Oid ownerId,
       int noldmembers, Oid *oldmembers,
       int nnewmembers, Oid *newmembers);

extern bool checkSharedDependencies(Oid classId, Oid objectId,
      char **detail_msg, char **detail_log_msg);

extern void shdepLockAndCheckObject(Oid classId, Oid objectId);

extern void copyTemplateDependencies(Oid templateDbId, Oid newDbId);

extern void dropDatabaseDependencies(Oid databaseId);

extern void shdepDropOwned(List *relids, DropBehavior behavior);

extern void shdepReassignOwned(List *relids, Oid newrole);
# 60 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/indexing.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/indexing.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/indexing.h" 2







typedef struct ResultRelInfo *CatalogIndexState;




extern CatalogIndexState CatalogOpenIndexes(Relation heapRel);
extern void CatalogCloseIndexes(CatalogIndexState indstate);
extern void CatalogIndexInsert(CatalogIndexState indstate,
       HeapTuple heapTuple);
extern void CatalogUpdateIndexes(Relation heapRel, HeapTuple heapTuple);
# 60 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/indexing.h"
extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;



extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;



extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;



extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;



extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;



extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;


extern int no_such_variable;




# 61 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/objectaccess.h" 1
# 27 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/objectaccess.h"
typedef enum ObjectAccessType
{
 OAT_POST_CREATE,
 OAT_DROP,
} ObjectAccessType;




typedef struct
{




 int dropflags;
} ObjectAccessDrop;




typedef void (*object_access_hook_type) (ObjectAccessType access,
              Oid classId,
              Oid objectId,
              int subId,
              void *arg);

extern object_access_hook_type object_access_hook;
# 62 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_tablespace.h" 1
# 31 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_tablespace.h"
typedef struct FormData_pg_tablespace
{
 NameData spcname;
 Oid spcowner;





} FormData_pg_tablespace;






typedef FormData_pg_tablespace *Form_pg_tablespace;
# 60 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_tablespace.h"
extern int no_such_variable;
extern int no_such_variable;
# 63 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/comment.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/comment.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/comment.h" 2
# 32 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/comment.h"
extern void CommentObject(CommentStmt *stmt);

extern void DeleteComments(Oid oid, Oid classoid, int32 subid);

extern void CreateComments(Oid oid, Oid classoid, int32 subid, char *comment);

extern void DeleteSharedComments(Oid oid, Oid classoid);

extern void CreateSharedComments(Oid oid, Oid classoid, char *comment);

extern char *GetComment(Oid oid, Oid classoid, int32 subid);
# 64 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/seclabel.h" 1
# 12 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/seclabel.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/objectaddress.h" 1
# 13 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/seclabel.h" 2




extern char *GetSecurityLabel(const ObjectAddress *object,
     const char *provider);
extern void SetSecurityLabel(const ObjectAddress *object,
     const char *provider, const char *label);
extern void DeleteSecurityLabel(const ObjectAddress *object);
extern void DeleteSharedSecurityLabel(Oid objectId, Oid classId);




extern void ExecSecLabelStmt(SecLabelStmt *stmt);

typedef void (*check_object_relabel_type) (const ObjectAddress *object,
                const char *seclabel);
extern void register_label_provider(const char *provider,
      check_object_relabel_type hook);
# 65 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/tablespace.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/tablespace.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/tablespace.h" 2






typedef struct xl_tblspc_create_rec
{
 Oid ts_id;
 char ts_path[1];
} xl_tblspc_create_rec;

typedef struct xl_tblspc_drop_rec
{
 Oid ts_id;
} xl_tblspc_drop_rec;

typedef struct TableSpaceOpts
{
 int32 vl_len_;
 float8 random_page_cost;
 float8 seq_page_cost;
} TableSpaceOpts;

extern void CreateTableSpace(CreateTableSpaceStmt *stmt);
extern void DropTableSpace(DropTableSpaceStmt *stmt);
extern void RenameTableSpace(const char *oldname, const char *newname);
extern void AlterTableSpaceOwner(const char *name, Oid newOwnerId);
extern void AlterTableSpaceOptions(AlterTableSpaceOptionsStmt *stmt);

extern void TablespaceCreateDbspace(Oid spcNode, Oid dbNode, bool isRedo);

extern Oid GetDefaultTablespace(char relpersistence);

extern void PrepareTempTablespaces(void);

extern Oid get_tablespace_oid(const char *tablespacename, bool missing_ok);
extern char *get_tablespace_name(Oid spc_oid);

extern bool directory_is_empty(const char *path);

extern void tblspc_redo(XLogRecPtr lsn, XLogRecord *rptr);
extern void tblspc_desc(StringInfo buf, uint8 xl_info, char *rec);
# 66 "tablespace.c" 2
# 1 "miscadmin.h" 1
# 26 "miscadmin.h"
# 1 "pgtime.h" 1
# 23 "pgtime.h"
typedef int64 pg_time_t;

struct pg_tm
{
 int tm_sec;
 int tm_min;
 int tm_hour;
 int tm_mday;
 int tm_mon;
 int tm_year;
 int tm_wday;
 int tm_yday;
 int tm_isdst;
 long int tm_gmtoff;
 const char *tm_zone;
};

typedef struct pg_tz pg_tz;
typedef struct pg_tzenum pg_tzenum;






extern struct pg_tm *pg_localtime(const pg_time_t *timep, const pg_tz *tz);
extern struct pg_tm *pg_gmtime(const pg_time_t *timep);
extern int pg_next_dst_boundary(const pg_time_t *timep,
      long int *before_gmtoff,
      int *before_isdst,
      pg_time_t *boundary,
      long int *after_gmtoff,
      int *after_isdst,
      const pg_tz *tz);
extern size_t pg_strftime(char *s, size_t max, const char *format,
   const struct pg_tm * tm);

extern bool pg_get_timezone_offset(const pg_tz *tz, long int *gmtoff);
extern const char *pg_get_timezone_name(pg_tz *tz);
extern bool pg_tz_acceptable(pg_tz *tz);



extern pg_tz *session_timezone;
extern pg_tz *log_timezone;

extern void pg_timezone_initialize(void);
extern pg_tz *pg_tzset(const char *tzname);

extern pg_tzenum *pg_tzenumerate_start(void);
extern pg_tz *pg_tzenumerate_next(pg_tzenum *dir);
extern void pg_tzenumerate_end(pg_tzenum *dir);
# 27 "miscadmin.h" 2
# 74 "miscadmin.h"
extern volatile bool InterruptPending;
extern volatile bool QueryCancelPending;
extern volatile bool ProcDiePending;

extern volatile bool ClientConnectionLost;


extern volatile bool ImmediateInterruptOK;
extern volatile uint32 InterruptHoldoffCount;
extern volatile uint32 CritSectionCount;


extern void ProcessInterrupts(void);
# 131 "miscadmin.h"
extern pid_t PostmasterPid;
extern bool IsPostmasterEnvironment;
extern bool IsUnderPostmaster;
extern bool IsBinaryUpgrade;

extern bool ExitOnAnyError;

extern char *DataDir;

extern int NBuffers;
extern int MaxBackends;
extern int MaxConnections;

extern int MyProcPid;
extern pg_time_t MyStartTime;
extern struct Port *MyProcPort;
extern long MyCancelKey;
extern int MyPMChildSlot;

extern char OutputFileName[];
extern char my_exec_path[];
extern char pkglib_path[];
# 163 "miscadmin.h"
extern Oid MyDatabaseId;

extern Oid MyDatabaseTableSpace;
# 201 "miscadmin.h"
extern int DateStyle;
extern int DateOrder;
# 216 "miscadmin.h"
extern int IntervalStyle;







extern bool HasCTZSet;
extern int CTimeZone;



extern bool enableFsync;
extern bool allowSystemTableMods;
extern int work_mem;
extern int maintenance_work_mem;

extern int VacuumCostPageHit;
extern int VacuumCostPageMiss;
extern int VacuumCostPageDirty;
extern int VacuumCostLimit;
extern int VacuumCostDelay;

extern int VacuumPageHit;
extern int VacuumPageMiss;
extern int VacuumPageDirty;

extern int VacuumCostBalance;
extern bool VacuumCostActive;
# 257 "miscadmin.h"
typedef char *pg_stack_base_t;


extern pg_stack_base_t set_stack_base(void);
extern void restore_stack_base(pg_stack_base_t base);
extern void check_stack_depth(void);


extern void PreventCommandIfReadOnly(const char *cmdname);
extern void PreventCommandDuringRecovery(const char *cmdname);


extern int trace_recovery_messages;
extern int trace_recovery(int trace_level);
# 281 "miscadmin.h"
extern char *DatabasePath;


extern void SetDatabasePath(const char *path);

extern char *GetUserNameFromId(Oid roleid);
extern Oid GetUserId(void);
extern Oid GetOuterUserId(void);
extern Oid GetSessionUserId(void);
extern void GetUserIdAndSecContext(Oid *userid, int *sec_context);
extern void SetUserIdAndSecContext(Oid userid, int sec_context);
extern bool InLocalUserIdChange(void);
extern bool InSecurityRestrictedOperation(void);
extern void GetUserIdAndContext(Oid *userid, bool *sec_def_context);
extern void SetUserIdAndContext(Oid userid, bool sec_def_context);
extern void InitializeSessionUserId(const char *rolename);
extern void InitializeSessionUserIdStandalone(void);
extern void SetSessionAuthorization(Oid userid, bool is_superuser);
extern Oid GetCurrentRoleId(void);
extern void SetCurrentRoleId(Oid roleid, bool is_superuser);

extern void SetDataDir(const char *dir);
extern void ChangeToDataDir(void);
extern char *make_absolute_path(const char *path);


extern bool superuser(void);
extern bool superuser_arg(Oid roleid);
# 335 "miscadmin.h"
typedef enum ProcessingMode
{
 BootstrapProcessing,
 InitProcessing,
 NormalProcessing
} ProcessingMode;

extern ProcessingMode Mode;
# 365 "miscadmin.h"
typedef enum
{
 NotAnAuxProcess = -1,
 CheckerProcess = 0,
 BootstrapProcess,
 StartupProcess,
 BgWriterProcess,
 CheckpointerProcess,
 WalWriterProcess,
 WalReceiverProcess,

 NUM_AUXPROCTYPES
} AuxProcType;

extern AuxProcType MyAuxProcType;
# 395 "miscadmin.h"
extern void pg_split_opts(char **argv, int *argcp, char *optstr);
extern void InitPostgres(const char *in_dbname, Oid dboid, const char *username,
    char *out_dbname);
extern void BaseInit(void);


extern bool IgnoreSystemIndexes;
extern bool process_shared_preload_libraries_in_progress;
extern char *shared_preload_libraries_string;
extern char *local_preload_libraries_string;
# 431 "miscadmin.h"
extern void CreateDataDirLockFile(bool amPostmaster);
extern void CreateSocketLockFile(const char *socketfile, bool amPostmaster);
extern void TouchSocketLockFile(void);
extern void AddToDataDirLockFile(int target_line, const char *str);
extern void ValidatePgVersion(const char *path);
extern void process_shared_preload_libraries(void);
extern void process_local_preload_libraries(void);
extern void pg_bindtextdomain(const char *domain);
extern bool has_rolreplication(Oid roleid);


extern bool BackupInProgress(void);
extern void CancelBackup(void);
# 67 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/bgwriter.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/bgwriter.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/bgwriter.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/bgwriter.h" 2



extern int BgWriterDelay;
extern int CheckPointTimeout;
extern int CheckPointWarning;
extern double CheckPointCompletionTarget;

extern void BackgroundWriterMain(void);
extern void CheckpointerMain(void);

extern void RequestCheckpoint(int flags);
extern void CheckpointWriteDelay(int flags, double progress);

extern bool ForwardFsyncRequest(RelFileNode rnode, ForkNumber forknum,
     BlockNumber segno);
extern void AbsorbFsyncRequests(void);

extern Size CheckpointerShmemSize(void);
extern void CheckpointerShmemInit(void);

extern bool FirstCallSinceLastCheckpoint(void);
# 68 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/fd.h" 1
# 48 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/fd.h"
typedef char *FileName;

typedef int File;



extern int max_files_per_process;




extern int max_safe_fds;







extern File PathNameOpenFile(FileName fileName, int fileFlags, int fileMode);
extern File OpenTemporaryFile(bool interXact);
extern void FileClose(File file);
extern int FilePrefetch(File file, off_t offset, int amount);
extern int FileRead(File file, char *buffer, int amount);
extern int FileWrite(File file, char *buffer, int amount);
extern int FileSync(File file);
extern off_t FileSeek(File file, off_t offset, int whence);
extern int FileTruncate(File file, off_t offset);
extern char *FilePathName(File file);


extern FILE *AllocateFile(const char *name, const char *mode);
extern int FreeFile(FILE *file);


extern DIR *AllocateDir(const char *dirname);
extern struct dirent *ReadDir(DIR *dir, const char *dirname);
extern int FreeDir(DIR *dir);


extern int BasicOpenFile(FileName fileName, int fileFlags, int fileMode);


extern void InitFileAccess(void);
extern void set_max_safe_fds(void);
extern void closeAllVfds(void);
extern void SetTempTablespaces(Oid *tableSpaces, int numSpaces);
extern bool TempTablespacesAreSet(void);
extern Oid GetNextTempTableSpace(void);
extern void AtEOXact_Files(void);
extern void AtEOSubXact_Files(bool isCommit, SubTransactionId mySubid,
      SubTransactionId parentSubid);
extern void RemovePgTempFiles(void);

extern int pg_fsync(int fd);
extern int pg_fsync_no_writethrough(int fd);
extern int pg_fsync_writethrough(int fd);
extern int pg_fdatasync(int fd);
extern int pg_flush_data(int fd, off_t offset, off_t amount);
# 69 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/standby.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/standby.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/standby.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/standby.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/procsignal.h" 1
# 30 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/procsignal.h"
typedef enum
{
 PROCSIG_CATCHUP_INTERRUPT,
 PROCSIG_NOTIFY_INTERRUPT,


 PROCSIG_RECOVERY_CONFLICT_DATABASE,
 PROCSIG_RECOVERY_CONFLICT_TABLESPACE,
 PROCSIG_RECOVERY_CONFLICT_LOCK,
 PROCSIG_RECOVERY_CONFLICT_SNAPSHOT,
 PROCSIG_RECOVERY_CONFLICT_BUFFERPIN,
 PROCSIG_RECOVERY_CONFLICT_STARTUP_DEADLOCK,

 NUM_PROCSIGNALS
} ProcSignalReason;




extern Size ProcSignalShmemSize(void);
extern void ProcSignalShmemInit(void);

extern void ProcSignalInit(int pss_idx);
extern int SendProcSignal(pid_t pid, ProcSignalReason reason,
      BackendId backendId);

extern void procsignal_sigusr1_handler(int postgres_signal_arg);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/standby.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/standby.h" 2


extern int vacuum_defer_cleanup_age;
extern int max_standby_archive_delay;
extern int max_standby_streaming_delay;

extern void InitRecoveryTransactionEnvironment(void);
extern void ShutdownRecoveryTransactionEnvironment(void);

extern void ResolveRecoveryConflictWithSnapshot(TransactionId latestRemovedXid,
         RelFileNode node);
extern void ResolveRecoveryConflictWithTablespace(Oid tsid);
extern void ResolveRecoveryConflictWithDatabase(Oid dbid);

extern void ResolveRecoveryConflictWithBufferPin(void);
extern void SendRecoveryConflictWithBufferPin(ProcSignalReason reason);
extern void CheckRecoveryConflictDeadlock(void);
# 46 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/standby.h"
extern void StandbyAcquireAccessExclusiveLock(TransactionId xid, Oid dbOid, Oid relOid);
extern void StandbyReleaseLockTree(TransactionId xid,
        int nsubxids, TransactionId *subxids);
extern void StandbyReleaseAllLocks(void);
extern void StandbyReleaseOldLocks(int nxids, TransactionId *xids);







typedef struct xl_standby_locks
{
 int nlocks;
 xl_standby_lock locks[1];
} xl_standby_locks;




typedef struct xl_running_xacts
{
 int xcnt;
 bool subxid_overflow;
 TransactionId nextXid;
 TransactionId oldestRunningXid;
 TransactionId latestCompletedXid;

 TransactionId xids[1];
} xl_running_xacts;





extern void standby_redo(XLogRecPtr lsn, XLogRecord *record);
extern void standby_desc(StringInfo buf, uint8 xl_info, char *rec);
# 97 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/standby.h"
typedef struct RunningTransactionsData
{
 int xcnt;
 bool subxid_overflow;
 TransactionId nextXid;
 TransactionId oldestRunningXid;
 TransactionId latestCompletedXid;

 TransactionId *xids;
} RunningTransactionsData;

typedef RunningTransactionsData *RunningTransactions;

extern void LogAccessExclusiveLock(Oid dbOid, Oid relOid);
extern void LogAccessExclusiveLockPrepare(void);

extern void LogStandbySnapshot(void);
# 70 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/acl.h" 1
# 27 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/acl.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 1
# 28 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/acl.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h" 1
# 59 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h"
# 1 "./fmgr.h" 1
# 60 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h" 2
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h"
typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
} ArrayType;




typedef struct ArrayBuildState
{
 MemoryContext mcontext;
 Datum *dvalues;
 bool *dnulls;
 int alen;
 int nelems;
 Oid element_type;
 int16 typlen;
 bool typbyval;
 char typalign;
} ArrayBuildState;




typedef struct ArrayMetaState
{
 Oid element_type;
 int16 typlen;
 bool typbyval;
 char typalign;
 char typdelim;
 Oid typioparam;
 Oid typiofunc;
 FmgrInfo proc;
} ArrayMetaState;




typedef struct ArrayMapState
{
 ArrayMetaState inp_extra;
 ArrayMetaState ret_extra;
} ArrayMapState;


typedef struct ArrayIteratorData *ArrayIterator;
# 182 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h"
extern bool Array_nulls;




extern Datum array_in(FunctionCallInfo fcinfo);
extern Datum array_out(FunctionCallInfo fcinfo);
extern Datum array_recv(FunctionCallInfo fcinfo);
extern Datum array_send(FunctionCallInfo fcinfo);
extern Datum array_eq(FunctionCallInfo fcinfo);
extern Datum array_ne(FunctionCallInfo fcinfo);
extern Datum array_lt(FunctionCallInfo fcinfo);
extern Datum array_gt(FunctionCallInfo fcinfo);
extern Datum array_le(FunctionCallInfo fcinfo);
extern Datum array_ge(FunctionCallInfo fcinfo);
extern Datum btarraycmp(FunctionCallInfo fcinfo);
extern Datum hash_array(FunctionCallInfo fcinfo);
extern Datum arrayoverlap(FunctionCallInfo fcinfo);
extern Datum arraycontains(FunctionCallInfo fcinfo);
extern Datum arraycontained(FunctionCallInfo fcinfo);
extern Datum array_ndims(FunctionCallInfo fcinfo);
extern Datum array_dims(FunctionCallInfo fcinfo);
extern Datum array_lower(FunctionCallInfo fcinfo);
extern Datum array_upper(FunctionCallInfo fcinfo);
extern Datum array_length(FunctionCallInfo fcinfo);
extern Datum array_larger(FunctionCallInfo fcinfo);
extern Datum array_smaller(FunctionCallInfo fcinfo);
extern Datum generate_subscripts(FunctionCallInfo fcinfo);
extern Datum generate_subscripts_nodir(FunctionCallInfo fcinfo);
extern Datum array_fill(FunctionCallInfo fcinfo);
extern Datum array_fill_with_lower_bounds(FunctionCallInfo fcinfo);
extern Datum array_unnest(FunctionCallInfo fcinfo);

extern Datum array_ref(ArrayType *array, int nSubscripts, int *indx,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign,
    bool *isNull);
extern ArrayType *array_set(ArrayType *array, int nSubscripts, int *indx,
    Datum dataValue, bool isNull,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign);
extern ArrayType *array_get_slice(ArrayType *array, int nSubscripts,
    int *upperIndx, int *lowerIndx,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign);
extern ArrayType *array_set_slice(ArrayType *array, int nSubscripts,
    int *upperIndx, int *lowerIndx,
    ArrayType *srcArray, bool isNull,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign);

extern Datum array_map(FunctionCallInfo fcinfo, Oid inpType, Oid retType,
    ArrayMapState *amstate);

extern void array_bitmap_copy(bits8 *destbitmap, int destoffset,
      const bits8 *srcbitmap, int srcoffset,
      int nitems);

extern ArrayType *construct_array(Datum *elems, int nelems,
    Oid elmtype,
    int elmlen, bool elmbyval, char elmalign);
extern ArrayType *construct_md_array(Datum *elems,
       bool *nulls,
       int ndims,
       int *dims,
       int *lbs,
       Oid elmtype, int elmlen, bool elmbyval, char elmalign);
extern ArrayType *construct_empty_array(Oid elmtype);
extern void deconstruct_array(ArrayType *array,
      Oid elmtype,
      int elmlen, bool elmbyval, char elmalign,
      Datum **elemsp, bool **nullsp, int *nelemsp);
extern bool array_contains_nulls(ArrayType *array);
extern ArrayBuildState *accumArrayResult(ArrayBuildState *astate,
     Datum dvalue, bool disnull,
     Oid element_type,
     MemoryContext rcontext);
extern Datum makeArrayResult(ArrayBuildState *astate,
    MemoryContext rcontext);
extern Datum makeMdArrayResult(ArrayBuildState *astate, int ndims,
      int *dims, int *lbs, MemoryContext rcontext, bool release);

extern ArrayIterator array_create_iterator(ArrayType *arr, int slice_ndim);
extern bool array_iterate(ArrayIterator iterator, Datum *value, bool *isnull);
extern void array_free_iterator(ArrayIterator iterator);





extern int ArrayGetOffset(int n, const int *dim, const int *lb, const int *indx);
extern int ArrayGetOffset0(int n, const int *tup, const int *scale);
extern int ArrayGetNItems(int ndim, const int *dims);
extern void mda_get_range(int n, int *span, const int *st, const int *endp);
extern void mda_get_prod(int n, const int *range, int *prod);
extern void mda_get_offset_values(int n, int *dist, const int *prod, const int *span);
extern int mda_next_tuple(int n, int *curr, const int *span);
extern int32 *ArrayGetIntegerTypmods(ArrayType *arr, int *n);




extern Datum array_push(FunctionCallInfo fcinfo);
extern Datum array_cat(FunctionCallInfo fcinfo);

extern ArrayType *create_singleton_array(FunctionCallInfo fcinfo,
        Oid element_type,
        Datum element,
        bool isNull,
        int ndims);

extern Datum array_agg_transfn(FunctionCallInfo fcinfo);
extern Datum array_agg_finalfn(FunctionCallInfo fcinfo);




extern Datum array_typanalyze(FunctionCallInfo fcinfo);
# 29 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/acl.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h" 1
# 30 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/acl.h" 2
# 45 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/acl.h"
typedef struct AclItem
{
 Oid ai_grantee;
 Oid ai_grantor;
 AclMode ai_privs;
} AclItem;
# 97 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/acl.h"
typedef ArrayType Acl;
# 161 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/acl.h"
typedef enum
{
 ACLMASK_ALL,
 ACLMASK_ANY
} AclMaskHow;


typedef enum
{
 ACLCHECK_OK = 0,
 ACLCHECK_NO_PRIV,
 ACLCHECK_NOT_OWNER
} AclResult;



typedef enum AclObjectKind
{
 ACL_KIND_COLUMN,
 ACL_KIND_CLASS,
 ACL_KIND_SEQUENCE,
 ACL_KIND_DATABASE,
 ACL_KIND_PROC,
 ACL_KIND_OPER,
 ACL_KIND_TYPE,
 ACL_KIND_LANGUAGE,
 ACL_KIND_LARGEOBJECT,
 ACL_KIND_NAMESPACE,
 ACL_KIND_OPCLASS,
 ACL_KIND_OPFAMILY,
 ACL_KIND_COLLATION,
 ACL_KIND_CONVERSION,
 ACL_KIND_TABLESPACE,
 ACL_KIND_TSDICTIONARY,
 ACL_KIND_TSCONFIGURATION,
 ACL_KIND_FDW,
 ACL_KIND_FOREIGN_SERVER,
 ACL_KIND_EXTENSION,
 MAX_ACL_KIND
} AclObjectKind;





extern Acl *acldefault(GrantObjectType objtype, Oid ownerId);
extern Acl *get_user_default_acl(GrantObjectType objtype, Oid ownerId,
      Oid nsp_oid);

extern Acl *aclupdate(const Acl *old_acl, const AclItem *mod_aip,
    int modechg, Oid ownerId, DropBehavior behavior);
extern Acl *aclnewowner(const Acl *old_acl, Oid oldOwnerId, Oid newOwnerId);
extern Acl *make_empty_acl(void);
extern Acl *aclcopy(const Acl *orig_acl);
extern Acl *aclconcat(const Acl *left_acl, const Acl *right_acl);
extern Acl *aclmerge(const Acl *left_acl, const Acl *right_acl, Oid ownerId);
extern void aclitemsort(Acl *acl);
extern bool aclequal(const Acl *left_acl, const Acl *right_acl);

extern AclMode aclmask(const Acl *acl, Oid roleid, Oid ownerId,
  AclMode mask, AclMaskHow how);
extern int aclmembers(const Acl *acl, Oid **roleids);

extern bool has_privs_of_role(Oid member, Oid role);
extern bool is_member_of_role(Oid member, Oid role);
extern bool is_member_of_role_nosuper(Oid member, Oid role);
extern bool is_admin_of_role(Oid member, Oid role);
extern void check_is_member_of_role(Oid member, Oid role);
extern Oid get_role_oid(const char *rolname, bool missing_ok);

extern void select_best_grantor(Oid roleId, AclMode privileges,
     const Acl *acl, Oid ownerId,
     Oid *grantorId, AclMode *grantOptions);

extern void initialize_acl(void);




extern Datum aclitemin(FunctionCallInfo fcinfo);
extern Datum aclitemout(FunctionCallInfo fcinfo);
extern Datum aclinsert(FunctionCallInfo fcinfo);
extern Datum aclremove(FunctionCallInfo fcinfo);
extern Datum aclcontains(FunctionCallInfo fcinfo);
extern Datum makeaclitem(FunctionCallInfo fcinfo);
extern Datum aclitem_eq(FunctionCallInfo fcinfo);
extern Datum hash_aclitem(FunctionCallInfo fcinfo);
extern Datum acldefault_sql(FunctionCallInfo fcinfo);
extern Datum aclexplode(FunctionCallInfo fcinfo);




extern void ExecuteGrantStmt(GrantStmt *stmt);
extern void ExecAlterDefaultPrivilegesStmt(AlterDefaultPrivilegesStmt *stmt);

extern void RemoveRoleFromObjectACL(Oid roleid, Oid classid, Oid objid);
extern void RemoveDefaultACLById(Oid defaclOid);

extern AclMode pg_attribute_aclmask(Oid table_oid, AttrNumber attnum,
      Oid roleid, AclMode mask, AclMaskHow how);
extern AclMode pg_class_aclmask(Oid table_oid, Oid roleid,
     AclMode mask, AclMaskHow how);
extern AclMode pg_database_aclmask(Oid db_oid, Oid roleid,
     AclMode mask, AclMaskHow how);
extern AclMode pg_proc_aclmask(Oid proc_oid, Oid roleid,
    AclMode mask, AclMaskHow how);
extern AclMode pg_language_aclmask(Oid lang_oid, Oid roleid,
     AclMode mask, AclMaskHow how);
extern AclMode pg_largeobject_aclmask_snapshot(Oid lobj_oid, Oid roleid,
       AclMode mask, AclMaskHow how, Snapshot snapshot);
extern AclMode pg_namespace_aclmask(Oid nsp_oid, Oid roleid,
      AclMode mask, AclMaskHow how);
extern AclMode pg_tablespace_aclmask(Oid spc_oid, Oid roleid,
       AclMode mask, AclMaskHow how);
extern AclMode pg_foreign_data_wrapper_aclmask(Oid fdw_oid, Oid roleid,
        AclMode mask, AclMaskHow how);
extern AclMode pg_foreign_server_aclmask(Oid srv_oid, Oid roleid,
        AclMode mask, AclMaskHow how);
extern AclMode pg_type_aclmask(Oid type_oid, Oid roleid,
    AclMode mask, AclMaskHow how);

extern AclResult pg_attribute_aclcheck(Oid table_oid, AttrNumber attnum,
       Oid roleid, AclMode mode);
extern AclResult pg_attribute_aclcheck_all(Oid table_oid, Oid roleid,
        AclMode mode, AclMaskHow how);
extern AclResult pg_class_aclcheck(Oid table_oid, Oid roleid, AclMode mode);
extern AclResult pg_database_aclcheck(Oid db_oid, Oid roleid, AclMode mode);
extern AclResult pg_proc_aclcheck(Oid proc_oid, Oid roleid, AclMode mode);
extern AclResult pg_language_aclcheck(Oid lang_oid, Oid roleid, AclMode mode);
extern AclResult pg_largeobject_aclcheck_snapshot(Oid lang_oid, Oid roleid,
         AclMode mode, Snapshot snapshot);
extern AclResult pg_namespace_aclcheck(Oid nsp_oid, Oid roleid, AclMode mode);
extern AclResult pg_tablespace_aclcheck(Oid spc_oid, Oid roleid, AclMode mode);
extern AclResult pg_foreign_data_wrapper_aclcheck(Oid fdw_oid, Oid roleid, AclMode mode);
extern AclResult pg_foreign_server_aclcheck(Oid srv_oid, Oid roleid, AclMode mode);
extern AclResult pg_type_aclcheck(Oid type_oid, Oid roleid, AclMode mode);

extern void aclcheck_error(AclResult aclerr, AclObjectKind objectkind,
      const char *objectname);

extern void aclcheck_error_col(AclResult aclerr, AclObjectKind objectkind,
       const char *objectname, const char *colname);

extern void aclcheck_error_type(AclResult aclerr, Oid typeOid);


extern bool pg_class_ownercheck(Oid class_oid, Oid roleid);
extern bool pg_type_ownercheck(Oid type_oid, Oid roleid);
extern bool pg_oper_ownercheck(Oid oper_oid, Oid roleid);
extern bool pg_proc_ownercheck(Oid proc_oid, Oid roleid);
extern bool pg_language_ownercheck(Oid lan_oid, Oid roleid);
extern bool pg_largeobject_ownercheck(Oid lobj_oid, Oid roleid);
extern bool pg_namespace_ownercheck(Oid nsp_oid, Oid roleid);
extern bool pg_tablespace_ownercheck(Oid spc_oid, Oid roleid);
extern bool pg_opclass_ownercheck(Oid opc_oid, Oid roleid);
extern bool pg_opfamily_ownercheck(Oid opf_oid, Oid roleid);
extern bool pg_database_ownercheck(Oid db_oid, Oid roleid);
extern bool pg_collation_ownercheck(Oid coll_oid, Oid roleid);
extern bool pg_conversion_ownercheck(Oid conv_oid, Oid roleid);
extern bool pg_ts_dict_ownercheck(Oid dict_oid, Oid roleid);
extern bool pg_ts_config_ownercheck(Oid cfg_oid, Oid roleid);
extern bool pg_foreign_data_wrapper_ownercheck(Oid srv_oid, Oid roleid);
extern bool pg_foreign_server_ownercheck(Oid srv_oid, Oid roleid);
extern bool pg_extension_ownercheck(Oid ext_oid, Oid roleid);
extern bool has_createrole_privilege(Oid roleid);
# 71 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/builtins.h" 1
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/builtins.h"
extern Datum has_any_column_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_any_column_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_any_column_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_any_column_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_any_column_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_any_column_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_name_name_name(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_name_name_attnum(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_name_id_name(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_name_id_attnum(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_id_name_name(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_id_name_attnum(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_id_id_name(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_id_id_attnum(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_name_attnum(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_id_attnum(FunctionCallInfo fcinfo);
extern Datum has_table_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_table_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_table_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_table_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_table_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_table_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_sequence_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_sequence_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_sequence_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_sequence_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_sequence_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_sequence_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_database_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_database_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_database_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_database_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_database_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_database_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_foreign_data_wrapper_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_foreign_data_wrapper_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_foreign_data_wrapper_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_foreign_data_wrapper_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_foreign_data_wrapper_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_foreign_data_wrapper_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_function_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_function_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_function_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_function_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_function_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_function_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_language_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_language_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_language_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_language_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_language_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_language_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_schema_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_schema_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_schema_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_schema_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_schema_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_schema_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_server_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_server_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_server_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_server_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_server_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_server_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_tablespace_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_tablespace_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_tablespace_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_tablespace_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_tablespace_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_tablespace_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_type_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_type_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_type_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_type_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_type_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_type_privilege_id(FunctionCallInfo fcinfo);
extern Datum pg_has_role_name_name(FunctionCallInfo fcinfo);
extern Datum pg_has_role_name_id(FunctionCallInfo fcinfo);
extern Datum pg_has_role_id_name(FunctionCallInfo fcinfo);
extern Datum pg_has_role_id_id(FunctionCallInfo fcinfo);
extern Datum pg_has_role_name(FunctionCallInfo fcinfo);
extern Datum pg_has_role_id(FunctionCallInfo fcinfo);


extern Datum boolin(FunctionCallInfo fcinfo);
extern Datum boolout(FunctionCallInfo fcinfo);
extern Datum boolrecv(FunctionCallInfo fcinfo);
extern Datum boolsend(FunctionCallInfo fcinfo);
extern Datum booltext(FunctionCallInfo fcinfo);
extern Datum booleq(FunctionCallInfo fcinfo);
extern Datum boolne(FunctionCallInfo fcinfo);
extern Datum boollt(FunctionCallInfo fcinfo);
extern Datum boolgt(FunctionCallInfo fcinfo);
extern Datum boolle(FunctionCallInfo fcinfo);
extern Datum boolge(FunctionCallInfo fcinfo);
extern Datum booland_statefunc(FunctionCallInfo fcinfo);
extern Datum boolor_statefunc(FunctionCallInfo fcinfo);
extern bool parse_bool(const char *value, bool *result);
extern bool parse_bool_with_len(const char *value, size_t len, bool *result);


extern Datum charin(FunctionCallInfo fcinfo);
extern Datum charout(FunctionCallInfo fcinfo);
extern Datum charrecv(FunctionCallInfo fcinfo);
extern Datum charsend(FunctionCallInfo fcinfo);
extern Datum chareq(FunctionCallInfo fcinfo);
extern Datum charne(FunctionCallInfo fcinfo);
extern Datum charlt(FunctionCallInfo fcinfo);
extern Datum charle(FunctionCallInfo fcinfo);
extern Datum chargt(FunctionCallInfo fcinfo);
extern Datum charge(FunctionCallInfo fcinfo);
extern Datum chartoi4(FunctionCallInfo fcinfo);
extern Datum i4tochar(FunctionCallInfo fcinfo);
extern Datum text_char(FunctionCallInfo fcinfo);
extern Datum char_text(FunctionCallInfo fcinfo);


extern Datum domain_in(FunctionCallInfo fcinfo);
extern Datum domain_recv(FunctionCallInfo fcinfo);
extern void domain_check(Datum value, bool isnull, Oid domainType, void **extra, MemoryContext mcxt);


extern Datum binary_encode(FunctionCallInfo fcinfo);
extern Datum binary_decode(FunctionCallInfo fcinfo);
extern unsigned hex_encode(const char *src, unsigned len, char *dst);
extern unsigned hex_decode(const char *src, unsigned len, char *dst);


extern Datum enum_in(FunctionCallInfo fcinfo);
extern Datum enum_out(FunctionCallInfo fcinfo);
extern Datum enum_recv(FunctionCallInfo fcinfo);
extern Datum enum_send(FunctionCallInfo fcinfo);
extern Datum enum_lt(FunctionCallInfo fcinfo);
extern Datum enum_le(FunctionCallInfo fcinfo);
extern Datum enum_eq(FunctionCallInfo fcinfo);
extern Datum enum_ne(FunctionCallInfo fcinfo);
extern Datum enum_ge(FunctionCallInfo fcinfo);
extern Datum enum_gt(FunctionCallInfo fcinfo);
extern Datum enum_cmp(FunctionCallInfo fcinfo);
extern Datum enum_smaller(FunctionCallInfo fcinfo);
extern Datum enum_larger(FunctionCallInfo fcinfo);
extern Datum enum_first(FunctionCallInfo fcinfo);
extern Datum enum_last(FunctionCallInfo fcinfo);
extern Datum enum_range_bounds(FunctionCallInfo fcinfo);
extern Datum enum_range_all(FunctionCallInfo fcinfo);


extern Datum int2in(FunctionCallInfo fcinfo);
extern Datum int2out(FunctionCallInfo fcinfo);
extern Datum int2recv(FunctionCallInfo fcinfo);
extern Datum int2send(FunctionCallInfo fcinfo);
extern Datum int2vectorin(FunctionCallInfo fcinfo);
extern Datum int2vectorout(FunctionCallInfo fcinfo);
extern Datum int2vectorrecv(FunctionCallInfo fcinfo);
extern Datum int2vectorsend(FunctionCallInfo fcinfo);
extern Datum int2vectoreq(FunctionCallInfo fcinfo);
extern Datum int4in(FunctionCallInfo fcinfo);
extern Datum int4out(FunctionCallInfo fcinfo);
extern Datum int4recv(FunctionCallInfo fcinfo);
extern Datum int4send(FunctionCallInfo fcinfo);
extern Datum i2toi4(FunctionCallInfo fcinfo);
extern Datum i4toi2(FunctionCallInfo fcinfo);
extern Datum int4_bool(FunctionCallInfo fcinfo);
extern Datum bool_int4(FunctionCallInfo fcinfo);
extern Datum int4eq(FunctionCallInfo fcinfo);
extern Datum int4ne(FunctionCallInfo fcinfo);
extern Datum int4lt(FunctionCallInfo fcinfo);
extern Datum int4le(FunctionCallInfo fcinfo);
extern Datum int4gt(FunctionCallInfo fcinfo);
extern Datum int4ge(FunctionCallInfo fcinfo);
extern Datum int2eq(FunctionCallInfo fcinfo);
extern Datum int2ne(FunctionCallInfo fcinfo);
extern Datum int2lt(FunctionCallInfo fcinfo);
extern Datum int2le(FunctionCallInfo fcinfo);
extern Datum int2gt(FunctionCallInfo fcinfo);
extern Datum int2ge(FunctionCallInfo fcinfo);
extern Datum int24eq(FunctionCallInfo fcinfo);
extern Datum int24ne(FunctionCallInfo fcinfo);
extern Datum int24lt(FunctionCallInfo fcinfo);
extern Datum int24le(FunctionCallInfo fcinfo);
extern Datum int24gt(FunctionCallInfo fcinfo);
extern Datum int24ge(FunctionCallInfo fcinfo);
extern Datum int42eq(FunctionCallInfo fcinfo);
extern Datum int42ne(FunctionCallInfo fcinfo);
extern Datum int42lt(FunctionCallInfo fcinfo);
extern Datum int42le(FunctionCallInfo fcinfo);
extern Datum int42gt(FunctionCallInfo fcinfo);
extern Datum int42ge(FunctionCallInfo fcinfo);
extern Datum int4um(FunctionCallInfo fcinfo);
extern Datum int4up(FunctionCallInfo fcinfo);
extern Datum int4pl(FunctionCallInfo fcinfo);
extern Datum int4mi(FunctionCallInfo fcinfo);
extern Datum int4mul(FunctionCallInfo fcinfo);
extern Datum int4div(FunctionCallInfo fcinfo);
extern Datum int4abs(FunctionCallInfo fcinfo);
extern Datum int4inc(FunctionCallInfo fcinfo);
extern Datum int2um(FunctionCallInfo fcinfo);
extern Datum int2up(FunctionCallInfo fcinfo);
extern Datum int2pl(FunctionCallInfo fcinfo);
extern Datum int2mi(FunctionCallInfo fcinfo);
extern Datum int2mul(FunctionCallInfo fcinfo);
extern Datum int2div(FunctionCallInfo fcinfo);
extern Datum int2abs(FunctionCallInfo fcinfo);
extern Datum int24pl(FunctionCallInfo fcinfo);
extern Datum int24mi(FunctionCallInfo fcinfo);
extern Datum int24mul(FunctionCallInfo fcinfo);
extern Datum int24div(FunctionCallInfo fcinfo);
extern Datum int42pl(FunctionCallInfo fcinfo);
extern Datum int42mi(FunctionCallInfo fcinfo);
extern Datum int42mul(FunctionCallInfo fcinfo);
extern Datum int42div(FunctionCallInfo fcinfo);
extern Datum int4mod(FunctionCallInfo fcinfo);
extern Datum int2mod(FunctionCallInfo fcinfo);
extern Datum int2larger(FunctionCallInfo fcinfo);
extern Datum int2smaller(FunctionCallInfo fcinfo);
extern Datum int4larger(FunctionCallInfo fcinfo);
extern Datum int4smaller(FunctionCallInfo fcinfo);

extern Datum int4and(FunctionCallInfo fcinfo);
extern Datum int4or(FunctionCallInfo fcinfo);
extern Datum int4xor(FunctionCallInfo fcinfo);
extern Datum int4not(FunctionCallInfo fcinfo);
extern Datum int4shl(FunctionCallInfo fcinfo);
extern Datum int4shr(FunctionCallInfo fcinfo);
extern Datum int2and(FunctionCallInfo fcinfo);
extern Datum int2or(FunctionCallInfo fcinfo);
extern Datum int2xor(FunctionCallInfo fcinfo);
extern Datum int2not(FunctionCallInfo fcinfo);
extern Datum int2shl(FunctionCallInfo fcinfo);
extern Datum int2shr(FunctionCallInfo fcinfo);
extern Datum generate_series_int4(FunctionCallInfo fcinfo);
extern Datum generate_series_step_int4(FunctionCallInfo fcinfo);
extern int2vector *buildint2vector(const int2 *int2s, int n);


extern Datum namein(FunctionCallInfo fcinfo);
extern Datum nameout(FunctionCallInfo fcinfo);
extern Datum namerecv(FunctionCallInfo fcinfo);
extern Datum namesend(FunctionCallInfo fcinfo);
extern Datum nameeq(FunctionCallInfo fcinfo);
extern Datum namene(FunctionCallInfo fcinfo);
extern Datum namelt(FunctionCallInfo fcinfo);
extern Datum namele(FunctionCallInfo fcinfo);
extern Datum namegt(FunctionCallInfo fcinfo);
extern Datum namege(FunctionCallInfo fcinfo);
extern int namecpy(Name n1, Name n2);
extern int namestrcpy(Name name, const char *str);
extern int namestrcmp(Name name, const char *str);
extern Datum current_user(FunctionCallInfo fcinfo);
extern Datum session_user(FunctionCallInfo fcinfo);
extern Datum current_schema(FunctionCallInfo fcinfo);
extern Datum current_schemas(FunctionCallInfo fcinfo);


extern int32 pg_atoi(char *s, int size, int c);
extern void pg_itoa(int16 i, char *a);
extern void pg_ltoa(int32 l, char *a);
extern void pg_lltoa(int64 ll, char *a);





extern Datum btboolcmp(FunctionCallInfo fcinfo);
extern Datum btint2cmp(FunctionCallInfo fcinfo);
extern Datum btint4cmp(FunctionCallInfo fcinfo);
extern Datum btint8cmp(FunctionCallInfo fcinfo);
extern Datum btfloat4cmp(FunctionCallInfo fcinfo);
extern Datum btfloat8cmp(FunctionCallInfo fcinfo);
extern Datum btint48cmp(FunctionCallInfo fcinfo);
extern Datum btint84cmp(FunctionCallInfo fcinfo);
extern Datum btint24cmp(FunctionCallInfo fcinfo);
extern Datum btint42cmp(FunctionCallInfo fcinfo);
extern Datum btint28cmp(FunctionCallInfo fcinfo);
extern Datum btint82cmp(FunctionCallInfo fcinfo);
extern Datum btfloat48cmp(FunctionCallInfo fcinfo);
extern Datum btfloat84cmp(FunctionCallInfo fcinfo);
extern Datum btoidcmp(FunctionCallInfo fcinfo);
extern Datum btoidvectorcmp(FunctionCallInfo fcinfo);
extern Datum btabstimecmp(FunctionCallInfo fcinfo);
extern Datum btreltimecmp(FunctionCallInfo fcinfo);
extern Datum bttintervalcmp(FunctionCallInfo fcinfo);
extern Datum btcharcmp(FunctionCallInfo fcinfo);
extern Datum btnamecmp(FunctionCallInfo fcinfo);
extern Datum bttextcmp(FunctionCallInfo fcinfo);






extern Datum btint2sortsupport(FunctionCallInfo fcinfo);
extern Datum btint4sortsupport(FunctionCallInfo fcinfo);
extern Datum btint8sortsupport(FunctionCallInfo fcinfo);
extern Datum btfloat4sortsupport(FunctionCallInfo fcinfo);
extern Datum btfloat8sortsupport(FunctionCallInfo fcinfo);
extern Datum btoidsortsupport(FunctionCallInfo fcinfo);
extern Datum btnamesortsupport(FunctionCallInfo fcinfo);


extern int extra_float_digits;

extern double get_float8_infinity(void);
extern float get_float4_infinity(void);
extern double get_float8_nan(void);
extern float get_float4_nan(void);
extern int is_infinite(double val);

extern Datum float4in(FunctionCallInfo fcinfo);
extern Datum float4out(FunctionCallInfo fcinfo);
extern Datum float4recv(FunctionCallInfo fcinfo);
extern Datum float4send(FunctionCallInfo fcinfo);
extern Datum float8in(FunctionCallInfo fcinfo);
extern Datum float8out(FunctionCallInfo fcinfo);
extern Datum float8recv(FunctionCallInfo fcinfo);
extern Datum float8send(FunctionCallInfo fcinfo);
extern Datum float4abs(FunctionCallInfo fcinfo);
extern Datum float4um(FunctionCallInfo fcinfo);
extern Datum float4up(FunctionCallInfo fcinfo);
extern Datum float4larger(FunctionCallInfo fcinfo);
extern Datum float4smaller(FunctionCallInfo fcinfo);
extern Datum float8abs(FunctionCallInfo fcinfo);
extern Datum float8um(FunctionCallInfo fcinfo);
extern Datum float8up(FunctionCallInfo fcinfo);
extern Datum float8larger(FunctionCallInfo fcinfo);
extern Datum float8smaller(FunctionCallInfo fcinfo);
extern Datum float4pl(FunctionCallInfo fcinfo);
extern Datum float4mi(FunctionCallInfo fcinfo);
extern Datum float4mul(FunctionCallInfo fcinfo);
extern Datum float4div(FunctionCallInfo fcinfo);
extern Datum float8pl(FunctionCallInfo fcinfo);
extern Datum float8mi(FunctionCallInfo fcinfo);
extern Datum float8mul(FunctionCallInfo fcinfo);
extern Datum float8div(FunctionCallInfo fcinfo);
extern Datum float4eq(FunctionCallInfo fcinfo);
extern Datum float4ne(FunctionCallInfo fcinfo);
extern Datum float4lt(FunctionCallInfo fcinfo);
extern Datum float4le(FunctionCallInfo fcinfo);
extern Datum float4gt(FunctionCallInfo fcinfo);
extern Datum float4ge(FunctionCallInfo fcinfo);
extern Datum float8eq(FunctionCallInfo fcinfo);
extern Datum float8ne(FunctionCallInfo fcinfo);
extern Datum float8lt(FunctionCallInfo fcinfo);
extern Datum float8le(FunctionCallInfo fcinfo);
extern Datum float8gt(FunctionCallInfo fcinfo);
extern Datum float8ge(FunctionCallInfo fcinfo);
extern Datum ftod(FunctionCallInfo fcinfo);
extern Datum i4tod(FunctionCallInfo fcinfo);
extern Datum i2tod(FunctionCallInfo fcinfo);
extern Datum dtof(FunctionCallInfo fcinfo);
extern Datum dtoi4(FunctionCallInfo fcinfo);
extern Datum dtoi2(FunctionCallInfo fcinfo);
extern Datum i4tof(FunctionCallInfo fcinfo);
extern Datum i2tof(FunctionCallInfo fcinfo);
extern Datum ftoi4(FunctionCallInfo fcinfo);
extern Datum ftoi2(FunctionCallInfo fcinfo);
extern Datum dround(FunctionCallInfo fcinfo);
extern Datum dceil(FunctionCallInfo fcinfo);
extern Datum dfloor(FunctionCallInfo fcinfo);
extern Datum dsign(FunctionCallInfo fcinfo);
extern Datum dtrunc(FunctionCallInfo fcinfo);
extern Datum dsqrt(FunctionCallInfo fcinfo);
extern Datum dcbrt(FunctionCallInfo fcinfo);
extern Datum dpow(FunctionCallInfo fcinfo);
extern Datum dexp(FunctionCallInfo fcinfo);
extern Datum dlog1(FunctionCallInfo fcinfo);
extern Datum dlog10(FunctionCallInfo fcinfo);
extern Datum dacos(FunctionCallInfo fcinfo);
extern Datum dasin(FunctionCallInfo fcinfo);
extern Datum datan(FunctionCallInfo fcinfo);
extern Datum datan2(FunctionCallInfo fcinfo);
extern Datum dcos(FunctionCallInfo fcinfo);
extern Datum dcot(FunctionCallInfo fcinfo);
extern Datum dsin(FunctionCallInfo fcinfo);
extern Datum dtan(FunctionCallInfo fcinfo);
extern Datum degrees(FunctionCallInfo fcinfo);
extern Datum dpi(FunctionCallInfo fcinfo);
extern Datum radians(FunctionCallInfo fcinfo);
extern Datum drandom(FunctionCallInfo fcinfo);
extern Datum setseed(FunctionCallInfo fcinfo);
extern Datum float8_accum(FunctionCallInfo fcinfo);
extern Datum float4_accum(FunctionCallInfo fcinfo);
extern Datum float8_avg(FunctionCallInfo fcinfo);
extern Datum float8_var_pop(FunctionCallInfo fcinfo);
extern Datum float8_var_samp(FunctionCallInfo fcinfo);
extern Datum float8_stddev_pop(FunctionCallInfo fcinfo);
extern Datum float8_stddev_samp(FunctionCallInfo fcinfo);
extern Datum float8_regr_accum(FunctionCallInfo fcinfo);
extern Datum float8_regr_sxx(FunctionCallInfo fcinfo);
extern Datum float8_regr_syy(FunctionCallInfo fcinfo);
extern Datum float8_regr_sxy(FunctionCallInfo fcinfo);
extern Datum float8_regr_avgx(FunctionCallInfo fcinfo);
extern Datum float8_regr_avgy(FunctionCallInfo fcinfo);
extern Datum float8_covar_pop(FunctionCallInfo fcinfo);
extern Datum float8_covar_samp(FunctionCallInfo fcinfo);
extern Datum float8_corr(FunctionCallInfo fcinfo);
extern Datum float8_regr_r2(FunctionCallInfo fcinfo);
extern Datum float8_regr_slope(FunctionCallInfo fcinfo);
extern Datum float8_regr_intercept(FunctionCallInfo fcinfo);
extern Datum float48pl(FunctionCallInfo fcinfo);
extern Datum float48mi(FunctionCallInfo fcinfo);
extern Datum float48mul(FunctionCallInfo fcinfo);
extern Datum float48div(FunctionCallInfo fcinfo);
extern Datum float84pl(FunctionCallInfo fcinfo);
extern Datum float84mi(FunctionCallInfo fcinfo);
extern Datum float84mul(FunctionCallInfo fcinfo);
extern Datum float84div(FunctionCallInfo fcinfo);
extern Datum float48eq(FunctionCallInfo fcinfo);
extern Datum float48ne(FunctionCallInfo fcinfo);
extern Datum float48lt(FunctionCallInfo fcinfo);
extern Datum float48le(FunctionCallInfo fcinfo);
extern Datum float48gt(FunctionCallInfo fcinfo);
extern Datum float48ge(FunctionCallInfo fcinfo);
extern Datum float84eq(FunctionCallInfo fcinfo);
extern Datum float84ne(FunctionCallInfo fcinfo);
extern Datum float84lt(FunctionCallInfo fcinfo);
extern Datum float84le(FunctionCallInfo fcinfo);
extern Datum float84gt(FunctionCallInfo fcinfo);
extern Datum float84ge(FunctionCallInfo fcinfo);
extern Datum width_bucket_float8(FunctionCallInfo fcinfo);


extern Datum pg_tablespace_size_oid(FunctionCallInfo fcinfo);
extern Datum pg_tablespace_size_name(FunctionCallInfo fcinfo);
extern Datum pg_database_size_oid(FunctionCallInfo fcinfo);
extern Datum pg_database_size_name(FunctionCallInfo fcinfo);
extern Datum pg_relation_size(FunctionCallInfo fcinfo);
extern Datum pg_total_relation_size(FunctionCallInfo fcinfo);
extern Datum pg_size_pretty(FunctionCallInfo fcinfo);
extern Datum pg_size_pretty_numeric(FunctionCallInfo fcinfo);
extern Datum pg_table_size(FunctionCallInfo fcinfo);
extern Datum pg_indexes_size(FunctionCallInfo fcinfo);
extern Datum pg_relation_filenode(FunctionCallInfo fcinfo);
extern Datum pg_relation_filepath(FunctionCallInfo fcinfo);


extern bytea *read_binary_file(const char *filename,
     int64 seek_offset, int64 bytes_to_read);
extern Datum pg_stat_file(FunctionCallInfo fcinfo);
extern Datum pg_read_file(FunctionCallInfo fcinfo);
extern Datum pg_read_file_all(FunctionCallInfo fcinfo);
extern Datum pg_read_binary_file(FunctionCallInfo fcinfo);
extern Datum pg_read_binary_file_all(FunctionCallInfo fcinfo);
extern Datum pg_ls_dir(FunctionCallInfo fcinfo);


extern Datum current_database(FunctionCallInfo fcinfo);
extern Datum current_query(FunctionCallInfo fcinfo);
extern Datum pg_cancel_backend(FunctionCallInfo fcinfo);
extern Datum pg_terminate_backend(FunctionCallInfo fcinfo);
extern Datum pg_reload_conf(FunctionCallInfo fcinfo);
extern Datum pg_tablespace_databases(FunctionCallInfo fcinfo);
extern Datum pg_tablespace_location(FunctionCallInfo fcinfo);
extern Datum pg_rotate_logfile(FunctionCallInfo fcinfo);
extern Datum pg_sleep(FunctionCallInfo fcinfo);
extern Datum pg_get_keywords(FunctionCallInfo fcinfo);
extern Datum pg_typeof(FunctionCallInfo fcinfo);
extern Datum pg_collation_for(FunctionCallInfo fcinfo);


extern Datum oidin(FunctionCallInfo fcinfo);
extern Datum oidout(FunctionCallInfo fcinfo);
extern Datum oidrecv(FunctionCallInfo fcinfo);
extern Datum oidsend(FunctionCallInfo fcinfo);
extern Datum oideq(FunctionCallInfo fcinfo);
extern Datum oidne(FunctionCallInfo fcinfo);
extern Datum oidlt(FunctionCallInfo fcinfo);
extern Datum oidle(FunctionCallInfo fcinfo);
extern Datum oidge(FunctionCallInfo fcinfo);
extern Datum oidgt(FunctionCallInfo fcinfo);
extern Datum oidlarger(FunctionCallInfo fcinfo);
extern Datum oidsmaller(FunctionCallInfo fcinfo);
extern Datum oidvectorin(FunctionCallInfo fcinfo);
extern Datum oidvectorout(FunctionCallInfo fcinfo);
extern Datum oidvectorrecv(FunctionCallInfo fcinfo);
extern Datum oidvectorsend(FunctionCallInfo fcinfo);
extern Datum oidvectoreq(FunctionCallInfo fcinfo);
extern Datum oidvectorne(FunctionCallInfo fcinfo);
extern Datum oidvectorlt(FunctionCallInfo fcinfo);
extern Datum oidvectorle(FunctionCallInfo fcinfo);
extern Datum oidvectorge(FunctionCallInfo fcinfo);
extern Datum oidvectorgt(FunctionCallInfo fcinfo);
extern oidvector *buildoidvector(const Oid *oids, int n);
extern Oid oidparse(Node *node);


extern Datum cstring_in(FunctionCallInfo fcinfo);
extern Datum cstring_out(FunctionCallInfo fcinfo);
extern Datum cstring_recv(FunctionCallInfo fcinfo);
extern Datum cstring_send(FunctionCallInfo fcinfo);
extern Datum any_in(FunctionCallInfo fcinfo);
extern Datum any_out(FunctionCallInfo fcinfo);
extern Datum anyarray_in(FunctionCallInfo fcinfo);
extern Datum anyarray_out(FunctionCallInfo fcinfo);
extern Datum anyarray_recv(FunctionCallInfo fcinfo);
extern Datum anyarray_send(FunctionCallInfo fcinfo);
extern Datum anynonarray_in(FunctionCallInfo fcinfo);
extern Datum anynonarray_out(FunctionCallInfo fcinfo);
extern Datum anyenum_in(FunctionCallInfo fcinfo);
extern Datum anyenum_out(FunctionCallInfo fcinfo);
extern Datum anyrange_in(FunctionCallInfo fcinfo);
extern Datum anyrange_out(FunctionCallInfo fcinfo);
extern Datum void_in(FunctionCallInfo fcinfo);
extern Datum void_out(FunctionCallInfo fcinfo);
extern Datum void_recv(FunctionCallInfo fcinfo);
extern Datum void_send(FunctionCallInfo fcinfo);
extern Datum trigger_in(FunctionCallInfo fcinfo);
extern Datum trigger_out(FunctionCallInfo fcinfo);
extern Datum language_handler_in(FunctionCallInfo fcinfo);
extern Datum language_handler_out(FunctionCallInfo fcinfo);
extern Datum fdw_handler_in(FunctionCallInfo fcinfo);
extern Datum fdw_handler_out(FunctionCallInfo fcinfo);
extern Datum internal_in(FunctionCallInfo fcinfo);
extern Datum internal_out(FunctionCallInfo fcinfo);
extern Datum opaque_in(FunctionCallInfo fcinfo);
extern Datum opaque_out(FunctionCallInfo fcinfo);
extern Datum anyelement_in(FunctionCallInfo fcinfo);
extern Datum anyelement_out(FunctionCallInfo fcinfo);
extern Datum shell_in(FunctionCallInfo fcinfo);
extern Datum shell_out(FunctionCallInfo fcinfo);
extern Datum pg_node_tree_in(FunctionCallInfo fcinfo);
extern Datum pg_node_tree_out(FunctionCallInfo fcinfo);
extern Datum pg_node_tree_recv(FunctionCallInfo fcinfo);
extern Datum pg_node_tree_send(FunctionCallInfo fcinfo);


extern Datum nameregexeq(FunctionCallInfo fcinfo);
extern Datum nameregexne(FunctionCallInfo fcinfo);
extern Datum textregexeq(FunctionCallInfo fcinfo);
extern Datum textregexne(FunctionCallInfo fcinfo);
extern Datum nameicregexeq(FunctionCallInfo fcinfo);
extern Datum nameicregexne(FunctionCallInfo fcinfo);
extern Datum texticregexeq(FunctionCallInfo fcinfo);
extern Datum texticregexne(FunctionCallInfo fcinfo);
extern Datum textregexsubstr(FunctionCallInfo fcinfo);
extern Datum textregexreplace_noopt(FunctionCallInfo fcinfo);
extern Datum textregexreplace(FunctionCallInfo fcinfo);
extern Datum similar_escape(FunctionCallInfo fcinfo);
extern Datum regexp_matches(FunctionCallInfo fcinfo);
extern Datum regexp_matches_no_flags(FunctionCallInfo fcinfo);
extern Datum regexp_split_to_table(FunctionCallInfo fcinfo);
extern Datum regexp_split_to_table_no_flags(FunctionCallInfo fcinfo);
extern Datum regexp_split_to_array(FunctionCallInfo fcinfo);
extern Datum regexp_split_to_array_no_flags(FunctionCallInfo fcinfo);
extern char *regexp_fixed_prefix(text *text_re, bool case_insensitive,
         Oid collation, bool *exact);


extern Datum regprocin(FunctionCallInfo fcinfo);
extern Datum regprocout(FunctionCallInfo fcinfo);
extern Datum regprocrecv(FunctionCallInfo fcinfo);
extern Datum regprocsend(FunctionCallInfo fcinfo);
extern Datum regprocedurein(FunctionCallInfo fcinfo);
extern Datum regprocedureout(FunctionCallInfo fcinfo);
extern Datum regprocedurerecv(FunctionCallInfo fcinfo);
extern Datum regproceduresend(FunctionCallInfo fcinfo);
extern Datum regoperin(FunctionCallInfo fcinfo);
extern Datum regoperout(FunctionCallInfo fcinfo);
extern Datum regoperrecv(FunctionCallInfo fcinfo);
extern Datum regopersend(FunctionCallInfo fcinfo);
extern Datum regoperatorin(FunctionCallInfo fcinfo);
extern Datum regoperatorout(FunctionCallInfo fcinfo);
extern Datum regoperatorrecv(FunctionCallInfo fcinfo);
extern Datum regoperatorsend(FunctionCallInfo fcinfo);
extern Datum regclassin(FunctionCallInfo fcinfo);
extern Datum regclassout(FunctionCallInfo fcinfo);
extern Datum regclassrecv(FunctionCallInfo fcinfo);
extern Datum regclasssend(FunctionCallInfo fcinfo);
extern Datum regtypein(FunctionCallInfo fcinfo);
extern Datum regtypeout(FunctionCallInfo fcinfo);
extern Datum regtyperecv(FunctionCallInfo fcinfo);
extern Datum regtypesend(FunctionCallInfo fcinfo);
extern Datum regconfigin(FunctionCallInfo fcinfo);
extern Datum regconfigout(FunctionCallInfo fcinfo);
extern Datum regconfigrecv(FunctionCallInfo fcinfo);
extern Datum regconfigsend(FunctionCallInfo fcinfo);
extern Datum regdictionaryin(FunctionCallInfo fcinfo);
extern Datum regdictionaryout(FunctionCallInfo fcinfo);
extern Datum regdictionaryrecv(FunctionCallInfo fcinfo);
extern Datum regdictionarysend(FunctionCallInfo fcinfo);
extern Datum text_regclass(FunctionCallInfo fcinfo);
extern List *stringToQualifiedNameList(const char *string);
extern char *format_procedure(Oid procedure_oid);
extern char *format_operator(Oid operator_oid);


extern Datum record_in(FunctionCallInfo fcinfo);
extern Datum record_out(FunctionCallInfo fcinfo);
extern Datum record_recv(FunctionCallInfo fcinfo);
extern Datum record_send(FunctionCallInfo fcinfo);
extern Datum record_eq(FunctionCallInfo fcinfo);
extern Datum record_ne(FunctionCallInfo fcinfo);
extern Datum record_lt(FunctionCallInfo fcinfo);
extern Datum record_gt(FunctionCallInfo fcinfo);
extern Datum record_le(FunctionCallInfo fcinfo);
extern Datum record_ge(FunctionCallInfo fcinfo);
extern Datum btrecordcmp(FunctionCallInfo fcinfo);


extern bool quote_all_identifiers;
extern Datum pg_get_ruledef(FunctionCallInfo fcinfo);
extern Datum pg_get_ruledef_ext(FunctionCallInfo fcinfo);
extern Datum pg_get_viewdef(FunctionCallInfo fcinfo);
extern Datum pg_get_viewdef_ext(FunctionCallInfo fcinfo);
extern Datum pg_get_viewdef_wrap(FunctionCallInfo fcinfo);
extern Datum pg_get_viewdef_name(FunctionCallInfo fcinfo);
extern Datum pg_get_viewdef_name_ext(FunctionCallInfo fcinfo);
extern Datum pg_get_indexdef(FunctionCallInfo fcinfo);
extern Datum pg_get_indexdef_ext(FunctionCallInfo fcinfo);
extern char *pg_get_indexdef_string(Oid indexrelid);
extern char *pg_get_indexdef_columns(Oid indexrelid, bool pretty);
extern Datum pg_get_triggerdef(FunctionCallInfo fcinfo);
extern Datum pg_get_triggerdef_ext(FunctionCallInfo fcinfo);
extern Datum pg_get_constraintdef(FunctionCallInfo fcinfo);
extern Datum pg_get_constraintdef_ext(FunctionCallInfo fcinfo);
extern char *pg_get_constraintdef_string(Oid constraintId);
extern Datum pg_get_expr(FunctionCallInfo fcinfo);
extern Datum pg_get_expr_ext(FunctionCallInfo fcinfo);
extern Datum pg_get_userbyid(FunctionCallInfo fcinfo);
extern Datum pg_get_serial_sequence(FunctionCallInfo fcinfo);
extern Datum pg_get_functiondef(FunctionCallInfo fcinfo);
extern Datum pg_get_function_arguments(FunctionCallInfo fcinfo);
extern Datum pg_get_function_identity_arguments(FunctionCallInfo fcinfo);
extern Datum pg_get_function_result(FunctionCallInfo fcinfo);
extern char *deparse_expression(Node *expr, List *dpcontext,
       bool forceprefix, bool showimplicit);
extern List *deparse_context_for(const char *aliasname, Oid relid);
extern List *deparse_context_for_planstate(Node *planstate, List *ancestors,
         List *rtable);
extern const char *quote_identifier(const char *ident);
extern char *quote_qualified_identifier(const char *qualifier,
         const char *ident);
extern char *generate_collation_name(Oid collid);



extern Datum tidin(FunctionCallInfo fcinfo);
extern Datum tidout(FunctionCallInfo fcinfo);
extern Datum tidrecv(FunctionCallInfo fcinfo);
extern Datum tidsend(FunctionCallInfo fcinfo);
extern Datum tideq(FunctionCallInfo fcinfo);
extern Datum tidne(FunctionCallInfo fcinfo);
extern Datum tidlt(FunctionCallInfo fcinfo);
extern Datum tidle(FunctionCallInfo fcinfo);
extern Datum tidgt(FunctionCallInfo fcinfo);
extern Datum tidge(FunctionCallInfo fcinfo);
extern Datum bttidcmp(FunctionCallInfo fcinfo);
extern Datum tidlarger(FunctionCallInfo fcinfo);
extern Datum tidsmaller(FunctionCallInfo fcinfo);
extern Datum currtid_byreloid(FunctionCallInfo fcinfo);
extern Datum currtid_byrelname(FunctionCallInfo fcinfo);


extern Datum bpcharin(FunctionCallInfo fcinfo);
extern Datum bpcharout(FunctionCallInfo fcinfo);
extern Datum bpcharrecv(FunctionCallInfo fcinfo);
extern Datum bpcharsend(FunctionCallInfo fcinfo);
extern Datum bpchartypmodin(FunctionCallInfo fcinfo);
extern Datum bpchartypmodout(FunctionCallInfo fcinfo);
extern Datum bpchar(FunctionCallInfo fcinfo);
extern Datum char_bpchar(FunctionCallInfo fcinfo);
extern Datum name_bpchar(FunctionCallInfo fcinfo);
extern Datum bpchar_name(FunctionCallInfo fcinfo);
extern Datum bpchareq(FunctionCallInfo fcinfo);
extern Datum bpcharne(FunctionCallInfo fcinfo);
extern Datum bpcharlt(FunctionCallInfo fcinfo);
extern Datum bpcharle(FunctionCallInfo fcinfo);
extern Datum bpchargt(FunctionCallInfo fcinfo);
extern Datum bpcharge(FunctionCallInfo fcinfo);
extern Datum bpcharcmp(FunctionCallInfo fcinfo);
extern Datum bpchar_larger(FunctionCallInfo fcinfo);
extern Datum bpchar_smaller(FunctionCallInfo fcinfo);
extern Datum bpcharlen(FunctionCallInfo fcinfo);
extern Datum bpcharoctetlen(FunctionCallInfo fcinfo);
extern Datum hashbpchar(FunctionCallInfo fcinfo);
extern Datum bpchar_pattern_lt(FunctionCallInfo fcinfo);
extern Datum bpchar_pattern_le(FunctionCallInfo fcinfo);
extern Datum bpchar_pattern_gt(FunctionCallInfo fcinfo);
extern Datum bpchar_pattern_ge(FunctionCallInfo fcinfo);
extern Datum btbpchar_pattern_cmp(FunctionCallInfo fcinfo);

extern Datum varcharin(FunctionCallInfo fcinfo);
extern Datum varcharout(FunctionCallInfo fcinfo);
extern Datum varcharrecv(FunctionCallInfo fcinfo);
extern Datum varcharsend(FunctionCallInfo fcinfo);
extern Datum varchartypmodin(FunctionCallInfo fcinfo);
extern Datum varchartypmodout(FunctionCallInfo fcinfo);
extern Datum varchar_transform(FunctionCallInfo fcinfo);
extern Datum varchar(FunctionCallInfo fcinfo);


extern text *cstring_to_text(const char *s);
extern text *cstring_to_text_with_len(const char *s, int len);
extern char *text_to_cstring(const text *t);
extern void text_to_cstring_buffer(const text *src, char *dst, size_t dst_len);




extern Datum textin(FunctionCallInfo fcinfo);
extern Datum textout(FunctionCallInfo fcinfo);
extern Datum textrecv(FunctionCallInfo fcinfo);
extern Datum textsend(FunctionCallInfo fcinfo);
extern Datum textcat(FunctionCallInfo fcinfo);
extern Datum texteq(FunctionCallInfo fcinfo);
extern Datum textne(FunctionCallInfo fcinfo);
extern Datum text_lt(FunctionCallInfo fcinfo);
extern Datum text_le(FunctionCallInfo fcinfo);
extern Datum text_gt(FunctionCallInfo fcinfo);
extern Datum text_ge(FunctionCallInfo fcinfo);
extern Datum text_larger(FunctionCallInfo fcinfo);
extern Datum text_smaller(FunctionCallInfo fcinfo);
extern Datum text_pattern_lt(FunctionCallInfo fcinfo);
extern Datum text_pattern_le(FunctionCallInfo fcinfo);
extern Datum text_pattern_gt(FunctionCallInfo fcinfo);
extern Datum text_pattern_ge(FunctionCallInfo fcinfo);
extern Datum bttext_pattern_cmp(FunctionCallInfo fcinfo);
extern Datum textlen(FunctionCallInfo fcinfo);
extern Datum textoctetlen(FunctionCallInfo fcinfo);
extern Datum textpos(FunctionCallInfo fcinfo);
extern Datum text_substr(FunctionCallInfo fcinfo);
extern Datum text_substr_no_len(FunctionCallInfo fcinfo);
extern Datum textoverlay(FunctionCallInfo fcinfo);
extern Datum textoverlay_no_len(FunctionCallInfo fcinfo);
extern Datum name_text(FunctionCallInfo fcinfo);
extern Datum text_name(FunctionCallInfo fcinfo);
extern int varstr_cmp(char *arg1, int len1, char *arg2, int len2, Oid collid);
extern List *textToQualifiedNameList(text *textval);
extern bool SplitIdentifierString(char *rawstring, char separator,
       List **namelist);
extern Datum replace_text(FunctionCallInfo fcinfo);
extern text *replace_text_regexp(text *src_text, void *regexp,
     text *replace_text, bool glob);
extern Datum split_text(FunctionCallInfo fcinfo);
extern Datum text_to_array(FunctionCallInfo fcinfo);
extern Datum array_to_text(FunctionCallInfo fcinfo);
extern Datum text_to_array_null(FunctionCallInfo fcinfo);
extern Datum array_to_text_null(FunctionCallInfo fcinfo);
extern Datum to_hex32(FunctionCallInfo fcinfo);
extern Datum to_hex64(FunctionCallInfo fcinfo);
extern Datum md5_text(FunctionCallInfo fcinfo);
extern Datum md5_bytea(FunctionCallInfo fcinfo);

extern Datum unknownin(FunctionCallInfo fcinfo);
extern Datum unknownout(FunctionCallInfo fcinfo);
extern Datum unknownrecv(FunctionCallInfo fcinfo);
extern Datum unknownsend(FunctionCallInfo fcinfo);

extern Datum pg_column_size(FunctionCallInfo fcinfo);

extern Datum bytea_string_agg_transfn(FunctionCallInfo fcinfo);
extern Datum bytea_string_agg_finalfn(FunctionCallInfo fcinfo);
extern Datum string_agg_transfn(FunctionCallInfo fcinfo);
extern Datum string_agg_finalfn(FunctionCallInfo fcinfo);

extern Datum text_concat(FunctionCallInfo fcinfo);
extern Datum text_concat_ws(FunctionCallInfo fcinfo);
extern Datum text_left(FunctionCallInfo fcinfo);
extern Datum text_right(FunctionCallInfo fcinfo);
extern Datum text_reverse(FunctionCallInfo fcinfo);
extern Datum text_format(FunctionCallInfo fcinfo);
extern Datum text_format_nv(FunctionCallInfo fcinfo);


extern Datum pgsql_version(FunctionCallInfo fcinfo);


extern Datum xidin(FunctionCallInfo fcinfo);
extern Datum xidout(FunctionCallInfo fcinfo);
extern Datum xidrecv(FunctionCallInfo fcinfo);
extern Datum xidsend(FunctionCallInfo fcinfo);
extern Datum xideq(FunctionCallInfo fcinfo);
extern Datum xid_age(FunctionCallInfo fcinfo);
extern int xidComparator(const void *arg1, const void *arg2);
extern Datum cidin(FunctionCallInfo fcinfo);
extern Datum cidout(FunctionCallInfo fcinfo);
extern Datum cidrecv(FunctionCallInfo fcinfo);
extern Datum cidsend(FunctionCallInfo fcinfo);
extern Datum cideq(FunctionCallInfo fcinfo);


extern Datum namelike(FunctionCallInfo fcinfo);
extern Datum namenlike(FunctionCallInfo fcinfo);
extern Datum nameiclike(FunctionCallInfo fcinfo);
extern Datum nameicnlike(FunctionCallInfo fcinfo);
extern Datum textlike(FunctionCallInfo fcinfo);
extern Datum textnlike(FunctionCallInfo fcinfo);
extern Datum texticlike(FunctionCallInfo fcinfo);
extern Datum texticnlike(FunctionCallInfo fcinfo);
extern Datum bytealike(FunctionCallInfo fcinfo);
extern Datum byteanlike(FunctionCallInfo fcinfo);
extern Datum like_escape(FunctionCallInfo fcinfo);
extern Datum like_escape_bytea(FunctionCallInfo fcinfo);


extern Datum lower(FunctionCallInfo fcinfo);
extern Datum upper(FunctionCallInfo fcinfo);
extern Datum initcap(FunctionCallInfo fcinfo);
extern Datum lpad(FunctionCallInfo fcinfo);
extern Datum rpad(FunctionCallInfo fcinfo);
extern Datum btrim(FunctionCallInfo fcinfo);
extern Datum btrim1(FunctionCallInfo fcinfo);
extern Datum byteatrim(FunctionCallInfo fcinfo);
extern Datum ltrim(FunctionCallInfo fcinfo);
extern Datum ltrim1(FunctionCallInfo fcinfo);
extern Datum rtrim(FunctionCallInfo fcinfo);
extern Datum rtrim1(FunctionCallInfo fcinfo);
extern Datum translate(FunctionCallInfo fcinfo);
extern Datum chr (FunctionCallInfo fcinfo);
extern Datum repeat(FunctionCallInfo fcinfo);
extern Datum ascii(FunctionCallInfo fcinfo);


extern char *inet_cidr_ntop(int af, const void *src, int bits,
      char *dst, size_t size);


extern int inet_net_pton(int af, const char *src,
     void *dst, size_t size);


extern Datum inet_in(FunctionCallInfo fcinfo);
extern Datum inet_out(FunctionCallInfo fcinfo);
extern Datum inet_recv(FunctionCallInfo fcinfo);
extern Datum inet_send(FunctionCallInfo fcinfo);
extern Datum cidr_in(FunctionCallInfo fcinfo);
extern Datum cidr_out(FunctionCallInfo fcinfo);
extern Datum cidr_recv(FunctionCallInfo fcinfo);
extern Datum cidr_send(FunctionCallInfo fcinfo);
extern Datum network_cmp(FunctionCallInfo fcinfo);
extern Datum network_lt(FunctionCallInfo fcinfo);
extern Datum network_le(FunctionCallInfo fcinfo);
extern Datum network_eq(FunctionCallInfo fcinfo);
extern Datum network_ge(FunctionCallInfo fcinfo);
extern Datum network_gt(FunctionCallInfo fcinfo);
extern Datum network_ne(FunctionCallInfo fcinfo);
extern Datum hashinet(FunctionCallInfo fcinfo);
extern Datum network_sub(FunctionCallInfo fcinfo);
extern Datum network_subeq(FunctionCallInfo fcinfo);
extern Datum network_sup(FunctionCallInfo fcinfo);
extern Datum network_supeq(FunctionCallInfo fcinfo);
extern Datum network_network(FunctionCallInfo fcinfo);
extern Datum network_netmask(FunctionCallInfo fcinfo);
extern Datum network_hostmask(FunctionCallInfo fcinfo);
extern Datum network_masklen(FunctionCallInfo fcinfo);
extern Datum network_family(FunctionCallInfo fcinfo);
extern Datum network_broadcast(FunctionCallInfo fcinfo);
extern Datum network_host(FunctionCallInfo fcinfo);
extern Datum network_show(FunctionCallInfo fcinfo);
extern Datum inet_abbrev(FunctionCallInfo fcinfo);
extern Datum cidr_abbrev(FunctionCallInfo fcinfo);
extern double convert_network_to_scalar(Datum value, Oid typid);
extern Datum inet_to_cidr(FunctionCallInfo fcinfo);
extern Datum inet_set_masklen(FunctionCallInfo fcinfo);
extern Datum cidr_set_masklen(FunctionCallInfo fcinfo);
extern Datum network_scan_first(Datum in);
extern Datum network_scan_last(Datum in);
extern Datum inet_client_addr(FunctionCallInfo fcinfo);
extern Datum inet_client_port(FunctionCallInfo fcinfo);
extern Datum inet_server_addr(FunctionCallInfo fcinfo);
extern Datum inet_server_port(FunctionCallInfo fcinfo);
extern Datum inetnot(FunctionCallInfo fcinfo);
extern Datum inetand(FunctionCallInfo fcinfo);
extern Datum inetor(FunctionCallInfo fcinfo);
extern Datum inetpl(FunctionCallInfo fcinfo);
extern Datum inetmi_int8(FunctionCallInfo fcinfo);
extern Datum inetmi(FunctionCallInfo fcinfo);
extern void clean_ipv6_addr(int addr_family, char *addr);


extern Datum macaddr_in(FunctionCallInfo fcinfo);
extern Datum macaddr_out(FunctionCallInfo fcinfo);
extern Datum macaddr_recv(FunctionCallInfo fcinfo);
extern Datum macaddr_send(FunctionCallInfo fcinfo);
extern Datum macaddr_cmp(FunctionCallInfo fcinfo);
extern Datum macaddr_lt(FunctionCallInfo fcinfo);
extern Datum macaddr_le(FunctionCallInfo fcinfo);
extern Datum macaddr_eq(FunctionCallInfo fcinfo);
extern Datum macaddr_ge(FunctionCallInfo fcinfo);
extern Datum macaddr_gt(FunctionCallInfo fcinfo);
extern Datum macaddr_ne(FunctionCallInfo fcinfo);
extern Datum macaddr_not(FunctionCallInfo fcinfo);
extern Datum macaddr_and(FunctionCallInfo fcinfo);
extern Datum macaddr_or(FunctionCallInfo fcinfo);
extern Datum macaddr_trunc(FunctionCallInfo fcinfo);
extern Datum hashmacaddr(FunctionCallInfo fcinfo);


extern Datum numeric_in(FunctionCallInfo fcinfo);
extern Datum numeric_out(FunctionCallInfo fcinfo);
extern Datum numeric_recv(FunctionCallInfo fcinfo);
extern Datum numeric_send(FunctionCallInfo fcinfo);
extern Datum numerictypmodin(FunctionCallInfo fcinfo);
extern Datum numerictypmodout(FunctionCallInfo fcinfo);
extern Datum numeric_transform(FunctionCallInfo fcinfo);
extern Datum numeric (FunctionCallInfo fcinfo);
extern Datum numeric_abs(FunctionCallInfo fcinfo);
extern Datum numeric_uminus(FunctionCallInfo fcinfo);
extern Datum numeric_uplus(FunctionCallInfo fcinfo);
extern Datum numeric_sign(FunctionCallInfo fcinfo);
extern Datum numeric_round(FunctionCallInfo fcinfo);
extern Datum numeric_trunc(FunctionCallInfo fcinfo);
extern Datum numeric_ceil(FunctionCallInfo fcinfo);
extern Datum numeric_floor(FunctionCallInfo fcinfo);
extern Datum numeric_cmp(FunctionCallInfo fcinfo);
extern Datum numeric_eq(FunctionCallInfo fcinfo);
extern Datum numeric_ne(FunctionCallInfo fcinfo);
extern Datum numeric_gt(FunctionCallInfo fcinfo);
extern Datum numeric_ge(FunctionCallInfo fcinfo);
extern Datum numeric_lt(FunctionCallInfo fcinfo);
extern Datum numeric_le(FunctionCallInfo fcinfo);
extern Datum numeric_add(FunctionCallInfo fcinfo);
extern Datum numeric_sub(FunctionCallInfo fcinfo);
extern Datum numeric_mul(FunctionCallInfo fcinfo);
extern Datum numeric_div(FunctionCallInfo fcinfo);
extern Datum numeric_div_trunc(FunctionCallInfo fcinfo);
extern Datum numeric_mod(FunctionCallInfo fcinfo);
extern Datum numeric_inc(FunctionCallInfo fcinfo);
extern Datum numeric_smaller(FunctionCallInfo fcinfo);
extern Datum numeric_larger(FunctionCallInfo fcinfo);
extern Datum numeric_fac(FunctionCallInfo fcinfo);
extern Datum numeric_sqrt(FunctionCallInfo fcinfo);
extern Datum numeric_exp(FunctionCallInfo fcinfo);
extern Datum numeric_ln(FunctionCallInfo fcinfo);
extern Datum numeric_log(FunctionCallInfo fcinfo);
extern Datum numeric_power(FunctionCallInfo fcinfo);
extern Datum int4_numeric(FunctionCallInfo fcinfo);
extern Datum numeric_int4(FunctionCallInfo fcinfo);
extern Datum int8_numeric(FunctionCallInfo fcinfo);
extern Datum numeric_int8(FunctionCallInfo fcinfo);
extern Datum int2_numeric(FunctionCallInfo fcinfo);
extern Datum numeric_int2(FunctionCallInfo fcinfo);
extern Datum float8_numeric(FunctionCallInfo fcinfo);
extern Datum numeric_float8(FunctionCallInfo fcinfo);
extern Datum numeric_float8_no_overflow(FunctionCallInfo fcinfo);
extern Datum float4_numeric(FunctionCallInfo fcinfo);
extern Datum numeric_float4(FunctionCallInfo fcinfo);
extern Datum numeric_accum(FunctionCallInfo fcinfo);
extern Datum numeric_avg_accum(FunctionCallInfo fcinfo);
extern Datum int2_accum(FunctionCallInfo fcinfo);
extern Datum int4_accum(FunctionCallInfo fcinfo);
extern Datum int8_accum(FunctionCallInfo fcinfo);
extern Datum int8_avg_accum(FunctionCallInfo fcinfo);
extern Datum numeric_avg(FunctionCallInfo fcinfo);
extern Datum numeric_var_pop(FunctionCallInfo fcinfo);
extern Datum numeric_var_samp(FunctionCallInfo fcinfo);
extern Datum numeric_stddev_pop(FunctionCallInfo fcinfo);
extern Datum numeric_stddev_samp(FunctionCallInfo fcinfo);
extern Datum int2_sum(FunctionCallInfo fcinfo);
extern Datum int4_sum(FunctionCallInfo fcinfo);
extern Datum int8_sum(FunctionCallInfo fcinfo);
extern Datum int2_avg_accum(FunctionCallInfo fcinfo);
extern Datum int4_avg_accum(FunctionCallInfo fcinfo);
extern Datum int8_avg(FunctionCallInfo fcinfo);
extern Datum width_bucket_numeric(FunctionCallInfo fcinfo);
extern Datum hash_numeric(FunctionCallInfo fcinfo);


extern Datum RI_FKey_check_ins(FunctionCallInfo fcinfo);
extern Datum RI_FKey_check_upd(FunctionCallInfo fcinfo);
extern Datum RI_FKey_noaction_del(FunctionCallInfo fcinfo);
extern Datum RI_FKey_noaction_upd(FunctionCallInfo fcinfo);
extern Datum RI_FKey_cascade_del(FunctionCallInfo fcinfo);
extern Datum RI_FKey_cascade_upd(FunctionCallInfo fcinfo);
extern Datum RI_FKey_restrict_del(FunctionCallInfo fcinfo);
extern Datum RI_FKey_restrict_upd(FunctionCallInfo fcinfo);
extern Datum RI_FKey_setnull_del(FunctionCallInfo fcinfo);
extern Datum RI_FKey_setnull_upd(FunctionCallInfo fcinfo);
extern Datum RI_FKey_setdefault_del(FunctionCallInfo fcinfo);
extern Datum RI_FKey_setdefault_upd(FunctionCallInfo fcinfo);


extern Datum suppress_redundant_updates_trigger(FunctionCallInfo fcinfo);


extern Datum getdatabaseencoding(FunctionCallInfo fcinfo);
extern Datum database_character_set(FunctionCallInfo fcinfo);
extern Datum pg_client_encoding(FunctionCallInfo fcinfo);
extern Datum PG_encoding_to_char(FunctionCallInfo fcinfo);
extern Datum PG_char_to_encoding(FunctionCallInfo fcinfo);
extern Datum PG_character_set_name(FunctionCallInfo fcinfo);
extern Datum PG_character_set_id(FunctionCallInfo fcinfo);
extern Datum pg_convert(FunctionCallInfo fcinfo);
extern Datum pg_convert_to(FunctionCallInfo fcinfo);
extern Datum pg_convert_from(FunctionCallInfo fcinfo);
extern Datum length_in_encoding(FunctionCallInfo fcinfo);
extern Datum pg_encoding_max_length_sql(FunctionCallInfo fcinfo);


extern Datum format_type(FunctionCallInfo fcinfo);
extern char *format_type_be(Oid type_oid);
extern char *format_type_with_typemod(Oid type_oid, int32 typemod);
extern Datum oidvectortypes(FunctionCallInfo fcinfo);
extern int32 type_maximum_size(Oid type_oid, int32 typemod);


extern Datum quote_ident(FunctionCallInfo fcinfo);
extern Datum quote_literal(FunctionCallInfo fcinfo);
extern char *quote_literal_cstr(const char *rawstr);
extern Datum quote_nullable(FunctionCallInfo fcinfo);


extern Datum show_config_by_name(FunctionCallInfo fcinfo);
extern Datum set_config_by_name(FunctionCallInfo fcinfo);
extern Datum show_all_settings(FunctionCallInfo fcinfo);


extern Datum pg_lock_status(FunctionCallInfo fcinfo);
extern Datum pg_advisory_lock_int8(FunctionCallInfo fcinfo);
extern Datum pg_advisory_xact_lock_int8(FunctionCallInfo fcinfo);
extern Datum pg_advisory_lock_shared_int8(FunctionCallInfo fcinfo);
extern Datum pg_advisory_xact_lock_shared_int8(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_lock_int8(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_xact_lock_int8(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_lock_shared_int8(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_xact_lock_shared_int8(FunctionCallInfo fcinfo);
extern Datum pg_advisory_unlock_int8(FunctionCallInfo fcinfo);
extern Datum pg_advisory_unlock_shared_int8(FunctionCallInfo fcinfo);
extern Datum pg_advisory_lock_int4(FunctionCallInfo fcinfo);
extern Datum pg_advisory_xact_lock_int4(FunctionCallInfo fcinfo);
extern Datum pg_advisory_lock_shared_int4(FunctionCallInfo fcinfo);
extern Datum pg_advisory_xact_lock_shared_int4(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_lock_int4(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_xact_lock_int4(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_lock_shared_int4(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_xact_lock_shared_int4(FunctionCallInfo fcinfo);
extern Datum pg_advisory_unlock_int4(FunctionCallInfo fcinfo);
extern Datum pg_advisory_unlock_shared_int4(FunctionCallInfo fcinfo);
extern Datum pg_advisory_unlock_all(FunctionCallInfo fcinfo);


extern Datum txid_snapshot_in(FunctionCallInfo fcinfo);
extern Datum txid_snapshot_out(FunctionCallInfo fcinfo);
extern Datum txid_snapshot_recv(FunctionCallInfo fcinfo);
extern Datum txid_snapshot_send(FunctionCallInfo fcinfo);
extern Datum txid_current(FunctionCallInfo fcinfo);
extern Datum txid_current_snapshot(FunctionCallInfo fcinfo);
extern Datum txid_snapshot_xmin(FunctionCallInfo fcinfo);
extern Datum txid_snapshot_xmax(FunctionCallInfo fcinfo);
extern Datum txid_snapshot_xip(FunctionCallInfo fcinfo);
extern Datum txid_visible_in_snapshot(FunctionCallInfo fcinfo);


extern Datum uuid_in(FunctionCallInfo fcinfo);
extern Datum uuid_out(FunctionCallInfo fcinfo);
extern Datum uuid_send(FunctionCallInfo fcinfo);
extern Datum uuid_recv(FunctionCallInfo fcinfo);
extern Datum uuid_lt(FunctionCallInfo fcinfo);
extern Datum uuid_le(FunctionCallInfo fcinfo);
extern Datum uuid_eq(FunctionCallInfo fcinfo);
extern Datum uuid_ge(FunctionCallInfo fcinfo);
extern Datum uuid_gt(FunctionCallInfo fcinfo);
extern Datum uuid_ne(FunctionCallInfo fcinfo);
extern Datum uuid_cmp(FunctionCallInfo fcinfo);
extern Datum uuid_hash(FunctionCallInfo fcinfo);


extern Datum window_row_number(FunctionCallInfo fcinfo);
extern Datum window_rank(FunctionCallInfo fcinfo);
extern Datum window_dense_rank(FunctionCallInfo fcinfo);
extern Datum window_percent_rank(FunctionCallInfo fcinfo);
extern Datum window_cume_dist(FunctionCallInfo fcinfo);
extern Datum window_ntile(FunctionCallInfo fcinfo);
extern Datum window_lag(FunctionCallInfo fcinfo);
extern Datum window_lag_with_offset(FunctionCallInfo fcinfo);
extern Datum window_lag_with_offset_and_default(FunctionCallInfo fcinfo);
extern Datum window_lead(FunctionCallInfo fcinfo);
extern Datum window_lead_with_offset(FunctionCallInfo fcinfo);
extern Datum window_lead_with_offset_and_default(FunctionCallInfo fcinfo);
extern Datum window_first_value(FunctionCallInfo fcinfo);
extern Datum window_last_value(FunctionCallInfo fcinfo);
extern Datum window_nth_value(FunctionCallInfo fcinfo);


extern Datum spg_quad_config(FunctionCallInfo fcinfo);
extern Datum spg_quad_choose(FunctionCallInfo fcinfo);
extern Datum spg_quad_picksplit(FunctionCallInfo fcinfo);
extern Datum spg_quad_inner_consistent(FunctionCallInfo fcinfo);
extern Datum spg_quad_leaf_consistent(FunctionCallInfo fcinfo);


extern Datum spg_kd_config(FunctionCallInfo fcinfo);
extern Datum spg_kd_choose(FunctionCallInfo fcinfo);
extern Datum spg_kd_picksplit(FunctionCallInfo fcinfo);
extern Datum spg_kd_inner_consistent(FunctionCallInfo fcinfo);


extern Datum spg_text_config(FunctionCallInfo fcinfo);
extern Datum spg_text_choose(FunctionCallInfo fcinfo);
extern Datum spg_text_picksplit(FunctionCallInfo fcinfo);
extern Datum spg_text_inner_consistent(FunctionCallInfo fcinfo);
extern Datum spg_text_leaf_consistent(FunctionCallInfo fcinfo);


extern Datum ginarrayextract(FunctionCallInfo fcinfo);
extern Datum ginarrayextract_2args(FunctionCallInfo fcinfo);
extern Datum ginqueryarrayextract(FunctionCallInfo fcinfo);
extern Datum ginarrayconsistent(FunctionCallInfo fcinfo);


extern Datum pg_prepared_xact(FunctionCallInfo fcinfo);


extern Datum pg_describe_object(FunctionCallInfo fcinfo);


extern Datum unique_key_recheck(FunctionCallInfo fcinfo);


extern Datum pg_available_extensions(FunctionCallInfo fcinfo);
extern Datum pg_available_extension_versions(FunctionCallInfo fcinfo);
extern Datum pg_extension_update_paths(FunctionCallInfo fcinfo);
extern Datum pg_extension_config_dump(FunctionCallInfo fcinfo);


extern Datum pg_prepared_statement(FunctionCallInfo fcinfo);


extern Datum pg_cursor(FunctionCallInfo fcinfo);
# 72 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/fmgroids.h" 1
# 73 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h" 1
# 70 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 2
# 112 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
typedef struct TupleTableSlot
{
 NodeTag type;
 bool tts_isempty;
 bool tts_shouldFree;
 bool tts_shouldFreeMin;
 bool tts_slow;
 HeapTuple tts_tuple;
 TupleDesc tts_tupleDescriptor;
 MemoryContext tts_mcxt;
 Buffer tts_buffer;
 int tts_nvalid;
 Datum *tts_values;
 bool *tts_isnull;
 MinimalTuple tts_mintuple;
 HeapTupleData tts_minhdr;
 long tts_off;
} TupleTableSlot;
# 141 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
extern TupleTableSlot *MakeTupleTableSlot(void);
extern TupleTableSlot *ExecAllocTableSlot(List **tupleTable);
extern void ExecResetTupleTable(List *tupleTable, bool shouldFree);
extern TupleTableSlot *MakeSingleTupleTableSlot(TupleDesc tupdesc);
extern void ExecDropSingleTupleTableSlot(TupleTableSlot *slot);
extern void ExecSetSlotDescriptor(TupleTableSlot *slot, TupleDesc tupdesc);
extern TupleTableSlot *ExecStoreTuple(HeapTuple tuple,
      TupleTableSlot *slot,
      Buffer buffer,
      bool shouldFree);
extern TupleTableSlot *ExecStoreMinimalTuple(MinimalTuple mtup,
       TupleTableSlot *slot,
       bool shouldFree);
extern TupleTableSlot *ExecClearTuple(TupleTableSlot *slot);
extern TupleTableSlot *ExecStoreVirtualTuple(TupleTableSlot *slot);
extern TupleTableSlot *ExecStoreAllNullTuple(TupleTableSlot *slot);
extern HeapTuple ExecCopySlotTuple(TupleTableSlot *slot);
extern MinimalTuple ExecCopySlotMinimalTuple(TupleTableSlot *slot);
extern HeapTuple ExecFetchSlotTuple(TupleTableSlot *slot);
extern MinimalTuple ExecFetchSlotMinimalTuple(TupleTableSlot *slot);
extern Datum ExecFetchSlotTupleDatum(TupleTableSlot *slot);
extern HeapTuple ExecMaterializeSlot(TupleTableSlot *slot);
extern TupleTableSlot *ExecCopySlot(TupleTableSlot *dstslot,
    TupleTableSlot *srcslot);


extern Datum slot_getattr(TupleTableSlot *slot, int attnum, bool *isnull);
extern void slot_getallattrs(TupleTableSlot *slot);
extern void slot_getsomeattrs(TupleTableSlot *slot, int attnum);
extern bool slot_attisnull(TupleTableSlot *slot, int attnum);
# 71 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h" 2
# 86 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h"
typedef enum
{
 DestNone,
 DestDebug,
 DestRemote,
 DestRemoteExecute,
 DestSPI,
 DestTuplestore,
 DestIntoRel,
 DestCopyOut,
 DestSQLFunction
} CommandDest;
# 108 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h"
typedef struct _DestReceiver DestReceiver;

struct _DestReceiver
{

 void (*receiveSlot) (TupleTableSlot *slot,
           DestReceiver *self);

 void (*rStartup) (DestReceiver *self,
           int operation,
           TupleDesc typeinfo);
 void (*rShutdown) (DestReceiver *self);

 void (*rDestroy) (DestReceiver *self);

 CommandDest mydest;

};

extern DestReceiver *None_Receiver;



extern void BeginCommand(const char *commandTag, CommandDest dest);
extern DestReceiver *CreateDestReceiver(CommandDest dest);
extern void EndCommand(const char *commandTag, CommandDest dest);



extern void NullCommand(CommandDest dest);
extern void ReadyForQuery(CommandDest dest);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 2
# 51 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
typedef enum
{
 PGC_INTERNAL,
 PGC_POSTMASTER,
 PGC_SIGHUP,
 PGC_BACKEND,
 PGC_SUSET,
 PGC_USERSET
} GucContext;
# 83 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
typedef enum
{
 PGC_S_DEFAULT,
 PGC_S_DYNAMIC_DEFAULT,
 PGC_S_ENV_VAR,
 PGC_S_FILE,
 PGC_S_ARGV,
 PGC_S_DATABASE,
 PGC_S_USER,
 PGC_S_DATABASE_USER,
 PGC_S_CLIENT,
 PGC_S_OVERRIDE,
 PGC_S_INTERACTIVE,
 PGC_S_TEST,
 PGC_S_SESSION
} GucSource;





typedef struct ConfigVariable
{
 char *name;
 char *value;
 char *filename;
 int sourceline;
 struct ConfigVariable *next;
} ConfigVariable;

extern bool ParseConfigFile(const char *config_file, const char *calling_file,
    bool strict, int depth, int elevel,
    ConfigVariable **head_p, ConfigVariable **tail_p);
extern bool ParseConfigFp(FILE *fp, const char *config_file,
     int depth, int elevel,
     ConfigVariable **head_p, ConfigVariable **tail_p);
extern void FreeConfigVariables(ConfigVariable *list);






struct config_enum_entry
{
 const char *name;
 int val;
 bool hidden;
};




typedef bool (*GucBoolCheckHook) (bool *newval, void **extra, GucSource source);
typedef bool (*GucIntCheckHook) (int *newval, void **extra, GucSource source);
typedef bool (*GucRealCheckHook) (double *newval, void **extra, GucSource source);
typedef bool (*GucStringCheckHook) (char **newval, void **extra, GucSource source);
typedef bool (*GucEnumCheckHook) (int *newval, void **extra, GucSource source);

typedef void (*GucBoolAssignHook) (bool newval, void *extra);
typedef void (*GucIntAssignHook) (int newval, void *extra);
typedef void (*GucRealAssignHook) (double newval, void *extra);
typedef void (*GucStringAssignHook) (const char *newval, void *extra);
typedef void (*GucEnumAssignHook) (int newval, void *extra);

typedef const char *(*GucShowHook) (void);




typedef enum
{

 GUC_ACTION_SET,
 GUC_ACTION_LOCAL,
 GUC_ACTION_SAVE
} GucAction;
# 190 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
extern bool log_duration;
extern bool Debug_print_plan;
extern bool Debug_print_parse;
extern bool Debug_print_rewritten;
extern bool Debug_pretty_print;

extern bool log_parser_stats;
extern bool log_planner_stats;
extern bool log_executor_stats;
extern bool log_statement_stats;
extern bool log_btree_build_stats;

extern bool check_function_bodies;
extern bool default_with_oids;
extern bool SQL_inheritance;

extern int log_min_error_statement;
extern int log_min_messages;
extern int client_min_messages;
extern int log_min_duration_statement;
extern int log_temp_files;

extern int temp_file_limit;

extern int num_temp_buffers;

extern char *data_directory;
extern char *ConfigFileName;
extern char *HbaFileName;
extern char *IdentFileName;
extern char *external_pid_file;

extern char *application_name;

extern int tcp_keepalives_idle;
extern int tcp_keepalives_interval;
extern int tcp_keepalives_count;




extern void SetConfigOption(const char *name, const char *value,
    GucContext context, GucSource source);

extern void DefineCustomBoolVariable(
       const char *name,
       const char *short_desc,
       const char *long_desc,
       bool *valueAddr,
       bool bootValue,
       GucContext context,
       int flags,
       GucBoolCheckHook check_hook,
       GucBoolAssignHook assign_hook,
       GucShowHook show_hook);

extern void DefineCustomIntVariable(
      const char *name,
      const char *short_desc,
      const char *long_desc,
      int *valueAddr,
      int bootValue,
      int minValue,
      int maxValue,
      GucContext context,
      int flags,
      GucIntCheckHook check_hook,
      GucIntAssignHook assign_hook,
      GucShowHook show_hook);

extern void DefineCustomRealVariable(
       const char *name,
       const char *short_desc,
       const char *long_desc,
       double *valueAddr,
       double bootValue,
       double minValue,
       double maxValue,
       GucContext context,
       int flags,
       GucRealCheckHook check_hook,
       GucRealAssignHook assign_hook,
       GucShowHook show_hook);

extern void DefineCustomStringVariable(
         const char *name,
         const char *short_desc,
         const char *long_desc,
         char **valueAddr,
         const char *bootValue,
         GucContext context,
         int flags,
         GucStringCheckHook check_hook,
         GucStringAssignHook assign_hook,
         GucShowHook show_hook);

extern void DefineCustomEnumVariable(
       const char *name,
       const char *short_desc,
       const char *long_desc,
       int *valueAddr,
       int bootValue,
       const struct config_enum_entry * options,
       GucContext context,
       int flags,
       GucEnumCheckHook check_hook,
       GucEnumAssignHook assign_hook,
       GucShowHook show_hook);

extern void EmitWarningsOnPlaceholders(const char *className);

extern const char *GetConfigOption(const char *name, bool missing_ok,
    bool restrict_superuser);
extern const char *GetConfigOptionResetString(const char *name);
extern void ProcessConfigFile(GucContext context);
extern void InitializeGUCOptions(void);
extern bool SelectConfigFiles(const char *userDoption, const char *progname);
extern void ResetAllOptions(void);
extern void AtStart_GUC(void);
extern int NewGUCNestLevel(void);
extern void AtEOXact_GUC(bool isCommit, int nestLevel);
extern void BeginReportingGUCOptions(void);
extern void ParseLongOption(const char *string, char **name, char **value);
extern bool parse_int(const char *value, int *result, int flags,
    const char **hintmsg);
extern bool parse_real(const char *value, double *result);
extern int set_config_option(const char *name, const char *value,
      GucContext context, GucSource source,
      GucAction action, bool changeVal, int elevel);
extern char *GetConfigOptionByName(const char *name, const char **varname);
extern void GetConfigOptionByNum(int varnum, const char **values, bool *noshow);
extern int GetNumConfigOptions(void);

extern void SetPGVariable(const char *name, List *args, bool is_local);
extern void GetPGVariable(const char *name, DestReceiver *dest);
extern TupleDesc GetPGVariableResultDesc(const char *name);

extern void ExecSetVariableStmt(VariableSetStmt *stmt);
extern char *ExtractSetVariableArgs(VariableSetStmt *stmt);

extern void ProcessGUCArray(ArrayType *array,
    GucContext context, GucSource source, GucAction action);
extern ArrayType *GUCArrayAdd(ArrayType *array, const char *name, const char *value);
extern ArrayType *GUCArrayDelete(ArrayType *array, const char *name);
extern ArrayType *GUCArrayReset(ArrayType *array);
# 343 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
extern char *GUC_check_errmsg_string;
extern char *GUC_check_errdetail_string;
extern char *GUC_check_errhint_string;

extern void GUC_check_errcode(int sqlerrcode);
# 369 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
extern bool check_default_tablespace(char **newval, void **extra, GucSource source);
extern bool check_temp_tablespaces(char **newval, void **extra, GucSource source);
extern void assign_temp_tablespaces(const char *newval, void *extra);


extern bool check_search_path(char **newval, void **extra, GucSource source);
extern void assign_search_path(const char *newval, void *extra);


extern bool check_wal_buffers(int *newval, void **extra, GucSource source);
extern void assign_xlog_sync_method(int new_sync_method, void *extra);
# 74 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/memnodes.h" 1
# 36 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/memnodes.h"
typedef struct MemoryContextMethods
{
 void *(*alloc) (MemoryContext context, Size size);

 void (*free_p) (MemoryContext context, void *pointer);
 void *(*realloc) (MemoryContext context, void *pointer, Size size);
 void (*init) (MemoryContext context);
 void (*reset) (MemoryContext context);
 void (*delete_context) (MemoryContext context);
 Size (*get_chunk_space) (MemoryContext context, void *pointer);
 bool (*is_empty) (MemoryContext context);
 void (*stats) (MemoryContext context, int level);



} MemoryContextMethods;


typedef struct MemoryContextData
{
 NodeTag type;
 MemoryContextMethods *methods;
 MemoryContext parent;
 MemoryContext firstchild;
 MemoryContext nextchild;
 char *name;
 bool isReset;
} MemoryContextData;
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h" 2
# 53 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h"
typedef struct StandardChunkHeader
{
 MemoryContext context;
 Size size;




} StandardChunkHeader;
# 72 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h"
extern MemoryContext TopMemoryContext;
extern MemoryContext ErrorContext;
extern MemoryContext PostmasterContext;
extern MemoryContext CacheMemoryContext;
extern MemoryContext MessageContext;
extern MemoryContext TopTransactionContext;
extern MemoryContext CurTransactionContext;


extern MemoryContext PortalContext;





extern void MemoryContextInit(void);
extern void MemoryContextReset(MemoryContext context);
extern void MemoryContextDelete(MemoryContext context);
extern void MemoryContextResetChildren(MemoryContext context);
extern void MemoryContextDeleteChildren(MemoryContext context);
extern void MemoryContextResetAndDeleteChildren(MemoryContext context);
extern void MemoryContextSetParent(MemoryContext context,
        MemoryContext new_parent);
extern Size GetMemoryChunkSpace(void *pointer);
extern MemoryContext GetMemoryChunkContext(void *pointer);
extern MemoryContext MemoryContextGetParent(MemoryContext context);
extern bool MemoryContextIsEmpty(MemoryContext context);
extern void MemoryContextStats(MemoryContext context);




extern bool MemoryContextContains(MemoryContext context, void *pointer);






extern MemoryContext MemoryContextCreate(NodeTag tag, Size size,
     MemoryContextMethods *methods,
     MemoryContext parent,
     const char *name);







extern MemoryContext AllocSetContextCreate(MemoryContext parent,
       const char *name,
       Size minContextSize,
       Size initBlockSize,
       Size maxBlockSize);
# 75 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_am.h" 1
# 34 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_am.h"
typedef struct FormData_pg_am
{
 NameData amname;
 int2 amstrategies;



 int2 amsupport;

 bool amcanorder;
 bool amcanorderbyop;
 bool amcanbackward;
 bool amcanunique;
 bool amcanmulticol;
 bool amoptionalkey;
 bool amsearcharray;
 bool amsearchnulls;
 bool amstorage;
 bool amclusterable;
 bool ampredlocks;
 Oid amkeytype;
 regproc aminsert;
 regproc ambeginscan;
 regproc amgettuple;
 regproc amgetbitmap;
 regproc amrescan;
 regproc amendscan;
 regproc ammarkpos;
 regproc amrestrpos;
 regproc ambuild;
 regproc ambuildempty;
 regproc ambulkdelete;
 regproc amvacuumcleanup;
 regproc amcanreturn;
 regproc amcostestimate;
 regproc amoptions;
} FormData_pg_am;






typedef FormData_pg_am *Form_pg_am;
# 120 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_am.h"
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_class.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_index.h" 1
# 31 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_index.h"
typedef struct FormData_pg_index
{
 Oid indexrelid;
 Oid indrelid;
 int2 indnatts;
 bool indisunique;
 bool indisprimary;
 bool indisexclusion;
 bool indimmediate;
 bool indisclustered;
 bool indisvalid;
 bool indcheckxmin;
 bool indisready;


 int2vector indkey;
# 58 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_index.h"
} FormData_pg_index;






typedef FormData_pg_index *Form_pg_index;
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h" 2


# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/rewrite/prs2lock.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/rewrite/prs2lock.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/rewrite/prs2lock.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/rewrite/prs2lock.h" 2






typedef struct RewriteRule
{
 Oid ruleId;
 CmdType event;
 AttrNumber attrno;
 Node *qual;
 List *actions;
 char enabled;
 bool isInstead;
} RewriteRule;







typedef struct RuleLock
{
 int numLocks;
 RewriteRule **rules;
} RuleLock;
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h" 1
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h" 1
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h" 1
# 27 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/reltrigger.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/reltrigger.h"
typedef struct Trigger
{
 Oid tgoid;

 char *tgname;
 Oid tgfoid;
 int16 tgtype;
 char tgenabled;
 bool tgisinternal;
 Oid tgconstrrelid;
 Oid tgconstrindid;
 Oid tgconstraint;
 bool tgdeferrable;
 bool tginitdeferred;
 int16 tgnargs;
 int16 tgnattr;
 int16 *tgattr;
 char **tgargs;
 char *tgqual;
} Trigger;

typedef struct TriggerDesc
{
 Trigger *triggers;
 int numtriggers;





 bool trig_insert_before_row;
 bool trig_insert_after_row;
 bool trig_insert_instead_row;
 bool trig_insert_before_statement;
 bool trig_insert_after_statement;
 bool trig_update_before_row;
 bool trig_update_after_row;
 bool trig_update_instead_row;
 bool trig_update_before_statement;
 bool trig_update_after_statement;
 bool trig_delete_before_row;
 bool trig_delete_after_row;
 bool trig_delete_instead_row;
 bool trig_delete_before_statement;
 bool trig_delete_after_statement;

 bool trig_truncate_before_statement;
 bool trig_truncate_after_statement;
} TriggerDesc;
# 28 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h" 2







typedef struct LockRelId
{
 Oid relId;
 Oid dbId;
} LockRelId;

typedef struct LockInfoData
{
 LockRelId lockRelId;
} LockInfoData;

typedef LockInfoData *LockInfo;






typedef struct RelationAmInfo
{
 FmgrInfo aminsert;
 FmgrInfo ambeginscan;
 FmgrInfo amgettuple;
 FmgrInfo amgetbitmap;
 FmgrInfo amrescan;
 FmgrInfo amendscan;
 FmgrInfo ammarkpos;
 FmgrInfo amrestrpos;
 FmgrInfo ambuild;
 FmgrInfo ambuildempty;
 FmgrInfo ambulkdelete;
 FmgrInfo amvacuumcleanup;
 FmgrInfo amcanreturn;
 FmgrInfo amcostestimate;
 FmgrInfo amoptions;
} RelationAmInfo;






typedef struct RelationData
{
 RelFileNode rd_node;

 struct SMgrRelationData *rd_smgr;
 int rd_refcnt;
 BackendId rd_backend;
 bool rd_isnailed;
 bool rd_isvalid;
 char rd_indexvalid;

 bool rd_islocaltemp;
# 99 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h"
 SubTransactionId rd_createSubid;
 SubTransactionId rd_newRelfilenodeSubid;


 Form_pg_class rd_rel;
 TupleDesc rd_att;
 Oid rd_id;
 List *rd_indexlist;
 Bitmapset *rd_indexattr;
 Oid rd_oidindex;
 LockInfoData rd_lockInfo;
 RuleLock *rd_rules;
 MemoryContext rd_rulescxt;
 TriggerDesc *trigdesc;






 bytea *rd_options;


 Form_pg_index rd_index;

 struct HeapTupleData *rd_indextuple;
 Form_pg_am rd_am;
# 142 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h"
 MemoryContext rd_indexcxt;
 RelationAmInfo *rd_aminfo;
 Oid *rd_opfamily;
 Oid *rd_opcintype;
 RegProcedure *rd_support;
 FmgrInfo *rd_supportinfo;
 int16 *rd_indoption;
 List *rd_indexprs;
 List *rd_indpred;
 Oid *rd_exclops;
 Oid *rd_exclprocs;
 uint16 *rd_exclstrats;
 void *rd_amcache;
 Oid *rd_indcollation;
# 166 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h"
 Oid rd_toastoid;


 struct PgStat_TableStatus *pgstat_info;
} RelationData;
# 181 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h"
typedef struct AutoVacOpts
{
 bool enabled;
 int vacuum_threshold;
 int analyze_threshold;
 int vacuum_cost_delay;
 int vacuum_cost_limit;
 int freeze_min_age;
 int freeze_max_age;
 int freeze_table_age;
 float8 vacuum_scale_factor;
 float8 analyze_scale_factor;
} AutoVacOpts;

typedef struct StdRdOptions
{
 int32 vl_len_;
 int fillfactor;
 AutoVacOpts autovacuum;
 bool security_barrier;
} StdRdOptions;
# 389 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/rel.h"
extern void RelationIncrementReferenceCount(Relation rel);
extern void RelationDecrementReferenceCount(Relation rel);
# 76 "tablespace.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/tqual.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/tqual.h"
extern SnapshotData SnapshotNowData;
extern SnapshotData SnapshotSelfData;
extern SnapshotData SnapshotAnyData;
extern SnapshotData SnapshotToastData;
# 58 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/tqual.h"
typedef enum
{
 HEAPTUPLE_DEAD,
 HEAPTUPLE_LIVE,
 HEAPTUPLE_RECENTLY_DEAD,
 HEAPTUPLE_INSERT_IN_PROGRESS,
 HEAPTUPLE_DELETE_IN_PROGRESS
} HTSV_Result;


extern bool HeapTupleSatisfiesMVCC(HeapTupleHeader tuple,
        Snapshot snapshot, Buffer buffer);
extern bool HeapTupleSatisfiesNow(HeapTupleHeader tuple,
       Snapshot snapshot, Buffer buffer);
extern bool HeapTupleSatisfiesSelf(HeapTupleHeader tuple,
        Snapshot snapshot, Buffer buffer);
extern bool HeapTupleSatisfiesAny(HeapTupleHeader tuple,
       Snapshot snapshot, Buffer buffer);
extern bool HeapTupleSatisfiesToast(HeapTupleHeader tuple,
      Snapshot snapshot, Buffer buffer);
extern bool HeapTupleSatisfiesDirty(HeapTupleHeader tuple,
      Snapshot snapshot, Buffer buffer);


extern HTSU_Result HeapTupleSatisfiesUpdate(HeapTupleHeader tuple,
       CommandId curcid, Buffer buffer);
extern HTSV_Result HeapTupleSatisfiesVacuum(HeapTupleHeader tuple,
       TransactionId OldestXmin, Buffer buffer);
extern bool HeapTupleIsSurelyDead(HeapTupleHeader tuple,
       TransactionId OldestXmin);

extern void HeapTupleSetHintBits(HeapTupleHeader tuple, Buffer buffer,
      uint16 infomask, TransactionId xid);
# 77 "tablespace.c" 2



char *default_tablespace = ((void *)0);
char *temp_tablespaces = ((void *)0);


static void create_tablespace_directories(const char *location,
         const Oid tablespaceoid);
static bool destroy_tablespace_directories(Oid tablespaceoid, bool redo);
# 106 "tablespace.c"
void
TablespaceCreateDbspace(Oid spcNode, Oid dbNode, bool isRedo)
{
 struct stat st;
 char *dir;





 if (spcNode == 1664)
  return;

 ;
 ;

 dir = GetDatabasePath(dbNode, spcNode);

 if (stat(dir, &st) < 0)
 {

  if ((*__error()) == 2)
  {




   LWLockAcquire(TablespaceCreateLock, LW_EXCLUSIVE);





   if (stat(dir, &st) == 0 && (((st.st_mode) & 0170000) == 0040000))
   {

   }
   else
   {

    if (mkdir(dir, 0000700) < 0)
    {
     char *parentdir;


     if ((*__error()) != 2 || !isRedo)
      (errstart(20, "tablespace.c", 155, __func__, ((void *)0)) ? (errfinish (errcode_for_file_access(), errmsg("could not create directory \"%s\": %m", dir))) : (void) 0);
# 164 "tablespace.c"
     parentdir = MemoryContextStrdup(CurrentMemoryContext, (dir));
     get_parent_directory(parentdir);
     get_parent_directory(parentdir);

     if (mkdir(parentdir, 0000700) < 0 && (*__error()) != 17)
      (errstart(20, "tablespace.c", 172, __func__, ((void *)0)) ? (errfinish (errcode_for_file_access(), errmsg("could not create directory \"%s\": %m", parentdir))) : (void) 0);



     pfree(parentdir);


     parentdir = MemoryContextStrdup(CurrentMemoryContext, (dir));
     get_parent_directory(parentdir);

     if (mkdir(parentdir, 0000700) < 0 && (*__error()) != 17)
      (errstart(20, "tablespace.c", 183, __func__, ((void *)0)) ? (errfinish (errcode_for_file_access(), errmsg("could not create directory \"%s\": %m", parentdir))) : (void) 0);



     pfree(parentdir);


     if (mkdir(dir, 0000700) < 0)
      (errstart(20, "tablespace.c", 191, __func__, ((void *)0)) ? (errfinish (errcode_for_file_access(), errmsg("could not create directory \"%s\": %m", dir))) : (void) 0);



    }
   }

   LWLockRelease(TablespaceCreateLock);
  }
  else
  {
   (errstart(20, "tablespace.c", 201, __func__, ((void *)0)) ? (errfinish (errcode_for_file_access(), errmsg("could not stat directory \"%s\": %m", dir))) : (void) 0);


  }
 }
 else
 {

  if (!(((st.st_mode) & 0170000) == 0040000))
   (errstart(20, "tablespace.c", 211, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('8') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('9') - '0') & 0x3F) << 24))), errmsg("\"%s\" exists but is not a directory", dir))) : (void) 0);



 }

 pfree(dir);
}
# 224 "tablespace.c"
void
CreateTableSpace(CreateTableSpaceStmt *stmt)
{

 Relation rel;
 Datum values[4];
 bool nulls[4];
 HeapTuple tuple;
 Oid tablespaceoid;
 char *location;
 Oid ownerId;


 if (!superuser())
  (errstart(20, "tablespace.c", 242, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('5') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('1') - '0') & 0x3F) << 24))), errmsg("permission denied to create tablespace \"%s\"", stmt->tablespacename), errhint("Must be superuser to create a tablespace."))) : (void) 0);






 if (stmt->owner)
  ownerId = get_role_oid(stmt->owner, ((bool) 0));
 else
  ownerId = GetUserId();


 location = MemoryContextStrdup(CurrentMemoryContext, (stmt->location));
 canonicalize_path(location);


 if (strchr(location, '\''))
  (errstart(20, "tablespace.c", 258, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('6') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('2') - '0') & 0x3F) << 24))), errmsg("tablespace location cannot contain single quotes"))) : (void) 0);
# 265 "tablespace.c"
 if (!( (((location)[0]) == '/') ))
  (errstart(20, "tablespace.c", 268, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('P') - '0') & 0x3F) << 12) + (((('1') - '0') & 0x3F) << 18) + (((('7') - '0') & 0x3F) << 24))), errmsg("tablespace location must be an absolute path"))) : (void) 0);
# 275 "tablespace.c"
 if (strlen(location) + 1 + strlen("PG_" "9.2" "_" "201204301") + 1 +
  10 + 1 + 10 + 1 + 10 > 1024)
  (errstart(20, "tablespace.c", 280, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('P') - '0') & 0x3F) << 12) + (((('1') - '0') & 0x3F) << 18) + (((('7') - '0') & 0x3F) << 24))), errmsg("tablespace location \"%s\" is too long", location))) : (void) 0);
# 286 "tablespace.c"
 if (!allowSystemTableMods && IsReservedName(stmt->tablespacename))
  (errstart(20, "tablespace.c", 291, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('9') - '0') & 0x3F) << 12) + (((('3') - '0') & 0x3F) << 18) + (((('9') - '0') & 0x3F) << 24))), errmsg("unacceptable tablespace name \"%s\"", stmt->tablespacename), errdetail("The prefix \"pg_\" is reserved for system tablespaces."))) : (void) 0);
# 298 "tablespace.c"
 if (((bool) ((get_tablespace_oid(stmt->tablespacename, ((bool) 1))) != ((Oid) 0))))
  (errstart(20, "tablespace.c", 302, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('7') - '0') & 0x3F) << 12) + (((('1') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("tablespace \"%s\" already exists", stmt->tablespacename))) : (void) 0);
# 309 "tablespace.c"
 rel = heap_open(1213, 3);

 do { void *_vstart = (void *) (nulls); int _val = (((bool) 0)); Size _len = (sizeof(nulls)); if ((((intptr_t) _vstart) & (sizeof(long) - 1)) == 0 && (_len & (sizeof(long) - 1)) == 0 && _val == 0 && _len <= 1024 && 1024 != 0) { long *_start = (long *) _vstart; long *_stop = (long *) ((char *) _start + _len); while (_start < _stop) *_start++ = 0; } else ((__builtin_object_size (_vstart, 0) != (size_t) -1) ? __builtin___memset_chk (_vstart, _val, _len, __builtin_object_size (_vstart, 0)) : __inline_memset_chk (_vstart, _val, _len)); } while (0);

 values[1 - 1] =
  DirectFunctionCall1Coll(namein, ((Oid) 0), ((Datum) (stmt->tablespacename)));
 values[2 - 1] =
  ((Datum) (((Datum) (ownerId)) & 0xffffffff));
 nulls[3 - 1] = ((bool) 1);
 nulls[4 - 1] = ((bool) 1);

 tuple = heap_form_tuple(rel->rd_att, values, nulls);

 tablespaceoid = simple_heap_insert(rel, tuple);

 CatalogUpdateIndexes(rel, tuple);

 heap_freetuple(tuple);


 recordDependencyOnOwner(1213, tablespaceoid, ownerId);


 do { if (object_access_hook) (*object_access_hook)((OAT_POST_CREATE),(1213), (tablespaceoid),(0),(((void *)0))); } while(0);


 create_tablespace_directories(location, tablespaceoid);


 {
  xl_tblspc_create_rec xlrec;
  XLogRecData rdata[2];

  xlrec.ts_id = tablespaceoid;
  rdata[0].data = (char *) &xlrec;
  rdata[0].len = __builtin_offsetof (xl_tblspc_create_rec, ts_path);
  rdata[0].buffer = 0;
  rdata[0].next = &(rdata[1]);

  rdata[1].data = (char *) location;
  rdata[1].len = strlen(location) + 1;
  rdata[1].buffer = 0;
  rdata[1].next = ((void *)0);

  (void) XLogInsert(5, 0x00, rdata);
 }







 ForceSyncCommit();

 pfree(location);


 relation_close(rel,0);





}






void
DropTableSpace(DropTableSpaceStmt *stmt)
{

 char *tablespacename = stmt->tablespacename;
 HeapScanDesc scandesc;
 Relation rel;
 HeapTuple tuple;
 ScanKeyData entry[1];
 Oid tablespaceoid;




 rel = heap_open(1213, 3);

 ScanKeyInit(&entry[0],
    1,
    3, 62,
    ((Datum) (tablespacename)));
 scandesc = heap_beginscan(rel, (&SnapshotNowData), 1, entry);
 tuple = heap_getnext(scandesc, ForwardScanDirection);

 if (!((const void*)(tuple) != ((void *)0)))
 {
  if (!stmt->missing_ok)
  {
   (errstart(20, "tablespace.c", 410, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('7') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('4') - '0') & 0x3F) << 24))), errmsg("tablespace \"%s\" does not exist", tablespacename))) : (void) 0);



  }
  else
  {
   (errstart(18, "tablespace.c", 416, __func__, ((void *)0)) ? (errfinish (errmsg("tablespace \"%s\" does not exist, skipping", tablespacename))) : (void) 0);



   heap_endscan(scandesc);
   relation_close(rel,0);
  }
  return;
 }

 tablespaceoid = ( (((tuple)->t_data)->t_infomask & 0x0008) ? *((Oid *) ((char *)((tuple)->t_data) + ((tuple)->t_data)->t_hoff - sizeof(Oid))) : ((Oid) 0) );


 if (!pg_tablespace_ownercheck(tablespaceoid, GetUserId()))
  aclcheck_error(ACLCHECK_NOT_OWNER, ACL_KIND_TABLESPACE,
        tablespacename);


 if (tablespaceoid == 1664 ||
  tablespaceoid == 1663)
  aclcheck_error(ACLCHECK_NO_PRIV, ACL_KIND_TABLESPACE,
        tablespacename);


 if (object_access_hook)
 {
  ObjectAccessDrop drop_arg;

  ((__builtin_object_size (&drop_arg, 0) != (size_t) -1) ? __builtin___memset_chk (&drop_arg, 0, sizeof(ObjectAccessDrop), __builtin_object_size (&drop_arg, 0)) : __inline_memset_chk (&drop_arg, 0, sizeof(ObjectAccessDrop)));
  do { if (object_access_hook) (*object_access_hook)((OAT_DROP),(1213), (tablespaceoid),(0),(&drop_arg)); } while(0);

 }




 simple_heap_delete(rel, &tuple->t_self);

 heap_endscan(scandesc);




 DeleteSharedComments(tablespaceoid, 1213);
 DeleteSharedSecurityLabel(tablespaceoid, 1213);




 deleteSharedDependencyRecordsFor(1213, tablespaceoid, 0);





 LWLockAcquire(TablespaceCreateLock, LW_EXCLUSIVE);




 if (!destroy_tablespace_directories(tablespaceoid, ((bool) 0)))
 {
# 485 "tablespace.c"
  RequestCheckpoint(0x0004 | 0x0008 | 0x0010);
  if (!destroy_tablespace_directories(tablespaceoid, ((bool) 0)))
  {

   (errstart(20, "tablespace.c", 492, __func__, ((void *)0)) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('5') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("tablespace \"%s\" is not empty", tablespacename))) : (void) 0);



  }
 }


 {
  xl_tblspc_drop_rec xlrec;
  XLogRecData rdata[1];

  xlrec.ts_id = tablespaceoid;
  rdata[0].data = (char *) &xlrec;
  rdata[0].len = sizeof(xl_tblspc_drop_rec);
  rdata[0].buffer = 0;
  rdata[0].next = ((void *)0);

  (void) XLogInsert(5, 0x10, rdata);
 }
# 522 "tablespace.c"
 ForceSyncCommit();




 LWLockRelease(TablespaceCreateLock);


 relation_close(rel,0);





}
# 545 "tablespace.c"
static void
create_tablespace_directories(const char *location, const Oid tablespaceoid)
{
 char *linkloc = MemoryContextAlloc(CurrentMemoryContext, (10 + 10 + 1));
 char *location_with_version_dir = MemoryContextAlloc(CurrentMemoryContext, (strlen(location) + 1 + strlen("PG_" "9.2" "_" "201204301") + 1));


 __builtin___sprintf_chk (linkloc, 0, __builtin_object_size (linkloc, 2 > 1), "pg_tblspc/%u", tablespaceoid);
 __builtin___sprintf_chk (location_with_version_dir, 0, __builtin_object_size (location_with_version_dir, 2 > 1), "%s/%s", location, "PG_" "9.2" "_" "201204301");






 if (chmod(location, 0000700) != 0)
 {
  if ((*__error()) == 2)
   (errstart(20, "tablespace.c", 567, __func__, ((void *)0)) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('8') - '0') & 0x3F) << 6) + (((('P') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('1') - '0') & 0x3F) << 24))), errmsg("directory \"%s\" does not exist", location), InRecovery ? errhint("Create this directory for the tablespace before " "restarting the server.") : 0)) : (void) 0);




  else
   (errstart(20, "tablespace.c", 572, __func__, ((void *)0)) ? (errfinish (errcode_for_file_access(), errmsg("could not set permissions on directory \"%s\": %m", location))) : (void) 0);



 }

 if (InRecovery)
 {
  struct stat st;






  if (stat(location_with_version_dir, &st) == 0 && (((st.st_mode) & 0170000) == 0040000))
  {
   if (!rmtree(location_with_version_dir, ((bool) 1)))

    (errstart(19, "tablespace.c", 590, __func__, ((void *)0)) ? (errfinish (errmsg("some useless files may be left behind in old database directory \"%s\"", location_with_version_dir))) : (void) 0);


  }
 }





 if (mkdir(location_with_version_dir, 0000700) < 0)
 {
  if ((*__error()) == 17)
   (errstart(20, "tablespace.c", 604, __func__, ((void *)0)) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('5') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('6') - '0') & 0x3F) << 24))), errmsg("directory \"%s\" already in use as a tablespace", location_with_version_dir))) : (void) 0);



  else
   (errstart(20, "tablespace.c", 609, __func__, ((void *)0)) ? (errfinish (errcode_for_file_access(), errmsg("could not create directory \"%s\": %m", location_with_version_dir))) : (void) 0);



 }


 if (InRecovery)
 {
  if (unlink(linkloc) < 0 && (*__error()) != 2)
   (errstart(20, "tablespace.c", 619, __func__, ((void *)0)) ? (errfinish (errcode_for_file_access(), errmsg("could not remove symbolic link \"%s\": %m", linkloc))) : (void) 0);



 }




 if (symlink(location, linkloc) < 0)
  (errstart(20, "tablespace.c", 629, __func__, ((void *)0)) ? (errfinish (errcode_for_file_access(), errmsg("could not create symbolic link \"%s\": %m", linkloc))) : (void) 0);




 pfree(linkloc);
 pfree(location_with_version_dir);
}
# 649 "tablespace.c"
static bool
destroy_tablespace_directories(Oid tablespaceoid, bool redo)
{
 char *linkloc;
 char *linkloc_with_version_dir;
 DIR *dirdesc;
 struct dirent *de;
 char *subfile;
 struct stat st;

 linkloc_with_version_dir = MemoryContextAlloc(CurrentMemoryContext, (9 + 1 + 10 + 1 + strlen("PG_" "9.2" "_" "201204301")));

 __builtin___sprintf_chk (linkloc_with_version_dir, 0, __builtin_object_size (linkloc_with_version_dir, 2 > 1), "pg_tblspc/%u/%s", tablespaceoid, "PG_" "9.2" "_" "201204301");
# 686 "tablespace.c"
 dirdesc = AllocateDir(linkloc_with_version_dir);
 if (dirdesc == ((void *)0))
 {
  if ((*__error()) == 2)
  {
   if (!redo)
    (errstart(19, "tablespace.c", 695, __func__, ((void *)0)) ? (errfinish (errcode_for_file_access(), errmsg("could not open directory \"%s\": %m", linkloc_with_version_dir))) : (void) 0);




   goto remove_symlink;
  }
  else if (redo)
  {

   (errstart(15, "tablespace.c", 705, __func__, ((void *)0)) ? (errfinish (errcode_for_file_access(), errmsg("could not open directory \"%s\": %m", linkloc_with_version_dir))) : (void) 0);



   pfree(linkloc_with_version_dir);
   return ((bool) 0);
  }

 }

 while ((de = ReadDir(dirdesc, linkloc_with_version_dir)) != ((void *)0))
 {
  if (strcmp(de->d_name, ".") == 0 ||
   strcmp(de->d_name, "..") == 0)
   continue;

  subfile = MemoryContextAlloc(CurrentMemoryContext, (strlen(linkloc_with_version_dir) + 1 + strlen(de->d_name) + 1));
  __builtin___sprintf_chk (subfile, 0, __builtin_object_size (subfile, 2 > 1), "%s/%s", linkloc_with_version_dir, de->d_name);


  if (!redo && !directory_is_empty(subfile))
  {
   FreeDir(dirdesc);
   pfree(subfile);
   pfree(linkloc_with_version_dir);
   return ((bool) 0);
  }


  if (rmdir(subfile) < 0)
   (errstart(redo ? 15 : 20, "tablespace.c", 735, __func__, ((void *)0)) ? (errfinish (errcode_for_file_access(), errmsg("could not remove directory \"%s\": %m", subfile))) : (void) 0);




  pfree(subfile);
 }

 FreeDir(dirdesc);


 if (rmdir(linkloc_with_version_dir) < 0)
 {
  (errstart(redo ? 15 : 20, "tablespace.c", 748, __func__, ((void *)0)) ? (errfinish (errcode_for_file_access(), errmsg("could not remove directory \"%s\": %m", linkloc_with_version_dir))) : (void) 0);



  pfree(linkloc_with_version_dir);
  return ((bool) 0);
 }
# 763 "tablespace.c"
remove_symlink:
 linkloc = MemoryContextStrdup(CurrentMemoryContext, (linkloc_with_version_dir));
 get_parent_directory(linkloc);
 if (lstat(linkloc, &st) == 0 && (((st.st_mode) & 0170000) == 0040000))
 {
  if (rmdir(linkloc) < 0)
   (errstart(redo ? 15 : 20, "tablespace.c", 772, __func__, ((void *)0)) ? (errfinish (errcode_for_file_access(), errmsg("could not remove directory \"%s\": %m", linkloc))) : (void) 0);



 }
 else
 {
  if (unlink(linkloc) < 0)
   (errstart(redo ? 15 : ((*__error()) == 2 ? 19 : 20), "tablespace.c", 780, __func__, ((void *)0)) ? (errfinish (errcode_for_file_access(), errmsg("could not remove symbolic link \"%s\": %m", linkloc))) : (void) 0);



 }

 pfree(linkloc_with_version_dir);
 pfree(linkloc);

 return ((bool) 1);
}







bool
directory_is_empty(const char *path)
{
 DIR *dirdesc;
 struct dirent *de;

 dirdesc = AllocateDir(path);

 while ((de = ReadDir(dirdesc, path)) != ((void *)0))
 {
  if (strcmp(de->d_name, ".") == 0 ||
   strcmp(de->d_name, "..") == 0)
   continue;
  FreeDir(dirdesc);
  return ((bool) 0);
 }

 FreeDir(dirdesc);
 return ((bool) 1);
}





void
RenameTableSpace(const char *oldname, const char *newname)
{
 Relation rel;
 ScanKeyData entry[1];
 HeapScanDesc scan;
 HeapTuple tup;
 HeapTuple newtuple;
 Form_pg_tablespace newform;


 rel = heap_open(1213, 3);

 ScanKeyInit(&entry[0],
    1,
    3, 62,
    ((Datum) (oldname)));
 scan = heap_beginscan(rel, (&SnapshotNowData), 1, entry);
 tup = heap_getnext(scan, ForwardScanDirection);
 if (!((const void*)(tup) != ((void *)0)))
  (errstart(20, "tablespace.c", 843, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('7') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('4') - '0') & 0x3F) << 24))), errmsg("tablespace \"%s\" does not exist", oldname))) : (void) 0);




 newtuple = heap_copytuple(tup);
 newform = (Form_pg_tablespace) ((char *) ((newtuple)->t_data) + (newtuple)->t_data->t_hoff);

 heap_endscan(scan);


 if (!pg_tablespace_ownercheck(( (((newtuple)->t_data)->t_infomask & 0x0008) ? *((Oid *) ((char *)((newtuple)->t_data) + ((newtuple)->t_data)->t_hoff - sizeof(Oid))) : ((Oid) 0) ), GetUserId()))
  aclcheck_error(ACLCHECK_NO_PRIV, ACL_KIND_TABLESPACE, oldname);


 if (!allowSystemTableMods && IsReservedName(newname))
  (errstart(20, "tablespace.c", 859, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('9') - '0') & 0x3F) << 12) + (((('3') - '0') & 0x3F) << 18) + (((('9') - '0') & 0x3F) << 24))), errmsg("unacceptable tablespace name \"%s\"", newname), errdetail("The prefix \"pg_\" is reserved for system tablespaces."))) : (void) 0);





 ScanKeyInit(&entry[0],
    1,
    3, 62,
    ((Datum) (newname)));
 scan = heap_beginscan(rel, (&SnapshotNowData), 1, entry);
 tup = heap_getnext(scan, ForwardScanDirection);
 if (((const void*)(tup) != ((void *)0)))
  (errstart(20, "tablespace.c", 872, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('7') - '0') & 0x3F) << 12) + (((('1') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("tablespace \"%s\" already exists", newname))) : (void) 0);




 heap_endscan(scan);


 namestrcpy(&(newform->spcname), newname);

 simple_heap_update(rel, &newtuple->t_self, newtuple);
 CatalogUpdateIndexes(rel, newtuple);

 relation_close(rel,0);
}




void
AlterTableSpaceOwner(const char *name, Oid newOwnerId)
{
 Relation rel;
 ScanKeyData entry[1];
 HeapScanDesc scandesc;
 Form_pg_tablespace spcForm;
 HeapTuple tup;


 rel = heap_open(1213, 3);

 ScanKeyInit(&entry[0],
    1,
    3, 62,
    ((Datum) (name)));
 scandesc = heap_beginscan(rel, (&SnapshotNowData), 1, entry);
 tup = heap_getnext(scandesc, ForwardScanDirection);
 if (!((const void*)(tup) != ((void *)0)))
  (errstart(20, "tablespace.c", 909, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('7') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('4') - '0') & 0x3F) << 24))), errmsg("tablespace \"%s\" does not exist", name))) : (void) 0);



 spcForm = (Form_pg_tablespace) ((char *) ((tup)->t_data) + (tup)->t_data->t_hoff);





 if (spcForm->spcowner != newOwnerId)
 {
  Datum repl_val[4];
  bool repl_null[4];
  bool repl_repl[4];
  Acl *newAcl;
  Datum aclDatum;
  bool isNull;
  HeapTuple newtuple;


  if (!pg_tablespace_ownercheck(( (((tup)->t_data)->t_infomask & 0x0008) ? *((Oid *) ((char *)((tup)->t_data) + ((tup)->t_data)->t_hoff - sizeof(Oid))) : ((Oid) 0) ), GetUserId()))
   aclcheck_error(ACLCHECK_NOT_OWNER, ACL_KIND_TABLESPACE,
         name);


  check_is_member_of_role(GetUserId(), newOwnerId);
# 945 "tablespace.c"
  ((__builtin_object_size (repl_null, 0) != (size_t) -1) ? __builtin___memset_chk (repl_null, ((bool) 0), sizeof(repl_null), __builtin_object_size (repl_null, 0)) : __inline_memset_chk (repl_null, ((bool) 0), sizeof(repl_null)));
  ((__builtin_object_size (repl_repl, 0) != (size_t) -1) ? __builtin___memset_chk (repl_repl, ((bool) 0), sizeof(repl_repl), __builtin_object_size (repl_repl, 0)) : __inline_memset_chk (repl_repl, ((bool) 0), sizeof(repl_repl)));

  repl_repl[2 - 1] = ((bool) 1);
  repl_val[2 - 1] = ((Datum) (((Datum) (newOwnerId)) & 0xffffffff));





  aclDatum = ( ((3) > 0) ? ( ((3) > (int) (((tup)->t_data)->t_infomask2 & 0x07FF)) ? ( (*(&isNull) = ((bool) 1)), (Datum)((void *)0) ) : ( ((void)((bool) 1)), (*((&isNull)) = ((bool) 0)), (!(((tup))->t_data->t_infomask & 0x0001)) ? ( ((((rel)->rd_att)))->attrs[((3))-1]->attcacheoff >= 0 ? ( ( ((((((rel)->rd_att)))->attrs[((3))-1])->attbyval) ? ( ((((((rel)->rd_att)))->attrs[((3))-1])->attlen) == (int) sizeof(Datum) ? *((Datum *)((char *) ((tup))->t_data + ((tup))->t_data->t_hoff + ((((rel)->rd_att)))->attrs[((3))-1]->attcacheoff)) : ( ((((((rel)->rd_att)))->attrs[((3))-1])->attlen) == (int) sizeof(int32) ? ((Datum) (((Datum) (*((int32 *)((char *) ((tup))->t_data + ((tup))->t_data->t_hoff + ((((rel)->rd_att)))->attrs[((3))-1]->attcacheoff)))) & 0xffffffff)) : ( ((((((rel)->rd_att)))->attrs[((3))-1])->attlen) == (int) sizeof(int16) ? ((Datum) (((Datum) (*((int16 *)((char *) ((tup))->t_data + ((tup))->t_data->t_hoff + ((((rel)->rd_att)))->attrs[((3))-1]->attcacheoff)))) & 0x0000ffff)) : ( ((void)((bool) 1)), ((Datum) (((Datum) (*((char *)((char *) ((tup))->t_data + ((tup))->t_data->t_hoff + ((((rel)->rd_att)))->attrs[((3))-1]->attcacheoff)))) & 0x000000ff)) ) ) ) ) : ((Datum) ((char *) ((char *) ((tup))->t_data + ((tup))->t_data->t_hoff + ((((rel)->rd_att)))->attrs[((3))-1]->attcacheoff))) ) ) : nocachegetattr(((tup)), ((3)), ((((rel)->rd_att)))) ) : ( (!((((tup))->t_data->t_bits)[(((3))-1) >> 3] & (1 << ((((3))-1) & 0x07)))) ? ( (*((&isNull)) = ((bool) 1)), (Datum)((void *)0) ) : ( nocachegetattr(((tup)), ((3)), ((((rel)->rd_att)))) ) ) ) ) : heap_getsysattr((tup), (3), (((rel)->rd_att)), (&isNull)) );



  if (!isNull)
  {
   newAcl = aclnewowner(((Acl *) pg_detoast_datum((struct varlena *) ((Pointer) (aclDatum)))),
         spcForm->spcowner, newOwnerId);
   repl_repl[3 - 1] = ((bool) 1);
   repl_val[3 - 1] = ((Datum) (newAcl));
  }

  newtuple = heap_modify_tuple(tup, ((rel)->rd_att), repl_val, repl_null, repl_repl);

  simple_heap_update(rel, &newtuple->t_self, newtuple);
  CatalogUpdateIndexes(rel, newtuple);

  heap_freetuple(newtuple);


  changeDependencyOnOwner(1213, ( (((tup)->t_data)->t_infomask & 0x0008) ? *((Oid *) ((char *)((tup)->t_data) + ((tup)->t_data)->t_hoff - sizeof(Oid))) : ((Oid) 0) ),
        newOwnerId);
 }

 heap_endscan(scandesc);
 relation_close(rel,0);
}





void
AlterTableSpaceOptions(AlterTableSpaceOptionsStmt *stmt)
{
 Relation rel;
 ScanKeyData entry[1];
 HeapScanDesc scandesc;
 HeapTuple tup;
 Datum datum;
 Datum newOptions;
 Datum repl_val[4];
 bool isnull;
 bool repl_null[4];
 bool repl_repl[4];
 HeapTuple newtuple;


 rel = heap_open(1213, 3);

 ScanKeyInit(&entry[0],
    1,
    3, 62,
    ((Datum) (stmt->tablespacename)));
 scandesc = heap_beginscan(rel, (&SnapshotNowData), 1, entry);
 tup = heap_getnext(scandesc, ForwardScanDirection);
 if (!((const void*)(tup) != ((void *)0)))
  (errstart(20, "tablespace.c", 1015, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('7') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('4') - '0') & 0x3F) << 24))), errmsg("tablespace \"%s\" does not exist", stmt->tablespacename))) : (void) 0);





 if (!pg_tablespace_ownercheck(( (((tup)->t_data)->t_infomask & 0x0008) ? *((Oid *) ((char *)((tup)->t_data) + ((tup)->t_data)->t_hoff - sizeof(Oid))) : ((Oid) 0) ), GetUserId()))
  aclcheck_error(ACLCHECK_NOT_OWNER, ACL_KIND_TABLESPACE,
        stmt->tablespacename);


 datum = ( ((4) > 0) ? ( ((4) > (int) (((tup)->t_data)->t_infomask2 & 0x07FF)) ? ( (*(&isnull) = ((bool) 1)), (Datum)((void *)0) ) : ( ((void)((bool) 1)), (*((&isnull)) = ((bool) 0)), (!(((tup))->t_data->t_infomask & 0x0001)) ? ( ((((rel)->rd_att)))->attrs[((4))-1]->attcacheoff >= 0 ? ( ( ((((((rel)->rd_att)))->attrs[((4))-1])->attbyval) ? ( ((((((rel)->rd_att)))->attrs[((4))-1])->attlen) == (int) sizeof(Datum) ? *((Datum *)((char *) ((tup))->t_data + ((tup))->t_data->t_hoff + ((((rel)->rd_att)))->attrs[((4))-1]->attcacheoff)) : ( ((((((rel)->rd_att)))->attrs[((4))-1])->attlen) == (int) sizeof(int32) ? ((Datum) (((Datum) (*((int32 *)((char *) ((tup))->t_data + ((tup))->t_data->t_hoff + ((((rel)->rd_att)))->attrs[((4))-1]->attcacheoff)))) & 0xffffffff)) : ( ((((((rel)->rd_att)))->attrs[((4))-1])->attlen) == (int) sizeof(int16) ? ((Datum) (((Datum) (*((int16 *)((char *) ((tup))->t_data + ((tup))->t_data->t_hoff + ((((rel)->rd_att)))->attrs[((4))-1]->attcacheoff)))) & 0x0000ffff)) : ( ((void)((bool) 1)), ((Datum) (((Datum) (*((char *)((char *) ((tup))->t_data + ((tup))->t_data->t_hoff + ((((rel)->rd_att)))->attrs[((4))-1]->attcacheoff)))) & 0x000000ff)) ) ) ) ) : ((Datum) ((char *) ((char *) ((tup))->t_data + ((tup))->t_data->t_hoff + ((((rel)->rd_att)))->attrs[((4))-1]->attcacheoff))) ) ) : nocachegetattr(((tup)), ((4)), ((((rel)->rd_att)))) ) : ( (!((((tup))->t_data->t_bits)[(((4))-1) >> 3] & (1 << ((((4))-1) & 0x07)))) ? ( (*((&isnull)) = ((bool) 1)), (Datum)((void *)0) ) : ( nocachegetattr(((tup)), ((4)), ((((rel)->rd_att)))) ) ) ) ) : heap_getsysattr((tup), (4), (((rel)->rd_att)), (&isnull)) );

 newOptions = transformRelOptions(isnull ? (Datum) 0 : datum,
          stmt->options, ((void *)0), ((void *)0), ((bool) 0),
          stmt->isReset);
 (void) tablespace_reloptions(newOptions, ((bool) 1));


 ((__builtin_object_size (repl_null, 0) != (size_t) -1) ? __builtin___memset_chk (repl_null, ((bool) 0), sizeof(repl_null), __builtin_object_size (repl_null, 0)) : __inline_memset_chk (repl_null, ((bool) 0), sizeof(repl_null)));
 ((__builtin_object_size (repl_repl, 0) != (size_t) -1) ? __builtin___memset_chk (repl_repl, ((bool) 0), sizeof(repl_repl), __builtin_object_size (repl_repl, 0)) : __inline_memset_chk (repl_repl, ((bool) 0), sizeof(repl_repl)));
 if (newOptions != (Datum) 0)
  repl_val[4 - 1] = newOptions;
 else
  repl_null[4 - 1] = ((bool) 1);
 repl_repl[4 - 1] = ((bool) 1);
 newtuple = heap_modify_tuple(tup, ((rel)->rd_att), repl_val,
         repl_null, repl_repl);


 simple_heap_update(rel, &newtuple->t_self, newtuple);
 CatalogUpdateIndexes(rel, newtuple);
 heap_freetuple(newtuple);


 heap_endscan(scandesc);
 relation_close(rel,0);
}






bool
check_default_tablespace(char **newval, void **extra, GucSource source)
{




 if (IsTransactionState())
 {
  if (**newval != '\0' &&
   !((bool) ((get_tablespace_oid(*newval, ((bool) 1))) != ((Oid) 0))))
  {
# 1076 "tablespace.c"
   if (source == PGC_S_TEST)
   {
    (errstart(18, "tablespace.c", 1081, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('7') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('4') - '0') & 0x3F) << 24))), errmsg("tablespace \"%s\" does not exist", *newval))) : (void) 0);



   }
   else
   {
    pre_format_elog_string((*__error()), ((void *)0)), GUC_check_errdetail_string = format_elog_string("Tablespace \"%s\" does not exist.",
         *newval);
    return ((bool) 0);
   }
  }
 }

 return ((bool) 1);
}
# 1109 "tablespace.c"
Oid
GetDefaultTablespace(char relpersistence)
{
 Oid result;


 if (relpersistence == 't')
 {
  PrepareTempTablespaces();
  return GetNextTempTableSpace();
 }


 if (default_tablespace == ((void *)0) || default_tablespace[0] == '\0')
  return ((Oid) 0);
# 1132 "tablespace.c"
 result = get_tablespace_oid(default_tablespace, ((bool) 1));





 if (result == MyDatabaseTableSpace)
  result = ((Oid) 0);
 return result;
}






typedef struct
{
 int numSpcs;
 Oid tblSpcs[1];
} temp_tablespaces_extra;


bool
check_temp_tablespaces(char **newval, void **extra, GucSource source)
{
 char *rawname;
 List *namelist;


 rawname = MemoryContextStrdup(CurrentMemoryContext, (*newval));


 if (!SplitIdentifierString(rawname, ',', &namelist))
 {

  pre_format_elog_string((*__error()), ((void *)0)), GUC_check_errdetail_string = format_elog_string("List syntax is invalid.");
  pfree(rawname);
  list_free(namelist);
  return ((bool) 0);
 }






 if (IsTransactionState())
 {
  temp_tablespaces_extra *myextra;
  Oid *tblSpcs;
  int numSpcs;
  ListCell *l;


  tblSpcs = (Oid *) MemoryContextAlloc(CurrentMemoryContext, (list_length(namelist) * sizeof(Oid)));
  numSpcs = 0;
  for ((l) = list_head(namelist); (l) != ((void *)0); (l) = ((l)->next))
  {
   char *curname = (char *) ((l)->data.ptr_value);
   Oid curoid;
   AclResult aclresult;


   if (curname[0] == '\0')
   {
    tblSpcs[numSpcs++] = ((Oid) 0);
    continue;
   }
# 1212 "tablespace.c"
   curoid = get_tablespace_oid(curname, source <= PGC_S_TEST);
   if (curoid == ((Oid) 0))
   {
    if (source == PGC_S_TEST)
     (errstart(18, "tablespace.c", 1219, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('7') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('4') - '0') & 0x3F) << 24))), errmsg("tablespace \"%s\" does not exist", curname))) : (void) 0);



    continue;
   }





   if (curoid == MyDatabaseTableSpace)
   {
    tblSpcs[numSpcs++] = ((Oid) 0);
    continue;
   }


   aclresult = pg_tablespace_aclcheck(curoid, GetUserId(),
              (1<<9));
   if (aclresult != ACLCHECK_OK)
   {
    if (source >= PGC_S_INTERACTIVE)
     aclcheck_error(aclresult, ACL_KIND_TABLESPACE, curname);
    continue;
   }

   tblSpcs[numSpcs++] = curoid;
  }


  myextra = malloc(__builtin_offsetof (temp_tablespaces_extra, tblSpcs) +
       numSpcs * sizeof(Oid));
  if (!myextra)
   return ((bool) 0);
  myextra->numSpcs = numSpcs;
  ((__builtin_object_size (myextra->tblSpcs, 0) != (size_t) -1) ? __builtin___memcpy_chk (myextra->tblSpcs, tblSpcs, numSpcs * sizeof(Oid), __builtin_object_size (myextra->tblSpcs, 0)) : __inline_memcpy_chk (myextra->tblSpcs, tblSpcs, numSpcs * sizeof(Oid)));
  *extra = (void *) myextra;

  pfree(tblSpcs);
 }

 pfree(rawname);
 list_free(namelist);

 return ((bool) 1);
}


void
assign_temp_tablespaces(const char *newval, void *extra)
{
 temp_tablespaces_extra *myextra = (temp_tablespaces_extra *) extra;
# 1277 "tablespace.c"
 if (myextra)
  SetTempTablespaces(myextra->tblSpcs, myextra->numSpcs);
 else
  SetTempTablespaces(((void *)0), 0);
}
# 1290 "tablespace.c"
void
PrepareTempTablespaces(void)
{
 char *rawname;
 List *namelist;
 Oid *tblSpcs;
 int numSpcs;
 ListCell *l;


 if (TempTablespacesAreSet())
  return;
# 1310 "tablespace.c"
 if (!IsTransactionState())
  return;


 rawname = MemoryContextStrdup(CurrentMemoryContext, (temp_tablespaces));


 if (!SplitIdentifierString(rawname, ',', &namelist))
 {

  SetTempTablespaces(((void *)0), 0);
  pfree(rawname);
  list_free(namelist);
  return;
 }


 tblSpcs = (Oid *) MemoryContextAlloc(TopTransactionContext,
           list_length(namelist) * sizeof(Oid));
 numSpcs = 0;
 for ((l) = list_head(namelist); (l) != ((void *)0); (l) = ((l)->next))
 {
  char *curname = (char *) ((l)->data.ptr_value);
  Oid curoid;
  AclResult aclresult;


  if (curname[0] == '\0')
  {
   tblSpcs[numSpcs++] = ((Oid) 0);
   continue;
  }


  curoid = get_tablespace_oid(curname, ((bool) 1));
  if (curoid == ((Oid) 0))
  {

   continue;
  }





  if (curoid == MyDatabaseTableSpace)
  {
   tblSpcs[numSpcs++] = ((Oid) 0);
   continue;
  }


  aclresult = pg_tablespace_aclcheck(curoid, GetUserId(),
             (1<<9));
  if (aclresult != ACLCHECK_OK)
   continue;

  tblSpcs[numSpcs++] = curoid;
 }

 SetTempTablespaces(tblSpcs, numSpcs);

 pfree(rawname);
 list_free(namelist);
}
# 1383 "tablespace.c"
Oid
get_tablespace_oid(const char *tablespacename, bool missing_ok)
{
 Oid result;
 Relation rel;
 HeapScanDesc scandesc;
 HeapTuple tuple;
 ScanKeyData entry[1];






 rel = heap_open(1213, 1);

 ScanKeyInit(&entry[0],
    1,
    3, 62,
    ((Datum) (tablespacename)));
 scandesc = heap_beginscan(rel, (&SnapshotNowData), 1, entry);
 tuple = heap_getnext(scandesc, ForwardScanDirection);


 if (((const void*)(tuple) != ((void *)0)))
  result = ( (((tuple)->t_data)->t_infomask & 0x0008) ? *((Oid *) ((char *)((tuple)->t_data) + ((tuple)->t_data)->t_hoff - sizeof(Oid))) : ((Oid) 0) );
 else
  result = ((Oid) 0);

 heap_endscan(scandesc);
 relation_close(rel,1);

 if (!((bool) ((result) != ((Oid) 0))) && !missing_ok)
  (errstart(20, "tablespace.c", 1419, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('7') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('4') - '0') & 0x3F) << 24))), errmsg("tablespace \"%s\" does not exist", tablespacename))) : (void) 0);




 return result;
}






char *
get_tablespace_name(Oid spc_oid)
{
 char *result;
 Relation rel;
 HeapScanDesc scandesc;
 HeapTuple tuple;
 ScanKeyData entry[1];






 rel = heap_open(1213, 1);

 ScanKeyInit(&entry[0],
    (-2),
    3, 184,
    ((Datum) (((Datum) (spc_oid)) & 0xffffffff)));
 scandesc = heap_beginscan(rel, (&SnapshotNowData), 1, entry);
 tuple = heap_getnext(scandesc, ForwardScanDirection);


 if (((const void*)(tuple) != ((void *)0)))
  result = MemoryContextStrdup(CurrentMemoryContext, (((((Form_pg_tablespace) ((char *) ((tuple)->t_data) + (tuple)->t_data->t_hoff))->spcname).data)));
 else
  result = ((void *)0);

 heap_endscan(scandesc);
 relation_close(rel,1);

 return result;
}





void
tblspc_redo(XLogRecPtr lsn, XLogRecord *record)
{
 uint8 info = record->xl_info & ~0x0F;


 ;

 if (info == 0x00)
 {
  xl_tblspc_create_rec *xlrec = (xl_tblspc_create_rec *) ((char*) (record) + (((intptr_t) ((sizeof(XLogRecord))) + ((8) - 1)) & ~((intptr_t) ((8) - 1))));
  char *location = xlrec->ts_path;

  create_tablespace_directories(location, xlrec->ts_id);
 }
 else if (info == 0x10)
 {
  xl_tblspc_drop_rec *xlrec = (xl_tblspc_drop_rec *) ((char*) (record) + (((intptr_t) ((sizeof(XLogRecord))) + ((8) - 1)) & ~((intptr_t) ((8) - 1))));
# 1502 "tablespace.c"
  if (!destroy_tablespace_directories(xlrec->ts_id, ((bool) 1)))
  {
   ResolveRecoveryConflictWithTablespace(xlrec->ts_id);
# 1514 "tablespace.c"
   if (!destroy_tablespace_directories(xlrec->ts_id, ((bool) 1)))
    (errstart(15, "tablespace.c", 1519, __func__, ((void *)0)) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('5') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("directories for tablespace %u could not be removed", xlrec->ts_id), errhint("You can remove the directories manually if necessary."))) : (void) 0);




  }
 }
 else
  elog_start("tablespace.c", 1523, __func__), elog_finish(22, "tblspc_redo: unknown op code %u", info);
}

void
tblspc_desc(StringInfo buf, uint8 xl_info, char *rec)
{
 uint8 info = xl_info & ~0x0F;

 if (info == 0x00)
 {
  xl_tblspc_create_rec *xlrec = (xl_tblspc_create_rec *) rec;

  appendStringInfo(buf, "create tablespace: %u \"%s\"",
       xlrec->ts_id, xlrec->ts_path);
 }
 else if (info == 0x10)
 {
  xl_tblspc_drop_rec *xlrec = (xl_tblspc_drop_rec *) rec;

  appendStringInfo(buf, "drop tablespace: %u", xlrec->ts_id);
 }
 else
  appendStringInfo(buf, "UNKNOWN");
}

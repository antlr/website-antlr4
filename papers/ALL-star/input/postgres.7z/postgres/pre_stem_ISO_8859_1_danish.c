# 1 "stem_ISO_8859_1_danish.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "stem_ISO_8859_1_danish.c"



# 1 "header.h" 1

# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 1 3 4






# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/syslimits.h" 1 3 4
# 8 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 2 3 4







# 1 "/usr/include/limits.h" 1 3 4
# 63 "/usr/include/limits.h" 3 4
# 1 "/usr/include/sys/cdefs.h" 1 3 4
# 417 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 418 "/usr/include/sys/cdefs.h" 2 3 4
# 494 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_posix_availability.h" 1 3 4
# 495 "/usr/include/sys/cdefs.h" 2 3 4
# 64 "/usr/include/limits.h" 2 3 4
# 1 "/usr/include/machine/limits.h" 1 3 4





# 1 "/usr/include/i386/limits.h" 1 3 4
# 40 "/usr/include/i386/limits.h" 3 4
# 1 "/usr/include/i386/_limits.h" 1 3 4
# 41 "/usr/include/i386/limits.h" 2 3 4
# 7 "/usr/include/machine/limits.h" 2 3 4
# 65 "/usr/include/limits.h" 2 3 4
# 1 "/usr/include/sys/syslimits.h" 1 3 4
# 66 "/usr/include/limits.h" 2 3 4
# 16 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 2 3 4
# 3 "header.h" 2

# 1 "api.h" 1

typedef unsigned char symbol;
# 14 "api.h"
struct SN_env {
    symbol * p;
    int c; int l; int lb; int bra; int ket;
    symbol * * S;
    int * I;
    unsigned char * B;
};

extern struct SN_env * SN_create_env(int S_size, int I_size, int B_size);
extern void SN_close_env(struct SN_env * z, int S_size);

extern int SN_set_current(struct SN_env * z, int size, const symbol * s);
# 5 "header.h" 2
# 15 "header.h"
struct among
{ int s_size;
    const symbol * s;
    int substring_i;
    int result;
    int (* function)(struct SN_env *);
};

extern symbol * create_s(void);
extern void lose_s(symbol * p);

extern int skip_utf8(const symbol * p, int c, int lb, int l, int n);

extern int in_grouping_U(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);
extern int in_grouping_b_U(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);
extern int out_grouping_U(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);
extern int out_grouping_b_U(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);

extern int in_grouping(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);
extern int in_grouping_b(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);
extern int out_grouping(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);
extern int out_grouping_b(struct SN_env * z, const unsigned char * s, int min, int max, int repeat);

extern int eq_s(struct SN_env * z, int s_size, const symbol * s);
extern int eq_s_b(struct SN_env * z, int s_size, const symbol * s);
extern int eq_v(struct SN_env * z, const symbol * p);
extern int eq_v_b(struct SN_env * z, const symbol * p);

extern int find_among(struct SN_env * z, const struct among * v, int v_size);
extern int find_among_b(struct SN_env * z, const struct among * v, int v_size);

extern int replace_s(struct SN_env * z, int c_bra, int c_ket, int s_size, const symbol * s, int * adjustment);
extern int slice_from_s(struct SN_env * z, int s_size, const symbol * s);
extern int slice_from_v(struct SN_env * z, const symbol * p);
extern int slice_del(struct SN_env * z);

extern int insert_s(struct SN_env * z, int bra, int ket, int s_size, const symbol * s);
extern int insert_v(struct SN_env * z, int bra, int ket, const symbol * p);

extern symbol * slice_to(struct SN_env * z, symbol * p);
extern symbol * assign_to(struct SN_env * z, symbol * p);

extern void debug(struct SN_env * z, int number, int line_count);
# 5 "stem_ISO_8859_1_danish.c" 2




extern int danish_ISO_8859_1_stem(struct SN_env * z);



static int r_undouble(struct SN_env * z);
static int r_other_suffix(struct SN_env * z);
static int r_consonant_pair(struct SN_env * z);
static int r_main_suffix(struct SN_env * z);
static int r_mark_regions(struct SN_env * z);





extern struct SN_env * danish_ISO_8859_1_create_env(void);
extern void danish_ISO_8859_1_close_env(struct SN_env * z);





static const symbol s_0_0[3] = { 'h', 'e', 'd' };
static const symbol s_0_1[5] = { 'e', 't', 'h', 'e', 'd' };
static const symbol s_0_2[4] = { 'e', 'r', 'e', 'd' };
static const symbol s_0_3[1] = { 'e' };
static const symbol s_0_4[5] = { 'e', 'r', 'e', 'd', 'e' };
static const symbol s_0_5[4] = { 'e', 'n', 'd', 'e' };
static const symbol s_0_6[6] = { 'e', 'r', 'e', 'n', 'd', 'e' };
static const symbol s_0_7[3] = { 'e', 'n', 'e' };
static const symbol s_0_8[4] = { 'e', 'r', 'n', 'e' };
static const symbol s_0_9[3] = { 'e', 'r', 'e' };
static const symbol s_0_10[2] = { 'e', 'n' };
static const symbol s_0_11[5] = { 'h', 'e', 'd', 'e', 'n' };
static const symbol s_0_12[4] = { 'e', 'r', 'e', 'n' };
static const symbol s_0_13[2] = { 'e', 'r' };
static const symbol s_0_14[5] = { 'h', 'e', 'd', 'e', 'r' };
static const symbol s_0_15[4] = { 'e', 'r', 'e', 'r' };
static const symbol s_0_16[1] = { 's' };
static const symbol s_0_17[4] = { 'h', 'e', 'd', 's' };
static const symbol s_0_18[2] = { 'e', 's' };
static const symbol s_0_19[5] = { 'e', 'n', 'd', 'e', 's' };
static const symbol s_0_20[7] = { 'e', 'r', 'e', 'n', 'd', 'e', 's' };
static const symbol s_0_21[4] = { 'e', 'n', 'e', 's' };
static const symbol s_0_22[5] = { 'e', 'r', 'n', 'e', 's' };
static const symbol s_0_23[4] = { 'e', 'r', 'e', 's' };
static const symbol s_0_24[3] = { 'e', 'n', 's' };
static const symbol s_0_25[6] = { 'h', 'e', 'd', 'e', 'n', 's' };
static const symbol s_0_26[5] = { 'e', 'r', 'e', 'n', 's' };
static const symbol s_0_27[3] = { 'e', 'r', 's' };
static const symbol s_0_28[3] = { 'e', 't', 's' };
static const symbol s_0_29[5] = { 'e', 'r', 'e', 't', 's' };
static const symbol s_0_30[2] = { 'e', 't' };
static const symbol s_0_31[4] = { 'e', 'r', 'e', 't' };

static const struct among a_0[32] =
{
         { 3, s_0_0, -1, 1, 0},
         { 5, s_0_1, 0, 1, 0},
         { 4, s_0_2, -1, 1, 0},
         { 1, s_0_3, -1, 1, 0},
         { 5, s_0_4, 3, 1, 0},
         { 4, s_0_5, 3, 1, 0},
         { 6, s_0_6, 5, 1, 0},
         { 3, s_0_7, 3, 1, 0},
         { 4, s_0_8, 3, 1, 0},
         { 3, s_0_9, 3, 1, 0},
         { 2, s_0_10, -1, 1, 0},
         { 5, s_0_11, 10, 1, 0},
         { 4, s_0_12, 10, 1, 0},
         { 2, s_0_13, -1, 1, 0},
         { 5, s_0_14, 13, 1, 0},
         { 4, s_0_15, 13, 1, 0},
         { 1, s_0_16, -1, 2, 0},
         { 4, s_0_17, 16, 1, 0},
         { 2, s_0_18, 16, 1, 0},
         { 5, s_0_19, 18, 1, 0},
         { 7, s_0_20, 19, 1, 0},
         { 4, s_0_21, 18, 1, 0},
         { 5, s_0_22, 18, 1, 0},
         { 4, s_0_23, 18, 1, 0},
         { 3, s_0_24, 16, 1, 0},
         { 6, s_0_25, 24, 1, 0},
         { 5, s_0_26, 24, 1, 0},
         { 3, s_0_27, 16, 1, 0},
         { 3, s_0_28, 16, 1, 0},
         { 5, s_0_29, 28, 1, 0},
         { 2, s_0_30, -1, 1, 0},
         { 4, s_0_31, 30, 1, 0}
};

static const symbol s_1_0[2] = { 'g', 'd' };
static const symbol s_1_1[2] = { 'd', 't' };
static const symbol s_1_2[2] = { 'g', 't' };
static const symbol s_1_3[2] = { 'k', 't' };

static const struct among a_1[4] =
{
         { 2, s_1_0, -1, -1, 0},
         { 2, s_1_1, -1, -1, 0},
         { 2, s_1_2, -1, -1, 0},
         { 2, s_1_3, -1, -1, 0}
};

static const symbol s_2_0[2] = { 'i', 'g' };
static const symbol s_2_1[3] = { 'l', 'i', 'g' };
static const symbol s_2_2[4] = { 'e', 'l', 'i', 'g' };
static const symbol s_2_3[3] = { 'e', 'l', 's' };
static const symbol s_2_4[4] = { 'l', 0xF8, 's', 't' };

static const struct among a_2[5] =
{
         { 2, s_2_0, -1, 1, 0},
         { 3, s_2_1, 0, 1, 0},
         { 4, s_2_2, 1, 1, 0},
         { 3, s_2_3, -1, 1, 0},
         { 4, s_2_4, -1, 2, 0}
};

static const unsigned char g_v[] = { 17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 48, 0, 128 };

static const unsigned char g_s_ending[] = { 239, 254, 42, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16 };

static const symbol s_0[] = { 's', 't' };
static const symbol s_1[] = { 'i', 'g' };
static const symbol s_2[] = { 'l', 0xF8, 's' };

static int r_mark_regions(struct SN_env * z) {
    z->I[0] = z->l;
    { int c_test = z->c;
        { int ret = z->c + 3;
            if (0 > ret || ret > z->l) return 0;
            z->c = ret;
        }
        z->I[1] = z->c;
        z->c = c_test;
    }
    if (out_grouping(z, g_v, 97, 248, 1) < 0) return 0;
    {
        int ret = in_grouping(z, g_v, 97, 248, 1);
        if (ret < 0) return 0;
        z->c += ret;
    }
    z->I[0] = z->c;

    if (!(z->I[0] < z->I[1])) goto lab0;
    z->I[0] = z->I[1];
lab0:
    return 1;
}

static int r_main_suffix(struct SN_env * z) {
    int among_var;
    { int mlimit;
        int m1 = z->l - z->c; (void)m1;
        if (z->c < z->I[0]) return 0;
        z->c = z->I[0];
        mlimit = z->lb; z->lb = z->c;
        z->c = z->l - m1;
        z->ket = z->c;
        if (z->c <= z->lb || z->p[z->c - 1] >> 5 != 3 || !((1851440 >> (z->p[z->c - 1] & 0x1f)) & 1)) { z->lb = mlimit; return 0; }
        among_var = find_among_b(z, a_0, 32);
        if (!(among_var)) { z->lb = mlimit; return 0; }
        z->bra = z->c;
        z->lb = mlimit;
    }
    switch(among_var) {
        case 0: return 0;
        case 1:
            { int ret = slice_del(z);
                if (ret < 0) return ret;
            }
            break;
        case 2:
            if (in_grouping_b(z, g_s_ending, 97, 229, 0)) return 0;
            { int ret = slice_del(z);
                if (ret < 0) return ret;
            }
            break;
    }
    return 1;
}

static int r_consonant_pair(struct SN_env * z) {
    { int m_test = z->l - z->c;
        { int mlimit;
            int m1 = z->l - z->c; (void)m1;
            if (z->c < z->I[0]) return 0;
            z->c = z->I[0];
            mlimit = z->lb; z->lb = z->c;
            z->c = z->l - m1;
            z->ket = z->c;
            if (z->c - 1 <= z->lb || (z->p[z->c - 1] != 100 && z->p[z->c - 1] != 116)) { z->lb = mlimit; return 0; }
            if (!(find_among_b(z, a_1, 4))) { z->lb = mlimit; return 0; }
            z->bra = z->c;
            z->lb = mlimit;
        }
        z->c = z->l - m_test;
    }
    if (z->c <= z->lb) return 0;
    z->c--;
    z->bra = z->c;
    { int ret = slice_del(z);
        if (ret < 0) return ret;
    }
    return 1;
}

static int r_other_suffix(struct SN_env * z) {
    int among_var;
    { int m1 = z->l - z->c; (void)m1;
        z->ket = z->c;
        if (!(eq_s_b(z, 2, s_0))) goto lab0;
        z->bra = z->c;
        if (!(eq_s_b(z, 2, s_1))) goto lab0;
        { int ret = slice_del(z);
            if (ret < 0) return ret;
        }
    lab0:
        z->c = z->l - m1;
    }
    { int mlimit;
        int m2 = z->l - z->c; (void)m2;
        if (z->c < z->I[0]) return 0;
        z->c = z->I[0];
        mlimit = z->lb; z->lb = z->c;
        z->c = z->l - m2;
        z->ket = z->c;
        if (z->c - 1 <= z->lb || z->p[z->c - 1] >> 5 != 3 || !((1572992 >> (z->p[z->c - 1] & 0x1f)) & 1)) { z->lb = mlimit; return 0; }
        among_var = find_among_b(z, a_2, 5);
        if (!(among_var)) { z->lb = mlimit; return 0; }
        z->bra = z->c;
        z->lb = mlimit;
    }
    switch(among_var) {
        case 0: return 0;
        case 1:
            { int ret = slice_del(z);
                if (ret < 0) return ret;
            }
            { int m3 = z->l - z->c; (void)m3;
                { int ret = r_consonant_pair(z);
                    if (ret == 0) goto lab1;
                    if (ret < 0) return ret;
                }
            lab1:
                z->c = z->l - m3;
            }
            break;
        case 2:
            { int ret = slice_from_s(z, 3, s_2);
                if (ret < 0) return ret;
            }
            break;
    }
    return 1;
}

static int r_undouble(struct SN_env * z) {
    { int mlimit;
        int m1 = z->l - z->c; (void)m1;
        if (z->c < z->I[0]) return 0;
        z->c = z->I[0];
        mlimit = z->lb; z->lb = z->c;
        z->c = z->l - m1;
        z->ket = z->c;
        if (out_grouping_b(z, g_v, 97, 248, 0)) { z->lb = mlimit; return 0; }
        z->bra = z->c;
        z->S[0] = slice_to(z, z->S[0]);
        if (z->S[0] == 0) return -1;
        z->lb = mlimit;
    }
    if (!(eq_v_b(z, z->S[0]))) return 0;
    { int ret = slice_del(z);
        if (ret < 0) return ret;
    }
    return 1;
}

extern int danish_ISO_8859_1_stem(struct SN_env * z) {
    { int c1 = z->c;
        { int ret = r_mark_regions(z);
            if (ret == 0) goto lab0;
            if (ret < 0) return ret;
        }
    lab0:
        z->c = c1;
    }
    z->lb = z->c; z->c = z->l;

    { int m2 = z->l - z->c; (void)m2;
        { int ret = r_main_suffix(z);
            if (ret == 0) goto lab1;
            if (ret < 0) return ret;
        }
    lab1:
        z->c = z->l - m2;
    }
    { int m3 = z->l - z->c; (void)m3;
        { int ret = r_consonant_pair(z);
            if (ret == 0) goto lab2;
            if (ret < 0) return ret;
        }
    lab2:
        z->c = z->l - m3;
    }
    { int m4 = z->l - z->c; (void)m4;
        { int ret = r_other_suffix(z);
            if (ret == 0) goto lab3;
            if (ret < 0) return ret;
        }
    lab3:
        z->c = z->l - m4;
    }
    { int m5 = z->l - z->c; (void)m5;
        { int ret = r_undouble(z);
            if (ret == 0) goto lab4;
            if (ret < 0) return ret;
        }
    lab4:
        z->c = z->l - m5;
    }
    z->c = z->lb;
    return 1;
}

extern struct SN_env * danish_ISO_8859_1_create_env(void) { return SN_create_env(1, 2, 0); }

extern void danish_ISO_8859_1_close_env(struct SN_env * z) { SN_close_env(z, 1); }

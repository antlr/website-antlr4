# 1 "qsort_tuple.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "qsort_tuple.c"
# 45 "qsort_tuple.c"
static void
swapfunc(SortTuple *a, SortTuple *b, size_t n)
{
 do
 {
  SortTuple t = *a;
  *a++ = *b;
  *b++ = t;
 } while (--n > 0);
}
# 64 "qsort_tuple.c"
static SortTuple *
med3_tuple(SortTuple *a, SortTuple *b, SortTuple *c, SortTupleComparator cmp_tuple, Tuplesortstate *state)
{
 return cmp_tuple(a, b, state) < 0 ?
  (cmp_tuple(b, c, state) < 0 ? b :
   (cmp_tuple(a, c, state) < 0 ? c : a))
  : (cmp_tuple(b, c, state) > 0 ? b :
   (cmp_tuple(a, c, state) < 0 ? a : c));
}

static void
qsort_tuple(SortTuple *a, size_t n, SortTupleComparator cmp_tuple, Tuplesortstate *state)
{
 SortTuple *pa,
      *pb,
      *pc,
      *pd,
      *pl,
      *pm,
      *pn;
 int d,
    r,
    presorted;

loop:
 CHECK_FOR_INTERRUPTS();
 if (n < 7)
 {
  for (pm = a + 1; pm < a + n; pm++)
   for (pl = pm; pl > a && cmp_tuple(pl - 1, pl, state) > 0; pl--)
    do { SortTuple t = *(pl); *(pl) = *(pl - 1); *(pl - 1) = t; } while (0);;
  return;
 }
 presorted = 1;
 for (pm = a + 1; pm < a + n; pm++)
 {
  CHECK_FOR_INTERRUPTS();
  if (cmp_tuple(pm - 1, pm, state) > 0)
  {
   presorted = 0;
   break;
  }
 }
 if (presorted)
  return;
 pm = a + (n / 2);
 if (n > 7)
 {
  pl = a;
  pn = a + (n - 1);
  if (n > 40)
  {
   d = (n / 8);
   pl = med3_tuple(pl, pl + d, pl + 2 * d, cmp_tuple, state);
   pm = med3_tuple(pm - d, pm, pm + d, cmp_tuple, state);
   pn = med3_tuple(pn - 2 * d, pn - d, pn, cmp_tuple, state);
  }
  pm = med3_tuple(pl, pm, pn, cmp_tuple, state);
 }
 do { SortTuple t = *(a); *(a) = *(pm); *(pm) = t; } while (0);;
 pa = pb = a + 1;
 pc = pd = a + (n - 1);
 for (;;)
 {
  while (pb <= pc && (r = cmp_tuple(pb, a, state)) <= 0)
  {
   CHECK_FOR_INTERRUPTS();
   if (r == 0)
   {
    do { SortTuple t = *(pa); *(pa) = *(pb); *(pb) = t; } while (0);;
    pa++;
   }
   pb++;
  }
  while (pb <= pc && (r = cmp_tuple(pc, a, state)) >= 0)
  {
   CHECK_FOR_INTERRUPTS();
   if (r == 0)
   {
    do { SortTuple t = *(pc); *(pc) = *(pd); *(pd) = t; } while (0);;
    pd--;
   }
   pc--;
  }
  if (pb > pc)
   break;
  do { SortTuple t = *(pb); *(pb) = *(pc); *(pc) = t; } while (0);;
  pb++;
  pc--;
 }
 pn = a + n;
 r = Min(pa - a, pb - pa);
 if ((r) > 0) swapfunc((a), (pb - r), (size_t)(r));
 r = Min(pd - pc, pn - pd - 1);
 if ((r) > 0) swapfunc((pb), (pn - r), (size_t)(r));
 if ((r = pb - pa) > 1)
  qsort_tuple(a, r, cmp_tuple, state);
 if ((r = pd - pc) > 1)
 {

  a = pn - r;
  n = r;
  goto loop;
 }

}




static SortTuple *
med3_ssup(SortTuple *a, SortTuple *b, SortTuple *c, SortSupport ssup)
{
 return ApplySortComparator((a)->datum1, (a)->isnull1, (b)->datum1, (b)->isnull1, ssup) < 0 ?
  (ApplySortComparator((b)->datum1, (b)->isnull1, (c)->datum1, (c)->isnull1, ssup) < 0 ? b :
   (ApplySortComparator((a)->datum1, (a)->isnull1, (c)->datum1, (c)->isnull1, ssup) < 0 ? c : a))
  : (ApplySortComparator((b)->datum1, (b)->isnull1, (c)->datum1, (c)->isnull1, ssup) > 0 ? b :
   (ApplySortComparator((a)->datum1, (a)->isnull1, (c)->datum1, (c)->isnull1, ssup) < 0 ? a : c));
}

static void
qsort_ssup(SortTuple *a, size_t n, SortSupport ssup)
{
 SortTuple *pa,
      *pb,
      *pc,
      *pd,
      *pl,
      *pm,
      *pn;
 int d,
    r,
    presorted;

loop:
 CHECK_FOR_INTERRUPTS();
 if (n < 7)
 {
  for (pm = a + 1; pm < a + n; pm++)
   for (pl = pm; pl > a && ApplySortComparator((pl - 1)->datum1, (pl - 1)->isnull1, (pl)->datum1, (pl)->isnull1, ssup) > 0; pl--)
    do { SortTuple t = *(pl); *(pl) = *(pl - 1); *(pl - 1) = t; } while (0);;
  return;
 }
 presorted = 1;
 for (pm = a + 1; pm < a + n; pm++)
 {
  CHECK_FOR_INTERRUPTS();
  if (ApplySortComparator((pm - 1)->datum1, (pm - 1)->isnull1, (pm)->datum1, (pm)->isnull1, ssup) > 0)
  {
   presorted = 0;
   break;
  }
 }
 if (presorted)
  return;
 pm = a + (n / 2);
 if (n > 7)
 {
  pl = a;
  pn = a + (n - 1);
  if (n > 40)
  {
   d = (n / 8);
   pl = med3_ssup(pl, pl + d, pl + 2 * d, ssup);
   pm = med3_ssup(pm - d, pm, pm + d, ssup);
   pn = med3_ssup(pn - 2 * d, pn - d, pn, ssup);
  }
  pm = med3_ssup(pl, pm, pn, ssup);
 }
 do { SortTuple t = *(a); *(a) = *(pm); *(pm) = t; } while (0);;
 pa = pb = a + 1;
 pc = pd = a + (n - 1);
 for (;;)
 {
  while (pb <= pc && (r = ApplySortComparator((pb)->datum1, (pb)->isnull1, (a)->datum1, (a)->isnull1, ssup)) <= 0)
  {
   CHECK_FOR_INTERRUPTS();
   if (r == 0)
   {
    do { SortTuple t = *(pa); *(pa) = *(pb); *(pb) = t; } while (0);;
    pa++;
   }
   pb++;
  }
  while (pb <= pc && (r = ApplySortComparator((pc)->datum1, (pc)->isnull1, (a)->datum1, (a)->isnull1, ssup)) >= 0)
  {
   CHECK_FOR_INTERRUPTS();
   if (r == 0)
   {
    do { SortTuple t = *(pc); *(pc) = *(pd); *(pd) = t; } while (0);;
    pd--;
   }
   pc--;
  }
  if (pb > pc)
   break;
  do { SortTuple t = *(pb); *(pb) = *(pc); *(pc) = t; } while (0);;
  pb++;
  pc--;
 }
 pn = a + n;
 r = Min(pa - a, pb - pa);
 if ((r) > 0) swapfunc((a), (pb - r), (size_t)(r));
 r = Min(pd - pc, pn - pd - 1);
 if ((r) > 0) swapfunc((pb), (pn - r), (size_t)(r));
 if ((r = pb - pa) > 1)
  qsort_ssup(a, r, ssup);
 if ((r = pd - pc) > 1)
 {

  a = pn - r;
  n = r;
  goto loop;
 }

}

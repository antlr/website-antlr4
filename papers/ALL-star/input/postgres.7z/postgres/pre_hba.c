# 1 "hba.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "hba.c"
# 17 "hba.c"
# 1 "postgres.h" 1
# 47 "postgres.h"
# 1 "c.h" 1
# 53 "c.h"
# 1 "pg_config.h" 1
# 54 "c.h" 2
# 1 "pg_config_manual.h" 1
# 55 "c.h" 2


# 1 "pg_config_os.h" 1
# 58 "c.h" 2

# 1 "postgres_ext.h" 1
# 29 "postgres_ext.h"
typedef unsigned int Oid;
# 60 "c.h" 2







# 1 "/usr/include/stdio.h" 1 3 4
# 64 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/sys/cdefs.h" 1 3 4
# 417 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 418 "/usr/include/sys/cdefs.h" 2 3 4
# 494 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_posix_availability.h" 1 3 4
# 495 "/usr/include/sys/cdefs.h" 2 3 4
# 65 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/Availability.h" 1 3 4
# 141 "/usr/include/Availability.h" 3 4
# 1 "/usr/include/AvailabilityInternal.h" 1 3 4
# 142 "/usr/include/Availability.h" 2 3 4
# 66 "/usr/include/stdio.h" 2 3 4

# 1 "/usr/include/_types.h" 1 3 4
# 27 "/usr/include/_types.h" 3 4
# 1 "/usr/include/sys/_types.h" 1 3 4
# 33 "/usr/include/sys/_types.h" 3 4
# 1 "/usr/include/machine/_types.h" 1 3 4
# 32 "/usr/include/machine/_types.h" 3 4
# 1 "/usr/include/i386/_types.h" 1 3 4
# 37 "/usr/include/i386/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 70 "/usr/include/i386/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;


typedef long int __darwin_ptrdiff_t;





typedef long unsigned int __darwin_size_t;





typedef __builtin_va_list __darwin_va_list;





typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 33 "/usr/include/machine/_types.h" 2 3 4
# 34 "/usr/include/sys/_types.h" 2 3 4
# 58 "/usr/include/sys/_types.h" 3 4
struct __darwin_pthread_handler_rec
{
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};
struct _opaque_pthread_attr_t { long __sig; char __opaque[56]; };
struct _opaque_pthread_cond_t { long __sig; char __opaque[40]; };
struct _opaque_pthread_condattr_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_mutex_t { long __sig; char __opaque[56]; };
struct _opaque_pthread_mutexattr_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_once_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_rwlock_t { long __sig; char __opaque[192]; };
struct _opaque_pthread_rwlockattr_t { long __sig; char __opaque[16]; };
struct _opaque_pthread_t { long __sig; struct __darwin_pthread_handler_rec *__cleanup_stack; char __opaque[1168]; };
# 94 "/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef struct _opaque_pthread_attr_t
   __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t
   __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t
   __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t
   __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t
   __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t
   __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t
   __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t
   __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t
   *__darwin_pthread_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];
# 28 "/usr/include/_types.h" 2 3 4
# 39 "/usr/include/_types.h" 3 4
typedef int __darwin_nl_item;
typedef int __darwin_wctrans_t;

typedef __uint32_t __darwin_wctype_t;
# 68 "/usr/include/stdio.h" 2 3 4





typedef __darwin_va_list va_list;




typedef __darwin_size_t size_t;






typedef __darwin_off_t fpos_t;
# 96 "/usr/include/stdio.h" 3 4
struct __sbuf {
 unsigned char *_base;
 int _size;
};


struct __sFILEX;
# 130 "/usr/include/stdio.h" 3 4
typedef struct __sFILE {
 unsigned char *_p;
 int _r;
 int _w;
 short _flags;
 short _file;
 struct __sbuf _bf;
 int _lbfsize;


 void *_cookie;
 int (*_close)(void *);
 int (*_read) (void *, char *, int);
 fpos_t (*_seek) (void *, fpos_t, int);
 int (*_write)(void *, const char *, int);


 struct __sbuf _ub;
 struct __sFILEX *_extra;
 int _ur;


 unsigned char _ubuf[3];
 unsigned char _nbuf[1];


 struct __sbuf _lb;


 int _blksize;
 fpos_t _offset;
} FILE;


extern FILE *__stdinp;
extern FILE *__stdoutp;
extern FILE *__stderrp;

# 238 "/usr/include/stdio.h" 3 4

void clearerr(FILE *);
int fclose(FILE *);
int feof(FILE *);
int ferror(FILE *);
int fflush(FILE *);
int fgetc(FILE *);
int fgetpos(FILE * , fpos_t *);
char *fgets(char * , int, FILE *);



FILE *fopen(const char * , const char * ) __asm("_" "fopen" );

int fprintf(FILE * , const char * , ...) __attribute__((__format__ (__printf__, 2, 3)));
int fputc(int, FILE *);
int fputs(const char * , FILE * ) __asm("_" "fputs" );
size_t fread(void * , size_t, size_t, FILE * );
FILE *freopen(const char * , const char * ,
                 FILE * ) __asm("_" "freopen" );
int fscanf(FILE * , const char * , ...) __attribute__((__format__ (__scanf__, 2, 3)));
int fseek(FILE *, long, int);
int fsetpos(FILE *, const fpos_t *);
long ftell(FILE *);
size_t fwrite(const void * , size_t, size_t, FILE * ) __asm("_" "fwrite" );
int getc(FILE *);
int getchar(void);
char *gets(char *);
void perror(const char *);
int printf(const char * , ...) __attribute__((__format__ (__printf__, 1, 2)));
int putc(int, FILE *);
int putchar(int);
int puts(const char *);
int remove(const char *);
int rename (const char *, const char *);
void rewind(FILE *);
int scanf(const char * , ...) __attribute__((__format__ (__scanf__, 1, 2)));
void setbuf(FILE * , char * );
int setvbuf(FILE * , char * , int, size_t);
int sprintf(char * , const char * , ...) __attribute__((__format__ (__printf__, 2, 3)));
int sscanf(const char * , const char * , ...) __attribute__((__format__ (__scanf__, 2, 3)));
FILE *tmpfile(void);
char *tmpnam(char *);
int ungetc(int, FILE *);
int vfprintf(FILE * , const char * , va_list) __attribute__((__format__ (__printf__, 2, 0)));
int vprintf(const char * , va_list) __attribute__((__format__ (__printf__, 1, 0)));
int vsprintf(char * , const char * , va_list) __attribute__((__format__ (__printf__, 2, 0)));

# 296 "/usr/include/stdio.h" 3 4




char *ctermid(char *);





FILE *fdopen(int, const char *) __asm("_" "fdopen" );

int fileno(FILE *);

# 318 "/usr/include/stdio.h" 3 4

int pclose(FILE *);



FILE *popen(const char *, const char *) __asm("_" "popen" );


# 340 "/usr/include/stdio.h" 3 4

int __srget(FILE *);
int __svfscanf(FILE *, const char *, va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int __swbuf(int, FILE *);








static __inline int __sputc(int _c, FILE *_p) {
 if (--_p->_w >= 0 || (_p->_w >= _p->_lbfsize && (char)_c != '\n'))
  return (*_p->_p++ = _c);
 else
  return (__swbuf(_c, _p));
}
# 377 "/usr/include/stdio.h" 3 4

void flockfile(FILE *);
int ftrylockfile(FILE *);
void funlockfile(FILE *);
int getc_unlocked(FILE *);
int getchar_unlocked(void);
int putc_unlocked(int, FILE *);
int putchar_unlocked(int);



int getw(FILE *);
int putw(int, FILE *);


char *tempnam(const char *, const char *) __asm("_" "tempnam" );

# 414 "/usr/include/stdio.h" 3 4
typedef __darwin_off_t off_t;



int fseeko(FILE *, off_t, int);
off_t ftello(FILE *);





int snprintf(char * , size_t, const char * , ...) __attribute__((__format__ (__printf__, 3, 4)));
int vfscanf(FILE * , const char * , va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int vscanf(const char * , va_list) __attribute__((__format__ (__scanf__, 1, 0)));
int vsnprintf(char * , size_t, const char * , va_list) __attribute__((__format__ (__printf__, 3, 0)));
int vsscanf(const char * , const char * , va_list) __attribute__((__format__ (__scanf__, 2, 0)));

# 442 "/usr/include/stdio.h" 3 4
typedef __darwin_ssize_t ssize_t;



int dprintf(int, const char * , ...) __attribute__((__format__ (__printf__, 2, 3))) __attribute__((visibility("default")));
int vdprintf(int, const char * , va_list) __attribute__((__format__ (__printf__, 2, 0))) __attribute__((visibility("default")));
ssize_t getdelim(char ** , size_t * , int, FILE * ) __attribute__((visibility("default")));
ssize_t getline(char ** , size_t * , FILE * ) __attribute__((visibility("default")));









extern const int sys_nerr;
extern const char *const sys_errlist[];

int asprintf(char **, const char *, ...) __attribute__((__format__ (__printf__, 2, 3)));
char *ctermid_r(char *);
char *fgetln(FILE *, size_t *);
const char *fmtcheck(const char *, const char *);
int fpurge(FILE *);
void setbuffer(FILE *, char *, int);
int setlinebuf(FILE *);
int vasprintf(char **, const char *, va_list) __attribute__((__format__ (__printf__, 2, 0)));
FILE *zopen(const char *, const char *, int);





FILE *funopen(const void *,
                 int (*)(void *, char *, int),
                 int (*)(void *, const char *, int),
                 fpos_t (*)(void *, fpos_t, int),
                 int (*)(void *));

# 499 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/secure/_stdio.h" 1 3 4
# 31 "/usr/include/secure/_stdio.h" 3 4
# 1 "/usr/include/secure/_common.h" 1 3 4
# 32 "/usr/include/secure/_stdio.h" 2 3 4
# 45 "/usr/include/secure/_stdio.h" 3 4
extern int __sprintf_chk (char * , int, size_t,
     const char * , ...)
  ;




extern int __snprintf_chk (char * , size_t, int, size_t,
      const char * , ...)
  ;





extern int __vsprintf_chk (char * , int, size_t,
      const char * , va_list)
  ;




extern int __vsnprintf_chk (char * , size_t, int, size_t,
       const char * , va_list)
  ;
# 500 "/usr/include/stdio.h" 2 3 4
# 68 "c.h" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 65 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/sys/wait.h" 1 3 4
# 79 "/usr/include/sys/wait.h" 3 4
typedef enum {
 P_ALL,
 P_PID,
 P_PGID
} idtype_t;






typedef __darwin_pid_t pid_t;




typedef __darwin_id_t id_t;
# 116 "/usr/include/sys/wait.h" 3 4
# 1 "/usr/include/sys/signal.h" 1 3 4
# 73 "/usr/include/sys/signal.h" 3 4
# 1 "/usr/include/sys/appleapiopts.h" 1 3 4
# 74 "/usr/include/sys/signal.h" 2 3 4







# 1 "/usr/include/machine/signal.h" 1 3 4
# 32 "/usr/include/machine/signal.h" 3 4
# 1 "/usr/include/i386/signal.h" 1 3 4
# 39 "/usr/include/i386/signal.h" 3 4
typedef int sig_atomic_t;
# 55 "/usr/include/i386/signal.h" 3 4
# 1 "/usr/include/i386/_structs.h" 1 3 4
# 56 "/usr/include/i386/signal.h" 2 3 4
# 33 "/usr/include/machine/signal.h" 2 3 4
# 82 "/usr/include/sys/signal.h" 2 3 4
# 148 "/usr/include/sys/signal.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 57 "/usr/include/sys/_structs.h" 3 4
# 1 "/usr/include/machine/_structs.h" 1 3 4
# 29 "/usr/include/machine/_structs.h" 3 4
# 1 "/usr/include/i386/_structs.h" 1 3 4
# 38 "/usr/include/i386/_structs.h" 3 4
# 1 "/usr/include/mach/i386/_structs.h" 1 3 4
# 43 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_thread_state
{
    unsigned int __eax;
    unsigned int __ebx;
    unsigned int __ecx;
    unsigned int __edx;
    unsigned int __edi;
    unsigned int __esi;
    unsigned int __ebp;
    unsigned int __esp;
    unsigned int __ss;
    unsigned int __eflags;
    unsigned int __eip;
    unsigned int __cs;
    unsigned int __ds;
    unsigned int __es;
    unsigned int __fs;
    unsigned int __gs;
};
# 89 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_fp_control
{
    unsigned short __invalid :1,
        __denorm :1,
    __zdiv :1,
    __ovrfl :1,
    __undfl :1,
    __precis :1,
      :2,
    __pc :2,





    __rc :2,






             :1,
      :3;
};
typedef struct __darwin_fp_control __darwin_fp_control_t;
# 147 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_fp_status
{
    unsigned short __invalid :1,
        __denorm :1,
    __zdiv :1,
    __ovrfl :1,
    __undfl :1,
    __precis :1,
    __stkflt :1,
    __errsumm :1,
    __c0 :1,
    __c1 :1,
    __c2 :1,
    __tos :3,
    __c3 :1,
    __busy :1;
};
typedef struct __darwin_fp_status __darwin_fp_status_t;
# 191 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_mmst_reg
{
 char __mmst_reg[10];
 char __mmst_rsrv[6];
};
# 210 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_xmm_reg
{
 char __xmm_reg[16];
};
# 232 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_float_state
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;
 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;
 __uint16_t __fpu_rsrv2;
 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;
 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 char __fpu_rsrv4[14*16];
 int __fpu_reserved1;
};


struct __darwin_i386_avx_state
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;
 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;
 __uint16_t __fpu_rsrv2;
 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;
 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 char __fpu_rsrv4[14*16];
 int __fpu_reserved1;
 char __avx_reserved1[64];
 struct __darwin_xmm_reg __fpu_ymmh0;
 struct __darwin_xmm_reg __fpu_ymmh1;
 struct __darwin_xmm_reg __fpu_ymmh2;
 struct __darwin_xmm_reg __fpu_ymmh3;
 struct __darwin_xmm_reg __fpu_ymmh4;
 struct __darwin_xmm_reg __fpu_ymmh5;
 struct __darwin_xmm_reg __fpu_ymmh6;
 struct __darwin_xmm_reg __fpu_ymmh7;
};
# 402 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_exception_state
{
 __uint16_t __trapno;
 __uint16_t __cpu;
 __uint32_t __err;
 __uint32_t __faultvaddr;
};
# 422 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_debug_state32
{
 unsigned int __dr0;
 unsigned int __dr1;
 unsigned int __dr2;
 unsigned int __dr3;
 unsigned int __dr4;
 unsigned int __dr5;
 unsigned int __dr6;
 unsigned int __dr7;
};
# 454 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_thread_state64
{
 __uint64_t __rax;
 __uint64_t __rbx;
 __uint64_t __rcx;
 __uint64_t __rdx;
 __uint64_t __rdi;
 __uint64_t __rsi;
 __uint64_t __rbp;
 __uint64_t __rsp;
 __uint64_t __r8;
 __uint64_t __r9;
 __uint64_t __r10;
 __uint64_t __r11;
 __uint64_t __r12;
 __uint64_t __r13;
 __uint64_t __r14;
 __uint64_t __r15;
 __uint64_t __rip;
 __uint64_t __rflags;
 __uint64_t __cs;
 __uint64_t __fs;
 __uint64_t __gs;
};
# 509 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_float_state64
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;


 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;

 __uint16_t __fpu_rsrv2;


 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;

 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 struct __darwin_xmm_reg __fpu_xmm8;
 struct __darwin_xmm_reg __fpu_xmm9;
 struct __darwin_xmm_reg __fpu_xmm10;
 struct __darwin_xmm_reg __fpu_xmm11;
 struct __darwin_xmm_reg __fpu_xmm12;
 struct __darwin_xmm_reg __fpu_xmm13;
 struct __darwin_xmm_reg __fpu_xmm14;
 struct __darwin_xmm_reg __fpu_xmm15;
 char __fpu_rsrv4[6*16];
 int __fpu_reserved1;
};


struct __darwin_x86_avx_state64
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;


 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;

 __uint16_t __fpu_rsrv2;


 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;

 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 struct __darwin_xmm_reg __fpu_xmm8;
 struct __darwin_xmm_reg __fpu_xmm9;
 struct __darwin_xmm_reg __fpu_xmm10;
 struct __darwin_xmm_reg __fpu_xmm11;
 struct __darwin_xmm_reg __fpu_xmm12;
 struct __darwin_xmm_reg __fpu_xmm13;
 struct __darwin_xmm_reg __fpu_xmm14;
 struct __darwin_xmm_reg __fpu_xmm15;
 char __fpu_rsrv4[6*16];
 int __fpu_reserved1;
 char __avx_reserved1[64];
 struct __darwin_xmm_reg __fpu_ymmh0;
 struct __darwin_xmm_reg __fpu_ymmh1;
 struct __darwin_xmm_reg __fpu_ymmh2;
 struct __darwin_xmm_reg __fpu_ymmh3;
 struct __darwin_xmm_reg __fpu_ymmh4;
 struct __darwin_xmm_reg __fpu_ymmh5;
 struct __darwin_xmm_reg __fpu_ymmh6;
 struct __darwin_xmm_reg __fpu_ymmh7;
 struct __darwin_xmm_reg __fpu_ymmh8;
 struct __darwin_xmm_reg __fpu_ymmh9;
 struct __darwin_xmm_reg __fpu_ymmh10;
 struct __darwin_xmm_reg __fpu_ymmh11;
 struct __darwin_xmm_reg __fpu_ymmh12;
 struct __darwin_xmm_reg __fpu_ymmh13;
 struct __darwin_xmm_reg __fpu_ymmh14;
 struct __darwin_xmm_reg __fpu_ymmh15;
};
# 751 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_exception_state64
{
    __uint16_t __trapno;
    __uint16_t __cpu;
    __uint32_t __err;
    __uint64_t __faultvaddr;
};
# 771 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_debug_state64
{
 __uint64_t __dr0;
 __uint64_t __dr1;
 __uint64_t __dr2;
 __uint64_t __dr3;
 __uint64_t __dr4;
 __uint64_t __dr5;
 __uint64_t __dr6;
 __uint64_t __dr7;
};
# 39 "/usr/include/i386/_structs.h" 2 3 4
# 48 "/usr/include/i386/_structs.h" 3 4
struct __darwin_mcontext32
{
 struct __darwin_i386_exception_state __es;
 struct __darwin_i386_thread_state __ss;
 struct __darwin_i386_float_state __fs;
};


struct __darwin_mcontext_avx32
{
 struct __darwin_i386_exception_state __es;
 struct __darwin_i386_thread_state __ss;
 struct __darwin_i386_avx_state __fs;
};
# 86 "/usr/include/i386/_structs.h" 3 4
struct __darwin_mcontext64
{
 struct __darwin_x86_exception_state64 __es;
 struct __darwin_x86_thread_state64 __ss;
 struct __darwin_x86_float_state64 __fs;
};


struct __darwin_mcontext_avx64
{
 struct __darwin_x86_exception_state64 __es;
 struct __darwin_x86_thread_state64 __ss;
 struct __darwin_x86_avx_state64 __fs;
};
# 127 "/usr/include/i386/_structs.h" 3 4
typedef struct __darwin_mcontext64 *mcontext_t;
# 30 "/usr/include/machine/_structs.h" 2 3 4
# 58 "/usr/include/sys/_structs.h" 2 3 4
# 75 "/usr/include/sys/_structs.h" 3 4
struct __darwin_sigaltstack
{
 void *ss_sp;
 __darwin_size_t ss_size;
 int ss_flags;
};
# 128 "/usr/include/sys/_structs.h" 3 4
struct __darwin_ucontext
{
 int uc_onstack;
 __darwin_sigset_t uc_sigmask;
 struct __darwin_sigaltstack uc_stack;
 struct __darwin_ucontext *uc_link;
 __darwin_size_t uc_mcsize;
 struct __darwin_mcontext64 *uc_mcontext;



};
# 218 "/usr/include/sys/_structs.h" 3 4
typedef struct __darwin_sigaltstack stack_t;
# 227 "/usr/include/sys/_structs.h" 3 4
typedef struct __darwin_ucontext ucontext_t;
# 149 "/usr/include/sys/signal.h" 2 3 4
# 157 "/usr/include/sys/signal.h" 3 4
typedef __darwin_pthread_attr_t pthread_attr_t;




typedef __darwin_sigset_t sigset_t;
# 172 "/usr/include/sys/signal.h" 3 4
typedef __darwin_uid_t uid_t;


union sigval {

 int sival_int;
 void *sival_ptr;
};





struct sigevent {
 int sigev_notify;
 int sigev_signo;
 union sigval sigev_value;
 void (*sigev_notify_function)(union sigval);
 pthread_attr_t *sigev_notify_attributes;
};


typedef struct __siginfo {
 int si_signo;
 int si_errno;
 int si_code;
 pid_t si_pid;
 uid_t si_uid;
 int si_status;
 void *si_addr;
 union sigval si_value;
 long si_band;
 unsigned long __pad[7];
} siginfo_t;
# 286 "/usr/include/sys/signal.h" 3 4
union __sigaction_u {
 void (*__sa_handler)(int);
 void (*__sa_sigaction)(int, struct __siginfo *,
         void *);
};


struct __sigaction {
 union __sigaction_u __sigaction_u;
 void (*sa_tramp)(void *, int, int, siginfo_t *, void *);
 sigset_t sa_mask;
 int sa_flags;
};




struct sigaction {
 union __sigaction_u __sigaction_u;
 sigset_t sa_mask;
 int sa_flags;
};
# 348 "/usr/include/sys/signal.h" 3 4
typedef void (*sig_t)(int);
# 365 "/usr/include/sys/signal.h" 3 4
struct sigvec {
 void (*sv_handler)(int);
 int sv_mask;
 int sv_flags;
};
# 384 "/usr/include/sys/signal.h" 3 4
struct sigstack {
 char *ss_sp;
 int ss_onstack;
};
# 406 "/usr/include/sys/signal.h" 3 4

void (*signal(int, void (*)(int)))(int);

# 117 "/usr/include/sys/wait.h" 2 3 4
# 1 "/usr/include/sys/resource.h" 1 3 4
# 77 "/usr/include/sys/resource.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 100 "/usr/include/sys/_structs.h" 3 4
struct timeval
{
 __darwin_time_t tv_sec;
 __darwin_suseconds_t tv_usec;
};
# 78 "/usr/include/sys/resource.h" 2 3 4
# 89 "/usr/include/sys/resource.h" 3 4
typedef __uint64_t rlim_t;
# 151 "/usr/include/sys/resource.h" 3 4
struct rusage {
 struct timeval ru_utime;
 struct timeval ru_stime;
# 162 "/usr/include/sys/resource.h" 3 4
 long ru_maxrss;

 long ru_ixrss;
 long ru_idrss;
 long ru_isrss;
 long ru_minflt;
 long ru_majflt;
 long ru_nswap;
 long ru_inblock;
 long ru_oublock;
 long ru_msgsnd;
 long ru_msgrcv;
 long ru_nsignals;
 long ru_nvcsw;
 long ru_nivcsw;


};
# 222 "/usr/include/sys/resource.h" 3 4
struct rlimit {
 rlim_t rlim_cur;
 rlim_t rlim_max;
};
# 244 "/usr/include/sys/resource.h" 3 4

int getpriority(int, id_t);

int getiopolicy_np(int, int) __attribute__((visibility("default")));

int getrlimit(int, struct rlimit *) __asm("_" "getrlimit" );
int getrusage(int, struct rusage *);
int setpriority(int, id_t, int);

int setiopolicy_np(int, int, int) __attribute__((visibility("default")));

int setrlimit(int, const struct rlimit *) __asm("_" "setrlimit" );

# 118 "/usr/include/sys/wait.h" 2 3 4
# 193 "/usr/include/sys/wait.h" 3 4
# 1 "/usr/include/machine/endian.h" 1 3 4
# 35 "/usr/include/machine/endian.h" 3 4
# 1 "/usr/include/i386/endian.h" 1 3 4
# 99 "/usr/include/i386/endian.h" 3 4
# 1 "/usr/include/sys/_endian.h" 1 3 4
# 124 "/usr/include/sys/_endian.h" 3 4
# 1 "/usr/include/libkern/_OSByteOrder.h" 1 3 4
# 66 "/usr/include/libkern/_OSByteOrder.h" 3 4
# 1 "/usr/include/libkern/i386/_OSByteOrder.h" 1 3 4
# 44 "/usr/include/libkern/i386/_OSByteOrder.h" 3 4
static __inline__
__uint16_t
_OSSwapInt16(
    __uint16_t _data
)
{
    return ((_data << 8) | (_data >> 8));
}

static __inline__
__uint32_t
_OSSwapInt32(
    __uint32_t _data
)
{

    return __builtin_bswap32(_data);




}


static __inline__
__uint64_t
_OSSwapInt64(
    __uint64_t _data
)
{
    return __builtin_bswap64(_data);
}
# 67 "/usr/include/libkern/_OSByteOrder.h" 2 3 4
# 125 "/usr/include/sys/_endian.h" 2 3 4
# 100 "/usr/include/i386/endian.h" 2 3 4
# 36 "/usr/include/machine/endian.h" 2 3 4
# 194 "/usr/include/sys/wait.h" 2 3 4







union wait {
 int w_status;



 struct {

  unsigned int w_Termsig:7,
    w_Coredump:1,
    w_Retcode:8,
    w_Filler:16;







 } w_T;





 struct {

  unsigned int w_Stopval:8,
    w_Stopsig:8,
    w_Filler:16;






 } w_S;
};
# 254 "/usr/include/sys/wait.h" 3 4

pid_t wait(int *) __asm("_" "wait" );
pid_t waitpid(pid_t, int *, int) __asm("_" "waitpid" );

int waitid(idtype_t, id_t, siginfo_t *, int) __asm("_" "waitid" );


pid_t wait3(int *, int, struct rusage *);
pid_t wait4(pid_t, int *, int, struct rusage *);


# 66 "/usr/include/stdlib.h" 2 3 4

# 1 "/usr/include/alloca.h" 1 3 4
# 35 "/usr/include/alloca.h" 3 4

void *alloca(size_t);

# 68 "/usr/include/stdlib.h" 2 3 4
# 81 "/usr/include/stdlib.h" 3 4
typedef __darwin_ct_rune_t ct_rune_t;




typedef __darwin_rune_t rune_t;






typedef __darwin_wchar_t wchar_t;



typedef struct {
 int quot;
 int rem;
} div_t;

typedef struct {
 long quot;
 long rem;
} ldiv_t;


typedef struct {
 long long quot;
 long long rem;
} lldiv_t;
# 134 "/usr/include/stdlib.h" 3 4
extern int __mb_cur_max;
# 144 "/usr/include/stdlib.h" 3 4

void abort(void) __attribute__((__noreturn__));
int abs(int) __attribute__((__const__));
int atexit(void (*)(void));
double atof(const char *);
int atoi(const char *);
long atol(const char *);

long long
  atoll(const char *);

void *bsearch(const void *, const void *, size_t,
     size_t, int (*)(const void *, const void *));
void *calloc(size_t, size_t);
div_t div(int, int) __attribute__((__const__));
void exit(int) __attribute__((__noreturn__));
void free(void *);
char *getenv(const char *);
long labs(long) __attribute__((__const__));
ldiv_t ldiv(long, long) __attribute__((__const__));

long long
  llabs(long long);
lldiv_t lldiv(long long, long long);

void *malloc(size_t);
int mblen(const char *, size_t);
size_t mbstowcs(wchar_t * , const char * , size_t);
int mbtowc(wchar_t * , const char * , size_t);
int posix_memalign(void **, size_t, size_t) __attribute__((visibility("default")));
void qsort(void *, size_t, size_t,
     int (*)(const void *, const void *));
int rand(void);
void *realloc(void *, size_t);
void srand(unsigned);
double strtod(const char *, char **) __asm("_" "strtod" );
float strtof(const char *, char **) __asm("_" "strtof" );
long strtol(const char *, char **, int);
long double
  strtold(const char *, char **) ;

long long
  strtoll(const char *, char **, int);

unsigned long
  strtoul(const char *, char **, int);

unsigned long long
  strtoull(const char *, char **, int);

int system(const char *) __asm("_" "system" );
size_t wcstombs(char * , const wchar_t * , size_t);
int wctomb(char *, wchar_t);


void _Exit(int) __attribute__((__noreturn__));
long a64l(const char *);
double drand48(void);
char *ecvt(double, int, int *, int *);
double erand48(unsigned short[3]);
char *fcvt(double, int, int *, int *);
char *gcvt(double, int, char *);
int getsubopt(char **, char * const *, char **);
int grantpt(int);

char *initstate(unsigned, char *, size_t);



long jrand48(unsigned short[3]);
char *l64a(long);
void lcong48(unsigned short[7]);
long lrand48(void);
char *mktemp(char *);
int mkstemp(char *);
long mrand48(void);
long nrand48(unsigned short[3]);
int posix_openpt(int);
char *ptsname(int);
int putenv(char *) __asm("_" "putenv" );
long random(void);
int rand_r(unsigned *);

char *realpath(const char * , char * ) __asm("_" "realpath" "$DARWIN_EXTSN");



unsigned short
 *seed48(unsigned short[3]);
int setenv(const char *, const char *, int) __asm("_" "setenv" );

void setkey(const char *) __asm("_" "setkey" );



char *setstate(const char *);
void srand48(long);

void srandom(unsigned);



int unlockpt(int);

int unsetenv(const char *) __asm("_" "unsetenv" );






# 1 "/usr/include/machine/types.h" 1 3 4
# 35 "/usr/include/machine/types.h" 3 4
# 1 "/usr/include/i386/types.h" 1 3 4
# 70 "/usr/include/i386/types.h" 3 4
# 1 "/usr/include/i386/_types.h" 1 3 4
# 71 "/usr/include/i386/types.h" 2 3 4







typedef signed char int8_t;

typedef unsigned char u_int8_t;


typedef short int16_t;

typedef unsigned short u_int16_t;


typedef int int32_t;

typedef unsigned int u_int32_t;


typedef long long int64_t;

typedef unsigned long long u_int64_t;


typedef int64_t register_t;






typedef __darwin_intptr_t intptr_t;



typedef unsigned long uintptr_t;




typedef u_int64_t user_addr_t;
typedef u_int64_t user_size_t;
typedef int64_t user_ssize_t;
typedef int64_t user_long_t;
typedef u_int64_t user_ulong_t;
typedef int64_t user_time_t;
typedef int64_t user_off_t;







typedef u_int64_t syscall_arg_t;
# 36 "/usr/include/machine/types.h" 2 3 4
# 256 "/usr/include/stdlib.h" 2 3 4


typedef __darwin_dev_t dev_t;




typedef __darwin_mode_t mode_t;



u_int32_t
  arc4random(void);
void arc4random_addrandom(unsigned char * , int );
void arc4random_buf(void * , size_t ) __attribute__((visibility("default")));
void arc4random_stir(void);
u_int32_t
  arc4random_uniform(u_int32_t ) __attribute__((visibility("default")));

int atexit_b(void (^)(void)) __attribute__((visibility("default")));
void *bsearch_b(const void *, const void *, size_t,
     size_t, int (^)(const void *, const void *)) __attribute__((visibility("default")));



char *cgetcap(char *, const char *, int);
int cgetclose(void);
int cgetent(char **, char **, const char *);
int cgetfirst(char **, char **);
int cgetmatch(const char *, const char *);
int cgetnext(char **, char **);
int cgetnum(char *, const char *, long *);
int cgetset(const char *);
int cgetstr(char *, const char *, char **);
int cgetustr(char *, const char *, char **);

int daemon(int, int) __asm("_" "daemon" "$1050") __attribute__((deprecated,visibility("default")));
char *devname(dev_t, mode_t);
char *devname_r(dev_t, mode_t, char *buf, int len);
char *getbsize(int *, long *);
int getloadavg(double [], int);
const char
 *getprogname(void);

int heapsort(void *, size_t, size_t,
     int (*)(const void *, const void *));

int heapsort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

int mergesort(void *, size_t, size_t,
     int (*)(const void *, const void *));

int mergesort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void psort(void *, size_t, size_t,
     int (*)(const void *, const void *)) __attribute__((visibility("default")));

void psort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void psort_r(void *, size_t, size_t, void *,
     int (*)(void *, const void *, const void *)) __attribute__((visibility("default")));

void qsort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void qsort_r(void *, size_t, size_t, void *,
     int (*)(void *, const void *, const void *));
int radixsort(const unsigned char **, int, const unsigned char *,
     unsigned);
void setprogname(const char *);
int sradixsort(const unsigned char **, int, const unsigned char *,
     unsigned);
void sranddev(void);
void srandomdev(void);
void *reallocf(void *, size_t);

long long
  strtoq(const char *, char **, int);
unsigned long long
  strtouq(const char *, char **, int);

extern char *suboptarg;
void *valloc(size_t);







# 69 "c.h" 2
# 1 "/usr/include/string.h" 1 3 4
# 79 "/usr/include/string.h" 3 4

void *memchr(const void *, int, size_t);
int memcmp(const void *, const void *, size_t);
void *memcpy(void *, const void *, size_t);
void *memmove(void *, const void *, size_t);
void *memset(void *, int, size_t);
char *strcat(char *, const char *);
char *strchr(const char *, int);
int strcmp(const char *, const char *);
int strcoll(const char *, const char *);
char *strcpy(char *, const char *);
size_t strcspn(const char *, const char *);
char *strerror(int) __asm("_" "strerror" );
size_t strlen(const char *);
char *strncat(char *, const char *, size_t);
int strncmp(const char *, const char *, size_t);
char *strncpy(char *, const char *, size_t);
char *strpbrk(const char *, const char *);
char *strrchr(const char *, int);
size_t strspn(const char *, const char *);
char *strstr(const char *, const char *);
char *strtok(char *, const char *);
size_t strxfrm(char *, const char *, size_t);

# 113 "/usr/include/string.h" 3 4

char *strtok_r(char *, const char *, char **);

# 125 "/usr/include/string.h" 3 4

int strerror_r(int, char *, size_t);
char *strdup(const char *);
void *memccpy(void *, const void *, int, size_t);

# 139 "/usr/include/string.h" 3 4

char *stpcpy(char *, const char *);
char *stpncpy(char *, const char *, size_t) __attribute__((visibility("default")));
char *strndup(const char *, size_t) __attribute__((visibility("default")));
size_t strnlen(const char *, size_t) __attribute__((visibility("default")));
char *strsignal(int sig);

# 158 "/usr/include/string.h" 3 4

void *memmem(const void *, size_t, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern4(void *, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern8(void *, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern16(void *, const void *, size_t) __attribute__((visibility("default")));

char *strcasestr(const char *, const char *);
char *strnstr(const char *, const char *, size_t);
size_t strlcat(char *, const char *, size_t);
size_t strlcpy(char *, const char *, size_t);
void strmode(int, char *);
char *strsep(char **, const char *);


void swab(const void * , void * , ssize_t);







# 1 "/usr/include/strings.h" 1 3 4
# 71 "/usr/include/strings.h" 3 4



int bcmp(const void *, const void *, size_t) ;
void bcopy(const void *, void *, size_t) ;
void bzero(void *, size_t) ;
char *index(const char *, int) ;
char *rindex(const char *, int) ;


int ffs(int);
int strcasecmp(const char *, const char *);
int strncasecmp(const char *, const char *, size_t);





int ffsl(long) __attribute__((visibility("default")));
int fls(int) __attribute__((visibility("default")));
int flsl(long) __attribute__((visibility("default")));


# 1 "/usr/include/string.h" 1 3 4
# 95 "/usr/include/strings.h" 2 3 4
# 181 "/usr/include/string.h" 2 3 4
# 190 "/usr/include/string.h" 3 4
# 1 "/usr/include/secure/_string.h" 1 3 4
# 58 "/usr/include/secure/_string.h" 3 4
static __inline void *
__inline_memcpy_chk (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memcpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 0));
}






static __inline void *
__inline_memmove_chk (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memmove_chk (__dest, __src, __len, __builtin_object_size (__dest, 0));
}






static __inline void *
__inline_memset_chk (void *__dest, int __val, size_t __len)
{
  return __builtin___memset_chk (__dest, __val, __len, __builtin_object_size (__dest, 0));
}






static __inline char *
__inline_strcpy_chk (char * __dest, const char * __src)
{
  return __builtin___strcpy_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_stpcpy_chk (char *__dest, const char *__src)
{
  return __builtin___stpcpy_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}






static __inline char *
__inline_stpncpy_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___stpncpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_strncpy_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___strncpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}






static __inline char *
__inline_strcat_chk (char * __dest, const char * __src)
{
  return __builtin___strcat_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_strncat_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___strncat_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}
# 191 "/usr/include/string.h" 2 3 4
# 70 "c.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stddef.h" 1 3 4
# 152 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 71 "c.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stdarg.h" 1 3 4
# 43 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 72 "c.h" 2

# 1 "./strings.h" 1
char *s1,
     *s2,
     *s3,
     *s4,
     *s5,
     *s6;
# 74 "c.h" 2


# 1 "/usr/include/stdint.h" 1 3 4
# 40 "/usr/include/stdint.h" 3 4
typedef unsigned char uint8_t;




typedef unsigned short uint16_t;




typedef unsigned int uint32_t;




typedef unsigned long long uint64_t;



typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;
# 97 "/usr/include/stdint.h" 3 4
typedef long int intmax_t;
# 106 "/usr/include/stdint.h" 3 4
typedef long unsigned int uintmax_t;
# 77 "c.h" 2

# 1 "/usr/include/sys/types.h" 1 3 4
# 84 "/usr/include/sys/types.h" 3 4
typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned int u_int;

typedef unsigned long u_long;


typedef unsigned short ushort;
typedef unsigned int uint;


typedef u_int64_t u_quad_t;
typedef int64_t quad_t;
typedef quad_t * qaddr_t;

typedef char * caddr_t;
typedef int32_t daddr_t;






typedef u_int32_t fixpt_t;


typedef __darwin_blkcnt_t blkcnt_t;




typedef __darwin_blksize_t blksize_t;




typedef __darwin_gid_t gid_t;





typedef __uint32_t in_addr_t;




typedef __uint16_t in_port_t;



typedef __darwin_ino_t ino_t;





typedef __darwin_ino64_t ino64_t;






typedef __int32_t key_t;
# 157 "/usr/include/sys/types.h" 3 4
typedef __uint16_t nlink_t;
# 176 "/usr/include/sys/types.h" 3 4
typedef int32_t segsz_t;
typedef int32_t swblk_t;
# 223 "/usr/include/sys/types.h" 3 4
typedef __darwin_clock_t clock_t;
# 240 "/usr/include/sys/types.h" 3 4
typedef __darwin_time_t time_t;




typedef __darwin_useconds_t useconds_t;




typedef __darwin_suseconds_t suseconds_t;
# 260 "/usr/include/sys/types.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 183 "/usr/include/sys/_structs.h" 3 4

typedef struct fd_set {
 __int32_t fds_bits[((((1024) % ((sizeof(__int32_t) * 8))) == 0) ? ((1024) / ((sizeof(__int32_t) * 8))) : (((1024) / ((sizeof(__int32_t) * 8))) + 1))];
} fd_set;



static __inline int
__darwin_fd_isset(int _n, const struct fd_set *_p)
{
 return (_p->fds_bits[_n/(sizeof(__int32_t) * 8)] & (1<<(_n % (sizeof(__int32_t) * 8))));
}
# 261 "/usr/include/sys/types.h" 2 3 4




typedef __int32_t fd_mask;
# 322 "/usr/include/sys/types.h" 3 4
typedef __darwin_pthread_cond_t pthread_cond_t;



typedef __darwin_pthread_condattr_t pthread_condattr_t;



typedef __darwin_pthread_mutex_t pthread_mutex_t;



typedef __darwin_pthread_mutexattr_t pthread_mutexattr_t;



typedef __darwin_pthread_once_t pthread_once_t;



typedef __darwin_pthread_rwlock_t pthread_rwlock_t;



typedef __darwin_pthread_rwlockattr_t pthread_rwlockattr_t;



typedef __darwin_pthread_t pthread_t;






typedef __darwin_pthread_key_t pthread_key_t;





typedef __darwin_fsblkcnt_t fsblkcnt_t;




typedef __darwin_fsfilcnt_t fsfilcnt_t;
# 79 "c.h" 2

# 1 "/usr/include/errno.h" 1 3 4
# 23 "/usr/include/errno.h" 3 4
# 1 "/usr/include/sys/errno.h" 1 3 4
# 74 "/usr/include/sys/errno.h" 3 4

extern int * __error(void);


# 24 "/usr/include/errno.h" 2 3 4
# 81 "c.h" 2
# 91 "c.h"
# 1 "/usr/include/locale.h" 1 3 4
# 40 "/usr/include/locale.h" 3 4
# 1 "/usr/include/_locale.h" 1 3 4
# 43 "/usr/include/_locale.h" 3 4
struct lconv {
 char *decimal_point;
 char *thousands_sep;
 char *grouping;
 char *int_curr_symbol;
 char *currency_symbol;
 char *mon_decimal_point;
 char *mon_thousands_sep;
 char *mon_grouping;
 char *positive_sign;
 char *negative_sign;
 char int_frac_digits;
 char frac_digits;
 char p_cs_precedes;
 char p_sep_by_space;
 char n_cs_precedes;
 char n_sep_by_space;
 char p_sign_posn;
 char n_sign_posn;
 char int_p_cs_precedes;
 char int_n_cs_precedes;
 char int_p_sep_by_space;
 char int_n_sep_by_space;
 char int_p_sign_posn;
 char int_n_sign_posn;
};






struct lconv *localeconv(void);

# 41 "/usr/include/locale.h" 2 3 4
# 52 "/usr/include/locale.h" 3 4

char *setlocale(int, const char *);

# 92 "c.h" 2
# 181 "c.h"
typedef char bool;
# 193 "c.h"
typedef bool *BoolPtr;
# 224 "c.h"
typedef char *Pointer;
# 233 "c.h"
typedef signed char int8;
typedef signed short int16;
typedef signed int int32;
# 245 "c.h"
typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;






typedef uint8 bits8;
typedef uint16 bits16;
typedef uint32 bits32;
# 265 "c.h"
typedef long int int64;


typedef unsigned long int uint64;
# 308 "c.h"
typedef size_t Size;
# 317 "c.h"
typedef unsigned int Index;
# 327 "c.h"
typedef signed int Offset;




typedef int16 int2;
typedef int32 int4;
typedef float float4;
typedef double float8;
# 348 "c.h"
typedef Oid regproc;
typedef regproc RegProcedure;

typedef uint32 TransactionId;

typedef uint32 LocalTransactionId;

typedef uint32 SubTransactionId;





typedef TransactionId MultiXactId;

typedef uint32 MultiXactOffset;

typedef uint32 CommandId;







typedef struct
{
 int indx[6];
} IntArray;
# 391 "c.h"
struct varlena
{
 char vl_len_[4];
 char vl_dat[1];
};
# 404 "c.h"
typedef struct varlena bytea;
typedef struct varlena text;
typedef struct varlena BpChar;
typedef struct varlena VarChar;
# 419 "c.h"
typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
 int dim1;
 int lbound1;
 int2 values[1];
} int2vector;

typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
 int dim1;
 int lbound1;
 Oid values[1];
} oidvector;





typedef struct nameData
{
 char data[64];
} NameData;
typedef NameData *Name;
# 829 "c.h"
extern int fdatasync(int fildes);
# 860 "c.h"
# 1 "port.h" 1
# 16 "port.h"
# 1 "/usr/include/ctype.h" 1 3 4
# 69 "/usr/include/ctype.h" 3 4
# 1 "/usr/include/runetype.h" 1 3 4
# 70 "/usr/include/runetype.h" 3 4
typedef __darwin_wint_t wint_t;
# 81 "/usr/include/runetype.h" 3 4
typedef struct {
 __darwin_rune_t __min;
 __darwin_rune_t __max;
 __darwin_rune_t __map;
 __uint32_t *__types;
} _RuneEntry;

typedef struct {
 int __nranges;
 _RuneEntry *__ranges;
} _RuneRange;

typedef struct {
 char __name[14];
 __uint32_t __mask;
} _RuneCharClass;

typedef struct {
 char __magic[8];
 char __encoding[32];

 __darwin_rune_t (*__sgetrune)(const char *, __darwin_size_t, char const **);
 int (*__sputrune)(__darwin_rune_t, char *, __darwin_size_t, char **);
 __darwin_rune_t __invalid_rune;

 __uint32_t __runetype[(1 <<8 )];
 __darwin_rune_t __maplower[(1 <<8 )];
 __darwin_rune_t __mapupper[(1 <<8 )];






 _RuneRange __runetype_ext;
 _RuneRange __maplower_ext;
 _RuneRange __mapupper_ext;

 void *__variable;
 int __variable_len;




 int __ncharclasses;
 _RuneCharClass *__charclasses;
} _RuneLocale;




extern _RuneLocale _DefaultRuneLocale;
extern _RuneLocale *_CurrentRuneLocale;

# 70 "/usr/include/ctype.h" 2 3 4
# 145 "/usr/include/ctype.h" 3 4

unsigned long ___runetype(__darwin_ct_rune_t);
__darwin_ct_rune_t ___tolower(__darwin_ct_rune_t);
__darwin_ct_rune_t ___toupper(__darwin_ct_rune_t);


static __inline int
isascii(int _c)
{
 return ((_c & ~0x7F) == 0);
}
# 164 "/usr/include/ctype.h" 3 4

int __maskrune(__darwin_ct_rune_t, unsigned long);



static __inline int
__istype(__darwin_ct_rune_t _c, unsigned long _f)
{



 return (isascii(_c) ? !!(_DefaultRuneLocale.__runetype[_c] & _f)
  : !!__maskrune(_c, _f));

}

static __inline __darwin_ct_rune_t
__isctype(__darwin_ct_rune_t _c, unsigned long _f)
{



 return (_c < 0 || _c >= (1 <<8 )) ? 0 :
  !!(_DefaultRuneLocale.__runetype[_c] & _f);

}
# 204 "/usr/include/ctype.h" 3 4

__darwin_ct_rune_t __toupper(__darwin_ct_rune_t);
__darwin_ct_rune_t __tolower(__darwin_ct_rune_t);



static __inline int
__wcwidth(__darwin_ct_rune_t _c)
{
 unsigned int _x;

 if (_c == 0)
  return (0);
 _x = (unsigned int)__maskrune(_c, 0xe0000000L|0x00040000L);
 if ((_x & 0xe0000000L) != 0)
  return ((_x & 0xe0000000L) >> 30);
 return ((_x & 0x00040000L) != 0 ? 1 : -1);
}






static __inline int
isalnum(int _c)
{
 return (__istype(_c, 0x00000100L|0x00000400L));
}

static __inline int
isalpha(int _c)
{
 return (__istype(_c, 0x00000100L));
}

static __inline int
isblank(int _c)
{
 return (__istype(_c, 0x00020000L));
}

static __inline int
iscntrl(int _c)
{
 return (__istype(_c, 0x00000200L));
}


static __inline int
isdigit(int _c)
{
 return (__isctype(_c, 0x00000400L));
}

static __inline int
isgraph(int _c)
{
 return (__istype(_c, 0x00000800L));
}

static __inline int
islower(int _c)
{
 return (__istype(_c, 0x00001000L));
}

static __inline int
isprint(int _c)
{
 return (__istype(_c, 0x00040000L));
}

static __inline int
ispunct(int _c)
{
 return (__istype(_c, 0x00002000L));
}

static __inline int
isspace(int _c)
{
 return (__istype(_c, 0x00004000L));
}

static __inline int
isupper(int _c)
{
 return (__istype(_c, 0x00008000L));
}


static __inline int
isxdigit(int _c)
{
 return (__isctype(_c, 0x00010000L));
}

static __inline int
toascii(int _c)
{
 return (_c & 0x7F);
}

static __inline int
tolower(int _c)
{
        return (__tolower(_c));
}

static __inline int
toupper(int _c)
{
        return (__toupper(_c));
}


static __inline int
digittoint(int _c)
{
 return (__maskrune(_c, 0x0F));
}

static __inline int
ishexnumber(int _c)
{
 return (__istype(_c, 0x00010000L));
}

static __inline int
isideogram(int _c)
{
 return (__istype(_c, 0x00080000L));
}

static __inline int
isnumber(int _c)
{
 return (__istype(_c, 0x00000400L));
}

static __inline int
isphonogram(int _c)
{
 return (__istype(_c, 0x00200000L));
}

static __inline int
isrune(int _c)
{
 return (__istype(_c, 0xFFFFFFF0L));
}

static __inline int
isspecial(int _c)
{
 return (__istype(_c, 0x00100000L));
}
# 17 "port.h" 2
# 1 "./netdb.h" 1
# 18 "port.h" 2
# 1 "./pwd.h" 1
# 19 "port.h" 2



typedef int pgsocket;
# 32 "port.h"
extern bool pg_set_noblock(pgsocket sock);
extern bool pg_set_block(pgsocket sock);



extern bool has_drive_prefix(const char *filename);
extern char *first_dir_separator(const char *filename);
extern char *last_dir_separator(const char *filename);
extern char *first_path_var_separator(const char *pathlist);
extern void join_path_components(char *ret_path,
      const char *head, const char *tail);
extern void canonicalize_path(char *path);
extern void make_native_path(char *path);
extern bool path_contains_parent_reference(const char *path);
extern bool path_is_relative_and_below_cwd(const char *path);
extern bool path_is_prefix_of_path(const char *path1, const char *path2);
extern const char *get_progname(const char *argv0);
extern void get_share_path(const char *my_exec_path, char *ret_path);
extern void get_etc_path(const char *my_exec_path, char *ret_path);
extern void get_include_path(const char *my_exec_path, char *ret_path);
extern void get_pkginclude_path(const char *my_exec_path, char *ret_path);
extern void get_includeserver_path(const char *my_exec_path, char *ret_path);
extern void get_lib_path(const char *my_exec_path, char *ret_path);
extern void get_pkglib_path(const char *my_exec_path, char *ret_path);
extern void get_locale_path(const char *my_exec_path, char *ret_path);
extern void get_doc_path(const char *my_exec_path, char *ret_path);
extern void get_html_path(const char *my_exec_path, char *ret_path);
extern void get_man_path(const char *my_exec_path, char *ret_path);
extern bool get_home_path(char *ret_path);
extern void get_parent_directory(char *path);


extern char **pgfnames(const char *path);
extern void pgfnames_cleanup(char **filenames);
# 92 "port.h"
extern void set_pglocale_pgservice(const char *argv0, const char *app);


extern int find_my_exec(const char *argv0, char *retpath);
extern int find_other_exec(const char *argv0, const char *target,
    const char *versionstr, char *retpath);
# 149 "port.h"
extern void pg_usleep(long microsec);


extern int pg_strcasecmp(const char *s1, const char *s2);
extern int pg_strncasecmp(const char *s1, const char *s2, size_t n);
extern unsigned char pg_toupper(unsigned char ch);
extern unsigned char pg_tolower(unsigned char ch);
extern unsigned char pg_ascii_toupper(unsigned char ch);
extern unsigned char pg_ascii_tolower(unsigned char ch);
# 247 "port.h"
extern char *simple_prompt(const char *prompt, int maxlen, bool echo);







extern int pclose_check(FILE *stream);
# 300 "port.h"
extern bool rmtree(const char *path, bool rmtopdir);
# 372 "port.h"
extern double pg_erand48(unsigned short xseed[3]);
extern long pg_lrand48(void);
extern void pg_srand48(long seed);
# 428 "port.h"
extern char *pqStrerror(int errnum, char *strerrbuf, size_t buflen);


extern int pqGetpwuid(uid_t uid, struct passwd * resultbuf, char *buffer,
     size_t buflen, struct passwd ** result);


extern int pqGethostbyname(const char *name,
    struct hostent * resultbuf,
    char *buffer, size_t buflen,
    struct hostent ** result,
    int *herrno);

extern void pg_qsort(void *base, size_t nel, size_t elsize,
   int (*cmp) (const void *, const void *));



typedef int (*qsort_arg_comparator) (const void *a, const void *b, void *arg);

extern void qsort_arg(void *base, size_t nel, size_t elsize,
    qsort_arg_comparator cmp, void *arg);


extern int pg_get_encoding_from_locale(const char *ctype, bool write_message);


extern char *inet_net_ntop(int af, const void *src, int bits,
     char *dst, size_t size);


extern int pg_check_dir(const char *dir);


extern int pg_mkdir_p(char *path, int omode);
# 861 "c.h" 2
# 48 "postgres.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
# 1 "/usr/include/setjmp.h" 1 3 4
# 26 "/usr/include/setjmp.h" 3 4
# 1 "/usr/include/machine/setjmp.h" 1 3 4
# 35 "/usr/include/machine/setjmp.h" 3 4
# 1 "/usr/include/i386/setjmp.h" 1 3 4
# 47 "/usr/include/i386/setjmp.h" 3 4
typedef int jmp_buf[((9 * 2) + 3 + 16)];
typedef int sigjmp_buf[((9 * 2) + 3 + 16) + 1];
# 65 "/usr/include/i386/setjmp.h" 3 4

int setjmp(jmp_buf);
void longjmp(jmp_buf, int);


int _setjmp(jmp_buf);
void _longjmp(jmp_buf, int);
int sigsetjmp(sigjmp_buf, int);
void siglongjmp(sigjmp_buf, int);



void longjmperror(void);


# 36 "/usr/include/machine/setjmp.h" 2 3 4
# 27 "/usr/include/setjmp.h" 2 3 4
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h" 2
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/errcodes.h" 1
# 70 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h" 2
# 114 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
extern bool errstart(int elevel, const char *filename, int lineno,
   const char *funcname, const char *domain);
extern void errfinish(int dummy,...);

extern int errcode(int sqlerrcode);

extern int errcode_for_file_access(void);
extern int errcode_for_socket_access(void);

extern int
errmsg(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errmsg_internal(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errmsg_plural(const char *fmt_singular, const char *fmt_plural,
     unsigned long n,...)


__attribute__((format(printf, 1, 4)))
__attribute__((format(printf, 2, 4)));

extern int
errdetail(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errdetail_internal(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errdetail_log(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errdetail_plural(const char *fmt_singular, const char *fmt_plural,
     unsigned long n,...)


__attribute__((format(printf, 1, 4)))
__attribute__((format(printf, 2, 4)));

extern int
errhint(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errcontext(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int errhidestmt(bool hide_stmt);

extern int errfunction(const char *funcname);
extern int errposition(int cursorpos);

extern int internalerrposition(int cursorpos);
extern int internalerrquery(const char *query);

extern int geterrcode(void);
extern int geterrposition(void);
extern int getinternalerrposition(void);
# 201 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
extern void elog_start(const char *filename, int lineno, const char *funcname);
extern void
elog_finish(int elevel, const char *fmt,...)


__attribute__((format(printf, 2, 3)));




extern void pre_format_elog_string(int errnumber, const char *domain);
extern char *
format_elog_string(const char *fmt,...)


__attribute__((format(printf, 1, 2)));




typedef struct ErrorContextCallback
{
 struct ErrorContextCallback *previous;
 void (*callback) (void *arg);
 void *arg;
} ErrorContextCallback;

extern ErrorContextCallback *error_context_stack;
# 296 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
extern sigjmp_buf *PG_exception_stack;
# 307 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
typedef struct ErrorData
{
 int elevel;
 bool output_to_server;
 bool output_to_client;
 bool show_funcname;
 bool hide_stmt;
 const char *filename;
 int lineno;
 const char *funcname;
 const char *domain;
 int sqlerrcode;
 char *message;
 char *detail;
 char *detail_log;
 char *hint;
 char *context;
 int cursorpos;
 int internalpos;
 char *internalquery;
 int saved_errno;
} ErrorData;

extern void EmitErrorReport(void);
extern ErrorData *CopyErrorData(void);
extern void FreeErrorData(ErrorData *edata);
extern void FlushErrorState(void);
extern void ReThrowError(ErrorData *edata) __attribute__((noreturn));
extern void pg_re_throw(void) __attribute__((noreturn));


typedef void (*emit_log_hook_type) (ErrorData *edata);
extern emit_log_hook_type emit_log_hook;




typedef enum
{
 PGERROR_TERSE,
 PGERROR_DEFAULT,
 PGERROR_VERBOSE
} PGErrorVerbosity;

extern int Log_error_verbosity;
extern char *Log_line_prefix;
extern int Log_destination;
# 362 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
extern void DebugFileOpen(void);
extern char *unpack_sql_state(int sql_state);
extern bool in_error_recursion_trouble(void);


extern void set_syslog_parameters(const char *ident, int facility);







extern void
write_stderr(const char *fmt,...)


__attribute__((format(printf, 1, 2)));
# 49 "postgres.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h" 1
# 36 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h"
typedef struct MemoryContextData *MemoryContext;






extern MemoryContext CurrentMemoryContext;




extern void *MemoryContextAlloc(MemoryContext context, Size size);
extern void *MemoryContextAllocZero(MemoryContext context, Size size);
extern void *MemoryContextAllocZeroAligned(MemoryContext context, Size size);
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h"
extern void pfree(void *pointer);

extern void *repalloc(void *pointer, Size size);
# 83 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h"
static inline MemoryContext
MemoryContextSwitchTo(MemoryContext context)
{
 MemoryContext old = CurrentMemoryContext;

 CurrentMemoryContext = context;
 return old;
}
# 100 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h"
extern char *MemoryContextStrdup(MemoryContext context, const char *string);



extern char *pnstrdup(const char *in, Size len);
# 50 "postgres.h" 2
# 67 "postgres.h"
struct varatt_external
{
 int32 va_rawsize;
 int32 va_extsize;
 Oid va_valueid;
 Oid va_toastrelid;
};
# 84 "postgres.h"
typedef union
{
 struct
 {
  uint32 va_header;
  char va_data[1];
 } va_4byte;
 struct
 {
  uint32 va_header;
  uint32 va_rawsize;
  char va_data[1];
 } va_compressed;
} varattrib_4b;

typedef struct
{
 uint8 va_header;
 char va_data[1];
} varattrib_1b;

typedef struct
{
 uint8 va_header;
 uint8 va_len_1be;
 char va_data[1];
} varattrib_1b_e;
# 302 "postgres.h"
typedef uintptr_t Datum;



typedef Datum *DatumPtr;
# 561 "postgres.h"
extern float4 DatumGetFloat4(Datum X);
# 574 "postgres.h"
extern Datum Float4GetDatum(float4 X);
# 584 "postgres.h"
extern float8 DatumGetFloat8(Datum X);
# 597 "postgres.h"
extern Datum Float8GetDatum(float8 X);
# 635 "postgres.h"
extern bool assert_enabled;
# 686 "postgres.h"
extern void ExceptionalCondition(const char *conditionName,
      const char *errorType,
    const char *fileName, int lineNumber) __attribute__((noreturn));
# 18 "hba.c" 2


# 1 "./pwd.h" 1
# 21 "hba.c" 2
# 1 "/usr/include/fcntl.h" 1 3 4
# 23 "/usr/include/fcntl.h" 3 4
# 1 "/usr/include/sys/fcntl.h" 1 3 4
# 339 "/usr/include/sys/fcntl.h" 3 4
struct flock {
 off_t l_start;
 off_t l_len;
 pid_t l_pid;
 short l_type;
 short l_whence;
};
# 355 "/usr/include/sys/fcntl.h" 3 4
struct radvisory {
       off_t ra_offset;
       int ra_count;
};
# 367 "/usr/include/sys/fcntl.h" 3 4
typedef struct fsignatures {
 off_t fs_file_start;
 void *fs_blob_start;
 size_t fs_blob_size;
} fsignatures_t;
# 381 "/usr/include/sys/fcntl.h" 3 4
typedef struct fstore {
 unsigned int fst_flags;
 int fst_posmode;
 off_t fst_offset;
 off_t fst_length;
 off_t fst_bytesalloc;
} fstore_t;



typedef struct fbootstraptransfer {
  off_t fbt_offset;
  size_t fbt_length;
  void *fbt_buffer;
} fbootstraptransfer_t;
# 419 "/usr/include/sys/fcntl.h" 3 4
#pragma pack(4)

struct log2phys {
 unsigned int l2p_flags;
 off_t l2p_contigbytes;


 off_t l2p_devoffset;


};

#pragma pack()
# 442 "/usr/include/sys/fcntl.h" 3 4
struct _filesec;
typedef struct _filesec *filesec_t;


typedef enum {
 FILESEC_OWNER = 1,
 FILESEC_GROUP = 2,
 FILESEC_UUID = 3,
 FILESEC_MODE = 4,
 FILESEC_ACL = 5,
 FILESEC_GRPUUID = 6,


 FILESEC_ACL_RAW = 100,
 FILESEC_ACL_ALLOCSIZE = 101
} filesec_property_t;






int open(const char *, int, ...) __asm("_" "open" );
int creat(const char *, mode_t) __asm("_" "creat" );
int fcntl(int, int, ...) __asm("_" "fcntl" );


int openx_np(const char *, int, filesec_t);
int flock(int, int);
filesec_t filesec_init(void);
filesec_t filesec_dup(filesec_t);
void filesec_free(filesec_t);
int filesec_get_property(filesec_t, filesec_property_t, void *);
int filesec_query_property(filesec_t, filesec_property_t, int *);
int filesec_set_property(filesec_t, filesec_property_t, const void *);
int filesec_unset_property(filesec_t, filesec_property_t) __attribute__((visibility("default")));




# 23 "/usr/include/fcntl.h" 2 3 4
# 22 "hba.c" 2
# 1 "/usr/include/sys/param.h" 1 3 4
# 96 "/usr/include/sys/param.h" 3 4
# 1 "/usr/include/sys/syslimits.h" 1 3 4
# 97 "/usr/include/sys/param.h" 2 3 4
# 110 "/usr/include/sys/param.h" 3 4
# 1 "/usr/include/machine/param.h" 1 3 4
# 35 "/usr/include/machine/param.h" 3 4
# 1 "/usr/include/i386/param.h" 1 3 4
# 75 "/usr/include/i386/param.h" 3 4
# 1 "/usr/include/i386/_param.h" 1 3 4
# 76 "/usr/include/i386/param.h" 2 3 4
# 36 "/usr/include/machine/param.h" 2 3 4
# 111 "/usr/include/sys/param.h" 2 3 4


# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 1 3 4






# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/syslimits.h" 1 3 4
# 8 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 2 3 4







# 1 "/usr/include/limits.h" 1 3 4
# 64 "/usr/include/limits.h" 3 4
# 1 "/usr/include/machine/limits.h" 1 3 4





# 1 "/usr/include/i386/limits.h" 1 3 4
# 40 "/usr/include/i386/limits.h" 3 4
# 1 "/usr/include/i386/_limits.h" 1 3 4
# 41 "/usr/include/i386/limits.h" 2 3 4
# 7 "/usr/include/machine/limits.h" 2 3 4
# 65 "/usr/include/limits.h" 2 3 4
# 16 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 2 3 4
# 114 "/usr/include/sys/param.h" 2 3 4
# 23 "hba.c" 2
# 1 "/usr/include/sys/socket.h" 1 3 4
# 77 "/usr/include/sys/socket.h" 3 4
# 1 "/usr/include/machine/_param.h" 1 3 4
# 78 "/usr/include/sys/socket.h" 2 3 4
# 106 "/usr/include/sys/socket.h" 3 4
typedef __uint8_t sa_family_t;




typedef __darwin_socklen_t socklen_t;
# 131 "/usr/include/sys/socket.h" 3 4
struct iovec {
 void * iov_base;
 size_t iov_len;
};
# 219 "/usr/include/sys/socket.h" 3 4
struct linger {
 int l_onoff;
 int l_linger;
};
# 237 "/usr/include/sys/socket.h" 3 4
struct so_np_extensions {
 u_int32_t npx_flags;
 u_int32_t npx_mask;
};
# 322 "/usr/include/sys/socket.h" 3 4
struct sockaddr {
 __uint8_t sa_len;
 sa_family_t sa_family;
 char sa_data[14];
};
# 335 "/usr/include/sys/socket.h" 3 4
struct sockproto {
 __uint16_t sp_family;
 __uint16_t sp_protocol;
};
# 355 "/usr/include/sys/socket.h" 3 4
struct sockaddr_storage {
 __uint8_t ss_len;
 sa_family_t ss_family;
 char __ss_pad1[((sizeof(__int64_t)) - sizeof(__uint8_t) - sizeof(sa_family_t))];
 __int64_t __ss_align;
 char __ss_pad2[(128 - sizeof(__uint8_t) - sizeof(sa_family_t) - ((sizeof(__int64_t)) - sizeof(__uint8_t) - sizeof(sa_family_t)) - (sizeof(__int64_t)))];
};
# 462 "/usr/include/sys/socket.h" 3 4
struct msghdr {
 void *msg_name;
 socklen_t msg_namelen;
 struct iovec *msg_iov;
 int msg_iovlen;
 void *msg_control;
 socklen_t msg_controllen;
 int msg_flags;
};
# 502 "/usr/include/sys/socket.h" 3 4
struct cmsghdr {
 socklen_t cmsg_len;
 int cmsg_level;
 int cmsg_type;

};
# 592 "/usr/include/sys/socket.h" 3 4
struct sf_hdtr {
 struct iovec *headers;
 int hdr_cnt;
 struct iovec *trailers;
 int trl_cnt;
};





int accept(int, struct sockaddr * , socklen_t * )
  __asm("_" "accept" );
int bind(int, const struct sockaddr *, socklen_t) __asm("_" "bind" );
int connect(int, const struct sockaddr *, socklen_t) __asm("_" "connect" );
int getpeername(int, struct sockaddr * , socklen_t * )
  __asm("_" "getpeername" );
int getsockname(int, struct sockaddr * , socklen_t * )
  __asm("_" "getsockname" );
int getsockopt(int, int, int, void * , socklen_t * );
int listen(int, int) __asm("_" "listen" );
ssize_t recv(int, void *, size_t, int) __asm("_" "recv" );
ssize_t recvfrom(int, void *, size_t, int, struct sockaddr * ,
  socklen_t * ) __asm("_" "recvfrom" );
ssize_t recvmsg(int, struct msghdr *, int) __asm("_" "recvmsg" );
ssize_t send(int, const void *, size_t, int) __asm("_" "send" );
ssize_t sendmsg(int, const struct msghdr *, int) __asm("_" "sendmsg" );
ssize_t sendto(int, const void *, size_t,
  int, const struct sockaddr *, socklen_t) __asm("_" "sendto" );
int setsockopt(int, int, int, const void *, socklen_t);
int shutdown(int, int);
int sockatmark(int) __attribute__((visibility("default")));
int socket(int, int, int);
int socketpair(int, int, int, int *) __asm("_" "socketpair" );


int sendfile(int, int, off_t, off_t *, struct sf_hdtr *, int);



void pfctlinput(int, struct sockaddr *);


# 24 "hba.c" 2
# 1 "/usr/include/netinet/in.h" 1 3 4
# 307 "/usr/include/netinet/in.h" 3 4
struct in_addr {
 in_addr_t s_addr;
};
# 380 "/usr/include/netinet/in.h" 3 4
struct sockaddr_in {
 __uint8_t sin_len;
 sa_family_t sin_family;
 in_port_t sin_port;
 struct in_addr sin_addr;
 char sin_zero[8];
};
# 398 "/usr/include/netinet/in.h" 3 4
struct ip_opts {
 struct in_addr ip_dst;
 char ip_opts[40];
};
# 506 "/usr/include/netinet/in.h" 3 4
struct ip_mreq {
 struct in_addr imr_multiaddr;
 struct in_addr imr_interface;
};






struct ip_mreqn {
 struct in_addr imr_multiaddr;
 struct in_addr imr_address;
 int imr_ifindex;
};

#pragma pack(4)



struct ip_mreq_source {
 struct in_addr imr_multiaddr;
 struct in_addr imr_sourceaddr;
 struct in_addr imr_interface;
};





struct group_req {
 uint32_t gr_interface;
 struct sockaddr_storage gr_group;
};

struct group_source_req {
 uint32_t gsr_interface;
 struct sockaddr_storage gsr_group;
 struct sockaddr_storage gsr_source;
};
# 554 "/usr/include/netinet/in.h" 3 4
struct __msfilterreq {
 uint32_t msfr_ifindex;
 uint32_t msfr_fmode;
 uint32_t msfr_nsrcs;
 uint32_t __msfr_align;
 struct sockaddr_storage msfr_group;
 struct sockaddr_storage *msfr_srcs;
};



#pragma pack()
struct sockaddr;






int setipv4sourcefilter(int, struct in_addr, struct in_addr, uint32_t,
     uint32_t, struct in_addr *) __attribute__((visibility("default")));
int getipv4sourcefilter(int, struct in_addr, struct in_addr, uint32_t *,
     uint32_t *, struct in_addr *) __attribute__((visibility("default")));
int setsourcefilter(int, uint32_t, struct sockaddr *, socklen_t,
     uint32_t, uint32_t, struct sockaddr_storage *) __attribute__((visibility("default")));
int getsourcefilter(int, uint32_t, struct sockaddr *, socklen_t,
     uint32_t *, uint32_t *, struct sockaddr_storage *) __attribute__((visibility("default")));
# 617 "/usr/include/netinet/in.h" 3 4
struct in_pktinfo {
 unsigned int ipi_ifindex;
 struct in_addr ipi_spec_dst;
 struct in_addr ipi_addr;
};
# 661 "/usr/include/netinet/in.h" 3 4
# 1 "/usr/include/netinet6/in6.h" 1 3 4
# 158 "/usr/include/netinet6/in6.h" 3 4
struct in6_addr {
 union {
  __uint8_t __u6_addr8[16];
  __uint16_t __u6_addr16[8];
  __uint32_t __u6_addr32[4];
 } __u6_addr;
};
# 176 "/usr/include/netinet6/in6.h" 3 4
struct sockaddr_in6 {
 __uint8_t sin6_len;
 sa_family_t sin6_family;
 in_port_t sin6_port;
 __uint32_t sin6_flowinfo;
 struct in6_addr sin6_addr;
 __uint32_t sin6_scope_id;
};
# 218 "/usr/include/netinet6/in6.h" 3 4
extern const struct in6_addr in6addr_any;
extern const struct in6_addr in6addr_loopback;

extern const struct in6_addr in6addr_nodelocal_allnodes;
extern const struct in6_addr in6addr_linklocal_allnodes;
extern const struct in6_addr in6addr_linklocal_allrouters;
extern const struct in6_addr in6addr_linklocal_allv2routers;
# 526 "/usr/include/netinet6/in6.h" 3 4
struct ipv6_mreq {
 struct in6_addr ipv6mr_multiaddr;
 unsigned int ipv6mr_interface;
};




struct in6_pktinfo {
 struct in6_addr ipi6_addr;
 unsigned int ipi6_ifindex;
};




struct ip6_mtuinfo {
 struct sockaddr_in6 ip6m_addr;
 uint32_t ip6m_mtu;
};
# 621 "/usr/include/netinet6/in6.h" 3 4

struct cmsghdr;

extern int inet6_option_space(int);
extern int inet6_option_init(void *, struct cmsghdr **, int);
extern int inet6_option_append(struct cmsghdr *, const __uint8_t *,
 int, int);
extern __uint8_t *inet6_option_alloc(struct cmsghdr *, int, int, int);
extern int inet6_option_next(const struct cmsghdr *, __uint8_t **);
extern int inet6_option_find(const struct cmsghdr *, __uint8_t **, int);

extern size_t inet6_rthdr_space(int, int);
extern struct cmsghdr *inet6_rthdr_init(void *, int);
extern int inet6_rthdr_add(struct cmsghdr *, const struct in6_addr *,
  unsigned int);
extern int inet6_rthdr_lasthop(struct cmsghdr *, unsigned int);



extern int inet6_rthdr_segments(const struct cmsghdr *);
extern struct in6_addr *inet6_rthdr_getaddr(struct cmsghdr *, int);
extern int inet6_rthdr_getflags(const struct cmsghdr *, int);

extern int inet6_opt_init(void *, socklen_t);
extern int inet6_opt_append(void *, socklen_t, int, __uint8_t,
     socklen_t, __uint8_t, void **);
extern int inet6_opt_finish(void *, socklen_t, int);
extern int inet6_opt_set_val(void *, int, void *, socklen_t);

extern int inet6_opt_next(void *, socklen_t, int, __uint8_t *,
          socklen_t *, void **);
extern int inet6_opt_find(void *, socklen_t, int, __uint8_t,
     socklen_t *, void **);
extern int inet6_opt_get_val(void *, int, void *, socklen_t);
extern socklen_t inet6_rth_space(int, int);
extern void *inet6_rth_init(void *, socklen_t, int, int);
extern int inet6_rth_add(void *, const struct in6_addr *);
extern int inet6_rth_reverse(const void *, void *);
extern int inet6_rth_segments(const void *);
extern struct in6_addr *inet6_rth_getaddr(const void *, int);
extern void addrsel_policy_init(void);

# 662 "/usr/include/netinet/in.h" 2 3 4





int bindresvport(int, struct sockaddr_in *);
struct sockaddr;
int bindresvport_sa(int, struct sockaddr *);

# 25 "hba.c" 2
# 1 "/usr/include/arpa/inet.h" 1 3 4
# 95 "/usr/include/arpa/inet.h" 3 4


in_addr_t inet_addr(const char *);
char *inet_ntoa(struct in_addr);
const char *inet_ntop(int, const void *, char *, socklen_t);
int inet_pton(int, const char *, void *);

int ascii2addr(int, const char *, void *);
char *addr2ascii(int, const void *, int, char *);
int inet_aton(const char *, struct in_addr *);
in_addr_t inet_lnaof(struct in_addr);
struct in_addr inet_makeaddr(in_addr_t, in_addr_t);
in_addr_t inet_netof(struct in_addr);
in_addr_t inet_network(const char *);
char *inet_net_ntop(int, const void *, int, char *, __darwin_size_t);
int inet_net_pton(int, const char *, void *, __darwin_size_t);
char *inet_neta(in_addr_t, char *, __darwin_size_t);
unsigned int inet_nsap_addr(const char *, unsigned char *, int maxlen);
char *inet_nsap_ntoa(int, const unsigned char *, char *ascii);



# 26 "hba.c" 2
# 1 "./unistd.h" 1
# 27 "hba.c" 2

# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_collation.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_collation.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/genbki.h" 1
# 49 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/genbki.h"
typedef int aclitem;
typedef int pg_node_tree;
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_collation.h" 2
# 32 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_collation.h"
typedef struct FormData_pg_collation
{
 NameData collname;
 Oid collnamespace;
 Oid collowner;
 int4 collencoding;
 NameData collcollate;
 NameData collctype;
} FormData_pg_collation;






typedef FormData_pg_collation *Form_pg_collation;
# 66 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_collation.h"
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
# 29 "hba.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/ip.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/ip.h"
# 1 "./getaddrinfo.h" 1
# 26 "./getaddrinfo.h"
# 1 "./netdb.h" 1
# 27 "./getaddrinfo.h" 2
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/ip.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h"
# 1 "./netdb.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h" 2

# 1 "/usr/include/sys/un.h" 1 3 4
# 79 "/usr/include/sys/un.h" 3 4
struct sockaddr_un {
 unsigned char sun_len;
 sa_family_t sun_family;
 char sun_path[104];
};
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h" 2
# 62 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h"
typedef struct
{
 struct sockaddr_storage addr;
 socklen_t salen;
} SockAddr;
# 113 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h"
typedef uint32 ProtocolVersion;

typedef ProtocolVersion MsgType;
# 124 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h"
typedef uint32 PacketLen;
# 141 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h"
typedef struct StartupPacket
{
 ProtocolVersion protoVersion;
 char database[64];

 char user[32];
 char options[64];
 char unused[64];
 char tty[64];
} StartupPacket;

extern bool Db_user_namespace;
# 176 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h"
typedef uint32 AuthRequest;
# 189 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h"
typedef struct CancelRequestPacket
{

 MsgType cancelRequestCode;
 uint32 backendPID;
 uint32 cancelAuthCode;
} CancelRequestPacket;
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/ip.h" 2
# 28 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/ip.h"
typedef void (*PgIfAddrCallback) (struct sockaddr * addr,
             struct sockaddr * netmask,
             void *cb_data);

extern int pg_getaddrinfo_all(const char *hostname, const char *servname,
       const struct addrinfo * hintp,
       struct addrinfo ** result);
extern void pg_freeaddrinfo_all(int hint_ai_family, struct addrinfo * ai);

extern int pg_getnameinfo_all(const struct sockaddr_storage * addr, int salen,
       char *node, int nodelen,
       char *service, int servicelen,
       int flags);

extern int pg_range_sockaddr(const struct sockaddr_storage * addr,
      const struct sockaddr_storage * netaddr,
      const struct sockaddr_storage * netmask);

extern int pg_sockaddr_cidr_mask(struct sockaddr_storage * mask,
       char *numbits, int family);


extern void pg_promote_v4_to_v6_addr(struct sockaddr_storage * addr);
extern void pg_promote_v4_to_v6_mask(struct sockaddr_storage * addr);


extern int pg_foreach_ifaddr(PgIfAddrCallback callback, void *cb_data);
# 30 "hba.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h" 1
# 35 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
typedef struct StringInfoData
{
 char *data;
 int len;
 int maxlen;
 int cursor;
} StringInfoData;

typedef StringInfoData *StringInfo;
# 72 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
extern StringInfo makeStringInfo(void);






extern void initStringInfo(StringInfo str);






extern void resetStringInfo(StringInfo str);
# 95 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
extern void
appendStringInfo(StringInfo str, const char *fmt,...)

__attribute__((format(printf, 2, 3)));
# 108 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
extern bool
appendStringInfoVA(StringInfo str, const char *fmt, va_list args)
__attribute__((format(printf, 2, 0)));






extern void appendStringInfoString(StringInfo str, const char *s);






extern void appendStringInfoChar(StringInfo str, char ch);
# 140 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
extern void appendStringInfoSpaces(StringInfo str, int count);






extern void appendBinaryStringInfo(StringInfo str,
        const char *data, int datalen);





extern void enlargeStringInfo(StringInfo str, int needed);
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h"
# 1 "/usr/include/sys/time.h" 1 3 4
# 78 "/usr/include/sys/time.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 88 "/usr/include/sys/_structs.h" 3 4
struct timespec
{
 __darwin_time_t tv_sec;
 long tv_nsec;
};
# 79 "/usr/include/sys/time.h" 2 3 4
# 94 "/usr/include/sys/time.h" 3 4
struct itimerval {
 struct timeval it_interval;
 struct timeval it_value;
};
# 144 "/usr/include/sys/time.h" 3 4
struct timezone {
 int tz_minuteswest;
 int tz_dsttime;
};
# 187 "/usr/include/sys/time.h" 3 4
struct clockinfo {
 int hz;
 int tick;
 int tickadj;
 int stathz;
 int profhz;
};




# 1 "./time.h" 1 3 4
# 199 "/usr/include/sys/time.h" 2 3 4





int adjtime(const struct timeval *, struct timeval *);
int futimes(int, const struct timeval *);
int lutimes(const char *, const struct timeval *) __attribute__((visibility("default")));
int settimeofday(const struct timeval *, const struct timezone *);


int getitimer(int, struct itimerval *);
int gettimeofday(struct timeval * , void * );

# 1 "/usr/include/sys/_select.h" 1 3 4
# 39 "/usr/include/sys/_select.h" 3 4
int select(int, fd_set * , fd_set * ,
  fd_set * , struct timeval * )




  __asm("_" "select" "$1050")




  ;
# 214 "/usr/include/sys/time.h" 2 3 4

int setitimer(int, const struct itimerval * ,
  struct itimerval * );
int utimes(const char *, const struct timeval *);


# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h" 2






# 1 "/usr/include/netinet/tcp.h" 1 3 4
# 71 "/usr/include/netinet/tcp.h" 3 4
typedef __uint32_t tcp_seq;
typedef __uint32_t tcp_cc;
# 81 "/usr/include/netinet/tcp.h" 3 4
struct tcphdr {
 unsigned short th_sport;
 unsigned short th_dport;
 tcp_seq th_seq;
 tcp_seq th_ack;

 unsigned int th_x2:4,
   th_off:4;





 unsigned char th_flags;
# 105 "/usr/include/netinet/tcp.h" 3 4
 unsigned short th_win;
 unsigned short th_sum;
 unsigned short th_urp;
};
# 30 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h" 2
# 68 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h"
# 1 "/usr/include/math.h" 1 3 4
# 28 "/usr/include/math.h" 3 4
# 1 "/usr/include/architecture/i386/math.h" 1 3 4
# 49 "/usr/include/architecture/i386/math.h" 3 4
 typedef float float_t;
 typedef double double_t;
# 108 "/usr/include/architecture/i386/math.h" 3 4
extern int __math_errhandling ( void );
# 128 "/usr/include/architecture/i386/math.h" 3 4
extern int __fpclassifyf(float );
extern int __fpclassifyd(double );
extern int __fpclassify (long double);
# 163 "/usr/include/architecture/i386/math.h" 3 4
 static __inline__ int __inline_isfinitef (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isfinited (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isfinite (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_isinff (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isinfd (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isinf (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_isnanf (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnand (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnan (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_isnormalf (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnormald (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnormal (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_signbitf (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_signbitd (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_signbit (long double) __attribute__ ((always_inline));

 static __inline__ int __inline_isinff( float __x ) { return __builtin_fabsf(__x) == __builtin_inff(); }
 static __inline__ int __inline_isinfd( double __x ) { return __builtin_fabs(__x) == __builtin_inf(); }
 static __inline__ int __inline_isinf( long double __x ) { return __builtin_fabsl(__x) == __builtin_infl(); }
 static __inline__ int __inline_isfinitef( float __x ) { return __x == __x && __builtin_fabsf(__x) != __builtin_inff(); }
 static __inline__ int __inline_isfinited( double __x ) { return __x == __x && __builtin_fabs(__x) != __builtin_inf(); }
 static __inline__ int __inline_isfinite( long double __x ) { return __x == __x && __builtin_fabsl(__x) != __builtin_infl(); }
 static __inline__ int __inline_isnanf( float __x ) { return __x != __x; }
 static __inline__ int __inline_isnand( double __x ) { return __x != __x; }
 static __inline__ int __inline_isnan( long double __x ) { return __x != __x; }
 static __inline__ int __inline_signbitf( float __x ) { union{ float __f; unsigned int __u; }__u; __u.__f = __x; return (int)(__u.__u >> 31); }
 static __inline__ int __inline_signbitd( double __x ) { union{ double __f; unsigned int __u[2]; }__u; __u.__f = __x; return (int)(__u.__u[1] >> 31); }
 static __inline__ int __inline_signbit( long double __x ){ union{ long double __ld; struct{ unsigned int __m[2]; short __sexp; }__p; }__u; __u.__ld = __x; return (int) (((unsigned short) __u.__p.__sexp) >> 15); }
 static __inline__ int __inline_isnormalf( float __x ) { float fabsf = __builtin_fabsf(__x); if( __x != __x ) return 0; return fabsf < __builtin_inff() && fabsf >= 1.17549435e-38F; }
 static __inline__ int __inline_isnormald( double __x ) { double fabsf = __builtin_fabs(__x); if( __x != __x ) return 0; return fabsf < __builtin_inf() && fabsf >= 2.2250738585072014e-308; }
 static __inline__ int __inline_isnormal( long double __x ) { long double fabsf = __builtin_fabsl(__x); if( __x != __x ) return 0; return fabsf < __builtin_infl() && fabsf >= 3.36210314311209350626e-4932L; }
# 253 "/usr/include/architecture/i386/math.h" 3 4
extern double acos( double );
extern float acosf( float );

extern double asin( double );
extern float asinf( float );

extern double atan( double );
extern float atanf( float );

extern double atan2( double, double );
extern float atan2f( float, float );

extern double cos( double );
extern float cosf( float );

extern double sin( double );
extern float sinf( float );

extern double tan( double );
extern float tanf( float );

extern double acosh( double );
extern float acoshf( float );

extern double asinh( double );
extern float asinhf( float );

extern double atanh( double );
extern float atanhf( float );

extern double cosh( double );
extern float coshf( float );

extern double sinh( double );
extern float sinhf( float );

extern double tanh( double );
extern float tanhf( float );

extern double exp ( double );
extern float expf ( float );

extern double exp2 ( double );
extern float exp2f ( float );

extern double expm1 ( double );
extern float expm1f ( float );

extern double log ( double );
extern float logf ( float );

extern double log10 ( double );
extern float log10f ( float );

extern double log2 ( double );
extern float log2f ( float );

extern double log1p ( double );
extern float log1pf ( float );

extern double logb ( double );
extern float logbf ( float );

extern double modf ( double, double * );
extern float modff ( float, float * );

extern double ldexp ( double, int );
extern float ldexpf ( float, int );

extern double frexp ( double, int * );
extern float frexpf ( float, int * );

extern int ilogb ( double );
extern int ilogbf ( float );

extern double scalbn ( double, int );
extern float scalbnf ( float, int );

extern double scalbln ( double, long int );
extern float scalblnf ( float, long int );

extern double fabs( double );
extern float fabsf( float );

extern double cbrt( double );
extern float cbrtf( float );

extern double hypot ( double, double );
extern float hypotf ( float, float );

extern double pow ( double, double );
extern float powf ( float, float );

extern double sqrt( double );
extern float sqrtf( float );

extern double erf( double );
extern float erff( float );

extern double erfc( double );
extern float erfcf( float );






extern double lgamma( double );
extern float lgammaf( float );

extern double tgamma( double );
extern float tgammaf( float );

extern double ceil ( double );
extern float ceilf ( float );

extern double floor ( double );
extern float floorf ( float );

extern double nearbyint ( double );
extern float nearbyintf ( float );

extern double rint ( double );
extern float rintf ( float );

extern long int lrint ( double );
extern long int lrintf ( float );

extern double round ( double );
extern float roundf ( float );

extern long int lround ( double );
extern long int lroundf ( float );



    extern long long int llrint ( double );
    extern long long int llrintf ( float );
    extern long long int llround ( double );
    extern long long int llroundf ( float );


extern double trunc ( double );
extern float truncf ( float );

extern double fmod ( double, double );
extern float fmodf ( float, float );

extern double remainder ( double, double );
extern float remainderf ( float, float );

extern double remquo ( double, double, int * );
extern float remquof ( float, float, int * );

extern double copysign ( double, double );
extern float copysignf ( float, float );

extern double nan( const char * );
extern float nanf( const char * );

extern double nextafter ( double, double );
extern float nextafterf ( float, float );

extern double fdim ( double, double );
extern float fdimf ( float, float );

extern double fmax ( double, double );
extern float fmaxf ( float, float );

extern double fmin ( double, double );
extern float fminf ( float, float );

extern double fma ( double, double, double );
extern float fmaf ( float, float, float );

extern long double acosl(long double);
extern long double asinl(long double);
extern long double atanl(long double);
extern long double atan2l(long double, long double);
extern long double cosl(long double);
extern long double sinl(long double);
extern long double tanl(long double);
extern long double acoshl(long double);
extern long double asinhl(long double);
extern long double atanhl(long double);
extern long double coshl(long double);
extern long double sinhl(long double);
extern long double tanhl(long double);
extern long double expl(long double);
extern long double exp2l(long double);
extern long double expm1l(long double);
extern long double logl(long double);
extern long double log10l(long double);
extern long double log2l(long double);
extern long double log1pl(long double);
extern long double logbl(long double);
extern long double modfl(long double, long double *);
extern long double ldexpl(long double, int);
extern long double frexpl(long double, int *);
extern int ilogbl(long double);
extern long double scalbnl(long double, int);
extern long double scalblnl(long double, long int);
extern long double fabsl(long double);
extern long double cbrtl(long double);
extern long double hypotl(long double, long double);
extern long double powl(long double, long double);
extern long double sqrtl(long double);
extern long double erfl(long double);
extern long double erfcl(long double);






extern long double lgammal(long double);

extern long double tgammal(long double);
extern long double ceill(long double);
extern long double floorl(long double);
extern long double nearbyintl(long double);
extern long double rintl(long double);
extern long int lrintl(long double);
extern long double roundl(long double);
extern long int lroundl(long double);



    extern long long int llrintl(long double);
    extern long long int llroundl(long double);


extern long double truncl(long double);
extern long double fmodl(long double, long double);
extern long double remainderl(long double, long double);
extern long double remquol(long double, long double, int *);
extern long double copysignl(long double, long double);
extern long double nanl(const char *);
extern long double nextafterl(long double, long double);
extern double nexttoward(double, long double);
extern float nexttowardf(float, long double);
extern long double nexttowardl(long double, long double);
extern long double fdiml(long double, long double);
extern long double fmaxl(long double, long double);
extern long double fminl(long double, long double);
extern long double fmal(long double, long double, long double);
# 507 "/usr/include/architecture/i386/math.h" 3 4
extern double __inf( void );
extern float __inff( void );
extern long double __infl( void );
extern float __nan( void );


extern double j0 ( double );

extern double j1 ( double );

extern double jn ( int, double );

extern double y0 ( double );

extern double y1 ( double );

extern double yn ( int, double );

extern double scalb ( double, double );
# 543 "/usr/include/architecture/i386/math.h" 3 4
extern int signgam;
# 558 "/usr/include/architecture/i386/math.h" 3 4
extern long int rinttol ( double );


extern long int roundtol ( double );
# 570 "/usr/include/architecture/i386/math.h" 3 4
struct exception {
 int type;
 char *name;
 double arg1;
 double arg2;
 double retval;
};
# 601 "/usr/include/architecture/i386/math.h" 3 4
extern int finite ( double );


extern double gamma ( double );




extern int matherr ( struct exception * );





extern double significand ( double );






extern double drem ( double, double );
# 29 "/usr/include/math.h" 2 3 4
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 1 3 4






# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/syslimits.h" 1 3 4
# 8 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 2 3 4
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/float.h" 1 3 4
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h" 2
# 44 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h"
typedef int64 Timestamp;
typedef int64 TimestampTz;
typedef int64 TimeOffset;
typedef int32 fsec_t;
# 56 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h"
typedef struct
{
 TimeOffset time;

 int32 day;
 int32 month;
} Interval;
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/hba.h" 1
# 15 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/hba.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 1
# 40 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h" 1
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum NodeTag
{
 T_Invalid = 0,




 T_IndexInfo = 10,
 T_ExprContext,
 T_ProjectionInfo,
 T_JunkFilter,
 T_ResultRelInfo,
 T_EState,
 T_TupleTableSlot,




 T_Plan = 100,
 T_Result,
 T_ModifyTable,
 T_Append,
 T_MergeAppend,
 T_RecursiveUnion,
 T_BitmapAnd,
 T_BitmapOr,
 T_Scan,
 T_SeqScan,
 T_IndexScan,
 T_IndexOnlyScan,
 T_BitmapIndexScan,
 T_BitmapHeapScan,
 T_TidScan,
 T_SubqueryScan,
 T_FunctionScan,
 T_ValuesScan,
 T_CteScan,
 T_WorkTableScan,
 T_ForeignScan,
 T_Join,
 T_NestLoop,
 T_MergeJoin,
 T_HashJoin,
 T_Material,
 T_Sort,
 T_Group,
 T_Agg,
 T_WindowAgg,
 T_Unique,
 T_Hash,
 T_SetOp,
 T_LockRows,
 T_Limit,

 T_NestLoopParam,
 T_PlanRowMark,
 T_PlanInvalItem,






 T_PlanState = 200,
 T_ResultState,
 T_ModifyTableState,
 T_AppendState,
 T_MergeAppendState,
 T_RecursiveUnionState,
 T_BitmapAndState,
 T_BitmapOrState,
 T_ScanState,
 T_SeqScanState,
 T_IndexScanState,
 T_IndexOnlyScanState,
 T_BitmapIndexScanState,
 T_BitmapHeapScanState,
 T_TidScanState,
 T_SubqueryScanState,
 T_FunctionScanState,
 T_ValuesScanState,
 T_CteScanState,
 T_WorkTableScanState,
 T_ForeignScanState,
 T_JoinState,
 T_NestLoopState,
 T_MergeJoinState,
 T_HashJoinState,
 T_MaterialState,
 T_SortState,
 T_GroupState,
 T_AggState,
 T_WindowAggState,
 T_UniqueState,
 T_HashState,
 T_SetOpState,
 T_LockRowsState,
 T_LimitState,




 T_Alias = 300,
 T_RangeVar,
 T_Expr,
 T_Var,
 T_Const,
 T_Param,
 T_Aggref,
 T_WindowFunc,
 T_ArrayRef,
 T_FuncExpr,
 T_NamedArgExpr,
 T_OpExpr,
 T_DistinctExpr,
 T_NullIfExpr,
 T_ScalarArrayOpExpr,
 T_BoolExpr,
 T_SubLink,
 T_SubPlan,
 T_AlternativeSubPlan,
 T_FieldSelect,
 T_FieldStore,
 T_RelabelType,
 T_CoerceViaIO,
 T_ArrayCoerceExpr,
 T_ConvertRowtypeExpr,
 T_CollateExpr,
 T_CaseExpr,
 T_CaseWhen,
 T_CaseTestExpr,
 T_ArrayExpr,
 T_RowExpr,
 T_RowCompareExpr,
 T_CoalesceExpr,
 T_MinMaxExpr,
 T_XmlExpr,
 T_NullTest,
 T_BooleanTest,
 T_CoerceToDomain,
 T_CoerceToDomainValue,
 T_SetToDefault,
 T_CurrentOfExpr,
 T_TargetEntry,
 T_RangeTblRef,
 T_JoinExpr,
 T_FromExpr,
 T_IntoClause,







 T_ExprState = 400,
 T_GenericExprState,
 T_AggrefExprState,
 T_WindowFuncExprState,
 T_ArrayRefExprState,
 T_FuncExprState,
 T_ScalarArrayOpExprState,
 T_BoolExprState,
 T_SubPlanState,
 T_AlternativeSubPlanState,
 T_FieldSelectState,
 T_FieldStoreState,
 T_CoerceViaIOState,
 T_ArrayCoerceExprState,
 T_ConvertRowtypeExprState,
 T_CaseExprState,
 T_CaseWhenState,
 T_ArrayExprState,
 T_RowExprState,
 T_RowCompareExprState,
 T_CoalesceExprState,
 T_MinMaxExprState,
 T_XmlExprState,
 T_NullTestState,
 T_CoerceToDomainState,
 T_DomainConstraintState,
 T_WholeRowVarExprState,




 T_PlannerInfo = 500,
 T_PlannerGlobal,
 T_RelOptInfo,
 T_IndexOptInfo,
 T_ParamPathInfo,
 T_Path,
 T_IndexPath,
 T_BitmapHeapPath,
 T_BitmapAndPath,
 T_BitmapOrPath,
 T_NestPath,
 T_MergePath,
 T_HashPath,
 T_TidPath,
 T_ForeignPath,
 T_AppendPath,
 T_MergeAppendPath,
 T_ResultPath,
 T_MaterialPath,
 T_UniquePath,
 T_EquivalenceClass,
 T_EquivalenceMember,
 T_PathKey,
 T_RestrictInfo,
 T_PlaceHolderVar,
 T_SpecialJoinInfo,
 T_AppendRelInfo,
 T_PlaceHolderInfo,
 T_MinMaxAggInfo,
 T_PlannerParamItem,




 T_MemoryContext = 600,
 T_AllocSetContext,




 T_Value = 650,
 T_Integer,
 T_Float,
 T_String,
 T_BitString,
 T_Null,




 T_List,
 T_IntList,
 T_OidList,




 T_Query = 700,
 T_PlannedStmt,
 T_InsertStmt,
 T_DeleteStmt,
 T_UpdateStmt,
 T_SelectStmt,
 T_AlterTableStmt,
 T_AlterTableCmd,
 T_AlterDomainStmt,
 T_SetOperationStmt,
 T_GrantStmt,
 T_GrantRoleStmt,
 T_AlterDefaultPrivilegesStmt,
 T_ClosePortalStmt,
 T_ClusterStmt,
 T_CopyStmt,
 T_CreateStmt,
 T_DefineStmt,
 T_DropStmt,
 T_TruncateStmt,
 T_CommentStmt,
 T_FetchStmt,
 T_IndexStmt,
 T_CreateFunctionStmt,
 T_AlterFunctionStmt,
 T_DoStmt,
 T_RenameStmt,
 T_RuleStmt,
 T_NotifyStmt,
 T_ListenStmt,
 T_UnlistenStmt,
 T_TransactionStmt,
 T_ViewStmt,
 T_LoadStmt,
 T_CreateDomainStmt,
 T_CreatedbStmt,
 T_DropdbStmt,
 T_VacuumStmt,
 T_ExplainStmt,
 T_CreateTableAsStmt,
 T_CreateSeqStmt,
 T_AlterSeqStmt,
 T_VariableSetStmt,
 T_VariableShowStmt,
 T_DiscardStmt,
 T_CreateTrigStmt,
 T_CreatePLangStmt,
 T_CreateRoleStmt,
 T_AlterRoleStmt,
 T_DropRoleStmt,
 T_LockStmt,
 T_ConstraintsSetStmt,
 T_ReindexStmt,
 T_CheckPointStmt,
 T_CreateSchemaStmt,
 T_AlterDatabaseStmt,
 T_AlterDatabaseSetStmt,
 T_AlterRoleSetStmt,
 T_CreateConversionStmt,
 T_CreateCastStmt,
 T_CreateOpClassStmt,
 T_CreateOpFamilyStmt,
 T_AlterOpFamilyStmt,
 T_PrepareStmt,
 T_ExecuteStmt,
 T_DeallocateStmt,
 T_DeclareCursorStmt,
 T_CreateTableSpaceStmt,
 T_DropTableSpaceStmt,
 T_AlterObjectSchemaStmt,
 T_AlterOwnerStmt,
 T_DropOwnedStmt,
 T_ReassignOwnedStmt,
 T_CompositeTypeStmt,
 T_CreateEnumStmt,
 T_CreateRangeStmt,
 T_AlterEnumStmt,
 T_AlterTSDictionaryStmt,
 T_AlterTSConfigurationStmt,
 T_CreateFdwStmt,
 T_AlterFdwStmt,
 T_CreateForeignServerStmt,
 T_AlterForeignServerStmt,
 T_CreateUserMappingStmt,
 T_AlterUserMappingStmt,
 T_DropUserMappingStmt,
 T_AlterTableSpaceOptionsStmt,
 T_SecLabelStmt,
 T_CreateForeignTableStmt,
 T_CreateExtensionStmt,
 T_AlterExtensionStmt,
 T_AlterExtensionContentsStmt,




 T_A_Expr = 900,
 T_ColumnRef,
 T_ParamRef,
 T_A_Const,
 T_FuncCall,
 T_A_Star,
 T_A_Indices,
 T_A_Indirection,
 T_A_ArrayExpr,
 T_ResTarget,
 T_TypeCast,
 T_CollateClause,
 T_SortBy,
 T_WindowDef,
 T_RangeSubselect,
 T_RangeFunction,
 T_TypeName,
 T_ColumnDef,
 T_IndexElem,
 T_Constraint,
 T_DefElem,
 T_RangeTblEntry,
 T_SortGroupClause,
 T_WindowClause,
 T_PrivGrantee,
 T_FuncWithArgs,
 T_AccessPriv,
 T_CreateOpClassItem,
 T_TableLikeClause,
 T_FunctionParameter,
 T_LockingClause,
 T_RowMarkClause,
 T_XmlSerialize,
 T_WithClause,
 T_CommonTableExpr,




 T_IdentifySystemCmd,
 T_BaseBackupCmd,
 T_StartReplicationCmd,
# 416 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
 T_TriggerData = 950,
 T_ReturnSetInfo,
 T_WindowObjectData,
 T_TIDBitmap,
 T_InlineCodeBlock,
 T_FdwRoutine
} NodeTag;







typedef struct Node
{
 NodeTag type;
} Node;
# 491 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
extern char *nodeToString(const void *obj);




extern void *stringToNode(char *str);




extern void *copyObject(const void *obj);




extern bool equal(const void *a, const void *b);
# 517 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef double Selectivity;
typedef double Cost;
# 527 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum CmdType
{
 CMD_UNKNOWN,
 CMD_SELECT,
 CMD_UPDATE,
 CMD_INSERT,
 CMD_DELETE,
 CMD_UTILITY,

 CMD_NOTHING

} CmdType;
# 551 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum JoinType
{




 JOIN_INNER,
 JOIN_LEFT,
 JOIN_FULL,
 JOIN_RIGHT,
# 571 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
 JOIN_SEMI,
 JOIN_ANTI,





 JOIN_UNIQUE_OUTER,
 JOIN_UNIQUE_INNER




} JoinType;
# 41 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 2


typedef struct ListCell ListCell;

typedef struct List
{
 NodeTag type;
 int length;
 ListCell *head;
 ListCell *tail;
} List;

struct ListCell
{
 union
 {
  void *ptr_value;
  int int_value;
  Oid oid_value;
 } data;
 ListCell *next;
};
# 79 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
static inline ListCell *
list_head(const List *l)
{
 return l ? l->head : ((void *)0);
}

static inline ListCell *
list_tail(List *l)
{
 return l ? l->tail : ((void *)0);
}

static inline int
list_length(const List *l)
{
 return l ? l->length : 0;
}
# 194 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
extern List *lappend(List *list, void *datum);
extern List *lappend_int(List *list, int datum);
extern List *lappend_oid(List *list, Oid datum);

extern ListCell *lappend_cell(List *list, ListCell *prev, void *datum);
extern ListCell *lappend_cell_int(List *list, ListCell *prev, int datum);
extern ListCell *lappend_cell_oid(List *list, ListCell *prev, Oid datum);

extern List *lcons(void *datum, List *list);
extern List *lcons_int(int datum, List *list);
extern List *lcons_oid(Oid datum, List *list);

extern List *list_concat(List *list1, List *list2);
extern List *list_truncate(List *list, int new_size);

extern void *list_nth(const List *list, int n);
extern int list_nth_int(const List *list, int n);
extern Oid list_nth_oid(const List *list, int n);

extern bool list_member(const List *list, const void *datum);
extern bool list_member_ptr(const List *list, const void *datum);
extern bool list_member_int(const List *list, int datum);
extern bool list_member_oid(const List *list, Oid datum);

extern List *list_delete(List *list, void *datum);
extern List *list_delete_ptr(List *list, void *datum);
extern List *list_delete_int(List *list, int datum);
extern List *list_delete_oid(List *list, Oid datum);
extern List *list_delete_first(List *list);
extern List *list_delete_cell(List *list, ListCell *cell, ListCell *prev);

extern List *list_union(const List *list1, const List *list2);
extern List *list_union_ptr(const List *list1, const List *list2);
extern List *list_union_int(const List *list1, const List *list2);
extern List *list_union_oid(const List *list1, const List *list2);

extern List *list_intersection(const List *list1, const List *list2);



extern List *list_difference(const List *list1, const List *list2);
extern List *list_difference_ptr(const List *list1, const List *list2);
extern List *list_difference_int(const List *list1, const List *list2);
extern List *list_difference_oid(const List *list1, const List *list2);

extern List *list_append_unique(List *list, void *datum);
extern List *list_append_unique_ptr(List *list, void *datum);
extern List *list_append_unique_int(List *list, int datum);
extern List *list_append_unique_oid(List *list, Oid datum);

extern List *list_concat_unique(List *list1, List *list2);
extern List *list_concat_unique_ptr(List *list1, List *list2);
extern List *list_concat_unique_int(List *list1, List *list2);
extern List *list_concat_unique_oid(List *list1, List *list2);

extern void list_free(List *list);
extern void list_free_deep(List *list);

extern List *list_copy(const List *list);
extern List *list_copy_tail(const List *list, int nskip);
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/hba.h" 2


typedef enum UserAuth
{
 uaReject,
 uaImplicitReject,
 uaKrb5,
 uaTrust,
 uaIdent,
 uaPassword,
 uaMD5,
 uaGSS,
 uaSSPI,
 uaPAM,
 uaLDAP,
 uaCert,
 uaRADIUS,
 uaPeer
} UserAuth;

typedef enum IPCompareMethod
{
 ipCmpMask,
 ipCmpSameHost,
 ipCmpSameNet,
 ipCmpAll
} IPCompareMethod;

typedef enum ConnType
{
 ctLocal,
 ctHost,
 ctHostSSL,
 ctHostNoSSL
} ConnType;

typedef struct HbaLine
{
 int linenumber;
 ConnType conntype;
 List *databases;
 List *roles;
 struct sockaddr_storage addr;
 struct sockaddr_storage mask;
 IPCompareMethod ip_cmp_method;
 char *hostname;
 UserAuth auth_method;

 char *usermap;
 char *pamservice;
 bool ldaptls;
 char *ldapserver;
 int ldapport;
 char *ldapbinddn;
 char *ldapbindpasswd;
 char *ldapsearchattribute;
 char *ldapbasedn;
 char *ldapprefix;
 char *ldapsuffix;
 bool clientcert;
 char *krb_server_hostname;
 char *krb_realm;
 bool include_realm;
 char *radiusserver;
 char *radiussecret;
 char *radiusidentifier;
 int radiusport;
} HbaLine;


typedef struct Port hbaPort;

extern bool load_hba(void);
extern void load_ident(void);
extern void hba_getauthmethod(hbaPort *port);
extern int check_usermap(const char *usermap_name,
     const char *pg_role, const char *auth_user,
     bool case_sensitive);
extern bool pg_isblank(const char c);
# 70 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h" 2



typedef enum CAC_state
{
 CAC_OK, CAC_STARTUP, CAC_SHUTDOWN, CAC_RECOVERY, CAC_TOOMANY,
 CAC_WAITBACKUP
} CAC_state;
# 104 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h"
typedef struct Port
{
 pgsocket sock;
 bool noblock;
 ProtocolVersion proto;
 SockAddr laddr;
 SockAddr raddr;
 char *remote_host;
 char *remote_hostname;

 int remote_hostname_resolv;





 char *remote_port;
 CAC_state canAcceptConnections;






 char *database_name;
 char *user_name;
 char *cmdline_options;
 List *guc_options;




 HbaLine *hba;
 char md5Salt[4];






 TimestampTz SessionStartTime;
# 153 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h"
 int default_keepalives_idle;
 int default_keepalives_interval;
 int default_keepalives_count;
 int keepalives_idle;
 int keepalives_interval;
 int keepalives_count;
# 168 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h"
 void *gss;
# 181 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h"
} Port;


extern ProtocolVersion FrontendProtocol;



extern int pq_getkeepalivesidle(Port *port);
extern int pq_getkeepalivesinterval(Port *port);
extern int pq_getkeepalivescount(Port *port);

extern int pq_setkeepalivesidle(int idle, Port *port);
extern int pq_setkeepalivesinterval(int interval, Port *port);
extern int pq_setkeepalivescount(int count, Port *port);
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq.h" 2







typedef struct
{
 int len;
 int isint;
 union
 {
  int *ptr;
  int integer;
 } u;
} PQArgBlock;
# 47 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq.h"
extern int StreamServerPort(int family, char *hostName,
 unsigned short portNumber, char *unixSocketName, pgsocket ListenSocket[],
     int MaxListen);
extern int StreamConnection(pgsocket server_fd, Port *port);
extern void StreamClose(pgsocket sock);
extern void TouchSocketFile(void);
extern void pq_init(void);
extern void pq_comm_reset(void);
extern int pq_getbytes(char *s, size_t len);
extern int pq_getstring(StringInfo s);
extern int pq_getmessage(StringInfo s, int maxlen);
extern int pq_getbyte(void);
extern int pq_peekbyte(void);
extern int pq_getbyte_if_available(unsigned char *c);
extern int pq_putbytes(const char *s, size_t len);
extern int pq_flush(void);
extern int pq_flush_if_writable(void);
extern bool pq_is_send_pending(void);
extern int pq_putmessage(char msgtype, const char *s, size_t len);
extern void pq_putmessage_noblock(char msgtype, const char *s, size_t len);
extern void pq_startcopyout(void);
extern void pq_endcopyout(bool errorAbort);




extern char *ssl_cert_file;
extern char *ssl_key_file;
extern char *ssl_ca_file;
extern char *ssl_crl_file;

extern int secure_initialize(void);
extern bool secure_loaded_verify_locations(void);
extern void secure_destroy(void);
extern int secure_open_server(Port *port);
extern void secure_close(Port *port);
extern ssize_t secure_read(Port *port, void *ptr, size_t len);
extern ssize_t secure_write(Port *port, void *ptr, size_t len);
# 31 "hba.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/postmaster.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/postmaster.h"
extern bool EnableSSL;
extern int ReservedBackends;
extern int PostPortNumber;
extern int Unix_socket_permissions;
extern char *Unix_socket_group;
extern char *UnixSocketDir;
extern char *ListenAddresses;
extern bool ClientAuthInProgress;
extern int PreAuthDelay;
extern int AuthenticationTimeout;
extern bool Log_connections;
extern bool log_hostname;
extern bool enable_bonjour;
extern char *bonjour_name;
extern bool restart_after_crash;




extern int postmaster_alive_fds[2];
# 47 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/postmaster.h"
extern const char *progname;

extern int PostmasterMain(int argc, char *argv[]);
extern void ClosePostmasterPorts(bool am_syslogger);

extern int MaxLivePostmasterChildren(void);
# 32 "hba.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/regex/regex.h" 1
# 38 "/Users/parrt/tmp/postgresql-9.2.4/src/include/regex/regex.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/mb/pg_wchar.h" 1
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/mb/pg_wchar.h"
typedef unsigned int pg_wchar;
# 179 "/Users/parrt/tmp/postgresql-9.2.4/src/include/mb/pg_wchar.h"
typedef enum pg_enc
{
 PG_SQL_ASCII = 0,
 PG_EUC_JP,
 PG_EUC_CN,
 PG_EUC_KR,
 PG_EUC_TW,
 PG_EUC_JIS_2004,
 PG_UTF8,
 PG_MULE_INTERNAL,
 PG_LATIN1,
 PG_LATIN2,
 PG_LATIN3,
 PG_LATIN4,
 PG_LATIN5,
 PG_LATIN6,
 PG_LATIN7,
 PG_LATIN8,
 PG_LATIN9,
 PG_LATIN10,
 PG_WIN1256,
 PG_WIN1258,
 PG_WIN866,
 PG_WIN874,
 PG_KOI8R,
 PG_WIN1251,
 PG_WIN1252,
 PG_ISO_8859_5,
 PG_ISO_8859_6,
 PG_ISO_8859_7,
 PG_ISO_8859_8,
 PG_WIN1250,
 PG_WIN1253,
 PG_WIN1254,
 PG_WIN1255,
 PG_WIN1257,
 PG_KOI8U,



 PG_SJIS,
 PG_BIG5,
 PG_GBK,
 PG_UHC,
 PG_GB18030,
 PG_JOHAB,
 PG_SHIFT_JIS_2004,
 _PG_LAST_ENCODING_

} pg_enc;
# 251 "/Users/parrt/tmp/postgresql-9.2.4/src/include/mb/pg_wchar.h"
typedef struct pg_encname
{
 char *name;
 pg_enc encoding;
} pg_encname;

extern pg_encname pg_encname_tbl[];
extern unsigned int pg_encname_tbl_sz;







typedef struct pg_enc2name
{
 char *name;
 pg_enc encoding;



} pg_enc2name;

extern pg_enc2name pg_enc2name_tbl[];




typedef struct pg_enc2gettext
{
 pg_enc encoding;
 const char *name;
} pg_enc2gettext;

extern pg_enc2gettext pg_enc2gettext_tbl[];




typedef int (*mb2wchar_with_len_converter) (const unsigned char *from,
             pg_wchar *to,
             int len);

typedef int (*wchar2mb_with_len_converter) (const pg_wchar *from,
              unsigned char *to,
              int len);

typedef int (*mblen_converter) (const unsigned char *mbstr);

typedef int (*mbdisplaylen_converter) (const unsigned char *mbstr);

typedef bool (*mbcharacter_incrementer) (unsigned char *mbstr, int len);

typedef int (*mbverifier) (const unsigned char *mbstr, int len);

typedef struct
{
 mb2wchar_with_len_converter mb2wchar_with_len;

 wchar2mb_with_len_converter wchar2mb_with_len;

 mblen_converter mblen;
 mbdisplaylen_converter dsplen;
 mbverifier mbverify;
 int maxmblen;
} pg_wchar_tbl;

extern pg_wchar_tbl pg_wchar_table[];






typedef struct
{
 uint32 utf;
 uint32 code;
} pg_utf_to_local;




typedef struct
{
 uint32 code;
 uint32 utf;
} pg_local_to_utf;




typedef struct
{
 uint32 utf1;
 uint32 utf2;
 uint32 code;
} pg_utf_to_local_combined;




typedef struct
{
 uint32 code;
 uint32 utf1;
 uint32 utf2;
} pg_local_to_utf_combined;
# 379 "/Users/parrt/tmp/postgresql-9.2.4/src/include/mb/pg_wchar.h"
extern int pg_char_to_encoding(const char *name);
extern const char *pg_encoding_to_char(int encoding);
extern int pg_valid_server_encoding_id(int encoding);





extern pg_encname *pg_char_to_encname_struct(const char *name);

extern int pg_mb2wchar(const char *from, pg_wchar *to);
extern int pg_mb2wchar_with_len(const char *from, pg_wchar *to, int len);
extern int pg_encoding_mb2wchar_with_len(int encoding,
         const char *from, pg_wchar *to, int len);
extern int pg_wchar2mb(const pg_wchar *from, char *to);
extern int pg_wchar2mb_with_len(const pg_wchar *from, char *to, int len);
extern int pg_encoding_wchar2mb_with_len(int encoding,
         const pg_wchar *from, char *to, int len);
extern int pg_char_and_wchar_strcmp(const char *s1, const pg_wchar *s2);
extern int pg_wchar_strncmp(const pg_wchar *s1, const pg_wchar *s2, size_t n);
extern int pg_char_and_wchar_strncmp(const char *s1, const pg_wchar *s2, size_t n);
extern size_t pg_wchar_strlen(const pg_wchar *wstr);
extern int pg_mblen(const char *mbstr);
extern int pg_dsplen(const char *mbstr);
extern int pg_encoding_mblen(int encoding, const char *mbstr);
extern int pg_encoding_dsplen(int encoding, const char *mbstr);
extern int pg_encoding_verifymb(int encoding, const char *mbstr, int len);
extern int pg_mule_mblen(const unsigned char *mbstr);
extern int pg_mic_mblen(const unsigned char *mbstr);
extern int pg_mbstrlen(const char *mbstr);
extern int pg_mbstrlen_with_len(const char *mbstr, int len);
extern int pg_mbcliplen(const char *mbstr, int len, int limit);
extern int pg_encoding_mbcliplen(int encoding, const char *mbstr,
       int len, int limit);
extern int pg_mbcharcliplen(const char *mbstr, int len, int imit);
extern int pg_encoding_max_length(int encoding);
extern int pg_database_encoding_max_length(void);
extern mbcharacter_incrementer pg_database_encoding_character_incrementer(void);

extern int PrepareClientEncoding(int encoding);
extern int SetClientEncoding(int encoding);
extern void InitializeClientEncoding(void);
extern int pg_get_client_encoding(void);
extern const char *pg_get_client_encoding_name(void);

extern void SetDatabaseEncoding(int encoding);
extern int GetDatabaseEncoding(void);
extern const char *GetDatabaseEncodingName(void);
extern int GetPlatformEncoding(void);
extern void pg_bind_textdomain_codeset(const char *domainname);

extern int pg_valid_client_encoding(const char *name);
extern int pg_valid_server_encoding(const char *name);

extern unsigned char *unicode_to_utf8(pg_wchar c, unsigned char *utf8string);
extern pg_wchar utf8_to_unicode(const unsigned char *c);
extern int pg_utf_mblen(const unsigned char *);
extern unsigned char *pg_do_encoding_conversion(unsigned char *src, int len,
        int src_encoding,
        int dest_encoding);

extern char *pg_client_to_server(const char *s, int len);
extern char *pg_server_to_client(const char *s, int len);
extern char *pg_any_to_server(const char *s, int len, int encoding);
extern char *pg_server_to_any(const char *s, int len, int encoding);

extern unsigned short BIG5toCNS(unsigned short big5, unsigned char *lc);
extern unsigned short CNStoBIG5(unsigned short cns, unsigned char lc);

extern void LocalToUtf(const unsigned char *iso, unsigned char *utf,
     const pg_local_to_utf *map, const pg_local_to_utf_combined *cmap,
     int size1, int size2, int encoding, int len);

extern void UtfToLocal(const unsigned char *utf, unsigned char *iso,
     const pg_utf_to_local *map, const pg_utf_to_local_combined *cmap,
     int size1, int size2, int encoding, int len);

extern bool pg_verifymbstr(const char *mbstr, int len, bool noError);
extern bool pg_verify_mbstr(int encoding, const char *mbstr, int len,
    bool noError);
extern int pg_verify_mbstr_len(int encoding, const char *mbstr, int len,
     bool noError);

extern void check_encoding_conversion_args(int src_encoding,
          int dest_encoding,
          int len,
          int expected_src_encoding,
          int expected_dest_encoding);

extern void report_invalid_encoding(int encoding, const char *mbstr, int len);
extern void report_untranslatable_char(int src_encoding, int dest_encoding,
         const char *mbstr, int len);

extern void pg_ascii2mic(const unsigned char *l, unsigned char *p, int len);
extern void pg_mic2ascii(const unsigned char *mic, unsigned char *p, int len);
extern void latin2mic(const unsigned char *l, unsigned char *p, int len,
    int lc, int encoding);
extern void mic2latin(const unsigned char *mic, unsigned char *p, int len,
    int lc, int encoding);
extern void latin2mic_with_table(const unsigned char *l, unsigned char *p,
      int len, int lc, int encoding,
      const unsigned char *tab);
extern void mic2latin_with_table(const unsigned char *mic, unsigned char *p,
      int len, int lc, int encoding,
      const unsigned char *tab);

extern bool pg_utf8_islegal(const unsigned char *source, int length);
# 39 "/Users/parrt/tmp/postgresql-9.2.4/src/include/regex/regex.h" 2
# 48 "/Users/parrt/tmp/postgresql-9.2.4/src/include/regex/regex.h"
typedef long regoff_t;






typedef struct
{
 int re_magic;
 size_t re_nsub;
 long re_info;
# 74 "/Users/parrt/tmp/postgresql-9.2.4/src/include/regex/regex.h"
 int re_csize;
 char *re_endp;
 Oid re_collation;

 char *re_guts;
 char *re_fns;
} regex_t;


typedef struct
{
 regoff_t rm_so;
 regoff_t rm_eo;
} regmatch_t;


typedef struct
{
 regmatch_t rm_extend;
} rm_detail_t;
# 168 "/Users/parrt/tmp/postgresql-9.2.4/src/include/regex/regex.h"
extern int pg_regcomp(regex_t *, const pg_wchar *, size_t, int, Oid);
extern int pg_regexec(regex_t *, const pg_wchar *, size_t, size_t, rm_detail_t *, size_t, regmatch_t[], int);
extern int pg_regprefix(regex_t *, pg_wchar **, size_t *);
extern void pg_regfree(regex_t *);
extern size_t pg_regerror(int, const regex_t *, char *, size_t);
extern void pg_set_regex_collation(Oid collation);
# 33 "hba.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/replication/walsender.h" 1
# 15 "/Users/parrt/tmp/postgresql-9.2.4/src/include/replication/walsender.h"
# 1 "/usr/include/signal.h" 1 3 4
# 71 "/usr/include/signal.h" 3 4
extern const char *const sys_signame[32];
extern const char *const sys_siglist[32];



int raise(int);




void (*bsd_signal(int, void (*)(int)))(int);
int kill(pid_t, int) __asm("_" "kill" );
int killpg(pid_t, int) __asm("_" "killpg" );
int pthread_kill(pthread_t, int);
int pthread_sigmask(int, const sigset_t *, sigset_t *) __asm("_" "pthread_sigmask" );
int sigaction(int, const struct sigaction * ,
     struct sigaction * );
int sigaddset(sigset_t *, int);
int sigaltstack(const stack_t * , stack_t * ) __asm("_" "sigaltstack" );
int sigdelset(sigset_t *, int);
int sigemptyset(sigset_t *);
int sigfillset(sigset_t *);
int sighold(int);
int sigignore(int);
int siginterrupt(int, int);
int sigismember(const sigset_t *, int);
int sigpause(int) __asm("_" "sigpause" );
int sigpending(sigset_t *);
int sigprocmask(int, const sigset_t * , sigset_t * );
int sigrelse(int);
void (*sigset(int, void (*)(int)))(int);
int sigsuspend(const sigset_t *) __asm("_" "sigsuspend" );
int sigwait(const sigset_t * , int * ) __asm("_" "sigwait" );

void psignal(unsigned int, const char *);
int sigblock(int);
int sigsetmask(int);
int sigvec(int, struct sigvec *, struct sigvec *);






static __inline int
__sigbits(int __signo)
{
    return __signo > 32 ? 0 : (1 << (__signo - 1));
}
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/replication/walsender.h" 2

# 1 "./fmgr.h" 1
# 22 "./fmgr.h"
typedef struct Node *fmNodePtr;


typedef struct StringInfoData *fmStringInfo;
# 34 "./fmgr.h"
typedef struct FunctionCallInfoData *FunctionCallInfo;

typedef Datum (*PGFunction) (FunctionCallInfo fcinfo);
# 49 "./fmgr.h"
typedef struct FmgrInfo
{
 PGFunction fn_addr;
 Oid fn_oid;
 short fn_nargs;

 bool fn_strict;
 bool fn_retset;
 unsigned char fn_stats;
 void *fn_extra;
 MemoryContext fn_mcxt;
 fmNodePtr fn_expr;
} FmgrInfo;




typedef struct FunctionCallInfoData
{
 FmgrInfo *flinfo;
 fmNodePtr context;
 fmNodePtr resultinfo;
 Oid fncollation;
 bool isnull;
 short nargs;
 Datum arg[100];
 bool argnull[100];
} FunctionCallInfoData;





extern void fmgr_info(Oid functionId, FmgrInfo *finfo);






extern void fmgr_info_cxt(Oid functionId, FmgrInfo *finfo,
     MemoryContext mcxt);
# 99 "./fmgr.h"
extern void fmgr_info_copy(FmgrInfo *dstinfo, FmgrInfo *srcinfo,
      MemoryContext destcxt);
# 187 "./fmgr.h"
extern struct varlena *pg_detoast_datum(struct varlena * datum);
extern struct varlena *pg_detoast_datum_copy(struct varlena * datum);
extern struct varlena *pg_detoast_datum_slice(struct varlena * datum,
        int32 first, int32 count);
extern struct varlena *pg_detoast_datum_packed(struct varlena * datum);
# 332 "./fmgr.h"
typedef struct
{
 int api_version;

} Pg_finfo_record;


typedef const Pg_finfo_record *(*PGFInfoFunction) (void);
# 383 "./fmgr.h"
typedef struct
{
 int len;
 int version;
 int funcmaxargs;
 int indexmaxkeys;
 int namedatalen;
 int float4byval;
 int float8byval;
} Pg_magic_struct;
# 410 "./fmgr.h"
typedef const Pg_magic_struct *(*PGModuleMagicFunction) (void);
# 435 "./fmgr.h"
extern Datum DirectFunctionCall1Coll(PGFunction func, Oid collation,
      Datum arg1);
extern Datum DirectFunctionCall2Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2);
extern Datum DirectFunctionCall3Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3);
extern Datum DirectFunctionCall4Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4);
extern Datum DirectFunctionCall5Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5);
extern Datum DirectFunctionCall6Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6);
extern Datum DirectFunctionCall7Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7);
extern Datum DirectFunctionCall8Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8);
extern Datum DirectFunctionCall9Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8,
      Datum arg9);





extern Datum FunctionCall1Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1);
extern Datum FunctionCall2Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2);
extern Datum FunctionCall3Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3);
extern Datum FunctionCall4Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4);
extern Datum FunctionCall5Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5);
extern Datum FunctionCall6Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6);
extern Datum FunctionCall7Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7);
extern Datum FunctionCall8Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8);
extern Datum FunctionCall9Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8,
      Datum arg9);







extern Datum OidFunctionCall0Coll(Oid functionId, Oid collation);
extern Datum OidFunctionCall1Coll(Oid functionId, Oid collation,
      Datum arg1);
extern Datum OidFunctionCall2Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2);
extern Datum OidFunctionCall3Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3);
extern Datum OidFunctionCall4Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4);
extern Datum OidFunctionCall5Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5);
extern Datum OidFunctionCall6Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6);
extern Datum OidFunctionCall7Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7);
extern Datum OidFunctionCall8Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8);
extern Datum OidFunctionCall9Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8,
      Datum arg9);
# 602 "./fmgr.h"
extern Datum InputFunctionCall(FmgrInfo *flinfo, char *str,
      Oid typioparam, int32 typmod);
extern Datum OidInputFunctionCall(Oid functionId, char *str,
      Oid typioparam, int32 typmod);
extern char *OutputFunctionCall(FmgrInfo *flinfo, Datum val);
extern char *OidOutputFunctionCall(Oid functionId, Datum val);
extern Datum ReceiveFunctionCall(FmgrInfo *flinfo, fmStringInfo buf,
     Oid typioparam, int32 typmod);
extern Datum OidReceiveFunctionCall(Oid functionId, fmStringInfo buf,
        Oid typioparam, int32 typmod);
extern bytea *SendFunctionCall(FmgrInfo *flinfo, Datum val);
extern bytea *OidSendFunctionCall(Oid functionId, Datum val);





extern const Pg_finfo_record *fetch_finfo_record(void *filehandle, char *funcname);
extern void clear_external_function_hash(void *filehandle);
extern Oid fmgr_internal_function(const char *proname);
extern Oid get_fn_expr_rettype(FmgrInfo *flinfo);
extern Oid get_fn_expr_argtype(FmgrInfo *flinfo, int argnum);
extern Oid get_call_expr_argtype(fmNodePtr expr, int argnum);
extern bool get_fn_expr_arg_stable(FmgrInfo *flinfo, int argnum);
extern bool get_call_expr_arg_stable(fmNodePtr expr, int argnum);




extern char *Dynamic_library_path;

extern PGFunction load_external_function(char *filename, char *funcname,
        bool signalNotFound, void **filehandle);
extern PGFunction lookup_external_function(void *filehandle, char *funcname);
extern void load_file(const char *filename, bool restricted);
extern void **find_rendezvous_variable(const char *varName);
# 650 "./fmgr.h"
extern int AggCheckCallContext(FunctionCallInfo fcinfo,
     MemoryContext *aggcontext);
# 662 "./fmgr.h"
typedef enum FmgrHookEventType
{
 FHET_START,
 FHET_END,
 FHET_ABORT
} FmgrHookEventType;

typedef bool (*needs_fmgr_hook_type) (Oid fn_oid);

typedef void (*fmgr_hook_type) (FmgrHookEventType event,
           FmgrInfo *flinfo, Datum *arg);

extern needs_fmgr_hook_type needs_fmgr_hook;
extern fmgr_hook_type fmgr_hook;
# 693 "./fmgr.h"
extern char *fmgr(Oid procedureId,...);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/replication/walsender.h" 2


extern bool am_walsender;
extern bool am_cascading_walsender;
extern volatile sig_atomic_t walsender_shutdown_requested;
extern volatile sig_atomic_t walsender_ready_to_stop;


extern int max_wal_senders;
extern int replication_timeout;

extern int WalSenderMain(void);
extern void WalSndSignals(void);
extern Size WalSndShmemSize(void);
extern void WalSndShmemInit(void);
extern void WalSndWakeup(void);
extern void WalSndRqstFileReload(void);

extern Datum pg_stat_get_wal_senders(FunctionCallInfo fcinfo);
# 34 "hba.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/fd.h" 1
# 41 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/fd.h"
# 1 "./dirent.h" 1
# 9 "./dirent.h"
struct dirent
{
 long d_ino;
 unsigned short d_reclen;
 unsigned short d_namlen;
 char d_name[MAX_PATH];
};

typedef struct DIR DIR;

DIR *opendir(const char *);
struct dirent *readdir(DIR *);
int closedir(DIR *);
# 42 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/fd.h" 2






typedef char *FileName;

typedef int File;



extern int max_files_per_process;




extern int max_safe_fds;







extern File PathNameOpenFile(FileName fileName, int fileFlags, int fileMode);
extern File OpenTemporaryFile(bool interXact);
extern void FileClose(File file);
extern int FilePrefetch(File file, off_t offset, int amount);
extern int FileRead(File file, char *buffer, int amount);
extern int FileWrite(File file, char *buffer, int amount);
extern int FileSync(File file);
extern off_t FileSeek(File file, off_t offset, int whence);
extern int FileTruncate(File file, off_t offset);
extern char *FilePathName(File file);


extern FILE *AllocateFile(const char *name, const char *mode);
extern int FreeFile(FILE *file);


extern DIR *AllocateDir(const char *dirname);
extern struct dirent *ReadDir(DIR *dir, const char *dirname);
extern int FreeDir(DIR *dir);


extern int BasicOpenFile(FileName fileName, int fileFlags, int fileMode);


extern void InitFileAccess(void);
extern void set_max_safe_fds(void);
extern void closeAllVfds(void);
extern void SetTempTablespaces(Oid *tableSpaces, int numSpaces);
extern bool TempTablespacesAreSet(void);
extern Oid GetNextTempTableSpace(void);
extern void AtEOXact_Files(void);
extern void AtEOSubXact_Files(bool isCommit, SubTransactionId mySubid,
      SubTransactionId parentSubid);
extern void RemovePgTempFiles(void);

extern int pg_fsync(int fd);
extern int pg_fsync_no_writethrough(int fd);
extern int pg_fsync_writethrough(int fd);
extern int pg_fdatasync(int fd);
extern int pg_flush_data(int fd, off_t offset, off_t amount);
# 35 "hba.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/acl.h" 1
# 27 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/acl.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/bitmapset.h" 1
# 29 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/bitmapset.h"
typedef uint32 bitmapword;
typedef int32 signedbitmapword;

typedef struct Bitmapset
{
 int nwords;
 bitmapword words[1];
} Bitmapset;



typedef enum
{
 BMS_EQUAL,
 BMS_SUBSET1,
 BMS_SUBSET2,
 BMS_DIFFERENT
} BMS_Comparison;


typedef enum
{
 BMS_EMPTY_SET,
 BMS_SINGLETON,
 BMS_MULTIPLE
} BMS_Membership;






extern Bitmapset *bms_copy(const Bitmapset *a);
extern bool bms_equal(const Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_make_singleton(int x);
extern void bms_free(Bitmapset *a);

extern Bitmapset *bms_union(const Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_intersect(const Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_difference(const Bitmapset *a, const Bitmapset *b);
extern bool bms_is_subset(const Bitmapset *a, const Bitmapset *b);
extern BMS_Comparison bms_subset_compare(const Bitmapset *a, const Bitmapset *b);
extern bool bms_is_member(int x, const Bitmapset *a);
extern bool bms_overlap(const Bitmapset *a, const Bitmapset *b);
extern bool bms_nonempty_difference(const Bitmapset *a, const Bitmapset *b);
extern int bms_singleton_member(const Bitmapset *a);
extern int bms_num_members(const Bitmapset *a);


extern BMS_Membership bms_membership(const Bitmapset *a);
extern bool bms_is_empty(const Bitmapset *a);



extern Bitmapset *bms_add_member(Bitmapset *a, int x);
extern Bitmapset *bms_del_member(Bitmapset *a, int x);
extern Bitmapset *bms_add_members(Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_int_members(Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_del_members(Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_join(Bitmapset *a, Bitmapset *b);


extern int bms_first_member(Bitmapset *a);


extern uint32 bms_hash_value(const Bitmapset *a);
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h"
typedef int16 AttrNumber;
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 2
# 38 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Alias
{
 NodeTag type;
 char *aliasname;
 List *colnames;
} Alias;

typedef enum InhOption
{
 INH_NO,
 INH_YES,
 INH_DEFAULT
} InhOption;


typedef enum OnCommitAction
{
 ONCOMMIT_NOOP,
 ONCOMMIT_PRESERVE_ROWS,
 ONCOMMIT_DELETE_ROWS,
 ONCOMMIT_DROP
} OnCommitAction;
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RangeVar
{
 NodeTag type;
 char *catalogname;
 char *schemaname;
 char *relname;
 InhOption inhOpt;

 char relpersistence;
 Alias *alias;
 int location;
} RangeVar;




typedef struct IntoClause
{
 NodeTag type;

 RangeVar *rel;
 List *colNames;
 List *options;
 OnCommitAction onCommit;
 char *tableSpaceName;
 bool skipData;
} IntoClause;
# 111 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Expr
{
 NodeTag type;
} Expr;
# 138 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Var
{
 Expr xpr;
 Index varno;

 AttrNumber varattno;

 Oid vartype;
 int32 vartypmod;
 Oid varcollid;
 Index varlevelsup;


 Index varnoold;
 AttrNumber varoattno;
 int location;
} Var;




typedef struct Const
{
 Expr xpr;
 Oid consttype;
 int32 consttypmod;
 Oid constcollid;
 int constlen;
 Datum constvalue;
 bool constisnull;

 bool constbyval;



 int location;
} Const;
# 201 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum ParamKind
{
 PARAM_EXTERN,
 PARAM_EXEC,
 PARAM_SUBLINK
} ParamKind;

typedef struct Param
{
 Expr xpr;
 ParamKind paramkind;
 int paramid;
 Oid paramtype;
 int32 paramtypmod;
 Oid paramcollid;
 int location;
} Param;
# 234 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Aggref
{
 Expr xpr;
 Oid aggfnoid;
 Oid aggtype;
 Oid aggcollid;
 Oid inputcollid;
 List *args;
 List *aggorder;
 List *aggdistinct;
 bool aggstar;
 Index agglevelsup;
 int location;
} Aggref;




typedef struct WindowFunc
{
 Expr xpr;
 Oid winfnoid;
 Oid wintype;
 Oid wincollid;
 Oid inputcollid;
 List *args;
 Index winref;
 bool winstar;
 bool winagg;
 int location;
} WindowFunc;
# 288 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ArrayRef
{
 Expr xpr;
 Oid refarraytype;
 Oid refelemtype;
 int32 reftypmod;
 Oid refcollid;
 List *refupperindexpr;

 List *reflowerindexpr;

 Expr *refexpr;

 Expr *refassgnexpr;

} ArrayRef;







typedef enum CoercionContext
{
 COERCION_IMPLICIT,
 COERCION_ASSIGNMENT,
 COERCION_EXPLICIT
} CoercionContext;
# 327 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum CoercionForm
{
 COERCE_EXPLICIT_CALL,
 COERCE_EXPLICIT_CAST,
 COERCE_IMPLICIT_CAST,
 COERCE_DONTCARE
} CoercionForm;




typedef struct FuncExpr
{
 Expr xpr;
 Oid funcid;
 Oid funcresulttype;
 bool funcretset;
 CoercionForm funcformat;
 Oid funccollid;
 Oid inputcollid;
 List *args;
 int location;
} FuncExpr;
# 365 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct NamedArgExpr
{
 Expr xpr;
 Expr *arg;
 char *name;
 int argnumber;
 int location;
} NamedArgExpr;
# 383 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct OpExpr
{
 Expr xpr;
 Oid opno;
 Oid opfuncid;
 Oid opresulttype;
 bool opretset;
 Oid opcollid;
 Oid inputcollid;
 List *args;
 int location;
} OpExpr;
# 406 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef OpExpr DistinctExpr;







typedef OpExpr NullIfExpr;
# 426 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ScalarArrayOpExpr
{
 Expr xpr;
 Oid opno;
 Oid opfuncid;
 bool useOr;
 Oid inputcollid;
 List *args;
 int location;
} ScalarArrayOpExpr;
# 448 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum BoolExprType
{
 AND_EXPR, OR_EXPR, NOT_EXPR
} BoolExprType;

typedef struct BoolExpr
{
 Expr xpr;
 BoolExprType boolop;
 List *args;
 int location;
} BoolExpr;
# 504 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum SubLinkType
{
 EXISTS_SUBLINK,
 ALL_SUBLINK,
 ANY_SUBLINK,
 ROWCOMPARE_SUBLINK,
 EXPR_SUBLINK,
 ARRAY_SUBLINK,
 CTE_SUBLINK
} SubLinkType;


typedef struct SubLink
{
 Expr xpr;
 SubLinkType subLinkType;
 Node *testexpr;
 List *operName;
 Node *subselect;
 int location;
} SubLink;
# 564 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct SubPlan
{
 Expr xpr;

 SubLinkType subLinkType;

 Node *testexpr;
 List *paramIds;

 int plan_id;

 char *plan_name;

 Oid firstColType;
 int32 firstColTypmod;
 Oid firstColCollation;


 bool useHashTable;

 bool unknownEqFalse;




 List *setParam;

 List *parParam;
 List *args;

 Cost startup_cost;
 Cost per_call_cost;
} SubPlan;
# 606 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct AlternativeSubPlan
{
 Expr xpr;
 List *subplans;
} AlternativeSubPlan;
# 621 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct FieldSelect
{
 Expr xpr;
 Expr *arg;
 AttrNumber fieldnum;
 Oid resulttype;

 int32 resulttypmod;
 Oid resultcollid;
} FieldSelect;
# 647 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct FieldStore
{
 Expr xpr;
 Expr *arg;
 List *newvals;
 List *fieldnums;
 Oid resulttype;

} FieldStore;
# 670 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RelabelType
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;
 int32 resulttypmod;
 Oid resultcollid;
 CoercionForm relabelformat;
 int location;
} RelabelType;
# 690 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CoerceViaIO
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;

 Oid resultcollid;
 CoercionForm coerceformat;
 int location;
} CoerceViaIO;
# 713 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ArrayCoerceExpr
{
 Expr xpr;
 Expr *arg;
 Oid elemfuncid;
 Oid resulttype;
 int32 resulttypmod;
 Oid resultcollid;
 bool isExplicit;
 CoercionForm coerceformat;
 int location;
} ArrayCoerceExpr;
# 738 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ConvertRowtypeExpr
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;

 CoercionForm convertformat;
 int location;
} ConvertRowtypeExpr;
# 755 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CollateExpr
{
 Expr xpr;
 Expr *arg;
 Oid collOid;
 int location;
} CollateExpr;
# 785 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CaseExpr
{
 Expr xpr;
 Oid casetype;
 Oid casecollid;
 Expr *arg;
 List *args;
 Expr *defresult;
 int location;
} CaseExpr;




typedef struct CaseWhen
{
 Expr xpr;
 Expr *expr;
 Expr *result;
 int location;
} CaseWhen;
# 815 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CaseTestExpr
{
 Expr xpr;
 Oid typeId;
 int32 typeMod;
 Oid collation;
} CaseTestExpr;
# 831 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ArrayExpr
{
 Expr xpr;
 Oid array_typeid;
 Oid array_collid;
 Oid element_typeid;
 List *elements;
 bool multidims;
 int location;
} ArrayExpr;
# 865 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RowExpr
{
 Expr xpr;
 List *args;
 Oid row_typeid;
# 880 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
 CoercionForm row_format;
 List *colnames;
 int location;
} RowExpr;
# 899 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum RowCompareType
{

 ROWCOMPARE_LT = 1,
 ROWCOMPARE_LE = 2,
 ROWCOMPARE_EQ = 3,
 ROWCOMPARE_GE = 4,
 ROWCOMPARE_GT = 5,
 ROWCOMPARE_NE = 6
} RowCompareType;

typedef struct RowCompareExpr
{
 Expr xpr;
 RowCompareType rctype;
 List *opnos;
 List *opfamilies;
 List *inputcollids;
 List *largs;
 List *rargs;
} RowCompareExpr;




typedef struct CoalesceExpr
{
 Expr xpr;
 Oid coalescetype;
 Oid coalescecollid;
 List *args;
 int location;
} CoalesceExpr;




typedef enum MinMaxOp
{
 IS_GREATEST,
 IS_LEAST
} MinMaxOp;

typedef struct MinMaxExpr
{
 Expr xpr;
 Oid minmaxtype;
 Oid minmaxcollid;
 Oid inputcollid;
 MinMaxOp op;
 List *args;
 int location;
} MinMaxExpr;
# 965 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum XmlExprOp
{
 IS_XMLCONCAT,
 IS_XMLELEMENT,
 IS_XMLFOREST,
 IS_XMLPARSE,
 IS_XMLPI,
 IS_XMLROOT,
 IS_XMLSERIALIZE,
 IS_DOCUMENT
} XmlExprOp;

typedef enum
{
 XMLOPTION_DOCUMENT,
 XMLOPTION_CONTENT
} XmlOptionType;

typedef struct XmlExpr
{
 Expr xpr;
 XmlExprOp op;
 char *name;
 List *named_args;
 List *arg_names;
 List *args;
 XmlOptionType xmloption;
 Oid type;
 int32 typmod;
 int location;
} XmlExpr;
# 1008 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum NullTestType
{
 IS_NULL, IS_NOT_NULL
} NullTestType;

typedef struct NullTest
{
 Expr xpr;
 Expr *arg;
 NullTestType nulltesttype;
 bool argisrow;
} NullTest;
# 1030 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum BoolTestType
{
 IS_TRUE, IS_NOT_TRUE, IS_FALSE, IS_NOT_FALSE, IS_UNKNOWN, IS_NOT_UNKNOWN
} BoolTestType;

typedef struct BooleanTest
{
 Expr xpr;
 Expr *arg;
 BoolTestType booltesttype;
} BooleanTest;
# 1051 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CoerceToDomain
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;
 int32 resulttypmod;
 Oid resultcollid;
 CoercionForm coercionformat;
 int location;
} CoerceToDomain;
# 1071 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CoerceToDomainValue
{
 Expr xpr;
 Oid typeId;
 int32 typeMod;
 Oid collation;
 int location;
} CoerceToDomainValue;
# 1087 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct SetToDefault
{
 Expr xpr;
 Oid typeId;
 int32 typeMod;
 Oid collation;
 int location;
} SetToDefault;
# 1108 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CurrentOfExpr
{
 Expr xpr;
 Index cvarno;
 char *cursor_name;
 int cursor_param;
} CurrentOfExpr;
# 1170 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct TargetEntry
{
 Expr xpr;
 Expr *expr;
 AttrNumber resno;
 char *resname;
 Index ressortgroupref;

 Oid resorigtbl;
 AttrNumber resorigcol;
 bool resjunk;

} TargetEntry;
# 1222 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RangeTblRef
{
 NodeTag type;
 int rtindex;
} RangeTblRef;
# 1251 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct JoinExpr
{
 NodeTag type;
 JoinType jointype;
 bool isNatural;
 Node *larg;
 Node *rarg;
 List *usingClause;
 Node *quals;
 Alias *alias;
 int rtindex;
} JoinExpr;
# 1273 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct FromExpr
{
 NodeTag type;
 List *fromlist;
 Node *quals;
} FromExpr;
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/value.h" 1
# 42 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/value.h"
typedef struct Value
{
 NodeTag type;
 union ValUnion
 {
  long ival;
  char *str;
 } val;
} Value;





extern Value *makeInteger(long i);
extern Value *makeFloat(char *numericStr);
extern Value *makeString(char *str);
extern Value *makeBitString(char *str);
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 2


typedef enum QuerySource
{
 QSRC_ORIGINAL,
 QSRC_PARSER,
 QSRC_INSTEAD_RULE,
 QSRC_QUAL_INSTEAD_RULE,
 QSRC_NON_INSTEAD_RULE
} QuerySource;


typedef enum SortByDir
{
 SORTBY_DEFAULT,
 SORTBY_ASC,
 SORTBY_DESC,
 SORTBY_USING
} SortByDir;

typedef enum SortByNulls
{
 SORTBY_NULLS_DEFAULT,
 SORTBY_NULLS_FIRST,
 SORTBY_NULLS_LAST
} SortByNulls;
# 60 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef uint32 AclMode;
# 98 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct Query
{
 NodeTag type;

 CmdType commandType;

 QuerySource querySource;

 uint32 queryId;

 bool canSetTag;

 Node *utilityStmt;


 int resultRelation;


 bool hasAggs;
 bool hasWindowFuncs;
 bool hasSubLinks;
 bool hasDistinctOn;
 bool hasRecursive;
 bool hasModifyingCTE;
 bool hasForUpdate;

 List *cteList;

 List *rtable;
 FromExpr *jointree;

 List *targetList;

 List *returningList;

 List *groupClause;

 Node *havingQual;

 List *windowClause;

 List *distinctClause;

 List *sortClause;

 Node *limitOffset;
 Node *limitCount;

 List *rowMarks;

 Node *setOperations;


 List *constraintDeps;

} Query;
# 177 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct TypeName
{
 NodeTag type;
 List *names;
 Oid typeOid;
 bool setof;
 bool pct_type;
 List *typmods;
 int32 typemod;
 List *arrayBounds;
 int location;
} TypeName;
# 203 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ColumnRef
{
 NodeTag type;
 List *fields;
 int location;
} ColumnRef;




typedef struct ParamRef
{
 NodeTag type;
 int number;
 int location;
} ParamRef;




typedef enum A_Expr_Kind
{
 AEXPR_OP,
 AEXPR_AND,
 AEXPR_OR,
 AEXPR_NOT,
 AEXPR_OP_ANY,
 AEXPR_OP_ALL,
 AEXPR_DISTINCT,
 AEXPR_NULLIF,
 AEXPR_OF,
 AEXPR_IN
} A_Expr_Kind;

typedef struct A_Expr
{
 NodeTag type;
 A_Expr_Kind kind;
 List *name;
 Node *lexpr;
 Node *rexpr;
 int location;
} A_Expr;




typedef struct A_Const
{
 NodeTag type;
 Value val;
 int location;
} A_Const;




typedef struct TypeCast
{
 NodeTag type;
 Node *arg;
 TypeName *typeName;
 int location;
} TypeCast;




typedef struct CollateClause
{
 NodeTag type;
 Node *arg;
 List *collname;
 int location;
} CollateClause;
# 289 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct FuncCall
{
 NodeTag type;
 List *funcname;
 List *args;
 List *agg_order;
 bool agg_star;
 bool agg_distinct;
 bool func_variadic;
 struct WindowDef *over;
 int location;
} FuncCall;







typedef struct A_Star
{
 NodeTag type;
} A_Star;




typedef struct A_Indices
{
 NodeTag type;
 Node *lidx;
 Node *uidx;
} A_Indices;
# 338 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct A_Indirection
{
 NodeTag type;
 Node *arg;
 List *indirection;
} A_Indirection;




typedef struct A_ArrayExpr
{
 NodeTag type;
 List *elements;
 int location;
} A_ArrayExpr;
# 373 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ResTarget
{
 NodeTag type;
 char *name;
 List *indirection;
 Node *val;
 int location;
} ResTarget;




typedef struct SortBy
{
 NodeTag type;
 Node *node;
 SortByDir sortby_dir;
 SortByNulls sortby_nulls;
 List *useOp;
 int location;
} SortBy;
# 403 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct WindowDef
{
 NodeTag type;
 char *name;
 char *refname;
 List *partitionClause;
 List *orderClause;
 int frameOptions;
 Node *startOffset;
 Node *endOffset;
 int location;
} WindowDef;
# 451 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct RangeSubselect
{
 NodeTag type;
 Node *subquery;
 Alias *alias;
} RangeSubselect;




typedef struct RangeFunction
{
 NodeTag type;
 Node *funccallnode;
 Alias *alias;
 List *coldeflist;

} RangeFunction;
# 488 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ColumnDef
{
 NodeTag type;
 char *colname;
 TypeName *typeName;
 int inhcount;
 bool is_local;
 bool is_not_null;
 bool is_from_type;
 char storage;
 Node *raw_default;
 Node *cooked_default;
 CollateClause *collClause;
 Oid collOid;
 List *constraints;
 List *fdwoptions;
} ColumnDef;




typedef struct TableLikeClause
{
 NodeTag type;
 RangeVar *relation;
 bits32 options;
} TableLikeClause;

typedef enum TableLikeOption
{
 CREATE_TABLE_LIKE_DEFAULTS = 1 << 0,
 CREATE_TABLE_LIKE_CONSTRAINTS = 1 << 1,
 CREATE_TABLE_LIKE_INDEXES = 1 << 2,
 CREATE_TABLE_LIKE_STORAGE = 1 << 3,
 CREATE_TABLE_LIKE_COMMENTS = 1 << 4,
 CREATE_TABLE_LIKE_ALL = 0x7FFFFFFF
} TableLikeOption;
# 533 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct IndexElem
{
 NodeTag type;
 char *name;
 Node *expr;
 char *indexcolname;
 List *collation;
 List *opclass;
 SortByDir ordering;
 SortByNulls nulls_ordering;
} IndexElem;
# 555 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum DefElemAction
{
 DEFELEM_UNSPEC,
 DEFELEM_SET,
 DEFELEM_ADD,
 DEFELEM_DROP
} DefElemAction;

typedef struct DefElem
{
 NodeTag type;
 char *defnamespace;
 char *defname;
 Node *arg;
 DefElemAction defaction;
} DefElem;
# 580 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct LockingClause
{
 NodeTag type;
 List *lockedRels;
 bool forUpdate;
 bool noWait;
} LockingClause;




typedef struct XmlSerialize
{
 NodeTag type;
 XmlOptionType xmloption;
 Node *expr;
 TypeName *typeName;
 int location;
} XmlSerialize;
# 677 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum RTEKind
{
 RTE_RELATION,
 RTE_SUBQUERY,
 RTE_JOIN,
 RTE_FUNCTION,
 RTE_VALUES,
 RTE_CTE
} RTEKind;

typedef struct RangeTblEntry
{
 NodeTag type;

 RTEKind rtekind;
# 702 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 Oid relid;
 char relkind;




 Query *subquery;
 bool security_barrier;
# 722 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 JoinType jointype;
 List *joinaliasvars;
# 733 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 Node *funcexpr;
 List *funccoltypes;
 List *funccoltypmods;
 List *funccolcollations;




 List *values_lists;
 List *values_collations;




 char *ctename;
 Index ctelevelsup;
 bool self_reference;
 List *ctecoltypes;
 List *ctecoltypmods;
 List *ctecolcollations;




 Alias *alias;
 Alias *eref;
 bool inh;
 bool inFromCl;
 AclMode requiredPerms;
 Oid checkAsUser;
 Bitmapset *selectedCols;
 Bitmapset *modifiedCols;
} RangeTblEntry;
# 825 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct SortGroupClause
{
 NodeTag type;
 Index tleSortGroupRef;
 Oid eqop;
 Oid sortop;
 bool nulls_first;
 bool hashable;
} SortGroupClause;
# 849 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct WindowClause
{
 NodeTag type;
 char *name;
 char *refname;
 List *partitionClause;
 List *orderClause;
 int frameOptions;
 Node *startOffset;
 Node *endOffset;
 Index winref;
 bool copiedOrder;
} WindowClause;
# 875 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct RowMarkClause
{
 NodeTag type;
 Index rti;
 bool forUpdate;
 bool noWait;
 bool pushedDown;
} RowMarkClause;
# 891 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct WithClause
{
 NodeTag type;
 List *ctes;
 bool recursive;
 int location;
} WithClause;







typedef struct CommonTableExpr
{
 NodeTag type;
 char *ctename;
 List *aliascolnames;

 Node *ctequery;
 int location;

 bool cterecursive;
 int cterefcount;

 List *ctecolnames;
 List *ctecoltypes;
 List *ctecoltypmods;
 List *ctecolcollations;
} CommonTableExpr;
# 943 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct InsertStmt
{
 NodeTag type;
 RangeVar *relation;
 List *cols;
 Node *selectStmt;
 List *returningList;
 WithClause *withClause;
} InsertStmt;





typedef struct DeleteStmt
{
 NodeTag type;
 RangeVar *relation;
 List *usingClause;
 Node *whereClause;
 List *returningList;
 WithClause *withClause;
} DeleteStmt;





typedef struct UpdateStmt
{
 NodeTag type;
 RangeVar *relation;
 List *targetList;
 Node *whereClause;
 List *fromClause;
 List *returningList;
 WithClause *withClause;
} UpdateStmt;
# 995 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum SetOperation
{
 SETOP_NONE = 0,
 SETOP_UNION,
 SETOP_INTERSECT,
 SETOP_EXCEPT
} SetOperation;

typedef struct SelectStmt
{
 NodeTag type;




 List *distinctClause;

 IntoClause *intoClause;
 List *targetList;
 List *fromClause;
 Node *whereClause;
 List *groupClause;
 Node *havingClause;
 List *windowClause;
 WithClause *withClause;
# 1029 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 List *valuesLists;





 List *sortClause;
 Node *limitOffset;
 Node *limitCount;
 List *lockingClause;




 SetOperation op;
 bool all;
 struct SelectStmt *larg;
 struct SelectStmt *rarg;

} SelectStmt;
# 1070 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct SetOperationStmt
{
 NodeTag type;
 SetOperation op;
 bool all;
 Node *larg;
 Node *rarg;



 List *colTypes;
 List *colTypmods;
 List *colCollations;
 List *groupClauses;

} SetOperationStmt;
# 1105 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum ObjectType
{
 OBJECT_AGGREGATE,
 OBJECT_ATTRIBUTE,
 OBJECT_CAST,
 OBJECT_COLUMN,
 OBJECT_CONSTRAINT,
 OBJECT_COLLATION,
 OBJECT_CONVERSION,
 OBJECT_DATABASE,
 OBJECT_DOMAIN,
 OBJECT_EXTENSION,
 OBJECT_FDW,
 OBJECT_FOREIGN_SERVER,
 OBJECT_FOREIGN_TABLE,
 OBJECT_FUNCTION,
 OBJECT_INDEX,
 OBJECT_LANGUAGE,
 OBJECT_LARGEOBJECT,
 OBJECT_OPCLASS,
 OBJECT_OPERATOR,
 OBJECT_OPFAMILY,
 OBJECT_ROLE,
 OBJECT_RULE,
 OBJECT_SCHEMA,
 OBJECT_SEQUENCE,
 OBJECT_TABLE,
 OBJECT_TABLESPACE,
 OBJECT_TRIGGER,
 OBJECT_TSCONFIGURATION,
 OBJECT_TSDICTIONARY,
 OBJECT_TSPARSER,
 OBJECT_TSTEMPLATE,
 OBJECT_TYPE,
 OBJECT_VIEW
} ObjectType;
# 1150 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CreateSchemaStmt
{
 NodeTag type;
 char *schemaname;
 char *authid;
 List *schemaElts;
} CreateSchemaStmt;

typedef enum DropBehavior
{
 DROP_RESTRICT,
 DROP_CASCADE
} DropBehavior;





typedef struct AlterTableStmt
{
 NodeTag type;
 RangeVar *relation;
 List *cmds;
 ObjectType relkind;
 bool missing_ok;
} AlterTableStmt;

typedef enum AlterTableType
{
 AT_AddColumn,
 AT_AddColumnRecurse,
 AT_AddColumnToView,
 AT_ColumnDefault,
 AT_DropNotNull,
 AT_SetNotNull,
 AT_SetStatistics,
 AT_SetOptions,
 AT_ResetOptions,
 AT_SetStorage,
 AT_DropColumn,
 AT_DropColumnRecurse,
 AT_AddIndex,
 AT_ReAddIndex,
 AT_AddConstraint,
 AT_AddConstraintRecurse,
 AT_ValidateConstraint,
 AT_ValidateConstraintRecurse,
 AT_ProcessedConstraint,

 AT_AddIndexConstraint,
 AT_DropConstraint,
 AT_DropConstraintRecurse,
 AT_AlterColumnType,
 AT_AlterColumnGenericOptions,
 AT_ChangeOwner,
 AT_ClusterOn,
 AT_DropCluster,
 AT_AddOids,
 AT_AddOidsRecurse,
 AT_DropOids,
 AT_SetTableSpace,
 AT_SetRelOptions,
 AT_ResetRelOptions,
 AT_ReplaceRelOptions,
 AT_EnableTrig,
 AT_EnableAlwaysTrig,
 AT_EnableReplicaTrig,
 AT_DisableTrig,
 AT_EnableTrigAll,
 AT_DisableTrigAll,
 AT_EnableTrigUser,
 AT_DisableTrigUser,
 AT_EnableRule,
 AT_EnableAlwaysRule,
 AT_EnableReplicaRule,
 AT_DisableRule,
 AT_AddInherit,
 AT_DropInherit,
 AT_AddOf,
 AT_DropOf,
 AT_GenericOptions,

 AT_ReAddConstraint
} AlterTableType;

typedef struct AlterTableCmd
{
 NodeTag type;
 AlterTableType subtype;
 char *name;

 Node *def;

 DropBehavior behavior;
 bool missing_ok;
} AlterTableCmd;
# 1255 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct AlterDomainStmt
{
 NodeTag type;
 char subtype;







 List *typeName;
 char *name;
 Node *def;
 DropBehavior behavior;
 bool missing_ok;
} AlterDomainStmt;






typedef enum GrantTargetType
{
 ACL_TARGET_OBJECT,
 ACL_TARGET_ALL_IN_SCHEMA,
 ACL_TARGET_DEFAULTS
} GrantTargetType;

typedef enum GrantObjectType
{
 ACL_OBJECT_COLUMN,
 ACL_OBJECT_RELATION,
 ACL_OBJECT_SEQUENCE,
 ACL_OBJECT_DATABASE,
 ACL_OBJECT_DOMAIN,
 ACL_OBJECT_FDW,
 ACL_OBJECT_FOREIGN_SERVER,
 ACL_OBJECT_FUNCTION,
 ACL_OBJECT_LANGUAGE,
 ACL_OBJECT_LARGEOBJECT,
 ACL_OBJECT_NAMESPACE,
 ACL_OBJECT_TABLESPACE,
 ACL_OBJECT_TYPE
} GrantObjectType;

typedef struct GrantStmt
{
 NodeTag type;
 bool is_grant;
 GrantTargetType targtype;
 GrantObjectType objtype;
 List *objects;

 List *privileges;

 List *grantees;
 bool grant_option;
 DropBehavior behavior;
} GrantStmt;

typedef struct PrivGrantee
{
 NodeTag type;
 char *rolname;
} PrivGrantee;






typedef struct FuncWithArgs
{
 NodeTag type;
 List *funcname;
 List *funcargs;
} FuncWithArgs;
# 1342 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct AccessPriv
{
 NodeTag type;
 char *priv_name;
 List *cols;
} AccessPriv;
# 1358 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct GrantRoleStmt
{
 NodeTag type;
 List *granted_roles;
 List *grantee_roles;
 bool is_grant;
 bool admin_opt;
 char *grantor;
 DropBehavior behavior;
} GrantRoleStmt;





typedef struct AlterDefaultPrivilegesStmt
{
 NodeTag type;
 List *options;
 GrantStmt *action;
} AlterDefaultPrivilegesStmt;
# 1388 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CopyStmt
{
 NodeTag type;
 RangeVar *relation;
 Node *query;
 List *attlist;

 bool is_from;
 char *filename;
 List *options;
} CopyStmt;
# 1407 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum
{
 VAR_SET_VALUE,
 VAR_SET_DEFAULT,
 VAR_SET_CURRENT,
 VAR_SET_MULTI,
 VAR_RESET,
 VAR_RESET_ALL
} VariableSetKind;

typedef struct VariableSetStmt
{
 NodeTag type;
 VariableSetKind kind;
 char *name;
 List *args;
 bool is_local;
} VariableSetStmt;





typedef struct VariableShowStmt
{
 NodeTag type;
 char *name;
} VariableShowStmt;
# 1447 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CreateStmt
{
 NodeTag type;
 RangeVar *relation;
 List *tableElts;
 List *inhRelations;

 TypeName *ofTypename;
 List *constraints;
 List *options;
 OnCommitAction oncommit;
 char *tablespacename;
 bool if_not_exists;
} CreateStmt;
# 1493 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum ConstrType
{
 CONSTR_NULL,
 CONSTR_NOTNULL,
 CONSTR_DEFAULT,
 CONSTR_CHECK,
 CONSTR_PRIMARY,
 CONSTR_UNIQUE,
 CONSTR_EXCLUSION,
 CONSTR_FOREIGN,
 CONSTR_ATTR_DEFERRABLE,
 CONSTR_ATTR_NOT_DEFERRABLE,
 CONSTR_ATTR_DEFERRED,
 CONSTR_ATTR_IMMEDIATE
} ConstrType;
# 1521 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct Constraint
{
 NodeTag type;
 ConstrType contype;


 char *conname;
 bool deferrable;
 bool initdeferred;
 int location;


 bool is_no_inherit;
 Node *raw_expr;
 char *cooked_expr;


 List *keys;


 List *exclusions;


 List *options;
 char *indexname;
 char *indexspace;

 char *access_method;
 Node *where_clause;


 RangeVar *pktable;
 List *fk_attrs;
 List *pk_attrs;
 char fk_matchtype;
 char fk_upd_action;
 char fk_del_action;
 List *old_conpfeqop;


 bool skip_validation;
 bool initially_valid;
} Constraint;






typedef struct CreateTableSpaceStmt
{
 NodeTag type;
 char *tablespacename;
 char *owner;
 char *location;
} CreateTableSpaceStmt;

typedef struct DropTableSpaceStmt
{
 NodeTag type;
 char *tablespacename;
 bool missing_ok;
} DropTableSpaceStmt;

typedef struct AlterTableSpaceOptionsStmt
{
 NodeTag type;
 char *tablespacename;
 List *options;
 bool isReset;
} AlterTableSpaceOptionsStmt;






typedef struct CreateExtensionStmt
{
 NodeTag type;
 char *extname;
 bool if_not_exists;
 List *options;
} CreateExtensionStmt;


typedef struct AlterExtensionStmt
{
 NodeTag type;
 char *extname;
 List *options;
} AlterExtensionStmt;

typedef struct AlterExtensionContentsStmt
{
 NodeTag type;
 char *extname;
 int action;
 ObjectType objtype;
 List *objname;
 List *objargs;
} AlterExtensionContentsStmt;






typedef struct CreateFdwStmt
{
 NodeTag type;
 char *fdwname;
 List *func_options;
 List *options;
} CreateFdwStmt;

typedef struct AlterFdwStmt
{
 NodeTag type;
 char *fdwname;
 List *func_options;
 List *options;
} AlterFdwStmt;






typedef struct CreateForeignServerStmt
{
 NodeTag type;
 char *servername;
 char *servertype;
 char *version;
 char *fdwname;
 List *options;
} CreateForeignServerStmt;

typedef struct AlterForeignServerStmt
{
 NodeTag type;
 char *servername;
 char *version;
 List *options;
 bool has_version;
} AlterForeignServerStmt;






typedef struct CreateForeignTableStmt
{
 CreateStmt base;
 char *servername;
 List *options;
} CreateForeignTableStmt;






typedef struct CreateUserMappingStmt
{
 NodeTag type;
 char *username;
 char *servername;
 List *options;
} CreateUserMappingStmt;

typedef struct AlterUserMappingStmt
{
 NodeTag type;
 char *username;
 char *servername;
 List *options;
} AlterUserMappingStmt;

typedef struct DropUserMappingStmt
{
 NodeTag type;
 char *username;
 char *servername;
 bool missing_ok;
} DropUserMappingStmt;





typedef struct CreateTrigStmt
{
 NodeTag type;
 char *trigname;
 RangeVar *relation;
 List *funcname;
 List *args;
 bool row;

 int16 timing;

 int16 events;
 List *columns;
 Node *whenClause;
 bool isconstraint;

 bool deferrable;
 bool initdeferred;
 RangeVar *constrrel;
} CreateTrigStmt;





typedef struct CreatePLangStmt
{
 NodeTag type;
 bool replace;
 char *plname;
 List *plhandler;
 List *plinline;
 List *plvalidator;
 bool pltrusted;
} CreatePLangStmt;
# 1759 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum RoleStmtType
{
 ROLESTMT_ROLE,
 ROLESTMT_USER,
 ROLESTMT_GROUP
} RoleStmtType;

typedef struct CreateRoleStmt
{
 NodeTag type;
 RoleStmtType stmt_type;
 char *role;
 List *options;
} CreateRoleStmt;

typedef struct AlterRoleStmt
{
 NodeTag type;
 char *role;
 List *options;
 int action;
} AlterRoleStmt;

typedef struct AlterRoleSetStmt
{
 NodeTag type;
 char *role;
 char *database;
 VariableSetStmt *setstmt;
} AlterRoleSetStmt;

typedef struct DropRoleStmt
{
 NodeTag type;
 List *roles;
 bool missing_ok;
} DropRoleStmt;






typedef struct CreateSeqStmt
{
 NodeTag type;
 RangeVar *sequence;
 List *options;
 Oid ownerId;
} CreateSeqStmt;

typedef struct AlterSeqStmt
{
 NodeTag type;
 RangeVar *sequence;
 List *options;
 bool missing_ok;
} AlterSeqStmt;





typedef struct DefineStmt
{
 NodeTag type;
 ObjectType kind;
 bool oldstyle;
 List *defnames;
 List *args;
 List *definition;
} DefineStmt;





typedef struct CreateDomainStmt
{
 NodeTag type;
 List *domainname;
 TypeName *typeName;
 CollateClause *collClause;
 List *constraints;
} CreateDomainStmt;





typedef struct CreateOpClassStmt
{
 NodeTag type;
 List *opclassname;
 List *opfamilyname;
 char *amname;
 TypeName *datatype;
 List *items;
 bool isDefault;
} CreateOpClassStmt;





typedef struct CreateOpClassItem
{
 NodeTag type;
 int itemtype;

 List *name;
 List *args;
 int number;
 List *order_family;
 List *class_args;

 TypeName *storedtype;
} CreateOpClassItem;





typedef struct CreateOpFamilyStmt
{
 NodeTag type;
 List *opfamilyname;
 char *amname;
} CreateOpFamilyStmt;





typedef struct AlterOpFamilyStmt
{
 NodeTag type;
 List *opfamilyname;
 char *amname;
 bool isDrop;
 List *items;
} AlterOpFamilyStmt;






typedef struct DropStmt
{
 NodeTag type;
 List *objects;
 List *arguments;
 ObjectType removeType;
 DropBehavior behavior;
 bool missing_ok;
 bool concurrent;
} DropStmt;





typedef struct TruncateStmt
{
 NodeTag type;
 List *relations;
 bool restart_seqs;
 DropBehavior behavior;
} TruncateStmt;





typedef struct CommentStmt
{
 NodeTag type;
 ObjectType objtype;
 List *objname;
 List *objargs;
 char *comment;
} CommentStmt;





typedef struct SecLabelStmt
{
 NodeTag type;
 ObjectType objtype;
 List *objname;
 List *objargs;
 char *provider;
 char *label;
} SecLabelStmt;
# 1975 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct DeclareCursorStmt
{
 NodeTag type;
 char *portalname;
 int options;
 Node *query;
} DeclareCursorStmt;





typedef struct ClosePortalStmt
{
 NodeTag type;
 char *portalname;

} ClosePortalStmt;





typedef enum FetchDirection
{

 FETCH_FORWARD,
 FETCH_BACKWARD,

 FETCH_ABSOLUTE,
 FETCH_RELATIVE
} FetchDirection;



typedef struct FetchStmt
{
 NodeTag type;
 FetchDirection direction;
 long howMany;
 char *portalname;
 bool ismove;
} FetchStmt;
# 2030 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct IndexStmt
{
 NodeTag type;
 char *idxname;
 RangeVar *relation;
 char *accessMethod;
 char *tableSpace;
 List *indexParams;
 List *options;
 Node *whereClause;
 List *excludeOpNames;
 char *idxcomment;
 Oid indexOid;
 Oid oldNode;
 bool unique;
 bool primary;
 bool isconstraint;
 bool deferrable;
 bool initdeferred;
 bool concurrent;
} IndexStmt;





typedef struct CreateFunctionStmt
{
 NodeTag type;
 bool replace;
 List *funcname;
 List *parameters;
 TypeName *returnType;
 List *options;
 List *withClause;
} CreateFunctionStmt;

typedef enum FunctionParameterMode
{

 FUNC_PARAM_IN = 'i',
 FUNC_PARAM_OUT = 'o',
 FUNC_PARAM_INOUT = 'b',
 FUNC_PARAM_VARIADIC = 'v',
 FUNC_PARAM_TABLE = 't'
} FunctionParameterMode;

typedef struct FunctionParameter
{
 NodeTag type;
 char *name;
 TypeName *argType;
 FunctionParameterMode mode;
 Node *defexpr;
} FunctionParameter;

typedef struct AlterFunctionStmt
{
 NodeTag type;
 FuncWithArgs *func;
 List *actions;
} AlterFunctionStmt;







typedef struct DoStmt
{
 NodeTag type;
 List *args;
} DoStmt;

typedef struct InlineCodeBlock
{
 NodeTag type;
 char *source_text;
 Oid langOid;
 bool langIsTrusted;
} InlineCodeBlock;





typedef struct RenameStmt
{
 NodeTag type;
 ObjectType renameType;
 ObjectType relationType;
 RangeVar *relation;
 List *object;
 List *objarg;
 char *subname;

 char *newname;
 DropBehavior behavior;
 bool missing_ok;
} RenameStmt;





typedef struct AlterObjectSchemaStmt
{
 NodeTag type;
 ObjectType objectType;
 RangeVar *relation;
 List *object;
 List *objarg;
 char *addname;
 char *newschema;
 bool missing_ok;
} AlterObjectSchemaStmt;





typedef struct AlterOwnerStmt
{
 NodeTag type;
 ObjectType objectType;
 RangeVar *relation;
 List *object;
 List *objarg;
 char *addname;
 char *newowner;
} AlterOwnerStmt;






typedef struct RuleStmt
{
 NodeTag type;
 RangeVar *relation;
 char *rulename;
 Node *whereClause;
 CmdType event;
 bool instead;
 List *actions;
 bool replace;
} RuleStmt;





typedef struct NotifyStmt
{
 NodeTag type;
 char *conditionname;
 char *payload;
} NotifyStmt;





typedef struct ListenStmt
{
 NodeTag type;
 char *conditionname;
} ListenStmt;





typedef struct UnlistenStmt
{
 NodeTag type;
 char *conditionname;
} UnlistenStmt;





typedef enum TransactionStmtKind
{
 TRANS_STMT_BEGIN,
 TRANS_STMT_START,
 TRANS_STMT_COMMIT,
 TRANS_STMT_ROLLBACK,
 TRANS_STMT_SAVEPOINT,
 TRANS_STMT_RELEASE,
 TRANS_STMT_ROLLBACK_TO,
 TRANS_STMT_PREPARE,
 TRANS_STMT_COMMIT_PREPARED,
 TRANS_STMT_ROLLBACK_PREPARED
} TransactionStmtKind;

typedef struct TransactionStmt
{
 NodeTag type;
 TransactionStmtKind kind;
 List *options;
 char *gid;
} TransactionStmt;





typedef struct CompositeTypeStmt
{
 NodeTag type;
 RangeVar *typevar;
 List *coldeflist;
} CompositeTypeStmt;





typedef struct CreateEnumStmt
{
 NodeTag type;
 List *typeName;
 List *vals;
} CreateEnumStmt;





typedef struct CreateRangeStmt
{
 NodeTag type;
 List *typeName;
 List *params;
} CreateRangeStmt;





typedef struct AlterEnumStmt
{
 NodeTag type;
 List *typeName;
 char *newVal;
 char *newValNeighbor;
 bool newValIsAfter;
} AlterEnumStmt;





typedef struct ViewStmt
{
 NodeTag type;
 RangeVar *view;
 List *aliases;
 Node *query;
 bool replace;
 List *options;
} ViewStmt;





typedef struct LoadStmt
{
 NodeTag type;
 char *filename;
} LoadStmt;





typedef struct CreatedbStmt
{
 NodeTag type;
 char *dbname;
 List *options;
} CreatedbStmt;





typedef struct AlterDatabaseStmt
{
 NodeTag type;
 char *dbname;
 List *options;
} AlterDatabaseStmt;

typedef struct AlterDatabaseSetStmt
{
 NodeTag type;
 char *dbname;
 VariableSetStmt *setstmt;
} AlterDatabaseSetStmt;





typedef struct DropdbStmt
{
 NodeTag type;
 char *dbname;
 bool missing_ok;
} DropdbStmt;





typedef struct ClusterStmt
{
 NodeTag type;
 RangeVar *relation;
 char *indexname;
 bool verbose;
} ClusterStmt;
# 2369 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum VacuumOption
{
 VACOPT_VACUUM = 1 << 0,
 VACOPT_ANALYZE = 1 << 1,
 VACOPT_VERBOSE = 1 << 2,
 VACOPT_FREEZE = 1 << 3,
 VACOPT_FULL = 1 << 4,
 VACOPT_NOWAIT = 1 << 5
} VacuumOption;

typedef struct VacuumStmt
{
 NodeTag type;
 int options;
 int freeze_min_age;
 int freeze_table_age;
 RangeVar *relation;
 List *va_cols;
} VacuumStmt;
# 2397 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ExplainStmt
{
 NodeTag type;
 Node *query;
 List *options;
} ExplainStmt;
# 2415 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CreateTableAsStmt
{
 NodeTag type;
 Node *query;
 IntoClause *into;
 bool is_select_into;
} CreateTableAsStmt;





typedef struct CheckPointStmt
{
 NodeTag type;
} CheckPointStmt;






typedef enum DiscardMode
{
 DISCARD_ALL,
 DISCARD_PLANS,
 DISCARD_TEMP
} DiscardMode;

typedef struct DiscardStmt
{
 NodeTag type;
 DiscardMode target;
} DiscardStmt;





typedef struct LockStmt
{
 NodeTag type;
 List *relations;
 int mode;
 bool nowait;
} LockStmt;





typedef struct ConstraintsSetStmt
{
 NodeTag type;
 List *constraints;
 bool deferred;
} ConstraintsSetStmt;





typedef struct ReindexStmt
{
 NodeTag type;
 ObjectType kind;
 RangeVar *relation;
 const char *name;
 bool do_system;
 bool do_user;
} ReindexStmt;





typedef struct CreateConversionStmt
{
 NodeTag type;
 List *conversion_name;
 char *for_encoding_name;
 char *to_encoding_name;
 List *func_name;
 bool def;
} CreateConversionStmt;





typedef struct CreateCastStmt
{
 NodeTag type;
 TypeName *sourcetype;
 TypeName *targettype;
 FuncWithArgs *func;
 CoercionContext context;
 bool inout;
} CreateCastStmt;





typedef struct PrepareStmt
{
 NodeTag type;
 char *name;
 List *argtypes;
 Node *query;
} PrepareStmt;







typedef struct ExecuteStmt
{
 NodeTag type;
 char *name;
 List *params;
} ExecuteStmt;






typedef struct DeallocateStmt
{
 NodeTag type;
 char *name;

} DeallocateStmt;




typedef struct DropOwnedStmt
{
 NodeTag type;
 List *roles;
 DropBehavior behavior;
} DropOwnedStmt;




typedef struct ReassignOwnedStmt
{
 NodeTag type;
 List *roles;
 char *newrole;
} ReassignOwnedStmt;




typedef struct AlterTSDictionaryStmt
{
 NodeTag type;
 List *dictname;
 List *options;
} AlterTSDictionaryStmt;




typedef struct AlterTSConfigurationStmt
{
 NodeTag type;
 List *cfgname;





 List *tokentype;
 List *dicts;
 bool override;
 bool replace;
 bool missing_ok;
} AlterTSConfigurationStmt;
# 28 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/acl.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h" 1
# 59 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h"
# 1 "./fmgr.h" 1
# 60 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h" 2
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h"
typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
} ArrayType;




typedef struct ArrayBuildState
{
 MemoryContext mcontext;
 Datum *dvalues;
 bool *dnulls;
 int alen;
 int nelems;
 Oid element_type;
 int16 typlen;
 bool typbyval;
 char typalign;
} ArrayBuildState;




typedef struct ArrayMetaState
{
 Oid element_type;
 int16 typlen;
 bool typbyval;
 char typalign;
 char typdelim;
 Oid typioparam;
 Oid typiofunc;
 FmgrInfo proc;
} ArrayMetaState;




typedef struct ArrayMapState
{
 ArrayMetaState inp_extra;
 ArrayMetaState ret_extra;
} ArrayMapState;


typedef struct ArrayIteratorData *ArrayIterator;
# 182 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h"
extern bool Array_nulls;




extern Datum array_in(FunctionCallInfo fcinfo);
extern Datum array_out(FunctionCallInfo fcinfo);
extern Datum array_recv(FunctionCallInfo fcinfo);
extern Datum array_send(FunctionCallInfo fcinfo);
extern Datum array_eq(FunctionCallInfo fcinfo);
extern Datum array_ne(FunctionCallInfo fcinfo);
extern Datum array_lt(FunctionCallInfo fcinfo);
extern Datum array_gt(FunctionCallInfo fcinfo);
extern Datum array_le(FunctionCallInfo fcinfo);
extern Datum array_ge(FunctionCallInfo fcinfo);
extern Datum btarraycmp(FunctionCallInfo fcinfo);
extern Datum hash_array(FunctionCallInfo fcinfo);
extern Datum arrayoverlap(FunctionCallInfo fcinfo);
extern Datum arraycontains(FunctionCallInfo fcinfo);
extern Datum arraycontained(FunctionCallInfo fcinfo);
extern Datum array_ndims(FunctionCallInfo fcinfo);
extern Datum array_dims(FunctionCallInfo fcinfo);
extern Datum array_lower(FunctionCallInfo fcinfo);
extern Datum array_upper(FunctionCallInfo fcinfo);
extern Datum array_length(FunctionCallInfo fcinfo);
extern Datum array_larger(FunctionCallInfo fcinfo);
extern Datum array_smaller(FunctionCallInfo fcinfo);
extern Datum generate_subscripts(FunctionCallInfo fcinfo);
extern Datum generate_subscripts_nodir(FunctionCallInfo fcinfo);
extern Datum array_fill(FunctionCallInfo fcinfo);
extern Datum array_fill_with_lower_bounds(FunctionCallInfo fcinfo);
extern Datum array_unnest(FunctionCallInfo fcinfo);

extern Datum array_ref(ArrayType *array, int nSubscripts, int *indx,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign,
    bool *isNull);
extern ArrayType *array_set(ArrayType *array, int nSubscripts, int *indx,
    Datum dataValue, bool isNull,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign);
extern ArrayType *array_get_slice(ArrayType *array, int nSubscripts,
    int *upperIndx, int *lowerIndx,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign);
extern ArrayType *array_set_slice(ArrayType *array, int nSubscripts,
    int *upperIndx, int *lowerIndx,
    ArrayType *srcArray, bool isNull,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign);

extern Datum array_map(FunctionCallInfo fcinfo, Oid inpType, Oid retType,
    ArrayMapState *amstate);

extern void array_bitmap_copy(bits8 *destbitmap, int destoffset,
      const bits8 *srcbitmap, int srcoffset,
      int nitems);

extern ArrayType *construct_array(Datum *elems, int nelems,
    Oid elmtype,
    int elmlen, bool elmbyval, char elmalign);
extern ArrayType *construct_md_array(Datum *elems,
       bool *nulls,
       int ndims,
       int *dims,
       int *lbs,
       Oid elmtype, int elmlen, bool elmbyval, char elmalign);
extern ArrayType *construct_empty_array(Oid elmtype);
extern void deconstruct_array(ArrayType *array,
      Oid elmtype,
      int elmlen, bool elmbyval, char elmalign,
      Datum **elemsp, bool **nullsp, int *nelemsp);
extern bool array_contains_nulls(ArrayType *array);
extern ArrayBuildState *accumArrayResult(ArrayBuildState *astate,
     Datum dvalue, bool disnull,
     Oid element_type,
     MemoryContext rcontext);
extern Datum makeArrayResult(ArrayBuildState *astate,
    MemoryContext rcontext);
extern Datum makeMdArrayResult(ArrayBuildState *astate, int ndims,
      int *dims, int *lbs, MemoryContext rcontext, bool release);

extern ArrayIterator array_create_iterator(ArrayType *arr, int slice_ndim);
extern bool array_iterate(ArrayIterator iterator, Datum *value, bool *isnull);
extern void array_free_iterator(ArrayIterator iterator);





extern int ArrayGetOffset(int n, const int *dim, const int *lb, const int *indx);
extern int ArrayGetOffset0(int n, const int *tup, const int *scale);
extern int ArrayGetNItems(int ndim, const int *dims);
extern void mda_get_range(int n, int *span, const int *st, const int *endp);
extern void mda_get_prod(int n, const int *range, int *prod);
extern void mda_get_offset_values(int n, int *dist, const int *prod, const int *span);
extern int mda_next_tuple(int n, int *curr, const int *span);
extern int32 *ArrayGetIntegerTypmods(ArrayType *arr, int *n);




extern Datum array_push(FunctionCallInfo fcinfo);
extern Datum array_cat(FunctionCallInfo fcinfo);

extern ArrayType *create_singleton_array(FunctionCallInfo fcinfo,
        Oid element_type,
        Datum element,
        bool isNull,
        int ndims);

extern Datum array_agg_transfn(FunctionCallInfo fcinfo);
extern Datum array_agg_finalfn(FunctionCallInfo fcinfo);




extern Datum array_typanalyze(FunctionCallInfo fcinfo);
# 29 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/acl.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h" 1
# 36 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
typedef struct FormData_pg_attribute
{
 Oid attrelid;
 NameData attname;
# 48 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 Oid atttypid;
# 57 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int4 attstattarget;





 int2 attlen;
# 78 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int2 attnum;





 int4 attndims;
# 93 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int4 attcacheoff;







 int4 atttypmod;





 bool attbyval;
# 122 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 char attstorage;





 char attalign;


 bool attnotnull;


 bool atthasdef;


 bool attisdropped;


 bool attislocal;


 int4 attinhcount;


 Oid attcollation;
# 160 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
} FormData_pg_attribute;
# 176 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
typedef FormData_pg_attribute *Form_pg_attribute;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 2


typedef struct attrDefault
{
 AttrNumber adnum;
 char *adbin;
} AttrDefault;

typedef struct constrCheck
{
 char *ccname;
 char *ccbin;
 bool ccvalid;
 bool ccnoinherit;
} ConstrCheck;


typedef struct tupleConstr
{
 AttrDefault *defval;
 ConstrCheck *check;
 uint16 num_defval;
 uint16 num_check;
 bool has_not_null;
} TupleConstr;
# 71 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
typedef struct tupleDesc
{
 int natts;
 Form_pg_attribute *attrs;

 TupleConstr *constr;
 Oid tdtypeid;
 int32 tdtypmod;
 bool tdhasoid;
 int tdrefcount;
} *TupleDesc;


extern TupleDesc CreateTemplateTupleDesc(int natts, bool hasoid);

extern TupleDesc CreateTupleDesc(int natts, bool hasoid,
    Form_pg_attribute *attrs);

extern TupleDesc CreateTupleDescCopy(TupleDesc tupdesc);

extern TupleDesc CreateTupleDescCopyConstr(TupleDesc tupdesc);

extern void FreeTupleDesc(TupleDesc tupdesc);

extern void IncrTupleDescRefCount(TupleDesc tupdesc);
extern void DecrTupleDescRefCount(TupleDesc tupdesc);
# 110 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
extern bool equalTupleDescs(TupleDesc tupdesc1, TupleDesc tupdesc2);

extern void TupleDescInitEntry(TupleDesc desc,
       AttrNumber attributeNumber,
       const char *attributeName,
       Oid oidtypeid,
       int32 typmod,
       int attdim);

extern void TupleDescInitEntryCollation(TupleDesc desc,
       AttrNumber attributeNumber,
       Oid collationid);

extern TupleDesc BuildDescForRelation(List *schema);

extern TupleDesc BuildDescFromLists(List *names, List *types, List *typmods, List *collations);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupmacs.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h" 1
# 15 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
# 1 "/usr/include/fcntl.h" 1 3 4
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h" 2
# 32 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
typedef struct XLogRecPtr
{
 uint32 xlogid;
 uint32 xrecoff;
} XLogRecPtr;
# 84 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
typedef uint32 TimeLineID;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/item.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/item.h"
typedef Pointer Item;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h"
typedef struct ItemIdData
{
 unsigned lp_off:15,
    lp_flags:2,
    lp_len:15;
} ItemIdData;

typedef ItemIdData *ItemId;
# 46 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h"
typedef uint16 ItemOffset;
typedef uint16 ItemLength;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h" 2






typedef uint16 OffsetNumber;
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 2
# 73 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef Pointer Page;
# 82 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef uint16 LocationIndex;
# 122 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef struct PageHeaderData
{

 XLogRecPtr pd_lsn;

 uint16 pd_tli;

 uint16 pd_flags;
 LocationIndex pd_lower;
 LocationIndex pd_upper;
 LocationIndex pd_special;
 uint16 pd_pagesize_version;
 TransactionId pd_prune_xid;
 ItemIdData pd_linp[1];
} PageHeaderData;

typedef PageHeaderData *PageHeader;
# 370 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
extern void PageInit(Page page, Size pageSize, Size specialSize);
extern bool PageHeaderIsValid(PageHeader page);
extern OffsetNumber PageAddItem(Page page, Item item, Size size,
   OffsetNumber offsetNumber, bool overwrite, bool is_heap);
extern Page PageGetTempPage(Page page);
extern Page PageGetTempPageCopy(Page page);
extern Page PageGetTempPageCopySpecial(Page page);
extern void PageRestoreTempPage(Page tempPage, Page oldPage);
extern void PageRepairFragmentation(Page page);
extern Size PageGetFreeSpace(Page page);
extern Size PageGetExactFreeSpace(Page page);
extern Size PageGetHeapFreeSpace(Page page);
extern void PageIndexTupleDelete(Page page, OffsetNumber offset);
extern void PageIndexMultiDelete(Page page, OffsetNumber *itemnos, int nitems);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h" 1
# 31 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h"
typedef uint32 BlockNumber;
# 53 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h"
typedef struct BlockIdData
{
 uint16 bi_hi;
 uint16 bi_lo;
} BlockIdData;

typedef BlockIdData *BlockId;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h" 2
# 37 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
typedef struct ItemPointerData
{
 BlockIdData ip_blkid;
 OffsetNumber ip_posid;
}




ItemPointerData;




typedef ItemPointerData *ItemPointer;
# 143 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
extern bool ItemPointerEquals(ItemPointer pointer1, ItemPointer pointer2);
extern int32 ItemPointerCompare(ItemPointer arg1, ItemPointer arg2);
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/backendid.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/backendid.h"
typedef int BackendId;



extern BackendId MyBackendId;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h" 2







typedef enum ForkNumber
{
 InvalidForkNumber = -1,
 MAIN_FORKNUM = 0,
 FSM_FORKNUM,
 VISIBILITYMAP_FORKNUM,
 INIT_FORKNUM





} ForkNumber;
# 77 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
typedef struct RelFileNode
{
 Oid spcNode;
 Oid dbNode;
 Oid relNode;
} RelFileNode;
# 92 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
typedef struct RelFileNodeBackend
{
 RelFileNode node;
 BackendId backend;
} RelFileNodeBackend;
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 107 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct HeapTupleFields
{
 TransactionId t_xmin;
 TransactionId t_xmax;

 union
 {
  CommandId t_cid;
  TransactionId t_xvac;
 } t_field3;
} HeapTupleFields;

typedef struct DatumTupleFields
{
 int32 datum_len_;

 int32 datum_typmod;

 Oid datum_typeid;





} DatumTupleFields;

typedef struct HeapTupleHeaderData
{
 union
 {
  HeapTupleFields t_heap;
  DatumTupleFields t_datum;
 } t_choice;

 ItemPointerData t_ctid;



 uint16 t_infomask2;

 uint16 t_infomask;

 uint8 t_hoff;



 bits8 t_bits[1];


} HeapTupleHeaderData;

typedef HeapTupleHeaderData *HeapTupleHeader;
# 461 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct MinimalTupleData
{
 uint32 t_len;

 char mt_padding[((__builtin_offsetof (HeapTupleHeaderData, t_infomask2) - sizeof(uint32)) % 8)];



 uint16 t_infomask2;

 uint16 t_infomask;

 uint8 t_hoff;



 bits8 t_bits[1];


} MinimalTupleData;

typedef MinimalTupleData *MinimalTuple;
# 517 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct HeapTupleData
{
 uint32 t_len;
 ItemPointerData t_self;
 Oid t_tableOid;
 HeapTupleHeader t_data;
} HeapTupleData;

typedef HeapTupleData *HeapTuple;
# 621 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heaptid
{
 RelFileNode node;
 ItemPointerData tid;
} xl_heaptid;




typedef struct xl_heap_delete
{
 xl_heaptid target;
 bool all_visible_cleared;
} xl_heap_delete;
# 646 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_header
{
 uint16 t_infomask2;
 uint16 t_infomask;
 uint8 t_hoff;
} xl_heap_header;




typedef struct xl_heap_insert
{
 xl_heaptid target;
 bool all_visible_cleared;

} xl_heap_insert;
# 671 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_multi_insert
{
 RelFileNode node;
 BlockNumber blkno;
 bool all_visible_cleared;
 uint16 ntuples;
 OffsetNumber offsets[1];


} xl_heap_multi_insert;



typedef struct xl_multi_insert_tuple
{
 uint16 datalen;
 uint16 t_infomask2;
 uint16 t_infomask;
 uint8 t_hoff;

} xl_multi_insert_tuple;




typedef struct xl_heap_update
{
 xl_heaptid target;
 ItemPointerData newtid;
 bool all_visible_cleared;
 bool new_all_visible_cleared;

} xl_heap_update;
# 718 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_clean
{
 RelFileNode node;
 BlockNumber block;
 TransactionId latestRemovedXid;
 uint16 nredirected;
 uint16 ndead;

} xl_heap_clean;
# 735 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_cleanup_info
{
 RelFileNode node;
 TransactionId latestRemovedXid;
} xl_heap_cleanup_info;





typedef struct xl_heap_newpage
{
 RelFileNode node;
 ForkNumber forknum;
 BlockNumber blkno;

} xl_heap_newpage;




typedef struct xl_heap_lock
{
 xl_heaptid target;
 TransactionId locking_xid;
 bool xid_is_mxact;
 bool shared_lock;
} xl_heap_lock;




typedef struct xl_heap_inplace
{
 xl_heaptid target;

} xl_heap_inplace;




typedef struct xl_heap_freeze
{
 RelFileNode node;
 BlockNumber block;
 TransactionId cutoff_xid;

} xl_heap_freeze;




typedef struct xl_heap_visible
{
 RelFileNode node;
 BlockNumber block;
 TransactionId cutoff_xid;
} xl_heap_visible;



extern void HeapTupleHeaderAdvanceLatestRemovedXid(HeapTupleHeader tuple,
            TransactionId *latestRemovedXid);


extern CommandId HeapTupleHeaderGetCmin(HeapTupleHeader tup);
extern CommandId HeapTupleHeaderGetCmax(HeapTupleHeader tup);
extern void HeapTupleHeaderAdjustCmax(HeapTupleHeader tup,
        CommandId *cmax,
        bool *iscombo);
# 890 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
extern Size heap_compute_data_size(TupleDesc tupleDesc,
        Datum *values, bool *isnull);
extern void heap_fill_tuple(TupleDesc tupleDesc,
    Datum *values, bool *isnull,
    char *data, Size data_size,
    uint16 *infomask, bits8 *bit);
extern bool heap_attisnull(HeapTuple tup, int attnum);
extern Datum nocachegetattr(HeapTuple tup, int attnum,
      TupleDesc att);
extern Datum heap_getsysattr(HeapTuple tup, int attnum, TupleDesc tupleDesc,
    bool *isnull);
extern HeapTuple heap_copytuple(HeapTuple tuple);
extern void heap_copytuple_with_tuple(HeapTuple src, HeapTuple dest);
extern HeapTuple heap_form_tuple(TupleDesc tupleDescriptor,
    Datum *values, bool *isnull);
extern HeapTuple heap_modify_tuple(HeapTuple tuple,
      TupleDesc tupleDesc,
      Datum *replValues,
      bool *replIsnull,
      bool *doReplace);
extern void heap_deform_tuple(HeapTuple tuple, TupleDesc tupleDesc,
      Datum *values, bool *isnull);


extern HeapTuple heap_formtuple(TupleDesc tupleDescriptor,
      Datum *values, char *nulls);
extern HeapTuple heap_modifytuple(HeapTuple tuple,
     TupleDesc tupleDesc,
     Datum *replValues,
     char *replNulls,
     char *replActions);
extern void heap_deformtuple(HeapTuple tuple, TupleDesc tupleDesc,
     Datum *values, char *nulls);
extern void heap_freetuple(HeapTuple htup);
extern MinimalTuple heap_form_minimal_tuple(TupleDesc tupleDescriptor,
      Datum *values, bool *isnull);
extern void heap_free_minimal_tuple(MinimalTuple mtup);
extern MinimalTuple heap_copy_minimal_tuple(MinimalTuple mtup);
extern HeapTuple heap_tuple_from_minimal_tuple(MinimalTuple mtup);
extern MinimalTuple minimal_tuple_from_heap_tuple(HeapTuple htup);
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h"
typedef int Buffer;
# 44 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h"
typedef struct BufferAccessStrategyData *BufferAccessStrategy;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h" 2


typedef struct SnapshotData *Snapshot;
# 30 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h"
typedef bool (*SnapshotSatisfiesFunc) (HeapTupleHeader tuple,
             Snapshot snapshot, Buffer buffer);

typedef struct SnapshotData
{
 SnapshotSatisfiesFunc satisfies;
# 47 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h"
 TransactionId xmin;
 TransactionId xmax;
 TransactionId *xip;
 uint32 xcnt;

 int32 subxcnt;
 TransactionId *subxip;
 bool suboverflowed;
 bool takenDuringRecovery;
 bool copied;





 CommandId curcid;
 uint32 active_count;
 uint32 regd_count;
} SnapshotData;





typedef enum
{
 HeapTupleMayBeUpdated,
 HeapTupleInvisible,
 HeapTupleSelfUpdated,
 HeapTupleUpdated,
 HeapTupleBeingUpdated
} HTSU_Result;
# 30 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/acl.h" 2
# 45 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/acl.h"
typedef struct AclItem
{
 Oid ai_grantee;
 Oid ai_grantor;
 AclMode ai_privs;
} AclItem;
# 97 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/acl.h"
typedef ArrayType Acl;
# 161 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/acl.h"
typedef enum
{
 ACLMASK_ALL,
 ACLMASK_ANY
} AclMaskHow;


typedef enum
{
 ACLCHECK_OK = 0,
 ACLCHECK_NO_PRIV,
 ACLCHECK_NOT_OWNER
} AclResult;



typedef enum AclObjectKind
{
 ACL_KIND_COLUMN,
 ACL_KIND_CLASS,
 ACL_KIND_SEQUENCE,
 ACL_KIND_DATABASE,
 ACL_KIND_PROC,
 ACL_KIND_OPER,
 ACL_KIND_TYPE,
 ACL_KIND_LANGUAGE,
 ACL_KIND_LARGEOBJECT,
 ACL_KIND_NAMESPACE,
 ACL_KIND_OPCLASS,
 ACL_KIND_OPFAMILY,
 ACL_KIND_COLLATION,
 ACL_KIND_CONVERSION,
 ACL_KIND_TABLESPACE,
 ACL_KIND_TSDICTIONARY,
 ACL_KIND_TSCONFIGURATION,
 ACL_KIND_FDW,
 ACL_KIND_FOREIGN_SERVER,
 ACL_KIND_EXTENSION,
 MAX_ACL_KIND
} AclObjectKind;





extern Acl *acldefault(GrantObjectType objtype, Oid ownerId);
extern Acl *get_user_default_acl(GrantObjectType objtype, Oid ownerId,
      Oid nsp_oid);

extern Acl *aclupdate(const Acl *old_acl, const AclItem *mod_aip,
    int modechg, Oid ownerId, DropBehavior behavior);
extern Acl *aclnewowner(const Acl *old_acl, Oid oldOwnerId, Oid newOwnerId);
extern Acl *make_empty_acl(void);
extern Acl *aclcopy(const Acl *orig_acl);
extern Acl *aclconcat(const Acl *left_acl, const Acl *right_acl);
extern Acl *aclmerge(const Acl *left_acl, const Acl *right_acl, Oid ownerId);
extern void aclitemsort(Acl *acl);
extern bool aclequal(const Acl *left_acl, const Acl *right_acl);

extern AclMode aclmask(const Acl *acl, Oid roleid, Oid ownerId,
  AclMode mask, AclMaskHow how);
extern int aclmembers(const Acl *acl, Oid **roleids);

extern bool has_privs_of_role(Oid member, Oid role);
extern bool is_member_of_role(Oid member, Oid role);
extern bool is_member_of_role_nosuper(Oid member, Oid role);
extern bool is_admin_of_role(Oid member, Oid role);
extern void check_is_member_of_role(Oid member, Oid role);
extern Oid get_role_oid(const char *rolname, bool missing_ok);

extern void select_best_grantor(Oid roleId, AclMode privileges,
     const Acl *acl, Oid ownerId,
     Oid *grantorId, AclMode *grantOptions);

extern void initialize_acl(void);




extern Datum aclitemin(FunctionCallInfo fcinfo);
extern Datum aclitemout(FunctionCallInfo fcinfo);
extern Datum aclinsert(FunctionCallInfo fcinfo);
extern Datum aclremove(FunctionCallInfo fcinfo);
extern Datum aclcontains(FunctionCallInfo fcinfo);
extern Datum makeaclitem(FunctionCallInfo fcinfo);
extern Datum aclitem_eq(FunctionCallInfo fcinfo);
extern Datum hash_aclitem(FunctionCallInfo fcinfo);
extern Datum acldefault_sql(FunctionCallInfo fcinfo);
extern Datum aclexplode(FunctionCallInfo fcinfo);




extern void ExecuteGrantStmt(GrantStmt *stmt);
extern void ExecAlterDefaultPrivilegesStmt(AlterDefaultPrivilegesStmt *stmt);

extern void RemoveRoleFromObjectACL(Oid roleid, Oid classid, Oid objid);
extern void RemoveDefaultACLById(Oid defaclOid);

extern AclMode pg_attribute_aclmask(Oid table_oid, AttrNumber attnum,
      Oid roleid, AclMode mask, AclMaskHow how);
extern AclMode pg_class_aclmask(Oid table_oid, Oid roleid,
     AclMode mask, AclMaskHow how);
extern AclMode pg_database_aclmask(Oid db_oid, Oid roleid,
     AclMode mask, AclMaskHow how);
extern AclMode pg_proc_aclmask(Oid proc_oid, Oid roleid,
    AclMode mask, AclMaskHow how);
extern AclMode pg_language_aclmask(Oid lang_oid, Oid roleid,
     AclMode mask, AclMaskHow how);
extern AclMode pg_largeobject_aclmask_snapshot(Oid lobj_oid, Oid roleid,
       AclMode mask, AclMaskHow how, Snapshot snapshot);
extern AclMode pg_namespace_aclmask(Oid nsp_oid, Oid roleid,
      AclMode mask, AclMaskHow how);
extern AclMode pg_tablespace_aclmask(Oid spc_oid, Oid roleid,
       AclMode mask, AclMaskHow how);
extern AclMode pg_foreign_data_wrapper_aclmask(Oid fdw_oid, Oid roleid,
        AclMode mask, AclMaskHow how);
extern AclMode pg_foreign_server_aclmask(Oid srv_oid, Oid roleid,
        AclMode mask, AclMaskHow how);
extern AclMode pg_type_aclmask(Oid type_oid, Oid roleid,
    AclMode mask, AclMaskHow how);

extern AclResult pg_attribute_aclcheck(Oid table_oid, AttrNumber attnum,
       Oid roleid, AclMode mode);
extern AclResult pg_attribute_aclcheck_all(Oid table_oid, Oid roleid,
        AclMode mode, AclMaskHow how);
extern AclResult pg_class_aclcheck(Oid table_oid, Oid roleid, AclMode mode);
extern AclResult pg_database_aclcheck(Oid db_oid, Oid roleid, AclMode mode);
extern AclResult pg_proc_aclcheck(Oid proc_oid, Oid roleid, AclMode mode);
extern AclResult pg_language_aclcheck(Oid lang_oid, Oid roleid, AclMode mode);
extern AclResult pg_largeobject_aclcheck_snapshot(Oid lang_oid, Oid roleid,
         AclMode mode, Snapshot snapshot);
extern AclResult pg_namespace_aclcheck(Oid nsp_oid, Oid roleid, AclMode mode);
extern AclResult pg_tablespace_aclcheck(Oid spc_oid, Oid roleid, AclMode mode);
extern AclResult pg_foreign_data_wrapper_aclcheck(Oid fdw_oid, Oid roleid, AclMode mode);
extern AclResult pg_foreign_server_aclcheck(Oid srv_oid, Oid roleid, AclMode mode);
extern AclResult pg_type_aclcheck(Oid type_oid, Oid roleid, AclMode mode);

extern void aclcheck_error(AclResult aclerr, AclObjectKind objectkind,
      const char *objectname);

extern void aclcheck_error_col(AclResult aclerr, AclObjectKind objectkind,
       const char *objectname, const char *colname);

extern void aclcheck_error_type(AclResult aclerr, Oid typeOid);


extern bool pg_class_ownercheck(Oid class_oid, Oid roleid);
extern bool pg_type_ownercheck(Oid type_oid, Oid roleid);
extern bool pg_oper_ownercheck(Oid oper_oid, Oid roleid);
extern bool pg_proc_ownercheck(Oid proc_oid, Oid roleid);
extern bool pg_language_ownercheck(Oid lan_oid, Oid roleid);
extern bool pg_largeobject_ownercheck(Oid lobj_oid, Oid roleid);
extern bool pg_namespace_ownercheck(Oid nsp_oid, Oid roleid);
extern bool pg_tablespace_ownercheck(Oid spc_oid, Oid roleid);
extern bool pg_opclass_ownercheck(Oid opc_oid, Oid roleid);
extern bool pg_opfamily_ownercheck(Oid opf_oid, Oid roleid);
extern bool pg_database_ownercheck(Oid db_oid, Oid roleid);
extern bool pg_collation_ownercheck(Oid coll_oid, Oid roleid);
extern bool pg_conversion_ownercheck(Oid conv_oid, Oid roleid);
extern bool pg_ts_dict_ownercheck(Oid dict_oid, Oid roleid);
extern bool pg_ts_config_ownercheck(Oid cfg_oid, Oid roleid);
extern bool pg_foreign_data_wrapper_ownercheck(Oid srv_oid, Oid roleid);
extern bool pg_foreign_server_ownercheck(Oid srv_oid, Oid roleid);
extern bool pg_extension_ownercheck(Oid ext_oid, Oid roleid);
extern bool has_createrole_privilege(Oid roleid);
# 36 "hba.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h" 1
# 70 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 2
# 112 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
typedef struct TupleTableSlot
{
 NodeTag type;
 bool tts_isempty;
 bool tts_shouldFree;
 bool tts_shouldFreeMin;
 bool tts_slow;
 HeapTuple tts_tuple;
 TupleDesc tts_tupleDescriptor;
 MemoryContext tts_mcxt;
 Buffer tts_buffer;
 int tts_nvalid;
 Datum *tts_values;
 bool *tts_isnull;
 MinimalTuple tts_mintuple;
 HeapTupleData tts_minhdr;
 long tts_off;
} TupleTableSlot;
# 141 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
extern TupleTableSlot *MakeTupleTableSlot(void);
extern TupleTableSlot *ExecAllocTableSlot(List **tupleTable);
extern void ExecResetTupleTable(List *tupleTable, bool shouldFree);
extern TupleTableSlot *MakeSingleTupleTableSlot(TupleDesc tupdesc);
extern void ExecDropSingleTupleTableSlot(TupleTableSlot *slot);
extern void ExecSetSlotDescriptor(TupleTableSlot *slot, TupleDesc tupdesc);
extern TupleTableSlot *ExecStoreTuple(HeapTuple tuple,
      TupleTableSlot *slot,
      Buffer buffer,
      bool shouldFree);
extern TupleTableSlot *ExecStoreMinimalTuple(MinimalTuple mtup,
       TupleTableSlot *slot,
       bool shouldFree);
extern TupleTableSlot *ExecClearTuple(TupleTableSlot *slot);
extern TupleTableSlot *ExecStoreVirtualTuple(TupleTableSlot *slot);
extern TupleTableSlot *ExecStoreAllNullTuple(TupleTableSlot *slot);
extern HeapTuple ExecCopySlotTuple(TupleTableSlot *slot);
extern MinimalTuple ExecCopySlotMinimalTuple(TupleTableSlot *slot);
extern HeapTuple ExecFetchSlotTuple(TupleTableSlot *slot);
extern MinimalTuple ExecFetchSlotMinimalTuple(TupleTableSlot *slot);
extern Datum ExecFetchSlotTupleDatum(TupleTableSlot *slot);
extern HeapTuple ExecMaterializeSlot(TupleTableSlot *slot);
extern TupleTableSlot *ExecCopySlot(TupleTableSlot *dstslot,
    TupleTableSlot *srcslot);


extern Datum slot_getattr(TupleTableSlot *slot, int attnum, bool *isnull);
extern void slot_getallattrs(TupleTableSlot *slot);
extern void slot_getsomeattrs(TupleTableSlot *slot, int attnum);
extern bool slot_attisnull(TupleTableSlot *slot, int attnum);
# 71 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h" 2
# 86 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h"
typedef enum
{
 DestNone,
 DestDebug,
 DestRemote,
 DestRemoteExecute,
 DestSPI,
 DestTuplestore,
 DestIntoRel,
 DestCopyOut,
 DestSQLFunction
} CommandDest;
# 108 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h"
typedef struct _DestReceiver DestReceiver;

struct _DestReceiver
{

 void (*receiveSlot) (TupleTableSlot *slot,
           DestReceiver *self);

 void (*rStartup) (DestReceiver *self,
           int operation,
           TupleDesc typeinfo);
 void (*rShutdown) (DestReceiver *self);

 void (*rDestroy) (DestReceiver *self);

 CommandDest mydest;

};

extern DestReceiver *None_Receiver;



extern void BeginCommand(const char *commandTag, CommandDest dest);
extern DestReceiver *CreateDestReceiver(CommandDest dest);
extern void EndCommand(const char *commandTag, CommandDest dest);



extern void NullCommand(CommandDest dest);
extern void ReadyForQuery(CommandDest dest);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 2
# 51 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
typedef enum
{
 PGC_INTERNAL,
 PGC_POSTMASTER,
 PGC_SIGHUP,
 PGC_BACKEND,
 PGC_SUSET,
 PGC_USERSET
} GucContext;
# 83 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
typedef enum
{
 PGC_S_DEFAULT,
 PGC_S_DYNAMIC_DEFAULT,
 PGC_S_ENV_VAR,
 PGC_S_FILE,
 PGC_S_ARGV,
 PGC_S_DATABASE,
 PGC_S_USER,
 PGC_S_DATABASE_USER,
 PGC_S_CLIENT,
 PGC_S_OVERRIDE,
 PGC_S_INTERACTIVE,
 PGC_S_TEST,
 PGC_S_SESSION
} GucSource;





typedef struct ConfigVariable
{
 char *name;
 char *value;
 char *filename;
 int sourceline;
 struct ConfigVariable *next;
} ConfigVariable;

extern bool ParseConfigFile(const char *config_file, const char *calling_file,
    bool strict, int depth, int elevel,
    ConfigVariable **head_p, ConfigVariable **tail_p);
extern bool ParseConfigFp(FILE *fp, const char *config_file,
     int depth, int elevel,
     ConfigVariable **head_p, ConfigVariable **tail_p);
extern void FreeConfigVariables(ConfigVariable *list);






struct config_enum_entry
{
 const char *name;
 int val;
 bool hidden;
};




typedef bool (*GucBoolCheckHook) (bool *newval, void **extra, GucSource source);
typedef bool (*GucIntCheckHook) (int *newval, void **extra, GucSource source);
typedef bool (*GucRealCheckHook) (double *newval, void **extra, GucSource source);
typedef bool (*GucStringCheckHook) (char **newval, void **extra, GucSource source);
typedef bool (*GucEnumCheckHook) (int *newval, void **extra, GucSource source);

typedef void (*GucBoolAssignHook) (bool newval, void *extra);
typedef void (*GucIntAssignHook) (int newval, void *extra);
typedef void (*GucRealAssignHook) (double newval, void *extra);
typedef void (*GucStringAssignHook) (const char *newval, void *extra);
typedef void (*GucEnumAssignHook) (int newval, void *extra);

typedef const char *(*GucShowHook) (void);




typedef enum
{

 GUC_ACTION_SET,
 GUC_ACTION_LOCAL,
 GUC_ACTION_SAVE
} GucAction;
# 190 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
extern bool log_duration;
extern bool Debug_print_plan;
extern bool Debug_print_parse;
extern bool Debug_print_rewritten;
extern bool Debug_pretty_print;

extern bool log_parser_stats;
extern bool log_planner_stats;
extern bool log_executor_stats;
extern bool log_statement_stats;
extern bool log_btree_build_stats;

extern bool check_function_bodies;
extern bool default_with_oids;
extern bool SQL_inheritance;

extern int log_min_error_statement;
extern int log_min_messages;
extern int client_min_messages;
extern int log_min_duration_statement;
extern int log_temp_files;

extern int temp_file_limit;

extern int num_temp_buffers;

extern char *data_directory;
extern char *ConfigFileName;
extern char *HbaFileName;
extern char *IdentFileName;
extern char *external_pid_file;

extern char *application_name;

extern int tcp_keepalives_idle;
extern int tcp_keepalives_interval;
extern int tcp_keepalives_count;




extern void SetConfigOption(const char *name, const char *value,
    GucContext context, GucSource source);

extern void DefineCustomBoolVariable(
       const char *name,
       const char *short_desc,
       const char *long_desc,
       bool *valueAddr,
       bool bootValue,
       GucContext context,
       int flags,
       GucBoolCheckHook check_hook,
       GucBoolAssignHook assign_hook,
       GucShowHook show_hook);

extern void DefineCustomIntVariable(
      const char *name,
      const char *short_desc,
      const char *long_desc,
      int *valueAddr,
      int bootValue,
      int minValue,
      int maxValue,
      GucContext context,
      int flags,
      GucIntCheckHook check_hook,
      GucIntAssignHook assign_hook,
      GucShowHook show_hook);

extern void DefineCustomRealVariable(
       const char *name,
       const char *short_desc,
       const char *long_desc,
       double *valueAddr,
       double bootValue,
       double minValue,
       double maxValue,
       GucContext context,
       int flags,
       GucRealCheckHook check_hook,
       GucRealAssignHook assign_hook,
       GucShowHook show_hook);

extern void DefineCustomStringVariable(
         const char *name,
         const char *short_desc,
         const char *long_desc,
         char **valueAddr,
         const char *bootValue,
         GucContext context,
         int flags,
         GucStringCheckHook check_hook,
         GucStringAssignHook assign_hook,
         GucShowHook show_hook);

extern void DefineCustomEnumVariable(
       const char *name,
       const char *short_desc,
       const char *long_desc,
       int *valueAddr,
       int bootValue,
       const struct config_enum_entry * options,
       GucContext context,
       int flags,
       GucEnumCheckHook check_hook,
       GucEnumAssignHook assign_hook,
       GucShowHook show_hook);

extern void EmitWarningsOnPlaceholders(const char *className);

extern const char *GetConfigOption(const char *name, bool missing_ok,
    bool restrict_superuser);
extern const char *GetConfigOptionResetString(const char *name);
extern void ProcessConfigFile(GucContext context);
extern void InitializeGUCOptions(void);
extern bool SelectConfigFiles(const char *userDoption, const char *progname);
extern void ResetAllOptions(void);
extern void AtStart_GUC(void);
extern int NewGUCNestLevel(void);
extern void AtEOXact_GUC(bool isCommit, int nestLevel);
extern void BeginReportingGUCOptions(void);
extern void ParseLongOption(const char *string, char **name, char **value);
extern bool parse_int(const char *value, int *result, int flags,
    const char **hintmsg);
extern bool parse_real(const char *value, double *result);
extern int set_config_option(const char *name, const char *value,
      GucContext context, GucSource source,
      GucAction action, bool changeVal, int elevel);
extern char *GetConfigOptionByName(const char *name, const char **varname);
extern void GetConfigOptionByNum(int varnum, const char **values, bool *noshow);
extern int GetNumConfigOptions(void);

extern void SetPGVariable(const char *name, List *args, bool is_local);
extern void GetPGVariable(const char *name, DestReceiver *dest);
extern TupleDesc GetPGVariableResultDesc(const char *name);

extern void ExecSetVariableStmt(VariableSetStmt *stmt);
extern char *ExtractSetVariableArgs(VariableSetStmt *stmt);

extern void ProcessGUCArray(ArrayType *array,
    GucContext context, GucSource source, GucAction action);
extern ArrayType *GUCArrayAdd(ArrayType *array, const char *name, const char *value);
extern ArrayType *GUCArrayDelete(ArrayType *array, const char *name);
extern ArrayType *GUCArrayReset(ArrayType *array);
# 343 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
extern char *GUC_check_errmsg_string;
extern char *GUC_check_errdetail_string;
extern char *GUC_check_errhint_string;

extern void GUC_check_errcode(int sqlerrcode);
# 369 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
extern bool check_default_tablespace(char **newval, void **extra, GucSource source);
extern bool check_temp_tablespaces(char **newval, void **extra, GucSource source);
extern void assign_temp_tablespaces(const char *newval, void *extra);


extern bool check_search_path(char **newval, void **extra, GucSource source);
extern void assign_search_path(const char *newval, void *extra);


extern bool check_wal_buffers(int *newval, void **extra, GucSource source);
extern void assign_xlog_sync_method(int new_sync_method, void *extra);
# 37 "hba.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/lsyscache.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/lsyscache.h"
typedef struct OpBtreeInterpretation
{
 Oid opfamily_id;
 int strategy;
 Oid oplefttype;
 Oid oprighttype;
} OpBtreeInterpretation;


typedef enum IOFuncSelector
{
 IOFunc_input,
 IOFunc_output,
 IOFunc_receive,
 IOFunc_send
} IOFuncSelector;


typedef int32 (*get_attavgwidth_hook_type) (Oid relid, AttrNumber attnum);
extern get_attavgwidth_hook_type get_attavgwidth_hook;

extern bool op_in_opfamily(Oid opno, Oid opfamily);
extern int get_op_opfamily_strategy(Oid opno, Oid opfamily);
extern Oid get_op_opfamily_sortfamily(Oid opno, Oid opfamily);
extern void get_op_opfamily_properties(Oid opno, Oid opfamily, bool ordering_op,
         int *strategy,
         Oid *lefttype,
         Oid *righttype);
extern Oid get_opfamily_member(Oid opfamily, Oid lefttype, Oid righttype,
     int16 strategy);
extern bool get_ordering_op_properties(Oid opno,
         Oid *opfamily, Oid *opcintype, int16 *strategy);
extern bool get_sort_function_for_ordering_op(Oid opno, Oid *sortfunc,
          bool *issupport, bool *reverse);
extern Oid get_equality_op_for_ordering_op(Oid opno, bool *reverse);
extern Oid get_ordering_op_for_equality_op(Oid opno, bool use_lhs_type);
extern List *get_mergejoin_opfamilies(Oid opno);
extern bool get_compatible_hash_operators(Oid opno,
         Oid *lhs_opno, Oid *rhs_opno);
extern bool get_op_hash_functions(Oid opno,
       RegProcedure *lhs_procno, RegProcedure *rhs_procno);
extern List *get_op_btree_interpretation(Oid opno);
extern bool equality_ops_are_compatible(Oid opno1, Oid opno2);
extern Oid get_opfamily_proc(Oid opfamily, Oid lefttype, Oid righttype,
      int16 procnum);
extern char *get_attname(Oid relid, AttrNumber attnum);
extern char *get_relid_attribute_name(Oid relid, AttrNumber attnum);
extern AttrNumber get_attnum(Oid relid, const char *attname);
extern Oid get_atttype(Oid relid, AttrNumber attnum);
extern int32 get_atttypmod(Oid relid, AttrNumber attnum);
extern void get_atttypetypmodcoll(Oid relid, AttrNumber attnum,
       Oid *typid, int32 *typmod, Oid *collid);
extern char *get_collation_name(Oid colloid);
extern char *get_constraint_name(Oid conoid);
extern Oid get_opclass_family(Oid opclass);
extern Oid get_opclass_input_type(Oid opclass);
extern RegProcedure get_opcode(Oid opno);
extern char *get_opname(Oid opno);
extern void op_input_types(Oid opno, Oid *lefttype, Oid *righttype);
extern bool op_mergejoinable(Oid opno, Oid inputtype);
extern bool op_hashjoinable(Oid opno, Oid inputtype);
extern bool op_strict(Oid opno);
extern char op_volatile(Oid opno);
extern Oid get_commutator(Oid opno);
extern Oid get_negator(Oid opno);
extern RegProcedure get_oprrest(Oid opno);
extern RegProcedure get_oprjoin(Oid opno);
extern char *get_func_name(Oid funcid);
extern Oid get_func_namespace(Oid funcid);
extern Oid get_func_rettype(Oid funcid);
extern int get_func_nargs(Oid funcid);
extern Oid get_func_signature(Oid funcid, Oid **argtypes, int *nargs);
extern bool get_func_retset(Oid funcid);
extern bool func_strict(Oid funcid);
extern char func_volatile(Oid funcid);
extern bool get_func_leakproof(Oid funcid);
extern float4 get_func_cost(Oid funcid);
extern float4 get_func_rows(Oid funcid);
extern Oid get_relname_relid(const char *relname, Oid relnamespace);
extern char *get_rel_name(Oid relid);
extern Oid get_rel_namespace(Oid relid);
extern Oid get_rel_type_id(Oid relid);
extern char get_rel_relkind(Oid relid);
extern Oid get_rel_tablespace(Oid relid);
extern bool get_typisdefined(Oid typid);
extern int16 get_typlen(Oid typid);
extern bool get_typbyval(Oid typid);
extern void get_typlenbyval(Oid typid, int16 *typlen, bool *typbyval);
extern void get_typlenbyvalalign(Oid typid, int16 *typlen, bool *typbyval,
      char *typalign);
extern Oid getTypeIOParam(HeapTuple typeTuple);
extern void get_type_io_data(Oid typid,
     IOFuncSelector which_func,
     int16 *typlen,
     bool *typbyval,
     char *typalign,
     char *typdelim,
     Oid *typioparam,
     Oid *func);
extern char get_typstorage(Oid typid);
extern Node *get_typdefault(Oid typid);
extern char get_typtype(Oid typid);
extern bool type_is_rowtype(Oid typid);
extern bool type_is_enum(Oid typid);
extern bool type_is_range(Oid typid);
extern void get_type_category_preferred(Oid typid,
       char *typcategory,
       bool *typispreferred);
extern Oid get_typ_typrelid(Oid typid);
extern Oid get_element_type(Oid typid);
extern Oid get_array_type(Oid typid);
extern Oid get_base_element_type(Oid typid);
extern void getTypeInputInfo(Oid type, Oid *typInput, Oid *typIOParam);
extern void getTypeOutputInfo(Oid type, Oid *typOutput, bool *typIsVarlena);
extern void getTypeBinaryInputInfo(Oid type, Oid *typReceive, Oid *typIOParam);
extern void getTypeBinaryOutputInfo(Oid type, Oid *typSend, bool *typIsVarlena);
extern Oid get_typmodin(Oid typid);
extern Oid get_typcollation(Oid typid);
extern bool type_is_collatable(Oid typid);
extern Oid getBaseType(Oid typid);
extern Oid getBaseTypeAndTypmod(Oid typid, int32 *typmod);
extern int32 get_typavgwidth(Oid typid, int32 typmod);
extern int32 get_attavgwidth(Oid relid, AttrNumber attnum);
extern bool get_attstatsslot(HeapTuple statstuple,
     Oid atttype, int32 atttypmod,
     int reqkind, Oid reqop,
     Oid *actualop,
     Datum **values, int *nvalues,
     float4 **numbers, int *nnumbers);
extern void free_attstatsslot(Oid atttype,
      Datum *values, int nvalues,
      float4 *numbers, int nnumbers);
extern char *get_namespace_name(Oid nspid);
extern Oid get_range_subtype(Oid rangeOid);
# 38 "hba.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/memnodes.h" 1
# 36 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/memnodes.h"
typedef struct MemoryContextMethods
{
 void *(*alloc) (MemoryContext context, Size size);

 void (*free_p) (MemoryContext context, void *pointer);
 void *(*realloc) (MemoryContext context, void *pointer, Size size);
 void (*init) (MemoryContext context);
 void (*reset) (MemoryContext context);
 void (*delete_context) (MemoryContext context);
 Size (*get_chunk_space) (MemoryContext context, void *pointer);
 bool (*is_empty) (MemoryContext context);
 void (*stats) (MemoryContext context, int level);



} MemoryContextMethods;


typedef struct MemoryContextData
{
 NodeTag type;
 MemoryContextMethods *methods;
 MemoryContext parent;
 MemoryContext firstchild;
 MemoryContext nextchild;
 char *name;
 bool isReset;
} MemoryContextData;
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h" 2
# 53 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h"
typedef struct StandardChunkHeader
{
 MemoryContext context;
 Size size;




} StandardChunkHeader;
# 72 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h"
extern MemoryContext TopMemoryContext;
extern MemoryContext ErrorContext;
extern MemoryContext PostmasterContext;
extern MemoryContext CacheMemoryContext;
extern MemoryContext MessageContext;
extern MemoryContext TopTransactionContext;
extern MemoryContext CurTransactionContext;


extern MemoryContext PortalContext;





extern void MemoryContextInit(void);
extern void MemoryContextReset(MemoryContext context);
extern void MemoryContextDelete(MemoryContext context);
extern void MemoryContextResetChildren(MemoryContext context);
extern void MemoryContextDeleteChildren(MemoryContext context);
extern void MemoryContextResetAndDeleteChildren(MemoryContext context);
extern void MemoryContextSetParent(MemoryContext context,
        MemoryContext new_parent);
extern Size GetMemoryChunkSpace(void *pointer);
extern MemoryContext GetMemoryChunkContext(void *pointer);
extern MemoryContext MemoryContextGetParent(MemoryContext context);
extern bool MemoryContextIsEmpty(MemoryContext context);
extern void MemoryContextStats(MemoryContext context);




extern bool MemoryContextContains(MemoryContext context, void *pointer);






extern MemoryContext MemoryContextCreate(NodeTag tag, Size size,
     MemoryContextMethods *methods,
     MemoryContext parent,
     const char *name);







extern MemoryContext AllocSetContextCreate(MemoryContext parent,
       const char *name,
       Size minContextSize,
       Size initBlockSize,
       Size maxBlockSize);
# 39 "hba.c" 2
# 47 "hba.c"
typedef struct check_network_data
{
 IPCompareMethod method;
 SockAddr *raddr;
 bool result;
} check_network_data;
# 62 "hba.c"
typedef struct HbaToken
{
 char *string;
 bool quoted;
} HbaToken;





static List *parsed_hba_lines = ((List *) ((void *)0));
static MemoryContext parsed_hba_context = ((void *)0);
# 85 "hba.c"
static List *ident_lines = ((List *) ((void *)0));
static List *ident_line_nums = ((List *) ((void *)0));
static MemoryContext ident_context = ((void *)0);


static MemoryContext tokenize_file(const char *filename, FILE *file,
     List **lines, List **line_nums);
static List *tokenize_inc_file(List *tokens, const char *outer_filename,
      const char *inc_filename);
static bool parse_hba_auth_opt(char *name, char *val, HbaLine *hbaline,
       int line_num);





bool
pg_isblank(const char c)
{
 return c == ' ' || c == '\t' || c == '\r';
}
# 131 "hba.c"
static bool
next_token(FILE *fp, char *buf, int bufsz, bool *initial_quote,
     bool *terminating_comma)
{
 int c;
 char *start_buf = buf;
 char *end_buf = buf + (bufsz - 2);
 bool in_quote = ((bool) 0);
 bool was_quote = ((bool) 0);
 bool saw_quote = ((bool) 0);


 ;

 *initial_quote = ((bool) 0);
 *terminating_comma = ((bool) 0);


 while ((c = getc(fp)) != (-1) && (pg_isblank(c) || c == ','))
  ;

 if (c == (-1) || c == '\n')
 {
  *buf = '\0';
  return ((bool) 0);
 }





 while (c != (-1) && c != '\n' &&
     (!pg_isblank(c) || in_quote))
 {

  if (c == '#' && !in_quote)
  {
   while ((c = getc(fp)) != (-1) && c != '\n')
    ;

   if (c != (-1) && buf == start_buf)
    c = getc(fp);
   break;
  }

  if (buf >= end_buf)
  {
   *buf = '\0';
   (errstart(15, "hba.c", 182, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication file token too long, skipping: \"%s\"", start_buf))) : (void) 0);




   while ((c = getc(fp)) != (-1) && c != '\n')
    ;
   break;
  }


  if (c == ',' && !in_quote)
  {
   *terminating_comma = ((bool) 1);
   break;
  }

  if (c != '"' || was_quote)
   *buf++ = c;


  if (in_quote && c == '"')
   was_quote = !was_quote;
  else
   was_quote = ((bool) 0);

  if (c == '"')
  {
   in_quote = !in_quote;
   saw_quote = ((bool) 1);
   if (buf == start_buf)
    *initial_quote = ((bool) 1);
  }

  c = getc(fp);
 }





 if (c != (-1))
  ungetc(c, fp);

 *buf = '\0';

 return (saw_quote || buf > start_buf);
}

static HbaToken *
make_hba_token(char *token, bool quoted)
{
 HbaToken *hbatoken;
 int toklen;

 toklen = strlen(token);
 hbatoken = (HbaToken *) MemoryContextAlloc(CurrentMemoryContext, (sizeof(HbaToken) + toklen + 1));
 hbatoken->string = (char *) hbatoken + sizeof(HbaToken);
 hbatoken->quoted = quoted;
 ((__builtin_object_size (hbatoken->string, 0) != (size_t) -1) ? __builtin___memcpy_chk (hbatoken->string, token, toklen + 1, __builtin_object_size (hbatoken->string, 0)) : __inline_memcpy_chk (hbatoken->string, token, toklen + 1));

 return hbatoken;
}




static HbaToken *
copy_hba_token(HbaToken *in)
{
 HbaToken *out = make_hba_token(in->string, in->quoted);

 return out;
}
# 261 "hba.c"
static List *
next_field_expand(const char *filename, FILE *file)
{
 char buf[256];
 bool trailing_comma;
 bool initial_quote;
 List *tokens = ((List *) ((void *)0));

 do
 {
  if (!next_token(file, buf, sizeof(buf), &initial_quote, &trailing_comma))
   break;


  if (!initial_quote && buf[0] == '@' && buf[1] != '\0')
   tokens = tokenize_inc_file(tokens, filename, buf + 1);
  else
   tokens = lappend(tokens, make_hba_token(buf, initial_quote));
 } while (trailing_comma);

 return tokens;
}
# 293 "hba.c"
static List *
tokenize_inc_file(List *tokens,
      const char *outer_filename,
      const char *inc_filename)
{
 char *inc_fullname;
 FILE *inc_file;
 List *inc_lines;
 List *inc_line_nums;
 ListCell *inc_line;
 MemoryContext linecxt;

 if (( (((inc_filename)[0]) == '/') ))
 {

  inc_fullname = MemoryContextStrdup(CurrentMemoryContext, (inc_filename));
 }
 else
 {

  inc_fullname = (char *) MemoryContextAlloc(CurrentMemoryContext, (strlen(outer_filename) + 1 + strlen(inc_filename) + 1));

  ((__builtin_object_size (inc_fullname, 0) != (size_t) -1) ? __builtin___strcpy_chk (inc_fullname, outer_filename, __builtin_object_size (inc_fullname, 2 > 1)) : __inline_strcpy_chk (inc_fullname, outer_filename));
  get_parent_directory(inc_fullname);
  join_path_components(inc_fullname, inc_fullname, inc_filename);
  canonicalize_path(inc_fullname);
 }

 inc_file = AllocateFile(inc_fullname, "r");
 if (inc_file == ((void *)0))
 {
  (errstart(15, "hba.c", 327, __func__, ((void *)0)) ? (errfinish (errcode_for_file_access(), errmsg("could not open secondary authentication file \"@%s\" as \"%s\": %m", inc_filename, inc_fullname))) : (void) 0);



  pfree(inc_fullname);
  return tokens;
 }


 linecxt = tokenize_file(inc_fullname, inc_file, &inc_lines, &inc_line_nums);

 FreeFile(inc_file);
 pfree(inc_fullname);

 for ((inc_line) = list_head(inc_lines); (inc_line) != ((void *)0); (inc_line) = ((inc_line)->next))
 {
  List *inc_fields = ((inc_line)->data.ptr_value);
  ListCell *inc_field;

  for ((inc_field) = list_head(inc_fields); (inc_field) != ((void *)0); (inc_field) = ((inc_field)->next))
  {
   List *inc_tokens = ((inc_field)->data.ptr_value);
   ListCell *inc_token;

   for ((inc_token) = list_head(inc_tokens); (inc_token) != ((void *)0); (inc_token) = ((inc_token)->next))
   {
    HbaToken *token = ((inc_token)->data.ptr_value);

    tokens = lappend(tokens, copy_hba_token(token));
   }
  }
 }

 MemoryContextDelete(linecxt);
 return tokens;
}
# 373 "hba.c"
static MemoryContext
tokenize_file(const char *filename, FILE *file,
     List **lines, List **line_nums)
{
 List *current_line = ((List *) ((void *)0));
 List *current_field = ((List *) ((void *)0));
 int line_number = 1;
 MemoryContext linecxt;
 MemoryContext oldcxt;

 linecxt = AllocSetContextCreate(TopMemoryContext,
         "tokenize file cxt",
         0,
         (8 * 1024),
         (8 * 1024 * 1024));
 oldcxt = MemoryContextSwitchTo(linecxt);

 *lines = *line_nums = ((List *) ((void *)0));

 while (!feof(file) && !ferror(file))
 {
  current_field = next_field_expand(filename, file);


  if (list_length(current_field) > 0)
  {
   if (current_line == ((List *) ((void *)0)))
   {

    current_line = lappend(current_line, current_field);
    *lines = lappend(*lines, current_line);
    *line_nums = lappend_int(*line_nums, line_number);
   }
   else
   {

    current_line = lappend(current_line, current_field);
   }
  }
  else
  {

   current_line = ((List *) ((void *)0));
   line_number++;
  }
 }

 MemoryContextSwitchTo(oldcxt);

 return linecxt;
}
# 432 "hba.c"
static bool
is_member(Oid userid, const char *role)
{
 Oid roleid;

 if (!((bool) ((userid) != ((Oid) 0))))
  return ((bool) 0);

 roleid = get_role_oid(role, ((bool) 1));

 if (!((bool) ((roleid) != ((Oid) 0))))
  return ((bool) 0);






 return is_member_of_role_nosuper(userid, roleid);
}




static bool
check_role(const char *role, Oid roleid, List *tokens)
{
 ListCell *cell;
 HbaToken *tok;

 for ((cell) = list_head(tokens); (cell) != ((void *)0); (cell) = ((cell)->next))
 {
  tok = ((cell)->data.ptr_value);
  if (!tok->quoted && tok->string[0] == '+')
  {
   if (is_member(roleid, tok->string + 1))
    return ((bool) 1);
  }
  else if ((strcmp(tok->string, role) == 0) ||
     (!tok->quoted && strcmp(tok->string, "all") == 0))
   return ((bool) 1);
 }
 return ((bool) 0);
}




static bool
check_db(const char *dbname, const char *role, Oid roleid, List *tokens)
{
 ListCell *cell;
 HbaToken *tok;

 for ((cell) = list_head(tokens); (cell) != ((void *)0); (cell) = ((cell)->next))
 {
  tok = ((cell)->data.ptr_value);
  if (am_walsender)
  {

   if ((!tok->quoted && strcmp(tok->string, "replication") == 0))
    return ((bool) 1);
  }
  else if ((!tok->quoted && strcmp(tok->string, "all") == 0))
   return ((bool) 1);
  else if ((!tok->quoted && strcmp(tok->string, "sameuser") == 0))
  {
   if (strcmp(dbname, role) == 0)
    return ((bool) 1);
  }
  else if ((!tok->quoted && strcmp(tok->string, "samegroup") == 0) ||
     (!tok->quoted && strcmp(tok->string, "samerole") == 0))
  {
   if (is_member(roleid, dbname))
    return ((bool) 1);
  }
  else if ((!tok->quoted && strcmp(tok->string, "replication") == 0))
   continue;
  else if ((strcmp(tok->string, dbname) == 0))
   return ((bool) 1);
 }
 return ((bool) 0);
}

static bool
ipv4eq(struct sockaddr_in * a, struct sockaddr_in * b)
{
 return (a->sin_addr.s_addr == b->sin_addr.s_addr);
}



static bool
ipv6eq(struct sockaddr_in6 * a, struct sockaddr_in6 * b)
{
 int i;

 for (i = 0; i < 16; i++)
  if (a->sin6_addr.__u6_addr.__u6_addr8[i] != b->sin6_addr.__u6_addr.__u6_addr8[i])
   return ((bool) 0);

 return ((bool) 1);
}





static bool
hostname_match(const char *pattern, const char *actual_hostname)
{
 if (pattern[0] == '.')
 {
  size_t plen = strlen(pattern);
  size_t hlen = strlen(actual_hostname);

  if (hlen < plen)
   return ((bool) 0);

  return (pg_strcasecmp(pattern, actual_hostname + (hlen - plen)) == 0);
 }
 else
  return (pg_strcasecmp(pattern, actual_hostname) == 0);
}




static bool
check_hostname(hbaPort *port, const char *hostname)
{
 struct addrinfo *gai_result,
      *gai;
 int ret;
 bool found;


 if (!port->remote_hostname)
 {
  char remote_hostname[1025];

  if (pg_getnameinfo_all(&port->raddr.addr, port->raddr.salen,
          remote_hostname, sizeof(remote_hostname),
          ((void *)0), 0,
          0) != 0)
   return ((bool) 0);

  port->remote_hostname = MemoryContextStrdup(CurrentMemoryContext, (remote_hostname));
 }

 if (!hostname_match(hostname, port->remote_hostname))
  return ((bool) 0);



 if (port->remote_hostname_resolv == +1)
  return ((bool) 1);
 if (port->remote_hostname_resolv == -1)
  return ((bool) 0);

 ret = getaddrinfo(port->remote_hostname, ((void *)0), ((void *)0), &gai_result);
 if (ret != 0)
  (errstart(20, "hba.c", 596, __func__, ((void *)0)) ? (errfinish (errmsg("could not translate host name \"%s\" to address: %s", port->remote_hostname, gai_strerror(ret)))) : (void) 0);



 found = ((bool) 0);
 for (gai = gai_result; gai; gai = gai->ai_next)
 {
  if (gai->ai_addr->sa_family == port->raddr.addr.ss_family)
  {
   if (gai->ai_addr->sa_family == 2)
   {
    if (ipv4eq((struct sockaddr_in *) gai->ai_addr,
         (struct sockaddr_in *) & port->raddr.addr))
    {
     found = ((bool) 1);
     break;
    }
   }

   else if (gai->ai_addr->sa_family == 30)
   {
    if (ipv6eq((struct sockaddr_in6 *) gai->ai_addr,
         (struct sockaddr_in6 *) & port->raddr.addr))
    {
     found = ((bool) 1);
     break;
    }
   }

  }
 }

 if (gai_result)
  freeaddrinfo(gai_result);

 if (!found)
  elog_start("hba.c", 630, __func__), elog_finish(13, "pg_hba.conf host name \"%s\" rejected because address resolution did not return a match with IP address of client",
    hostname);

 port->remote_hostname_resolv = found ? +1 : -1;

 return found;
}




static bool
check_ip(SockAddr *raddr, struct sockaddr * addr, struct sockaddr * mask)
{
 if (raddr->addr.ss_family == addr->sa_family)
 {

  if (!pg_range_sockaddr(&raddr->addr,
          (struct sockaddr_storage *) addr,
          (struct sockaddr_storage *) mask))
   return ((bool) 0);
 }

 else if (addr->sa_family == 2 &&
    raddr->addr.ss_family == 30)
 {





  struct sockaddr_storage addrcopy,
     maskcopy;

  ((__builtin_object_size (&addrcopy, 0) != (size_t) -1) ? __builtin___memcpy_chk (&addrcopy, &addr, sizeof(addrcopy), __builtin_object_size (&addrcopy, 0)) : __inline_memcpy_chk (&addrcopy, &addr, sizeof(addrcopy)));
  ((__builtin_object_size (&maskcopy, 0) != (size_t) -1) ? __builtin___memcpy_chk (&maskcopy, &mask, sizeof(maskcopy), __builtin_object_size (&maskcopy, 0)) : __inline_memcpy_chk (&maskcopy, &mask, sizeof(maskcopy)));
  pg_promote_v4_to_v6_addr(&addrcopy);
  pg_promote_v4_to_v6_mask(&maskcopy);

  if (!pg_range_sockaddr(&raddr->addr, &addrcopy, &maskcopy))
   return ((bool) 0);
 }

 else
 {

  return ((bool) 0);
 }

 return ((bool) 1);
}




static void
check_network_callback(struct sockaddr * addr, struct sockaddr * netmask,
        void *cb_data)
{
 check_network_data *cn = (check_network_data *) cb_data;
 struct sockaddr_storage mask;


 if (cn->result)
  return;

 if (cn->method == ipCmpSameHost)
 {

  pg_sockaddr_cidr_mask(&mask, ((void *)0), addr->sa_family);
  cn->result = check_ip(cn->raddr, addr, (struct sockaddr *) & mask);
 }
 else
 {

  cn->result = check_ip(cn->raddr, addr, netmask);
 }
}




static bool
check_same_host_or_net(SockAddr *raddr, IPCompareMethod method)
{
 check_network_data cn;

 cn.method = method;
 cn.raddr = raddr;
 cn.result = ((bool) 0);

 (*__error()) = 0;
 if (pg_foreach_ifaddr(check_network_callback, &cn) < 0)
 {
  elog_start("hba.c", 724, __func__), elog_finish(15, "error enumerating network interfaces: %m");
  return ((bool) 0);
 }

 return cn.result;
}
# 814 "hba.c"
static HbaLine *
parse_hba_line(List *line, int line_num)
{
 char *str;
 struct addrinfo *gai_result;
 struct addrinfo hints;
 int ret;
 char *cidr_slash;
 char *unsupauth;
 ListCell *field;
 List *tokens;
 ListCell *tokencell;
 HbaToken *token;
 HbaLine *parsedline;

 parsedline = MemoryContextAllocZero(CurrentMemoryContext, (sizeof(HbaLine)));
 parsedline->linenumber = line_num;


 field = list_head(line);
 tokens = ((field)->data.ptr_value);
 if (tokens->length > 1)
 {
  (errstart(15, "hba.c", 842, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("multiple values specified for connection type"), errhint("Specify exactly one connection type per line."), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);





  return ((void *)0);
 }
 token = ((list_head(tokens))->data.ptr_value);
 if (strcmp(token->string, "local") == 0)
 {

  parsedline->conntype = ctLocal;
# 858 "hba.c"
 }
 else if (strcmp(token->string, "host") == 0 ||
    strcmp(token->string, "hostssl") == 0 ||
    strcmp(token->string, "hostnossl") == 0)
 {

  if (token->string[4] == 's')
  {
# 881 "hba.c"
   (errstart(15, "hba.c", 886, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("hostssl is not supported by this build"), errhint("Compile with --with-openssl to use SSL connections."), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);





   return ((void *)0);

  }






  else
  {

   parsedline->conntype = ctHost;
  }
 }
 else
 {
  (errstart(15, "hba.c", 909, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("invalid connection type \"%s\"", token->string), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);





  return ((void *)0);
 }


 field = ((field)->next);
 if (!field)
 {
  (errstart(15, "hba.c", 921, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("end-of-line before database specification"), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);




  return ((void *)0);
 }
 parsedline->databases = ((List *) ((void *)0));
 tokens = ((field)->data.ptr_value);
 for ((tokencell) = list_head(tokens); (tokencell) != ((void *)0); (tokencell) = ((tokencell)->next))
 {
  parsedline->databases = lappend(parsedline->databases,
          copy_hba_token(((tokencell)->data.ptr_value)));
 }


 field = ((field)->next);
 if (!field)
 {
  (errstart(15, "hba.c", 940, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("end-of-line before role specification"), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);




  return ((void *)0);
 }
 parsedline->roles = ((List *) ((void *)0));
 tokens = ((field)->data.ptr_value);
 for ((tokencell) = list_head(tokens); (tokencell) != ((void *)0); (tokencell) = ((tokencell)->next))
 {
  parsedline->roles = lappend(parsedline->roles,
         copy_hba_token(((tokencell)->data.ptr_value)));
 }

 if (parsedline->conntype != ctLocal)
 {

  field = ((field)->next);
  if (!field)
  {
   (errstart(15, "hba.c", 961, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("end-of-line before IP address specification"), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);




   return ((void *)0);
  }
  tokens = ((field)->data.ptr_value);
  if (tokens->length > 1)
  {
   (errstart(15, "hba.c", 972, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("multiple values specified for host address"), errhint("Specify one address range per line."), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);





   return ((void *)0);
  }
  token = ((list_head(tokens))->data.ptr_value);

  if ((!token->quoted && strcmp(token->string, "all") == 0))
  {
   parsedline->ip_cmp_method = ipCmpAll;
  }
  else if ((!token->quoted && strcmp(token->string, "samehost") == 0))
  {

   parsedline->ip_cmp_method = ipCmpSameHost;
  }
  else if ((!token->quoted && strcmp(token->string, "samenet") == 0))
  {

   parsedline->ip_cmp_method = ipCmpSameNet;
  }
  else
  {

   parsedline->ip_cmp_method = ipCmpMask;


   str = MemoryContextStrdup(CurrentMemoryContext, (token->string));


   cidr_slash = strchr(str, '/');
   if (cidr_slash)
    *cidr_slash = '\0';


   hints.ai_flags = 0;
   hints.ai_family = 0;
   hints.ai_socktype = 0;
   hints.ai_protocol = 0;
   hints.ai_addrlen = 0;
   hints.ai_canonname = ((void *)0);
   hints.ai_addr = ((void *)0);
   hints.ai_next = ((void *)0);

   ret = pg_getaddrinfo_all(str, ((void *)0), &hints, &gai_result);
   if (ret == 0 && gai_result)
    ((__builtin_object_size (&parsedline->addr, 0) != (size_t) -1) ? __builtin___memcpy_chk (&parsedline->addr, gai_result->ai_addr, gai_result->ai_addrlen, __builtin_object_size (&parsedline->addr, 0)) : __inline_memcpy_chk (&parsedline->addr, gai_result->ai_addr, gai_result->ai_addrlen));

   else if (ret == (-2))
    parsedline->hostname = str;
   else
   {
    (errstart(15, "hba.c", 1027, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("invalid IP address \"%s\": %s", str, gai_strerror(ret)), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);





    if (gai_result)
     pg_freeaddrinfo_all(hints.ai_family, gai_result);
    return ((void *)0);
   }

   pg_freeaddrinfo_all(hints.ai_family, gai_result);


   if (cidr_slash)
   {
    if (parsedline->hostname)
    {
     (errstart(15, "hba.c", 1045, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("specifying both host name and CIDR mask is invalid: \"%s\"", token->string), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);





     return ((void *)0);
    }

    if (pg_sockaddr_cidr_mask(&parsedline->mask, cidr_slash + 1,
            parsedline->addr.ss_family) < 0)
    {
     (errstart(15, "hba.c", 1057, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("invalid CIDR mask in address \"%s\"", token->string), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);





     return ((void *)0);
    }
    pfree(str);
   }
   else if (!parsedline->hostname)
   {

    pfree(str);
    field = ((field)->next);
    if (!field)
    {
     (errstart(15, "hba.c", 1074, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("end-of-line before netmask specification"), errhint("Specify an address range in CIDR notation, or provide a separate netmask."), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);





     return ((void *)0);
    }
    tokens = ((field)->data.ptr_value);
    if (tokens->length > 1)
    {
     (errstart(15, "hba.c", 1084, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("multiple values specified for netmask"), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);




     return ((void *)0);
    }
    token = ((list_head(tokens))->data.ptr_value);

    ret = pg_getaddrinfo_all(token->string, ((void *)0),
           &hints, &gai_result);
    if (ret || !gai_result)
    {
     (errstart(15, "hba.c", 1098, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("invalid IP mask \"%s\": %s", token->string, gai_strerror(ret)), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);





     if (gai_result)
      pg_freeaddrinfo_all(hints.ai_family, gai_result);
     return ((void *)0);
    }

    ((__builtin_object_size (&parsedline->mask, 0) != (size_t) -1) ? __builtin___memcpy_chk (&parsedline->mask, gai_result->ai_addr, gai_result->ai_addrlen, __builtin_object_size (&parsedline->mask, 0)) : __inline_memcpy_chk (&parsedline->mask, gai_result->ai_addr, gai_result->ai_addrlen));

    pg_freeaddrinfo_all(hints.ai_family, gai_result);

    if (parsedline->addr.ss_family != parsedline->mask.ss_family)
    {
     (errstart(15, "hba.c", 1114, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("IP address and mask do not match"), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);




     return ((void *)0);
    }
   }
  }
 }


 field = ((field)->next);
 if (!field)
 {
  (errstart(15, "hba.c", 1129, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("end-of-line before authentication method"), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);




  return ((void *)0);
 }
 tokens = ((field)->data.ptr_value);
 if (tokens->length > 1)
 {
  (errstart(15, "hba.c", 1140, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("multiple values specified for authentication type"), errhint("Specify exactly one authentication type per line."), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);





  return ((void *)0);
 }
 token = ((list_head(tokens))->data.ptr_value);

 unsupauth = ((void *)0);
 if (strcmp(token->string, "trust") == 0)
  parsedline->auth_method = uaTrust;
 else if (strcmp(token->string, "ident") == 0)
  parsedline->auth_method = uaIdent;
 else if (strcmp(token->string, "peer") == 0)
  parsedline->auth_method = uaPeer;
 else if (strcmp(token->string, "password") == 0)
  parsedline->auth_method = uaPassword;
 else if (strcmp(token->string, "krb5") == 0)



  unsupauth = "krb5";

 else if (strcmp(token->string, "gss") == 0)



  unsupauth = "gss";

 else if (strcmp(token->string, "sspi") == 0)



  unsupauth = "sspi";

 else if (strcmp(token->string, "reject") == 0)
  parsedline->auth_method = uaReject;
 else if (strcmp(token->string, "md5") == 0)
 {
  if (Db_user_namespace)
  {
   (errstart(15, "hba.c", 1182, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("MD5 authentication is not supported when \"db_user_namespace\" is enabled"), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);




   return ((void *)0);
  }
  parsedline->auth_method = uaMD5;
 }
 else if (strcmp(token->string, "pam") == 0)



  unsupauth = "pam";

 else if (strcmp(token->string, "ldap") == 0)



  unsupauth = "ldap";

 else if (strcmp(token->string, "cert") == 0)



  unsupauth = "cert";

 else if (strcmp(token->string, "radius") == 0)
  parsedline->auth_method = uaRADIUS;
 else
 {
  (errstart(15, "hba.c", 1214, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("invalid authentication method \"%s\"", token->string), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);





  return ((void *)0);
 }

 if (unsupauth)
 {
  (errstart(15, "hba.c", 1225, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("invalid authentication method \"%s\": not supported by this build", token->string), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);





  return ((void *)0);
 }





 if (parsedline->conntype == ctLocal &&
  parsedline->auth_method == uaIdent)
  parsedline->auth_method = uaPeer;


 if (parsedline->conntype == ctLocal &&
  parsedline->auth_method == uaKrb5)
 {
  (errstart(15, "hba.c", 1245, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("krb5 authentication is not supported on local sockets"), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);




  return ((void *)0);
 }

 if (parsedline->conntype == ctLocal &&
  parsedline->auth_method == uaGSS)
 {
  (errstart(15, "hba.c", 1256, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("gssapi authentication is not supported on local sockets"), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);




  return ((void *)0);
 }

 if (parsedline->conntype != ctLocal &&
  parsedline->auth_method == uaPeer)
 {
  (errstart(15, "hba.c", 1267, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("peer authentication is only supported on local sockets"), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);




  return ((void *)0);
 }







 if (parsedline->conntype != ctHostSSL &&
  parsedline->auth_method == uaCert)
 {
  (errstart(15, "hba.c", 1284, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("cert authentication is only supported on hostssl connections"), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);




  return ((void *)0);
 }


 while ((field = ((field)->next)) != ((void *)0))
 {
  tokens = ((field)->data.ptr_value);
  for ((tokencell) = list_head(tokens); (tokencell) != ((void *)0); (tokencell) = ((tokencell)->next))
  {
   char *val;

   token = ((tokencell)->data.ptr_value);

   str = MemoryContextStrdup(CurrentMemoryContext, (token->string));
   val = strchr(str, '=');
   if (val == ((void *)0))
   {



    (errstart(15, "hba.c", 1309, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication option not in name=value format: %s", token->string), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);




    return ((void *)0);
   }

   *val++ = '\0';
   if (!parse_hba_auth_opt(str, val, parsedline, line_num))

    return ((void *)0);
   pfree(str);
  }
 }





 if (parsedline->auth_method == uaLDAP)
 {
  do { if (parsedline->ldapserver == ((void *)0)) { (errstart(15, "hba.c", 1327, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication method \"%s\" requires argument \"%s\" to be set", "ldap", "ldapserver"), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } } while (0);;







  if (parsedline->ldapprefix || parsedline->ldapsuffix)
  {
   if (parsedline->ldapbasedn ||
    parsedline->ldapbinddn ||
    parsedline->ldapbindpasswd ||
    parsedline->ldapsearchattribute)
   {
    (errstart(15, "hba.c", 1346, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("cannot use ldapbasedn, ldapbinddn, ldapbindpasswd, or ldapsearchattribute together with ldapprefix"), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);




    return ((void *)0);
   }
  }
  else if (!parsedline->ldapbasedn)
  {
   (errstart(15, "hba.c", 1356, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication method \"ldap\" requires argument \"ldapbasedn\", \"ldapprefix\", or \"ldapsuffix\" to be set"), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);




   return ((void *)0);
  }
 }

 if (parsedline->auth_method == uaRADIUS)
 {
  do { if (parsedline->radiusserver == ((void *)0)) { (errstart(15, "hba.c", 1363, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication method \"%s\" requires argument \"%s\" to be set", "radius", "radiusserver"), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } } while (0);;
  do { if (parsedline->radiussecret == ((void *)0)) { (errstart(15, "hba.c", 1364, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication method \"%s\" requires argument \"%s\" to be set", "radius", "radiussecret"), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } } while (0);;
 }




 if (parsedline->auth_method == uaCert)
 {
  parsedline->clientcert = ((bool) 1);
 }

 return parsedline;
}






static bool
parse_hba_auth_opt(char *name, char *val, HbaLine *hbaline, int line_num)
{
 if (strcmp(name, "map") == 0)
 {
  if (hbaline->auth_method != uaIdent &&
   hbaline->auth_method != uaPeer &&
   hbaline->auth_method != uaKrb5 &&
   hbaline->auth_method != uaGSS &&
   hbaline->auth_method != uaSSPI &&
   hbaline->auth_method != uaCert)
   do { (errstart(15, "hba.c", 1394, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication option \"%s\" is only valid for authentication methods %s", "map", (("ident, peer, krb5, gssapi, sspi, and cert"))), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } while (0);;
  hbaline->usermap = MemoryContextStrdup(CurrentMemoryContext, (val));
 }
 else if (strcmp(name, "clientcert") == 0)
 {




  if (hbaline->conntype != ctHostSSL)
  {
   (errstart(15, "hba.c", 1409, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("clientcert can only be configured for \"hostssl\" rows"), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);




   return ((bool) 0);
  }
  if (strcmp(val, "1") == 0)
  {
   if (!secure_loaded_verify_locations())
   {
    (errstart(15, "hba.c", 1421, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("client certificates can only be checked if a root certificate store is available"), errhint("Make sure the configuration parameter \"ssl_ca_file\" is set."), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);





    return ((bool) 0);
   }
   hbaline->clientcert = ((bool) 1);
  }
  else
  {
   if (hbaline->auth_method == uaCert)
   {
    (errstart(15, "hba.c", 1434, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("clientcert can not be set to 0 when using \"cert\" authentication"), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);




    return ((bool) 0);
   }
   hbaline->clientcert = ((bool) 0);
  }
 }
 else if (strcmp(name, "pamservice") == 0)
 {
  do { if (hbaline->auth_method != uaPAM) do { (errstart(15, "hba.c", 1442, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication option \"%s\" is only valid for authentication methods %s", "pamservice", ("pam")), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } while (0);; } while (0);;
  hbaline->pamservice = MemoryContextStrdup(CurrentMemoryContext, (val));
 }
 else if (strcmp(name, "ldaptls") == 0)
 {
  do { if (hbaline->auth_method != uaLDAP) do { (errstart(15, "hba.c", 1447, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication option \"%s\" is only valid for authentication methods %s", "ldaptls", ("ldap")), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } while (0);; } while (0);;
  if (strcmp(val, "1") == 0)
   hbaline->ldaptls = ((bool) 1);
  else
   hbaline->ldaptls = ((bool) 0);
 }
 else if (strcmp(name, "ldapserver") == 0)
 {
  do { if (hbaline->auth_method != uaLDAP) do { (errstart(15, "hba.c", 1455, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication option \"%s\" is only valid for authentication methods %s", "ldapserver", ("ldap")), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } while (0);; } while (0);;
  hbaline->ldapserver = MemoryContextStrdup(CurrentMemoryContext, (val));
 }
 else if (strcmp(name, "ldapport") == 0)
 {
  do { if (hbaline->auth_method != uaLDAP) do { (errstart(15, "hba.c", 1460, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication option \"%s\" is only valid for authentication methods %s", "ldapport", ("ldap")), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } while (0);; } while (0);;
  hbaline->ldapport = atoi(val);
  if (hbaline->ldapport == 0)
  {
   (errstart(15, "hba.c", 1468, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("invalid LDAP port number: \"%s\"", val), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);




   return ((bool) 0);
  }
 }
 else if (strcmp(name, "ldapbinddn") == 0)
 {
  do { if (hbaline->auth_method != uaLDAP) do { (errstart(15, "hba.c", 1474, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication option \"%s\" is only valid for authentication methods %s", "ldapbinddn", ("ldap")), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } while (0);; } while (0);;
  hbaline->ldapbinddn = MemoryContextStrdup(CurrentMemoryContext, (val));
 }
 else if (strcmp(name, "ldapbindpasswd") == 0)
 {
  do { if (hbaline->auth_method != uaLDAP) do { (errstart(15, "hba.c", 1479, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication option \"%s\" is only valid for authentication methods %s", "ldapbindpasswd", ("ldap")), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } while (0);; } while (0);;
  hbaline->ldapbindpasswd = MemoryContextStrdup(CurrentMemoryContext, (val));
 }
 else if (strcmp(name, "ldapsearchattribute") == 0)
 {
  do { if (hbaline->auth_method != uaLDAP) do { (errstart(15, "hba.c", 1484, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication option \"%s\" is only valid for authentication methods %s", "ldapsearchattribute", ("ldap")), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } while (0);; } while (0);;
  hbaline->ldapsearchattribute = MemoryContextStrdup(CurrentMemoryContext, (val));
 }
 else if (strcmp(name, "ldapbasedn") == 0)
 {
  do { if (hbaline->auth_method != uaLDAP) do { (errstart(15, "hba.c", 1489, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication option \"%s\" is only valid for authentication methods %s", "ldapbasedn", ("ldap")), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } while (0);; } while (0);;
  hbaline->ldapbasedn = MemoryContextStrdup(CurrentMemoryContext, (val));
 }
 else if (strcmp(name, "ldapprefix") == 0)
 {
  do { if (hbaline->auth_method != uaLDAP) do { (errstart(15, "hba.c", 1494, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication option \"%s\" is only valid for authentication methods %s", "ldapprefix", ("ldap")), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } while (0);; } while (0);;
  hbaline->ldapprefix = MemoryContextStrdup(CurrentMemoryContext, (val));
 }
 else if (strcmp(name, "ldapsuffix") == 0)
 {
  do { if (hbaline->auth_method != uaLDAP) do { (errstart(15, "hba.c", 1499, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication option \"%s\" is only valid for authentication methods %s", "ldapsuffix", ("ldap")), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } while (0);; } while (0);;
  hbaline->ldapsuffix = MemoryContextStrdup(CurrentMemoryContext, (val));
 }
 else if (strcmp(name, "krb_server_hostname") == 0)
 {
  do { if (hbaline->auth_method != uaKrb5) do { (errstart(15, "hba.c", 1504, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication option \"%s\" is only valid for authentication methods %s", "krb_server_hostname", ("krb5")), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } while (0);; } while (0);;
  hbaline->krb_server_hostname = MemoryContextStrdup(CurrentMemoryContext, (val));
 }
 else if (strcmp(name, "krb_realm") == 0)
 {
  if (hbaline->auth_method != uaKrb5 &&
   hbaline->auth_method != uaGSS &&
   hbaline->auth_method != uaSSPI)
   do { (errstart(15, "hba.c", 1512, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication option \"%s\" is only valid for authentication methods %s", "krb_realm", (("krb5, gssapi, and sspi"))), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } while (0);;
  hbaline->krb_realm = MemoryContextStrdup(CurrentMemoryContext, (val));
 }
 else if (strcmp(name, "include_realm") == 0)
 {
  if (hbaline->auth_method != uaKrb5 &&
   hbaline->auth_method != uaGSS &&
   hbaline->auth_method != uaSSPI)
   do { (errstart(15, "hba.c", 1520, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication option \"%s\" is only valid for authentication methods %s", "include_realm", (("krb5, gssapi, and sspi"))), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } while (0);;
  if (strcmp(val, "1") == 0)
   hbaline->include_realm = ((bool) 1);
  else
   hbaline->include_realm = ((bool) 0);
 }
 else if (strcmp(name, "radiusserver") == 0)
 {
  struct addrinfo *gai_result;
  struct addrinfo hints;
  int ret;

  do { if (hbaline->auth_method != uaRADIUS) do { (errstart(15, "hba.c", 1532, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication option \"%s\" is only valid for authentication methods %s", "radiusserver", ("radius")), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } while (0);; } while (0);;

  do { void *_vstart = (void *) (&hints); int _val = (0); Size _len = (sizeof(hints)); if ((((intptr_t) _vstart) & (sizeof(long) - 1)) == 0 && (_len & (sizeof(long) - 1)) == 0 && _val == 0 && _len <= 1024 && 1024 != 0) { long *_start = (long *) _vstart; long *_stop = (long *) ((char *) _start + _len); while (_start < _stop) *_start++ = 0; } else ((__builtin_object_size (_vstart, 0) != (size_t) -1) ? __builtin___memset_chk (_vstart, _val, _len, __builtin_object_size (_vstart, 0)) : __inline_memset_chk (_vstart, _val, _len)); } while (0);
  hints.ai_socktype = 2;
  hints.ai_family = 0;

  ret = pg_getaddrinfo_all(val, ((void *)0), &hints, &gai_result);
  if (ret || !gai_result)
  {
   (errstart(15, "hba.c", 1546, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("could not translate RADIUS server name \"%s\" to address: %s", val, gai_strerror(ret)), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);





   if (gai_result)
    pg_freeaddrinfo_all(hints.ai_family, gai_result);
   return ((bool) 0);
  }
  pg_freeaddrinfo_all(hints.ai_family, gai_result);
  hbaline->radiusserver = MemoryContextStrdup(CurrentMemoryContext, (val));
 }
 else if (strcmp(name, "radiusport") == 0)
 {
  do { if (hbaline->auth_method != uaRADIUS) do { (errstart(15, "hba.c", 1556, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication option \"%s\" is only valid for authentication methods %s", "radiusport", ("radius")), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } while (0);; } while (0);;
  hbaline->radiusport = atoi(val);
  if (hbaline->radiusport == 0)
  {
   (errstart(15, "hba.c", 1564, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("invalid RADIUS port number: \"%s\"", val), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);




   return ((bool) 0);
  }
 }
 else if (strcmp(name, "radiussecret") == 0)
 {
  do { if (hbaline->auth_method != uaRADIUS) do { (errstart(15, "hba.c", 1570, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication option \"%s\" is only valid for authentication methods %s", "radiussecret", ("radius")), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } while (0);; } while (0);;
  hbaline->radiussecret = MemoryContextStrdup(CurrentMemoryContext, (val));
 }
 else if (strcmp(name, "radiusidentifier") == 0)
 {
  do { if (hbaline->auth_method != uaRADIUS) do { (errstart(15, "hba.c", 1575, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("authentication option \"%s\" is only valid for authentication methods %s", "radiusidentifier", ("radius")), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0); return ((bool) 0); } while (0);; } while (0);;
  hbaline->radiusidentifier = MemoryContextStrdup(CurrentMemoryContext, (val));
 }
 else
 {
  (errstart(15, "hba.c", 1585, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("unrecognized authentication option name: \"%s\"", name), errcontext("line %d of configuration file \"%s\"", line_num, HbaFileName))) : (void) 0);





  return ((bool) 0);
 }
 return ((bool) 1);
}





static void
check_hba(hbaPort *port)
{
 Oid roleid;
 ListCell *line;
 HbaLine *hba;


 roleid = get_role_oid(port->user_name, ((bool) 1));

 for ((line) = list_head(parsed_hba_lines); (line) != ((void *)0); (line) = ((line)->next))
 {
  hba = (HbaLine *) ((line)->data.ptr_value);


  if (hba->conntype == ctLocal)
  {
   if (!((port->raddr.addr.ss_family) == 1))
    continue;
  }
  else
  {
   if (((port->raddr.addr.ss_family) == 1))
    continue;
# 1636 "hba.c"
   if (hba->conntype == ctHostSSL)
    continue;



   switch (hba->ip_cmp_method)
   {
    case ipCmpMask:
     if (hba->hostname)
     {
      if (!check_hostname(port,
           hba->hostname))
       continue;
     }
     else
     {
      if (!check_ip(&port->raddr,
           (struct sockaddr *) & hba->addr,
           (struct sockaddr *) & hba->mask))
       continue;
     }
     break;
    case ipCmpAll:
     break;
    case ipCmpSameHost:
    case ipCmpSameNet:
     if (!check_same_host_or_net(&port->raddr,
            hba->ip_cmp_method))
      continue;
     break;
    default:

     continue;
   }
  }


  if (!check_db(port->database_name, port->user_name, roleid,
       hba->databases))
   continue;

  if (!check_role(port->user_name, roleid, hba->roles))
   continue;


  port->hba = hba;
  return;
 }


 hba = MemoryContextAllocZero(CurrentMemoryContext, (sizeof(HbaLine)));
 hba->auth_method = uaImplicitReject;
 port->hba = hba;
}
# 1702 "hba.c"
bool
load_hba(void)
{
 FILE *file;
 List *hba_lines = ((List *) ((void *)0));
 List *hba_line_nums = ((List *) ((void *)0));
 ListCell *line,
      *line_num;
 List *new_parsed_lines = ((List *) ((void *)0));
 bool ok = ((bool) 1);
 MemoryContext linecxt;
 MemoryContext oldcxt;
 MemoryContext hbacxt;

 file = AllocateFile(HbaFileName, "r");
 if (file == ((void *)0))
 {
  (errstart(15, "hba.c", 1722, __func__, ((void *)0)) ? (errfinish (errcode_for_file_access(), errmsg("could not open configuration file \"%s\": %m", HbaFileName))) : (void) 0);



  return ((bool) 0);
 }

 linecxt = tokenize_file(HbaFileName, file, &hba_lines, &hba_line_nums);
 FreeFile(file);


 hbacxt = AllocSetContextCreate(TopMemoryContext,
           "hba parser context",
           0,
           0,
           (8 * 1024 * 1024));
 oldcxt = MemoryContextSwitchTo(hbacxt);
 for ((line) = list_head(hba_lines), (line_num) = list_head(hba_line_nums); (line) != ((void *)0) && (line_num) != ((void *)0); (line) = ((line)->next), (line_num) = ((line_num)->next))
 {
  HbaLine *newline;

  if ((newline = parse_hba_line(((line)->data.ptr_value), ((line_num)->data.int_value))) == ((void *)0))
  {





   MemoryContextReset(hbacxt);
   new_parsed_lines = ((List *) ((void *)0));
   ok = ((bool) 0);






   continue;
  }

  new_parsed_lines = lappend(new_parsed_lines, newline);
 }






 if (ok && new_parsed_lines == ((List *) ((void *)0)))
 {
  (errstart(15, "hba.c", 1772, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("configuration file \"%s\" contains no entries", HbaFileName))) : (void) 0);



  ok = ((bool) 0);
 }


 MemoryContextDelete(linecxt);
 MemoryContextSwitchTo(oldcxt);

 if (!ok)
 {

  MemoryContextDelete(hbacxt);
  return ((bool) 0);
 }


 if (parsed_hba_context != ((void *)0))
  MemoryContextDelete(parsed_hba_context);
 parsed_hba_context = hbacxt;
 parsed_hba_lines = new_parsed_lines;

 return ((bool) 1);
}







static void
parse_ident_usermap(List *line, int line_number, const char *usermap_name,
     const char *pg_role, const char *ident_user,
     bool case_insensitive, bool *found_p, bool *error_p)
{
 ListCell *field;
 List *tokens;
 HbaToken *token;
 char *file_map;
 char *file_pgrole;
 char *file_ident_user;

 *found_p = ((bool) 0);
 *error_p = ((bool) 0);

 ;
 field = list_head(line);


 tokens = ((field)->data.ptr_value);
 do { if (tokens->length > 1) { (errstart(15, "hba.c", 1822, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("multiple values in ident field"), errcontext("line %d of configuration file \"%s\"", line_number, IdentFileName))) : (void) 0); *error_p = ((bool) 1); return; } } while (0);;
 token = ((list_head(tokens))->data.ptr_value);
 file_map = token->string;


 field = ((field)->next);
 do { if (!field) { (errstart(15, "hba.c", 1828, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("missing entry in file \"%s\" at end of line %d", IdentFileName, line_number))) : (void) 0); *error_p = ((bool) 1); return; } } while (0);;
 tokens = ((field)->data.ptr_value);
 do { if (tokens->length > 1) { (errstart(15, "hba.c", 1830, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("multiple values in ident field"), errcontext("line %d of configuration file \"%s\"", line_number, IdentFileName))) : (void) 0); *error_p = ((bool) 1); return; } } while (0);;
 token = ((list_head(tokens))->data.ptr_value);
 file_ident_user = token->string;


 field = ((field)->next);
 do { if (!field) { (errstart(15, "hba.c", 1836, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("missing entry in file \"%s\" at end of line %d", IdentFileName, line_number))) : (void) 0); *error_p = ((bool) 1); return; } } while (0);;
 tokens = ((field)->data.ptr_value);
 do { if (tokens->length > 1) { (errstart(15, "hba.c", 1838, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("multiple values in ident field"), errcontext("line %d of configuration file \"%s\"", line_number, IdentFileName))) : (void) 0); *error_p = ((bool) 1); return; } } while (0);;
 token = ((list_head(tokens))->data.ptr_value);
 file_pgrole = token->string;

 if (strcmp(file_map, usermap_name) != 0)

  return;


 if (file_ident_user[0] == '/')
 {






  int r;
  regex_t re;
  regmatch_t matches[2];
  pg_wchar *wstr;
  int wlen;
  char *ofs;
  char *regexp_pgrole;

  wstr = MemoryContextAlloc(CurrentMemoryContext, ((strlen(file_ident_user + 1) + 1) * sizeof(pg_wchar)));
  wlen = pg_mb2wchar_with_len(file_ident_user + 1, wstr, strlen(file_ident_user + 1));





  r = pg_regcomp(&re, wstr, wlen, 000003, 950);
  if (r)
  {
   char errstr[100];

   pg_regerror(r, &re, errstr, sizeof(errstr));
   (errstart(15, "hba.c", 1879, __func__, ((void *)0)) ? (errfinish (errcode((((('2') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('1') - '0') & 0x3F) << 18) + (((('B') - '0') & 0x3F) << 24))), errmsg("invalid regular expression \"%s\": %s", file_ident_user + 1, errstr))) : (void) 0);




   pfree(wstr);
   *error_p = ((bool) 1);
   return;
  }
  pfree(wstr);

  wstr = MemoryContextAlloc(CurrentMemoryContext, ((strlen(ident_user) + 1) * sizeof(pg_wchar)));
  wlen = pg_mb2wchar_with_len(ident_user, wstr, strlen(ident_user));

  r = pg_regexec(&re, wstr, wlen, 0, ((void *)0), 2, matches, 0);
  if (r)
  {
   char errstr[100];

   if (r != 1)
   {

    pg_regerror(r, &re, errstr, sizeof(errstr));
    (errstart(15, "hba.c", 1902, __func__, ((void *)0)) ? (errfinish (errcode((((('2') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('1') - '0') & 0x3F) << 18) + (((('B') - '0') & 0x3F) << 24))), errmsg("regular expression match for \"%s\" failed: %s", file_ident_user + 1, errstr))) : (void) 0);



    *error_p = ((bool) 1);
   }

   pfree(wstr);
   pg_regfree(&re);
   return;
  }
  pfree(wstr);

  if ((ofs = strstr(file_pgrole, "\\1")) != ((void *)0))
  {

   if (matches[1].rm_so < 0)
   {
    (errstart(15, "hba.c", 1920, __func__, ((void *)0)) ? (errfinish (errcode((((('2') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('1') - '0') & 0x3F) << 18) + (((('B') - '0') & 0x3F) << 24))), errmsg("regular expression \"%s\" has no subexpressions as requested by backreference in \"%s\"", file_ident_user + 1, file_pgrole))) : (void) 0);



    pg_regfree(&re);
    *error_p = ((bool) 1);
    return;
   }





   regexp_pgrole = MemoryContextAllocZero(CurrentMemoryContext, (strlen(file_pgrole) - 2 + (matches[1].rm_eo - matches[1].rm_so) + 1));
   ((__builtin_object_size (regexp_pgrole, 0) != (size_t) -1) ? __builtin___strncpy_chk (regexp_pgrole, file_pgrole, (ofs - file_pgrole), __builtin_object_size (regexp_pgrole, 2 > 1)) : __inline_strncpy_chk (regexp_pgrole, file_pgrole, (ofs - file_pgrole)));
   ((__builtin_object_size (regexp_pgrole + strlen(regexp_pgrole), 0) != (size_t) -1) ? __builtin___memcpy_chk (regexp_pgrole + strlen(regexp_pgrole), ident_user + matches[1].rm_so, matches[1].rm_eo - matches[1].rm_so, __builtin_object_size (regexp_pgrole + strlen(regexp_pgrole), 0)) : __inline_memcpy_chk (regexp_pgrole + strlen(regexp_pgrole), ident_user + matches[1].rm_so, matches[1].rm_eo - matches[1].rm_so));


   ((__builtin_object_size (regexp_pgrole, 0) != (size_t) -1) ? __builtin___strcat_chk (regexp_pgrole, ofs + 2, __builtin_object_size (regexp_pgrole, 2 > 1)) : __inline_strcat_chk (regexp_pgrole, ofs + 2));
  }
  else
  {

   regexp_pgrole = MemoryContextStrdup(CurrentMemoryContext, (file_pgrole));
  }

  pg_regfree(&re);





  if (case_insensitive)
  {
   if (pg_strcasecmp(regexp_pgrole, pg_role) == 0)
    *found_p = ((bool) 1);
  }
  else
  {
   if (strcmp(regexp_pgrole, pg_role) == 0)
    *found_p = ((bool) 1);
  }
  pfree(regexp_pgrole);

  return;
 }
 else
 {

  if (case_insensitive)
  {
   if (pg_strcasecmp(file_pgrole, pg_role) == 0 &&
    pg_strcasecmp(file_ident_user, ident_user) == 0)
    *found_p = ((bool) 1);
  }
  else
  {
   if (strcmp(file_pgrole, pg_role) == 0 &&
    strcmp(file_ident_user, ident_user) == 0)
    *found_p = ((bool) 1);
  }
 }
 return;
}
# 1996 "hba.c"
int
check_usermap(const char *usermap_name,
     const char *pg_role,
     const char *auth_user,
     bool case_insensitive)
{
 bool found_entry = ((bool) 0),
    error = ((bool) 0);

 if (usermap_name == ((void *)0) || usermap_name[0] == '\0')
 {
  if (case_insensitive)
  {
   if (pg_strcasecmp(pg_role, auth_user) == 0)
    return (0);
  }
  else
  {
   if (strcmp(pg_role, auth_user) == 0)
    return (0);
  }
  (errstart(15, "hba.c", 2019, __func__, ((void *)0)) ? (errfinish (errmsg("provided user name (%s) and authenticated user name (%s) do not match", pg_role, auth_user))) : (void) 0);


  return (-1);
 }
 else
 {
  ListCell *line_cell,
       *num_cell;

  for ((line_cell) = list_head(ident_lines), (num_cell) = list_head(ident_line_nums); (line_cell) != ((void *)0) && (num_cell) != ((void *)0); (line_cell) = ((line_cell)->next), (num_cell) = ((num_cell)->next))
  {
   parse_ident_usermap(((line_cell)->data.ptr_value), ((num_cell)->data.int_value),
        usermap_name, pg_role, auth_user, case_insensitive,
        &found_entry, &error);
   if (found_entry || error)
    break;
  }
 }
 if (!found_entry && !error)
 {
  (errstart(15, "hba.c", 2040, __func__, ((void *)0)) ? (errfinish (errmsg("no match in usermap \"%s\" for user \"%s\" authenticated as \"%s\"", usermap_name, pg_role, auth_user))) : (void) 0);


 }
 return found_entry ? (0) : (-1);
}
# 2052 "hba.c"
void
load_ident(void)
{
 FILE *file;

 if (ident_context != ((void *)0))
 {
  MemoryContextDelete(ident_context);
  ident_context = ((void *)0);
 }

 file = AllocateFile(IdentFileName, "r");
 if (file == ((void *)0))
 {

  (errstart(15, "hba.c", 2070, __func__, ((void *)0)) ? (errfinish (errcode_for_file_access(), errmsg("could not open usermap file \"%s\": %m", IdentFileName))) : (void) 0);



 }
 else
 {
  ident_context = tokenize_file(IdentFileName, file, &ident_lines,
           &ident_line_nums);
  FreeFile(file);
 }
}
# 2090 "hba.c"
void
hba_getauthmethod(hbaPort *port)
{
 check_hba(port);
}

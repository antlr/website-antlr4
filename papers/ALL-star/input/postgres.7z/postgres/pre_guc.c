# 1 "guc.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "guc.c"
# 17 "guc.c"
# 1 "postgres.h" 1
# 47 "postgres.h"
# 1 "c.h" 1
# 53 "c.h"
# 1 "pg_config.h" 1
# 54 "c.h" 2
# 1 "pg_config_manual.h" 1
# 55 "c.h" 2


# 1 "pg_config_os.h" 1
# 58 "c.h" 2

# 1 "postgres_ext.h" 1
# 29 "postgres_ext.h"
typedef unsigned int Oid;
# 60 "c.h" 2







# 1 "/usr/include/stdio.h" 1 3 4
# 64 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/sys/cdefs.h" 1 3 4
# 417 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 418 "/usr/include/sys/cdefs.h" 2 3 4
# 494 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_posix_availability.h" 1 3 4
# 495 "/usr/include/sys/cdefs.h" 2 3 4
# 65 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/Availability.h" 1 3 4
# 141 "/usr/include/Availability.h" 3 4
# 1 "/usr/include/AvailabilityInternal.h" 1 3 4
# 142 "/usr/include/Availability.h" 2 3 4
# 66 "/usr/include/stdio.h" 2 3 4

# 1 "/usr/include/_types.h" 1 3 4
# 27 "/usr/include/_types.h" 3 4
# 1 "/usr/include/sys/_types.h" 1 3 4
# 33 "/usr/include/sys/_types.h" 3 4
# 1 "/usr/include/machine/_types.h" 1 3 4
# 32 "/usr/include/machine/_types.h" 3 4
# 1 "/usr/include/i386/_types.h" 1 3 4
# 37 "/usr/include/i386/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 70 "/usr/include/i386/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;


typedef long int __darwin_ptrdiff_t;





typedef long unsigned int __darwin_size_t;





typedef __builtin_va_list __darwin_va_list;





typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 33 "/usr/include/machine/_types.h" 2 3 4
# 34 "/usr/include/sys/_types.h" 2 3 4
# 58 "/usr/include/sys/_types.h" 3 4
struct __darwin_pthread_handler_rec
{
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};
struct _opaque_pthread_attr_t { long __sig; char __opaque[56]; };
struct _opaque_pthread_cond_t { long __sig; char __opaque[40]; };
struct _opaque_pthread_condattr_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_mutex_t { long __sig; char __opaque[56]; };
struct _opaque_pthread_mutexattr_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_once_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_rwlock_t { long __sig; char __opaque[192]; };
struct _opaque_pthread_rwlockattr_t { long __sig; char __opaque[16]; };
struct _opaque_pthread_t { long __sig; struct __darwin_pthread_handler_rec *__cleanup_stack; char __opaque[1168]; };
# 94 "/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef struct _opaque_pthread_attr_t
   __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t
   __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t
   __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t
   __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t
   __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t
   __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t
   __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t
   __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t
   *__darwin_pthread_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];
# 28 "/usr/include/_types.h" 2 3 4
# 39 "/usr/include/_types.h" 3 4
typedef int __darwin_nl_item;
typedef int __darwin_wctrans_t;

typedef __uint32_t __darwin_wctype_t;
# 68 "/usr/include/stdio.h" 2 3 4





typedef __darwin_va_list va_list;




typedef __darwin_size_t size_t;






typedef __darwin_off_t fpos_t;
# 96 "/usr/include/stdio.h" 3 4
struct __sbuf {
 unsigned char *_base;
 int _size;
};


struct __sFILEX;
# 130 "/usr/include/stdio.h" 3 4
typedef struct __sFILE {
 unsigned char *_p;
 int _r;
 int _w;
 short _flags;
 short _file;
 struct __sbuf _bf;
 int _lbfsize;


 void *_cookie;
 int (*_close)(void *);
 int (*_read) (void *, char *, int);
 fpos_t (*_seek) (void *, fpos_t, int);
 int (*_write)(void *, const char *, int);


 struct __sbuf _ub;
 struct __sFILEX *_extra;
 int _ur;


 unsigned char _ubuf[3];
 unsigned char _nbuf[1];


 struct __sbuf _lb;


 int _blksize;
 fpos_t _offset;
} FILE;


extern FILE *__stdinp;
extern FILE *__stdoutp;
extern FILE *__stderrp;

# 238 "/usr/include/stdio.h" 3 4

void clearerr(FILE *);
int fclose(FILE *);
int feof(FILE *);
int ferror(FILE *);
int fflush(FILE *);
int fgetc(FILE *);
int fgetpos(FILE * , fpos_t *);
char *fgets(char * , int, FILE *);



FILE *fopen(const char * , const char * ) __asm("_" "fopen" );

int fprintf(FILE * , const char * , ...) __attribute__((__format__ (__printf__, 2, 3)));
int fputc(int, FILE *);
int fputs(const char * , FILE * ) __asm("_" "fputs" );
size_t fread(void * , size_t, size_t, FILE * );
FILE *freopen(const char * , const char * ,
                 FILE * ) __asm("_" "freopen" );
int fscanf(FILE * , const char * , ...) __attribute__((__format__ (__scanf__, 2, 3)));
int fseek(FILE *, long, int);
int fsetpos(FILE *, const fpos_t *);
long ftell(FILE *);
size_t fwrite(const void * , size_t, size_t, FILE * ) __asm("_" "fwrite" );
int getc(FILE *);
int getchar(void);
char *gets(char *);
void perror(const char *);
int printf(const char * , ...) __attribute__((__format__ (__printf__, 1, 2)));
int putc(int, FILE *);
int putchar(int);
int puts(const char *);
int remove(const char *);
int rename (const char *, const char *);
void rewind(FILE *);
int scanf(const char * , ...) __attribute__((__format__ (__scanf__, 1, 2)));
void setbuf(FILE * , char * );
int setvbuf(FILE * , char * , int, size_t);
int sprintf(char * , const char * , ...) __attribute__((__format__ (__printf__, 2, 3)));
int sscanf(const char * , const char * , ...) __attribute__((__format__ (__scanf__, 2, 3)));
FILE *tmpfile(void);
char *tmpnam(char *);
int ungetc(int, FILE *);
int vfprintf(FILE * , const char * , va_list) __attribute__((__format__ (__printf__, 2, 0)));
int vprintf(const char * , va_list) __attribute__((__format__ (__printf__, 1, 0)));
int vsprintf(char * , const char * , va_list) __attribute__((__format__ (__printf__, 2, 0)));

# 296 "/usr/include/stdio.h" 3 4




char *ctermid(char *);





FILE *fdopen(int, const char *) __asm("_" "fdopen" );

int fileno(FILE *);

# 318 "/usr/include/stdio.h" 3 4

int pclose(FILE *);



FILE *popen(const char *, const char *) __asm("_" "popen" );


# 340 "/usr/include/stdio.h" 3 4

int __srget(FILE *);
int __svfscanf(FILE *, const char *, va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int __swbuf(int, FILE *);








static __inline int __sputc(int _c, FILE *_p) {
 if (--_p->_w >= 0 || (_p->_w >= _p->_lbfsize && (char)_c != '\n'))
  return (*_p->_p++ = _c);
 else
  return (__swbuf(_c, _p));
}
# 377 "/usr/include/stdio.h" 3 4

void flockfile(FILE *);
int ftrylockfile(FILE *);
void funlockfile(FILE *);
int getc_unlocked(FILE *);
int getchar_unlocked(void);
int putc_unlocked(int, FILE *);
int putchar_unlocked(int);



int getw(FILE *);
int putw(int, FILE *);


char *tempnam(const char *, const char *) __asm("_" "tempnam" );

# 414 "/usr/include/stdio.h" 3 4
typedef __darwin_off_t off_t;



int fseeko(FILE *, off_t, int);
off_t ftello(FILE *);





int snprintf(char * , size_t, const char * , ...) __attribute__((__format__ (__printf__, 3, 4)));
int vfscanf(FILE * , const char * , va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int vscanf(const char * , va_list) __attribute__((__format__ (__scanf__, 1, 0)));
int vsnprintf(char * , size_t, const char * , va_list) __attribute__((__format__ (__printf__, 3, 0)));
int vsscanf(const char * , const char * , va_list) __attribute__((__format__ (__scanf__, 2, 0)));

# 442 "/usr/include/stdio.h" 3 4
typedef __darwin_ssize_t ssize_t;



int dprintf(int, const char * , ...) __attribute__((__format__ (__printf__, 2, 3))) __attribute__((visibility("default")));
int vdprintf(int, const char * , va_list) __attribute__((__format__ (__printf__, 2, 0))) __attribute__((visibility("default")));
ssize_t getdelim(char ** , size_t * , int, FILE * ) __attribute__((visibility("default")));
ssize_t getline(char ** , size_t * , FILE * ) __attribute__((visibility("default")));









extern const int sys_nerr;
extern const char *const sys_errlist[];

int asprintf(char **, const char *, ...) __attribute__((__format__ (__printf__, 2, 3)));
char *ctermid_r(char *);
char *fgetln(FILE *, size_t *);
const char *fmtcheck(const char *, const char *);
int fpurge(FILE *);
void setbuffer(FILE *, char *, int);
int setlinebuf(FILE *);
int vasprintf(char **, const char *, va_list) __attribute__((__format__ (__printf__, 2, 0)));
FILE *zopen(const char *, const char *, int);





FILE *funopen(const void *,
                 int (*)(void *, char *, int),
                 int (*)(void *, const char *, int),
                 fpos_t (*)(void *, fpos_t, int),
                 int (*)(void *));

# 499 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/secure/_stdio.h" 1 3 4
# 31 "/usr/include/secure/_stdio.h" 3 4
# 1 "/usr/include/secure/_common.h" 1 3 4
# 32 "/usr/include/secure/_stdio.h" 2 3 4
# 45 "/usr/include/secure/_stdio.h" 3 4
extern int __sprintf_chk (char * , int, size_t,
     const char * , ...)
  ;




extern int __snprintf_chk (char * , size_t, int, size_t,
      const char * , ...)
  ;





extern int __vsprintf_chk (char * , int, size_t,
      const char * , va_list)
  ;




extern int __vsnprintf_chk (char * , size_t, int, size_t,
       const char * , va_list)
  ;
# 500 "/usr/include/stdio.h" 2 3 4
# 68 "c.h" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 65 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/sys/wait.h" 1 3 4
# 79 "/usr/include/sys/wait.h" 3 4
typedef enum {
 P_ALL,
 P_PID,
 P_PGID
} idtype_t;






typedef __darwin_pid_t pid_t;




typedef __darwin_id_t id_t;
# 116 "/usr/include/sys/wait.h" 3 4
# 1 "/usr/include/sys/signal.h" 1 3 4
# 73 "/usr/include/sys/signal.h" 3 4
# 1 "/usr/include/sys/appleapiopts.h" 1 3 4
# 74 "/usr/include/sys/signal.h" 2 3 4







# 1 "/usr/include/machine/signal.h" 1 3 4
# 32 "/usr/include/machine/signal.h" 3 4
# 1 "/usr/include/i386/signal.h" 1 3 4
# 39 "/usr/include/i386/signal.h" 3 4
typedef int sig_atomic_t;
# 55 "/usr/include/i386/signal.h" 3 4
# 1 "/usr/include/i386/_structs.h" 1 3 4
# 56 "/usr/include/i386/signal.h" 2 3 4
# 33 "/usr/include/machine/signal.h" 2 3 4
# 82 "/usr/include/sys/signal.h" 2 3 4
# 148 "/usr/include/sys/signal.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 57 "/usr/include/sys/_structs.h" 3 4
# 1 "/usr/include/machine/_structs.h" 1 3 4
# 29 "/usr/include/machine/_structs.h" 3 4
# 1 "/usr/include/i386/_structs.h" 1 3 4
# 38 "/usr/include/i386/_structs.h" 3 4
# 1 "/usr/include/mach/i386/_structs.h" 1 3 4
# 43 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_thread_state
{
    unsigned int __eax;
    unsigned int __ebx;
    unsigned int __ecx;
    unsigned int __edx;
    unsigned int __edi;
    unsigned int __esi;
    unsigned int __ebp;
    unsigned int __esp;
    unsigned int __ss;
    unsigned int __eflags;
    unsigned int __eip;
    unsigned int __cs;
    unsigned int __ds;
    unsigned int __es;
    unsigned int __fs;
    unsigned int __gs;
};
# 89 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_fp_control
{
    unsigned short __invalid :1,
        __denorm :1,
    __zdiv :1,
    __ovrfl :1,
    __undfl :1,
    __precis :1,
      :2,
    __pc :2,





    __rc :2,






             :1,
      :3;
};
typedef struct __darwin_fp_control __darwin_fp_control_t;
# 147 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_fp_status
{
    unsigned short __invalid :1,
        __denorm :1,
    __zdiv :1,
    __ovrfl :1,
    __undfl :1,
    __precis :1,
    __stkflt :1,
    __errsumm :1,
    __c0 :1,
    __c1 :1,
    __c2 :1,
    __tos :3,
    __c3 :1,
    __busy :1;
};
typedef struct __darwin_fp_status __darwin_fp_status_t;
# 191 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_mmst_reg
{
 char __mmst_reg[10];
 char __mmst_rsrv[6];
};
# 210 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_xmm_reg
{
 char __xmm_reg[16];
};
# 232 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_float_state
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;
 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;
 __uint16_t __fpu_rsrv2;
 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;
 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 char __fpu_rsrv4[14*16];
 int __fpu_reserved1;
};


struct __darwin_i386_avx_state
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;
 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;
 __uint16_t __fpu_rsrv2;
 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;
 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 char __fpu_rsrv4[14*16];
 int __fpu_reserved1;
 char __avx_reserved1[64];
 struct __darwin_xmm_reg __fpu_ymmh0;
 struct __darwin_xmm_reg __fpu_ymmh1;
 struct __darwin_xmm_reg __fpu_ymmh2;
 struct __darwin_xmm_reg __fpu_ymmh3;
 struct __darwin_xmm_reg __fpu_ymmh4;
 struct __darwin_xmm_reg __fpu_ymmh5;
 struct __darwin_xmm_reg __fpu_ymmh6;
 struct __darwin_xmm_reg __fpu_ymmh7;
};
# 402 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_exception_state
{
 __uint16_t __trapno;
 __uint16_t __cpu;
 __uint32_t __err;
 __uint32_t __faultvaddr;
};
# 422 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_debug_state32
{
 unsigned int __dr0;
 unsigned int __dr1;
 unsigned int __dr2;
 unsigned int __dr3;
 unsigned int __dr4;
 unsigned int __dr5;
 unsigned int __dr6;
 unsigned int __dr7;
};
# 454 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_thread_state64
{
 __uint64_t __rax;
 __uint64_t __rbx;
 __uint64_t __rcx;
 __uint64_t __rdx;
 __uint64_t __rdi;
 __uint64_t __rsi;
 __uint64_t __rbp;
 __uint64_t __rsp;
 __uint64_t __r8;
 __uint64_t __r9;
 __uint64_t __r10;
 __uint64_t __r11;
 __uint64_t __r12;
 __uint64_t __r13;
 __uint64_t __r14;
 __uint64_t __r15;
 __uint64_t __rip;
 __uint64_t __rflags;
 __uint64_t __cs;
 __uint64_t __fs;
 __uint64_t __gs;
};
# 509 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_float_state64
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;


 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;

 __uint16_t __fpu_rsrv2;


 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;

 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 struct __darwin_xmm_reg __fpu_xmm8;
 struct __darwin_xmm_reg __fpu_xmm9;
 struct __darwin_xmm_reg __fpu_xmm10;
 struct __darwin_xmm_reg __fpu_xmm11;
 struct __darwin_xmm_reg __fpu_xmm12;
 struct __darwin_xmm_reg __fpu_xmm13;
 struct __darwin_xmm_reg __fpu_xmm14;
 struct __darwin_xmm_reg __fpu_xmm15;
 char __fpu_rsrv4[6*16];
 int __fpu_reserved1;
};


struct __darwin_x86_avx_state64
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;


 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;

 __uint16_t __fpu_rsrv2;


 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;

 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 struct __darwin_xmm_reg __fpu_xmm8;
 struct __darwin_xmm_reg __fpu_xmm9;
 struct __darwin_xmm_reg __fpu_xmm10;
 struct __darwin_xmm_reg __fpu_xmm11;
 struct __darwin_xmm_reg __fpu_xmm12;
 struct __darwin_xmm_reg __fpu_xmm13;
 struct __darwin_xmm_reg __fpu_xmm14;
 struct __darwin_xmm_reg __fpu_xmm15;
 char __fpu_rsrv4[6*16];
 int __fpu_reserved1;
 char __avx_reserved1[64];
 struct __darwin_xmm_reg __fpu_ymmh0;
 struct __darwin_xmm_reg __fpu_ymmh1;
 struct __darwin_xmm_reg __fpu_ymmh2;
 struct __darwin_xmm_reg __fpu_ymmh3;
 struct __darwin_xmm_reg __fpu_ymmh4;
 struct __darwin_xmm_reg __fpu_ymmh5;
 struct __darwin_xmm_reg __fpu_ymmh6;
 struct __darwin_xmm_reg __fpu_ymmh7;
 struct __darwin_xmm_reg __fpu_ymmh8;
 struct __darwin_xmm_reg __fpu_ymmh9;
 struct __darwin_xmm_reg __fpu_ymmh10;
 struct __darwin_xmm_reg __fpu_ymmh11;
 struct __darwin_xmm_reg __fpu_ymmh12;
 struct __darwin_xmm_reg __fpu_ymmh13;
 struct __darwin_xmm_reg __fpu_ymmh14;
 struct __darwin_xmm_reg __fpu_ymmh15;
};
# 751 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_exception_state64
{
    __uint16_t __trapno;
    __uint16_t __cpu;
    __uint32_t __err;
    __uint64_t __faultvaddr;
};
# 771 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_debug_state64
{
 __uint64_t __dr0;
 __uint64_t __dr1;
 __uint64_t __dr2;
 __uint64_t __dr3;
 __uint64_t __dr4;
 __uint64_t __dr5;
 __uint64_t __dr6;
 __uint64_t __dr7;
};
# 39 "/usr/include/i386/_structs.h" 2 3 4
# 48 "/usr/include/i386/_structs.h" 3 4
struct __darwin_mcontext32
{
 struct __darwin_i386_exception_state __es;
 struct __darwin_i386_thread_state __ss;
 struct __darwin_i386_float_state __fs;
};


struct __darwin_mcontext_avx32
{
 struct __darwin_i386_exception_state __es;
 struct __darwin_i386_thread_state __ss;
 struct __darwin_i386_avx_state __fs;
};
# 86 "/usr/include/i386/_structs.h" 3 4
struct __darwin_mcontext64
{
 struct __darwin_x86_exception_state64 __es;
 struct __darwin_x86_thread_state64 __ss;
 struct __darwin_x86_float_state64 __fs;
};


struct __darwin_mcontext_avx64
{
 struct __darwin_x86_exception_state64 __es;
 struct __darwin_x86_thread_state64 __ss;
 struct __darwin_x86_avx_state64 __fs;
};
# 127 "/usr/include/i386/_structs.h" 3 4
typedef struct __darwin_mcontext64 *mcontext_t;
# 30 "/usr/include/machine/_structs.h" 2 3 4
# 58 "/usr/include/sys/_structs.h" 2 3 4
# 75 "/usr/include/sys/_structs.h" 3 4
struct __darwin_sigaltstack
{
 void *ss_sp;
 __darwin_size_t ss_size;
 int ss_flags;
};
# 128 "/usr/include/sys/_structs.h" 3 4
struct __darwin_ucontext
{
 int uc_onstack;
 __darwin_sigset_t uc_sigmask;
 struct __darwin_sigaltstack uc_stack;
 struct __darwin_ucontext *uc_link;
 __darwin_size_t uc_mcsize;
 struct __darwin_mcontext64 *uc_mcontext;



};
# 218 "/usr/include/sys/_structs.h" 3 4
typedef struct __darwin_sigaltstack stack_t;
# 227 "/usr/include/sys/_structs.h" 3 4
typedef struct __darwin_ucontext ucontext_t;
# 149 "/usr/include/sys/signal.h" 2 3 4
# 157 "/usr/include/sys/signal.h" 3 4
typedef __darwin_pthread_attr_t pthread_attr_t;




typedef __darwin_sigset_t sigset_t;
# 172 "/usr/include/sys/signal.h" 3 4
typedef __darwin_uid_t uid_t;


union sigval {

 int sival_int;
 void *sival_ptr;
};





struct sigevent {
 int sigev_notify;
 int sigev_signo;
 union sigval sigev_value;
 void (*sigev_notify_function)(union sigval);
 pthread_attr_t *sigev_notify_attributes;
};


typedef struct __siginfo {
 int si_signo;
 int si_errno;
 int si_code;
 pid_t si_pid;
 uid_t si_uid;
 int si_status;
 void *si_addr;
 union sigval si_value;
 long si_band;
 unsigned long __pad[7];
} siginfo_t;
# 286 "/usr/include/sys/signal.h" 3 4
union __sigaction_u {
 void (*__sa_handler)(int);
 void (*__sa_sigaction)(int, struct __siginfo *,
         void *);
};


struct __sigaction {
 union __sigaction_u __sigaction_u;
 void (*sa_tramp)(void *, int, int, siginfo_t *, void *);
 sigset_t sa_mask;
 int sa_flags;
};




struct sigaction {
 union __sigaction_u __sigaction_u;
 sigset_t sa_mask;
 int sa_flags;
};
# 348 "/usr/include/sys/signal.h" 3 4
typedef void (*sig_t)(int);
# 365 "/usr/include/sys/signal.h" 3 4
struct sigvec {
 void (*sv_handler)(int);
 int sv_mask;
 int sv_flags;
};
# 384 "/usr/include/sys/signal.h" 3 4
struct sigstack {
 char *ss_sp;
 int ss_onstack;
};
# 406 "/usr/include/sys/signal.h" 3 4

void (*signal(int, void (*)(int)))(int);

# 117 "/usr/include/sys/wait.h" 2 3 4
# 1 "/usr/include/sys/resource.h" 1 3 4
# 77 "/usr/include/sys/resource.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 100 "/usr/include/sys/_structs.h" 3 4
struct timeval
{
 __darwin_time_t tv_sec;
 __darwin_suseconds_t tv_usec;
};
# 78 "/usr/include/sys/resource.h" 2 3 4
# 89 "/usr/include/sys/resource.h" 3 4
typedef __uint64_t rlim_t;
# 151 "/usr/include/sys/resource.h" 3 4
struct rusage {
 struct timeval ru_utime;
 struct timeval ru_stime;
# 162 "/usr/include/sys/resource.h" 3 4
 long ru_maxrss;

 long ru_ixrss;
 long ru_idrss;
 long ru_isrss;
 long ru_minflt;
 long ru_majflt;
 long ru_nswap;
 long ru_inblock;
 long ru_oublock;
 long ru_msgsnd;
 long ru_msgrcv;
 long ru_nsignals;
 long ru_nvcsw;
 long ru_nivcsw;


};
# 222 "/usr/include/sys/resource.h" 3 4
struct rlimit {
 rlim_t rlim_cur;
 rlim_t rlim_max;
};
# 244 "/usr/include/sys/resource.h" 3 4

int getpriority(int, id_t);

int getiopolicy_np(int, int) __attribute__((visibility("default")));

int getrlimit(int, struct rlimit *) __asm("_" "getrlimit" );
int getrusage(int, struct rusage *);
int setpriority(int, id_t, int);

int setiopolicy_np(int, int, int) __attribute__((visibility("default")));

int setrlimit(int, const struct rlimit *) __asm("_" "setrlimit" );

# 118 "/usr/include/sys/wait.h" 2 3 4
# 193 "/usr/include/sys/wait.h" 3 4
# 1 "/usr/include/machine/endian.h" 1 3 4
# 35 "/usr/include/machine/endian.h" 3 4
# 1 "/usr/include/i386/endian.h" 1 3 4
# 99 "/usr/include/i386/endian.h" 3 4
# 1 "/usr/include/sys/_endian.h" 1 3 4
# 124 "/usr/include/sys/_endian.h" 3 4
# 1 "/usr/include/libkern/_OSByteOrder.h" 1 3 4
# 66 "/usr/include/libkern/_OSByteOrder.h" 3 4
# 1 "/usr/include/libkern/i386/_OSByteOrder.h" 1 3 4
# 44 "/usr/include/libkern/i386/_OSByteOrder.h" 3 4
static __inline__
__uint16_t
_OSSwapInt16(
    __uint16_t _data
)
{
    return ((_data << 8) | (_data >> 8));
}

static __inline__
__uint32_t
_OSSwapInt32(
    __uint32_t _data
)
{

    return __builtin_bswap32(_data);




}


static __inline__
__uint64_t
_OSSwapInt64(
    __uint64_t _data
)
{
    return __builtin_bswap64(_data);
}
# 67 "/usr/include/libkern/_OSByteOrder.h" 2 3 4
# 125 "/usr/include/sys/_endian.h" 2 3 4
# 100 "/usr/include/i386/endian.h" 2 3 4
# 36 "/usr/include/machine/endian.h" 2 3 4
# 194 "/usr/include/sys/wait.h" 2 3 4







union wait {
 int w_status;



 struct {

  unsigned int w_Termsig:7,
    w_Coredump:1,
    w_Retcode:8,
    w_Filler:16;







 } w_T;





 struct {

  unsigned int w_Stopval:8,
    w_Stopsig:8,
    w_Filler:16;






 } w_S;
};
# 254 "/usr/include/sys/wait.h" 3 4

pid_t wait(int *) __asm("_" "wait" );
pid_t waitpid(pid_t, int *, int) __asm("_" "waitpid" );

int waitid(idtype_t, id_t, siginfo_t *, int) __asm("_" "waitid" );


pid_t wait3(int *, int, struct rusage *);
pid_t wait4(pid_t, int *, int, struct rusage *);


# 66 "/usr/include/stdlib.h" 2 3 4

# 1 "/usr/include/alloca.h" 1 3 4
# 35 "/usr/include/alloca.h" 3 4

void *alloca(size_t);

# 68 "/usr/include/stdlib.h" 2 3 4
# 81 "/usr/include/stdlib.h" 3 4
typedef __darwin_ct_rune_t ct_rune_t;




typedef __darwin_rune_t rune_t;






typedef __darwin_wchar_t wchar_t;



typedef struct {
 int quot;
 int rem;
} div_t;

typedef struct {
 long quot;
 long rem;
} ldiv_t;


typedef struct {
 long long quot;
 long long rem;
} lldiv_t;
# 134 "/usr/include/stdlib.h" 3 4
extern int __mb_cur_max;
# 144 "/usr/include/stdlib.h" 3 4

void abort(void) __attribute__((__noreturn__));
int abs(int) __attribute__((__const__));
int atexit(void (*)(void));
double atof(const char *);
int atoi(const char *);
long atol(const char *);

long long
  atoll(const char *);

void *bsearch(const void *, const void *, size_t,
     size_t, int (*)(const void *, const void *));
void *calloc(size_t, size_t);
div_t div(int, int) __attribute__((__const__));
void exit(int) __attribute__((__noreturn__));
void free(void *);
char *getenv(const char *);
long labs(long) __attribute__((__const__));
ldiv_t ldiv(long, long) __attribute__((__const__));

long long
  llabs(long long);
lldiv_t lldiv(long long, long long);

void *malloc(size_t);
int mblen(const char *, size_t);
size_t mbstowcs(wchar_t * , const char * , size_t);
int mbtowc(wchar_t * , const char * , size_t);
int posix_memalign(void **, size_t, size_t) __attribute__((visibility("default")));
void qsort(void *, size_t, size_t,
     int (*)(const void *, const void *));
int rand(void);
void *realloc(void *, size_t);
void srand(unsigned);
double strtod(const char *, char **) __asm("_" "strtod" );
float strtof(const char *, char **) __asm("_" "strtof" );
long strtol(const char *, char **, int);
long double
  strtold(const char *, char **) ;

long long
  strtoll(const char *, char **, int);

unsigned long
  strtoul(const char *, char **, int);

unsigned long long
  strtoull(const char *, char **, int);

int system(const char *) __asm("_" "system" );
size_t wcstombs(char * , const wchar_t * , size_t);
int wctomb(char *, wchar_t);


void _Exit(int) __attribute__((__noreturn__));
long a64l(const char *);
double drand48(void);
char *ecvt(double, int, int *, int *);
double erand48(unsigned short[3]);
char *fcvt(double, int, int *, int *);
char *gcvt(double, int, char *);
int getsubopt(char **, char * const *, char **);
int grantpt(int);

char *initstate(unsigned, char *, size_t);



long jrand48(unsigned short[3]);
char *l64a(long);
void lcong48(unsigned short[7]);
long lrand48(void);
char *mktemp(char *);
int mkstemp(char *);
long mrand48(void);
long nrand48(unsigned short[3]);
int posix_openpt(int);
char *ptsname(int);
int putenv(char *) __asm("_" "putenv" );
long random(void);
int rand_r(unsigned *);

char *realpath(const char * , char * ) __asm("_" "realpath" "$DARWIN_EXTSN");



unsigned short
 *seed48(unsigned short[3]);
int setenv(const char *, const char *, int) __asm("_" "setenv" );

void setkey(const char *) __asm("_" "setkey" );



char *setstate(const char *);
void srand48(long);

void srandom(unsigned);



int unlockpt(int);

int unsetenv(const char *) __asm("_" "unsetenv" );






# 1 "/usr/include/machine/types.h" 1 3 4
# 35 "/usr/include/machine/types.h" 3 4
# 1 "/usr/include/i386/types.h" 1 3 4
# 70 "/usr/include/i386/types.h" 3 4
# 1 "/usr/include/i386/_types.h" 1 3 4
# 71 "/usr/include/i386/types.h" 2 3 4







typedef signed char int8_t;

typedef unsigned char u_int8_t;


typedef short int16_t;

typedef unsigned short u_int16_t;


typedef int int32_t;

typedef unsigned int u_int32_t;


typedef long long int64_t;

typedef unsigned long long u_int64_t;


typedef int64_t register_t;






typedef __darwin_intptr_t intptr_t;



typedef unsigned long uintptr_t;




typedef u_int64_t user_addr_t;
typedef u_int64_t user_size_t;
typedef int64_t user_ssize_t;
typedef int64_t user_long_t;
typedef u_int64_t user_ulong_t;
typedef int64_t user_time_t;
typedef int64_t user_off_t;







typedef u_int64_t syscall_arg_t;
# 36 "/usr/include/machine/types.h" 2 3 4
# 256 "/usr/include/stdlib.h" 2 3 4


typedef __darwin_dev_t dev_t;




typedef __darwin_mode_t mode_t;



u_int32_t
  arc4random(void);
void arc4random_addrandom(unsigned char * , int );
void arc4random_buf(void * , size_t ) __attribute__((visibility("default")));
void arc4random_stir(void);
u_int32_t
  arc4random_uniform(u_int32_t ) __attribute__((visibility("default")));

int atexit_b(void (^)(void)) __attribute__((visibility("default")));
void *bsearch_b(const void *, const void *, size_t,
     size_t, int (^)(const void *, const void *)) __attribute__((visibility("default")));



char *cgetcap(char *, const char *, int);
int cgetclose(void);
int cgetent(char **, char **, const char *);
int cgetfirst(char **, char **);
int cgetmatch(const char *, const char *);
int cgetnext(char **, char **);
int cgetnum(char *, const char *, long *);
int cgetset(const char *);
int cgetstr(char *, const char *, char **);
int cgetustr(char *, const char *, char **);

int daemon(int, int) __asm("_" "daemon" "$1050") __attribute__((deprecated,visibility("default")));
char *devname(dev_t, mode_t);
char *devname_r(dev_t, mode_t, char *buf, int len);
char *getbsize(int *, long *);
int getloadavg(double [], int);
const char
 *getprogname(void);

int heapsort(void *, size_t, size_t,
     int (*)(const void *, const void *));

int heapsort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

int mergesort(void *, size_t, size_t,
     int (*)(const void *, const void *));

int mergesort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void psort(void *, size_t, size_t,
     int (*)(const void *, const void *)) __attribute__((visibility("default")));

void psort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void psort_r(void *, size_t, size_t, void *,
     int (*)(void *, const void *, const void *)) __attribute__((visibility("default")));

void qsort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void qsort_r(void *, size_t, size_t, void *,
     int (*)(void *, const void *, const void *));
int radixsort(const unsigned char **, int, const unsigned char *,
     unsigned);
void setprogname(const char *);
int sradixsort(const unsigned char **, int, const unsigned char *,
     unsigned);
void sranddev(void);
void srandomdev(void);
void *reallocf(void *, size_t);

long long
  strtoq(const char *, char **, int);
unsigned long long
  strtouq(const char *, char **, int);

extern char *suboptarg;
void *valloc(size_t);







# 69 "c.h" 2
# 1 "/usr/include/string.h" 1 3 4
# 79 "/usr/include/string.h" 3 4

void *memchr(const void *, int, size_t);
int memcmp(const void *, const void *, size_t);
void *memcpy(void *, const void *, size_t);
void *memmove(void *, const void *, size_t);
void *memset(void *, int, size_t);
char *strcat(char *, const char *);
char *strchr(const char *, int);
int strcmp(const char *, const char *);
int strcoll(const char *, const char *);
char *strcpy(char *, const char *);
size_t strcspn(const char *, const char *);
char *strerror(int) __asm("_" "strerror" );
size_t strlen(const char *);
char *strncat(char *, const char *, size_t);
int strncmp(const char *, const char *, size_t);
char *strncpy(char *, const char *, size_t);
char *strpbrk(const char *, const char *);
char *strrchr(const char *, int);
size_t strspn(const char *, const char *);
char *strstr(const char *, const char *);
char *strtok(char *, const char *);
size_t strxfrm(char *, const char *, size_t);

# 113 "/usr/include/string.h" 3 4

char *strtok_r(char *, const char *, char **);

# 125 "/usr/include/string.h" 3 4

int strerror_r(int, char *, size_t);
char *strdup(const char *);
void *memccpy(void *, const void *, int, size_t);

# 139 "/usr/include/string.h" 3 4

char *stpcpy(char *, const char *);
char *stpncpy(char *, const char *, size_t) __attribute__((visibility("default")));
char *strndup(const char *, size_t) __attribute__((visibility("default")));
size_t strnlen(const char *, size_t) __attribute__((visibility("default")));
char *strsignal(int sig);

# 158 "/usr/include/string.h" 3 4

void *memmem(const void *, size_t, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern4(void *, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern8(void *, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern16(void *, const void *, size_t) __attribute__((visibility("default")));

char *strcasestr(const char *, const char *);
char *strnstr(const char *, const char *, size_t);
size_t strlcat(char *, const char *, size_t);
size_t strlcpy(char *, const char *, size_t);
void strmode(int, char *);
char *strsep(char **, const char *);


void swab(const void * , void * , ssize_t);







# 1 "/usr/include/strings.h" 1 3 4
# 71 "/usr/include/strings.h" 3 4



int bcmp(const void *, const void *, size_t) ;
void bcopy(const void *, void *, size_t) ;
void bzero(void *, size_t) ;
char *index(const char *, int) ;
char *rindex(const char *, int) ;


int ffs(int);
int strcasecmp(const char *, const char *);
int strncasecmp(const char *, const char *, size_t);





int ffsl(long) __attribute__((visibility("default")));
int fls(int) __attribute__((visibility("default")));
int flsl(long) __attribute__((visibility("default")));


# 1 "/usr/include/string.h" 1 3 4
# 95 "/usr/include/strings.h" 2 3 4
# 181 "/usr/include/string.h" 2 3 4
# 190 "/usr/include/string.h" 3 4
# 1 "/usr/include/secure/_string.h" 1 3 4
# 58 "/usr/include/secure/_string.h" 3 4
static __inline void *
__inline_memcpy_chk (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memcpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 0));
}






static __inline void *
__inline_memmove_chk (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memmove_chk (__dest, __src, __len, __builtin_object_size (__dest, 0));
}






static __inline void *
__inline_memset_chk (void *__dest, int __val, size_t __len)
{
  return __builtin___memset_chk (__dest, __val, __len, __builtin_object_size (__dest, 0));
}






static __inline char *
__inline_strcpy_chk (char * __dest, const char * __src)
{
  return __builtin___strcpy_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_stpcpy_chk (char *__dest, const char *__src)
{
  return __builtin___stpcpy_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}






static __inline char *
__inline_stpncpy_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___stpncpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_strncpy_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___strncpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}






static __inline char *
__inline_strcat_chk (char * __dest, const char * __src)
{
  return __builtin___strcat_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_strncat_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___strncat_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}
# 191 "/usr/include/string.h" 2 3 4
# 70 "c.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stddef.h" 1 3 4
# 152 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 71 "c.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stdarg.h" 1 3 4
# 43 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 72 "c.h" 2

# 1 "./strings.h" 1
char *s1,
     *s2,
     *s3,
     *s4,
     *s5,
     *s6;
# 74 "c.h" 2


# 1 "/usr/include/stdint.h" 1 3 4
# 40 "/usr/include/stdint.h" 3 4
typedef unsigned char uint8_t;




typedef unsigned short uint16_t;




typedef unsigned int uint32_t;




typedef unsigned long long uint64_t;



typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;
# 97 "/usr/include/stdint.h" 3 4
typedef long int intmax_t;
# 106 "/usr/include/stdint.h" 3 4
typedef long unsigned int uintmax_t;
# 77 "c.h" 2

# 1 "/usr/include/sys/types.h" 1 3 4
# 84 "/usr/include/sys/types.h" 3 4
typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned int u_int;

typedef unsigned long u_long;


typedef unsigned short ushort;
typedef unsigned int uint;


typedef u_int64_t u_quad_t;
typedef int64_t quad_t;
typedef quad_t * qaddr_t;

typedef char * caddr_t;
typedef int32_t daddr_t;






typedef u_int32_t fixpt_t;


typedef __darwin_blkcnt_t blkcnt_t;




typedef __darwin_blksize_t blksize_t;




typedef __darwin_gid_t gid_t;





typedef __uint32_t in_addr_t;




typedef __uint16_t in_port_t;



typedef __darwin_ino_t ino_t;





typedef __darwin_ino64_t ino64_t;






typedef __int32_t key_t;
# 157 "/usr/include/sys/types.h" 3 4
typedef __uint16_t nlink_t;
# 176 "/usr/include/sys/types.h" 3 4
typedef int32_t segsz_t;
typedef int32_t swblk_t;
# 223 "/usr/include/sys/types.h" 3 4
typedef __darwin_clock_t clock_t;
# 240 "/usr/include/sys/types.h" 3 4
typedef __darwin_time_t time_t;




typedef __darwin_useconds_t useconds_t;




typedef __darwin_suseconds_t suseconds_t;
# 260 "/usr/include/sys/types.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 183 "/usr/include/sys/_structs.h" 3 4

typedef struct fd_set {
 __int32_t fds_bits[((((1024) % ((sizeof(__int32_t) * 8))) == 0) ? ((1024) / ((sizeof(__int32_t) * 8))) : (((1024) / ((sizeof(__int32_t) * 8))) + 1))];
} fd_set;



static __inline int
__darwin_fd_isset(int _n, const struct fd_set *_p)
{
 return (_p->fds_bits[_n/(sizeof(__int32_t) * 8)] & (1<<(_n % (sizeof(__int32_t) * 8))));
}
# 261 "/usr/include/sys/types.h" 2 3 4




typedef __int32_t fd_mask;
# 322 "/usr/include/sys/types.h" 3 4
typedef __darwin_pthread_cond_t pthread_cond_t;



typedef __darwin_pthread_condattr_t pthread_condattr_t;



typedef __darwin_pthread_mutex_t pthread_mutex_t;



typedef __darwin_pthread_mutexattr_t pthread_mutexattr_t;



typedef __darwin_pthread_once_t pthread_once_t;



typedef __darwin_pthread_rwlock_t pthread_rwlock_t;



typedef __darwin_pthread_rwlockattr_t pthread_rwlockattr_t;



typedef __darwin_pthread_t pthread_t;






typedef __darwin_pthread_key_t pthread_key_t;





typedef __darwin_fsblkcnt_t fsblkcnt_t;




typedef __darwin_fsfilcnt_t fsfilcnt_t;
# 79 "c.h" 2

# 1 "/usr/include/errno.h" 1 3 4
# 23 "/usr/include/errno.h" 3 4
# 1 "/usr/include/sys/errno.h" 1 3 4
# 74 "/usr/include/sys/errno.h" 3 4

extern int * __error(void);


# 24 "/usr/include/errno.h" 2 3 4
# 81 "c.h" 2
# 91 "c.h"
# 1 "/usr/include/locale.h" 1 3 4
# 40 "/usr/include/locale.h" 3 4
# 1 "/usr/include/_locale.h" 1 3 4
# 43 "/usr/include/_locale.h" 3 4
struct lconv {
 char *decimal_point;
 char *thousands_sep;
 char *grouping;
 char *int_curr_symbol;
 char *currency_symbol;
 char *mon_decimal_point;
 char *mon_thousands_sep;
 char *mon_grouping;
 char *positive_sign;
 char *negative_sign;
 char int_frac_digits;
 char frac_digits;
 char p_cs_precedes;
 char p_sep_by_space;
 char n_cs_precedes;
 char n_sep_by_space;
 char p_sign_posn;
 char n_sign_posn;
 char int_p_cs_precedes;
 char int_n_cs_precedes;
 char int_p_sep_by_space;
 char int_n_sep_by_space;
 char int_p_sign_posn;
 char int_n_sign_posn;
};






struct lconv *localeconv(void);

# 41 "/usr/include/locale.h" 2 3 4
# 52 "/usr/include/locale.h" 3 4

char *setlocale(int, const char *);

# 92 "c.h" 2
# 181 "c.h"
typedef char bool;
# 193 "c.h"
typedef bool *BoolPtr;
# 224 "c.h"
typedef char *Pointer;
# 233 "c.h"
typedef signed char int8;
typedef signed short int16;
typedef signed int int32;
# 245 "c.h"
typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;






typedef uint8 bits8;
typedef uint16 bits16;
typedef uint32 bits32;
# 265 "c.h"
typedef long int int64;


typedef unsigned long int uint64;
# 308 "c.h"
typedef size_t Size;
# 317 "c.h"
typedef unsigned int Index;
# 327 "c.h"
typedef signed int Offset;




typedef int16 int2;
typedef int32 int4;
typedef float float4;
typedef double float8;
# 348 "c.h"
typedef Oid regproc;
typedef regproc RegProcedure;

typedef uint32 TransactionId;

typedef uint32 LocalTransactionId;

typedef uint32 SubTransactionId;





typedef TransactionId MultiXactId;

typedef uint32 MultiXactOffset;

typedef uint32 CommandId;







typedef struct
{
 int indx[6];
} IntArray;
# 391 "c.h"
struct varlena
{
 char vl_len_[4];
 char vl_dat[1];
};
# 404 "c.h"
typedef struct varlena bytea;
typedef struct varlena text;
typedef struct varlena BpChar;
typedef struct varlena VarChar;
# 419 "c.h"
typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
 int dim1;
 int lbound1;
 int2 values[1];
} int2vector;

typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
 int dim1;
 int lbound1;
 Oid values[1];
} oidvector;





typedef struct nameData
{
 char data[64];
} NameData;
typedef NameData *Name;
# 829 "c.h"
extern int fdatasync(int fildes);
# 860 "c.h"
# 1 "port.h" 1
# 16 "port.h"
# 1 "/usr/include/ctype.h" 1 3 4
# 69 "/usr/include/ctype.h" 3 4
# 1 "/usr/include/runetype.h" 1 3 4
# 70 "/usr/include/runetype.h" 3 4
typedef __darwin_wint_t wint_t;
# 81 "/usr/include/runetype.h" 3 4
typedef struct {
 __darwin_rune_t __min;
 __darwin_rune_t __max;
 __darwin_rune_t __map;
 __uint32_t *__types;
} _RuneEntry;

typedef struct {
 int __nranges;
 _RuneEntry *__ranges;
} _RuneRange;

typedef struct {
 char __name[14];
 __uint32_t __mask;
} _RuneCharClass;

typedef struct {
 char __magic[8];
 char __encoding[32];

 __darwin_rune_t (*__sgetrune)(const char *, __darwin_size_t, char const **);
 int (*__sputrune)(__darwin_rune_t, char *, __darwin_size_t, char **);
 __darwin_rune_t __invalid_rune;

 __uint32_t __runetype[(1 <<8 )];
 __darwin_rune_t __maplower[(1 <<8 )];
 __darwin_rune_t __mapupper[(1 <<8 )];






 _RuneRange __runetype_ext;
 _RuneRange __maplower_ext;
 _RuneRange __mapupper_ext;

 void *__variable;
 int __variable_len;




 int __ncharclasses;
 _RuneCharClass *__charclasses;
} _RuneLocale;




extern _RuneLocale _DefaultRuneLocale;
extern _RuneLocale *_CurrentRuneLocale;

# 70 "/usr/include/ctype.h" 2 3 4
# 145 "/usr/include/ctype.h" 3 4

unsigned long ___runetype(__darwin_ct_rune_t);
__darwin_ct_rune_t ___tolower(__darwin_ct_rune_t);
__darwin_ct_rune_t ___toupper(__darwin_ct_rune_t);


static __inline int
isascii(int _c)
{
 return ((_c & ~0x7F) == 0);
}
# 164 "/usr/include/ctype.h" 3 4

int __maskrune(__darwin_ct_rune_t, unsigned long);



static __inline int
__istype(__darwin_ct_rune_t _c, unsigned long _f)
{



 return (isascii(_c) ? !!(_DefaultRuneLocale.__runetype[_c] & _f)
  : !!__maskrune(_c, _f));

}

static __inline __darwin_ct_rune_t
__isctype(__darwin_ct_rune_t _c, unsigned long _f)
{



 return (_c < 0 || _c >= (1 <<8 )) ? 0 :
  !!(_DefaultRuneLocale.__runetype[_c] & _f);

}
# 204 "/usr/include/ctype.h" 3 4

__darwin_ct_rune_t __toupper(__darwin_ct_rune_t);
__darwin_ct_rune_t __tolower(__darwin_ct_rune_t);



static __inline int
__wcwidth(__darwin_ct_rune_t _c)
{
 unsigned int _x;

 if (_c == 0)
  return (0);
 _x = (unsigned int)__maskrune(_c, 0xe0000000L|0x00040000L);
 if ((_x & 0xe0000000L) != 0)
  return ((_x & 0xe0000000L) >> 30);
 return ((_x & 0x00040000L) != 0 ? 1 : -1);
}






static __inline int
isalnum(int _c)
{
 return (__istype(_c, 0x00000100L|0x00000400L));
}

static __inline int
isalpha(int _c)
{
 return (__istype(_c, 0x00000100L));
}

static __inline int
isblank(int _c)
{
 return (__istype(_c, 0x00020000L));
}

static __inline int
iscntrl(int _c)
{
 return (__istype(_c, 0x00000200L));
}


static __inline int
isdigit(int _c)
{
 return (__isctype(_c, 0x00000400L));
}

static __inline int
isgraph(int _c)
{
 return (__istype(_c, 0x00000800L));
}

static __inline int
islower(int _c)
{
 return (__istype(_c, 0x00001000L));
}

static __inline int
isprint(int _c)
{
 return (__istype(_c, 0x00040000L));
}

static __inline int
ispunct(int _c)
{
 return (__istype(_c, 0x00002000L));
}

static __inline int
isspace(int _c)
{
 return (__istype(_c, 0x00004000L));
}

static __inline int
isupper(int _c)
{
 return (__istype(_c, 0x00008000L));
}


static __inline int
isxdigit(int _c)
{
 return (__isctype(_c, 0x00010000L));
}

static __inline int
toascii(int _c)
{
 return (_c & 0x7F);
}

static __inline int
tolower(int _c)
{
        return (__tolower(_c));
}

static __inline int
toupper(int _c)
{
        return (__toupper(_c));
}


static __inline int
digittoint(int _c)
{
 return (__maskrune(_c, 0x0F));
}

static __inline int
ishexnumber(int _c)
{
 return (__istype(_c, 0x00010000L));
}

static __inline int
isideogram(int _c)
{
 return (__istype(_c, 0x00080000L));
}

static __inline int
isnumber(int _c)
{
 return (__istype(_c, 0x00000400L));
}

static __inline int
isphonogram(int _c)
{
 return (__istype(_c, 0x00200000L));
}

static __inline int
isrune(int _c)
{
 return (__istype(_c, 0xFFFFFFF0L));
}

static __inline int
isspecial(int _c)
{
 return (__istype(_c, 0x00100000L));
}
# 17 "port.h" 2
# 1 "./netdb.h" 1
# 18 "port.h" 2
# 1 "./pwd.h" 1
# 19 "port.h" 2



typedef int pgsocket;
# 32 "port.h"
extern bool pg_set_noblock(pgsocket sock);
extern bool pg_set_block(pgsocket sock);



extern bool has_drive_prefix(const char *filename);
extern char *first_dir_separator(const char *filename);
extern char *last_dir_separator(const char *filename);
extern char *first_path_var_separator(const char *pathlist);
extern void join_path_components(char *ret_path,
      const char *head, const char *tail);
extern void canonicalize_path(char *path);
extern void make_native_path(char *path);
extern bool path_contains_parent_reference(const char *path);
extern bool path_is_relative_and_below_cwd(const char *path);
extern bool path_is_prefix_of_path(const char *path1, const char *path2);
extern const char *get_progname(const char *argv0);
extern void get_share_path(const char *my_exec_path, char *ret_path);
extern void get_etc_path(const char *my_exec_path, char *ret_path);
extern void get_include_path(const char *my_exec_path, char *ret_path);
extern void get_pkginclude_path(const char *my_exec_path, char *ret_path);
extern void get_includeserver_path(const char *my_exec_path, char *ret_path);
extern void get_lib_path(const char *my_exec_path, char *ret_path);
extern void get_pkglib_path(const char *my_exec_path, char *ret_path);
extern void get_locale_path(const char *my_exec_path, char *ret_path);
extern void get_doc_path(const char *my_exec_path, char *ret_path);
extern void get_html_path(const char *my_exec_path, char *ret_path);
extern void get_man_path(const char *my_exec_path, char *ret_path);
extern bool get_home_path(char *ret_path);
extern void get_parent_directory(char *path);


extern char **pgfnames(const char *path);
extern void pgfnames_cleanup(char **filenames);
# 92 "port.h"
extern void set_pglocale_pgservice(const char *argv0, const char *app);


extern int find_my_exec(const char *argv0, char *retpath);
extern int find_other_exec(const char *argv0, const char *target,
    const char *versionstr, char *retpath);
# 149 "port.h"
extern void pg_usleep(long microsec);


extern int pg_strcasecmp(const char *s1, const char *s2);
extern int pg_strncasecmp(const char *s1, const char *s2, size_t n);
extern unsigned char pg_toupper(unsigned char ch);
extern unsigned char pg_tolower(unsigned char ch);
extern unsigned char pg_ascii_toupper(unsigned char ch);
extern unsigned char pg_ascii_tolower(unsigned char ch);
# 247 "port.h"
extern char *simple_prompt(const char *prompt, int maxlen, bool echo);







extern int pclose_check(FILE *stream);
# 300 "port.h"
extern bool rmtree(const char *path, bool rmtopdir);
# 372 "port.h"
extern double pg_erand48(unsigned short xseed[3]);
extern long pg_lrand48(void);
extern void pg_srand48(long seed);
# 428 "port.h"
extern char *pqStrerror(int errnum, char *strerrbuf, size_t buflen);


extern int pqGetpwuid(uid_t uid, struct passwd * resultbuf, char *buffer,
     size_t buflen, struct passwd ** result);


extern int pqGethostbyname(const char *name,
    struct hostent * resultbuf,
    char *buffer, size_t buflen,
    struct hostent ** result,
    int *herrno);

extern void pg_qsort(void *base, size_t nel, size_t elsize,
   int (*cmp) (const void *, const void *));



typedef int (*qsort_arg_comparator) (const void *a, const void *b, void *arg);

extern void qsort_arg(void *base, size_t nel, size_t elsize,
    qsort_arg_comparator cmp, void *arg);


extern int pg_get_encoding_from_locale(const char *ctype, bool write_message);


extern char *inet_net_ntop(int af, const void *src, int bits,
     char *dst, size_t size);


extern int pg_check_dir(const char *dir);


extern int pg_mkdir_p(char *path, int omode);
# 861 "c.h" 2
# 48 "postgres.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
# 1 "/usr/include/setjmp.h" 1 3 4
# 26 "/usr/include/setjmp.h" 3 4
# 1 "/usr/include/machine/setjmp.h" 1 3 4
# 35 "/usr/include/machine/setjmp.h" 3 4
# 1 "/usr/include/i386/setjmp.h" 1 3 4
# 47 "/usr/include/i386/setjmp.h" 3 4
typedef int jmp_buf[((9 * 2) + 3 + 16)];
typedef int sigjmp_buf[((9 * 2) + 3 + 16) + 1];
# 65 "/usr/include/i386/setjmp.h" 3 4

int setjmp(jmp_buf);
void longjmp(jmp_buf, int);


int _setjmp(jmp_buf);
void _longjmp(jmp_buf, int);
int sigsetjmp(sigjmp_buf, int);
void siglongjmp(sigjmp_buf, int);



void longjmperror(void);


# 36 "/usr/include/machine/setjmp.h" 2 3 4
# 27 "/usr/include/setjmp.h" 2 3 4
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h" 2
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/errcodes.h" 1
# 70 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h" 2
# 114 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
extern bool errstart(int elevel, const char *filename, int lineno,
   const char *funcname, const char *domain);
extern void errfinish(int dummy,...);

extern int errcode(int sqlerrcode);

extern int errcode_for_file_access(void);
extern int errcode_for_socket_access(void);

extern int
errmsg(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errmsg_internal(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errmsg_plural(const char *fmt_singular, const char *fmt_plural,
     unsigned long n,...)


__attribute__((format(printf, 1, 4)))
__attribute__((format(printf, 2, 4)));

extern int
errdetail(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errdetail_internal(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errdetail_log(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errdetail_plural(const char *fmt_singular, const char *fmt_plural,
     unsigned long n,...)


__attribute__((format(printf, 1, 4)))
__attribute__((format(printf, 2, 4)));

extern int
errhint(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int
errcontext(const char *fmt,...)


__attribute__((format(printf, 1, 2)));

extern int errhidestmt(bool hide_stmt);

extern int errfunction(const char *funcname);
extern int errposition(int cursorpos);

extern int internalerrposition(int cursorpos);
extern int internalerrquery(const char *query);

extern int geterrcode(void);
extern int geterrposition(void);
extern int getinternalerrposition(void);
# 201 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
extern void elog_start(const char *filename, int lineno, const char *funcname);
extern void
elog_finish(int elevel, const char *fmt,...)


__attribute__((format(printf, 2, 3)));




extern void pre_format_elog_string(int errnumber, const char *domain);
extern char *
format_elog_string(const char *fmt,...)


__attribute__((format(printf, 1, 2)));




typedef struct ErrorContextCallback
{
 struct ErrorContextCallback *previous;
 void (*callback) (void *arg);
 void *arg;
} ErrorContextCallback;

extern ErrorContextCallback *error_context_stack;
# 296 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
extern sigjmp_buf *PG_exception_stack;
# 307 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
typedef struct ErrorData
{
 int elevel;
 bool output_to_server;
 bool output_to_client;
 bool show_funcname;
 bool hide_stmt;
 const char *filename;
 int lineno;
 const char *funcname;
 const char *domain;
 int sqlerrcode;
 char *message;
 char *detail;
 char *detail_log;
 char *hint;
 char *context;
 int cursorpos;
 int internalpos;
 char *internalquery;
 int saved_errno;
} ErrorData;

extern void EmitErrorReport(void);
extern ErrorData *CopyErrorData(void);
extern void FreeErrorData(ErrorData *edata);
extern void FlushErrorState(void);
extern void ReThrowError(ErrorData *edata) __attribute__((noreturn));
extern void pg_re_throw(void) __attribute__((noreturn));


typedef void (*emit_log_hook_type) (ErrorData *edata);
extern emit_log_hook_type emit_log_hook;




typedef enum
{
 PGERROR_TERSE,
 PGERROR_DEFAULT,
 PGERROR_VERBOSE
} PGErrorVerbosity;

extern int Log_error_verbosity;
extern char *Log_line_prefix;
extern int Log_destination;
# 362 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/elog.h"
extern void DebugFileOpen(void);
extern char *unpack_sql_state(int sql_state);
extern bool in_error_recursion_trouble(void);


extern void set_syslog_parameters(const char *ident, int facility);







extern void
write_stderr(const char *fmt,...)


__attribute__((format(printf, 1, 2)));
# 49 "postgres.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h" 1
# 36 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h"
typedef struct MemoryContextData *MemoryContext;






extern MemoryContext CurrentMemoryContext;




extern void *MemoryContextAlloc(MemoryContext context, Size size);
extern void *MemoryContextAllocZero(MemoryContext context, Size size);
extern void *MemoryContextAllocZeroAligned(MemoryContext context, Size size);
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h"
extern void pfree(void *pointer);

extern void *repalloc(void *pointer, Size size);
# 83 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h"
static inline MemoryContext
MemoryContextSwitchTo(MemoryContext context)
{
 MemoryContext old = CurrentMemoryContext;

 CurrentMemoryContext = context;
 return old;
}
# 100 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/palloc.h"
extern char *MemoryContextStrdup(MemoryContext context, const char *string);



extern char *pnstrdup(const char *in, Size len);
# 50 "postgres.h" 2
# 67 "postgres.h"
struct varatt_external
{
 int32 va_rawsize;
 int32 va_extsize;
 Oid va_valueid;
 Oid va_toastrelid;
};
# 84 "postgres.h"
typedef union
{
 struct
 {
  uint32 va_header;
  char va_data[1];
 } va_4byte;
 struct
 {
  uint32 va_header;
  uint32 va_rawsize;
  char va_data[1];
 } va_compressed;
} varattrib_4b;

typedef struct
{
 uint8 va_header;
 char va_data[1];
} varattrib_1b;

typedef struct
{
 uint8 va_header;
 uint8 va_len_1be;
 char va_data[1];
} varattrib_1b_e;
# 302 "postgres.h"
typedef uintptr_t Datum;



typedef Datum *DatumPtr;
# 561 "postgres.h"
extern float4 DatumGetFloat4(Datum X);
# 574 "postgres.h"
extern Datum Float4GetDatum(float4 X);
# 584 "postgres.h"
extern float8 DatumGetFloat8(Datum X);
# 597 "postgres.h"
extern Datum Float8GetDatum(float8 X);
# 635 "postgres.h"
extern bool assert_enabled;
# 686 "postgres.h"
extern void ExceptionalCondition(const char *conditionName,
      const char *errorType,
    const char *fileName, int lineNumber) __attribute__((noreturn));
# 18 "guc.c" 2


# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/float.h" 1 3 4
# 21 "guc.c" 2
# 1 "/usr/include/math.h" 1 3 4
# 28 "/usr/include/math.h" 3 4
# 1 "/usr/include/architecture/i386/math.h" 1 3 4
# 49 "/usr/include/architecture/i386/math.h" 3 4
 typedef float float_t;
 typedef double double_t;
# 108 "/usr/include/architecture/i386/math.h" 3 4
extern int __math_errhandling ( void );
# 128 "/usr/include/architecture/i386/math.h" 3 4
extern int __fpclassifyf(float );
extern int __fpclassifyd(double );
extern int __fpclassify (long double);
# 163 "/usr/include/architecture/i386/math.h" 3 4
 static __inline__ int __inline_isfinitef (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isfinited (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isfinite (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_isinff (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isinfd (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isinf (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_isnanf (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnand (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnan (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_isnormalf (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnormald (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnormal (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_signbitf (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_signbitd (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_signbit (long double) __attribute__ ((always_inline));

 static __inline__ int __inline_isinff( float __x ) { return __builtin_fabsf(__x) == __builtin_inff(); }
 static __inline__ int __inline_isinfd( double __x ) { return __builtin_fabs(__x) == __builtin_inf(); }
 static __inline__ int __inline_isinf( long double __x ) { return __builtin_fabsl(__x) == __builtin_infl(); }
 static __inline__ int __inline_isfinitef( float __x ) { return __x == __x && __builtin_fabsf(__x) != __builtin_inff(); }
 static __inline__ int __inline_isfinited( double __x ) { return __x == __x && __builtin_fabs(__x) != __builtin_inf(); }
 static __inline__ int __inline_isfinite( long double __x ) { return __x == __x && __builtin_fabsl(__x) != __builtin_infl(); }
 static __inline__ int __inline_isnanf( float __x ) { return __x != __x; }
 static __inline__ int __inline_isnand( double __x ) { return __x != __x; }
 static __inline__ int __inline_isnan( long double __x ) { return __x != __x; }
 static __inline__ int __inline_signbitf( float __x ) { union{ float __f; unsigned int __u; }__u; __u.__f = __x; return (int)(__u.__u >> 31); }
 static __inline__ int __inline_signbitd( double __x ) { union{ double __f; unsigned int __u[2]; }__u; __u.__f = __x; return (int)(__u.__u[1] >> 31); }
 static __inline__ int __inline_signbit( long double __x ){ union{ long double __ld; struct{ unsigned int __m[2]; short __sexp; }__p; }__u; __u.__ld = __x; return (int) (((unsigned short) __u.__p.__sexp) >> 15); }
 static __inline__ int __inline_isnormalf( float __x ) { float fabsf = __builtin_fabsf(__x); if( __x != __x ) return 0; return fabsf < __builtin_inff() && fabsf >= 1.17549435e-38F; }
 static __inline__ int __inline_isnormald( double __x ) { double fabsf = __builtin_fabs(__x); if( __x != __x ) return 0; return fabsf < __builtin_inf() && fabsf >= 2.2250738585072014e-308; }
 static __inline__ int __inline_isnormal( long double __x ) { long double fabsf = __builtin_fabsl(__x); if( __x != __x ) return 0; return fabsf < __builtin_infl() && fabsf >= 3.36210314311209350626e-4932L; }
# 253 "/usr/include/architecture/i386/math.h" 3 4
extern double acos( double );
extern float acosf( float );

extern double asin( double );
extern float asinf( float );

extern double atan( double );
extern float atanf( float );

extern double atan2( double, double );
extern float atan2f( float, float );

extern double cos( double );
extern float cosf( float );

extern double sin( double );
extern float sinf( float );

extern double tan( double );
extern float tanf( float );

extern double acosh( double );
extern float acoshf( float );

extern double asinh( double );
extern float asinhf( float );

extern double atanh( double );
extern float atanhf( float );

extern double cosh( double );
extern float coshf( float );

extern double sinh( double );
extern float sinhf( float );

extern double tanh( double );
extern float tanhf( float );

extern double exp ( double );
extern float expf ( float );

extern double exp2 ( double );
extern float exp2f ( float );

extern double expm1 ( double );
extern float expm1f ( float );

extern double log ( double );
extern float logf ( float );

extern double log10 ( double );
extern float log10f ( float );

extern double log2 ( double );
extern float log2f ( float );

extern double log1p ( double );
extern float log1pf ( float );

extern double logb ( double );
extern float logbf ( float );

extern double modf ( double, double * );
extern float modff ( float, float * );

extern double ldexp ( double, int );
extern float ldexpf ( float, int );

extern double frexp ( double, int * );
extern float frexpf ( float, int * );

extern int ilogb ( double );
extern int ilogbf ( float );

extern double scalbn ( double, int );
extern float scalbnf ( float, int );

extern double scalbln ( double, long int );
extern float scalblnf ( float, long int );

extern double fabs( double );
extern float fabsf( float );

extern double cbrt( double );
extern float cbrtf( float );

extern double hypot ( double, double );
extern float hypotf ( float, float );

extern double pow ( double, double );
extern float powf ( float, float );

extern double sqrt( double );
extern float sqrtf( float );

extern double erf( double );
extern float erff( float );

extern double erfc( double );
extern float erfcf( float );






extern double lgamma( double );
extern float lgammaf( float );

extern double tgamma( double );
extern float tgammaf( float );

extern double ceil ( double );
extern float ceilf ( float );

extern double floor ( double );
extern float floorf ( float );

extern double nearbyint ( double );
extern float nearbyintf ( float );

extern double rint ( double );
extern float rintf ( float );

extern long int lrint ( double );
extern long int lrintf ( float );

extern double round ( double );
extern float roundf ( float );

extern long int lround ( double );
extern long int lroundf ( float );



    extern long long int llrint ( double );
    extern long long int llrintf ( float );
    extern long long int llround ( double );
    extern long long int llroundf ( float );


extern double trunc ( double );
extern float truncf ( float );

extern double fmod ( double, double );
extern float fmodf ( float, float );

extern double remainder ( double, double );
extern float remainderf ( float, float );

extern double remquo ( double, double, int * );
extern float remquof ( float, float, int * );

extern double copysign ( double, double );
extern float copysignf ( float, float );

extern double nan( const char * );
extern float nanf( const char * );

extern double nextafter ( double, double );
extern float nextafterf ( float, float );

extern double fdim ( double, double );
extern float fdimf ( float, float );

extern double fmax ( double, double );
extern float fmaxf ( float, float );

extern double fmin ( double, double );
extern float fminf ( float, float );

extern double fma ( double, double, double );
extern float fmaf ( float, float, float );

extern long double acosl(long double);
extern long double asinl(long double);
extern long double atanl(long double);
extern long double atan2l(long double, long double);
extern long double cosl(long double);
extern long double sinl(long double);
extern long double tanl(long double);
extern long double acoshl(long double);
extern long double asinhl(long double);
extern long double atanhl(long double);
extern long double coshl(long double);
extern long double sinhl(long double);
extern long double tanhl(long double);
extern long double expl(long double);
extern long double exp2l(long double);
extern long double expm1l(long double);
extern long double logl(long double);
extern long double log10l(long double);
extern long double log2l(long double);
extern long double log1pl(long double);
extern long double logbl(long double);
extern long double modfl(long double, long double *);
extern long double ldexpl(long double, int);
extern long double frexpl(long double, int *);
extern int ilogbl(long double);
extern long double scalbnl(long double, int);
extern long double scalblnl(long double, long int);
extern long double fabsl(long double);
extern long double cbrtl(long double);
extern long double hypotl(long double, long double);
extern long double powl(long double, long double);
extern long double sqrtl(long double);
extern long double erfl(long double);
extern long double erfcl(long double);






extern long double lgammal(long double);

extern long double tgammal(long double);
extern long double ceill(long double);
extern long double floorl(long double);
extern long double nearbyintl(long double);
extern long double rintl(long double);
extern long int lrintl(long double);
extern long double roundl(long double);
extern long int lroundl(long double);



    extern long long int llrintl(long double);
    extern long long int llroundl(long double);


extern long double truncl(long double);
extern long double fmodl(long double, long double);
extern long double remainderl(long double, long double);
extern long double remquol(long double, long double, int *);
extern long double copysignl(long double, long double);
extern long double nanl(const char *);
extern long double nextafterl(long double, long double);
extern double nexttoward(double, long double);
extern float nexttowardf(float, long double);
extern long double nexttowardl(long double, long double);
extern long double fdiml(long double, long double);
extern long double fmaxl(long double, long double);
extern long double fminl(long double, long double);
extern long double fmal(long double, long double, long double);
# 507 "/usr/include/architecture/i386/math.h" 3 4
extern double __inf( void );
extern float __inff( void );
extern long double __infl( void );
extern float __nan( void );


extern double j0 ( double );

extern double j1 ( double );

extern double jn ( int, double );

extern double y0 ( double );

extern double y1 ( double );

extern double yn ( int, double );

extern double scalb ( double, double );
# 543 "/usr/include/architecture/i386/math.h" 3 4
extern int signgam;
# 558 "/usr/include/architecture/i386/math.h" 3 4
extern long int rinttol ( double );


extern long int roundtol ( double );
# 570 "/usr/include/architecture/i386/math.h" 3 4
struct exception {
 int type;
 char *name;
 double arg1;
 double arg2;
 double retval;
};
# 601 "/usr/include/architecture/i386/math.h" 3 4
extern int finite ( double );


extern double gamma ( double );




extern int matherr ( struct exception * );





extern double significand ( double );






extern double drem ( double, double );
# 29 "/usr/include/math.h" 2 3 4
# 22 "guc.c" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 1 3 4






# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/syslimits.h" 1 3 4
# 8 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 2 3 4







# 1 "/usr/include/limits.h" 1 3 4
# 64 "/usr/include/limits.h" 3 4
# 1 "/usr/include/machine/limits.h" 1 3 4





# 1 "/usr/include/i386/limits.h" 1 3 4
# 40 "/usr/include/i386/limits.h" 3 4
# 1 "/usr/include/i386/_limits.h" 1 3 4
# 41 "/usr/include/i386/limits.h" 2 3 4
# 7 "/usr/include/machine/limits.h" 2 3 4
# 65 "/usr/include/limits.h" 2 3 4
# 1 "/usr/include/sys/syslimits.h" 1 3 4
# 66 "/usr/include/limits.h" 2 3 4
# 16 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 2 3 4
# 23 "guc.c" 2
# 1 "./unistd.h" 1
# 24 "guc.c" 2
# 1 "/usr/include/sys/stat.h" 1 3 4
# 79 "/usr/include/sys/stat.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 88 "/usr/include/sys/_structs.h" 3 4
struct timespec
{
 __darwin_time_t tv_sec;
 long tv_nsec;
};
# 80 "/usr/include/sys/stat.h" 2 3 4
# 153 "/usr/include/sys/stat.h" 3 4
struct ostat {
 __uint16_t st_dev;
 ino_t st_ino;
 mode_t st_mode;
 nlink_t st_nlink;
 __uint16_t st_uid;
 __uint16_t st_gid;
 __uint16_t st_rdev;
 __int32_t st_size;
 struct timespec st_atimespec;
 struct timespec st_mtimespec;
 struct timespec st_ctimespec;
 __int32_t st_blksize;
 __int32_t st_blocks;
 __uint32_t st_flags;
 __uint32_t st_gen;
};
# 225 "/usr/include/sys/stat.h" 3 4
struct stat { dev_t st_dev; mode_t st_mode; nlink_t st_nlink; __darwin_ino64_t st_ino; uid_t st_uid; gid_t st_gid; dev_t st_rdev; struct timespec st_atimespec; struct timespec st_mtimespec; struct timespec st_ctimespec; struct timespec st_birthtimespec; off_t st_size; blkcnt_t st_blocks; blksize_t st_blksize; __uint32_t st_flags; __uint32_t st_gen; __int32_t st_lspare; __int64_t st_qspare[2]; };
# 264 "/usr/include/sys/stat.h" 3 4
struct stat64 { dev_t st_dev; mode_t st_mode; nlink_t st_nlink; __darwin_ino64_t st_ino; uid_t st_uid; gid_t st_gid; dev_t st_rdev; struct timespec st_atimespec; struct timespec st_mtimespec; struct timespec st_ctimespec; struct timespec st_birthtimespec; off_t st_size; blkcnt_t st_blocks; blksize_t st_blksize; __uint32_t st_flags; __uint32_t st_gen; __int32_t st_lspare; __int64_t st_qspare[2]; };
# 428 "/usr/include/sys/stat.h" 3 4


int chmod(const char *, mode_t) __asm("_" "chmod" );
int fchmod(int, mode_t) __asm("_" "fchmod" );
int fstat(int, struct stat *) __asm("_" "fstat" "$INODE64");
int lstat(const char *, struct stat *) __asm("_" "lstat" "$INODE64");
int mkdir(const char *, mode_t);
int mkfifo(const char *, mode_t);
int stat(const char *, struct stat *) __asm("_" "stat" "$INODE64");
int mknod(const char *, mode_t, dev_t);
mode_t umask(mode_t);



struct _filesec;
typedef struct _filesec *filesec_t;


int chflags(const char *, __uint32_t);
int chmodx_np(const char *, filesec_t);
int fchflags(int, __uint32_t);
int fchmodx_np(int, filesec_t);
int fstatx_np(int, struct stat *, filesec_t) __asm("_" "fstatx_np" "$INODE64");
int lchflags(const char *, __uint32_t) __attribute__((visibility("default")));
int lchmod(const char *, mode_t) __attribute__((visibility("default")));
int lstatx_np(const char *, struct stat *, filesec_t) __asm("_" "lstatx_np" "$INODE64");
int mkdirx_np(const char *, filesec_t);
int mkfifox_np(const char *, filesec_t);
int statx_np(const char *, struct stat *, filesec_t) __asm("_" "statx_np" "$INODE64");
int umaskx_np(filesec_t) __attribute__((deprecated,visibility("default")));



int fstatx64_np(int, struct stat64 *, filesec_t) __attribute__((deprecated,visibility("default")));
int lstatx64_np(const char *, struct stat64 *, filesec_t) __attribute__((deprecated,visibility("default")));
int statx64_np(const char *, struct stat64 *, filesec_t) __attribute__((deprecated,visibility("default")));
int fstat64(int, struct stat64 *) __attribute__((deprecated,visibility("default")));
int lstat64(const char *, struct stat64 *) __attribute__((deprecated,visibility("default")));
int stat64(const char *, struct stat64 *) __attribute__((deprecated,visibility("default")));




# 25 "guc.c" 2

# 1 "/usr/include/syslog.h" 1 3 4
# 23 "/usr/include/syslog.h" 3 4
# 1 "/usr/include/sys/syslog.h" 1 3 4
# 222 "/usr/include/sys/syslog.h" 3 4

void closelog(void);
void openlog(const char *, int, int);
int setlogmask(int);
void syslog(int, const char *, ...) __attribute__((__format__ (__printf__, 2, 3))) ;

void vsyslog(int, const char *, __darwin_va_list) __attribute__((__format__ (__printf__, 2, 0))) ;


# 24 "/usr/include/syslog.h" 2 3 4
# 27 "guc.c" 2


# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/gin.h" 1
# 13 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/gin.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 1
# 14 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/rmgr.h" 1
# 11 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/rmgr.h"
typedef uint8 RmgrId;
# 15 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h" 1
# 15 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
# 1 "/usr/include/fcntl.h" 1 3 4
# 23 "/usr/include/fcntl.h" 3 4
# 1 "/usr/include/sys/fcntl.h" 1 3 4
# 339 "/usr/include/sys/fcntl.h" 3 4
struct flock {
 off_t l_start;
 off_t l_len;
 pid_t l_pid;
 short l_type;
 short l_whence;
};
# 355 "/usr/include/sys/fcntl.h" 3 4
struct radvisory {
       off_t ra_offset;
       int ra_count;
};
# 367 "/usr/include/sys/fcntl.h" 3 4
typedef struct fsignatures {
 off_t fs_file_start;
 void *fs_blob_start;
 size_t fs_blob_size;
} fsignatures_t;
# 381 "/usr/include/sys/fcntl.h" 3 4
typedef struct fstore {
 unsigned int fst_flags;
 int fst_posmode;
 off_t fst_offset;
 off_t fst_length;
 off_t fst_bytesalloc;
} fstore_t;



typedef struct fbootstraptransfer {
  off_t fbt_offset;
  size_t fbt_length;
  void *fbt_buffer;
} fbootstraptransfer_t;
# 419 "/usr/include/sys/fcntl.h" 3 4
#pragma pack(4)

struct log2phys {
 unsigned int l2p_flags;
 off_t l2p_contigbytes;


 off_t l2p_devoffset;


};

#pragma pack()
# 446 "/usr/include/sys/fcntl.h" 3 4
typedef enum {
 FILESEC_OWNER = 1,
 FILESEC_GROUP = 2,
 FILESEC_UUID = 3,
 FILESEC_MODE = 4,
 FILESEC_ACL = 5,
 FILESEC_GRPUUID = 6,


 FILESEC_ACL_RAW = 100,
 FILESEC_ACL_ALLOCSIZE = 101
} filesec_property_t;






int open(const char *, int, ...) __asm("_" "open" );
int creat(const char *, mode_t) __asm("_" "creat" );
int fcntl(int, int, ...) __asm("_" "fcntl" );


int openx_np(const char *, int, filesec_t);
int flock(int, int);
filesec_t filesec_init(void);
filesec_t filesec_dup(filesec_t);
void filesec_free(filesec_t);
int filesec_get_property(filesec_t, filesec_property_t, void *);
int filesec_query_property(filesec_t, filesec_property_t, int *);
int filesec_set_property(filesec_t, filesec_property_t, const void *);
int filesec_unset_property(filesec_t, filesec_property_t) __attribute__((visibility("default")));




# 23 "/usr/include/fcntl.h" 2 3 4
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h" 2
# 32 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
typedef struct XLogRecPtr
{
 uint32 xlogid;
 uint32 xrecoff;
} XLogRecPtr;
# 84 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h"
typedef uint32 TimeLineID;
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h"
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 1 3 4






# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/syslimits.h" 1 3 4
# 8 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 2 3 4
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h" 2
# 44 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h"
typedef int64 Timestamp;
typedef int64 TimestampTz;
typedef int64 TimeOffset;
typedef int32 fsec_t;
# 56 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h"
typedef struct
{
 TimeOffset time;

 int32 day;
 int32 month;
} Interval;
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h" 1
# 35 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
typedef struct StringInfoData
{
 char *data;
 int len;
 int maxlen;
 int cursor;
} StringInfoData;

typedef StringInfoData *StringInfo;
# 72 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
extern StringInfo makeStringInfo(void);






extern void initStringInfo(StringInfo str);






extern void resetStringInfo(StringInfo str);
# 95 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
extern void
appendStringInfo(StringInfo str, const char *fmt,...)

__attribute__((format(printf, 2, 3)));
# 108 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
extern bool
appendStringInfoVA(StringInfo str, const char *fmt, va_list args)
__attribute__((format(printf, 2, 0)));






extern void appendStringInfoString(StringInfo str, const char *s);






extern void appendStringInfoChar(StringInfo str, char ch);
# 140 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h"
extern void appendStringInfoSpaces(StringInfo str, int count);






extern void appendBinaryStringInfo(StringInfo str,
        const char *data, int datalen);





extern void enlargeStringInfo(StringInfo str, int needed);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h"
typedef int Buffer;
# 44 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h"
typedef struct BufferAccessStrategyData *BufferAccessStrategy;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/pg_crc.h" 1
# 32 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/pg_crc.h"
typedef uint32 pg_crc32;
# 57 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/pg_crc.h"
extern const uint32 pg_crc32_table[];
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 2
# 41 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
typedef struct XLogRecord
{
 pg_crc32 xl_crc;
 XLogRecPtr xl_prev;
 TransactionId xl_xid;
 uint32 xl_tot_len;
 uint32 xl_len;
 uint8 xl_info;
 RmgrId xl_rmid;





} XLogRecord;
# 88 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
extern int sync_method;
# 120 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
typedef struct XLogRecData
{
 char *data;
 uint32 len;
 Buffer buffer;
 bool buffer_std;
 struct XLogRecData *next;
} XLogRecData;

extern TimeLineID ThisTimeLineID;
# 138 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
extern bool InRecovery;
# 161 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
typedef enum
{
 STANDBY_DISABLED,
 STANDBY_INITIALIZED,
 STANDBY_SNAPSHOT_PENDING,
 STANDBY_SNAPSHOT_READY
} HotStandbyState;

extern HotStandbyState standbyState;







typedef enum
{
 RECOVERY_TARGET_UNSET,
 RECOVERY_TARGET_XID,
 RECOVERY_TARGET_TIME,
 RECOVERY_TARGET_NAME
} RecoveryTargetType;

extern XLogRecPtr XactLastRecEnd;

extern bool reachedConsistency;


extern int CheckPointSegments;
extern int wal_keep_segments;
extern int XLOGbuffers;
extern int XLogArchiveTimeout;
extern bool XLogArchiveMode;
extern char *XLogArchiveCommand;
extern bool EnableHotStandby;
extern bool fullPageWrites;
extern bool log_checkpoints;


typedef enum WalLevel
{
 WAL_LEVEL_MINIMAL = 0,
 WAL_LEVEL_ARCHIVE,
 WAL_LEVEL_HOT_STANDBY
} WalLevel;
extern int wal_level;
# 245 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h"
typedef struct CheckpointStatsData
{
 TimestampTz ckpt_start_t;
 TimestampTz ckpt_write_t;
 TimestampTz ckpt_sync_t;
 TimestampTz ckpt_sync_end_t;
 TimestampTz ckpt_end_t;

 int ckpt_bufs_written;

 int ckpt_segs_added;
 int ckpt_segs_removed;
 int ckpt_segs_recycled;

 int ckpt_sync_rels;
 uint64 ckpt_longest_sync;
 uint64 ckpt_agg_sync_time;



} CheckpointStatsData;

extern CheckpointStatsData CheckpointStats;

extern XLogRecPtr XLogInsert(RmgrId rmid, uint8 info, XLogRecData *rdata);
extern void XLogFlush(XLogRecPtr RecPtr);
extern bool XLogBackgroundFlush(void);
extern bool XLogNeedsFlush(XLogRecPtr RecPtr);
extern int XLogFileInit(uint32 log, uint32 seg,
    bool *use_existent, bool use_lock);
extern int XLogFileOpen(uint32 log, uint32 seg);


extern void CheckXLogRemoved(uint32 log, uint32 seg, TimeLineID tli);
extern void XLogSetAsyncXactLSN(XLogRecPtr record);

extern Buffer RestoreBackupBlock(XLogRecPtr lsn, XLogRecord *record,
       int block_index,
       bool get_cleanup_lock, bool keep_buffer);

extern void xlog_redo(XLogRecPtr lsn, XLogRecord *record);
extern void xlog_desc(StringInfo buf, uint8 xl_info, char *rec);

extern void issue_xlog_fsync(int fd, uint32 log, uint32 seg);

extern bool RecoveryInProgress(void);
extern bool HotStandbyActive(void);
extern bool XLogInsertAllowed(void);
extern void GetXLogReceiptTime(TimestampTz *rtime, bool *fromStream);
extern XLogRecPtr GetXLogReplayRecPtr(TimeLineID *targetTLI);
extern XLogRecPtr GetStandbyFlushRecPtr(TimeLineID *targetTLI);
extern XLogRecPtr GetXLogInsertRecPtr(void);
extern XLogRecPtr GetXLogWriteRecPtr(void);
extern bool RecoveryIsPaused(void);
extern void SetRecoveryPause(bool recoveryPause);
extern TimestampTz GetLatestXTime(void);
extern TimestampTz GetCurrentChunkReplayStartTime(void);

extern void UpdateControlFile(void);
extern uint64 GetSystemIdentifier(void);
extern Size XLOGShmemSize(void);
extern void XLOGShmemInit(void);
extern void BootStrapXLOG(void);
extern void StartupXLOG(void);
extern void ShutdownXLOG(int code, Datum arg);
extern void InitXLOGAccess(void);
extern void CreateCheckPoint(int flags);
extern bool CreateRestartPoint(int flags);
extern void XLogPutNextOid(Oid nextOid);
extern XLogRecPtr XLogRestorePoint(const char *rpName);
extern void UpdateFullPageWrites(void);
extern XLogRecPtr GetRedoRecPtr(void);
extern XLogRecPtr GetInsertRecPtr(void);
extern XLogRecPtr GetFlushRecPtr(void);
extern void GetNextXidAndEpoch(TransactionId *xid, uint32 *epoch);
extern TimeLineID GetRecoveryTargetTLI(void);

extern bool CheckPromoteSignal(void);
extern void WakeupRecovery(void);
extern void SetWalWriterSleeping(bool sleeping);




extern XLogRecPtr do_pg_start_backup(const char *backupidstr, bool fast, char **labelfile);
extern XLogRecPtr do_pg_stop_backup(char *labelfile, bool waitforarchive);
extern void do_pg_abort_backup(void);
# 14 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/gin.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h" 1
# 31 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h"
typedef uint32 BlockNumber;
# 53 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h"
typedef struct BlockIdData
{
 uint16 bi_hi;
 uint16 bi_lo;
} BlockIdData;

typedef BlockIdData *BlockId;
# 15 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/gin.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h"
typedef int16 AttrNumber;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/genbki.h" 1
# 49 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/genbki.h"
typedef int aclitem;
typedef int pg_node_tree;
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h" 2
# 36 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
typedef struct FormData_pg_attribute
{
 Oid attrelid;
 NameData attname;
# 48 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 Oid atttypid;
# 57 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int4 attstattarget;





 int2 attlen;
# 78 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int2 attnum;





 int4 attndims;
# 93 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 int4 attcacheoff;







 int4 atttypmod;





 bool attbyval;
# 122 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
 char attstorage;





 char attalign;


 bool attnotnull;


 bool atthasdef;


 bool attisdropped;


 bool attislocal;


 int4 attinhcount;


 Oid attcollation;
# 160 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
} FormData_pg_attribute;
# 176 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_attribute.h"
typedef FormData_pg_attribute *Form_pg_attribute;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 1
# 40 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h" 1
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum NodeTag
{
 T_Invalid = 0,




 T_IndexInfo = 10,
 T_ExprContext,
 T_ProjectionInfo,
 T_JunkFilter,
 T_ResultRelInfo,
 T_EState,
 T_TupleTableSlot,




 T_Plan = 100,
 T_Result,
 T_ModifyTable,
 T_Append,
 T_MergeAppend,
 T_RecursiveUnion,
 T_BitmapAnd,
 T_BitmapOr,
 T_Scan,
 T_SeqScan,
 T_IndexScan,
 T_IndexOnlyScan,
 T_BitmapIndexScan,
 T_BitmapHeapScan,
 T_TidScan,
 T_SubqueryScan,
 T_FunctionScan,
 T_ValuesScan,
 T_CteScan,
 T_WorkTableScan,
 T_ForeignScan,
 T_Join,
 T_NestLoop,
 T_MergeJoin,
 T_HashJoin,
 T_Material,
 T_Sort,
 T_Group,
 T_Agg,
 T_WindowAgg,
 T_Unique,
 T_Hash,
 T_SetOp,
 T_LockRows,
 T_Limit,

 T_NestLoopParam,
 T_PlanRowMark,
 T_PlanInvalItem,






 T_PlanState = 200,
 T_ResultState,
 T_ModifyTableState,
 T_AppendState,
 T_MergeAppendState,
 T_RecursiveUnionState,
 T_BitmapAndState,
 T_BitmapOrState,
 T_ScanState,
 T_SeqScanState,
 T_IndexScanState,
 T_IndexOnlyScanState,
 T_BitmapIndexScanState,
 T_BitmapHeapScanState,
 T_TidScanState,
 T_SubqueryScanState,
 T_FunctionScanState,
 T_ValuesScanState,
 T_CteScanState,
 T_WorkTableScanState,
 T_ForeignScanState,
 T_JoinState,
 T_NestLoopState,
 T_MergeJoinState,
 T_HashJoinState,
 T_MaterialState,
 T_SortState,
 T_GroupState,
 T_AggState,
 T_WindowAggState,
 T_UniqueState,
 T_HashState,
 T_SetOpState,
 T_LockRowsState,
 T_LimitState,




 T_Alias = 300,
 T_RangeVar,
 T_Expr,
 T_Var,
 T_Const,
 T_Param,
 T_Aggref,
 T_WindowFunc,
 T_ArrayRef,
 T_FuncExpr,
 T_NamedArgExpr,
 T_OpExpr,
 T_DistinctExpr,
 T_NullIfExpr,
 T_ScalarArrayOpExpr,
 T_BoolExpr,
 T_SubLink,
 T_SubPlan,
 T_AlternativeSubPlan,
 T_FieldSelect,
 T_FieldStore,
 T_RelabelType,
 T_CoerceViaIO,
 T_ArrayCoerceExpr,
 T_ConvertRowtypeExpr,
 T_CollateExpr,
 T_CaseExpr,
 T_CaseWhen,
 T_CaseTestExpr,
 T_ArrayExpr,
 T_RowExpr,
 T_RowCompareExpr,
 T_CoalesceExpr,
 T_MinMaxExpr,
 T_XmlExpr,
 T_NullTest,
 T_BooleanTest,
 T_CoerceToDomain,
 T_CoerceToDomainValue,
 T_SetToDefault,
 T_CurrentOfExpr,
 T_TargetEntry,
 T_RangeTblRef,
 T_JoinExpr,
 T_FromExpr,
 T_IntoClause,







 T_ExprState = 400,
 T_GenericExprState,
 T_AggrefExprState,
 T_WindowFuncExprState,
 T_ArrayRefExprState,
 T_FuncExprState,
 T_ScalarArrayOpExprState,
 T_BoolExprState,
 T_SubPlanState,
 T_AlternativeSubPlanState,
 T_FieldSelectState,
 T_FieldStoreState,
 T_CoerceViaIOState,
 T_ArrayCoerceExprState,
 T_ConvertRowtypeExprState,
 T_CaseExprState,
 T_CaseWhenState,
 T_ArrayExprState,
 T_RowExprState,
 T_RowCompareExprState,
 T_CoalesceExprState,
 T_MinMaxExprState,
 T_XmlExprState,
 T_NullTestState,
 T_CoerceToDomainState,
 T_DomainConstraintState,
 T_WholeRowVarExprState,




 T_PlannerInfo = 500,
 T_PlannerGlobal,
 T_RelOptInfo,
 T_IndexOptInfo,
 T_ParamPathInfo,
 T_Path,
 T_IndexPath,
 T_BitmapHeapPath,
 T_BitmapAndPath,
 T_BitmapOrPath,
 T_NestPath,
 T_MergePath,
 T_HashPath,
 T_TidPath,
 T_ForeignPath,
 T_AppendPath,
 T_MergeAppendPath,
 T_ResultPath,
 T_MaterialPath,
 T_UniquePath,
 T_EquivalenceClass,
 T_EquivalenceMember,
 T_PathKey,
 T_RestrictInfo,
 T_PlaceHolderVar,
 T_SpecialJoinInfo,
 T_AppendRelInfo,
 T_PlaceHolderInfo,
 T_MinMaxAggInfo,
 T_PlannerParamItem,




 T_MemoryContext = 600,
 T_AllocSetContext,




 T_Value = 650,
 T_Integer,
 T_Float,
 T_String,
 T_BitString,
 T_Null,




 T_List,
 T_IntList,
 T_OidList,




 T_Query = 700,
 T_PlannedStmt,
 T_InsertStmt,
 T_DeleteStmt,
 T_UpdateStmt,
 T_SelectStmt,
 T_AlterTableStmt,
 T_AlterTableCmd,
 T_AlterDomainStmt,
 T_SetOperationStmt,
 T_GrantStmt,
 T_GrantRoleStmt,
 T_AlterDefaultPrivilegesStmt,
 T_ClosePortalStmt,
 T_ClusterStmt,
 T_CopyStmt,
 T_CreateStmt,
 T_DefineStmt,
 T_DropStmt,
 T_TruncateStmt,
 T_CommentStmt,
 T_FetchStmt,
 T_IndexStmt,
 T_CreateFunctionStmt,
 T_AlterFunctionStmt,
 T_DoStmt,
 T_RenameStmt,
 T_RuleStmt,
 T_NotifyStmt,
 T_ListenStmt,
 T_UnlistenStmt,
 T_TransactionStmt,
 T_ViewStmt,
 T_LoadStmt,
 T_CreateDomainStmt,
 T_CreatedbStmt,
 T_DropdbStmt,
 T_VacuumStmt,
 T_ExplainStmt,
 T_CreateTableAsStmt,
 T_CreateSeqStmt,
 T_AlterSeqStmt,
 T_VariableSetStmt,
 T_VariableShowStmt,
 T_DiscardStmt,
 T_CreateTrigStmt,
 T_CreatePLangStmt,
 T_CreateRoleStmt,
 T_AlterRoleStmt,
 T_DropRoleStmt,
 T_LockStmt,
 T_ConstraintsSetStmt,
 T_ReindexStmt,
 T_CheckPointStmt,
 T_CreateSchemaStmt,
 T_AlterDatabaseStmt,
 T_AlterDatabaseSetStmt,
 T_AlterRoleSetStmt,
 T_CreateConversionStmt,
 T_CreateCastStmt,
 T_CreateOpClassStmt,
 T_CreateOpFamilyStmt,
 T_AlterOpFamilyStmt,
 T_PrepareStmt,
 T_ExecuteStmt,
 T_DeallocateStmt,
 T_DeclareCursorStmt,
 T_CreateTableSpaceStmt,
 T_DropTableSpaceStmt,
 T_AlterObjectSchemaStmt,
 T_AlterOwnerStmt,
 T_DropOwnedStmt,
 T_ReassignOwnedStmt,
 T_CompositeTypeStmt,
 T_CreateEnumStmt,
 T_CreateRangeStmt,
 T_AlterEnumStmt,
 T_AlterTSDictionaryStmt,
 T_AlterTSConfigurationStmt,
 T_CreateFdwStmt,
 T_AlterFdwStmt,
 T_CreateForeignServerStmt,
 T_AlterForeignServerStmt,
 T_CreateUserMappingStmt,
 T_AlterUserMappingStmt,
 T_DropUserMappingStmt,
 T_AlterTableSpaceOptionsStmt,
 T_SecLabelStmt,
 T_CreateForeignTableStmt,
 T_CreateExtensionStmt,
 T_AlterExtensionStmt,
 T_AlterExtensionContentsStmt,




 T_A_Expr = 900,
 T_ColumnRef,
 T_ParamRef,
 T_A_Const,
 T_FuncCall,
 T_A_Star,
 T_A_Indices,
 T_A_Indirection,
 T_A_ArrayExpr,
 T_ResTarget,
 T_TypeCast,
 T_CollateClause,
 T_SortBy,
 T_WindowDef,
 T_RangeSubselect,
 T_RangeFunction,
 T_TypeName,
 T_ColumnDef,
 T_IndexElem,
 T_Constraint,
 T_DefElem,
 T_RangeTblEntry,
 T_SortGroupClause,
 T_WindowClause,
 T_PrivGrantee,
 T_FuncWithArgs,
 T_AccessPriv,
 T_CreateOpClassItem,
 T_TableLikeClause,
 T_FunctionParameter,
 T_LockingClause,
 T_RowMarkClause,
 T_XmlSerialize,
 T_WithClause,
 T_CommonTableExpr,




 T_IdentifySystemCmd,
 T_BaseBackupCmd,
 T_StartReplicationCmd,
# 416 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
 T_TriggerData = 950,
 T_ReturnSetInfo,
 T_WindowObjectData,
 T_TIDBitmap,
 T_InlineCodeBlock,
 T_FdwRoutine
} NodeTag;







typedef struct Node
{
 NodeTag type;
} Node;
# 491 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
extern char *nodeToString(const void *obj);




extern void *stringToNode(char *str);




extern void *copyObject(const void *obj);




extern bool equal(const void *a, const void *b);
# 517 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef double Selectivity;
typedef double Cost;
# 527 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum CmdType
{
 CMD_UNKNOWN,
 CMD_SELECT,
 CMD_UPDATE,
 CMD_INSERT,
 CMD_DELETE,
 CMD_UTILITY,

 CMD_NOTHING

} CmdType;
# 551 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
typedef enum JoinType
{




 JOIN_INNER,
 JOIN_LEFT,
 JOIN_FULL,
 JOIN_RIGHT,
# 571 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h"
 JOIN_SEMI,
 JOIN_ANTI,





 JOIN_UNIQUE_OUTER,
 JOIN_UNIQUE_INNER




} JoinType;
# 41 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 2


typedef struct ListCell ListCell;

typedef struct List
{
 NodeTag type;
 int length;
 ListCell *head;
 ListCell *tail;
} List;

struct ListCell
{
 union
 {
  void *ptr_value;
  int int_value;
  Oid oid_value;
 } data;
 ListCell *next;
};
# 79 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
static inline ListCell *
list_head(const List *l)
{
 return l ? l->head : ((void *)0);
}

static inline ListCell *
list_tail(List *l)
{
 return l ? l->tail : ((void *)0);
}

static inline int
list_length(const List *l)
{
 return l ? l->length : 0;
}
# 194 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h"
extern List *lappend(List *list, void *datum);
extern List *lappend_int(List *list, int datum);
extern List *lappend_oid(List *list, Oid datum);

extern ListCell *lappend_cell(List *list, ListCell *prev, void *datum);
extern ListCell *lappend_cell_int(List *list, ListCell *prev, int datum);
extern ListCell *lappend_cell_oid(List *list, ListCell *prev, Oid datum);

extern List *lcons(void *datum, List *list);
extern List *lcons_int(int datum, List *list);
extern List *lcons_oid(Oid datum, List *list);

extern List *list_concat(List *list1, List *list2);
extern List *list_truncate(List *list, int new_size);

extern void *list_nth(const List *list, int n);
extern int list_nth_int(const List *list, int n);
extern Oid list_nth_oid(const List *list, int n);

extern bool list_member(const List *list, const void *datum);
extern bool list_member_ptr(const List *list, const void *datum);
extern bool list_member_int(const List *list, int datum);
extern bool list_member_oid(const List *list, Oid datum);

extern List *list_delete(List *list, void *datum);
extern List *list_delete_ptr(List *list, void *datum);
extern List *list_delete_int(List *list, int datum);
extern List *list_delete_oid(List *list, Oid datum);
extern List *list_delete_first(List *list);
extern List *list_delete_cell(List *list, ListCell *cell, ListCell *prev);

extern List *list_union(const List *list1, const List *list2);
extern List *list_union_ptr(const List *list1, const List *list2);
extern List *list_union_int(const List *list1, const List *list2);
extern List *list_union_oid(const List *list1, const List *list2);

extern List *list_intersection(const List *list1, const List *list2);



extern List *list_difference(const List *list1, const List *list2);
extern List *list_difference_ptr(const List *list1, const List *list2);
extern List *list_difference_int(const List *list1, const List *list2);
extern List *list_difference_oid(const List *list1, const List *list2);

extern List *list_append_unique(List *list, void *datum);
extern List *list_append_unique_ptr(List *list, void *datum);
extern List *list_append_unique_int(List *list, int datum);
extern List *list_append_unique_oid(List *list, Oid datum);

extern List *list_concat_unique(List *list1, List *list2);
extern List *list_concat_unique_ptr(List *list1, List *list2);
extern List *list_concat_unique_int(List *list1, List *list2);
extern List *list_concat_unique_oid(List *list1, List *list2);

extern void list_free(List *list);
extern void list_free_deep(List *list);

extern List *list_copy(const List *list);
extern List *list_copy_tail(const List *list, int nskip);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 2


typedef struct attrDefault
{
 AttrNumber adnum;
 char *adbin;
} AttrDefault;

typedef struct constrCheck
{
 char *ccname;
 char *ccbin;
 bool ccvalid;
 bool ccnoinherit;
} ConstrCheck;


typedef struct tupleConstr
{
 AttrDefault *defval;
 ConstrCheck *check;
 uint16 num_defval;
 uint16 num_check;
 bool has_not_null;
} TupleConstr;
# 71 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
typedef struct tupleDesc
{
 int natts;
 Form_pg_attribute *attrs;

 TupleConstr *constr;
 Oid tdtypeid;
 int32 tdtypmod;
 bool tdhasoid;
 int tdrefcount;
} *TupleDesc;


extern TupleDesc CreateTemplateTupleDesc(int natts, bool hasoid);

extern TupleDesc CreateTupleDesc(int natts, bool hasoid,
    Form_pg_attribute *attrs);

extern TupleDesc CreateTupleDescCopy(TupleDesc tupdesc);

extern TupleDesc CreateTupleDescCopyConstr(TupleDesc tupdesc);

extern void FreeTupleDesc(TupleDesc tupdesc);

extern void IncrTupleDescRefCount(TupleDesc tupdesc);
extern void DecrTupleDescRefCount(TupleDesc tupdesc);
# 110 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h"
extern bool equalTupleDescs(TupleDesc tupdesc1, TupleDesc tupdesc2);

extern void TupleDescInitEntry(TupleDesc desc,
       AttrNumber attributeNumber,
       const char *attributeName,
       Oid oidtypeid,
       int32 typmod,
       int attdim);

extern void TupleDescInitEntryCollation(TupleDesc desc,
       AttrNumber attributeNumber,
       Oid collationid);

extern TupleDesc BuildDescForRelation(List *schema);

extern TupleDesc BuildDescFromLists(List *names, List *types, List *typmods, List *collations);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/bitmapset.h" 1
# 29 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/bitmapset.h"
typedef uint32 bitmapword;
typedef int32 signedbitmapword;

typedef struct Bitmapset
{
 int nwords;
 bitmapword words[1];
} Bitmapset;



typedef enum
{
 BMS_EQUAL,
 BMS_SUBSET1,
 BMS_SUBSET2,
 BMS_DIFFERENT
} BMS_Comparison;


typedef enum
{
 BMS_EMPTY_SET,
 BMS_SINGLETON,
 BMS_MULTIPLE
} BMS_Membership;






extern Bitmapset *bms_copy(const Bitmapset *a);
extern bool bms_equal(const Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_make_singleton(int x);
extern void bms_free(Bitmapset *a);

extern Bitmapset *bms_union(const Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_intersect(const Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_difference(const Bitmapset *a, const Bitmapset *b);
extern bool bms_is_subset(const Bitmapset *a, const Bitmapset *b);
extern BMS_Comparison bms_subset_compare(const Bitmapset *a, const Bitmapset *b);
extern bool bms_is_member(int x, const Bitmapset *a);
extern bool bms_overlap(const Bitmapset *a, const Bitmapset *b);
extern bool bms_nonempty_difference(const Bitmapset *a, const Bitmapset *b);
extern int bms_singleton_member(const Bitmapset *a);
extern int bms_num_members(const Bitmapset *a);


extern BMS_Membership bms_membership(const Bitmapset *a);
extern bool bms_is_empty(const Bitmapset *a);



extern Bitmapset *bms_add_member(Bitmapset *a, int x);
extern Bitmapset *bms_del_member(Bitmapset *a, int x);
extern Bitmapset *bms_add_members(Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_int_members(Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_del_members(Bitmapset *a, const Bitmapset *b);
extern Bitmapset *bms_join(Bitmapset *a, Bitmapset *b);


extern int bms_first_member(Bitmapset *a);


extern uint32 bms_hash_value(const Bitmapset *a);
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h" 2


typedef struct RelationData *Relation;







typedef Relation *RelationPtr;




extern Relation RelationIdGetRelation(Oid relationId);
extern void RelationClose(Relation relation);




extern List *RelationGetIndexList(Relation relation);
extern Oid RelationGetOidIndex(Relation relation);
extern List *RelationGetIndexExpressions(Relation relation);
extern List *RelationGetIndexPredicate(Relation relation);
extern Bitmapset *RelationGetIndexAttrBitmap(Relation relation);
extern void RelationGetExclusionInfo(Relation indexRelation,
       Oid **operators,
       Oid **procs,
       uint16 **strategies);

extern void RelationSetIndexList(Relation relation,
      List *indexIds, Oid oidIndex);

extern void RelationInitIndexAccessInfo(Relation relation);




extern void RelationCacheInitialize(void);
extern void RelationCacheInitializePhase2(void);
extern void RelationCacheInitializePhase3(void);




extern Relation RelationBuildLocalRelation(const char *relname,
         Oid relnamespace,
         TupleDesc tupDesc,
         Oid relid,
         Oid relfilenode,
         Oid reltablespace,
         bool shared_relation,
         bool mapped_relation,
         char relpersistence);




extern void RelationSetNewRelfilenode(Relation relation,
        TransactionId freezeXid);




extern void RelationForgetRelation(Oid rid);

extern void RelationCacheInvalidateEntry(Oid relationId);

extern void RelationCacheInvalidate(void);

extern void RelationCloseSmgrByOid(Oid relationId);

extern void AtEOXact_RelationCache(bool isCommit);
extern void AtEOSubXact_RelationCache(bool isCommit, SubTransactionId mySubid,
        SubTransactionId parentSubid);




extern bool RelationIdIsInInitFile(Oid relationId);
extern void RelationCacheInitFilePreInvalidate(void);
extern void RelationCacheInitFilePostInvalidate(void);
extern void RelationCacheInitFileRemove(void);


extern bool criticalRelcachesBuilt;


extern bool criticalSharedRelcachesBuilt;
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/gin.h" 2
# 39 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/gin.h"
typedef struct GinStatsData
{
 BlockNumber nPendingPages;
 BlockNumber nTotalPages;
 BlockNumber nEntryPages;
 BlockNumber nDataPages;
 int64 nEntries;
 int32 ginVersion;
} GinStatsData;


extern int GinFuzzySearchLimit;


extern void ginGetStats(Relation index, GinStatsData *stats);
extern void ginUpdateStats(Relation index, const GinStatsData *stats);


extern void gin_redo(XLogRecPtr lsn, XLogRecord *record);
extern void gin_desc(StringInfo buf, uint8 xl_info, char *rec);
extern void gin_xlog_startup(void);
extern void gin_xlog_cleanup(void);
extern bool gin_safe_restartpoint(void);
# 30 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/transam.h" 1
# 101 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/transam.h"
typedef struct VariableCacheData
{



 Oid nextOid;
 uint32 oidCount;




 TransactionId nextXid;

 TransactionId oldestXid;
 TransactionId xidVacLimit;
 TransactionId xidWarnLimit;
 TransactionId xidStopLimit;
 TransactionId xidWrapLimit;
 Oid oldestXidDB;




 TransactionId latestCompletedXid;

} VariableCacheData;

typedef VariableCacheData *VariableCache;
# 137 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/transam.h"
extern bool TransactionStartedDuringRecovery(void);


extern VariableCache ShmemVariableCache;


extern const XLogRecPtr InvalidXLogRecPtr;





extern bool TransactionIdDidCommit(TransactionId transactionId);
extern bool TransactionIdDidAbort(TransactionId transactionId);
extern bool TransactionIdIsKnownCompleted(TransactionId transactionId);
extern void TransactionIdAbort(TransactionId transactionId);
extern void TransactionIdCommitTree(TransactionId xid, int nxids, TransactionId *xids);
extern void TransactionIdAsyncCommitTree(TransactionId xid, int nxids, TransactionId *xids, XLogRecPtr lsn);
extern void TransactionIdAbortTree(TransactionId xid, int nxids, TransactionId *xids);
extern bool TransactionIdPrecedes(TransactionId id1, TransactionId id2);
extern bool TransactionIdPrecedesOrEquals(TransactionId id1, TransactionId id2);
extern bool TransactionIdFollows(TransactionId id1, TransactionId id2);
extern bool TransactionIdFollowsOrEquals(TransactionId id1, TransactionId id2);
extern TransactionId TransactionIdLatest(TransactionId mainxid,
     int nxids, const TransactionId *xids);
extern XLogRecPtr TransactionIdGetCommitLSN(TransactionId xid);


extern TransactionId GetNewTransactionId(bool isSubXact);
extern TransactionId ReadNewTransactionId(void);
extern void SetTransactionIdLimit(TransactionId oldest_datfrozenxid,
       Oid oldest_datoid);
extern bool ForceTransactionIdLimitUpdate(void);
extern Oid GetNewObjectId(void);
# 31 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/twophase.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/twophase.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/proc.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/proc.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/proc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/proc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/latch.h" 1
# 88 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/latch.h"
# 1 "/usr/include/signal.h" 1 3 4
# 71 "/usr/include/signal.h" 3 4
extern const char *const sys_signame[32];
extern const char *const sys_siglist[32];



int raise(int);




void (*bsd_signal(int, void (*)(int)))(int);
int kill(pid_t, int) __asm("_" "kill" );
int killpg(pid_t, int) __asm("_" "killpg" );
int pthread_kill(pthread_t, int);
int pthread_sigmask(int, const sigset_t *, sigset_t *) __asm("_" "pthread_sigmask" );
int sigaction(int, const struct sigaction * ,
     struct sigaction * );
int sigaddset(sigset_t *, int);
int sigaltstack(const stack_t * , stack_t * ) __asm("_" "sigaltstack" );
int sigdelset(sigset_t *, int);
int sigemptyset(sigset_t *);
int sigfillset(sigset_t *);
int sighold(int);
int sigignore(int);
int siginterrupt(int, int);
int sigismember(const sigset_t *, int);
int sigpause(int) __asm("_" "sigpause" );
int sigpending(sigset_t *);
int sigprocmask(int, const sigset_t * , sigset_t * );
int sigrelse(int);
void (*sigset(int, void (*)(int)))(int);
int sigsuspend(const sigset_t *) __asm("_" "sigsuspend" );
int sigwait(const sigset_t * , int * ) __asm("_" "sigwait" );

void psignal(unsigned int, const char *);
int sigblock(int);
int sigsetmask(int);
int sigvec(int, struct sigvec *, struct sigvec *);






static __inline int
__sigbits(int __signo)
{
    return __signo > 32 ? 0 : (1 << (__signo - 1));
}
# 89 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/latch.h" 2






typedef struct
{
 sig_atomic_t is_set;
 bool is_shared;
 int owner_pid;



} Latch;
# 115 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/latch.h"
extern void InitializeLatchSupport(void);
extern void InitLatch(volatile Latch *latch);
extern void InitSharedLatch(volatile Latch *latch);
extern void OwnLatch(volatile Latch *latch);
extern void DisownLatch(volatile Latch *latch);
extern int WaitLatch(volatile Latch *latch, int wakeEvents, long timeout);
extern int WaitLatchOrSocket(volatile Latch *latch, int wakeEvents,
      pgsocket sock, long timeout);
extern void SetLatch(volatile Latch *latch);
extern void ResetLatch(volatile Latch *latch);
# 134 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/latch.h"
extern void latch_sigusr1_handler(void);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/proc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/backendid.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/backendid.h"
typedef int BackendId;



extern BackendId MyBackendId;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lwlock.h" 1
# 47 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lwlock.h"
typedef enum LWLockId
{
 BufFreelistLock,
 ShmemIndexLock,
 OidGenLock,
 XidGenLock,
 ProcArrayLock,
 SInvalReadLock,
 SInvalWriteLock,
 WALInsertLock,
 WALWriteLock,
 ControlFileLock,
 CheckpointLock,
 CLogControlLock,
 SubtransControlLock,
 MultiXactGenLock,
 MultiXactOffsetControlLock,
 MultiXactMemberControlLock,
 RelCacheInitLock,
 CheckpointerCommLock,
 TwoPhaseStateLock,
 TablespaceCreateLock,
 BtreeVacuumLock,
 AddinShmemInitLock,
 AutovacuumLock,
 AutovacuumScheduleLock,
 SyncScanLock,
 RelationMappingLock,
 AsyncCtlLock,
 AsyncQueueLock,
 SerializableXactHashLock,
 SerializableFinishedListLock,
 SerializablePredicateLockListLock,
 OldSerXidLock,
 SyncRepLock,

 FirstBufMappingLock,
 FirstLockMgrLock = FirstBufMappingLock + 16,
 FirstPredicateLockMgrLock = FirstLockMgrLock + (1 << 4),


 NumFixedLWLocks = FirstPredicateLockMgrLock + (1 << 4),

 MaxDynamicLWLock = 1000000000
} LWLockId;


typedef enum LWLockMode
{
 LW_EXCLUSIVE,
 LW_SHARED,
 LW_WAIT_UNTIL_FREE


} LWLockMode;






extern LWLockId LWLockAssign(void);
extern void LWLockAcquire(LWLockId lockid, LWLockMode mode);
extern bool LWLockConditionalAcquire(LWLockId lockid, LWLockMode mode);
extern bool LWLockAcquireOrWait(LWLockId lockid, LWLockMode mode);
extern void LWLockRelease(LWLockId lockid);
extern void LWLockReleaseAll(void);
extern bool LWLockHeldByMe(LWLockId lockid);

extern int NumLWLocks(void);
extern Size LWLockShmemSize(void);
extern void CreateLWLocks(void);

extern void RequestAddinLWLocks(int n);
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/shmem.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/shmem.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/hsearch.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/hsearch.h"
typedef uint32 (*HashValueFunc) (const void *key, Size keysize);







typedef int (*HashCompareFunc) (const void *key1, const void *key2,
           Size keysize);






typedef void *(*HashCopyFunc) (void *dest, const void *src, Size keysize);






typedef void *(*HashAllocFunc) (Size request);






typedef struct HASHELEMENT
{
 struct HASHELEMENT *link;
 uint32 hashvalue;
} HASHELEMENT;


typedef struct HASHHDR HASHHDR;


typedef struct HTAB HTAB;



typedef struct HASHCTL
{
 long num_partitions;
 long ssize;
 long dsize;
 long max_dsize;
 long ffactor;
 Size keysize;
 Size entrysize;
 HashValueFunc hash;
 HashCompareFunc match;
 HashCopyFunc keycopy;
 HashAllocFunc alloc;
 MemoryContext hcxt;
 HASHHDR *hctl;
} HASHCTL;
# 102 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/hsearch.h"
typedef enum
{
 HASH_FIND,
 HASH_ENTER,
 HASH_REMOVE,
 HASH_ENTER_NULL
} HASHACTION;


typedef struct
{
 HTAB *hashp;
 uint32 curBucket;
 HASHELEMENT *curEntry;
} HASH_SEQ_STATUS;




extern HTAB *hash_create(const char *tabname, long nelem,
   HASHCTL *info, int flags);
extern void hash_destroy(HTAB *hashp);
extern void hash_stats(const char *where, HTAB *hashp);
extern void *hash_search(HTAB *hashp, const void *keyPtr, HASHACTION action,
   bool *foundPtr);
extern uint32 get_hash_value(HTAB *hashp, const void *keyPtr);
extern void *hash_search_with_hash_value(HTAB *hashp, const void *keyPtr,
       uint32 hashvalue, HASHACTION action,
       bool *foundPtr);
extern long hash_get_num_entries(HTAB *hashp);
extern void hash_seq_init(HASH_SEQ_STATUS *status, HTAB *hashp);
extern void *hash_seq_search(HASH_SEQ_STATUS *status);
extern void hash_seq_term(HASH_SEQ_STATUS *status);
extern void hash_freeze(HTAB *hashp);
extern Size hash_estimate_size(long num_entries, Size entrysize);
extern long hash_select_dirsize(long num_entries);
extern Size hash_get_shared_size(HASHCTL *info, int flags);
extern void AtEOXact_HashTables(bool isCommit);
extern void AtEOSubXact_HashTables(bool isCommit, int nestDepth);




extern uint32 string_hash(const void *key, Size keysize);
extern uint32 tag_hash(const void *key, Size keysize);
extern uint32 oid_hash(const void *key, Size keysize);
extern uint32 bitmap_hash(const void *key, Size keysize);
extern int bitmap_match(const void *key1, const void *key2, Size keysize);
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/shmem.h" 2



typedef struct SHM_QUEUE
{
 struct SHM_QUEUE *prev;
 struct SHM_QUEUE *next;
} SHM_QUEUE;


extern void InitShmemAccess(void *seghdr);
extern void InitShmemAllocation(void);
extern void *ShmemAlloc(Size size);
extern bool ShmemAddrIsValid(const void *addr);
extern void InitShmemIndex(void);
extern HTAB *ShmemInitHash(const char *name, long init_size, long max_size,
     HASHCTL *infoP, int hash_flags);
extern void *ShmemInitStruct(const char *name, Size size, bool *foundPtr);
extern Size add_size(Size s1, Size s2);
extern Size mul_size(Size s1, Size s2);


extern void RequestAddinShmemSpace(Size size);
# 56 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/shmem.h"
typedef struct
{
 char key[(48)];
 void *location;
 Size size;
} ShmemIndexEnt;




extern void SHMQueueInit(SHM_QUEUE *queue);
extern void SHMQueueElemInit(SHM_QUEUE *queue);
extern void SHMQueueDelete(SHM_QUEUE *queue);
extern void SHMQueueInsertBefore(SHM_QUEUE *queue, SHM_QUEUE *elem);
extern void SHMQueueInsertAfter(SHM_QUEUE *queue, SHM_QUEUE *elem);
extern Pointer SHMQueueNext(const SHM_QUEUE *queue, const SHM_QUEUE *curElem,
    Size linkOffset);
extern Pointer SHMQueuePrev(const SHM_QUEUE *queue, const SHM_QUEUE *curElem,
    Size linkOffset);
extern bool SHMQueueEmpty(const SHM_QUEUE *queue);
extern bool SHMQueueIsDetached(const SHM_QUEUE *queue);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h" 2



typedef struct PGPROC PGPROC;

typedef struct PROC_QUEUE
{
 SHM_QUEUE links;
 int size;
} PROC_QUEUE;


extern int max_locks_per_xact;
# 58 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct
{
 BackendId backendId;
 LocalTransactionId localTransactionId;

} VirtualTransactionId;
# 86 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef int LOCKMASK;
typedef int LOCKMODE;
# 116 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct LockMethodData
{
 int numLockModes;
 const LOCKMASK *conflictTab;
 const char *const * lockModeNames;
 const bool *trace_flag;
} LockMethodData;

typedef const LockMethodData *LockMethod;





typedef uint16 LOCKMETHODID;
# 165 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef enum LockTagType
{
 LOCKTAG_RELATION,

 LOCKTAG_RELATION_EXTEND,

 LOCKTAG_PAGE,

 LOCKTAG_TUPLE,

 LOCKTAG_TRANSACTION,

 LOCKTAG_VIRTUALTRANSACTION,

 LOCKTAG_OBJECT,







 LOCKTAG_USERLOCK,
 LOCKTAG_ADVISORY
} LockTagType;
# 201 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct LOCKTAG
{
 uint32 locktag_field1;
 uint32 locktag_field2;
 uint32 locktag_field3;
 uint16 locktag_field4;
 uint8 locktag_type;
 uint8 locktag_lockmethodid;
} LOCKTAG;
# 299 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct LOCK
{

 LOCKTAG tag;


 LOCKMASK grantMask;
 LOCKMASK waitMask;
 SHM_QUEUE procLocks;
 PROC_QUEUE waitProcs;
 int requested[10];
 int nRequested;
 int granted[10];
 int nGranted;
} LOCK;
# 352 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct PROCLOCKTAG
{

 LOCK *myLock;
 PGPROC *myProc;
} PROCLOCKTAG;

typedef struct PROCLOCK
{

 PROCLOCKTAG tag;


 LOCKMASK holdMask;
 LOCKMASK releaseMask;
 SHM_QUEUE lockLink;
 SHM_QUEUE procLink;
} PROCLOCK;
# 383 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct LOCALLOCKTAG
{
 LOCKTAG lock;
 LOCKMODE mode;
} LOCALLOCKTAG;

typedef struct LOCALLOCKOWNER
{






 struct ResourceOwnerData *owner;
 int64 nLocks;
} LOCALLOCKOWNER;

typedef struct LOCALLOCK
{

 LOCALLOCKTAG tag;


 LOCK *lock;
 PROCLOCK *proclock;
 uint32 hashcode;
 int64 nLocks;
 int numLockOwners;
 int maxLockOwners;
 bool holdsStrongLockCount;
 LOCALLOCKOWNER *lockOwners;
} LOCALLOCK;
# 425 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
typedef struct LockInstanceData
{
 LOCKTAG locktag;
 LOCKMASK holdMask;
 LOCKMODE waitLockMode;
 BackendId backend;
 LocalTransactionId lxid;
 int pid;
 bool fastpath;
} LockInstanceData;

typedef struct LockData
{
 int nelements;
 LockInstanceData *locks;
} LockData;



typedef enum
{
 LOCKACQUIRE_NOT_AVAIL,
 LOCKACQUIRE_OK,
 LOCKACQUIRE_ALREADY_HELD
} LockAcquireResult;


typedef enum
{
 DS_NOT_YET_CHECKED,
 DS_NO_DEADLOCK,
 DS_SOFT_DEADLOCK,
 DS_HARD_DEADLOCK,
 DS_BLOCKED_BY_AUTOVACUUM

} DeadLockState;
# 478 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h"
extern void InitLocks(void);
extern LockMethod GetLocksMethodTable(const LOCK *lock);
extern uint32 LockTagHashCode(const LOCKTAG *locktag);
extern LockAcquireResult LockAcquire(const LOCKTAG *locktag,
   LOCKMODE lockmode,
   bool sessionLock,
   bool dontWait);
extern LockAcquireResult LockAcquireExtended(const LOCKTAG *locktag,
     LOCKMODE lockmode,
     bool sessionLock,
     bool dontWait,
     bool report_memory_error);
extern void AbortStrongLockAcquire(void);
extern bool LockRelease(const LOCKTAG *locktag,
   LOCKMODE lockmode, bool sessionLock);
extern void LockReleaseAll(LOCKMETHODID lockmethodid, bool allLocks);
extern void LockReleaseSession(LOCKMETHODID lockmethodid);
extern void LockReleaseCurrentOwner(void);
extern void LockReassignCurrentOwner(void);
extern bool LockHasWaiters(const LOCKTAG *locktag,
      LOCKMODE lockmode, bool sessionLock);
extern VirtualTransactionId *GetLockConflicts(const LOCKTAG *locktag,
     LOCKMODE lockmode);
extern void AtPrepare_Locks(void);
extern void PostPrepare_Locks(TransactionId xid);
extern int LockCheckConflicts(LockMethod lockMethodTable,
       LOCKMODE lockmode,
       LOCK *lock, PROCLOCK *proclock, PGPROC *proc);
extern void GrantLock(LOCK *lock, PROCLOCK *proclock, LOCKMODE lockmode);
extern void GrantAwaitedLock(void);
extern void RemoveFromWaitQueue(PGPROC *proc, uint32 hashcode);
extern Size LockShmemSize(void);
extern LockData *GetLockStatusData(void);

extern void ReportLockTableError(bool report);

typedef struct xl_standby_lock
{
 TransactionId xid;
 Oid dbOid;
 Oid relOid;
} xl_standby_lock;

extern xl_standby_lock *GetRunningTransactionLocks(int *nlocks);
extern const char *GetLockmodeName(LOCKMETHODID lockmethodid, LOCKMODE mode);

extern void lock_twophase_recover(TransactionId xid, uint16 info,
       void *recdata, uint32 len);
extern void lock_twophase_postcommit(TransactionId xid, uint16 info,
       void *recdata, uint32 len);
extern void lock_twophase_postabort(TransactionId xid, uint16 info,
      void *recdata, uint32 len);
extern void lock_twophase_standby_recover(TransactionId xid, uint16 info,
         void *recdata, uint32 len);

extern DeadLockState DeadLockCheck(PGPROC *proc);
extern PGPROC *GetBlockingAutoVacuumPgproc(void);
extern void DeadLockReport(void);
extern void RememberSimpleDeadLock(PGPROC *proc1,
        LOCKMODE lockmode,
        LOCK *lock,
        PGPROC *proc2);
extern void InitDeadLockChecking(void);







extern void VirtualXactLockTableInsert(VirtualTransactionId vxid);
extern void VirtualXactLockTableCleanup(void);
extern bool VirtualXactLock(VirtualTransactionId vxid, bool wait);
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/proc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/pg_sema.h" 1
# 50 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/pg_sema.h"
typedef struct PGSemaphoreData
{
 int semId;
 int semNum;
} PGSemaphoreData;







typedef PGSemaphoreData *PGSemaphore;



extern void PGReserveSemaphores(int maxSemas, int port);


extern void PGSemaphoreCreate(PGSemaphore sema);


extern void PGSemaphoreReset(PGSemaphore sema);


extern void PGSemaphoreLock(PGSemaphore sema, bool interruptOK);


extern void PGSemaphoreUnlock(PGSemaphore sema);


extern bool PGSemaphoreTryLock(PGSemaphore sema);
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/proc.h" 2
# 36 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/proc.h"
struct XidCache
{
 TransactionId xids[64];
};
# 74 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/proc.h"
struct PGPROC
{

 SHM_QUEUE links;

 PGSemaphoreData sem;
 int waitStatus;

 Latch procLatch;

 LocalTransactionId lxid;


 int pid;
 int pgprocno;


 BackendId backendId;
 Oid databaseId;
 Oid roleId;






 bool recoveryConflictPending;


 bool lwWaiting;
 uint8 lwWaitMode;
 struct PGPROC *lwWaitLink;



 LOCK *waitLock;
 PROCLOCK *waitProcLock;
 LOCKMODE waitLockMode;
 LOCKMASK heldLocks;
# 121 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/proc.h"
 XLogRecPtr waitLSN;
 int syncRepState;
 SHM_QUEUE syncRepLinks;






 SHM_QUEUE myProcLocks[(1 << 4)];

 struct XidCache subxids;


 LWLockId backendLock;


 uint64 fpLockBits;
 Oid fpRelId[16];
 bool fpVXIDLock;
 LocalTransactionId fpLocalTransactionId;

};




extern PGPROC *MyProc;
extern struct PGXACT *MyPgXact;
# 159 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/proc.h"
typedef struct PGXACT
{
 TransactionId xid;



 TransactionId xmin;




 uint8 vacuumFlags;
 bool overflowed;
 bool inCommit;

 uint8 nxids;
} PGXACT;




typedef struct PROC_HDR
{

 PGPROC *allProcs;

 PGXACT *allPgXact;

 uint32 allProcCount;

 PGPROC *freeProcs;

 PGPROC *autovacFreeProcs;

 Latch *walwriterLatch;

 Latch *checkpointerLatch;

 int spins_per_delay;

 PGPROC *startupProc;
 int startupProcPid;

 int startupBufferPinWaitBufId;
} PROC_HDR;

extern PROC_HDR *ProcGlobal;

extern PGPROC *PreparedXactProcs;
# 221 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/proc.h"
extern int DeadlockTimeout;
extern int StatementTimeout;
extern bool log_lock_waits;

extern volatile bool cancel_from_timeout;





extern int ProcGlobalSemas(void);
extern Size ProcGlobalShmemSize(void);
extern void InitProcGlobal(void);
extern void InitProcess(void);
extern void InitProcessPhase2(void);
extern void InitAuxiliaryProcess(void);

extern void PublishStartupProcessInformation(void);
extern void SetStartupBufferPinWaitBufId(int bufid);
extern int GetStartupBufferPinWaitBufId(void);

extern bool HaveNFreeProcs(int n);
extern void ProcReleaseLocks(bool isCommit);

extern void ProcQueueInit(PROC_QUEUE *queue);
extern int ProcSleep(LOCALLOCK *locallock, LockMethod lockMethodTable);
extern PGPROC *ProcWakeup(PGPROC *proc, int waitStatus);
extern void ProcLockWakeup(LockMethod lockMethodTable, LOCK *lock);
extern bool IsWaitingForLock(void);
extern void LockErrorCleanup(void);

extern void ProcWaitForSignal(void);
extern void ProcSendSignal(int pid);

extern bool enable_sig_alarm(int delayms, bool is_statement_timeout);
extern bool disable_sig_alarm(bool is_statement_timeout);
extern void handle_sig_alarm(int postgres_signal_arg);

extern bool enable_standby_sig_alarm(TimestampTz now,
       TimestampTz fin_time, bool deadlock_only);
extern bool disable_standby_sig_alarm(void);
extern void handle_standby_sig_alarm(int postgres_signal_arg);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/twophase.h" 2





typedef struct GlobalTransactionData *GlobalTransaction;


extern int max_prepared_xacts;

extern Size TwoPhaseShmemSize(void);
extern void TwoPhaseShmemInit(void);

extern PGPROC *TwoPhaseGetDummyProc(TransactionId xid);
extern BackendId TwoPhaseGetDummyBackendId(TransactionId xid);

extern GlobalTransaction MarkAsPreparing(TransactionId xid, const char *gid,
    TimestampTz prepared_at,
    Oid owner, Oid databaseid);

extern void StartPrepare(GlobalTransaction gxact);
extern void EndPrepare(GlobalTransaction gxact);
extern bool StandbyTransactionIdIsPrepared(TransactionId xid);

extern TransactionId PrescanPreparedTransactions(TransactionId **xids_p,
       int *nxids_p);
extern void StandbyRecoverPreparedTransactions(bool overwriteOK);
extern void RecoverPreparedTransactions(void);

extern void RecreateTwoPhaseFile(TransactionId xid, void *content, int len);
extern void RemoveTwoPhaseFile(TransactionId xid, bool giveWarning);

extern void CheckPointTwoPhase(XLogRecPtr redo_horizon);

extern void FinishPreparedTransaction(const char *gid, bool isCommit);
# 32 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h" 1
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
typedef enum ForkNumber
{
 InvalidForkNumber = -1,
 MAIN_FORKNUM = 0,
 FSM_FORKNUM,
 VISIBILITYMAP_FORKNUM,
 INIT_FORKNUM





} ForkNumber;
# 77 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
typedef struct RelFileNode
{
 Oid spcNode;
 Oid dbNode;
 Oid relNode;
} RelFileNode;
# 92 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h"
typedef struct RelFileNodeBackend
{
 RelFileNode node;
 BackendId backend;
} RelFileNodeBackend;
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h" 2
# 30 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
extern int DefaultXactIsoLevel;
extern int XactIsoLevel;
# 44 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
extern bool DefaultXactReadOnly;
extern bool XactReadOnly;





extern bool DefaultXactDeferrable;
extern bool XactDeferrable;

typedef enum
{
 SYNCHRONOUS_COMMIT_OFF,
 SYNCHRONOUS_COMMIT_LOCAL_FLUSH,
 SYNCHRONOUS_COMMIT_REMOTE_WRITE,

 SYNCHRONOUS_COMMIT_REMOTE_FLUSH
} SyncCommitLevel;





extern int synchronous_commit;


extern bool MyXactAccessedTempRel;




typedef enum
{
 XACT_EVENT_COMMIT,
 XACT_EVENT_ABORT,
 XACT_EVENT_PREPARE
} XactEvent;

typedef void (*XactCallback) (XactEvent event, void *arg);

typedef enum
{
 SUBXACT_EVENT_START_SUB,
 SUBXACT_EVENT_COMMIT_SUB,
 SUBXACT_EVENT_ABORT_SUB
} SubXactEvent;

typedef void (*SubXactCallback) (SubXactEvent event, SubTransactionId mySubid,
         SubTransactionId parentSubid, void *arg);
# 112 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
typedef struct xl_xact_assignment
{
 TransactionId xtop;
 int nsubxacts;
 TransactionId xsub[1];
} xl_xact_assignment;



typedef struct xl_xact_commit_compact
{
 TimestampTz xact_time;
 int nsubxacts;

 TransactionId subxacts[1];
} xl_xact_commit_compact;



typedef struct xl_xact_commit
{
 TimestampTz xact_time;
 uint32 xinfo;
 int nrels;
 int nsubxacts;
 int nmsgs;
 Oid dbId;
 Oid tsId;

 RelFileNode xnodes[1];


} xl_xact_commit;
# 163 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
typedef struct xl_xact_abort
{
 TimestampTz xact_time;
 int nrels;
 int nsubxacts;

 RelFileNode xnodes[1];

} xl_xact_abort;
# 184 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
typedef struct xl_xact_commit_prepared
{
 TransactionId xid;
 xl_xact_commit crec;

} xl_xact_commit_prepared;



typedef struct xl_xact_abort_prepared
{
 TransactionId xid;
 xl_xact_abort arec;

} xl_xact_abort_prepared;
# 207 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xact.h"
extern bool IsTransactionState(void);
extern bool IsAbortedTransactionBlockState(void);
extern TransactionId GetTopTransactionId(void);
extern TransactionId GetTopTransactionIdIfAny(void);
extern TransactionId GetCurrentTransactionId(void);
extern TransactionId GetCurrentTransactionIdIfAny(void);
extern TransactionId GetStableLatestTransactionId(void);
extern SubTransactionId GetCurrentSubTransactionId(void);
extern bool SubTransactionIsActive(SubTransactionId subxid);
extern CommandId GetCurrentCommandId(bool used);
extern TimestampTz GetCurrentTransactionStartTimestamp(void);
extern TimestampTz GetCurrentStatementStartTimestamp(void);
extern TimestampTz GetCurrentTransactionStopTimestamp(void);
extern void SetCurrentStatementStartTimestamp(void);
extern int GetCurrentTransactionNestLevel(void);
extern bool TransactionIdIsCurrentTransactionId(TransactionId xid);
extern void CommandCounterIncrement(void);
extern void ForceSyncCommit(void);
extern void StartTransactionCommand(void);
extern void CommitTransactionCommand(void);
extern void AbortCurrentTransaction(void);
extern void BeginTransactionBlock(void);
extern bool EndTransactionBlock(void);
extern bool PrepareTransactionBlock(char *gid);
extern void UserAbortTransactionBlock(void);
extern void ReleaseSavepoint(List *options);
extern void DefineSavepoint(char *name);
extern void RollbackToSavepoint(List *options);
extern void BeginInternalSubTransaction(char *name);
extern void ReleaseCurrentSubTransaction(void);
extern void RollbackAndReleaseCurrentSubTransaction(void);
extern bool IsSubTransaction(void);
extern bool IsTransactionBlock(void);
extern bool IsTransactionOrTransactionBlock(void);
extern char TransactionBlockStatusCode(void);
extern void AbortOutOfAnyTransaction(void);
extern void PreventTransactionChain(bool isTopLevel, const char *stmtType);
extern void RequireTransactionChain(bool isTopLevel, const char *stmtType);
extern bool IsInTransactionChain(bool isTopLevel);
extern void RegisterXactCallback(XactCallback callback, void *arg);
extern void UnregisterXactCallback(XactCallback callback, void *arg);
extern void RegisterSubXactCallback(SubXactCallback callback, void *arg);
extern void UnregisterSubXactCallback(SubXactCallback callback, void *arg);

extern int xactGetCommittedChildren(TransactionId **ptr);

extern void xact_redo(XLogRecPtr lsn, XLogRecord *record);
extern void xact_desc(StringInfo buf, uint8 xl_info, char *rec);
# 33 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/namespace.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/namespace.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 2
# 38 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Alias
{
 NodeTag type;
 char *aliasname;
 List *colnames;
} Alias;

typedef enum InhOption
{
 INH_NO,
 INH_YES,
 INH_DEFAULT
} InhOption;


typedef enum OnCommitAction
{
 ONCOMMIT_NOOP,
 ONCOMMIT_PRESERVE_ROWS,
 ONCOMMIT_DELETE_ROWS,
 ONCOMMIT_DROP
} OnCommitAction;
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RangeVar
{
 NodeTag type;
 char *catalogname;
 char *schemaname;
 char *relname;
 InhOption inhOpt;

 char relpersistence;
 Alias *alias;
 int location;
} RangeVar;




typedef struct IntoClause
{
 NodeTag type;

 RangeVar *rel;
 List *colNames;
 List *options;
 OnCommitAction onCommit;
 char *tableSpaceName;
 bool skipData;
} IntoClause;
# 111 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Expr
{
 NodeTag type;
} Expr;
# 138 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Var
{
 Expr xpr;
 Index varno;

 AttrNumber varattno;

 Oid vartype;
 int32 vartypmod;
 Oid varcollid;
 Index varlevelsup;


 Index varnoold;
 AttrNumber varoattno;
 int location;
} Var;




typedef struct Const
{
 Expr xpr;
 Oid consttype;
 int32 consttypmod;
 Oid constcollid;
 int constlen;
 Datum constvalue;
 bool constisnull;

 bool constbyval;



 int location;
} Const;
# 201 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum ParamKind
{
 PARAM_EXTERN,
 PARAM_EXEC,
 PARAM_SUBLINK
} ParamKind;

typedef struct Param
{
 Expr xpr;
 ParamKind paramkind;
 int paramid;
 Oid paramtype;
 int32 paramtypmod;
 Oid paramcollid;
 int location;
} Param;
# 234 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct Aggref
{
 Expr xpr;
 Oid aggfnoid;
 Oid aggtype;
 Oid aggcollid;
 Oid inputcollid;
 List *args;
 List *aggorder;
 List *aggdistinct;
 bool aggstar;
 Index agglevelsup;
 int location;
} Aggref;




typedef struct WindowFunc
{
 Expr xpr;
 Oid winfnoid;
 Oid wintype;
 Oid wincollid;
 Oid inputcollid;
 List *args;
 Index winref;
 bool winstar;
 bool winagg;
 int location;
} WindowFunc;
# 288 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ArrayRef
{
 Expr xpr;
 Oid refarraytype;
 Oid refelemtype;
 int32 reftypmod;
 Oid refcollid;
 List *refupperindexpr;

 List *reflowerindexpr;

 Expr *refexpr;

 Expr *refassgnexpr;

} ArrayRef;







typedef enum CoercionContext
{
 COERCION_IMPLICIT,
 COERCION_ASSIGNMENT,
 COERCION_EXPLICIT
} CoercionContext;
# 327 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum CoercionForm
{
 COERCE_EXPLICIT_CALL,
 COERCE_EXPLICIT_CAST,
 COERCE_IMPLICIT_CAST,
 COERCE_DONTCARE
} CoercionForm;




typedef struct FuncExpr
{
 Expr xpr;
 Oid funcid;
 Oid funcresulttype;
 bool funcretset;
 CoercionForm funcformat;
 Oid funccollid;
 Oid inputcollid;
 List *args;
 int location;
} FuncExpr;
# 365 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct NamedArgExpr
{
 Expr xpr;
 Expr *arg;
 char *name;
 int argnumber;
 int location;
} NamedArgExpr;
# 383 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct OpExpr
{
 Expr xpr;
 Oid opno;
 Oid opfuncid;
 Oid opresulttype;
 bool opretset;
 Oid opcollid;
 Oid inputcollid;
 List *args;
 int location;
} OpExpr;
# 406 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef OpExpr DistinctExpr;







typedef OpExpr NullIfExpr;
# 426 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ScalarArrayOpExpr
{
 Expr xpr;
 Oid opno;
 Oid opfuncid;
 bool useOr;
 Oid inputcollid;
 List *args;
 int location;
} ScalarArrayOpExpr;
# 448 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum BoolExprType
{
 AND_EXPR, OR_EXPR, NOT_EXPR
} BoolExprType;

typedef struct BoolExpr
{
 Expr xpr;
 BoolExprType boolop;
 List *args;
 int location;
} BoolExpr;
# 504 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum SubLinkType
{
 EXISTS_SUBLINK,
 ALL_SUBLINK,
 ANY_SUBLINK,
 ROWCOMPARE_SUBLINK,
 EXPR_SUBLINK,
 ARRAY_SUBLINK,
 CTE_SUBLINK
} SubLinkType;


typedef struct SubLink
{
 Expr xpr;
 SubLinkType subLinkType;
 Node *testexpr;
 List *operName;
 Node *subselect;
 int location;
} SubLink;
# 564 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct SubPlan
{
 Expr xpr;

 SubLinkType subLinkType;

 Node *testexpr;
 List *paramIds;

 int plan_id;

 char *plan_name;

 Oid firstColType;
 int32 firstColTypmod;
 Oid firstColCollation;


 bool useHashTable;

 bool unknownEqFalse;




 List *setParam;

 List *parParam;
 List *args;

 Cost startup_cost;
 Cost per_call_cost;
} SubPlan;
# 606 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct AlternativeSubPlan
{
 Expr xpr;
 List *subplans;
} AlternativeSubPlan;
# 621 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct FieldSelect
{
 Expr xpr;
 Expr *arg;
 AttrNumber fieldnum;
 Oid resulttype;

 int32 resulttypmod;
 Oid resultcollid;
} FieldSelect;
# 647 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct FieldStore
{
 Expr xpr;
 Expr *arg;
 List *newvals;
 List *fieldnums;
 Oid resulttype;

} FieldStore;
# 670 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RelabelType
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;
 int32 resulttypmod;
 Oid resultcollid;
 CoercionForm relabelformat;
 int location;
} RelabelType;
# 690 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CoerceViaIO
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;

 Oid resultcollid;
 CoercionForm coerceformat;
 int location;
} CoerceViaIO;
# 713 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ArrayCoerceExpr
{
 Expr xpr;
 Expr *arg;
 Oid elemfuncid;
 Oid resulttype;
 int32 resulttypmod;
 Oid resultcollid;
 bool isExplicit;
 CoercionForm coerceformat;
 int location;
} ArrayCoerceExpr;
# 738 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ConvertRowtypeExpr
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;

 CoercionForm convertformat;
 int location;
} ConvertRowtypeExpr;
# 755 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CollateExpr
{
 Expr xpr;
 Expr *arg;
 Oid collOid;
 int location;
} CollateExpr;
# 785 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CaseExpr
{
 Expr xpr;
 Oid casetype;
 Oid casecollid;
 Expr *arg;
 List *args;
 Expr *defresult;
 int location;
} CaseExpr;




typedef struct CaseWhen
{
 Expr xpr;
 Expr *expr;
 Expr *result;
 int location;
} CaseWhen;
# 815 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CaseTestExpr
{
 Expr xpr;
 Oid typeId;
 int32 typeMod;
 Oid collation;
} CaseTestExpr;
# 831 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct ArrayExpr
{
 Expr xpr;
 Oid array_typeid;
 Oid array_collid;
 Oid element_typeid;
 List *elements;
 bool multidims;
 int location;
} ArrayExpr;
# 865 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RowExpr
{
 Expr xpr;
 List *args;
 Oid row_typeid;
# 880 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
 CoercionForm row_format;
 List *colnames;
 int location;
} RowExpr;
# 899 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum RowCompareType
{

 ROWCOMPARE_LT = 1,
 ROWCOMPARE_LE = 2,
 ROWCOMPARE_EQ = 3,
 ROWCOMPARE_GE = 4,
 ROWCOMPARE_GT = 5,
 ROWCOMPARE_NE = 6
} RowCompareType;

typedef struct RowCompareExpr
{
 Expr xpr;
 RowCompareType rctype;
 List *opnos;
 List *opfamilies;
 List *inputcollids;
 List *largs;
 List *rargs;
} RowCompareExpr;




typedef struct CoalesceExpr
{
 Expr xpr;
 Oid coalescetype;
 Oid coalescecollid;
 List *args;
 int location;
} CoalesceExpr;




typedef enum MinMaxOp
{
 IS_GREATEST,
 IS_LEAST
} MinMaxOp;

typedef struct MinMaxExpr
{
 Expr xpr;
 Oid minmaxtype;
 Oid minmaxcollid;
 Oid inputcollid;
 MinMaxOp op;
 List *args;
 int location;
} MinMaxExpr;
# 965 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum XmlExprOp
{
 IS_XMLCONCAT,
 IS_XMLELEMENT,
 IS_XMLFOREST,
 IS_XMLPARSE,
 IS_XMLPI,
 IS_XMLROOT,
 IS_XMLSERIALIZE,
 IS_DOCUMENT
} XmlExprOp;

typedef enum
{
 XMLOPTION_DOCUMENT,
 XMLOPTION_CONTENT
} XmlOptionType;

typedef struct XmlExpr
{
 Expr xpr;
 XmlExprOp op;
 char *name;
 List *named_args;
 List *arg_names;
 List *args;
 XmlOptionType xmloption;
 Oid type;
 int32 typmod;
 int location;
} XmlExpr;
# 1008 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum NullTestType
{
 IS_NULL, IS_NOT_NULL
} NullTestType;

typedef struct NullTest
{
 Expr xpr;
 Expr *arg;
 NullTestType nulltesttype;
 bool argisrow;
} NullTest;
# 1030 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef enum BoolTestType
{
 IS_TRUE, IS_NOT_TRUE, IS_FALSE, IS_NOT_FALSE, IS_UNKNOWN, IS_NOT_UNKNOWN
} BoolTestType;

typedef struct BooleanTest
{
 Expr xpr;
 Expr *arg;
 BoolTestType booltesttype;
} BooleanTest;
# 1051 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CoerceToDomain
{
 Expr xpr;
 Expr *arg;
 Oid resulttype;
 int32 resulttypmod;
 Oid resultcollid;
 CoercionForm coercionformat;
 int location;
} CoerceToDomain;
# 1071 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CoerceToDomainValue
{
 Expr xpr;
 Oid typeId;
 int32 typeMod;
 Oid collation;
 int location;
} CoerceToDomainValue;
# 1087 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct SetToDefault
{
 Expr xpr;
 Oid typeId;
 int32 typeMod;
 Oid collation;
 int location;
} SetToDefault;
# 1108 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct CurrentOfExpr
{
 Expr xpr;
 Index cvarno;
 char *cursor_name;
 int cursor_param;
} CurrentOfExpr;
# 1170 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct TargetEntry
{
 Expr xpr;
 Expr *expr;
 AttrNumber resno;
 char *resname;
 Index ressortgroupref;

 Oid resorigtbl;
 AttrNumber resorigcol;
 bool resjunk;

} TargetEntry;
# 1222 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct RangeTblRef
{
 NodeTag type;
 int rtindex;
} RangeTblRef;
# 1251 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct JoinExpr
{
 NodeTag type;
 JoinType jointype;
 bool isNatural;
 Node *larg;
 Node *rarg;
 List *usingClause;
 Node *quals;
 Alias *alias;
 int rtindex;
} JoinExpr;
# 1273 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h"
typedef struct FromExpr
{
 NodeTag type;
 List *fromlist;
 Node *quals;
} FromExpr;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/namespace.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/namespace.h" 2
# 28 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/namespace.h"
typedef struct _FuncCandidateList
{
 struct _FuncCandidateList *next;
 int pathpos;
 Oid oid;
 int nargs;
 int nvargs;
 int ndargs;
 int *argnumbers;
 Oid args[1];
} *FuncCandidateList;




typedef struct OverrideSearchPath
{
 List *schemas;
 bool addCatalog;
 bool addTemp;
} OverrideSearchPath;

typedef void (*RangeVarGetRelidCallback) (const RangeVar *relation, Oid relId,
             Oid oldRelId, void *callback_arg);




extern Oid RangeVarGetRelidExtended(const RangeVar *relation,
       LOCKMODE lockmode, bool missing_ok, bool nowait,
       RangeVarGetRelidCallback callback,
       void *callback_arg);
extern Oid RangeVarGetCreationNamespace(const RangeVar *newRelation);
extern Oid RangeVarGetAndCheckCreationNamespace(RangeVar *newRelation,
          LOCKMODE lockmode,
          Oid *existing_relation_id);
extern void RangeVarAdjustRelationPersistence(RangeVar *newRelation, Oid nspid);
extern Oid RelnameGetRelid(const char *relname);
extern bool RelationIsVisible(Oid relid);

extern Oid TypenameGetTypid(const char *typname);
extern bool TypeIsVisible(Oid typid);

extern FuncCandidateList FuncnameGetCandidates(List *names,
       int nargs, List *argnames,
       bool expand_variadic,
       bool expand_defaults);
extern bool FunctionIsVisible(Oid funcid);

extern Oid OpernameGetOprid(List *names, Oid oprleft, Oid oprright);
extern FuncCandidateList OpernameGetCandidates(List *names, char oprkind);
extern bool OperatorIsVisible(Oid oprid);

extern Oid OpclassnameGetOpcid(Oid amid, const char *opcname);
extern bool OpclassIsVisible(Oid opcid);

extern Oid OpfamilynameGetOpfid(Oid amid, const char *opfname);
extern bool OpfamilyIsVisible(Oid opfid);

extern Oid CollationGetCollid(const char *collname);
extern bool CollationIsVisible(Oid collid);

extern Oid ConversionGetConid(const char *conname);
extern bool ConversionIsVisible(Oid conid);

extern Oid get_ts_parser_oid(List *names, bool missing_ok);
extern bool TSParserIsVisible(Oid prsId);

extern Oid get_ts_dict_oid(List *names, bool missing_ok);
extern bool TSDictionaryIsVisible(Oid dictId);

extern Oid get_ts_template_oid(List *names, bool missing_ok);
extern bool TSTemplateIsVisible(Oid tmplId);

extern Oid get_ts_config_oid(List *names, bool missing_ok);
extern bool TSConfigIsVisible(Oid cfgid);

extern void DeconstructQualifiedName(List *names,
       char **nspname_p,
       char **objname_p);
extern Oid LookupNamespaceNoError(const char *nspname);
extern Oid LookupExplicitNamespace(const char *nspname);
extern Oid get_namespace_oid(const char *nspname, bool missing_ok);

extern Oid LookupCreationNamespace(const char *nspname);
extern void CheckSetNamespace(Oid oldNspOid, Oid nspOid, Oid classid,
      Oid objid);
extern Oid QualifiedNameGetCreationNamespace(List *names, char **objname_p);
extern RangeVar *makeRangeVarFromNameList(List *names);
extern char *NameListToString(List *names);
extern char *NameListToQuotedString(List *names);

extern bool isTempNamespace(Oid namespaceId);
extern bool isTempToastNamespace(Oid namespaceId);
extern bool isTempOrToastNamespace(Oid namespaceId);
extern bool isAnyTempNamespace(Oid namespaceId);
extern bool isOtherTempNamespace(Oid namespaceId);
extern int GetTempNamespaceBackendId(Oid namespaceId);
extern Oid GetTempToastNamespace(void);
extern void ResetTempTableNamespace(void);

extern OverrideSearchPath *GetOverrideSearchPath(MemoryContext context);
extern OverrideSearchPath *CopyOverrideSearchPath(OverrideSearchPath *path);
extern void PushOverrideSearchPath(OverrideSearchPath *newpath);
extern void PopOverrideSearchPath(void);

extern Oid get_collation_oid(List *collname, bool missing_ok);
extern Oid get_conversion_oid(List *conname, bool missing_ok);
extern Oid FindDefaultConversionProc(int4 for_encoding, int4 to_encoding);


extern void InitializeSearchPath(void);
extern void AtEOXact_Namespace(bool isCommit);
extern void AtEOSubXact_Namespace(bool isCommit, SubTransactionId mySubid,
       SubTransactionId parentSubid);


extern char *namespace_search_path;

extern List *fetch_search_path(bool includeImplicit);
extern int fetch_search_path_array(Oid *sarray, int sarray_len);
# 34 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/async.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/async.h"
# 1 "./fmgr.h" 1
# 22 "./fmgr.h"
typedef struct Node *fmNodePtr;


typedef struct StringInfoData *fmStringInfo;
# 34 "./fmgr.h"
typedef struct FunctionCallInfoData *FunctionCallInfo;

typedef Datum (*PGFunction) (FunctionCallInfo fcinfo);
# 49 "./fmgr.h"
typedef struct FmgrInfo
{
 PGFunction fn_addr;
 Oid fn_oid;
 short fn_nargs;

 bool fn_strict;
 bool fn_retset;
 unsigned char fn_stats;
 void *fn_extra;
 MemoryContext fn_mcxt;
 fmNodePtr fn_expr;
} FmgrInfo;




typedef struct FunctionCallInfoData
{
 FmgrInfo *flinfo;
 fmNodePtr context;
 fmNodePtr resultinfo;
 Oid fncollation;
 bool isnull;
 short nargs;
 Datum arg[100];
 bool argnull[100];
} FunctionCallInfoData;





extern void fmgr_info(Oid functionId, FmgrInfo *finfo);






extern void fmgr_info_cxt(Oid functionId, FmgrInfo *finfo,
     MemoryContext mcxt);
# 99 "./fmgr.h"
extern void fmgr_info_copy(FmgrInfo *dstinfo, FmgrInfo *srcinfo,
      MemoryContext destcxt);
# 187 "./fmgr.h"
extern struct varlena *pg_detoast_datum(struct varlena * datum);
extern struct varlena *pg_detoast_datum_copy(struct varlena * datum);
extern struct varlena *pg_detoast_datum_slice(struct varlena * datum,
        int32 first, int32 count);
extern struct varlena *pg_detoast_datum_packed(struct varlena * datum);
# 332 "./fmgr.h"
typedef struct
{
 int api_version;

} Pg_finfo_record;


typedef const Pg_finfo_record *(*PGFInfoFunction) (void);
# 383 "./fmgr.h"
typedef struct
{
 int len;
 int version;
 int funcmaxargs;
 int indexmaxkeys;
 int namedatalen;
 int float4byval;
 int float8byval;
} Pg_magic_struct;
# 410 "./fmgr.h"
typedef const Pg_magic_struct *(*PGModuleMagicFunction) (void);
# 435 "./fmgr.h"
extern Datum DirectFunctionCall1Coll(PGFunction func, Oid collation,
      Datum arg1);
extern Datum DirectFunctionCall2Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2);
extern Datum DirectFunctionCall3Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3);
extern Datum DirectFunctionCall4Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4);
extern Datum DirectFunctionCall5Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5);
extern Datum DirectFunctionCall6Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6);
extern Datum DirectFunctionCall7Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7);
extern Datum DirectFunctionCall8Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8);
extern Datum DirectFunctionCall9Coll(PGFunction func, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8,
      Datum arg9);





extern Datum FunctionCall1Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1);
extern Datum FunctionCall2Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2);
extern Datum FunctionCall3Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3);
extern Datum FunctionCall4Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4);
extern Datum FunctionCall5Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5);
extern Datum FunctionCall6Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6);
extern Datum FunctionCall7Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7);
extern Datum FunctionCall8Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8);
extern Datum FunctionCall9Coll(FmgrInfo *flinfo, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8,
      Datum arg9);







extern Datum OidFunctionCall0Coll(Oid functionId, Oid collation);
extern Datum OidFunctionCall1Coll(Oid functionId, Oid collation,
      Datum arg1);
extern Datum OidFunctionCall2Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2);
extern Datum OidFunctionCall3Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3);
extern Datum OidFunctionCall4Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4);
extern Datum OidFunctionCall5Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5);
extern Datum OidFunctionCall6Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6);
extern Datum OidFunctionCall7Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7);
extern Datum OidFunctionCall8Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8);
extern Datum OidFunctionCall9Coll(Oid functionId, Oid collation,
      Datum arg1, Datum arg2,
      Datum arg3, Datum arg4, Datum arg5,
      Datum arg6, Datum arg7, Datum arg8,
      Datum arg9);
# 602 "./fmgr.h"
extern Datum InputFunctionCall(FmgrInfo *flinfo, char *str,
      Oid typioparam, int32 typmod);
extern Datum OidInputFunctionCall(Oid functionId, char *str,
      Oid typioparam, int32 typmod);
extern char *OutputFunctionCall(FmgrInfo *flinfo, Datum val);
extern char *OidOutputFunctionCall(Oid functionId, Datum val);
extern Datum ReceiveFunctionCall(FmgrInfo *flinfo, fmStringInfo buf,
     Oid typioparam, int32 typmod);
extern Datum OidReceiveFunctionCall(Oid functionId, fmStringInfo buf,
        Oid typioparam, int32 typmod);
extern bytea *SendFunctionCall(FmgrInfo *flinfo, Datum val);
extern bytea *OidSendFunctionCall(Oid functionId, Datum val);





extern const Pg_finfo_record *fetch_finfo_record(void *filehandle, char *funcname);
extern void clear_external_function_hash(void *filehandle);
extern Oid fmgr_internal_function(const char *proname);
extern Oid get_fn_expr_rettype(FmgrInfo *flinfo);
extern Oid get_fn_expr_argtype(FmgrInfo *flinfo, int argnum);
extern Oid get_call_expr_argtype(fmNodePtr expr, int argnum);
extern bool get_fn_expr_arg_stable(FmgrInfo *flinfo, int argnum);
extern bool get_call_expr_arg_stable(fmNodePtr expr, int argnum);




extern char *Dynamic_library_path;

extern PGFunction load_external_function(char *filename, char *funcname,
        bool signalNotFound, void **filehandle);
extern PGFunction lookup_external_function(void *filehandle, char *funcname);
extern void load_file(const char *filename, bool restricted);
extern void **find_rendezvous_variable(const char *varName);
# 650 "./fmgr.h"
extern int AggCheckCallContext(FunctionCallInfo fcinfo,
     MemoryContext *aggcontext);
# 662 "./fmgr.h"
typedef enum FmgrHookEventType
{
 FHET_START,
 FHET_END,
 FHET_ABORT
} FmgrHookEventType;

typedef bool (*needs_fmgr_hook_type) (Oid fn_oid);

typedef void (*fmgr_hook_type) (FmgrHookEventType event,
           FmgrInfo *flinfo, Datum *arg);

extern needs_fmgr_hook_type needs_fmgr_hook;
extern fmgr_hook_type fmgr_hook;
# 693 "./fmgr.h"
extern char *fmgr(Oid procedureId,...);
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/async.h" 2






extern bool Trace_notify;

extern Size AsyncShmemSize(void);
extern void AsyncShmemInit(void);


extern void Async_Notify(const char *channel, const char *payload);
extern void Async_Listen(const char *channel);
extern void Async_Unlisten(const char *channel);
extern void Async_UnlistenAll(void);


extern Datum pg_listening_channels(FunctionCallInfo fcinfo);
extern Datum pg_notify(FunctionCallInfo fcinfo);


extern void PreCommit_Notify(void);
extern void AtCommit_Notify(void);
extern void AtAbort_Notify(void);
extern void AtSubStart_Notify(void);
extern void AtSubCommit_Notify(void);
extern void AtSubAbort_Notify(void);
extern void AtPrepare_Notify(void);
extern void ProcessCompletedNotifies(void);


extern void HandleNotifyInterrupt(void);






extern void EnableNotifyInterrupt(void);
extern bool DisableNotifyInterrupt(void);
# 35 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/prepare.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/prepare.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/explain.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/explain.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/executor.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/executor.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/execdesc.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/execdesc.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/sdir.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/sdir.h"
typedef enum ScanDirection
{
 BackwardScanDirection = -1,
 NoMovementScanDirection = 0,
 ForwardScanDirection = 1
} ScanDirection;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/skey.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/skey.h"
# 1 "./fmgr.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/skey.h" 2







typedef uint16 StrategyNumber;
# 85 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/skey.h"
typedef struct ScanKeyData
{
 int sk_flags;
 AttrNumber sk_attno;
 StrategyNumber sk_strategy;
 Oid sk_subtype;
 Oid sk_collation;
 FmgrInfo sk_func;
 Datum sk_argument;
} ScanKeyData;

typedef ScanKeyData *ScanKey;
# 151 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/skey.h"
extern void ScanKeyInit(ScanKey entry,
   AttrNumber attributeNumber,
   StrategyNumber strategy,
   RegProcedure procedure,
   Datum argument);
extern void ScanKeyEntryInitialize(ScanKey entry,
        int flags,
        AttrNumber attributeNumber,
        StrategyNumber strategy,
        Oid subtype,
        Oid collation,
        RegProcedure procedure,
        Datum argument);
extern void ScanKeyEntryInitializeWithInfo(ScanKey entry,
          int flags,
          AttrNumber attributeNumber,
          StrategyNumber strategy,
          Oid subtype,
          Oid collation,
          FmgrInfo *finfo,
          Datum argument);
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/tidbitmap.h" 1
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/tidbitmap.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h"
typedef struct ItemIdData
{
 unsigned lp_off:15,
    lp_flags:2,
    lp_len:15;
} ItemIdData;

typedef ItemIdData *ItemId;
# 46 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemid.h"
typedef uint16 ItemOffset;
typedef uint16 ItemLength;
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/off.h" 2






typedef uint16 OffsetNumber;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h" 2
# 37 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
typedef struct ItemPointerData
{
 BlockIdData ip_blkid;
 OffsetNumber ip_posid;
}




ItemPointerData;




typedef ItemPointerData *ItemPointer;
# 143 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h"
extern bool ItemPointerEquals(ItemPointer pointer1, ItemPointer pointer2);
extern int32 ItemPointerCompare(ItemPointer arg1, ItemPointer arg2);
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/tidbitmap.h" 2






typedef struct TIDBitmap TIDBitmap;


typedef struct TBMIterator TBMIterator;


typedef struct
{
 BlockNumber blockno;
 int ntuples;
 bool recheck;

 OffsetNumber offsets[1];
} TBMIterateResult;



extern TIDBitmap *tbm_create(long maxbytes);
extern void tbm_free(TIDBitmap *tbm);

extern void tbm_add_tuples(TIDBitmap *tbm,
      const ItemPointer tids, int ntids,
      bool recheck);
extern void tbm_add_page(TIDBitmap *tbm, BlockNumber pageno);

extern void tbm_union(TIDBitmap *a, const TIDBitmap *b);
extern void tbm_intersect(TIDBitmap *a, const TIDBitmap *b);

extern bool tbm_is_empty(const TIDBitmap *tbm);

extern TBMIterator *tbm_begin_iterate(TIDBitmap *tbm);
extern TBMIterateResult *tbm_iterate(TBMIterator *iterator);
extern void tbm_end_iterate(TBMIterator *iterator);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h" 2

# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupmacs.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/item.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/item.h"
typedef Pointer Item;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 2
# 73 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef Pointer Page;
# 82 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef uint16 LocationIndex;
# 122 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
typedef struct PageHeaderData
{

 XLogRecPtr pd_lsn;

 uint16 pd_tli;

 uint16 pd_flags;
 LocationIndex pd_lower;
 LocationIndex pd_upper;
 LocationIndex pd_special;
 uint16 pd_pagesize_version;
 TransactionId pd_prune_xid;
 ItemIdData pd_linp[1];
} PageHeaderData;

typedef PageHeaderData *PageHeader;
# 370 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h"
extern void PageInit(Page page, Size pageSize, Size specialSize);
extern bool PageHeaderIsValid(PageHeader page);
extern OffsetNumber PageAddItem(Page page, Item item, Size size,
   OffsetNumber offsetNumber, bool overwrite, bool is_heap);
extern Page PageGetTempPage(Page page);
extern Page PageGetTempPageCopy(Page page);
extern Page PageGetTempPageCopySpecial(Page page);
extern void PageRestoreTempPage(Page tempPage, Page oldPage);
extern void PageRepairFragmentation(Page page);
extern Size PageGetFreeSpace(Page page);
extern Size PageGetExactFreeSpace(Page page);
extern Size PageGetHeapFreeSpace(Page page);
extern void PageIndexTupleDelete(Page page, OffsetNumber offset);
extern void PageIndexMultiDelete(Page page, OffsetNumber *itemnos, int nitems);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/itemptr.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 2
# 107 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct HeapTupleFields
{
 TransactionId t_xmin;
 TransactionId t_xmax;

 union
 {
  CommandId t_cid;
  TransactionId t_xvac;
 } t_field3;
} HeapTupleFields;

typedef struct DatumTupleFields
{
 int32 datum_len_;

 int32 datum_typmod;

 Oid datum_typeid;





} DatumTupleFields;

typedef struct HeapTupleHeaderData
{
 union
 {
  HeapTupleFields t_heap;
  DatumTupleFields t_datum;
 } t_choice;

 ItemPointerData t_ctid;



 uint16 t_infomask2;

 uint16 t_infomask;

 uint8 t_hoff;



 bits8 t_bits[1];


} HeapTupleHeaderData;

typedef HeapTupleHeaderData *HeapTupleHeader;
# 461 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct MinimalTupleData
{
 uint32 t_len;

 char mt_padding[((__builtin_offsetof (HeapTupleHeaderData, t_infomask2) - sizeof(uint32)) % 8)];



 uint16 t_infomask2;

 uint16 t_infomask;

 uint8 t_hoff;



 bits8 t_bits[1];


} MinimalTupleData;

typedef MinimalTupleData *MinimalTuple;
# 517 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct HeapTupleData
{
 uint32 t_len;
 ItemPointerData t_self;
 Oid t_tableOid;
 HeapTupleHeader t_data;
} HeapTupleData;

typedef HeapTupleData *HeapTuple;
# 621 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heaptid
{
 RelFileNode node;
 ItemPointerData tid;
} xl_heaptid;




typedef struct xl_heap_delete
{
 xl_heaptid target;
 bool all_visible_cleared;
} xl_heap_delete;
# 646 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_header
{
 uint16 t_infomask2;
 uint16 t_infomask;
 uint8 t_hoff;
} xl_heap_header;




typedef struct xl_heap_insert
{
 xl_heaptid target;
 bool all_visible_cleared;

} xl_heap_insert;
# 671 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_multi_insert
{
 RelFileNode node;
 BlockNumber blkno;
 bool all_visible_cleared;
 uint16 ntuples;
 OffsetNumber offsets[1];


} xl_heap_multi_insert;



typedef struct xl_multi_insert_tuple
{
 uint16 datalen;
 uint16 t_infomask2;
 uint16 t_infomask;
 uint8 t_hoff;

} xl_multi_insert_tuple;




typedef struct xl_heap_update
{
 xl_heaptid target;
 ItemPointerData newtid;
 bool all_visible_cleared;
 bool new_all_visible_cleared;

} xl_heap_update;
# 718 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_clean
{
 RelFileNode node;
 BlockNumber block;
 TransactionId latestRemovedXid;
 uint16 nredirected;
 uint16 ndead;

} xl_heap_clean;
# 735 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
typedef struct xl_heap_cleanup_info
{
 RelFileNode node;
 TransactionId latestRemovedXid;
} xl_heap_cleanup_info;





typedef struct xl_heap_newpage
{
 RelFileNode node;
 ForkNumber forknum;
 BlockNumber blkno;

} xl_heap_newpage;




typedef struct xl_heap_lock
{
 xl_heaptid target;
 TransactionId locking_xid;
 bool xid_is_mxact;
 bool shared_lock;
} xl_heap_lock;




typedef struct xl_heap_inplace
{
 xl_heaptid target;

} xl_heap_inplace;




typedef struct xl_heap_freeze
{
 RelFileNode node;
 BlockNumber block;
 TransactionId cutoff_xid;

} xl_heap_freeze;




typedef struct xl_heap_visible
{
 RelFileNode node;
 BlockNumber block;
 TransactionId cutoff_xid;
} xl_heap_visible;



extern void HeapTupleHeaderAdvanceLatestRemovedXid(HeapTupleHeader tuple,
            TransactionId *latestRemovedXid);


extern CommandId HeapTupleHeaderGetCmin(HeapTupleHeader tup);
extern CommandId HeapTupleHeaderGetCmax(HeapTupleHeader tup);
extern void HeapTupleHeaderAdjustCmax(HeapTupleHeader tup,
        CommandId *cmax,
        bool *iscombo);
# 890 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h"
extern Size heap_compute_data_size(TupleDesc tupleDesc,
        Datum *values, bool *isnull);
extern void heap_fill_tuple(TupleDesc tupleDesc,
    Datum *values, bool *isnull,
    char *data, Size data_size,
    uint16 *infomask, bits8 *bit);
extern bool heap_attisnull(HeapTuple tup, int attnum);
extern Datum nocachegetattr(HeapTuple tup, int attnum,
      TupleDesc att);
extern Datum heap_getsysattr(HeapTuple tup, int attnum, TupleDesc tupleDesc,
    bool *isnull);
extern HeapTuple heap_copytuple(HeapTuple tuple);
extern void heap_copytuple_with_tuple(HeapTuple src, HeapTuple dest);
extern HeapTuple heap_form_tuple(TupleDesc tupleDescriptor,
    Datum *values, bool *isnull);
extern HeapTuple heap_modify_tuple(HeapTuple tuple,
      TupleDesc tupleDesc,
      Datum *replValues,
      bool *replIsnull,
      bool *doReplace);
extern void heap_deform_tuple(HeapTuple tuple, TupleDesc tupleDesc,
      Datum *values, bool *isnull);


extern HeapTuple heap_formtuple(TupleDesc tupleDescriptor,
      Datum *values, char *nulls);
extern HeapTuple heap_modifytuple(HeapTuple tuple,
     TupleDesc tupleDesc,
     Datum *replValues,
     char *replNulls,
     char *replActions);
extern void heap_deformtuple(HeapTuple tuple, TupleDesc tupleDesc,
     Datum *values, char *nulls);
extern void heap_freetuple(HeapTuple htup);
extern MinimalTuple heap_form_minimal_tuple(TupleDesc tupleDescriptor,
      Datum *values, bool *isnull);
extern void heap_free_minimal_tuple(MinimalTuple mtup);
extern MinimalTuple heap_copy_minimal_tuple(MinimalTuple mtup);
extern HeapTuple heap_tuple_from_minimal_tuple(MinimalTuple mtup);
extern MinimalTuple minimal_tuple_from_heap_tuple(HeapTuple htup);
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h" 2


typedef struct SnapshotData *Snapshot;
# 30 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h"
typedef bool (*SnapshotSatisfiesFunc) (HeapTupleHeader tuple,
             Snapshot snapshot, Buffer buffer);

typedef struct SnapshotData
{
 SnapshotSatisfiesFunc satisfies;
# 47 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h"
 TransactionId xmin;
 TransactionId xmax;
 TransactionId *xip;
 uint32 xcnt;

 int32 subxcnt;
 TransactionId *subxip;
 bool suboverflowed;
 bool takenDuringRecovery;
 bool copied;





 CommandId curcid;
 uint32 active_count;
 uint32 regd_count;
} SnapshotData;





typedef enum
{
 HeapTupleMayBeUpdated,
 HeapTupleInvisible,
 HeapTupleSelfUpdated,
 HeapTupleUpdated,
 HeapTupleBeingUpdated
} HTSU_Result;
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h" 2




typedef struct IndexBuildResult
{
 double heap_tuples;
 double index_tuples;
} IndexBuildResult;
# 41 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h"
typedef struct IndexVacuumInfo
{
 Relation index;
 bool analyze_only;
 bool estimated_count;
 int message_level;
 double num_heap_tuples;
 BufferAccessStrategy strategy;
} IndexVacuumInfo;
# 68 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h"
typedef struct IndexBulkDeleteResult
{
 BlockNumber num_pages;
 BlockNumber pages_removed;
 bool estimated_count;
 double num_index_tuples;
 double tuples_removed;
 BlockNumber pages_deleted;
 BlockNumber pages_free;
} IndexBulkDeleteResult;


typedef bool (*IndexBulkDeleteCallback) (ItemPointer itemptr, void *state);


typedef struct IndexScanDescData *IndexScanDesc;
typedef struct SysScanDescData *SysScanDesc;
# 106 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h"
typedef enum IndexUniqueCheck
{
 UNIQUE_CHECK_NO,
 UNIQUE_CHECK_YES,
 UNIQUE_CHECK_PARTIAL,
 UNIQUE_CHECK_EXISTING
} IndexUniqueCheck;
# 125 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/genam.h"
extern Relation index_open(Oid relationId, LOCKMODE lockmode);
extern void index_close(Relation relation, LOCKMODE lockmode);

extern bool index_insert(Relation indexRelation,
    Datum *values, bool *isnull,
    ItemPointer heap_t_ctid,
    Relation heapRelation,
    IndexUniqueCheck checkUnique);

extern IndexScanDesc index_beginscan(Relation heapRelation,
    Relation indexRelation,
    Snapshot snapshot,
    int nkeys, int norderbys);
extern IndexScanDesc index_beginscan_bitmap(Relation indexRelation,
        Snapshot snapshot,
        int nkeys);
extern void index_rescan(IndexScanDesc scan,
    ScanKey keys, int nkeys,
    ScanKey orderbys, int norderbys);
extern void index_endscan(IndexScanDesc scan);
extern void index_markpos(IndexScanDesc scan);
extern void index_restrpos(IndexScanDesc scan);
extern ItemPointer index_getnext_tid(IndexScanDesc scan,
      ScanDirection direction);
extern HeapTuple index_fetch_heap(IndexScanDesc scan);
extern HeapTuple index_getnext(IndexScanDesc scan, ScanDirection direction);
extern int64 index_getbitmap(IndexScanDesc scan, TIDBitmap *bitmap);

extern IndexBulkDeleteResult *index_bulk_delete(IndexVacuumInfo *info,
      IndexBulkDeleteResult *stats,
      IndexBulkDeleteCallback callback,
      void *callback_state);
extern IndexBulkDeleteResult *index_vacuum_cleanup(IndexVacuumInfo *info,
      IndexBulkDeleteResult *stats);
extern bool index_can_return(Relation indexRelation);
extern RegProcedure index_getprocid(Relation irel, AttrNumber attnum,
    uint16 procnum);
extern FmgrInfo *index_getprocinfo(Relation irel, AttrNumber attnum,
      uint16 procnum);




extern IndexScanDesc RelationGetIndexScan(Relation indexRelation,
      int nkeys, int norderbys);
extern void IndexScanEnd(IndexScanDesc scan);
extern char *BuildIndexValueDescription(Relation indexRelation,
         Datum *values, bool *isnull);




extern SysScanDesc systable_beginscan(Relation heapRelation,
       Oid indexId,
       bool indexOK,
       Snapshot snapshot,
       int nkeys, ScanKey key);
extern HeapTuple systable_getnext(SysScanDesc sysscan);
extern bool systable_recheck_tuple(SysScanDesc sysscan, HeapTuple tup);
extern void systable_endscan(SysScanDesc sysscan);
extern SysScanDesc systable_beginscan_ordered(Relation heapRelation,
         Relation indexRelation,
         Snapshot snapshot,
         int nkeys, ScanKey key);
extern HeapTuple systable_getnext_ordered(SysScanDesc sysscan,
       ScanDirection direction);
extern void systable_endscan_ordered(SysScanDesc sysscan);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h" 2
# 30 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h"
typedef struct BulkInsertStateData *BulkInsertState;

typedef enum
{
 LockTupleShared,
 LockTupleExclusive
} LockTupleMode;
# 48 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/heapam.h"
extern Relation relation_open(Oid relationId, LOCKMODE lockmode);
extern Relation try_relation_open(Oid relationId, LOCKMODE lockmode);
extern Relation relation_openrv(const RangeVar *relation, LOCKMODE lockmode);
extern Relation relation_openrv_extended(const RangeVar *relation,
       LOCKMODE lockmode, bool missing_ok);
extern void relation_close(Relation relation, LOCKMODE lockmode);

extern Relation heap_open(Oid relationId, LOCKMODE lockmode);
extern Relation heap_openrv(const RangeVar *relation, LOCKMODE lockmode);
extern Relation heap_openrv_extended(const RangeVar *relation,
      LOCKMODE lockmode, bool missing_ok);




typedef struct HeapScanDescData *HeapScanDesc;







extern HeapScanDesc heap_beginscan(Relation relation, Snapshot snapshot,
      int nkeys, ScanKey key);
extern HeapScanDesc heap_beginscan_strat(Relation relation, Snapshot snapshot,
      int nkeys, ScanKey key,
      bool allow_strat, bool allow_sync);
extern HeapScanDesc heap_beginscan_bm(Relation relation, Snapshot snapshot,
      int nkeys, ScanKey key);
extern void heap_rescan(HeapScanDesc scan, ScanKey key);
extern void heap_endscan(HeapScanDesc scan);
extern HeapTuple heap_getnext(HeapScanDesc scan, ScanDirection direction);

extern bool heap_fetch(Relation relation, Snapshot snapshot,
     HeapTuple tuple, Buffer *userbuf, bool keep_buf,
     Relation stats_relation);
extern bool heap_hot_search_buffer(ItemPointer tid, Relation relation,
        Buffer buffer, Snapshot snapshot, HeapTuple heapTuple,
        bool *all_dead, bool first_call);
extern bool heap_hot_search(ItemPointer tid, Relation relation,
    Snapshot snapshot, bool *all_dead);

extern void heap_get_latest_tid(Relation relation, Snapshot snapshot,
     ItemPointer tid);
extern void setLastTid(const ItemPointer tid);

extern BulkInsertState GetBulkInsertState(void);
extern void FreeBulkInsertState(BulkInsertState);

extern Oid heap_insert(Relation relation, HeapTuple tup, CommandId cid,
   int options, BulkInsertState bistate);
extern void heap_multi_insert(Relation relation, HeapTuple *tuples, int ntuples,
      CommandId cid, int options, BulkInsertState bistate);
extern HTSU_Result heap_delete(Relation relation, ItemPointer tid,
   ItemPointer ctid, TransactionId *update_xmax,
   CommandId cid, Snapshot crosscheck, bool wait);
extern HTSU_Result heap_update(Relation relation, ItemPointer otid,
   HeapTuple newtup,
   ItemPointer ctid, TransactionId *update_xmax,
   CommandId cid, Snapshot crosscheck, bool wait);
extern HTSU_Result heap_lock_tuple(Relation relation, HeapTuple tuple,
    Buffer *buffer, ItemPointer ctid,
    TransactionId *update_xmax, CommandId cid,
    LockTupleMode mode, bool nowait);
extern void heap_inplace_update(Relation relation, HeapTuple tuple);
extern bool heap_freeze_tuple(HeapTupleHeader tuple, TransactionId cutoff_xid);
extern bool heap_tuple_needs_freeze(HeapTupleHeader tuple, TransactionId cutoff_xid,
      Buffer buf);

extern Oid simple_heap_insert(Relation relation, HeapTuple tup);
extern void simple_heap_delete(Relation relation, ItemPointer tid);
extern void simple_heap_update(Relation relation, ItemPointer otid,
       HeapTuple tup);

extern void heap_markpos(HeapScanDesc scan);
extern void heap_restrpos(HeapScanDesc scan);

extern void heap_sync(Relation relation);

extern void heap_redo(XLogRecPtr lsn, XLogRecord *rptr);
extern void heap_desc(StringInfo buf, uint8 xl_info, char *rec);
extern void heap2_redo(XLogRecPtr lsn, XLogRecord *rptr);
extern void heap2_desc(StringInfo buf, uint8 xl_info, char *rec);

extern XLogRecPtr log_heap_cleanup_info(RelFileNode rnode,
       TransactionId latestRemovedXid);
extern XLogRecPtr log_heap_clean(Relation reln, Buffer buffer,
      OffsetNumber *redirected, int nredirected,
      OffsetNumber *nowdead, int ndead,
      OffsetNumber *nowunused, int nunused,
      TransactionId latestRemovedXid);
extern XLogRecPtr log_heap_freeze(Relation reln, Buffer buffer,
    TransactionId cutoff_xid,
    OffsetNumber *offsets, int offcnt);
extern XLogRecPtr log_heap_visible(RelFileNode rnode, BlockNumber block,
     Buffer vm_buffer, TransactionId cutoff_xid);
extern XLogRecPtr log_newpage(RelFileNode *rnode, ForkNumber forkNum,
   BlockNumber blk, Page page);


extern void heap_page_prune_opt(Relation relation, Buffer buffer,
     TransactionId OldestXmin);
extern int heap_page_prune(Relation relation, Buffer buffer,
    TransactionId OldestXmin,
    bool report_stats, TransactionId *latestRemovedXid);
extern void heap_page_prune_execute(Buffer buffer,
      OffsetNumber *redirected, int nredirected,
      OffsetNumber *nowdead, int ndead,
      OffsetNumber *nowunused, int nunused);
extern void heap_get_root_tuples(Page page, OffsetNumber *root_offsets);


extern void ss_report_location(Relation rel, BlockNumber location);
extern BlockNumber ss_get_location(Relation rel, BlockNumber relnblocks);
extern void SyncScanShmemInit(void);
extern Size SyncScanShmemSize(void);
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/instrument.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/instrument.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/portability/instr_time.h" 1
# 57 "/Users/parrt/tmp/postgresql-9.2.4/src/include/portability/instr_time.h"
# 1 "/usr/include/sys/time.h" 1 3 4
# 78 "/usr/include/sys/time.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 79 "/usr/include/sys/time.h" 2 3 4
# 94 "/usr/include/sys/time.h" 3 4
struct itimerval {
 struct timeval it_interval;
 struct timeval it_value;
};
# 144 "/usr/include/sys/time.h" 3 4
struct timezone {
 int tz_minuteswest;
 int tz_dsttime;
};
# 187 "/usr/include/sys/time.h" 3 4
struct clockinfo {
 int hz;
 int tick;
 int tickadj;
 int stathz;
 int profhz;
};




# 1 "./time.h" 1 3 4
# 199 "/usr/include/sys/time.h" 2 3 4





int adjtime(const struct timeval *, struct timeval *);
int futimes(int, const struct timeval *);
int lutimes(const char *, const struct timeval *) __attribute__((visibility("default")));
int settimeofday(const struct timeval *, const struct timezone *);


int getitimer(int, struct itimerval *);
int gettimeofday(struct timeval * , void * );

# 1 "/usr/include/sys/_select.h" 1 3 4
# 39 "/usr/include/sys/_select.h" 3 4
int select(int, fd_set * , fd_set * ,
  fd_set * , struct timeval * )




  __asm("_" "select" "$1050")




  ;
# 214 "/usr/include/sys/time.h" 2 3 4

int setitimer(int, const struct itimerval * ,
  struct itimerval * );
int utimes(const char *, const struct timeval *);


# 58 "/Users/parrt/tmp/postgresql-9.2.4/src/include/portability/instr_time.h" 2

typedef struct timeval instr_time;
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/instrument.h" 2


typedef struct BufferUsage
{
 long shared_blks_hit;
 long shared_blks_read;
 long shared_blks_dirtied;
 long shared_blks_written;
 long local_blks_hit;
 long local_blks_read;
 long local_blks_dirtied;
 long local_blks_written;
 long temp_blks_read;
 long temp_blks_written;
 instr_time blk_read_time;
 instr_time blk_write_time;
} BufferUsage;


typedef enum InstrumentOption
{
 INSTRUMENT_TIMER = 1 << 0,
 INSTRUMENT_BUFFERS = 1 << 1,
 INSTRUMENT_ROWS = 1 << 2,
 INSTRUMENT_ALL = 0x7FFFFFFF
} InstrumentOption;

typedef struct Instrumentation
{

 bool need_timer;
 bool need_bufusage;

 bool running;
 instr_time starttime;
 instr_time counter;
 double firsttuple;
 double tuplecount;
 BufferUsage bufusage_start;

 double startup;
 double total;
 double ntuples;
 double nloops;
 double nfiltered1;
 double nfiltered2;
 BufferUsage bufusage;
} Instrumentation;

extern BufferUsage pgBufferUsage;

extern Instrumentation *InstrAlloc(int n, int instrument_options);
extern void InstrStartNode(Instrumentation *instr);
extern void InstrStopNode(Instrumentation *instr, double nTuples);
extern void InstrEndLoop(Instrumentation *instr);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/params.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/params.h"
struct ParseState;
# 53 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/params.h"
typedef struct ParamExternData
{
 Datum value;
 bool isnull;
 uint16 pflags;
 Oid ptype;
} ParamExternData;

typedef struct ParamListInfoData *ParamListInfo;

typedef void (*ParamFetchHook) (ParamListInfo params, int paramid);

typedef void (*ParserSetupHook) (struct ParseState *pstate, void *arg);

typedef struct ParamListInfoData
{
 ParamFetchHook paramFetch;
 void *paramFetchArg;
 ParserSetupHook parserSetup;
 void *parserSetupArg;
 int numParams;
 ParamExternData params[1];
} ParamListInfoData;
# 95 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/params.h"
typedef struct ParamExecData
{
 void *execPlan;
 Datum value;
 bool isnull;
} ParamExecData;



extern ParamListInfo copyParamList(ParamListInfo from);
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/sdir.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/bitmapset.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h" 2
# 34 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct PlannedStmt
{
 NodeTag type;

 CmdType commandType;

 uint32 queryId;

 bool hasReturning;

 bool hasModifyingCTE;

 bool canSetTag;

 bool transientPlan;

 struct Plan *planTree;

 List *rtable;


 List *resultRelations;

 Node *utilityStmt;

 List *subplans;

 Bitmapset *rewindPlanIDs;

 List *rowMarks;

 List *relationOids;

 List *invalItems;

 int nParamExec;
} PlannedStmt;
# 89 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct Plan
{
 NodeTag type;




 Cost startup_cost;
 Cost total_cost;




 double plan_rows;
 int plan_width;




 List *targetlist;
 List *qual;
 struct Plan *lefttree;
 struct Plan *righttree;
 List *initPlan;
# 126 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
 Bitmapset *extParam;
 Bitmapset *allParam;
} Plan;
# 152 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct Result
{
 Plan plan;
 Node *resconstantqual;
} Result;
# 167 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct ModifyTable
{
 Plan plan;
 CmdType operation;
 bool canSetTag;
 List *resultRelations;
 int resultRelIndex;
 List *plans;
 List *returningLists;
 List *rowMarks;
 int epqParam;
} ModifyTable;






typedef struct Append
{
 Plan plan;
 List *appendplans;
} Append;






typedef struct MergeAppend
{
 Plan plan;
 List *mergeplans;

 int numCols;
 AttrNumber *sortColIdx;
 Oid *sortOperators;
 Oid *collations;
 bool *nullsFirst;
} MergeAppend;
# 216 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct RecursiveUnion
{
 Plan plan;
 int wtParam;

 int numCols;

 AttrNumber *dupColIdx;
 Oid *dupOperators;
 long numGroups;
} RecursiveUnion;
# 236 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct BitmapAnd
{
 Plan plan;
 List *bitmapplans;
} BitmapAnd;
# 250 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct BitmapOr
{
 Plan plan;
 List *bitmapplans;
} BitmapOr;






typedef struct Scan
{
 Plan plan;
 Index scanrelid;
} Scan;





typedef Scan SeqScan;
# 305 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct IndexScan
{
 Scan scan;
 Oid indexid;
 List *indexqual;
 List *indexqualorig;
 List *indexorderby;
 List *indexorderbyorig;
 ScanDirection indexorderdir;
} IndexScan;
# 333 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct IndexOnlyScan
{
 Scan scan;
 Oid indexid;
 List *indexqual;
 List *indexorderby;
 List *indextlist;
 ScanDirection indexorderdir;
} IndexOnlyScan;
# 360 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct BitmapIndexScan
{
 Scan scan;
 Oid indexid;
 List *indexqual;
 List *indexqualorig;
} BitmapIndexScan;
# 377 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct BitmapHeapScan
{
 Scan scan;
 List *bitmapqualorig;
} BitmapHeapScan;
# 390 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct TidScan
{
 Scan scan;
 List *tidquals;
} TidScan;
# 412 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct SubqueryScan
{
 Scan scan;
 Plan *subplan;
} SubqueryScan;





typedef struct FunctionScan
{
 Scan scan;
 Node *funcexpr;
 List *funccolnames;
 List *funccoltypes;
 List *funccoltypmods;
 List *funccolcollations;
} FunctionScan;





typedef struct ValuesScan
{
 Scan scan;
 List *values_lists;
} ValuesScan;





typedef struct CteScan
{
 Scan scan;
 int ctePlanId;
 int cteParam;
} CteScan;





typedef struct WorkTableScan
{
 Scan scan;
 int wtParam;
} WorkTableScan;
# 475 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct ForeignScan
{
 Scan scan;
 List *fdw_exprs;
 List *fdw_private;
 bool fsSystemCol;
} ForeignScan;
# 506 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct Join
{
 Plan plan;
 JoinType jointype;
 List *joinqual;
} Join;
# 524 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct NestLoop
{
 Join join;
 List *nestParams;
} NestLoop;

typedef struct NestLoopParam
{
 NodeTag type;
 int paramno;
 Var *paramval;
} NestLoopParam;
# 548 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct MergeJoin
{
 Join join;
 List *mergeclauses;

 Oid *mergeFamilies;
 Oid *mergeCollations;
 int *mergeStrategies;
 bool *mergeNullsFirst;
} MergeJoin;





typedef struct HashJoin
{
 Join join;
 List *hashclauses;
} HashJoin;





typedef struct Material
{
 Plan plan;
} Material;





typedef struct Sort
{
 Plan plan;
 int numCols;
 AttrNumber *sortColIdx;
 Oid *sortOperators;
 Oid *collations;
 bool *nullsFirst;
} Sort;







typedef struct Group
{
 Plan plan;
 int numCols;
 AttrNumber *grpColIdx;
 Oid *grpOperators;
} Group;
# 620 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef enum AggStrategy
{
 AGG_PLAIN,
 AGG_SORTED,
 AGG_HASHED
} AggStrategy;

typedef struct Agg
{
 Plan plan;
 AggStrategy aggstrategy;
 int numCols;
 AttrNumber *grpColIdx;
 Oid *grpOperators;
 long numGroups;
} Agg;





typedef struct WindowAgg
{
 Plan plan;
 Index winref;
 int partNumCols;
 AttrNumber *partColIdx;
 Oid *partOperators;
 int ordNumCols;
 AttrNumber *ordColIdx;
 Oid *ordOperators;
 int frameOptions;
 Node *startOffset;
 Node *endOffset;
} WindowAgg;





typedef struct Unique
{
 Plan plan;
 int numCols;
 AttrNumber *uniqColIdx;
 Oid *uniqOperators;
} Unique;
# 677 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct Hash
{
 Plan plan;
 Oid skewTable;
 AttrNumber skewColumn;
 bool skewInherit;
 Oid skewColType;
 int32 skewColTypmod;

} Hash;





typedef enum SetOpCmd
{
 SETOPCMD_INTERSECT,
 SETOPCMD_INTERSECT_ALL,
 SETOPCMD_EXCEPT,
 SETOPCMD_EXCEPT_ALL
} SetOpCmd;

typedef enum SetOpStrategy
{
 SETOP_SORTED,
 SETOP_HASHED
} SetOpStrategy;

typedef struct SetOp
{
 Plan plan;
 SetOpCmd cmd;
 SetOpStrategy strategy;
 int numCols;

 AttrNumber *dupColIdx;
 Oid *dupOperators;
 AttrNumber flagColIdx;
 int firstFlag;
 long numGroups;
} SetOp;
# 729 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct LockRows
{
 Plan plan;
 List *rowMarks;
 int epqParam;
} LockRows;
# 743 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct Limit
{
 Plan plan;
 Node *limitOffset;
 Node *limitCount;
} Limit;
# 763 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef enum RowMarkType
{
 ROW_MARK_EXCLUSIVE,
 ROW_MARK_SHARE,
 ROW_MARK_REFERENCE,
 ROW_MARK_COPY
} RowMarkType;
# 807 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct PlanRowMark
{
 NodeTag type;
 Index rti;
 Index prti;
 Index rowmarkId;
 RowMarkType markType;
 bool noWait;
 bool isParent;
} PlanRowMark;
# 828 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h"
typedef struct PlanInvalItem
{
 NodeTag type;
 int cacheId;
 uint32 hashValue;
} PlanInvalItem;
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/reltrigger.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/reltrigger.h"
typedef struct Trigger
{
 Oid tgoid;

 char *tgname;
 Oid tgfoid;
 int16 tgtype;
 char tgenabled;
 bool tgisinternal;
 Oid tgconstrrelid;
 Oid tgconstrindid;
 Oid tgconstraint;
 bool tgdeferrable;
 bool tginitdeferred;
 int16 tgnargs;
 int16 tgnattr;
 int16 *tgattr;
 char **tgargs;
 char *tgqual;
} Trigger;

typedef struct TriggerDesc
{
 Trigger *triggers;
 int numtriggers;





 bool trig_insert_before_row;
 bool trig_insert_after_row;
 bool trig_insert_instead_row;
 bool trig_insert_before_statement;
 bool trig_insert_after_statement;
 bool trig_update_before_row;
 bool trig_update_after_row;
 bool trig_update_instead_row;
 bool trig_update_before_statement;
 bool trig_update_after_statement;
 bool trig_delete_before_row;
 bool trig_delete_after_row;
 bool trig_delete_instead_row;
 bool trig_delete_before_statement;
 bool trig_delete_after_statement;

 bool trig_truncate_before_statement;
 bool trig_truncate_after_statement;
} TriggerDesc;
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/sortsupport.h" 1
# 50 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/sortsupport.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/attnum.h" 1
# 51 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/sortsupport.h" 2

typedef struct SortSupportData *SortSupport;

typedef struct SortSupportData
{




 MemoryContext ssup_cxt;
 Oid ssup_collation;






 bool ssup_reverse;
 bool ssup_nulls_first;





 AttrNumber ssup_attno;





 void *ssup_extra;
# 96 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/sortsupport.h"
 int (*comparator) (Datum x, Datum y, SortSupport ssup);




} SortSupportData;
# 111 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/sortsupport.h"
static inline int
ApplySortComparator(Datum datum1, bool isNull1,
     Datum datum2, bool isNull2,
     SortSupport ssup)
{
 int compare;

 if (isNull1)
 {
  if (isNull2)
   compare = 0;
  else if (ssup->ssup_nulls_first)
   compare = -1;
  else
   compare = 1;
 }
 else if (isNull2)
 {
  if (ssup->ssup_nulls_first)
   compare = 1;
  else
   compare = -1;
 }
 else
 {
  compare = (*ssup->comparator) (datum1, datum2, ssup);
  if (ssup->ssup_reverse)
   compare = -compare;
 }

 return compare;
}
# 151 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/sortsupport.h"
extern void PrepareSortSupportComparisonShim(Oid cmpFunc, SortSupport ssup);
extern void PrepareSortSupportFromOrderingOp(Oid orderingOp, SortSupport ssup);
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/tuplestore.h" 1
# 34 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/tuplestore.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 2
# 112 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
typedef struct TupleTableSlot
{
 NodeTag type;
 bool tts_isempty;
 bool tts_shouldFree;
 bool tts_shouldFreeMin;
 bool tts_slow;
 HeapTuple tts_tuple;
 TupleDesc tts_tupleDescriptor;
 MemoryContext tts_mcxt;
 Buffer tts_buffer;
 int tts_nvalid;
 Datum *tts_values;
 bool *tts_isnull;
 MinimalTuple tts_mintuple;
 HeapTupleData tts_minhdr;
 long tts_off;
} TupleTableSlot;
# 141 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h"
extern TupleTableSlot *MakeTupleTableSlot(void);
extern TupleTableSlot *ExecAllocTableSlot(List **tupleTable);
extern void ExecResetTupleTable(List *tupleTable, bool shouldFree);
extern TupleTableSlot *MakeSingleTupleTableSlot(TupleDesc tupdesc);
extern void ExecDropSingleTupleTableSlot(TupleTableSlot *slot);
extern void ExecSetSlotDescriptor(TupleTableSlot *slot, TupleDesc tupdesc);
extern TupleTableSlot *ExecStoreTuple(HeapTuple tuple,
      TupleTableSlot *slot,
      Buffer buffer,
      bool shouldFree);
extern TupleTableSlot *ExecStoreMinimalTuple(MinimalTuple mtup,
       TupleTableSlot *slot,
       bool shouldFree);
extern TupleTableSlot *ExecClearTuple(TupleTableSlot *slot);
extern TupleTableSlot *ExecStoreVirtualTuple(TupleTableSlot *slot);
extern TupleTableSlot *ExecStoreAllNullTuple(TupleTableSlot *slot);
extern HeapTuple ExecCopySlotTuple(TupleTableSlot *slot);
extern MinimalTuple ExecCopySlotMinimalTuple(TupleTableSlot *slot);
extern HeapTuple ExecFetchSlotTuple(TupleTableSlot *slot);
extern MinimalTuple ExecFetchSlotMinimalTuple(TupleTableSlot *slot);
extern Datum ExecFetchSlotTupleDatum(TupleTableSlot *slot);
extern HeapTuple ExecMaterializeSlot(TupleTableSlot *slot);
extern TupleTableSlot *ExecCopySlot(TupleTableSlot *dstslot,
    TupleTableSlot *srcslot);


extern Datum slot_getattr(TupleTableSlot *slot, int attnum, bool *isnull);
extern void slot_getallattrs(TupleTableSlot *slot);
extern void slot_getsomeattrs(TupleTableSlot *slot, int attnum);
extern bool slot_attisnull(TupleTableSlot *slot, int attnum);
# 35 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/tuplestore.h" 2





typedef struct Tuplestorestate Tuplestorestate;






extern Tuplestorestate *tuplestore_begin_heap(bool randomAccess,
       bool interXact,
       int maxKBytes);

extern void tuplestore_set_eflags(Tuplestorestate *state, int eflags);

extern void tuplestore_puttupleslot(Tuplestorestate *state,
      TupleTableSlot *slot);
extern void tuplestore_puttuple(Tuplestorestate *state, HeapTuple tuple);
extern void tuplestore_putvalues(Tuplestorestate *state, TupleDesc tdesc,
      Datum *values, bool *isnull);




extern int tuplestore_alloc_read_pointer(Tuplestorestate *state, int eflags);

extern void tuplestore_select_read_pointer(Tuplestorestate *state, int ptr);

extern void tuplestore_copy_read_pointer(Tuplestorestate *state,
        int srcptr, int destptr);

extern void tuplestore_trim(Tuplestorestate *state);

extern bool tuplestore_in_memory(Tuplestorestate *state);

extern bool tuplestore_gettupleslot(Tuplestorestate *state, bool forward,
      bool copy, TupleTableSlot *slot);
extern bool tuplestore_advance(Tuplestorestate *state, bool forward);

extern bool tuplestore_ateof(Tuplestorestate *state);

extern void tuplestore_rescan(Tuplestorestate *state);

extern void tuplestore_clear(Tuplestorestate *state);

extern void tuplestore_end(Tuplestorestate *state);
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 2
# 53 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct IndexInfo
{
 NodeTag type;
 int ii_NumIndexAttrs;
 AttrNumber ii_KeyAttrNumbers[32];
 List *ii_Expressions;
 List *ii_ExpressionsState;
 List *ii_Predicate;
 List *ii_PredicateState;
 Oid *ii_ExclusionOps;
 Oid *ii_ExclusionProcs;
 uint16 *ii_ExclusionStrats;
 bool ii_Unique;
 bool ii_ReadyForInserts;
 bool ii_Concurrent;
 bool ii_BrokenHotChain;
} IndexInfo;







typedef void (*ExprContextCallbackFunction) (Datum arg);

typedef struct ExprContext_CB
{
 struct ExprContext_CB *next;
 ExprContextCallbackFunction function;
 Datum arg;
} ExprContext_CB;
# 109 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ExprContext
{
 NodeTag type;


 TupleTableSlot *ecxt_scantuple;
 TupleTableSlot *ecxt_innertuple;
 TupleTableSlot *ecxt_outertuple;


 MemoryContext ecxt_per_query_memory;
 MemoryContext ecxt_per_tuple_memory;


 ParamExecData *ecxt_param_exec_vals;
 ParamListInfo ecxt_param_list_info;





 Datum *ecxt_aggvalues;
 bool *ecxt_aggnulls;


 Datum caseValue_datum;
 bool caseValue_isNull;


 Datum domainValue_datum;
 bool domainValue_isNull;


 struct EState *ecxt_estate;


 ExprContext_CB *ecxt_callbacks;
} ExprContext;




typedef enum
{
 ExprSingleResult,
 ExprMultipleResult,
 ExprEndResult
} ExprDoneCond;







typedef enum
{
 SFRM_ValuePerCall = 0x01,
 SFRM_Materialize = 0x02,
 SFRM_Materialize_Random = 0x04,
 SFRM_Materialize_Preferred = 0x08
} SetFunctionReturnMode;







typedef struct ReturnSetInfo
{
 NodeTag type;

 ExprContext *econtext;
 TupleDesc expectedDesc;
 int allowedModes;

 SetFunctionReturnMode returnMode;
 ExprDoneCond isDone;

 Tuplestorestate *setResult;
 TupleDesc setDesc;
} ReturnSetInfo;
# 232 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ProjectionInfo
{
 NodeTag type;
 List *pi_targetlist;
 ExprContext *pi_exprContext;
 TupleTableSlot *pi_slot;
 ExprDoneCond *pi_itemIsDone;
 bool pi_directMap;
 int pi_numSimpleVars;
 int *pi_varSlotOffsets;
 int *pi_varNumbers;
 int *pi_varOutputCols;
 int pi_lastInnerVar;
 int pi_lastOuterVar;
 int pi_lastScanVar;
} ProjectionInfo;
# 276 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct JunkFilter
{
 NodeTag type;
 List *jf_targetList;
 TupleDesc jf_cleanTupType;
 AttrNumber *jf_cleanMap;
 TupleTableSlot *jf_resultSlot;
 AttrNumber jf_junkAttNo;
} JunkFilter;
# 308 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ResultRelInfo
{
 NodeTag type;
 Index ri_RangeTableIndex;
 Relation ri_RelationDesc;
 int ri_NumIndices;
 RelationPtr ri_IndexRelationDescs;
 IndexInfo **ri_IndexRelationInfo;
 TriggerDesc *ri_TrigDesc;
 FmgrInfo *ri_TrigFunctions;
 List **ri_TrigWhenExprs;
 Instrumentation *ri_TrigInstrument;
 List **ri_ConstraintExprs;
 JunkFilter *ri_junkFilter;
 ProjectionInfo *ri_projectReturning;
} ResultRelInfo;







typedef struct EState
{
 NodeTag type;


 ScanDirection es_direction;
 Snapshot es_snapshot;
 Snapshot es_crosscheck_snapshot;
 List *es_range_table;
 PlannedStmt *es_plannedstmt;

 JunkFilter *es_junkFilter;


 CommandId es_output_cid;


 ResultRelInfo *es_result_relations;
 int es_num_result_relations;
 ResultRelInfo *es_result_relation_info;


 List *es_trig_target_relations;
 TupleTableSlot *es_trig_tuple_slot;
 TupleTableSlot *es_trig_oldtup_slot;
 TupleTableSlot *es_trig_newtup_slot;


 ParamListInfo es_param_list_info;
 ParamExecData *es_param_exec_vals;


 MemoryContext es_query_cxt;

 List *es_tupleTable;

 List *es_rowMarks;

 uint32 es_processed;
 Oid es_lastoid;

 int es_top_eflags;
 int es_instrument;
 bool es_finished;

 List *es_exprcontexts;

 List *es_subplanstates;

 List *es_auxmodifytables;






 ExprContext *es_per_tuple_exprcontext;
# 398 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
 HeapTuple *es_epqTuple;
 bool *es_epqTupleSet;
 bool *es_epqScanDone;
} EState;
# 416 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ExecRowMark
{
 Relation relation;
 Index rti;
 Index prti;
 Index rowmarkId;
 RowMarkType markType;
 bool noWait;
 ItemPointerData curCtid;
} ExecRowMark;
# 439 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ExecAuxRowMark
{
 ExecRowMark *rowmark;
 AttrNumber ctidAttNo;
 AttrNumber toidAttNo;
 AttrNumber wholeAttNo;
} ExecAuxRowMark;
# 464 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct TupleHashEntryData *TupleHashEntry;
typedef struct TupleHashTableData *TupleHashTable;

typedef struct TupleHashEntryData
{

 MinimalTuple firstTuple;

} TupleHashEntryData;

typedef struct TupleHashTableData
{
 HTAB *hashtab;
 int numCols;
 AttrNumber *keyColIdx;
 FmgrInfo *tab_hash_funcs;
 FmgrInfo *tab_eq_funcs;
 MemoryContext tablecxt;
 MemoryContext tempcxt;
 Size entrysize;
 TupleTableSlot *tableslot;

 TupleTableSlot *inputslot;
 FmgrInfo *in_hash_funcs;
 FmgrInfo *cur_eq_funcs;
} TupleHashTableData;

typedef HASH_SEQ_STATUS TupleHashIterator;
# 536 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ExprState ExprState;

typedef Datum (*ExprStateEvalFunc) (ExprState *expression,
            ExprContext *econtext,
            bool *isNull,
            ExprDoneCond *isDone);

struct ExprState
{
 NodeTag type;
 Expr *expr;
 ExprStateEvalFunc evalfunc;
};
# 557 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct GenericExprState
{
 ExprState xprstate;
 ExprState *arg;
} GenericExprState;





typedef struct WholeRowVarExprState
{
 ExprState xprstate;
 struct PlanState *parent;
 JunkFilter *wrv_junkFilter;
} WholeRowVarExprState;





typedef struct AggrefExprState
{
 ExprState xprstate;
 List *args;
 int aggno;
} AggrefExprState;





typedef struct WindowFuncExprState
{
 ExprState xprstate;
 List *args;
 int wfuncno;
} WindowFuncExprState;
# 604 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ArrayRefExprState
{
 ExprState xprstate;
 List *refupperindexpr;
 List *reflowerindexpr;
 ExprState *refexpr;
 ExprState *refassgnexpr;
 int16 refattrlength;
 int16 refelemlength;
 bool refelembyval;
 char refelemalign;
} ArrayRefExprState;
# 625 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct FuncExprState
{
 ExprState xprstate;
 List *args;






 FmgrInfo func;






 Tuplestorestate *funcResultStore;
 TupleTableSlot *funcResultSlot;





 TupleDesc funcResultDesc;
 bool funcReturnsTuple;
# 660 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
 bool setArgsValid;






 bool setHasSetArg;







 bool shutdown_reg;






 FunctionCallInfoData fcinfo_data;
} FuncExprState;







typedef struct ScalarArrayOpExprState
{
 FuncExprState fxprstate;

 Oid element_type;
 int16 typlen;
 bool typbyval;
 char typalign;
} ScalarArrayOpExprState;





typedef struct BoolExprState
{
 ExprState xprstate;
 List *args;
} BoolExprState;





typedef struct SubPlanState
{
 ExprState xprstate;
 struct PlanState *planstate;
 ExprState *testexpr;
 List *args;
 HeapTuple curTuple;
 Datum curArray;

 ProjectionInfo *projLeft;
 ProjectionInfo *projRight;
 TupleHashTable hashtable;
 TupleHashTable hashnulls;
 bool havehashrows;
 bool havenullrows;
 MemoryContext hashtablecxt;
 MemoryContext hashtempcxt;
 ExprContext *innerecontext;
 AttrNumber *keyColIdx;
 FmgrInfo *tab_hash_funcs;
 FmgrInfo *tab_eq_funcs;
 FmgrInfo *lhs_hash_funcs;
 FmgrInfo *cur_eq_funcs;
} SubPlanState;





typedef struct AlternativeSubPlanState
{
 ExprState xprstate;
 List *subplans;
 int active;
} AlternativeSubPlanState;





typedef struct FieldSelectState
{
 ExprState xprstate;
 ExprState *arg;
 TupleDesc argdesc;
} FieldSelectState;





typedef struct FieldStoreState
{
 ExprState xprstate;
 ExprState *arg;
 List *newvals;
 TupleDesc argdesc;
} FieldStoreState;





typedef struct CoerceViaIOState
{
 ExprState xprstate;
 ExprState *arg;
 FmgrInfo outfunc;
 FmgrInfo infunc;
 Oid intypioparam;
} CoerceViaIOState;





typedef struct ArrayCoerceExprState
{
 ExprState xprstate;
 ExprState *arg;
 Oid resultelemtype;
 FmgrInfo elemfunc;

 struct ArrayMapState *amstate;
} ArrayCoerceExprState;





typedef struct ConvertRowtypeExprState
{
 ExprState xprstate;
 ExprState *arg;
 TupleDesc indesc;
 TupleDesc outdesc;

 struct TupleConversionMap *map;
 bool initialized;
} ConvertRowtypeExprState;





typedef struct CaseExprState
{
 ExprState xprstate;
 ExprState *arg;
 List *args;
 ExprState *defresult;
} CaseExprState;





typedef struct CaseWhenState
{
 ExprState xprstate;
 ExprState *expr;
 ExprState *result;
} CaseWhenState;
# 846 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ArrayExprState
{
 ExprState xprstate;
 List *elements;
 int16 elemlength;
 bool elembyval;
 char elemalign;
} ArrayExprState;





typedef struct RowExprState
{
 ExprState xprstate;
 List *args;
 TupleDesc tupdesc;
} RowExprState;





typedef struct RowCompareExprState
{
 ExprState xprstate;
 List *largs;
 List *rargs;
 FmgrInfo *funcs;
 Oid *collations;
} RowCompareExprState;





typedef struct CoalesceExprState
{
 ExprState xprstate;
 List *args;
} CoalesceExprState;





typedef struct MinMaxExprState
{
 ExprState xprstate;
 List *args;
 FmgrInfo cfunc;
} MinMaxExprState;





typedef struct XmlExprState
{
 ExprState xprstate;
 List *named_args;
 List *args;
} XmlExprState;





typedef struct NullTestState
{
 ExprState xprstate;
 ExprState *arg;

 TupleDesc argdesc;
} NullTestState;





typedef struct CoerceToDomainState
{
 ExprState xprstate;
 ExprState *arg;

 List *constraints;
} CoerceToDomainState;
# 942 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef enum DomainConstraintType
{
 DOM_CONSTRAINT_NOTNULL,
 DOM_CONSTRAINT_CHECK
} DomainConstraintType;

typedef struct DomainConstraintState
{
 NodeTag type;
 DomainConstraintType constrainttype;
 char *name;
 ExprState *check_expr;
} DomainConstraintState;
# 972 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct PlanState
{
 NodeTag type;

 Plan *plan;

 EState *state;



 Instrumentation *instrument;






 List *targetlist;
 List *qual;
 struct PlanState *lefttree;
 struct PlanState *righttree;
 List *initPlan;

 List *subPlan;




 Bitmapset *chgParam;




 TupleTableSlot *ps_ResultTupleSlot;
 ExprContext *ps_ExprContext;
 ProjectionInfo *ps_ProjInfo;
 bool ps_TupFromTlist;

} PlanState;
# 1039 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct EPQState
{
 EState *estate;
 PlanState *planstate;
 TupleTableSlot *origslot;
 Plan *plan;
 List *arowMarks;
 int epqParam;
} EPQState;






typedef struct ResultState
{
 PlanState ps;
 ExprState *resconstantqual;
 bool rs_done;
 bool rs_checkqual;
} ResultState;





typedef struct ModifyTableState
{
 PlanState ps;
 CmdType operation;
 bool canSetTag;
 bool mt_done;
 PlanState **mt_plans;
 int mt_nplans;
 int mt_whichplan;
 ResultRelInfo *resultRelInfo;
 List **mt_arowmarks;
 EPQState mt_epqstate;
 bool fireBSTriggers;
} ModifyTableState;
# 1088 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct AppendState
{
 PlanState ps;
 PlanState **appendplans;
 int as_nplans;
 int as_whichplan;
} AppendState;
# 1109 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct MergeAppendState
{
 PlanState ps;
 PlanState **mergeplans;
 int ms_nplans;
 int ms_nkeys;
 SortSupport ms_sortkeys;
 TupleTableSlot **ms_slots;
 int *ms_heap;
 int ms_heap_size;
 bool ms_initialized;
 int ms_last_slot;
} MergeAppendState;
# 1134 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct RecursiveUnionState
{
 PlanState ps;
 bool recursing;
 bool intermediate_empty;
 Tuplestorestate *working_table;
 Tuplestorestate *intermediate_table;

 FmgrInfo *eqfunctions;
 FmgrInfo *hashfunctions;
 MemoryContext tempContext;
 TupleHashTable hashtable;
 MemoryContext tableContext;
} RecursiveUnionState;





typedef struct BitmapAndState
{
 PlanState ps;
 PlanState **bitmapplans;
 int nplans;
} BitmapAndState;





typedef struct BitmapOrState
{
 PlanState ps;
 PlanState **bitmapplans;
 int nplans;
} BitmapOrState;
# 1190 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ScanState
{
 PlanState ps;
 Relation ss_currentRelation;
 HeapScanDesc ss_currentScanDesc;
 TupleTableSlot *ss_ScanTupleSlot;
} ScanState;





typedef ScanState SeqScanState;






typedef struct
{
 ScanKey scan_key;
 ExprState *key_expr;
 bool key_toastable;
} IndexRuntimeKeyInfo;

typedef struct
{
 ScanKey scan_key;
 ExprState *array_expr;
 int next_elem;
 int num_elems;
 Datum *elem_values;
 bool *elem_nulls;
} IndexArrayKeyInfo;
# 1242 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct IndexScanState
{
 ScanState ss;
 List *indexqualorig;
 ScanKey iss_ScanKeys;
 int iss_NumScanKeys;
 ScanKey iss_OrderByKeys;
 int iss_NumOrderByKeys;
 IndexRuntimeKeyInfo *iss_RuntimeKeys;
 int iss_NumRuntimeKeys;
 bool iss_RuntimeKeysReady;
 ExprContext *iss_RuntimeContext;
 Relation iss_RelationDesc;
 IndexScanDesc iss_ScanDesc;
} IndexScanState;
# 1276 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct IndexOnlyScanState
{
 ScanState ss;
 List *indexqual;
 ScanKey ioss_ScanKeys;
 int ioss_NumScanKeys;
 ScanKey ioss_OrderByKeys;
 int ioss_NumOrderByKeys;
 IndexRuntimeKeyInfo *ioss_RuntimeKeys;
 int ioss_NumRuntimeKeys;
 bool ioss_RuntimeKeysReady;
 ExprContext *ioss_RuntimeContext;
 Relation ioss_RelationDesc;
 IndexScanDesc ioss_ScanDesc;
 Buffer ioss_VMBuffer;
 long ioss_HeapFetches;
} IndexOnlyScanState;
# 1310 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct BitmapIndexScanState
{
 ScanState ss;
 TIDBitmap *biss_result;
 ScanKey biss_ScanKeys;
 int biss_NumScanKeys;
 IndexRuntimeKeyInfo *biss_RuntimeKeys;
 int biss_NumRuntimeKeys;
 IndexArrayKeyInfo *biss_ArrayKeys;
 int biss_NumArrayKeys;
 bool biss_RuntimeKeysReady;
 ExprContext *biss_RuntimeContext;
 Relation biss_RelationDesc;
 IndexScanDesc biss_ScanDesc;
} BitmapIndexScanState;
# 1338 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct BitmapHeapScanState
{
 ScanState ss;
 List *bitmapqualorig;
 TIDBitmap *tbm;
 TBMIterator *tbmiterator;
 TBMIterateResult *tbmres;
 TBMIterator *prefetch_iterator;
 int prefetch_pages;
 int prefetch_target;
} BitmapHeapScanState;
# 1359 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct TidScanState
{
 ScanState ss;
 List *tss_tidquals;
 bool tss_isCurrentOf;
 int tss_NumTids;
 int tss_TidPtr;
 int tss_MarkTidPtr;
 ItemPointerData *tss_TidList;
 HeapTupleData tss_htup;
} TidScanState;
# 1378 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct SubqueryScanState
{
 ScanState ss;
 PlanState *subplan;
} SubqueryScanState;
# 1396 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct FunctionScanState
{
 ScanState ss;
 int eflags;
 TupleDesc tupdesc;
 Tuplestorestate *tuplestorestate;
 ExprState *funcexpr;
} FunctionScanState;
# 1423 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct ValuesScanState
{
 ScanState ss;
 ExprContext *rowcontext;
 List **exprlists;
 int array_len;
 int curr_idx;
 int marked_idx;
} ValuesScanState;
# 1443 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct CteScanState
{
 ScanState ss;
 int eflags;
 int readptr;
 PlanState *cteplanstate;

 struct CteScanState *leader;

 Tuplestorestate *cte_table;
 bool eof_cte;
} CteScanState;
# 1464 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct WorkTableScanState
{
 ScanState ss;
 RecursiveUnionState *rustate;
} WorkTableScanState;







typedef struct ForeignScanState
{
 ScanState ss;

 struct FdwRoutine *fdwroutine;
 void *fdw_state;
} ForeignScanState;
# 1495 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct JoinState
{
 PlanState ps;
 JoinType jointype;
 List *joinqual;
} JoinState;
# 1510 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct NestLoopState
{
 JoinState js;
 bool nl_NeedNewOuter;
 bool nl_MatchedOuter;
 TupleTableSlot *nl_NullInnerTupleSlot;
} NestLoopState;
# 1540 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct MergeJoinClauseData *MergeJoinClause;

typedef struct MergeJoinState
{
 JoinState js;
 int mj_NumClauses;
 MergeJoinClause mj_Clauses;
 int mj_JoinState;
 bool mj_ExtraMarks;
 bool mj_ConstFalseJoin;
 bool mj_FillOuter;
 bool mj_FillInner;
 bool mj_MatchedOuter;
 bool mj_MatchedInner;
 TupleTableSlot *mj_OuterTupleSlot;
 TupleTableSlot *mj_InnerTupleSlot;
 TupleTableSlot *mj_MarkedTupleSlot;
 TupleTableSlot *mj_NullOuterTupleSlot;
 TupleTableSlot *mj_NullInnerTupleSlot;
 ExprContext *mj_OuterEContext;
 ExprContext *mj_InnerEContext;
} MergeJoinState;
# 1591 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct HashJoinTupleData *HashJoinTuple;
typedef struct HashJoinTableData *HashJoinTable;

typedef struct HashJoinState
{
 JoinState js;
 List *hashclauses;
 List *hj_OuterHashKeys;
 List *hj_InnerHashKeys;
 List *hj_HashOperators;
 HashJoinTable hj_HashTable;
 uint32 hj_CurHashValue;
 int hj_CurBucketNo;
 int hj_CurSkewBucketNo;
 HashJoinTuple hj_CurTuple;
 TupleTableSlot *hj_OuterTupleSlot;
 TupleTableSlot *hj_HashTupleSlot;
 TupleTableSlot *hj_NullOuterTupleSlot;
 TupleTableSlot *hj_NullInnerTupleSlot;
 TupleTableSlot *hj_FirstOuterTupleSlot;
 int hj_JoinState;
 bool hj_MatchedOuter;
 bool hj_OuterNotEmpty;
} HashJoinState;
# 1631 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct MaterialState
{
 ScanState ss;
 int eflags;
 bool eof_underlying;
 Tuplestorestate *tuplestorestate;
} MaterialState;





typedef struct SortState
{
 ScanState ss;
 bool randomAccess;
 bool bounded;
 int64 bound;
 bool sort_Done;
 bool bounded_Done;
 int64 bound_Done;
 void *tuplesortstate;
} SortState;





typedef struct GroupState
{
 ScanState ss;
 FmgrInfo *eqfunctions;
 bool grp_done;
} GroupState;
# 1679 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct AggStatePerAggData *AggStatePerAgg;
typedef struct AggStatePerGroupData *AggStatePerGroup;

typedef struct AggState
{
 ScanState ss;
 List *aggs;
 int numaggs;
 FmgrInfo *eqfunctions;
 FmgrInfo *hashfunctions;
 AggStatePerAgg peragg;
 MemoryContext aggcontext;
 ExprContext *tmpcontext;
 bool agg_done;

 AggStatePerGroup pergroup;
 HeapTuple grp_firstTuple;

 TupleHashTable hashtable;
 TupleTableSlot *hashslot;
 List *hash_needed;
 bool table_filled;
 TupleHashIterator hashiter;
} AggState;






typedef struct WindowStatePerFuncData *WindowStatePerFunc;
typedef struct WindowStatePerAggData *WindowStatePerAgg;

typedef struct WindowAggState
{
 ScanState ss;


 List *funcs;
 int numfuncs;
 int numaggs;

 WindowStatePerFunc perfunc;
 WindowStatePerAgg peragg;
 FmgrInfo *partEqfunctions;
 FmgrInfo *ordEqfunctions;
 Tuplestorestate *buffer;
 int current_ptr;
 int64 spooled_rows;
 int64 currentpos;
 int64 frameheadpos;
 int64 frametailpos;

 struct WindowObjectData *agg_winobj;

 int64 aggregatedbase;
 int64 aggregatedupto;

 int frameOptions;
 ExprState *startOffset;
 ExprState *endOffset;
 Datum startOffsetValue;
 Datum endOffsetValue;

 MemoryContext partcontext;
 MemoryContext aggcontext;
 ExprContext *tmpcontext;

 bool all_first;
 bool all_done;
 bool partition_spooled;


 bool more_partitions;

 bool framehead_valid;

 bool frametail_valid;


 TupleTableSlot *first_part_slot;



 TupleTableSlot *agg_row_slot;
 TupleTableSlot *temp_slot_1;
 TupleTableSlot *temp_slot_2;
} WindowAggState;
# 1779 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct UniqueState
{
 PlanState ps;
 FmgrInfo *eqfunctions;
 MemoryContext tempContext;
} UniqueState;





typedef struct HashState
{
 PlanState ps;
 HashJoinTable hashtable;
 List *hashkeys;

} HashState;
# 1808 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef struct SetOpStatePerGroupData *SetOpStatePerGroup;

typedef struct SetOpState
{
 PlanState ps;
 FmgrInfo *eqfunctions;
 FmgrInfo *hashfunctions;
 bool setop_done;
 long numOutput;
 MemoryContext tempContext;

 SetOpStatePerGroup pergroup;
 HeapTuple grp_firstTuple;

 TupleHashTable hashtable;
 MemoryContext tableContext;
 bool table_filled;
 TupleHashIterator hashiter;
} SetOpState;







typedef struct LockRowsState
{
 PlanState ps;
 List *lr_arowMarks;
 EPQState lr_epqstate;
} LockRowsState;
# 1853 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h"
typedef enum
{
 LIMIT_INITIAL,
 LIMIT_RESCAN,
 LIMIT_EMPTY,
 LIMIT_INWINDOW,
 LIMIT_SUBPLANEOF,
 LIMIT_WINDOWEND,
 LIMIT_WINDOWSTART
} LimitStateCond;

typedef struct LimitState
{
 PlanState ps;
 ExprState *limitOffset;
 ExprState *limitCount;
 int64 offset;
 int64 count;
 bool noCount;
 LimitStateCond lstate;
 int64 position;
 TupleTableSlot *subSlot;
} LimitState;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/execdesc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h" 1
# 70 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 1
# 71 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h" 2
# 86 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h"
typedef enum
{
 DestNone,
 DestDebug,
 DestRemote,
 DestRemoteExecute,
 DestSPI,
 DestTuplestore,
 DestIntoRel,
 DestCopyOut,
 DestSQLFunction
} CommandDest;
# 108 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h"
typedef struct _DestReceiver DestReceiver;

struct _DestReceiver
{

 void (*receiveSlot) (TupleTableSlot *slot,
           DestReceiver *self);

 void (*rStartup) (DestReceiver *self,
           int operation,
           TupleDesc typeinfo);
 void (*rShutdown) (DestReceiver *self);

 void (*rDestroy) (DestReceiver *self);

 CommandDest mydest;

};

extern DestReceiver *None_Receiver;



extern void BeginCommand(const char *commandTag, CommandDest dest);
extern DestReceiver *CreateDestReceiver(CommandDest dest);
extern void EndCommand(const char *commandTag, CommandDest dest);



extern void NullCommand(CommandDest dest);
extern void ReadyForQuery(CommandDest dest);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/execdesc.h" 2
# 33 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/execdesc.h"
typedef struct QueryDesc
{

 CmdType operation;
 PlannedStmt *plannedstmt;
 Node *utilitystmt;
 const char *sourceText;
 Snapshot snapshot;
 Snapshot crosscheck_snapshot;
 DestReceiver *dest;
 ParamListInfo params;
 int instrument_options;


 TupleDesc tupDesc;
 EState *estate;
 PlanState *planstate;


 struct Instrumentation *totaltime;
} QueryDesc;


extern QueryDesc *CreateQueryDesc(PlannedStmt *plannedstmt,
    const char *sourceText,
    Snapshot snapshot,
    Snapshot crosscheck_snapshot,
    DestReceiver *dest,
    ParamListInfo params,
    int instrument_options);

extern QueryDesc *CreateUtilityQueryDesc(Node *utilitystmt,
        const char *sourceText,
        Snapshot snapshot,
        DestReceiver *dest,
        ParamListInfo params);

extern void FreeQueryDesc(QueryDesc *qdesc);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/executor.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 1
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/value.h" 1
# 42 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/value.h"
typedef struct Value
{
 NodeTag type;
 union ValUnion
 {
  long ival;
  char *str;
 } val;
} Value;





extern Value *makeInteger(long i);
extern Value *makeFloat(char *numericStr);
extern Value *makeString(char *str);
extern Value *makeBitString(char *str);
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 2


typedef enum QuerySource
{
 QSRC_ORIGINAL,
 QSRC_PARSER,
 QSRC_INSTEAD_RULE,
 QSRC_QUAL_INSTEAD_RULE,
 QSRC_NON_INSTEAD_RULE
} QuerySource;


typedef enum SortByDir
{
 SORTBY_DEFAULT,
 SORTBY_ASC,
 SORTBY_DESC,
 SORTBY_USING
} SortByDir;

typedef enum SortByNulls
{
 SORTBY_NULLS_DEFAULT,
 SORTBY_NULLS_FIRST,
 SORTBY_NULLS_LAST
} SortByNulls;
# 60 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef uint32 AclMode;
# 98 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct Query
{
 NodeTag type;

 CmdType commandType;

 QuerySource querySource;

 uint32 queryId;

 bool canSetTag;

 Node *utilityStmt;


 int resultRelation;


 bool hasAggs;
 bool hasWindowFuncs;
 bool hasSubLinks;
 bool hasDistinctOn;
 bool hasRecursive;
 bool hasModifyingCTE;
 bool hasForUpdate;

 List *cteList;

 List *rtable;
 FromExpr *jointree;

 List *targetList;

 List *returningList;

 List *groupClause;

 Node *havingQual;

 List *windowClause;

 List *distinctClause;

 List *sortClause;

 Node *limitOffset;
 Node *limitCount;

 List *rowMarks;

 Node *setOperations;


 List *constraintDeps;

} Query;
# 177 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct TypeName
{
 NodeTag type;
 List *names;
 Oid typeOid;
 bool setof;
 bool pct_type;
 List *typmods;
 int32 typemod;
 List *arrayBounds;
 int location;
} TypeName;
# 203 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ColumnRef
{
 NodeTag type;
 List *fields;
 int location;
} ColumnRef;




typedef struct ParamRef
{
 NodeTag type;
 int number;
 int location;
} ParamRef;




typedef enum A_Expr_Kind
{
 AEXPR_OP,
 AEXPR_AND,
 AEXPR_OR,
 AEXPR_NOT,
 AEXPR_OP_ANY,
 AEXPR_OP_ALL,
 AEXPR_DISTINCT,
 AEXPR_NULLIF,
 AEXPR_OF,
 AEXPR_IN
} A_Expr_Kind;

typedef struct A_Expr
{
 NodeTag type;
 A_Expr_Kind kind;
 List *name;
 Node *lexpr;
 Node *rexpr;
 int location;
} A_Expr;




typedef struct A_Const
{
 NodeTag type;
 Value val;
 int location;
} A_Const;




typedef struct TypeCast
{
 NodeTag type;
 Node *arg;
 TypeName *typeName;
 int location;
} TypeCast;




typedef struct CollateClause
{
 NodeTag type;
 Node *arg;
 List *collname;
 int location;
} CollateClause;
# 289 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct FuncCall
{
 NodeTag type;
 List *funcname;
 List *args;
 List *agg_order;
 bool agg_star;
 bool agg_distinct;
 bool func_variadic;
 struct WindowDef *over;
 int location;
} FuncCall;







typedef struct A_Star
{
 NodeTag type;
} A_Star;




typedef struct A_Indices
{
 NodeTag type;
 Node *lidx;
 Node *uidx;
} A_Indices;
# 338 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct A_Indirection
{
 NodeTag type;
 Node *arg;
 List *indirection;
} A_Indirection;




typedef struct A_ArrayExpr
{
 NodeTag type;
 List *elements;
 int location;
} A_ArrayExpr;
# 373 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ResTarget
{
 NodeTag type;
 char *name;
 List *indirection;
 Node *val;
 int location;
} ResTarget;




typedef struct SortBy
{
 NodeTag type;
 Node *node;
 SortByDir sortby_dir;
 SortByNulls sortby_nulls;
 List *useOp;
 int location;
} SortBy;
# 403 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct WindowDef
{
 NodeTag type;
 char *name;
 char *refname;
 List *partitionClause;
 List *orderClause;
 int frameOptions;
 Node *startOffset;
 Node *endOffset;
 int location;
} WindowDef;
# 451 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct RangeSubselect
{
 NodeTag type;
 Node *subquery;
 Alias *alias;
} RangeSubselect;




typedef struct RangeFunction
{
 NodeTag type;
 Node *funccallnode;
 Alias *alias;
 List *coldeflist;

} RangeFunction;
# 488 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ColumnDef
{
 NodeTag type;
 char *colname;
 TypeName *typeName;
 int inhcount;
 bool is_local;
 bool is_not_null;
 bool is_from_type;
 char storage;
 Node *raw_default;
 Node *cooked_default;
 CollateClause *collClause;
 Oid collOid;
 List *constraints;
 List *fdwoptions;
} ColumnDef;




typedef struct TableLikeClause
{
 NodeTag type;
 RangeVar *relation;
 bits32 options;
} TableLikeClause;

typedef enum TableLikeOption
{
 CREATE_TABLE_LIKE_DEFAULTS = 1 << 0,
 CREATE_TABLE_LIKE_CONSTRAINTS = 1 << 1,
 CREATE_TABLE_LIKE_INDEXES = 1 << 2,
 CREATE_TABLE_LIKE_STORAGE = 1 << 3,
 CREATE_TABLE_LIKE_COMMENTS = 1 << 4,
 CREATE_TABLE_LIKE_ALL = 0x7FFFFFFF
} TableLikeOption;
# 533 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct IndexElem
{
 NodeTag type;
 char *name;
 Node *expr;
 char *indexcolname;
 List *collation;
 List *opclass;
 SortByDir ordering;
 SortByNulls nulls_ordering;
} IndexElem;
# 555 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum DefElemAction
{
 DEFELEM_UNSPEC,
 DEFELEM_SET,
 DEFELEM_ADD,
 DEFELEM_DROP
} DefElemAction;

typedef struct DefElem
{
 NodeTag type;
 char *defnamespace;
 char *defname;
 Node *arg;
 DefElemAction defaction;
} DefElem;
# 580 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct LockingClause
{
 NodeTag type;
 List *lockedRels;
 bool forUpdate;
 bool noWait;
} LockingClause;




typedef struct XmlSerialize
{
 NodeTag type;
 XmlOptionType xmloption;
 Node *expr;
 TypeName *typeName;
 int location;
} XmlSerialize;
# 677 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum RTEKind
{
 RTE_RELATION,
 RTE_SUBQUERY,
 RTE_JOIN,
 RTE_FUNCTION,
 RTE_VALUES,
 RTE_CTE
} RTEKind;

typedef struct RangeTblEntry
{
 NodeTag type;

 RTEKind rtekind;
# 702 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 Oid relid;
 char relkind;




 Query *subquery;
 bool security_barrier;
# 722 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 JoinType jointype;
 List *joinaliasvars;
# 733 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 Node *funcexpr;
 List *funccoltypes;
 List *funccoltypmods;
 List *funccolcollations;




 List *values_lists;
 List *values_collations;




 char *ctename;
 Index ctelevelsup;
 bool self_reference;
 List *ctecoltypes;
 List *ctecoltypmods;
 List *ctecolcollations;




 Alias *alias;
 Alias *eref;
 bool inh;
 bool inFromCl;
 AclMode requiredPerms;
 Oid checkAsUser;
 Bitmapset *selectedCols;
 Bitmapset *modifiedCols;
} RangeTblEntry;
# 825 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct SortGroupClause
{
 NodeTag type;
 Index tleSortGroupRef;
 Oid eqop;
 Oid sortop;
 bool nulls_first;
 bool hashable;
} SortGroupClause;
# 849 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct WindowClause
{
 NodeTag type;
 char *name;
 char *refname;
 List *partitionClause;
 List *orderClause;
 int frameOptions;
 Node *startOffset;
 Node *endOffset;
 Index winref;
 bool copiedOrder;
} WindowClause;
# 875 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct RowMarkClause
{
 NodeTag type;
 Index rti;
 bool forUpdate;
 bool noWait;
 bool pushedDown;
} RowMarkClause;
# 891 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct WithClause
{
 NodeTag type;
 List *ctes;
 bool recursive;
 int location;
} WithClause;







typedef struct CommonTableExpr
{
 NodeTag type;
 char *ctename;
 List *aliascolnames;

 Node *ctequery;
 int location;

 bool cterecursive;
 int cterefcount;

 List *ctecolnames;
 List *ctecoltypes;
 List *ctecoltypmods;
 List *ctecolcollations;
} CommonTableExpr;
# 943 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct InsertStmt
{
 NodeTag type;
 RangeVar *relation;
 List *cols;
 Node *selectStmt;
 List *returningList;
 WithClause *withClause;
} InsertStmt;





typedef struct DeleteStmt
{
 NodeTag type;
 RangeVar *relation;
 List *usingClause;
 Node *whereClause;
 List *returningList;
 WithClause *withClause;
} DeleteStmt;





typedef struct UpdateStmt
{
 NodeTag type;
 RangeVar *relation;
 List *targetList;
 Node *whereClause;
 List *fromClause;
 List *returningList;
 WithClause *withClause;
} UpdateStmt;
# 995 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum SetOperation
{
 SETOP_NONE = 0,
 SETOP_UNION,
 SETOP_INTERSECT,
 SETOP_EXCEPT
} SetOperation;

typedef struct SelectStmt
{
 NodeTag type;




 List *distinctClause;

 IntoClause *intoClause;
 List *targetList;
 List *fromClause;
 Node *whereClause;
 List *groupClause;
 Node *havingClause;
 List *windowClause;
 WithClause *withClause;
# 1029 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
 List *valuesLists;





 List *sortClause;
 Node *limitOffset;
 Node *limitCount;
 List *lockingClause;




 SetOperation op;
 bool all;
 struct SelectStmt *larg;
 struct SelectStmt *rarg;

} SelectStmt;
# 1070 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct SetOperationStmt
{
 NodeTag type;
 SetOperation op;
 bool all;
 Node *larg;
 Node *rarg;



 List *colTypes;
 List *colTypmods;
 List *colCollations;
 List *groupClauses;

} SetOperationStmt;
# 1105 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum ObjectType
{
 OBJECT_AGGREGATE,
 OBJECT_ATTRIBUTE,
 OBJECT_CAST,
 OBJECT_COLUMN,
 OBJECT_CONSTRAINT,
 OBJECT_COLLATION,
 OBJECT_CONVERSION,
 OBJECT_DATABASE,
 OBJECT_DOMAIN,
 OBJECT_EXTENSION,
 OBJECT_FDW,
 OBJECT_FOREIGN_SERVER,
 OBJECT_FOREIGN_TABLE,
 OBJECT_FUNCTION,
 OBJECT_INDEX,
 OBJECT_LANGUAGE,
 OBJECT_LARGEOBJECT,
 OBJECT_OPCLASS,
 OBJECT_OPERATOR,
 OBJECT_OPFAMILY,
 OBJECT_ROLE,
 OBJECT_RULE,
 OBJECT_SCHEMA,
 OBJECT_SEQUENCE,
 OBJECT_TABLE,
 OBJECT_TABLESPACE,
 OBJECT_TRIGGER,
 OBJECT_TSCONFIGURATION,
 OBJECT_TSDICTIONARY,
 OBJECT_TSPARSER,
 OBJECT_TSTEMPLATE,
 OBJECT_TYPE,
 OBJECT_VIEW
} ObjectType;
# 1150 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CreateSchemaStmt
{
 NodeTag type;
 char *schemaname;
 char *authid;
 List *schemaElts;
} CreateSchemaStmt;

typedef enum DropBehavior
{
 DROP_RESTRICT,
 DROP_CASCADE
} DropBehavior;





typedef struct AlterTableStmt
{
 NodeTag type;
 RangeVar *relation;
 List *cmds;
 ObjectType relkind;
 bool missing_ok;
} AlterTableStmt;

typedef enum AlterTableType
{
 AT_AddColumn,
 AT_AddColumnRecurse,
 AT_AddColumnToView,
 AT_ColumnDefault,
 AT_DropNotNull,
 AT_SetNotNull,
 AT_SetStatistics,
 AT_SetOptions,
 AT_ResetOptions,
 AT_SetStorage,
 AT_DropColumn,
 AT_DropColumnRecurse,
 AT_AddIndex,
 AT_ReAddIndex,
 AT_AddConstraint,
 AT_AddConstraintRecurse,
 AT_ValidateConstraint,
 AT_ValidateConstraintRecurse,
 AT_ProcessedConstraint,

 AT_AddIndexConstraint,
 AT_DropConstraint,
 AT_DropConstraintRecurse,
 AT_AlterColumnType,
 AT_AlterColumnGenericOptions,
 AT_ChangeOwner,
 AT_ClusterOn,
 AT_DropCluster,
 AT_AddOids,
 AT_AddOidsRecurse,
 AT_DropOids,
 AT_SetTableSpace,
 AT_SetRelOptions,
 AT_ResetRelOptions,
 AT_ReplaceRelOptions,
 AT_EnableTrig,
 AT_EnableAlwaysTrig,
 AT_EnableReplicaTrig,
 AT_DisableTrig,
 AT_EnableTrigAll,
 AT_DisableTrigAll,
 AT_EnableTrigUser,
 AT_DisableTrigUser,
 AT_EnableRule,
 AT_EnableAlwaysRule,
 AT_EnableReplicaRule,
 AT_DisableRule,
 AT_AddInherit,
 AT_DropInherit,
 AT_AddOf,
 AT_DropOf,
 AT_GenericOptions,

 AT_ReAddConstraint
} AlterTableType;

typedef struct AlterTableCmd
{
 NodeTag type;
 AlterTableType subtype;
 char *name;

 Node *def;

 DropBehavior behavior;
 bool missing_ok;
} AlterTableCmd;
# 1255 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct AlterDomainStmt
{
 NodeTag type;
 char subtype;







 List *typeName;
 char *name;
 Node *def;
 DropBehavior behavior;
 bool missing_ok;
} AlterDomainStmt;






typedef enum GrantTargetType
{
 ACL_TARGET_OBJECT,
 ACL_TARGET_ALL_IN_SCHEMA,
 ACL_TARGET_DEFAULTS
} GrantTargetType;

typedef enum GrantObjectType
{
 ACL_OBJECT_COLUMN,
 ACL_OBJECT_RELATION,
 ACL_OBJECT_SEQUENCE,
 ACL_OBJECT_DATABASE,
 ACL_OBJECT_DOMAIN,
 ACL_OBJECT_FDW,
 ACL_OBJECT_FOREIGN_SERVER,
 ACL_OBJECT_FUNCTION,
 ACL_OBJECT_LANGUAGE,
 ACL_OBJECT_LARGEOBJECT,
 ACL_OBJECT_NAMESPACE,
 ACL_OBJECT_TABLESPACE,
 ACL_OBJECT_TYPE
} GrantObjectType;

typedef struct GrantStmt
{
 NodeTag type;
 bool is_grant;
 GrantTargetType targtype;
 GrantObjectType objtype;
 List *objects;

 List *privileges;

 List *grantees;
 bool grant_option;
 DropBehavior behavior;
} GrantStmt;

typedef struct PrivGrantee
{
 NodeTag type;
 char *rolname;
} PrivGrantee;






typedef struct FuncWithArgs
{
 NodeTag type;
 List *funcname;
 List *funcargs;
} FuncWithArgs;
# 1342 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct AccessPriv
{
 NodeTag type;
 char *priv_name;
 List *cols;
} AccessPriv;
# 1358 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct GrantRoleStmt
{
 NodeTag type;
 List *granted_roles;
 List *grantee_roles;
 bool is_grant;
 bool admin_opt;
 char *grantor;
 DropBehavior behavior;
} GrantRoleStmt;





typedef struct AlterDefaultPrivilegesStmt
{
 NodeTag type;
 List *options;
 GrantStmt *action;
} AlterDefaultPrivilegesStmt;
# 1388 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CopyStmt
{
 NodeTag type;
 RangeVar *relation;
 Node *query;
 List *attlist;

 bool is_from;
 char *filename;
 List *options;
} CopyStmt;
# 1407 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum
{
 VAR_SET_VALUE,
 VAR_SET_DEFAULT,
 VAR_SET_CURRENT,
 VAR_SET_MULTI,
 VAR_RESET,
 VAR_RESET_ALL
} VariableSetKind;

typedef struct VariableSetStmt
{
 NodeTag type;
 VariableSetKind kind;
 char *name;
 List *args;
 bool is_local;
} VariableSetStmt;





typedef struct VariableShowStmt
{
 NodeTag type;
 char *name;
} VariableShowStmt;
# 1447 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CreateStmt
{
 NodeTag type;
 RangeVar *relation;
 List *tableElts;
 List *inhRelations;

 TypeName *ofTypename;
 List *constraints;
 List *options;
 OnCommitAction oncommit;
 char *tablespacename;
 bool if_not_exists;
} CreateStmt;
# 1493 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum ConstrType
{
 CONSTR_NULL,
 CONSTR_NOTNULL,
 CONSTR_DEFAULT,
 CONSTR_CHECK,
 CONSTR_PRIMARY,
 CONSTR_UNIQUE,
 CONSTR_EXCLUSION,
 CONSTR_FOREIGN,
 CONSTR_ATTR_DEFERRABLE,
 CONSTR_ATTR_NOT_DEFERRABLE,
 CONSTR_ATTR_DEFERRED,
 CONSTR_ATTR_IMMEDIATE
} ConstrType;
# 1521 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct Constraint
{
 NodeTag type;
 ConstrType contype;


 char *conname;
 bool deferrable;
 bool initdeferred;
 int location;


 bool is_no_inherit;
 Node *raw_expr;
 char *cooked_expr;


 List *keys;


 List *exclusions;


 List *options;
 char *indexname;
 char *indexspace;

 char *access_method;
 Node *where_clause;


 RangeVar *pktable;
 List *fk_attrs;
 List *pk_attrs;
 char fk_matchtype;
 char fk_upd_action;
 char fk_del_action;
 List *old_conpfeqop;


 bool skip_validation;
 bool initially_valid;
} Constraint;






typedef struct CreateTableSpaceStmt
{
 NodeTag type;
 char *tablespacename;
 char *owner;
 char *location;
} CreateTableSpaceStmt;

typedef struct DropTableSpaceStmt
{
 NodeTag type;
 char *tablespacename;
 bool missing_ok;
} DropTableSpaceStmt;

typedef struct AlterTableSpaceOptionsStmt
{
 NodeTag type;
 char *tablespacename;
 List *options;
 bool isReset;
} AlterTableSpaceOptionsStmt;






typedef struct CreateExtensionStmt
{
 NodeTag type;
 char *extname;
 bool if_not_exists;
 List *options;
} CreateExtensionStmt;


typedef struct AlterExtensionStmt
{
 NodeTag type;
 char *extname;
 List *options;
} AlterExtensionStmt;

typedef struct AlterExtensionContentsStmt
{
 NodeTag type;
 char *extname;
 int action;
 ObjectType objtype;
 List *objname;
 List *objargs;
} AlterExtensionContentsStmt;






typedef struct CreateFdwStmt
{
 NodeTag type;
 char *fdwname;
 List *func_options;
 List *options;
} CreateFdwStmt;

typedef struct AlterFdwStmt
{
 NodeTag type;
 char *fdwname;
 List *func_options;
 List *options;
} AlterFdwStmt;






typedef struct CreateForeignServerStmt
{
 NodeTag type;
 char *servername;
 char *servertype;
 char *version;
 char *fdwname;
 List *options;
} CreateForeignServerStmt;

typedef struct AlterForeignServerStmt
{
 NodeTag type;
 char *servername;
 char *version;
 List *options;
 bool has_version;
} AlterForeignServerStmt;






typedef struct CreateForeignTableStmt
{
 CreateStmt base;
 char *servername;
 List *options;
} CreateForeignTableStmt;






typedef struct CreateUserMappingStmt
{
 NodeTag type;
 char *username;
 char *servername;
 List *options;
} CreateUserMappingStmt;

typedef struct AlterUserMappingStmt
{
 NodeTag type;
 char *username;
 char *servername;
 List *options;
} AlterUserMappingStmt;

typedef struct DropUserMappingStmt
{
 NodeTag type;
 char *username;
 char *servername;
 bool missing_ok;
} DropUserMappingStmt;





typedef struct CreateTrigStmt
{
 NodeTag type;
 char *trigname;
 RangeVar *relation;
 List *funcname;
 List *args;
 bool row;

 int16 timing;

 int16 events;
 List *columns;
 Node *whenClause;
 bool isconstraint;

 bool deferrable;
 bool initdeferred;
 RangeVar *constrrel;
} CreateTrigStmt;





typedef struct CreatePLangStmt
{
 NodeTag type;
 bool replace;
 char *plname;
 List *plhandler;
 List *plinline;
 List *plvalidator;
 bool pltrusted;
} CreatePLangStmt;
# 1759 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum RoleStmtType
{
 ROLESTMT_ROLE,
 ROLESTMT_USER,
 ROLESTMT_GROUP
} RoleStmtType;

typedef struct CreateRoleStmt
{
 NodeTag type;
 RoleStmtType stmt_type;
 char *role;
 List *options;
} CreateRoleStmt;

typedef struct AlterRoleStmt
{
 NodeTag type;
 char *role;
 List *options;
 int action;
} AlterRoleStmt;

typedef struct AlterRoleSetStmt
{
 NodeTag type;
 char *role;
 char *database;
 VariableSetStmt *setstmt;
} AlterRoleSetStmt;

typedef struct DropRoleStmt
{
 NodeTag type;
 List *roles;
 bool missing_ok;
} DropRoleStmt;






typedef struct CreateSeqStmt
{
 NodeTag type;
 RangeVar *sequence;
 List *options;
 Oid ownerId;
} CreateSeqStmt;

typedef struct AlterSeqStmt
{
 NodeTag type;
 RangeVar *sequence;
 List *options;
 bool missing_ok;
} AlterSeqStmt;





typedef struct DefineStmt
{
 NodeTag type;
 ObjectType kind;
 bool oldstyle;
 List *defnames;
 List *args;
 List *definition;
} DefineStmt;





typedef struct CreateDomainStmt
{
 NodeTag type;
 List *domainname;
 TypeName *typeName;
 CollateClause *collClause;
 List *constraints;
} CreateDomainStmt;





typedef struct CreateOpClassStmt
{
 NodeTag type;
 List *opclassname;
 List *opfamilyname;
 char *amname;
 TypeName *datatype;
 List *items;
 bool isDefault;
} CreateOpClassStmt;





typedef struct CreateOpClassItem
{
 NodeTag type;
 int itemtype;

 List *name;
 List *args;
 int number;
 List *order_family;
 List *class_args;

 TypeName *storedtype;
} CreateOpClassItem;





typedef struct CreateOpFamilyStmt
{
 NodeTag type;
 List *opfamilyname;
 char *amname;
} CreateOpFamilyStmt;





typedef struct AlterOpFamilyStmt
{
 NodeTag type;
 List *opfamilyname;
 char *amname;
 bool isDrop;
 List *items;
} AlterOpFamilyStmt;






typedef struct DropStmt
{
 NodeTag type;
 List *objects;
 List *arguments;
 ObjectType removeType;
 DropBehavior behavior;
 bool missing_ok;
 bool concurrent;
} DropStmt;





typedef struct TruncateStmt
{
 NodeTag type;
 List *relations;
 bool restart_seqs;
 DropBehavior behavior;
} TruncateStmt;





typedef struct CommentStmt
{
 NodeTag type;
 ObjectType objtype;
 List *objname;
 List *objargs;
 char *comment;
} CommentStmt;





typedef struct SecLabelStmt
{
 NodeTag type;
 ObjectType objtype;
 List *objname;
 List *objargs;
 char *provider;
 char *label;
} SecLabelStmt;
# 1975 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct DeclareCursorStmt
{
 NodeTag type;
 char *portalname;
 int options;
 Node *query;
} DeclareCursorStmt;





typedef struct ClosePortalStmt
{
 NodeTag type;
 char *portalname;

} ClosePortalStmt;





typedef enum FetchDirection
{

 FETCH_FORWARD,
 FETCH_BACKWARD,

 FETCH_ABSOLUTE,
 FETCH_RELATIVE
} FetchDirection;



typedef struct FetchStmt
{
 NodeTag type;
 FetchDirection direction;
 long howMany;
 char *portalname;
 bool ismove;
} FetchStmt;
# 2030 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct IndexStmt
{
 NodeTag type;
 char *idxname;
 RangeVar *relation;
 char *accessMethod;
 char *tableSpace;
 List *indexParams;
 List *options;
 Node *whereClause;
 List *excludeOpNames;
 char *idxcomment;
 Oid indexOid;
 Oid oldNode;
 bool unique;
 bool primary;
 bool isconstraint;
 bool deferrable;
 bool initdeferred;
 bool concurrent;
} IndexStmt;





typedef struct CreateFunctionStmt
{
 NodeTag type;
 bool replace;
 List *funcname;
 List *parameters;
 TypeName *returnType;
 List *options;
 List *withClause;
} CreateFunctionStmt;

typedef enum FunctionParameterMode
{

 FUNC_PARAM_IN = 'i',
 FUNC_PARAM_OUT = 'o',
 FUNC_PARAM_INOUT = 'b',
 FUNC_PARAM_VARIADIC = 'v',
 FUNC_PARAM_TABLE = 't'
} FunctionParameterMode;

typedef struct FunctionParameter
{
 NodeTag type;
 char *name;
 TypeName *argType;
 FunctionParameterMode mode;
 Node *defexpr;
} FunctionParameter;

typedef struct AlterFunctionStmt
{
 NodeTag type;
 FuncWithArgs *func;
 List *actions;
} AlterFunctionStmt;







typedef struct DoStmt
{
 NodeTag type;
 List *args;
} DoStmt;

typedef struct InlineCodeBlock
{
 NodeTag type;
 char *source_text;
 Oid langOid;
 bool langIsTrusted;
} InlineCodeBlock;





typedef struct RenameStmt
{
 NodeTag type;
 ObjectType renameType;
 ObjectType relationType;
 RangeVar *relation;
 List *object;
 List *objarg;
 char *subname;

 char *newname;
 DropBehavior behavior;
 bool missing_ok;
} RenameStmt;





typedef struct AlterObjectSchemaStmt
{
 NodeTag type;
 ObjectType objectType;
 RangeVar *relation;
 List *object;
 List *objarg;
 char *addname;
 char *newschema;
 bool missing_ok;
} AlterObjectSchemaStmt;





typedef struct AlterOwnerStmt
{
 NodeTag type;
 ObjectType objectType;
 RangeVar *relation;
 List *object;
 List *objarg;
 char *addname;
 char *newowner;
} AlterOwnerStmt;






typedef struct RuleStmt
{
 NodeTag type;
 RangeVar *relation;
 char *rulename;
 Node *whereClause;
 CmdType event;
 bool instead;
 List *actions;
 bool replace;
} RuleStmt;





typedef struct NotifyStmt
{
 NodeTag type;
 char *conditionname;
 char *payload;
} NotifyStmt;





typedef struct ListenStmt
{
 NodeTag type;
 char *conditionname;
} ListenStmt;





typedef struct UnlistenStmt
{
 NodeTag type;
 char *conditionname;
} UnlistenStmt;





typedef enum TransactionStmtKind
{
 TRANS_STMT_BEGIN,
 TRANS_STMT_START,
 TRANS_STMT_COMMIT,
 TRANS_STMT_ROLLBACK,
 TRANS_STMT_SAVEPOINT,
 TRANS_STMT_RELEASE,
 TRANS_STMT_ROLLBACK_TO,
 TRANS_STMT_PREPARE,
 TRANS_STMT_COMMIT_PREPARED,
 TRANS_STMT_ROLLBACK_PREPARED
} TransactionStmtKind;

typedef struct TransactionStmt
{
 NodeTag type;
 TransactionStmtKind kind;
 List *options;
 char *gid;
} TransactionStmt;





typedef struct CompositeTypeStmt
{
 NodeTag type;
 RangeVar *typevar;
 List *coldeflist;
} CompositeTypeStmt;





typedef struct CreateEnumStmt
{
 NodeTag type;
 List *typeName;
 List *vals;
} CreateEnumStmt;





typedef struct CreateRangeStmt
{
 NodeTag type;
 List *typeName;
 List *params;
} CreateRangeStmt;





typedef struct AlterEnumStmt
{
 NodeTag type;
 List *typeName;
 char *newVal;
 char *newValNeighbor;
 bool newValIsAfter;
} AlterEnumStmt;





typedef struct ViewStmt
{
 NodeTag type;
 RangeVar *view;
 List *aliases;
 Node *query;
 bool replace;
 List *options;
} ViewStmt;





typedef struct LoadStmt
{
 NodeTag type;
 char *filename;
} LoadStmt;





typedef struct CreatedbStmt
{
 NodeTag type;
 char *dbname;
 List *options;
} CreatedbStmt;





typedef struct AlterDatabaseStmt
{
 NodeTag type;
 char *dbname;
 List *options;
} AlterDatabaseStmt;

typedef struct AlterDatabaseSetStmt
{
 NodeTag type;
 char *dbname;
 VariableSetStmt *setstmt;
} AlterDatabaseSetStmt;





typedef struct DropdbStmt
{
 NodeTag type;
 char *dbname;
 bool missing_ok;
} DropdbStmt;





typedef struct ClusterStmt
{
 NodeTag type;
 RangeVar *relation;
 char *indexname;
 bool verbose;
} ClusterStmt;
# 2369 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef enum VacuumOption
{
 VACOPT_VACUUM = 1 << 0,
 VACOPT_ANALYZE = 1 << 1,
 VACOPT_VERBOSE = 1 << 2,
 VACOPT_FREEZE = 1 << 3,
 VACOPT_FULL = 1 << 4,
 VACOPT_NOWAIT = 1 << 5
} VacuumOption;

typedef struct VacuumStmt
{
 NodeTag type;
 int options;
 int freeze_min_age;
 int freeze_table_age;
 RangeVar *relation;
 List *va_cols;
} VacuumStmt;
# 2397 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct ExplainStmt
{
 NodeTag type;
 Node *query;
 List *options;
} ExplainStmt;
# 2415 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h"
typedef struct CreateTableAsStmt
{
 NodeTag type;
 Node *query;
 IntoClause *into;
 bool is_select_into;
} CreateTableAsStmt;





typedef struct CheckPointStmt
{
 NodeTag type;
} CheckPointStmt;






typedef enum DiscardMode
{
 DISCARD_ALL,
 DISCARD_PLANS,
 DISCARD_TEMP
} DiscardMode;

typedef struct DiscardStmt
{
 NodeTag type;
 DiscardMode target;
} DiscardStmt;





typedef struct LockStmt
{
 NodeTag type;
 List *relations;
 int mode;
 bool nowait;
} LockStmt;





typedef struct ConstraintsSetStmt
{
 NodeTag type;
 List *constraints;
 bool deferred;
} ConstraintsSetStmt;





typedef struct ReindexStmt
{
 NodeTag type;
 ObjectType kind;
 RangeVar *relation;
 const char *name;
 bool do_system;
 bool do_user;
} ReindexStmt;





typedef struct CreateConversionStmt
{
 NodeTag type;
 List *conversion_name;
 char *for_encoding_name;
 char *to_encoding_name;
 List *func_name;
 bool def;
} CreateConversionStmt;





typedef struct CreateCastStmt
{
 NodeTag type;
 TypeName *sourcetype;
 TypeName *targettype;
 FuncWithArgs *func;
 CoercionContext context;
 bool inout;
} CreateCastStmt;





typedef struct PrepareStmt
{
 NodeTag type;
 char *name;
 List *argtypes;
 Node *query;
} PrepareStmt;







typedef struct ExecuteStmt
{
 NodeTag type;
 char *name;
 List *params;
} ExecuteStmt;






typedef struct DeallocateStmt
{
 NodeTag type;
 char *name;

} DeallocateStmt;




typedef struct DropOwnedStmt
{
 NodeTag type;
 List *roles;
 DropBehavior behavior;
} DropOwnedStmt;




typedef struct ReassignOwnedStmt
{
 NodeTag type;
 List *roles;
 char *newrole;
} ReassignOwnedStmt;




typedef struct AlterTSDictionaryStmt
{
 NodeTag type;
 List *dictname;
 List *options;
} AlterTSDictionaryStmt;




typedef struct AlterTSConfigurationStmt
{
 NodeTag type;
 List *cfgname;





 List *tokentype;
 List *dicts;
 bool override;
 bool replace;
 bool missing_ok;
} AlterTSConfigurationStmt;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/executor.h" 2
# 76 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/executor.h"
typedef void (*ExecutorStart_hook_type) (QueryDesc *queryDesc, int eflags);
extern ExecutorStart_hook_type ExecutorStart_hook;


typedef void (*ExecutorRun_hook_type) (QueryDesc *queryDesc,
               ScanDirection direction,
               long count);
extern ExecutorRun_hook_type ExecutorRun_hook;


typedef void (*ExecutorFinish_hook_type) (QueryDesc *queryDesc);
extern ExecutorFinish_hook_type ExecutorFinish_hook;


typedef void (*ExecutorEnd_hook_type) (QueryDesc *queryDesc);
extern ExecutorEnd_hook_type ExecutorEnd_hook;


typedef bool (*ExecutorCheckPerms_hook_type) (List *, bool);
extern ExecutorCheckPerms_hook_type ExecutorCheckPerms_hook;





extern void ExecReScan(PlanState *node);
extern void ExecMarkPos(PlanState *node);
extern void ExecRestrPos(PlanState *node);
extern bool ExecSupportsMarkRestore(NodeTag plantype);
extern bool ExecSupportsBackwardScan(Plan *node);
extern bool ExecMaterializesOutput(NodeTag plantype);




extern bool execCurrentOf(CurrentOfExpr *cexpr,
     ExprContext *econtext,
     Oid table_oid,
     ItemPointer current_tid);




extern bool execTuplesMatch(TupleTableSlot *slot1,
    TupleTableSlot *slot2,
    int numCols,
    AttrNumber *matchColIdx,
    FmgrInfo *eqfunctions,
    MemoryContext evalContext);
extern bool execTuplesUnequal(TupleTableSlot *slot1,
      TupleTableSlot *slot2,
      int numCols,
      AttrNumber *matchColIdx,
      FmgrInfo *eqfunctions,
      MemoryContext evalContext);
extern FmgrInfo *execTuplesMatchPrepare(int numCols,
        Oid *eqOperators);
extern void execTuplesHashPrepare(int numCols,
       Oid *eqOperators,
       FmgrInfo **eqFunctions,
       FmgrInfo **hashFunctions);
extern TupleHashTable BuildTupleHashTable(int numCols, AttrNumber *keyColIdx,
     FmgrInfo *eqfunctions,
     FmgrInfo *hashfunctions,
     long nbuckets, Size entrysize,
     MemoryContext tablecxt,
     MemoryContext tempcxt);
extern TupleHashEntry LookupTupleHashEntry(TupleHashTable hashtable,
      TupleTableSlot *slot,
      bool *isnew);
extern TupleHashEntry FindTupleHashEntry(TupleHashTable hashtable,
       TupleTableSlot *slot,
       FmgrInfo *eqfunctions,
       FmgrInfo *hashfunctions);




extern JunkFilter *ExecInitJunkFilter(List *targetList, bool hasoid,
       TupleTableSlot *slot);
extern JunkFilter *ExecInitJunkFilterConversion(List *targetList,
        TupleDesc cleanTupType,
        TupleTableSlot *slot);
extern AttrNumber ExecFindJunkAttribute(JunkFilter *junkfilter,
       const char *attrName);
extern AttrNumber ExecFindJunkAttributeInTlist(List *targetlist,
        const char *attrName);
extern Datum ExecGetJunkAttribute(TupleTableSlot *slot, AttrNumber attno,
      bool *isNull);
extern TupleTableSlot *ExecFilterJunk(JunkFilter *junkfilter,
      TupleTableSlot *slot);





extern void ExecutorStart(QueryDesc *queryDesc, int eflags);
extern void standard_ExecutorStart(QueryDesc *queryDesc, int eflags);
extern void ExecutorRun(QueryDesc *queryDesc,
   ScanDirection direction, long count);
extern void standard_ExecutorRun(QueryDesc *queryDesc,
      ScanDirection direction, long count);
extern void ExecutorFinish(QueryDesc *queryDesc);
extern void standard_ExecutorFinish(QueryDesc *queryDesc);
extern void ExecutorEnd(QueryDesc *queryDesc);
extern void standard_ExecutorEnd(QueryDesc *queryDesc);
extern void ExecutorRewind(QueryDesc *queryDesc);
extern bool ExecCheckRTPerms(List *rangeTable, bool ereport_on_violation);
extern void CheckValidResultRel(Relation resultRel, CmdType operation);
extern void InitResultRelInfo(ResultRelInfo *resultRelInfo,
      Relation resultRelationDesc,
      Index resultRelationIndex,
      int instrument_options);
extern ResultRelInfo *ExecGetTriggerResultRel(EState *estate, Oid relid);
extern bool ExecContextForcesOids(PlanState *planstate, bool *hasoids);
extern void ExecConstraints(ResultRelInfo *resultRelInfo,
    TupleTableSlot *slot, EState *estate);
extern ExecRowMark *ExecFindRowMark(EState *estate, Index rti);
extern ExecAuxRowMark *ExecBuildAuxRowMark(ExecRowMark *erm, List *targetlist);
extern TupleTableSlot *EvalPlanQual(EState *estate, EPQState *epqstate,
    Relation relation, Index rti,
    ItemPointer tid, TransactionId priorXmax);
extern HeapTuple EvalPlanQualFetch(EState *estate, Relation relation,
      int lockmode, ItemPointer tid, TransactionId priorXmax);
extern void EvalPlanQualInit(EPQState *epqstate, EState *estate,
     Plan *subplan, List *auxrowmarks, int epqParam);
extern void EvalPlanQualSetPlan(EPQState *epqstate,
     Plan *subplan, List *auxrowmarks);
extern void EvalPlanQualSetTuple(EPQState *epqstate, Index rti,
      HeapTuple tuple);
extern HeapTuple EvalPlanQualGetTuple(EPQState *epqstate, Index rti);


extern void EvalPlanQualFetchRowMarks(EPQState *epqstate);
extern TupleTableSlot *EvalPlanQualNext(EPQState *epqstate);
extern void EvalPlanQualBegin(EPQState *epqstate, EState *parentestate);
extern void EvalPlanQualEnd(EPQState *epqstate);




extern PlanState *ExecInitNode(Plan *node, EState *estate, int eflags);
extern TupleTableSlot *ExecProcNode(PlanState *node);
extern Node *MultiExecProcNode(PlanState *node);
extern void ExecEndNode(PlanState *node);




extern Datum GetAttributeByNum(HeapTupleHeader tuple, AttrNumber attrno,
      bool *isNull);
extern Datum GetAttributeByName(HeapTupleHeader tuple, const char *attname,
       bool *isNull);
extern Tuplestorestate *ExecMakeTableFunctionResult(ExprState *funcexpr,
       ExprContext *econtext,
       TupleDesc expectedDesc,
       bool randomAccess);
extern Datum ExecEvalExprSwitchContext(ExprState *expression, ExprContext *econtext,
        bool *isNull, ExprDoneCond *isDone);
extern ExprState *ExecInitExpr(Expr *node, PlanState *parent);
extern ExprState *ExecPrepareExpr(Expr *node, EState *estate);
extern bool ExecQual(List *qual, ExprContext *econtext, bool resultForNull);
extern int ExecTargetListLength(List *targetlist);
extern int ExecCleanTargetListLength(List *targetlist);
extern TupleTableSlot *ExecProject(ProjectionInfo *projInfo,
   ExprDoneCond *isDone);




typedef TupleTableSlot *(*ExecScanAccessMtd) (ScanState *node);
typedef bool (*ExecScanRecheckMtd) (ScanState *node, TupleTableSlot *slot);

extern TupleTableSlot *ExecScan(ScanState *node, ExecScanAccessMtd accessMtd,
   ExecScanRecheckMtd recheckMtd);
extern void ExecAssignScanProjectionInfo(ScanState *node);
extern void ExecScanReScan(ScanState *node);




extern void ExecInitResultTupleSlot(EState *estate, PlanState *planstate);
extern void ExecInitScanTupleSlot(EState *estate, ScanState *scanstate);
extern TupleTableSlot *ExecInitExtraTupleSlot(EState *estate);
extern TupleTableSlot *ExecInitNullTupleSlot(EState *estate,
       TupleDesc tupType);
extern TupleDesc ExecTypeFromTL(List *targetList, bool hasoid);
extern TupleDesc ExecCleanTypeFromTL(List *targetList, bool hasoid);
extern TupleDesc ExecTypeFromExprList(List *exprList, List *namesList);
extern void UpdateChangedParamSet(PlanState *node, Bitmapset *newchg);

typedef struct TupOutputState
{
 TupleTableSlot *slot;
 DestReceiver *dest;
} TupOutputState;

extern TupOutputState *begin_tup_output_tupdesc(DestReceiver *dest,
       TupleDesc tupdesc);
extern void do_tup_output(TupOutputState *tstate, Datum *values, bool *isnull);
extern void do_text_output_multiline(TupOutputState *tstate, char *text);
extern void end_tup_output(TupOutputState *tstate);
# 298 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/executor.h"
extern EState *CreateExecutorState(void);
extern void FreeExecutorState(EState *estate);
extern ExprContext *CreateExprContext(EState *estate);
extern ExprContext *CreateStandaloneExprContext(void);
extern void FreeExprContext(ExprContext *econtext, bool isCommit);
extern void ReScanExprContext(ExprContext *econtext);




extern ExprContext *MakePerTupleExprContext(EState *estate);
# 326 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/executor.h"
extern void ExecAssignExprContext(EState *estate, PlanState *planstate);
extern void ExecAssignResultType(PlanState *planstate, TupleDesc tupDesc);
extern void ExecAssignResultTypeFromTL(PlanState *planstate);
extern TupleDesc ExecGetResultType(PlanState *planstate);
extern ProjectionInfo *ExecBuildProjectionInfo(List *targetList,
      ExprContext *econtext,
      TupleTableSlot *slot,
      TupleDesc inputDesc);
extern void ExecAssignProjectionInfo(PlanState *planstate,
       TupleDesc inputDesc);
extern void ExecFreeExprContext(PlanState *planstate);
extern TupleDesc ExecGetScanType(ScanState *scanstate);
extern void ExecAssignScanType(ScanState *scanstate, TupleDesc tupDesc);
extern void ExecAssignScanTypeFromOuterPlan(ScanState *scanstate);

extern bool ExecRelationIsTargetRelation(EState *estate, Index scanrelid);

extern Relation ExecOpenScanRelation(EState *estate, Index scanrelid);
extern void ExecCloseScanRelation(Relation scanrel);

extern void ExecOpenIndices(ResultRelInfo *resultRelInfo);
extern void ExecCloseIndices(ResultRelInfo *resultRelInfo);
extern List *ExecInsertIndexTuples(TupleTableSlot *slot, ItemPointer tupleid,
       EState *estate);
extern bool check_exclusion_constraint(Relation heap, Relation index,
         IndexInfo *indexInfo,
         ItemPointer tupleid,
         Datum *values, bool *isnull,
         EState *estate,
         bool newIndex, bool errorOK);

extern void RegisterExprContextCallback(ExprContext *econtext,
       ExprContextCallbackFunction function,
       Datum arg);
extern void UnregisterExprContextCallback(ExprContext *econtext,
         ExprContextCallbackFunction function,
         Datum arg);
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/explain.h" 2

typedef enum ExplainFormat
{
 EXPLAIN_FORMAT_TEXT,
 EXPLAIN_FORMAT_XML,
 EXPLAIN_FORMAT_JSON,
 EXPLAIN_FORMAT_YAML
} ExplainFormat;

typedef struct ExplainState
{
 StringInfo str;

 bool verbose;
 bool analyze;
 bool costs;
 bool buffers;
 bool timing;
 ExplainFormat format;

 PlannedStmt *pstmt;
 List *rtable;
 int indent;
 List *grouping_stack;
} ExplainState;


typedef void (*ExplainOneQuery_hook_type) (Query *query,
                IntoClause *into,
                ExplainState *es,
              const char *queryString,
                ParamListInfo params);
extern ExplainOneQuery_hook_type ExplainOneQuery_hook;


typedef const char *(*explain_get_index_name_hook_type) (Oid indexId);
extern explain_get_index_name_hook_type explain_get_index_name_hook;


extern void ExplainQuery(ExplainStmt *stmt, const char *queryString,
    ParamListInfo params, DestReceiver *dest);

extern void ExplainInitState(ExplainState *es);

extern TupleDesc ExplainResultDesc(ExplainStmt *stmt);

extern void ExplainOneUtility(Node *utilityStmt, IntoClause *into,
      ExplainState *es,
      const char *queryString, ParamListInfo params);

extern void ExplainOnePlan(PlannedStmt *plannedstmt, IntoClause *into,
      ExplainState *es,
      const char *queryString, ParamListInfo params);

extern void ExplainPrintPlan(ExplainState *es, QueryDesc *queryDesc);

extern void ExplainQueryText(ExplainState *es, QueryDesc *queryDesc);

extern void ExplainBeginOutput(ExplainState *es);
extern void ExplainEndOutput(ExplainState *es);
extern void ExplainSeparatePlans(ExplainState *es);

extern void ExplainPropertyList(const char *qlabel, List *data,
     ExplainState *es);
extern void ExplainPropertyText(const char *qlabel, const char *value,
     ExplainState *es);
extern void ExplainPropertyInteger(const char *qlabel, int value,
        ExplainState *es);
extern void ExplainPropertyLong(const char *qlabel, long value,
     ExplainState *es);
extern void ExplainPropertyFloat(const char *qlabel, double value, int ndigits,
      ExplainState *es);
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/prepare.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/plancache.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/plancache.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/params.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/plancache.h" 2
# 76 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/plancache.h"
typedef struct CachedPlanSource
{
 int magic;
 Node *raw_parse_tree;
 const char *query_string;
 const char *commandTag;
 Oid *param_types;
 int num_params;
 ParserSetupHook parserSetup;
 void *parserSetupArg;
 int cursor_options;
 bool fixed_result;
 TupleDesc resultDesc;
 struct OverrideSearchPath *search_path;
 MemoryContext context;

 List *query_list;
 List *relationOids;
 List *invalItems;
 MemoryContext query_context;

 struct CachedPlan *gplan;

 bool is_complete;
 bool is_saved;
 bool is_valid;
 bool is_oneshot;
 int generation;

 struct CachedPlanSource *next_saved;

 double generic_cost;
 double total_custom_cost;
 int num_custom_plans;
} CachedPlanSource;
# 122 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/plancache.h"
typedef struct CachedPlan
{
 int magic;
 List *stmt_list;

 bool is_saved;
 bool is_valid;
 bool is_oneshot;
 TransactionId saved_xmin;

 int generation;
 int refcount;
 MemoryContext context;
} CachedPlan;


extern void InitPlanCache(void);
extern void ResetPlanCache(void);

extern CachedPlanSource *CreateCachedPlan(Node *raw_parse_tree,
     const char *query_string,
     const char *commandTag);
extern CachedPlanSource *CreateOneShotCachedPlan(Node *raw_parse_tree,
     const char *query_string,
     const char *commandTag);
extern void CompleteCachedPlan(CachedPlanSource *plansource,
       List *querytree_list,
       MemoryContext querytree_context,
       Oid *param_types,
       int num_params,
       ParserSetupHook parserSetup,
       void *parserSetupArg,
       int cursor_options,
       bool fixed_result);

extern void SaveCachedPlan(CachedPlanSource *plansource);
extern void DropCachedPlan(CachedPlanSource *plansource);

extern void CachedPlanSetParentContext(CachedPlanSource *plansource,
         MemoryContext newcontext);

extern CachedPlanSource *CopyCachedPlan(CachedPlanSource *plansource);

extern bool CachedPlanIsValid(CachedPlanSource *plansource);

extern List *CachedPlanGetTargetList(CachedPlanSource *plansource);

extern CachedPlan *GetCachedPlan(CachedPlanSource *plansource,
     ParamListInfo boundParams,
     bool useResOwner);
extern void ReleaseCachedPlan(CachedPlan *plan, bool useResOwner);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/prepare.h" 2
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/prepare.h"
typedef struct
{

 char stmt_name[64];
 CachedPlanSource *plansource;
 bool from_sql;
 TimestampTz prepare_time;
} PreparedStatement;



extern void PrepareQuery(PrepareStmt *stmt, const char *queryString);
extern void ExecuteQuery(ExecuteStmt *stmt, IntoClause *intoClause,
    const char *queryString, ParamListInfo params,
    DestReceiver *dest, char *completionTag);
extern void DeallocateQuery(DeallocateStmt *stmt);
extern void ExplainExecuteQuery(ExecuteStmt *execstmt, IntoClause *into,
     ExplainState *es,
     const char *queryString, ParamListInfo params);


extern void StorePreparedStatement(const char *stmt_name,
        CachedPlanSource *plansource,
        bool from_sql);
extern PreparedStatement *FetchPreparedStatement(const char *stmt_name,
        bool throwError);
extern void DropPreparedStatement(const char *stmt_name, bool showError);
extern TupleDesc FetchPreparedStatementResultDesc(PreparedStatement *stmt);
extern List *FetchPreparedStatementTargetList(PreparedStatement *stmt);

extern void DropAllPreparedStatements(void);
# 36 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/vacuum.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/vacuum.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/vacuum.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_statistic.h" 1
# 31 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_statistic.h"
typedef struct FormData_pg_statistic
{

 Oid starelid;
 int2 staattnum;
 bool stainherit;


 float4 stanullfrac;
# 51 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_statistic.h"
 int4 stawidth;
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_statistic.h"
 float4 stadistinct;
# 87 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_statistic.h"
 int2 stakind1;
 int2 stakind2;
 int2 stakind3;
 int2 stakind4;
 int2 stakind5;

 Oid staop1;
 Oid staop2;
 Oid staop3;
 Oid staop4;
 Oid staop5;
# 118 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_statistic.h"
} FormData_pg_statistic;
# 128 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_statistic.h"
typedef FormData_pg_statistic *Form_pg_statistic;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/vacuum.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h" 1
# 37 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
typedef struct FormData_pg_type
{
 NameData typname;
 Oid typnamespace;
 Oid typowner;
# 50 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
 int2 typlen;
# 60 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
 bool typbyval;
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
 char typtype;







 char typcategory;

 bool typispreferred;





 bool typisdefined;

 char typdelim;

 Oid typrelid;
# 102 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
 Oid typelem;





 Oid typarray;




 regproc typinput;
 regproc typoutput;
 regproc typreceive;
 regproc typsend;




 regproc typmodin;
 regproc typmodout;




 regproc typanalyze;
# 153 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
 char typalign;
# 165 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
 char typstorage;
# 175 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
 bool typnotnull;





 Oid typbasetype;






 int4 typtypmod;





 int4 typndims;





 Oid typcollation;
# 226 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
} FormData_pg_type;






typedef FormData_pg_type *Form_pg_type;
# 286 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;





extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;




extern int no_such_variable;
extern int no_such_variable;
# 379 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;





extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;




extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;



extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;


extern int no_such_variable;
extern int no_such_variable;

extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
extern int no_such_variable;
# 639 "/Users/parrt/tmp/postgresql-9.2.4/src/include/catalog/pg_type.h"
extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;

extern int no_such_variable;
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/vacuum.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/vacuum.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/vacuum.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/lock.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/vacuum.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/vacuum.h" 2
# 59 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/vacuum.h"
typedef struct VacAttrStats *VacAttrStatsP;

typedef Datum (*AnalyzeAttrFetchFunc) (VacAttrStatsP stats, int rownum,
               bool *isNull);

typedef void (*AnalyzeAttrComputeStatsFunc) (VacAttrStatsP stats,
             AnalyzeAttrFetchFunc fetchfunc,
               int samplerows,
               double totalrows);

typedef struct VacAttrStats
{
# 81 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/vacuum.h"
 Form_pg_attribute attr;
 Oid attrtypid;
 int32 attrtypmod;
 Form_pg_type attrtype;
 MemoryContext anl_context;





 AnalyzeAttrComputeStatsFunc compute_stats;
 int minrows;
 void *extra_data;





 bool stats_valid;
 float4 stanullfrac;
 int4 stawidth;
 float4 stadistinct;
 int2 stakind[5];
 Oid staop[5];
 int numnumbers[5];
 float4 *stanumbers[5];
 int numvalues[5];
 Datum *stavalues[5];







 Oid statypid[5];
 int2 statyplen[5];
 bool statypbyval[5];
 char statypalign[5];





 int tupattnum;
 HeapTuple *rows;
 TupleDesc tupDesc;
 Datum *exprvals;
 bool *exprnulls;
 int rowstride;
} VacAttrStats;



extern int default_statistics_target;

extern int vacuum_freeze_min_age;
extern int vacuum_freeze_table_age;



extern void vacuum(VacuumStmt *vacstmt, Oid relid, bool do_toast,
    BufferAccessStrategy bstrategy, bool for_wraparound, bool isTopLevel);
extern void vac_open_indexes(Relation relation, LOCKMODE lockmode,
     int *nindexes, Relation **Irel);
extern void vac_close_indexes(int nindexes, Relation *Irel, LOCKMODE lockmode);
extern double vac_estimate_reltuples(Relation relation, bool is_analyze,
        BlockNumber total_pages,
        BlockNumber scanned_pages,
        double scanned_tuples);
extern void vac_update_relstats(Relation relation,
     BlockNumber num_pages,
     double num_tuples,
     BlockNumber num_all_visible_pages,
     bool hasindex,
     TransactionId frozenxid);
extern void vacuum_set_xid_limits(int freeze_min_age, int freeze_table_age,
       bool sharedRel,
       TransactionId *oldestXmin,
       TransactionId *freezeLimit,
       TransactionId *freezeTableLimit);
extern void vac_update_datfrozenxid(void);
extern void vacuum_delay_point(void);


extern void lazy_vacuum_rel(Relation onerel, VacuumStmt *vacstmt,
    BufferAccessStrategy bstrategy);


extern void analyze_rel(Oid relid, VacuumStmt *vacstmt,
   BufferAccessStrategy bstrategy);
extern bool std_typanalyze(VacAttrStats *stats);
extern double anl_random_fract(void);
extern double anl_init_selection_state(int n);
extern double anl_get_next_S(double t, int n, double *stateptr);
# 37 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/variable.h" 1
# 13 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/variable.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/dest.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h" 1
# 59 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h"
# 1 "./fmgr.h" 1
# 60 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h" 2
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h"
typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
} ArrayType;




typedef struct ArrayBuildState
{
 MemoryContext mcontext;
 Datum *dvalues;
 bool *dnulls;
 int alen;
 int nelems;
 Oid element_type;
 int16 typlen;
 bool typbyval;
 char typalign;
} ArrayBuildState;




typedef struct ArrayMetaState
{
 Oid element_type;
 int16 typlen;
 bool typbyval;
 char typalign;
 char typdelim;
 Oid typioparam;
 Oid typiofunc;
 FmgrInfo proc;
} ArrayMetaState;




typedef struct ArrayMapState
{
 ArrayMetaState inp_extra;
 ArrayMetaState ret_extra;
} ArrayMapState;


typedef struct ArrayIteratorData *ArrayIterator;
# 182 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/array.h"
extern bool Array_nulls;




extern Datum array_in(FunctionCallInfo fcinfo);
extern Datum array_out(FunctionCallInfo fcinfo);
extern Datum array_recv(FunctionCallInfo fcinfo);
extern Datum array_send(FunctionCallInfo fcinfo);
extern Datum array_eq(FunctionCallInfo fcinfo);
extern Datum array_ne(FunctionCallInfo fcinfo);
extern Datum array_lt(FunctionCallInfo fcinfo);
extern Datum array_gt(FunctionCallInfo fcinfo);
extern Datum array_le(FunctionCallInfo fcinfo);
extern Datum array_ge(FunctionCallInfo fcinfo);
extern Datum btarraycmp(FunctionCallInfo fcinfo);
extern Datum hash_array(FunctionCallInfo fcinfo);
extern Datum arrayoverlap(FunctionCallInfo fcinfo);
extern Datum arraycontains(FunctionCallInfo fcinfo);
extern Datum arraycontained(FunctionCallInfo fcinfo);
extern Datum array_ndims(FunctionCallInfo fcinfo);
extern Datum array_dims(FunctionCallInfo fcinfo);
extern Datum array_lower(FunctionCallInfo fcinfo);
extern Datum array_upper(FunctionCallInfo fcinfo);
extern Datum array_length(FunctionCallInfo fcinfo);
extern Datum array_larger(FunctionCallInfo fcinfo);
extern Datum array_smaller(FunctionCallInfo fcinfo);
extern Datum generate_subscripts(FunctionCallInfo fcinfo);
extern Datum generate_subscripts_nodir(FunctionCallInfo fcinfo);
extern Datum array_fill(FunctionCallInfo fcinfo);
extern Datum array_fill_with_lower_bounds(FunctionCallInfo fcinfo);
extern Datum array_unnest(FunctionCallInfo fcinfo);

extern Datum array_ref(ArrayType *array, int nSubscripts, int *indx,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign,
    bool *isNull);
extern ArrayType *array_set(ArrayType *array, int nSubscripts, int *indx,
    Datum dataValue, bool isNull,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign);
extern ArrayType *array_get_slice(ArrayType *array, int nSubscripts,
    int *upperIndx, int *lowerIndx,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign);
extern ArrayType *array_set_slice(ArrayType *array, int nSubscripts,
    int *upperIndx, int *lowerIndx,
    ArrayType *srcArray, bool isNull,
    int arraytyplen, int elmlen, bool elmbyval, char elmalign);

extern Datum array_map(FunctionCallInfo fcinfo, Oid inpType, Oid retType,
    ArrayMapState *amstate);

extern void array_bitmap_copy(bits8 *destbitmap, int destoffset,
      const bits8 *srcbitmap, int srcoffset,
      int nitems);

extern ArrayType *construct_array(Datum *elems, int nelems,
    Oid elmtype,
    int elmlen, bool elmbyval, char elmalign);
extern ArrayType *construct_md_array(Datum *elems,
       bool *nulls,
       int ndims,
       int *dims,
       int *lbs,
       Oid elmtype, int elmlen, bool elmbyval, char elmalign);
extern ArrayType *construct_empty_array(Oid elmtype);
extern void deconstruct_array(ArrayType *array,
      Oid elmtype,
      int elmlen, bool elmbyval, char elmalign,
      Datum **elemsp, bool **nullsp, int *nelemsp);
extern bool array_contains_nulls(ArrayType *array);
extern ArrayBuildState *accumArrayResult(ArrayBuildState *astate,
     Datum dvalue, bool disnull,
     Oid element_type,
     MemoryContext rcontext);
extern Datum makeArrayResult(ArrayBuildState *astate,
    MemoryContext rcontext);
extern Datum makeMdArrayResult(ArrayBuildState *astate, int ndims,
      int *dims, int *lbs, MemoryContext rcontext, bool release);

extern ArrayIterator array_create_iterator(ArrayType *arr, int slice_ndim);
extern bool array_iterate(ArrayIterator iterator, Datum *value, bool *isnull);
extern void array_free_iterator(ArrayIterator iterator);





extern int ArrayGetOffset(int n, const int *dim, const int *lb, const int *indx);
extern int ArrayGetOffset0(int n, const int *tup, const int *scale);
extern int ArrayGetNItems(int ndim, const int *dims);
extern void mda_get_range(int n, int *span, const int *st, const int *endp);
extern void mda_get_prod(int n, const int *range, int *prod);
extern void mda_get_offset_values(int n, int *dist, const int *prod, const int *span);
extern int mda_next_tuple(int n, int *curr, const int *span);
extern int32 *ArrayGetIntegerTypmods(ArrayType *arr, int *n);




extern Datum array_push(FunctionCallInfo fcinfo);
extern Datum array_cat(FunctionCallInfo fcinfo);

extern ArrayType *create_singleton_array(FunctionCallInfo fcinfo,
        Oid element_type,
        Datum element,
        bool isNull,
        int ndims);

extern Datum array_agg_transfn(FunctionCallInfo fcinfo);
extern Datum array_agg_finalfn(FunctionCallInfo fcinfo);




extern Datum array_typanalyze(FunctionCallInfo fcinfo);
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 2
# 51 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
typedef enum
{
 PGC_INTERNAL,
 PGC_POSTMASTER,
 PGC_SIGHUP,
 PGC_BACKEND,
 PGC_SUSET,
 PGC_USERSET
} GucContext;
# 83 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
typedef enum
{
 PGC_S_DEFAULT,
 PGC_S_DYNAMIC_DEFAULT,
 PGC_S_ENV_VAR,
 PGC_S_FILE,
 PGC_S_ARGV,
 PGC_S_DATABASE,
 PGC_S_USER,
 PGC_S_DATABASE_USER,
 PGC_S_CLIENT,
 PGC_S_OVERRIDE,
 PGC_S_INTERACTIVE,
 PGC_S_TEST,
 PGC_S_SESSION
} GucSource;





typedef struct ConfigVariable
{
 char *name;
 char *value;
 char *filename;
 int sourceline;
 struct ConfigVariable *next;
} ConfigVariable;

extern bool ParseConfigFile(const char *config_file, const char *calling_file,
    bool strict, int depth, int elevel,
    ConfigVariable **head_p, ConfigVariable **tail_p);
extern bool ParseConfigFp(FILE *fp, const char *config_file,
     int depth, int elevel,
     ConfigVariable **head_p, ConfigVariable **tail_p);
extern void FreeConfigVariables(ConfigVariable *list);






struct config_enum_entry
{
 const char *name;
 int val;
 bool hidden;
};




typedef bool (*GucBoolCheckHook) (bool *newval, void **extra, GucSource source);
typedef bool (*GucIntCheckHook) (int *newval, void **extra, GucSource source);
typedef bool (*GucRealCheckHook) (double *newval, void **extra, GucSource source);
typedef bool (*GucStringCheckHook) (char **newval, void **extra, GucSource source);
typedef bool (*GucEnumCheckHook) (int *newval, void **extra, GucSource source);

typedef void (*GucBoolAssignHook) (bool newval, void *extra);
typedef void (*GucIntAssignHook) (int newval, void *extra);
typedef void (*GucRealAssignHook) (double newval, void *extra);
typedef void (*GucStringAssignHook) (const char *newval, void *extra);
typedef void (*GucEnumAssignHook) (int newval, void *extra);

typedef const char *(*GucShowHook) (void);




typedef enum
{

 GUC_ACTION_SET,
 GUC_ACTION_LOCAL,
 GUC_ACTION_SAVE
} GucAction;
# 190 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
extern bool log_duration;
extern bool Debug_print_plan;
extern bool Debug_print_parse;
extern bool Debug_print_rewritten;
extern bool Debug_pretty_print;

extern bool log_parser_stats;
extern bool log_planner_stats;
extern bool log_executor_stats;
extern bool log_statement_stats;
extern bool log_btree_build_stats;

extern bool check_function_bodies;
extern bool default_with_oids;
extern bool SQL_inheritance;

extern int log_min_error_statement;
extern int log_min_messages;
extern int client_min_messages;
extern int log_min_duration_statement;
extern int log_temp_files;

extern int temp_file_limit;

extern int num_temp_buffers;

extern char *data_directory;
extern char *ConfigFileName;
extern char *HbaFileName;
extern char *IdentFileName;
extern char *external_pid_file;

extern char *application_name;

extern int tcp_keepalives_idle;
extern int tcp_keepalives_interval;
extern int tcp_keepalives_count;




extern void SetConfigOption(const char *name, const char *value,
    GucContext context, GucSource source);

extern void DefineCustomBoolVariable(
       const char *name,
       const char *short_desc,
       const char *long_desc,
       bool *valueAddr,
       bool bootValue,
       GucContext context,
       int flags,
       GucBoolCheckHook check_hook,
       GucBoolAssignHook assign_hook,
       GucShowHook show_hook);

extern void DefineCustomIntVariable(
      const char *name,
      const char *short_desc,
      const char *long_desc,
      int *valueAddr,
      int bootValue,
      int minValue,
      int maxValue,
      GucContext context,
      int flags,
      GucIntCheckHook check_hook,
      GucIntAssignHook assign_hook,
      GucShowHook show_hook);

extern void DefineCustomRealVariable(
       const char *name,
       const char *short_desc,
       const char *long_desc,
       double *valueAddr,
       double bootValue,
       double minValue,
       double maxValue,
       GucContext context,
       int flags,
       GucRealCheckHook check_hook,
       GucRealAssignHook assign_hook,
       GucShowHook show_hook);

extern void DefineCustomStringVariable(
         const char *name,
         const char *short_desc,
         const char *long_desc,
         char **valueAddr,
         const char *bootValue,
         GucContext context,
         int flags,
         GucStringCheckHook check_hook,
         GucStringAssignHook assign_hook,
         GucShowHook show_hook);

extern void DefineCustomEnumVariable(
       const char *name,
       const char *short_desc,
       const char *long_desc,
       int *valueAddr,
       int bootValue,
       const struct config_enum_entry * options,
       GucContext context,
       int flags,
       GucEnumCheckHook check_hook,
       GucEnumAssignHook assign_hook,
       GucShowHook show_hook);

extern void EmitWarningsOnPlaceholders(const char *className);

extern const char *GetConfigOption(const char *name, bool missing_ok,
    bool restrict_superuser);
extern const char *GetConfigOptionResetString(const char *name);
extern void ProcessConfigFile(GucContext context);
extern void InitializeGUCOptions(void);
extern bool SelectConfigFiles(const char *userDoption, const char *progname);
extern void ResetAllOptions(void);
extern void AtStart_GUC(void);
extern int NewGUCNestLevel(void);
extern void AtEOXact_GUC(bool isCommit, int nestLevel);
extern void BeginReportingGUCOptions(void);
extern void ParseLongOption(const char *string, char **name, char **value);
extern bool parse_int(const char *value, int *result, int flags,
    const char **hintmsg);
extern bool parse_real(const char *value, double *result);
extern int set_config_option(const char *name, const char *value,
      GucContext context, GucSource source,
      GucAction action, bool changeVal, int elevel);
extern char *GetConfigOptionByName(const char *name, const char **varname);
extern void GetConfigOptionByNum(int varnum, const char **values, bool *noshow);
extern int GetNumConfigOptions(void);

extern void SetPGVariable(const char *name, List *args, bool is_local);
extern void GetPGVariable(const char *name, DestReceiver *dest);
extern TupleDesc GetPGVariableResultDesc(const char *name);

extern void ExecSetVariableStmt(VariableSetStmt *stmt);
extern char *ExtractSetVariableArgs(VariableSetStmt *stmt);

extern void ProcessGUCArray(ArrayType *array,
    GucContext context, GucSource source, GucAction action);
extern ArrayType *GUCArrayAdd(ArrayType *array, const char *name, const char *value);
extern ArrayType *GUCArrayDelete(ArrayType *array, const char *name);
extern ArrayType *GUCArrayReset(ArrayType *array);
# 343 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
extern char *GUC_check_errmsg_string;
extern char *GUC_check_errdetail_string;
extern char *GUC_check_errhint_string;

extern void GUC_check_errcode(int sqlerrcode);
# 369 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h"
extern bool check_default_tablespace(char **newval, void **extra, GucSource source);
extern bool check_temp_tablespaces(char **newval, void **extra, GucSource source);
extern void assign_temp_tablespaces(const char *newval, void *extra);


extern bool check_search_path(char **newval, void **extra, GucSource source);
extern void assign_search_path(const char *newval, void *extra);


extern bool check_wal_buffers(int *newval, void **extra, GucSource source);
extern void assign_xlog_sync_method(int new_sync_method, void *extra);
# 14 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/variable.h" 2


extern bool check_datestyle(char **newval, void **extra, GucSource source);
extern void assign_datestyle(const char *newval, void *extra);
extern bool check_timezone(char **newval, void **extra, GucSource source);
extern void assign_timezone(const char *newval, void *extra);
extern const char *show_timezone(void);
extern bool check_log_timezone(char **newval, void **extra, GucSource source);
extern void assign_log_timezone(const char *newval, void *extra);
extern const char *show_log_timezone(void);
extern bool check_transaction_read_only(bool *newval, void **extra, GucSource source);
extern bool check_XactIsoLevel(char **newval, void **extra, GucSource source);
extern void assign_XactIsoLevel(const char *newval, void *extra);
extern const char *show_XactIsoLevel(void);
extern bool check_transaction_deferrable(bool *newval, void **extra, GucSource source);
extern bool check_random_seed(double *newval, void **extra, GucSource source);
extern void assign_random_seed(double newval, void *extra);
extern const char *show_random_seed(void);
extern bool check_client_encoding(char **newval, void **extra, GucSource source);
extern void assign_client_encoding(const char *newval, void *extra);
extern bool check_session_authorization(char **newval, void **extra, GucSource source);
extern void assign_session_authorization(const char *newval, void *extra);
extern bool check_role(char **newval, void **extra, GucSource source);
extern void assign_role(const char *newval, void *extra);
extern const char *show_role(void);
# 38 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/trigger.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/trigger.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/trigger.h" 2
# 27 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/trigger.h"
typedef uint32 TriggerEvent;

typedef struct TriggerData
{
 NodeTag type;
 TriggerEvent tg_event;
 Relation tg_relation;
 HeapTuple tg_trigtuple;
 HeapTuple tg_newtuple;
 Trigger *tg_trigger;
 Buffer tg_trigtuplebuf;
 Buffer tg_newtuplebuf;
} TriggerData;
# 100 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/trigger.h"
extern int SessionReplicationRole;
# 111 "/Users/parrt/tmp/postgresql-9.2.4/src/include/commands/trigger.h"
extern Oid CreateTrigger(CreateTrigStmt *stmt, const char *queryString,
     Oid constraintOid, Oid indexOid,
     bool isInternal);

extern void RemoveTriggerById(Oid trigOid);
extern Oid get_trigger_oid(Oid relid, const char *name, bool missing_ok);

extern void renametrig(RenameStmt *stmt);

extern void EnableDisableTrigger(Relation rel, const char *tgname,
      char fires_when, bool skip_system);

extern void RelationBuildTriggers(Relation relation);

extern TriggerDesc *CopyTriggerDesc(TriggerDesc *trigdesc);

extern void FreeTriggerDesc(TriggerDesc *trigdesc);

extern void ExecBSInsertTriggers(EState *estate,
      ResultRelInfo *relinfo);
extern void ExecASInsertTriggers(EState *estate,
      ResultRelInfo *relinfo);
extern TupleTableSlot *ExecBRInsertTriggers(EState *estate,
      ResultRelInfo *relinfo,
      TupleTableSlot *slot);
extern void ExecARInsertTriggers(EState *estate,
      ResultRelInfo *relinfo,
      HeapTuple trigtuple,
      List *recheckIndexes);
extern TupleTableSlot *ExecIRInsertTriggers(EState *estate,
      ResultRelInfo *relinfo,
      TupleTableSlot *slot);
extern void ExecBSDeleteTriggers(EState *estate,
      ResultRelInfo *relinfo);
extern void ExecASDeleteTriggers(EState *estate,
      ResultRelInfo *relinfo);
extern bool ExecBRDeleteTriggers(EState *estate,
      EPQState *epqstate,
      ResultRelInfo *relinfo,
      ItemPointer tupleid);
extern void ExecARDeleteTriggers(EState *estate,
      ResultRelInfo *relinfo,
      ItemPointer tupleid);
extern bool ExecIRDeleteTriggers(EState *estate,
      ResultRelInfo *relinfo,
      HeapTuple trigtuple);
extern void ExecBSUpdateTriggers(EState *estate,
      ResultRelInfo *relinfo);
extern void ExecASUpdateTriggers(EState *estate,
      ResultRelInfo *relinfo);
extern TupleTableSlot *ExecBRUpdateTriggers(EState *estate,
      EPQState *epqstate,
      ResultRelInfo *relinfo,
      ItemPointer tupleid,
      TupleTableSlot *slot);
extern void ExecARUpdateTriggers(EState *estate,
      ResultRelInfo *relinfo,
      ItemPointer tupleid,
      HeapTuple newtuple,
      List *recheckIndexes);
extern TupleTableSlot *ExecIRUpdateTriggers(EState *estate,
      ResultRelInfo *relinfo,
      HeapTuple trigtuple,
      TupleTableSlot *slot);
extern void ExecBSTruncateTriggers(EState *estate,
        ResultRelInfo *relinfo);
extern void ExecASTruncateTriggers(EState *estate,
        ResultRelInfo *relinfo);

extern void AfterTriggerBeginXact(void);
extern void AfterTriggerBeginQuery(void);
extern void AfterTriggerEndQuery(EState *estate);
extern void AfterTriggerFireDeferred(void);
extern void AfterTriggerEndXact(bool isCommit);
extern void AfterTriggerBeginSubXact(void);
extern void AfterTriggerEndSubXact(bool isCommit);
extern void AfterTriggerSetState(ConstraintsSetStmt *stmt);
extern bool AfterTriggerPendingOnRel(Oid relid);





extern bool RI_FKey_keyequal_upd_pk(Trigger *trigger, Relation pk_rel,
      HeapTuple old_row, HeapTuple new_row);
extern bool RI_FKey_keyequal_upd_fk(Trigger *trigger, Relation fk_rel,
      HeapTuple old_row, HeapTuple new_row);
extern bool RI_Initial_Check(Trigger *trigger,
     Relation fk_rel, Relation pk_rel);






extern int RI_FKey_trigger_type(Oid tgfoid);

extern Datum pg_trigger_depth(FunctionCallInfo fcinfo);
# 39 "guc.c" 2
# 1 "funcapi.h" 1
# 19 "funcapi.h"
# 1 "fmgr.h" 1
# 20 "funcapi.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/tupdesc.h" 1
# 21 "funcapi.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/executor.h" 1
# 22 "funcapi.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/tuptable.h" 1
# 23 "funcapi.h" 2
# 35 "funcapi.h"
typedef struct AttInMetadata
{

 TupleDesc tupdesc;


 FmgrInfo *attinfuncs;


 Oid *attioparams;


 int32 *atttypmods;
} AttInMetadata;
# 57 "funcapi.h"
typedef struct FuncCallContext
{






 uint32 call_cntr;
# 74 "funcapi.h"
 uint32 max_calls;







 TupleTableSlot *slot;







 void *user_fctx;
# 99 "funcapi.h"
 AttInMetadata *attinmeta;
# 109 "funcapi.h"
 MemoryContext multi_call_memory_ctx;
# 120 "funcapi.h"
 TupleDesc tuple_desc;

} FuncCallContext;
# 150 "funcapi.h"
typedef enum TypeFuncClass
{
 TYPEFUNC_SCALAR,
 TYPEFUNC_COMPOSITE,
 TYPEFUNC_RECORD,
 TYPEFUNC_OTHER
} TypeFuncClass;

extern TypeFuncClass get_call_result_type(FunctionCallInfo fcinfo,
      Oid *resultTypeId,
      TupleDesc *resultTupleDesc);
extern TypeFuncClass get_expr_result_type(Node *expr,
      Oid *resultTypeId,
      TupleDesc *resultTupleDesc);
extern TypeFuncClass get_func_result_type(Oid functionId,
      Oid *resultTypeId,
      TupleDesc *resultTupleDesc);

extern bool resolve_polymorphic_argtypes(int numargs, Oid *argtypes,
        char *argmodes,
        Node *call_expr);

extern int get_func_arg_info(HeapTuple procTup,
      Oid **p_argtypes, char ***p_argnames,
      char **p_argmodes);

extern int get_func_input_arg_names(Datum proargnames, Datum proargmodes,
       char ***arg_names);

extern char *get_func_result_name(Oid functionId);

extern TupleDesc build_function_result_tupdesc_d(Datum proallargtypes,
        Datum proargmodes,
        Datum proargnames);
extern TupleDesc build_function_result_tupdesc_t(HeapTuple procTuple);
# 223 "funcapi.h"
extern TupleDesc RelationNameGetTupleDesc(const char *relname);
extern TupleDesc TypeGetTupleDesc(Oid typeoid, List *colaliases);


extern TupleDesc BlessTupleDesc(TupleDesc tupdesc);
extern AttInMetadata *TupleDescGetAttInMetadata(TupleDesc tupdesc);
extern HeapTuple BuildTupleFromCStrings(AttInMetadata *attinmeta, char **values);
extern TupleTableSlot *TupleDescGetSlot(TupleDesc tupdesc);
# 277 "funcapi.h"
extern FuncCallContext *init_MultiFuncCall(FunctionCallInfo fcinfo);
extern FuncCallContext *per_MultiFuncCall(FunctionCallInfo fcinfo);
extern void end_MultiFuncCall(FunctionCallInfo fcinfo, FuncCallContext *funcctx);
# 40 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/auth.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/auth.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h" 1
# 29 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h"
# 1 "/usr/include/netinet/tcp.h" 1 3 4
# 71 "/usr/include/netinet/tcp.h" 3 4
typedef __uint32_t tcp_seq;
typedef __uint32_t tcp_cc;
# 81 "/usr/include/netinet/tcp.h" 3 4
struct tcphdr {
 unsigned short th_sport;
 unsigned short th_dport;
 tcp_seq th_seq;
 tcp_seq th_ack;

 unsigned int th_x2:4,
   th_off:4;





 unsigned char th_flags;
# 105 "/usr/include/netinet/tcp.h" 3 4
 unsigned short th_win;
 unsigned short th_sum;
 unsigned short th_urp;
};
# 30 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h" 2
# 68 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h" 1
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/hba.h" 1
# 14 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/hba.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h"
# 1 "/usr/include/sys/socket.h" 1 3 4
# 77 "/usr/include/sys/socket.h" 3 4
# 1 "/usr/include/machine/_param.h" 1 3 4
# 29 "/usr/include/machine/_param.h" 3 4
# 1 "/usr/include/i386/_param.h" 1 3 4
# 30 "/usr/include/machine/_param.h" 2 3 4
# 78 "/usr/include/sys/socket.h" 2 3 4
# 106 "/usr/include/sys/socket.h" 3 4
typedef __uint8_t sa_family_t;




typedef __darwin_socklen_t socklen_t;
# 131 "/usr/include/sys/socket.h" 3 4
struct iovec {
 void * iov_base;
 size_t iov_len;
};
# 219 "/usr/include/sys/socket.h" 3 4
struct linger {
 int l_onoff;
 int l_linger;
};
# 237 "/usr/include/sys/socket.h" 3 4
struct so_np_extensions {
 u_int32_t npx_flags;
 u_int32_t npx_mask;
};
# 322 "/usr/include/sys/socket.h" 3 4
struct sockaddr {
 __uint8_t sa_len;
 sa_family_t sa_family;
 char sa_data[14];
};
# 335 "/usr/include/sys/socket.h" 3 4
struct sockproto {
 __uint16_t sp_family;
 __uint16_t sp_protocol;
};
# 355 "/usr/include/sys/socket.h" 3 4
struct sockaddr_storage {
 __uint8_t ss_len;
 sa_family_t ss_family;
 char __ss_pad1[((sizeof(__int64_t)) - sizeof(__uint8_t) - sizeof(sa_family_t))];
 __int64_t __ss_align;
 char __ss_pad2[(128 - sizeof(__uint8_t) - sizeof(sa_family_t) - ((sizeof(__int64_t)) - sizeof(__uint8_t) - sizeof(sa_family_t)) - (sizeof(__int64_t)))];
};
# 462 "/usr/include/sys/socket.h" 3 4
struct msghdr {
 void *msg_name;
 socklen_t msg_namelen;
 struct iovec *msg_iov;
 int msg_iovlen;
 void *msg_control;
 socklen_t msg_controllen;
 int msg_flags;
};
# 502 "/usr/include/sys/socket.h" 3 4
struct cmsghdr {
 socklen_t cmsg_len;
 int cmsg_level;
 int cmsg_type;

};
# 592 "/usr/include/sys/socket.h" 3 4
struct sf_hdtr {
 struct iovec *headers;
 int hdr_cnt;
 struct iovec *trailers;
 int trl_cnt;
};





int accept(int, struct sockaddr * , socklen_t * )
  __asm("_" "accept" );
int bind(int, const struct sockaddr *, socklen_t) __asm("_" "bind" );
int connect(int, const struct sockaddr *, socklen_t) __asm("_" "connect" );
int getpeername(int, struct sockaddr * , socklen_t * )
  __asm("_" "getpeername" );
int getsockname(int, struct sockaddr * , socklen_t * )
  __asm("_" "getsockname" );
int getsockopt(int, int, int, void * , socklen_t * );
int listen(int, int) __asm("_" "listen" );
ssize_t recv(int, void *, size_t, int) __asm("_" "recv" );
ssize_t recvfrom(int, void *, size_t, int, struct sockaddr * ,
  socklen_t * ) __asm("_" "recvfrom" );
ssize_t recvmsg(int, struct msghdr *, int) __asm("_" "recvmsg" );
ssize_t send(int, const void *, size_t, int) __asm("_" "send" );
ssize_t sendmsg(int, const struct msghdr *, int) __asm("_" "sendmsg" );
ssize_t sendto(int, const void *, size_t,
  int, const struct sockaddr *, socklen_t) __asm("_" "sendto" );
int setsockopt(int, int, int, const void *, socklen_t);
int shutdown(int, int);
int sockatmark(int) __attribute__((visibility("default")));
int socket(int, int, int);
int socketpair(int, int, int, int *) __asm("_" "socketpair" );


int sendfile(int, int, off_t, off_t *, struct sf_hdtr *, int);



void pfctlinput(int, struct sockaddr *);


# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h" 2
# 1 "./netdb.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h" 2

# 1 "/usr/include/sys/un.h" 1 3 4
# 79 "/usr/include/sys/un.h" 3 4
struct sockaddr_un {
 unsigned char sun_len;
 sa_family_t sun_family;
 char sun_path[104];
};
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h" 2

# 1 "/usr/include/netinet/in.h" 1 3 4
# 307 "/usr/include/netinet/in.h" 3 4
struct in_addr {
 in_addr_t s_addr;
};
# 380 "/usr/include/netinet/in.h" 3 4
struct sockaddr_in {
 __uint8_t sin_len;
 sa_family_t sin_family;
 in_port_t sin_port;
 struct in_addr sin_addr;
 char sin_zero[8];
};
# 398 "/usr/include/netinet/in.h" 3 4
struct ip_opts {
 struct in_addr ip_dst;
 char ip_opts[40];
};
# 506 "/usr/include/netinet/in.h" 3 4
struct ip_mreq {
 struct in_addr imr_multiaddr;
 struct in_addr imr_interface;
};






struct ip_mreqn {
 struct in_addr imr_multiaddr;
 struct in_addr imr_address;
 int imr_ifindex;
};

#pragma pack(4)



struct ip_mreq_source {
 struct in_addr imr_multiaddr;
 struct in_addr imr_sourceaddr;
 struct in_addr imr_interface;
};





struct group_req {
 uint32_t gr_interface;
 struct sockaddr_storage gr_group;
};

struct group_source_req {
 uint32_t gsr_interface;
 struct sockaddr_storage gsr_group;
 struct sockaddr_storage gsr_source;
};
# 554 "/usr/include/netinet/in.h" 3 4
struct __msfilterreq {
 uint32_t msfr_ifindex;
 uint32_t msfr_fmode;
 uint32_t msfr_nsrcs;
 uint32_t __msfr_align;
 struct sockaddr_storage msfr_group;
 struct sockaddr_storage *msfr_srcs;
};



#pragma pack()
struct sockaddr;






int setipv4sourcefilter(int, struct in_addr, struct in_addr, uint32_t,
     uint32_t, struct in_addr *) __attribute__((visibility("default")));
int getipv4sourcefilter(int, struct in_addr, struct in_addr, uint32_t *,
     uint32_t *, struct in_addr *) __attribute__((visibility("default")));
int setsourcefilter(int, uint32_t, struct sockaddr *, socklen_t,
     uint32_t, uint32_t, struct sockaddr_storage *) __attribute__((visibility("default")));
int getsourcefilter(int, uint32_t, struct sockaddr *, socklen_t,
     uint32_t *, uint32_t *, struct sockaddr_storage *) __attribute__((visibility("default")));
# 617 "/usr/include/netinet/in.h" 3 4
struct in_pktinfo {
 unsigned int ipi_ifindex;
 struct in_addr ipi_spec_dst;
 struct in_addr ipi_addr;
};
# 661 "/usr/include/netinet/in.h" 3 4
# 1 "/usr/include/netinet6/in6.h" 1 3 4
# 158 "/usr/include/netinet6/in6.h" 3 4
struct in6_addr {
 union {
  __uint8_t __u6_addr8[16];
  __uint16_t __u6_addr16[8];
  __uint32_t __u6_addr32[4];
 } __u6_addr;
};
# 176 "/usr/include/netinet6/in6.h" 3 4
struct sockaddr_in6 {
 __uint8_t sin6_len;
 sa_family_t sin6_family;
 in_port_t sin6_port;
 __uint32_t sin6_flowinfo;
 struct in6_addr sin6_addr;
 __uint32_t sin6_scope_id;
};
# 218 "/usr/include/netinet6/in6.h" 3 4
extern const struct in6_addr in6addr_any;
extern const struct in6_addr in6addr_loopback;

extern const struct in6_addr in6addr_nodelocal_allnodes;
extern const struct in6_addr in6addr_linklocal_allnodes;
extern const struct in6_addr in6addr_linklocal_allrouters;
extern const struct in6_addr in6addr_linklocal_allv2routers;
# 526 "/usr/include/netinet6/in6.h" 3 4
struct ipv6_mreq {
 struct in6_addr ipv6mr_multiaddr;
 unsigned int ipv6mr_interface;
};




struct in6_pktinfo {
 struct in6_addr ipi6_addr;
 unsigned int ipi6_ifindex;
};




struct ip6_mtuinfo {
 struct sockaddr_in6 ip6m_addr;
 uint32_t ip6m_mtu;
};
# 621 "/usr/include/netinet6/in6.h" 3 4

struct cmsghdr;

extern int inet6_option_space(int);
extern int inet6_option_init(void *, struct cmsghdr **, int);
extern int inet6_option_append(struct cmsghdr *, const __uint8_t *,
 int, int);
extern __uint8_t *inet6_option_alloc(struct cmsghdr *, int, int, int);
extern int inet6_option_next(const struct cmsghdr *, __uint8_t **);
extern int inet6_option_find(const struct cmsghdr *, __uint8_t **, int);

extern size_t inet6_rthdr_space(int, int);
extern struct cmsghdr *inet6_rthdr_init(void *, int);
extern int inet6_rthdr_add(struct cmsghdr *, const struct in6_addr *,
  unsigned int);
extern int inet6_rthdr_lasthop(struct cmsghdr *, unsigned int);



extern int inet6_rthdr_segments(const struct cmsghdr *);
extern struct in6_addr *inet6_rthdr_getaddr(struct cmsghdr *, int);
extern int inet6_rthdr_getflags(const struct cmsghdr *, int);

extern int inet6_opt_init(void *, socklen_t);
extern int inet6_opt_append(void *, socklen_t, int, __uint8_t,
     socklen_t, __uint8_t, void **);
extern int inet6_opt_finish(void *, socklen_t, int);
extern int inet6_opt_set_val(void *, int, void *, socklen_t);

extern int inet6_opt_next(void *, socklen_t, int, __uint8_t *,
          socklen_t *, void **);
extern int inet6_opt_find(void *, socklen_t, int, __uint8_t,
     socklen_t *, void **);
extern int inet6_opt_get_val(void *, int, void *, socklen_t);
extern socklen_t inet6_rth_space(int, int);
extern void *inet6_rth_init(void *, socklen_t, int, int);
extern int inet6_rth_add(void *, const struct in6_addr *);
extern int inet6_rth_reverse(const void *, void *);
extern int inet6_rth_segments(const void *);
extern struct in6_addr *inet6_rth_getaddr(const void *, int);
extern void addrsel_policy_init(void);

# 662 "/usr/include/netinet/in.h" 2 3 4





int bindresvport(int, struct sockaddr_in *);
struct sockaddr;
int bindresvport_sa(int, struct sockaddr *);

# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h" 2
# 62 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h"
typedef struct
{
 struct sockaddr_storage addr;
 socklen_t salen;
} SockAddr;
# 113 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h"
typedef uint32 ProtocolVersion;

typedef ProtocolVersion MsgType;
# 124 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h"
typedef uint32 PacketLen;
# 141 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h"
typedef struct StartupPacket
{
 ProtocolVersion protoVersion;
 char database[64];

 char user[32];
 char options[64];
 char unused[64];
 char tty[64];
} StartupPacket;

extern bool Db_user_namespace;
# 176 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h"
typedef uint32 AuthRequest;
# 189 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h"
typedef struct CancelRequestPacket
{

 MsgType cancelRequestCode;
 uint32 backendPID;
 uint32 cancelAuthCode;
} CancelRequestPacket;
# 15 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/hba.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/pg_list.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/hba.h" 2


typedef enum UserAuth
{
 uaReject,
 uaImplicitReject,
 uaKrb5,
 uaTrust,
 uaIdent,
 uaPassword,
 uaMD5,
 uaGSS,
 uaSSPI,
 uaPAM,
 uaLDAP,
 uaCert,
 uaRADIUS,
 uaPeer
} UserAuth;

typedef enum IPCompareMethod
{
 ipCmpMask,
 ipCmpSameHost,
 ipCmpSameNet,
 ipCmpAll
} IPCompareMethod;

typedef enum ConnType
{
 ctLocal,
 ctHost,
 ctHostSSL,
 ctHostNoSSL
} ConnType;

typedef struct HbaLine
{
 int linenumber;
 ConnType conntype;
 List *databases;
 List *roles;
 struct sockaddr_storage addr;
 struct sockaddr_storage mask;
 IPCompareMethod ip_cmp_method;
 char *hostname;
 UserAuth auth_method;

 char *usermap;
 char *pamservice;
 bool ldaptls;
 char *ldapserver;
 int ldapport;
 char *ldapbinddn;
 char *ldapbindpasswd;
 char *ldapsearchattribute;
 char *ldapbasedn;
 char *ldapprefix;
 char *ldapsuffix;
 bool clientcert;
 char *krb_server_hostname;
 char *krb_realm;
 bool include_realm;
 char *radiusserver;
 char *radiussecret;
 char *radiusidentifier;
 int radiusport;
} HbaLine;


typedef struct Port hbaPort;

extern bool load_hba(void);
extern void load_ident(void);
extern void hba_getauthmethod(hbaPort *port);
extern int check_usermap(const char *usermap_name,
     const char *pg_role, const char *auth_user,
     bool case_sensitive);
extern bool pg_isblank(const char c);
# 70 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h" 2



typedef enum CAC_state
{
 CAC_OK, CAC_STARTUP, CAC_SHUTDOWN, CAC_RECOVERY, CAC_TOOMANY,
 CAC_WAITBACKUP
} CAC_state;
# 104 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h"
typedef struct Port
{
 pgsocket sock;
 bool noblock;
 ProtocolVersion proto;
 SockAddr laddr;
 SockAddr raddr;
 char *remote_host;
 char *remote_hostname;

 int remote_hostname_resolv;





 char *remote_port;
 CAC_state canAcceptConnections;






 char *database_name;
 char *user_name;
 char *cmdline_options;
 List *guc_options;




 HbaLine *hba;
 char md5Salt[4];






 TimestampTz SessionStartTime;
# 153 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h"
 int default_keepalives_idle;
 int default_keepalives_interval;
 int default_keepalives_count;
 int keepalives_idle;
 int keepalives_interval;
 int keepalives_count;
# 168 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h"
 void *gss;
# 181 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq-be.h"
} Port;


extern ProtocolVersion FrontendProtocol;



extern int pq_getkeepalivesidle(Port *port);
extern int pq_getkeepalivesinterval(Port *port);
extern int pq_getkeepalivescount(Port *port);

extern int pq_setkeepalivesidle(int idle, Port *port);
extern int pq_setkeepalivesinterval(int interval, Port *port);
extern int pq_setkeepalivescount(int count, Port *port);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/auth.h" 2

extern char *pg_krb_server_keyfile;
extern char *pg_krb_srvnam;
extern bool pg_krb_caseins_users;
extern char *pg_krb_server_hostname;
extern char *pg_krb_realm;

extern void ClientAuthentication(Port *port);


typedef void (*ClientAuthentication_hook_type) (Port *, int);
extern ClientAuthentication_hook_type ClientAuthentication_hook;
# 41 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/be-fsstubs.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/be-fsstubs.h"
# 1 "./fmgr.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/be-fsstubs.h" 2




extern Datum lo_import(FunctionCallInfo fcinfo);
extern Datum lo_import_with_oid(FunctionCallInfo fcinfo);
extern Datum lo_export(FunctionCallInfo fcinfo);

extern Datum lo_creat(FunctionCallInfo fcinfo);
extern Datum lo_create(FunctionCallInfo fcinfo);

extern Datum lo_open(FunctionCallInfo fcinfo);
extern Datum lo_close(FunctionCallInfo fcinfo);

extern Datum loread(FunctionCallInfo fcinfo);
extern Datum lowrite(FunctionCallInfo fcinfo);

extern Datum lo_lseek(FunctionCallInfo fcinfo);
extern Datum lo_tell(FunctionCallInfo fcinfo);
extern Datum lo_unlink(FunctionCallInfo fcinfo);
extern Datum lo_truncate(FunctionCallInfo fcinfo);




extern bool lo_compat_privileges;






extern int lo_read(int fd, char *buf, int len);
extern int lo_write(int fd, const char *buf, int len);




extern void AtEOXact_LargeObject(bool isCommit);
extern void AtEOSubXact_LargeObject(bool isCommit, SubTransactionId mySubid,
      SubTransactionId parentSubid);
# 42 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/stringinfo.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq.h" 2
# 29 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq.h"
typedef struct
{
 int len;
 int isint;
 union
 {
  int *ptr;
  int integer;
 } u;
} PQArgBlock;
# 47 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/libpq.h"
extern int StreamServerPort(int family, char *hostName,
 unsigned short portNumber, char *unixSocketName, pgsocket ListenSocket[],
     int MaxListen);
extern int StreamConnection(pgsocket server_fd, Port *port);
extern void StreamClose(pgsocket sock);
extern void TouchSocketFile(void);
extern void pq_init(void);
extern void pq_comm_reset(void);
extern int pq_getbytes(char *s, size_t len);
extern int pq_getstring(StringInfo s);
extern int pq_getmessage(StringInfo s, int maxlen);
extern int pq_getbyte(void);
extern int pq_peekbyte(void);
extern int pq_getbyte_if_available(unsigned char *c);
extern int pq_putbytes(const char *s, size_t len);
extern int pq_flush(void);
extern int pq_flush_if_writable(void);
extern bool pq_is_send_pending(void);
extern int pq_putmessage(char msgtype, const char *s, size_t len);
extern void pq_putmessage_noblock(char msgtype, const char *s, size_t len);
extern void pq_startcopyout(void);
extern void pq_endcopyout(bool errorAbort);




extern char *ssl_cert_file;
extern char *ssl_key_file;
extern char *ssl_ca_file;
extern char *ssl_crl_file;

extern int secure_initialize(void);
extern bool secure_loaded_verify_locations(void);
extern void secure_destroy(void);
extern int secure_open_server(Port *port);
extern void secure_close(Port *port);
extern ssize_t secure_read(Port *port, void *ptr, size_t len);
extern ssize_t secure_write(Port *port, void *ptr, size_t len);
# 43 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqformat.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqformat.h"
extern void pq_beginmessage(StringInfo buf, char msgtype);
extern void pq_sendbyte(StringInfo buf, int byt);
extern void pq_sendbytes(StringInfo buf, const char *data, int datalen);
extern void pq_sendcountedtext(StringInfo buf, const char *str, int slen,
       bool countincludesself);
extern void pq_sendtext(StringInfo buf, const char *str, int slen);
extern void pq_sendstring(StringInfo buf, const char *str);
extern void pq_send_ascii_string(StringInfo buf, const char *str);
extern void pq_sendint(StringInfo buf, int i, int b);
extern void pq_sendint64(StringInfo buf, int64 i);
extern void pq_sendfloat4(StringInfo buf, float4 f);
extern void pq_sendfloat8(StringInfo buf, float8 f);
extern void pq_endmessage(StringInfo buf);

extern void pq_begintypsend(StringInfo buf);
extern bytea *pq_endtypsend(StringInfo buf);

extern void pq_puttextmessage(char msgtype, const char *str);
extern void pq_putemptymessage(char msgtype);

extern int pq_getmsgbyte(StringInfo msg);
extern unsigned int pq_getmsgint(StringInfo msg, int b);
extern int64 pq_getmsgint64(StringInfo msg);
extern float4 pq_getmsgfloat4(StringInfo msg);
extern float8 pq_getmsgfloat8(StringInfo msg);
extern const char *pq_getmsgbytes(StringInfo msg, int datalen);
extern void pq_copymsgbytes(StringInfo msg, char *buf, int datalen);
extern char *pq_getmsgtext(StringInfo msg, int rawbytes, int *nbytes);
extern const char *pq_getmsgstring(StringInfo msg);
extern void pq_getmsgend(StringInfo msg);
# 44 "guc.c" 2
# 1 "miscadmin.h" 1
# 26 "miscadmin.h"
# 1 "pgtime.h" 1
# 23 "pgtime.h"
typedef int64 pg_time_t;

struct pg_tm
{
 int tm_sec;
 int tm_min;
 int tm_hour;
 int tm_mday;
 int tm_mon;
 int tm_year;
 int tm_wday;
 int tm_yday;
 int tm_isdst;
 long int tm_gmtoff;
 const char *tm_zone;
};

typedef struct pg_tz pg_tz;
typedef struct pg_tzenum pg_tzenum;






extern struct pg_tm *pg_localtime(const pg_time_t *timep, const pg_tz *tz);
extern struct pg_tm *pg_gmtime(const pg_time_t *timep);
extern int pg_next_dst_boundary(const pg_time_t *timep,
      long int *before_gmtoff,
      int *before_isdst,
      pg_time_t *boundary,
      long int *after_gmtoff,
      int *after_isdst,
      const pg_tz *tz);
extern size_t pg_strftime(char *s, size_t max, const char *format,
   const struct pg_tm * tm);

extern bool pg_get_timezone_offset(const pg_tz *tz, long int *gmtoff);
extern const char *pg_get_timezone_name(pg_tz *tz);
extern bool pg_tz_acceptable(pg_tz *tz);



extern pg_tz *session_timezone;
extern pg_tz *log_timezone;

extern void pg_timezone_initialize(void);
extern pg_tz *pg_tzset(const char *tzname);

extern pg_tzenum *pg_tzenumerate_start(void);
extern pg_tz *pg_tzenumerate_next(pg_tzenum *dir);
extern void pg_tzenumerate_end(pg_tzenum *dir);
# 27 "miscadmin.h" 2
# 74 "miscadmin.h"
extern volatile bool InterruptPending;
extern volatile bool QueryCancelPending;
extern volatile bool ProcDiePending;

extern volatile bool ClientConnectionLost;


extern volatile bool ImmediateInterruptOK;
extern volatile uint32 InterruptHoldoffCount;
extern volatile uint32 CritSectionCount;


extern void ProcessInterrupts(void);
# 131 "miscadmin.h"
extern pid_t PostmasterPid;
extern bool IsPostmasterEnvironment;
extern bool IsUnderPostmaster;
extern bool IsBinaryUpgrade;

extern bool ExitOnAnyError;

extern char *DataDir;

extern int NBuffers;
extern int MaxBackends;
extern int MaxConnections;

extern int MyProcPid;
extern pg_time_t MyStartTime;
extern struct Port *MyProcPort;
extern long MyCancelKey;
extern int MyPMChildSlot;

extern char OutputFileName[];
extern char my_exec_path[];
extern char pkglib_path[];
# 163 "miscadmin.h"
extern Oid MyDatabaseId;

extern Oid MyDatabaseTableSpace;
# 201 "miscadmin.h"
extern int DateStyle;
extern int DateOrder;
# 216 "miscadmin.h"
extern int IntervalStyle;







extern bool HasCTZSet;
extern int CTimeZone;



extern bool enableFsync;
extern bool allowSystemTableMods;
extern int work_mem;
extern int maintenance_work_mem;

extern int VacuumCostPageHit;
extern int VacuumCostPageMiss;
extern int VacuumCostPageDirty;
extern int VacuumCostLimit;
extern int VacuumCostDelay;

extern int VacuumPageHit;
extern int VacuumPageMiss;
extern int VacuumPageDirty;

extern int VacuumCostBalance;
extern bool VacuumCostActive;
# 257 "miscadmin.h"
typedef char *pg_stack_base_t;


extern pg_stack_base_t set_stack_base(void);
extern void restore_stack_base(pg_stack_base_t base);
extern void check_stack_depth(void);


extern void PreventCommandIfReadOnly(const char *cmdname);
extern void PreventCommandDuringRecovery(const char *cmdname);


extern int trace_recovery_messages;
extern int trace_recovery(int trace_level);
# 281 "miscadmin.h"
extern char *DatabasePath;


extern void SetDatabasePath(const char *path);

extern char *GetUserNameFromId(Oid roleid);
extern Oid GetUserId(void);
extern Oid GetOuterUserId(void);
extern Oid GetSessionUserId(void);
extern void GetUserIdAndSecContext(Oid *userid, int *sec_context);
extern void SetUserIdAndSecContext(Oid userid, int sec_context);
extern bool InLocalUserIdChange(void);
extern bool InSecurityRestrictedOperation(void);
extern void GetUserIdAndContext(Oid *userid, bool *sec_def_context);
extern void SetUserIdAndContext(Oid userid, bool sec_def_context);
extern void InitializeSessionUserId(const char *rolename);
extern void InitializeSessionUserIdStandalone(void);
extern void SetSessionAuthorization(Oid userid, bool is_superuser);
extern Oid GetCurrentRoleId(void);
extern void SetCurrentRoleId(Oid roleid, bool is_superuser);

extern void SetDataDir(const char *dir);
extern void ChangeToDataDir(void);
extern char *make_absolute_path(const char *path);


extern bool superuser(void);
extern bool superuser_arg(Oid roleid);
# 335 "miscadmin.h"
typedef enum ProcessingMode
{
 BootstrapProcessing,
 InitProcessing,
 NormalProcessing
} ProcessingMode;

extern ProcessingMode Mode;
# 365 "miscadmin.h"
typedef enum
{
 NotAnAuxProcess = -1,
 CheckerProcess = 0,
 BootstrapProcess,
 StartupProcess,
 BgWriterProcess,
 CheckpointerProcess,
 WalWriterProcess,
 WalReceiverProcess,

 NUM_AUXPROCTYPES
} AuxProcType;

extern AuxProcType MyAuxProcType;
# 395 "miscadmin.h"
extern void pg_split_opts(char **argv, int *argcp, char *optstr);
extern void InitPostgres(const char *in_dbname, Oid dboid, const char *username,
    char *out_dbname);
extern void BaseInit(void);


extern bool IgnoreSystemIndexes;
extern bool process_shared_preload_libraries_in_progress;
extern char *shared_preload_libraries_string;
extern char *local_preload_libraries_string;
# 431 "miscadmin.h"
extern void CreateDataDirLockFile(bool amPostmaster);
extern void CreateSocketLockFile(const char *socketfile, bool amPostmaster);
extern void TouchSocketLockFile(void);
extern void AddToDataDirLockFile(int target_line, const char *str);
extern void ValidatePgVersion(const char *path);
extern void process_shared_preload_libraries(void);
extern void process_local_preload_libraries(void);
extern void pg_bindtextdomain(const char *domain);
extern bool has_rolreplication(Oid roleid);


extern bool BackupInProgress(void);
extern void CancelBackup(void);
# 45 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/optimizer/cost.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/optimizer/cost.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/plannodes.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/optimizer/cost.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h" 2






typedef Bitmapset *Relids;





typedef enum CostSelector
{
 STARTUP_COST, TOTAL_COST
} CostSelector;





typedef struct QualCost
{
 Cost startup;
 Cost per_tuple;
} QualCost;






typedef struct AggClauseCosts
{
 int numAggs;
 int numOrderedAggs;
 QualCost transCost;
 Cost finalCost;
 Size transitionSpace;
} AggClauseCosts;
# 72 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct PlannerGlobal
{
 NodeTag type;

 ParamListInfo boundParams;

 List *paramlist;

 List *subplans;

 List *subroots;

 Bitmapset *rewindPlanIDs;

 List *finalrtable;

 List *finalrowmarks;

 List *resultRelations;

 List *relationOids;

 List *invalItems;

 Index lastPHId;

 Index lastRowMarkId;

 bool transientPlan;


 int nParamExec;
} PlannerGlobal;
# 121 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct PlannerInfo
{
 NodeTag type;

 Query *parse;

 PlannerGlobal *glob;

 Index query_level;

 struct PlannerInfo *parent_root;
# 140 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
 struct RelOptInfo **simple_rel_array;
 int simple_rel_array_size;







 RangeTblEntry **simple_rte_array;






 Relids all_baserels;
# 167 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
 List *join_rel_list;
 struct HTAB *join_rel_hash;
# 177 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
 List **join_rel_level;
 int join_cur_level;

 List *init_plans;

 List *cte_plan_ids;

 List *eq_classes;

 List *canon_pathkeys;

 List *left_join_clauses;



 List *right_join_clauses;



 List *full_join_clauses;


 List *join_info_list;

 List *append_rel_list;

 List *rowMarks;

 List *placeholder_list;

 List *query_pathkeys;


 List *group_pathkeys;
 List *window_pathkeys;
 List *distinct_pathkeys;
 List *sort_pathkeys;

 List *minmax_aggs;

 List *initial_rels;

 MemoryContext planner_cxt;

 double total_table_pages;

 double tuple_fraction;
 double limit_tuples;

 bool hasInheritedTarget;

 bool hasJoinRTEs;
 bool hasHavingQual;
 bool hasPseudoConstantQuals;

 bool hasRecursion;


 int wt_param_id;
 struct Plan *non_recursive_plan;


 Relids curOuterRels;
 List *curOuterParams;


 void *join_search_private;


 List *plan_params;
} PlannerInfo;
# 386 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef enum RelOptKind
{
 RELOPT_BASEREL,
 RELOPT_JOINREL,
 RELOPT_OTHER_MEMBER_REL,
 RELOPT_DEADREL
} RelOptKind;

typedef struct RelOptInfo
{
 NodeTag type;

 RelOptKind reloptkind;


 Relids relids;


 double rows;
 int width;


 List *reltargetlist;
 List *pathlist;
 List *ppilist;
 struct Path *cheapest_startup_path;
 struct Path *cheapest_total_path;
 struct Path *cheapest_unique_path;
 List *cheapest_parameterized_paths;


 Index relid;
 Oid reltablespace;
 RTEKind rtekind;
 AttrNumber min_attr;
 AttrNumber max_attr;
 Relids *attr_needed;
 int32 *attr_widths;
 List *indexlist;
 BlockNumber pages;
 double tuples;
 double allvisfrac;

 struct Plan *subplan;
 PlannerInfo *subroot;

 struct FdwRoutine *fdwroutine;
 void *fdw_private;


 List *baserestrictinfo;

 QualCost baserestrictcost;
 List *joininfo;

 bool has_eclass_joins;
} RelOptInfo;
# 470 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct IndexOptInfo
{
 NodeTag type;

 Oid indexoid;
 Oid reltablespace;
 RelOptInfo *rel;


 BlockNumber pages;
 double tuples;


 int ncolumns;
 int *indexkeys;
 Oid *indexcollations;
 Oid *opfamily;
 Oid *opcintype;
 Oid *sortopfamily;
 bool *reverse_sort;
 bool *nulls_first;
 Oid relam;

 RegProcedure amcostestimate;

 List *indexprs;
 List *indpred;

 List *indextlist;

 bool predOK;
 bool unique;
 bool immediate;
 bool hypothetical;
 bool canreturn;
 bool amcanorderbyop;
 bool amoptionalkey;
 bool amsearcharray;
 bool amsearchnulls;
 bool amhasgettuple;
 bool amhasgetbitmap;
} IndexOptInfo;
# 554 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct EquivalenceClass
{
 NodeTag type;

 List *ec_opfamilies;
 Oid ec_collation;
 List *ec_members;
 List *ec_sources;
 List *ec_derives;
 Relids ec_relids;
 bool ec_has_const;
 bool ec_has_volatile;
 bool ec_below_outer_join;
 bool ec_broken;
 Index ec_sortref;
 struct EquivalenceClass *ec_merged;
} EquivalenceClass;
# 601 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct EquivalenceMember
{
 NodeTag type;

 Expr *em_expr;
 Relids em_relids;
 Relids em_nullable_relids;
 bool em_is_const;
 bool em_is_child;
 Oid em_datatype;
} EquivalenceMember;
# 630 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct PathKey
{
 NodeTag type;

 EquivalenceClass *pk_eclass;
 Oid pk_opfamily;
 int pk_strategy;
 bool pk_nulls_first;
} PathKey;
# 655 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct ParamPathInfo
{
 NodeTag type;

 Relids ppi_req_outer;
 double ppi_rows;
 List *ppi_clauses;
} ParamPathInfo;
# 689 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct Path
{
 NodeTag type;

 NodeTag pathtype;

 RelOptInfo *parent;
 ParamPathInfo *param_info;


 double rows;
 Cost startup_cost;
 Cost total_cost;

 List *pathkeys;

} Path;
# 763 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct IndexPath
{
 Path path;
 IndexOptInfo *indexinfo;
 List *indexclauses;
 List *indexquals;
 List *indexqualcols;
 List *indexorderbys;
 List *indexorderbycols;
 ScanDirection indexscandir;
 Cost indextotalcost;
 Selectivity indexselectivity;
} IndexPath;
# 794 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct BitmapHeapPath
{
 Path path;
 Path *bitmapqual;
} BitmapHeapPath;







typedef struct BitmapAndPath
{
 Path path;
 List *bitmapquals;
 Selectivity bitmapselectivity;
} BitmapAndPath;







typedef struct BitmapOrPath
{
 Path path;
 List *bitmapquals;
 Selectivity bitmapselectivity;
} BitmapOrPath;
# 833 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct TidPath
{
 Path path;
 List *tidquals;
} TidPath;
# 848 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct ForeignPath
{
 Path path;
 List *fdw_private;
} ForeignPath;
# 863 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct AppendPath
{
 Path path;
 List *subpaths;
} AppendPath;
# 881 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct MergeAppendPath
{
 Path path;
 List *subpaths;
 double limit_tuples;
} MergeAppendPath;
# 895 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct ResultPath
{
 Path path;
 List *quals;
} ResultPath;







typedef struct MaterialPath
{
 Path path;
 Path *subpath;
} MaterialPath;
# 926 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef enum
{
 UNIQUE_PATH_NOOP,
 UNIQUE_PATH_HASH,
 UNIQUE_PATH_SORT
} UniquePathMethod;

typedef struct UniquePath
{
 Path path;
 Path *subpath;
 UniquePathMethod umethod;
 List *in_operators;
 List *uniq_exprs;
} UniquePath;





typedef struct JoinPath
{
 Path path;

 JoinType jointype;

 Path *outerjoinpath;
 Path *innerjoinpath;

 List *joinrestrictinfo;






} JoinPath;





typedef JoinPath NestPath;
# 998 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct MergePath
{
 JoinPath jpath;
 List *path_mergeclauses;
 List *outersortkeys;
 List *innersortkeys;
 bool materialize_inner;
} MergePath;
# 1016 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct HashPath
{
 JoinPath jpath;
 List *path_hashclauses;
 int num_batches;
} HashPath;
# 1153 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct RestrictInfo
{
 NodeTag type;

 Expr *clause;

 bool is_pushed_down;

 bool outerjoin_delayed;

 bool can_join;

 bool pseudoconstant;


 Relids clause_relids;


 Relids required_relids;


 Relids outer_relids;


 Relids nullable_relids;


 Relids left_relids;
 Relids right_relids;


 Expr *orclause;


 EquivalenceClass *parent_ec;


 QualCost eval_cost;
 Selectivity norm_selec;


 Selectivity outer_selec;



 List *mergeopfamilies;


 EquivalenceClass *left_ec;
 EquivalenceClass *right_ec;
 EquivalenceMember *left_em;
 EquivalenceMember *right_em;
 List *scansel_cache;


 bool outer_is_left;


 Oid hashjoinoperator;


 Selectivity left_bucketsize;
 Selectivity right_bucketsize;
} RestrictInfo;
# 1225 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct MergeScanSelCache
{

 Oid opfamily;
 Oid collation;
 int strategy;
 bool nulls_first;

 Selectivity leftstartsel;
 Selectivity leftendsel;
 Selectivity rightstartsel;
 Selectivity rightendsel;
} MergeScanSelCache;
# 1253 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct PlaceHolderVar
{
 Expr xpr;
 Expr *phexpr;
 Relids phrels;
 Index phid;
 Index phlevelsup;
} PlaceHolderVar;
# 1318 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct SpecialJoinInfo
{
 NodeTag type;
 Relids min_lefthand;
 Relids min_righthand;
 Relids syn_lefthand;
 Relids syn_righthand;
 JoinType jointype;
 bool lhs_strict;
 bool delay_upper_joins;
 List *join_quals;
} SpecialJoinInfo;
# 1365 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct AppendRelInfo
{
 NodeTag type;







 Index parent_relid;
 Index child_relid;







 Oid parent_reltype;
 Oid child_reltype;
# 1403 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
 List *translated_vars;






 Oid parent_reloid;
} AppendRelInfo;
# 1444 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct PlaceHolderInfo
{
 NodeTag type;

 Index phid;
 PlaceHolderVar *ph_var;
 Relids ph_eval_at;
 Relids ph_needed;
 Relids ph_may_need;
 int32 ph_width;
} PlaceHolderInfo;





typedef struct MinMaxAggInfo
{
 NodeTag type;

 Oid aggfnoid;
 Oid aggsortop;
 Expr *target;
 PlannerInfo *subroot;
 Path *path;
 Cost pathcost;
 Param *param;
} MinMaxAggInfo;
# 1520 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct PlannerParamItem
{
 NodeTag type;

 Node *item;
 int paramId;
} PlannerParamItem;
# 1544 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct SemiAntiJoinFactors
{
 Selectivity outer_match_frac;
 Selectivity match_count;
} SemiAntiJoinFactors;
# 1562 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/relation.h"
typedef struct JoinCostWorkspace
{

 Cost startup_cost;
 Cost total_cost;


 Cost run_cost;


 Cost inner_rescan_run_cost;
 double outer_matched_rows;
 Selectivity inner_scan_frac;


 Cost inner_run_cost;
 double outer_rows;
 double inner_rows;
 double outer_skip_rows;
 double inner_skip_rows;


 int numbuckets;
 int numbatches;
} JoinCostWorkspace;
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/optimizer/cost.h" 2
# 32 "/Users/parrt/tmp/postgresql-9.2.4/src/include/optimizer/cost.h"
typedef enum
{
 CONSTRAINT_EXCLUSION_OFF,
 CONSTRAINT_EXCLUSION_ON,
 CONSTRAINT_EXCLUSION_PARTITION
} ConstraintExclusionType;
# 46 "/Users/parrt/tmp/postgresql-9.2.4/src/include/optimizer/cost.h"
extern double seq_page_cost;
extern double random_page_cost;
extern double cpu_tuple_cost;
extern double cpu_index_tuple_cost;
extern double cpu_operator_cost;
extern int effective_cache_size;
extern Cost disable_cost;
extern bool enable_seqscan;
extern bool enable_indexscan;
extern bool enable_indexonlyscan;
extern bool enable_bitmapscan;
extern bool enable_tidscan;
extern bool enable_sort;
extern bool enable_hashagg;
extern bool enable_nestloop;
extern bool enable_material;
extern bool enable_mergejoin;
extern bool enable_hashjoin;
extern int constraint_exclusion;

extern double clamp_row_est(double nrows);
extern double index_pages_fetched(double tuples_fetched, BlockNumber pages,
     double index_pages, PlannerInfo *root);
extern void cost_seqscan(Path *path, PlannerInfo *root, RelOptInfo *baserel,
    ParamPathInfo *param_info);
extern void cost_index(IndexPath *path, PlannerInfo *root,
     double loop_count);
extern void cost_bitmap_heap_scan(Path *path, PlannerInfo *root, RelOptInfo *baserel,
       ParamPathInfo *param_info,
       Path *bitmapqual, double loop_count);
extern void cost_bitmap_and_node(BitmapAndPath *path, PlannerInfo *root);
extern void cost_bitmap_or_node(BitmapOrPath *path, PlannerInfo *root);
extern void cost_bitmap_tree_node(Path *path, Cost *cost, Selectivity *selec);
extern void cost_tidscan(Path *path, PlannerInfo *root,
    RelOptInfo *baserel, List *tidquals);
extern void cost_subqueryscan(Path *path, PlannerInfo *root,
      RelOptInfo *baserel, ParamPathInfo *param_info);
extern void cost_functionscan(Path *path, PlannerInfo *root,
      RelOptInfo *baserel);
extern void cost_valuesscan(Path *path, PlannerInfo *root,
    RelOptInfo *baserel);
extern void cost_ctescan(Path *path, PlannerInfo *root, RelOptInfo *baserel);
extern void cost_recursive_union(Plan *runion, Plan *nrterm, Plan *rterm);
extern void cost_sort(Path *path, PlannerInfo *root,
    List *pathkeys, Cost input_cost, double tuples, int width,
    Cost comparison_cost, int sort_mem,
    double limit_tuples);
extern void cost_merge_append(Path *path, PlannerInfo *root,
      List *pathkeys, int n_streams,
      Cost input_startup_cost, Cost input_total_cost,
      double tuples);
extern void cost_material(Path *path,
     Cost input_startup_cost, Cost input_total_cost,
     double tuples, int width);
extern void cost_agg(Path *path, PlannerInfo *root,
   AggStrategy aggstrategy, const AggClauseCosts *aggcosts,
   int numGroupCols, double numGroups,
   Cost input_startup_cost, Cost input_total_cost,
   double input_tuples);
extern void cost_windowagg(Path *path, PlannerInfo *root,
      List *windowFuncs, int numPartCols, int numOrderCols,
      Cost input_startup_cost, Cost input_total_cost,
      double input_tuples);
extern void cost_group(Path *path, PlannerInfo *root,
     int numGroupCols, double numGroups,
     Cost input_startup_cost, Cost input_total_cost,
     double input_tuples);
extern void initial_cost_nestloop(PlannerInfo *root,
       JoinCostWorkspace *workspace,
       JoinType jointype,
       Path *outer_path, Path *inner_path,
       SpecialJoinInfo *sjinfo,
       SemiAntiJoinFactors *semifactors);
extern void final_cost_nestloop(PlannerInfo *root, NestPath *path,
     JoinCostWorkspace *workspace,
     SpecialJoinInfo *sjinfo,
     SemiAntiJoinFactors *semifactors);
extern void initial_cost_mergejoin(PlannerInfo *root,
        JoinCostWorkspace *workspace,
        JoinType jointype,
        List *mergeclauses,
        Path *outer_path, Path *inner_path,
        List *outersortkeys, List *innersortkeys,
        SpecialJoinInfo *sjinfo);
extern void final_cost_mergejoin(PlannerInfo *root, MergePath *path,
      JoinCostWorkspace *workspace,
      SpecialJoinInfo *sjinfo);
extern void initial_cost_hashjoin(PlannerInfo *root,
       JoinCostWorkspace *workspace,
       JoinType jointype,
       List *hashclauses,
       Path *outer_path, Path *inner_path,
       SpecialJoinInfo *sjinfo,
       SemiAntiJoinFactors *semifactors);
extern void final_cost_hashjoin(PlannerInfo *root, HashPath *path,
     JoinCostWorkspace *workspace,
     SpecialJoinInfo *sjinfo,
     SemiAntiJoinFactors *semifactors);
extern void cost_subplan(PlannerInfo *root, SubPlan *subplan, Plan *plan);
extern void cost_qual_eval(QualCost *cost, List *quals, PlannerInfo *root);
extern void cost_qual_eval_node(QualCost *cost, Node *qual, PlannerInfo *root);
extern void compute_semi_anti_join_factors(PlannerInfo *root,
          RelOptInfo *outerrel,
          RelOptInfo *innerrel,
          JoinType jointype,
          SpecialJoinInfo *sjinfo,
          List *restrictlist,
          SemiAntiJoinFactors *semifactors);
extern void set_baserel_size_estimates(PlannerInfo *root, RelOptInfo *rel);
extern double get_parameterized_baserel_size(PlannerInfo *root,
          RelOptInfo *rel,
          List *param_clauses);
extern double get_parameterized_joinrel_size(PlannerInfo *root,
          RelOptInfo *rel,
          double outer_rows,
          double inner_rows,
          SpecialJoinInfo *sjinfo,
          List *restrict_clauses);
extern void set_joinrel_size_estimates(PlannerInfo *root, RelOptInfo *rel,
         RelOptInfo *outer_rel,
         RelOptInfo *inner_rel,
         SpecialJoinInfo *sjinfo,
         List *restrictlist);
extern void set_subquery_size_estimates(PlannerInfo *root, RelOptInfo *rel);
extern void set_function_size_estimates(PlannerInfo *root, RelOptInfo *rel);
extern void set_values_size_estimates(PlannerInfo *root, RelOptInfo *rel);
extern void set_cte_size_estimates(PlannerInfo *root, RelOptInfo *rel,
        Plan *cteplan);
extern void set_foreign_size_estimates(PlannerInfo *root, RelOptInfo *rel);





extern Selectivity clauselist_selectivity(PlannerInfo *root,
        List *clauses,
        int varRelid,
        JoinType jointype,
        SpecialJoinInfo *sjinfo);
extern Selectivity clause_selectivity(PlannerInfo *root,
       Node *clause,
       int varRelid,
       JoinType jointype,
       SpecialJoinInfo *sjinfo);
# 46 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/optimizer/geqo.h" 1
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/optimizer/geqo.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/optimizer/geqo_gene.h" 1
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/optimizer/geqo_gene.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h" 1
# 27 "/Users/parrt/tmp/postgresql-9.2.4/src/include/optimizer/geqo_gene.h" 2



typedef int Gene;

typedef struct Chromosome
{
 Gene *string;
 Cost worth;
} Chromosome;

typedef struct Pool
{
 Chromosome *data;
 int size;
 int string_length;
} Pool;
# 27 "/Users/parrt/tmp/postgresql-9.2.4/src/include/optimizer/geqo.h" 2
# 51 "/Users/parrt/tmp/postgresql-9.2.4/src/include/optimizer/geqo.h"
extern int Geqo_effort;





extern int Geqo_pool_size;

extern int Geqo_generations;

extern double Geqo_selection_bias;





extern double Geqo_seed;





typedef struct
{
 List *initial_rels;
 unsigned short random_state[3];
} GeqoPrivateData;



extern RelOptInfo *geqo(PlannerInfo *root,
  int number_of_rels, List *initial_rels);


extern Cost geqo_eval(PlannerInfo *root, Gene *tour, int num_gene);
extern RelOptInfo *gimme_tree(PlannerInfo *root, Gene *tour, int num_gene);
# 47 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/optimizer/paths.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/optimizer/paths.h"
extern bool enable_geqo;
extern int geqo_threshold;


typedef RelOptInfo *(*join_search_hook_type) (PlannerInfo *root,
                int levels_needed,
                List *initial_rels);
extern join_search_hook_type join_search_hook;


extern RelOptInfo *make_one_rel(PlannerInfo *root, List *joinlist);
extern RelOptInfo *standard_join_search(PlannerInfo *root, int levels_needed,
      List *initial_rels);
# 45 "/Users/parrt/tmp/postgresql-9.2.4/src/include/optimizer/paths.h"
extern void create_index_paths(PlannerInfo *root, RelOptInfo *rel);
extern List *generate_bitmap_or_paths(PlannerInfo *root, RelOptInfo *rel,
       List *clauses, List *other_clauses,
       bool restriction_only);
extern bool relation_has_unique_index_for(PlannerInfo *root, RelOptInfo *rel,
         List *restrictlist,
         List *exprlist, List *oprlist);
extern bool eclass_member_matches_indexcol(EquivalenceClass *ec,
          EquivalenceMember *em,
          IndexOptInfo *index, int indexcol);
extern bool match_index_to_operand(Node *operand, int indexcol,
        IndexOptInfo *index);
extern void expand_indexqual_conditions(IndexOptInfo *index,
       List *indexclauses, List *indexclausecols,
       List **indexquals_p, List **indexqualcols_p);
extern void check_partial_indexes(PlannerInfo *root, RelOptInfo *rel);
extern Expr *adjust_rowcompare_for_index(RowCompareExpr *clause,
       IndexOptInfo *index,
       int indexcol,
       List **indexcolnos,
       bool *var_on_left_p);





extern bool create_or_index_quals(PlannerInfo *root, RelOptInfo *rel);





extern void create_tidscan_paths(PlannerInfo *root, RelOptInfo *rel);





extern void add_paths_to_joinrel(PlannerInfo *root, RelOptInfo *joinrel,
      RelOptInfo *outerrel, RelOptInfo *innerrel,
      JoinType jointype, SpecialJoinInfo *sjinfo,
      List *restrictlist);





extern void join_search_one_level(PlannerInfo *root, int level);
extern RelOptInfo *make_join_rel(PlannerInfo *root,
     RelOptInfo *rel1, RelOptInfo *rel2);
extern bool have_join_order_restriction(PlannerInfo *root,
       RelOptInfo *rel1, RelOptInfo *rel2);





extern bool process_equivalence(PlannerInfo *root, RestrictInfo *restrictinfo,
     bool below_outer_join);
extern Expr *canonicalize_ec_expression(Expr *expr,
         Oid req_type, Oid req_collation);
extern void reconsider_outer_join_clauses(PlannerInfo *root);
extern EquivalenceClass *get_eclass_for_sort_expr(PlannerInfo *root,
       Expr *expr,
       List *opfamilies,
       Oid opcintype,
       Oid collation,
       Index sortref,
       Relids rel,
       bool create_it);
extern void generate_base_implied_equalities(PlannerInfo *root);
extern List *generate_join_implied_equalities(PlannerInfo *root,
         Relids join_relids,
         Relids outer_relids,
         RelOptInfo *inner_rel);
extern bool exprs_known_equal(PlannerInfo *root, Node *item1, Node *item2);
extern void add_child_rel_equivalences(PlannerInfo *root,
         AppendRelInfo *appinfo,
         RelOptInfo *parent_rel,
         RelOptInfo *child_rel);
extern void mutate_eclass_expressions(PlannerInfo *root,
        Node *(*mutator) (),
        void *context,
        bool include_child_exprs);
extern List *generate_implied_equalities_for_indexcol(PlannerInfo *root,
           IndexOptInfo *index,
           int indexcol);
extern bool have_relevant_eclass_joinclause(PlannerInfo *root,
        RelOptInfo *rel1, RelOptInfo *rel2);
extern bool has_relevant_eclass_joinclause(PlannerInfo *root,
          RelOptInfo *rel1);
extern bool eclass_useful_for_merging(EquivalenceClass *eclass,
        RelOptInfo *rel);
extern bool is_redundant_derived_clause(RestrictInfo *rinfo, List *clauselist);





typedef enum
{
 PATHKEYS_EQUAL,
 PATHKEYS_BETTER1,
 PATHKEYS_BETTER2,
 PATHKEYS_DIFFERENT
} PathKeysComparison;

extern List *canonicalize_pathkeys(PlannerInfo *root, List *pathkeys);
extern PathKeysComparison compare_pathkeys(List *keys1, List *keys2);
extern bool pathkeys_contained_in(List *keys1, List *keys2);
extern Path *get_cheapest_path_for_pathkeys(List *paths, List *pathkeys,
          Relids required_outer,
          CostSelector cost_criterion);
extern Path *get_cheapest_fractional_path_for_pathkeys(List *paths,
            List *pathkeys,
            Relids required_outer,
            double fraction);
extern List *build_index_pathkeys(PlannerInfo *root, IndexOptInfo *index,
      ScanDirection scandir);
extern List *convert_subquery_pathkeys(PlannerInfo *root, RelOptInfo *rel,
        List *subquery_pathkeys);
extern List *build_join_pathkeys(PlannerInfo *root,
     RelOptInfo *joinrel,
     JoinType jointype,
     List *outer_pathkeys);
extern List *make_pathkeys_for_sortclauses(PlannerInfo *root,
         List *sortclauses,
         List *tlist,
         bool canonicalize);
extern void initialize_mergeclause_eclasses(PlannerInfo *root,
        RestrictInfo *restrictinfo);
extern void update_mergeclause_eclasses(PlannerInfo *root,
       RestrictInfo *restrictinfo);
extern List *find_mergeclauses_for_pathkeys(PlannerInfo *root,
          List *pathkeys,
          bool outer_keys,
          List *restrictinfos);
extern List *select_outer_pathkeys_for_merge(PlannerInfo *root,
        List *mergeclauses,
        RelOptInfo *joinrel);
extern List *make_inner_pathkeys_for_merge(PlannerInfo *root,
         List *mergeclauses,
         List *outer_pathkeys);
extern List *truncate_useless_pathkeys(PlannerInfo *root,
        RelOptInfo *rel,
        List *pathkeys);
extern bool has_useful_pathkeys(PlannerInfo *root, RelOptInfo *rel);
# 48 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/optimizer/planmain.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/optimizer/planmain.h"
extern double cursor_tuple_fraction;




extern void query_planner(PlannerInfo *root, List *tlist,
     double tuple_fraction, double limit_tuples,
     Path **cheapest_path, Path **sorted_path,
     double *num_groups);




extern void preprocess_minmax_aggregates(PlannerInfo *root, List *tlist);
extern Plan *optimize_minmax_aggregates(PlannerInfo *root, List *tlist,
         const AggClauseCosts *aggcosts, Path *best_path);




extern Plan *create_plan(PlannerInfo *root, Path *best_path);
extern SubqueryScan *make_subqueryscan(List *qptlist, List *qpqual,
      Index scanrelid, Plan *subplan);
extern ForeignScan *make_foreignscan(List *qptlist, List *qpqual,
     Index scanrelid, List *fdw_exprs, List *fdw_private);
extern Append *make_append(List *appendplans, List *tlist);
extern RecursiveUnion *make_recursive_union(List *tlist,
      Plan *lefttree, Plan *righttree, int wtParam,
      List *distinctList, long numGroups);
extern Sort *make_sort_from_pathkeys(PlannerInfo *root, Plan *lefttree,
      List *pathkeys, double limit_tuples);
extern Sort *make_sort_from_sortclauses(PlannerInfo *root, List *sortcls,
         Plan *lefttree);
extern Sort *make_sort_from_groupcols(PlannerInfo *root, List *groupcls,
       AttrNumber *grpColIdx, Plan *lefttree);
extern Agg *make_agg(PlannerInfo *root, List *tlist, List *qual,
   AggStrategy aggstrategy, const AggClauseCosts *aggcosts,
   int numGroupCols, AttrNumber *grpColIdx, Oid *grpOperators,
   long numGroups,
   Plan *lefttree);
extern WindowAgg *make_windowagg(PlannerInfo *root, List *tlist,
      List *windowFuncs, Index winref,
      int partNumCols, AttrNumber *partColIdx, Oid *partOperators,
      int ordNumCols, AttrNumber *ordColIdx, Oid *ordOperators,
      int frameOptions, Node *startOffset, Node *endOffset,
      Plan *lefttree);
extern Group *make_group(PlannerInfo *root, List *tlist, List *qual,
     int numGroupCols, AttrNumber *grpColIdx, Oid *grpOperators,
     double numGroups,
     Plan *lefttree);
extern Plan *materialize_finished_plan(Plan *subplan);
extern Unique *make_unique(Plan *lefttree, List *distinctList);
extern LockRows *make_lockrows(Plan *lefttree, List *rowMarks, int epqParam);
extern Limit *make_limit(Plan *lefttree, Node *limitOffset, Node *limitCount,
     int64 offset_est, int64 count_est);
extern SetOp *make_setop(SetOpCmd cmd, SetOpStrategy strategy, Plan *lefttree,
     List *distinctList, AttrNumber flagColIdx, int firstFlag,
     long numGroups, double outputRows);
extern Result *make_result(PlannerInfo *root, List *tlist,
   Node *resconstantqual, Plan *subplan);
extern ModifyTable *make_modifytable(CmdType operation, bool canSetTag,
     List *resultRelations, List *subplans, List *returningLists,
     List *rowMarks, int epqParam);
extern bool is_projection_capable_plan(Plan *plan);




extern int from_collapse_limit;
extern int join_collapse_limit;

extern void add_base_rels_to_query(PlannerInfo *root, Node *jtnode);
extern void build_base_rel_tlists(PlannerInfo *root, List *final_tlist);
extern void add_vars_to_targetlist(PlannerInfo *root, List *vars,
        Relids where_needed, bool create_new_ph);
extern List *deconstruct_jointree(PlannerInfo *root);
extern void distribute_restrictinfo_to_rels(PlannerInfo *root,
        RestrictInfo *restrictinfo);
extern void process_implied_equality(PlannerInfo *root,
       Oid opno,
       Oid collation,
       Expr *item1,
       Expr *item2,
       Relids qualscope,
       Relids nullable_relids,
       bool below_outer_join,
       bool both_const);
extern RestrictInfo *build_implied_join_equality(Oid opno,
       Oid collation,
       Expr *item1,
       Expr *item2,
       Relids qualscope,
       Relids nullable_relids);




extern List *remove_useless_joins(PlannerInfo *root, List *joinlist);




extern Plan *set_plan_references(PlannerInfo *root, Plan *plan);
extern void fix_opfuncids(Node *node);
extern void set_opfuncid(OpExpr *opexpr);
extern void set_sa_opfuncid(ScalarArrayOpExpr *opexpr);
extern void record_plan_function_dependency(PlannerInfo *root, Oid funcid);
extern void extract_query_dependencies(Node *query,
         List **relationOids,
         List **invalItems);
# 49 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_expr.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_expr.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_node.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_node.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_node.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_node.h" 2





typedef struct ParseState ParseState;

typedef Node *(*PreParseColumnRefHook) (ParseState *pstate, ColumnRef *cref);
typedef Node *(*PostParseColumnRefHook) (ParseState *pstate, ColumnRef *cref, Node *var);
typedef Node *(*ParseParamRefHook) (ParseState *pstate, ParamRef *pref);
typedef Node *(*CoerceParamHook) (ParseState *pstate, Param *param,
            Oid targetTypeId, int32 targetTypeMod,
             int location);
# 86 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_node.h"
struct ParseState
{
 struct ParseState *parentParseState;
 const char *p_sourcetext;
 List *p_rtable;
 List *p_joinexprs;
 List *p_joinlist;

 List *p_relnamespace;
 List *p_varnamespace;
 List *p_ctenamespace;
 List *p_future_ctes;
 CommonTableExpr *p_parent_cte;
 List *p_windowdefs;
 int p_next_resno;
 List *p_locking_clause;
 Node *p_value_substitute;
 bool p_hasAggs;
 bool p_hasWindowFuncs;
 bool p_hasSubLinks;
 bool p_hasModifyingCTE;
 bool p_is_insert;
 bool p_is_update;
 bool p_locked_from_parent;
 Relation p_target_relation;
 RangeTblEntry *p_target_rangetblentry;





 PreParseColumnRefHook p_pre_columnref_hook;
 PostParseColumnRefHook p_post_columnref_hook;
 ParseParamRefHook p_paramref_hook;
 CoerceParamHook p_coerce_param_hook;
 void *p_ref_hook_state;
};


typedef struct ParseCallbackState
{
 ParseState *pstate;
 int location;
 ErrorContextCallback errcontext;
} ParseCallbackState;


extern ParseState *make_parsestate(ParseState *parentParseState);
extern void free_parsestate(ParseState *pstate);
extern int parser_errposition(ParseState *pstate, int location);

extern void setup_parser_errposition_callback(ParseCallbackState *pcbstate,
          ParseState *pstate, int location);
extern void cancel_parser_errposition_callback(ParseCallbackState *pcbstate);

extern Var *make_var(ParseState *pstate, RangeTblEntry *rte, int attrno,
   int location);
extern Oid transformArrayType(Oid *arrayType, int32 *arrayTypmod);
extern ArrayRef *transformArraySubscripts(ParseState *pstate,
       Node *arrayBase,
       Oid arrayType,
       Oid elementType,
       int32 arrayTypMod,
       List *indirection,
       Node *assignFrom);
extern Const *make_const(ParseState *pstate, Value *value, int location);
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_expr.h" 2


extern bool Transform_null_equals;

extern Node *transformExpr(ParseState *pstate, Node *expr);
# 50 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_type.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_type.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/htup.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parse_type.h" 2



typedef HeapTuple Type;

extern Type LookupTypeName(ParseState *pstate, const TypeName *typeName,
      int32 *typmod_p);
extern Type typenameType(ParseState *pstate, const TypeName *typeName,
    int32 *typmod_p);
extern Oid typenameTypeId(ParseState *pstate, const TypeName *typeName);
extern void typenameTypeIdAndMod(ParseState *pstate, const TypeName *typeName,
      Oid *typeid_p, int32 *typmod_p);

extern char *TypeNameToString(const TypeName *typeName);
extern char *TypeNameListToString(List *typenames);

extern Oid LookupCollation(ParseState *pstate, List *collnames, int location);
extern Oid GetColumnDefCollation(ParseState *pstate, ColumnDef *coldef, Oid typeOid);

extern Type typeidType(Oid id);

extern Oid typeTypeId(Type tp);
extern int16 typeLen(Type t);
extern bool typeByVal(Type t);
extern char *typeTypeName(Type t);
extern Oid typeTypeRelid(Type typ);
extern Oid typeTypeCollation(Type typ);
extern Datum stringTypeDatum(Type tp, char *string, int32 atttypmod);

extern Oid typeidTypeRelid(Oid type_id);

extern void parseTypeString(const char *str, Oid *typeid_p, int32 *typmod_p);
# 51 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parser.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/parser.h"
typedef enum
{
 BACKSLASH_QUOTE_OFF,
 BACKSLASH_QUOTE_ON,
 BACKSLASH_QUOTE_SAFE_ENCODING
} BackslashQuoteType;


extern int backslash_quote;
extern bool escape_string_warning;
extern bool standard_conforming_strings;



extern List *raw_parser(const char *str);


extern List *SystemFuncName(char *name);
extern TypeName *SystemTypeName(char *name);
# 52 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/scansup.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/scansup.h"
extern char *scanstr(const char *s);

extern char *downcase_truncate_identifier(const char *ident, int len,
        bool warn);

extern void truncate_identifier(char *ident, int len, bool warn);

extern bool scanner_isspace(char ch);
# 53 "guc.c" 2
# 1 "pgstat.h" 1
# 14 "pgstat.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h" 1
# 15 "pgstat.h" 2

# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/libpq/pqcomm.h" 1
# 17 "pgstat.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/portability/instr_time.h" 1
# 18 "pgstat.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/hsearch.h" 1
# 19 "pgstat.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h" 1
# 20 "pgstat.h" 2



typedef enum TrackFunctionsLevel
{
 TRACK_FUNC_OFF,
 TRACK_FUNC_PL,
 TRACK_FUNC_ALL
} TrackFunctionsLevel;





typedef enum StatMsgType
{
 PGSTAT_MTYPE_DUMMY,
 PGSTAT_MTYPE_INQUIRY,
 PGSTAT_MTYPE_TABSTAT,
 PGSTAT_MTYPE_TABPURGE,
 PGSTAT_MTYPE_DROPDB,
 PGSTAT_MTYPE_RESETCOUNTER,
 PGSTAT_MTYPE_RESETSHAREDCOUNTER,
 PGSTAT_MTYPE_RESETSINGLECOUNTER,
 PGSTAT_MTYPE_AUTOVAC_START,
 PGSTAT_MTYPE_VACUUM,
 PGSTAT_MTYPE_ANALYZE,
 PGSTAT_MTYPE_BGWRITER,
 PGSTAT_MTYPE_FUNCSTAT,
 PGSTAT_MTYPE_FUNCPURGE,
 PGSTAT_MTYPE_RECOVERYCONFLICT,
 PGSTAT_MTYPE_TEMPFILE,
 PGSTAT_MTYPE_DEADLOCK
} StatMsgType;





typedef int64 PgStat_Counter;
# 82 "pgstat.h"
typedef struct PgStat_TableCounts
{
 PgStat_Counter t_numscans;

 PgStat_Counter t_tuples_returned;
 PgStat_Counter t_tuples_fetched;

 PgStat_Counter t_tuples_inserted;
 PgStat_Counter t_tuples_updated;
 PgStat_Counter t_tuples_deleted;
 PgStat_Counter t_tuples_hot_updated;

 PgStat_Counter t_delta_live_tuples;
 PgStat_Counter t_delta_dead_tuples;
 PgStat_Counter t_changed_tuples;

 PgStat_Counter t_blocks_fetched;
 PgStat_Counter t_blocks_hit;
} PgStat_TableCounts;


typedef enum PgStat_Shared_Reset_Target
{
 RESET_BGWRITER
} PgStat_Shared_Reset_Target;


typedef enum PgStat_Single_Reset_Type
{
 RESET_TABLE,
 RESET_FUNCTION
} PgStat_Single_Reset_Type;
# 136 "pgstat.h"
typedef struct PgStat_TableStatus
{
 Oid t_id;
 bool t_shared;
 struct PgStat_TableXactStatus *trans;
 PgStat_TableCounts t_counts;
} PgStat_TableStatus;





typedef struct PgStat_TableXactStatus
{
 PgStat_Counter tuples_inserted;
 PgStat_Counter tuples_updated;
 PgStat_Counter tuples_deleted;
 int nest_level;

 struct PgStat_TableXactStatus *upper;
 PgStat_TableStatus *parent;

 struct PgStat_TableXactStatus *next;
} PgStat_TableXactStatus;
# 172 "pgstat.h"
typedef struct PgStat_MsgHdr
{
 StatMsgType m_type;
 int m_size;
} PgStat_MsgHdr;
# 191 "pgstat.h"
typedef struct PgStat_MsgDummy
{
 PgStat_MsgHdr m_hdr;
} PgStat_MsgDummy;
# 203 "pgstat.h"
typedef struct PgStat_MsgInquiry
{
 PgStat_MsgHdr m_hdr;
 TimestampTz inquiry_time;
} PgStat_MsgInquiry;






typedef struct PgStat_TableEntry
{
 Oid t_id;
 PgStat_TableCounts t_counts;
} PgStat_TableEntry;
# 229 "pgstat.h"
typedef struct PgStat_MsgTabstat
{
 PgStat_MsgHdr m_hdr;
 Oid m_databaseid;
 int m_nentries;
 int m_xact_commit;
 int m_xact_rollback;
 PgStat_Counter m_block_read_time;
 PgStat_Counter m_block_write_time;
 PgStat_TableEntry m_entry[(((1000 - sizeof(PgStat_MsgHdr)) - sizeof(Oid) - 3 * sizeof(int)) / sizeof(PgStat_TableEntry))];
} PgStat_MsgTabstat;
# 251 "pgstat.h"
typedef struct PgStat_MsgTabpurge
{
 PgStat_MsgHdr m_hdr;
 Oid m_databaseid;
 int m_nentries;
 Oid m_tableid[(((1000 - sizeof(PgStat_MsgHdr)) - sizeof(Oid) - sizeof(int)) / sizeof(Oid))];
} PgStat_MsgTabpurge;







typedef struct PgStat_MsgDropdb
{
 PgStat_MsgHdr m_hdr;
 Oid m_databaseid;
} PgStat_MsgDropdb;







typedef struct PgStat_MsgResetcounter
{
 PgStat_MsgHdr m_hdr;
 Oid m_databaseid;
} PgStat_MsgResetcounter;






typedef struct PgStat_MsgResetsharedcounter
{
 PgStat_MsgHdr m_hdr;
 PgStat_Shared_Reset_Target m_resettarget;
} PgStat_MsgResetsharedcounter;






typedef struct PgStat_MsgResetsinglecounter
{
 PgStat_MsgHdr m_hdr;
 Oid m_databaseid;
 PgStat_Single_Reset_Type m_resettype;
 Oid m_objectid;
} PgStat_MsgResetsinglecounter;






typedef struct PgStat_MsgAutovacStart
{
 PgStat_MsgHdr m_hdr;
 Oid m_databaseid;
 TimestampTz m_start_time;
} PgStat_MsgAutovacStart;







typedef struct PgStat_MsgVacuum
{
 PgStat_MsgHdr m_hdr;
 Oid m_databaseid;
 Oid m_tableoid;
 bool m_autovacuum;
 TimestampTz m_vacuumtime;
 PgStat_Counter m_tuples;
} PgStat_MsgVacuum;







typedef struct PgStat_MsgAnalyze
{
 PgStat_MsgHdr m_hdr;
 Oid m_databaseid;
 Oid m_tableoid;
 bool m_autovacuum;
 TimestampTz m_analyzetime;
 PgStat_Counter m_live_tuples;
 PgStat_Counter m_dead_tuples;
} PgStat_MsgAnalyze;






typedef struct PgStat_MsgBgWriter
{
 PgStat_MsgHdr m_hdr;

 PgStat_Counter m_timed_checkpoints;
 PgStat_Counter m_requested_checkpoints;
 PgStat_Counter m_buf_written_checkpoints;
 PgStat_Counter m_buf_written_clean;
 PgStat_Counter m_maxwritten_clean;
 PgStat_Counter m_buf_written_backend;
 PgStat_Counter m_buf_fsync_backend;
 PgStat_Counter m_buf_alloc;
 PgStat_Counter m_checkpoint_write_time;
 PgStat_Counter m_checkpoint_sync_time;
} PgStat_MsgBgWriter;





typedef struct PgStat_MsgRecoveryConflict
{
 PgStat_MsgHdr m_hdr;

 Oid m_databaseid;
 int m_reason;
} PgStat_MsgRecoveryConflict;





typedef struct PgStat_MsgTempFile
{
 PgStat_MsgHdr m_hdr;

 Oid m_databaseid;
 size_t m_filesize;
} PgStat_MsgTempFile;
# 407 "pgstat.h"
typedef struct PgStat_FunctionCounts
{
 PgStat_Counter f_numcalls;
 instr_time f_total_time;
 instr_time f_self_time;
} PgStat_FunctionCounts;





typedef struct PgStat_BackendFunctionEntry
{
 Oid f_id;
 PgStat_FunctionCounts f_counts;
} PgStat_BackendFunctionEntry;





typedef struct PgStat_FunctionEntry
{
 Oid f_id;
 PgStat_Counter f_numcalls;
 PgStat_Counter f_total_time;
 PgStat_Counter f_self_time;
} PgStat_FunctionEntry;
# 445 "pgstat.h"
typedef struct PgStat_MsgFuncstat
{
 PgStat_MsgHdr m_hdr;
 Oid m_databaseid;
 int m_nentries;
 PgStat_FunctionEntry m_entry[(((1000 - sizeof(PgStat_MsgHdr)) - sizeof(Oid) - sizeof(int)) / sizeof(PgStat_FunctionEntry))];
} PgStat_MsgFuncstat;
# 462 "pgstat.h"
typedef struct PgStat_MsgFuncpurge
{
 PgStat_MsgHdr m_hdr;
 Oid m_databaseid;
 int m_nentries;
 Oid m_functionid[(((1000 - sizeof(PgStat_MsgHdr)) - sizeof(Oid) - sizeof(int)) / sizeof(Oid))];
} PgStat_MsgFuncpurge;






typedef struct PgStat_MsgDeadlock
{
 PgStat_MsgHdr m_hdr;
 Oid m_databaseid;
} PgStat_MsgDeadlock;






typedef union PgStat_Msg
{
 PgStat_MsgHdr msg_hdr;
 PgStat_MsgDummy msg_dummy;
 PgStat_MsgInquiry msg_inquiry;
 PgStat_MsgTabstat msg_tabstat;
 PgStat_MsgTabpurge msg_tabpurge;
 PgStat_MsgDropdb msg_dropdb;
 PgStat_MsgResetcounter msg_resetcounter;
 PgStat_MsgResetsharedcounter msg_resetsharedcounter;
 PgStat_MsgResetsinglecounter msg_resetsinglecounter;
 PgStat_MsgAutovacStart msg_autovacuum;
 PgStat_MsgVacuum msg_vacuum;
 PgStat_MsgAnalyze msg_analyze;
 PgStat_MsgBgWriter msg_bgwriter;
 PgStat_MsgFuncstat msg_funcstat;
 PgStat_MsgFuncpurge msg_funcpurge;
 PgStat_MsgRecoveryConflict msg_recoveryconflict;
 PgStat_MsgDeadlock msg_deadlock;
} PgStat_Msg;
# 522 "pgstat.h"
typedef struct PgStat_StatDBEntry
{
 Oid databaseid;
 PgStat_Counter n_xact_commit;
 PgStat_Counter n_xact_rollback;
 PgStat_Counter n_blocks_fetched;
 PgStat_Counter n_blocks_hit;
 PgStat_Counter n_tuples_returned;
 PgStat_Counter n_tuples_fetched;
 PgStat_Counter n_tuples_inserted;
 PgStat_Counter n_tuples_updated;
 PgStat_Counter n_tuples_deleted;
 TimestampTz last_autovac_time;
 PgStat_Counter n_conflict_tablespace;
 PgStat_Counter n_conflict_lock;
 PgStat_Counter n_conflict_snapshot;
 PgStat_Counter n_conflict_bufferpin;
 PgStat_Counter n_conflict_startup_deadlock;
 PgStat_Counter n_temp_files;
 PgStat_Counter n_temp_bytes;
 PgStat_Counter n_deadlocks;
 PgStat_Counter n_block_read_time;
 PgStat_Counter n_block_write_time;

 TimestampTz stat_reset_timestamp;





 HTAB *tables;
 HTAB *functions;
} PgStat_StatDBEntry;






typedef struct PgStat_StatTabEntry
{
 Oid tableid;

 PgStat_Counter numscans;

 PgStat_Counter tuples_returned;
 PgStat_Counter tuples_fetched;

 PgStat_Counter tuples_inserted;
 PgStat_Counter tuples_updated;
 PgStat_Counter tuples_deleted;
 PgStat_Counter tuples_hot_updated;

 PgStat_Counter n_live_tuples;
 PgStat_Counter n_dead_tuples;
 PgStat_Counter changes_since_analyze;

 PgStat_Counter blocks_fetched;
 PgStat_Counter blocks_hit;

 TimestampTz vacuum_timestamp;
 PgStat_Counter vacuum_count;
 TimestampTz autovac_vacuum_timestamp;
 PgStat_Counter autovac_vacuum_count;
 TimestampTz analyze_timestamp;
 PgStat_Counter analyze_count;
 TimestampTz autovac_analyze_timestamp;
 PgStat_Counter autovac_analyze_count;
} PgStat_StatTabEntry;






typedef struct PgStat_StatFuncEntry
{
 Oid functionid;

 PgStat_Counter f_numcalls;

 PgStat_Counter f_total_time;
 PgStat_Counter f_self_time;
} PgStat_StatFuncEntry;





typedef struct PgStat_GlobalStats
{
 TimestampTz stats_timestamp;
 PgStat_Counter timed_checkpoints;
 PgStat_Counter requested_checkpoints;
 PgStat_Counter checkpoint_write_time;
 PgStat_Counter checkpoint_sync_time;
 PgStat_Counter buf_written_checkpoints;
 PgStat_Counter buf_written_clean;
 PgStat_Counter maxwritten_clean;
 PgStat_Counter buf_written_backend;
 PgStat_Counter buf_fsync_backend;
 PgStat_Counter buf_alloc;
 TimestampTz stat_reset_timestamp;
} PgStat_GlobalStats;






typedef enum BackendState
{
 STATE_UNDEFINED,
 STATE_IDLE,
 STATE_RUNNING,
 STATE_IDLEINTRANSACTION,
 STATE_FASTPATH,
 STATE_IDLEINTRANSACTION_ABORTED,
 STATE_DISABLED,
} BackendState;
# 658 "pgstat.h"
typedef struct PgBackendStatus
{
# 669 "pgstat.h"
 int st_changecount;


 int st_procpid;


 TimestampTz st_proc_start_timestamp;
 TimestampTz st_xact_start_timestamp;
 TimestampTz st_activity_start_timestamp;
 TimestampTz st_state_start_timestamp;


 Oid st_databaseid;
 Oid st_userid;
 SockAddr st_clientaddr;
 char *st_clienthostname;


 bool st_waiting;


 BackendState st_state;


 char *st_appname;


 char *st_activity;
} PgBackendStatus;




typedef struct PgStat_FunctionCallUsage
{


 PgStat_FunctionCounts *fs;

 instr_time save_f_total_time;

 instr_time save_total;

 instr_time f_start;
} PgStat_FunctionCallUsage;






extern bool pgstat_track_activities;
extern bool pgstat_track_counts;
extern int pgstat_track_functions;
extern int pgstat_track_activity_query_size;
extern char *pgstat_stat_tmpname;
extern char *pgstat_stat_filename;




extern PgStat_MsgBgWriter BgWriterStats;




extern PgStat_Counter pgStatBlockReadTime;
extern PgStat_Counter pgStatBlockWriteTime;





extern Size BackendStatusShmemSize(void);
extern void CreateSharedBackendStatus(void);

extern void pgstat_init(void);
extern int pgstat_start(void);
extern void pgstat_reset_all(void);
extern void allow_immediate_pgstat_restart(void);
# 759 "pgstat.h"
extern void pgstat_ping(void);

extern void pgstat_report_stat(bool force);
extern void pgstat_vacuum_stat(void);
extern void pgstat_drop_database(Oid databaseid);

extern void pgstat_clear_snapshot(void);
extern void pgstat_reset_counters(void);
extern void pgstat_reset_shared_counters(const char *);
extern void pgstat_reset_single_counter(Oid objectid, PgStat_Single_Reset_Type type);

extern void pgstat_report_autovac(Oid dboid);
extern void pgstat_report_vacuum(Oid tableoid, bool shared,
      PgStat_Counter tuples);
extern void pgstat_report_analyze(Relation rel,
       PgStat_Counter livetuples, PgStat_Counter deadtuples);

extern void pgstat_report_recovery_conflict(int reason);
extern void pgstat_report_deadlock(void);

extern void pgstat_initialize(void);
extern void pgstat_bestart(void);

extern void pgstat_report_activity(BackendState state, const char *cmd_str);
extern void pgstat_report_tempfile(size_t filesize);
extern void pgstat_report_appname(const char *appname);
extern void pgstat_report_xact_timestamp(TimestampTz tstamp);
extern void pgstat_report_waiting(bool waiting);
extern const char *pgstat_get_backend_current_activity(int pid, bool checkUser);
extern const char *pgstat_get_crashed_backend_activity(int pid, char *buffer,
         int buflen);

extern PgStat_TableStatus *find_tabstat_entry(Oid rel_id);
extern PgStat_BackendFunctionEntry *find_funcstat_entry(Oid func_id);

extern void pgstat_initstats(Relation rel);
# 838 "pgstat.h"
extern void pgstat_count_heap_insert(Relation rel, int n);
extern void pgstat_count_heap_update(Relation rel, bool hot);
extern void pgstat_count_heap_delete(Relation rel);
extern void pgstat_update_heap_dead_tuples(Relation rel, int delta);

extern void pgstat_init_function_usage(FunctionCallInfoData *fcinfo,
         PgStat_FunctionCallUsage *fcu);
extern void pgstat_end_function_usage(PgStat_FunctionCallUsage *fcu,
        bool finalize);

extern void AtEOXact_PgStat(bool isCommit);
extern void AtEOSubXact_PgStat(bool isCommit, int nestDepth);

extern void AtPrepare_PgStat(void);
extern void PostPrepare_PgStat(void);

extern void pgstat_twophase_postcommit(TransactionId xid, uint16 info,
         void *recdata, uint32 len);
extern void pgstat_twophase_postabort(TransactionId xid, uint16 info,
        void *recdata, uint32 len);

extern void pgstat_send_bgwriter(void);






extern PgStat_StatDBEntry *pgstat_fetch_stat_dbentry(Oid dbid);
extern PgStat_StatTabEntry *pgstat_fetch_stat_tabentry(Oid relid);
extern PgBackendStatus *pgstat_fetch_stat_beentry(int beid);
extern PgStat_StatFuncEntry *pgstat_fetch_stat_funcentry(Oid funcid);
extern int pgstat_fetch_stat_numbackends(void);
extern PgStat_GlobalStats *pgstat_fetch_global(void);
# 54 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/autovacuum.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/autovacuum.h"
extern bool autovacuum_start_daemon;
extern int autovacuum_max_workers;
extern int autovacuum_naptime;
extern int autovacuum_vac_thresh;
extern double autovacuum_vac_scale;
extern int autovacuum_anl_thresh;
extern double autovacuum_anl_scale;
extern int autovacuum_freeze_max_age;
extern int autovacuum_vac_cost_delay;
extern int autovacuum_vac_cost_limit;


extern int AutovacuumLauncherPid;

extern int Log_autovacuum_min_duration;


extern bool AutoVacuumingActive(void);
extern bool IsAutoVacuumLauncherProcess(void);
extern bool IsAutoVacuumWorkerProcess(void);





extern void autovac_init(void);
extern int StartAutoVacLauncher(void);
extern int StartAutoVacWorker(void);


extern void AutoVacWorkerFailed(void);


extern void AutoVacuumUpdateDelay(void);
# 62 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/autovacuum.h"
extern Size AutoVacuumShmemSize(void);
extern void AutoVacuumShmemInit(void);
# 55 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/bgwriter.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/bgwriter.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/block.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/bgwriter.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/bgwriter.h" 2



extern int BgWriterDelay;
extern int CheckPointTimeout;
extern int CheckPointWarning;
extern double CheckPointCompletionTarget;

extern void BackgroundWriterMain(void);
extern void CheckpointerMain(void);

extern void RequestCheckpoint(int flags);
extern void CheckpointWriteDelay(int flags, double progress);

extern bool ForwardFsyncRequest(RelFileNode rnode, ForkNumber forknum,
     BlockNumber segno);
extern void AbsorbFsyncRequests(void);

extern Size CheckpointerShmemSize(void);
extern void CheckpointerShmemInit(void);

extern bool FirstCallSinceLastCheckpoint(void);
# 56 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/postmaster.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/postmaster.h"
extern bool EnableSSL;
extern int ReservedBackends;
extern int PostPortNumber;
extern int Unix_socket_permissions;
extern char *Unix_socket_group;
extern char *UnixSocketDir;
extern char *ListenAddresses;
extern bool ClientAuthInProgress;
extern int PreAuthDelay;
extern int AuthenticationTimeout;
extern bool Log_connections;
extern bool log_hostname;
extern bool enable_bonjour;
extern char *bonjour_name;
extern bool restart_after_crash;




extern int postmaster_alive_fds[2];
# 47 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/postmaster.h"
extern const char *progname;

extern int PostmasterMain(int argc, char *argv[]);
extern void ClosePostmasterPorts(bool am_syslogger);

extern int MaxLivePostmasterChildren(void);
# 57 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/syslogger.h" 1
# 15 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/syslogger.h"
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 1 3 4






# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/syslimits.h" 1 3 4
# 8 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 2 3 4
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/syslogger.h" 2
# 44 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/syslogger.h"
typedef struct
{
 char nuls[2];
 uint16 len;
 int32 pid;
 char is_last;

 char data[1];
} PipeProtoHeader;

typedef union
{
 PipeProtoHeader proto;
 char filler[((int) 512)];
} PipeProtoChunk;






extern bool Logging_collector;
extern int Log_RotationAge;
extern int Log_RotationSize;
extern char *Log_directory;
extern char *Log_filename;
extern bool Log_truncate_on_rotation;
extern int Log_file_mode;

extern bool am_syslogger;


extern int syslogPipe[2];





extern int SysLogger_Start(void);

extern void write_syslogger_file(const char *buffer, int count, int dest);
# 58 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/walwriter.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/postmaster/walwriter.h"
extern int WalWriterDelay;

extern void WalWriterMain(void);
# 59 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/replication/syncrep.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/replication/syncrep.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlogdefs.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/replication/syncrep.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/replication/syncrep.h" 2
# 35 "/Users/parrt/tmp/postgresql-9.2.4/src/include/replication/syncrep.h"
extern char *SyncRepStandbyNames;


extern void SyncRepWaitForLSN(XLogRecPtr XactCommitLSN);


extern void SyncRepCleanupAtProcExit(void);


extern void SyncRepInitConfig(void);
extern void SyncRepReleaseWaiters(void);


extern void SyncRepUpdateSyncStandbysDefined(void);


extern int SyncRepWakeQueue(bool all, int mode);

extern bool check_synchronous_standby_names(char **newval, void **extra, GucSource source);
extern void assign_synchronous_commit(int newval, void *extra);
# 60 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/replication/walreceiver.h" 1
# 15 "/Users/parrt/tmp/postgresql-9.2.4/src/include/replication/walreceiver.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/xlog.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/replication/walreceiver.h" 2

# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/spin.h" 1
# 59 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/spin.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/s_lock.h" 1
# 198 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/s_lock.h"
typedef unsigned char slock_t;



static __inline__ int
tas(volatile slock_t *lock)
{
 register slock_t _res = 1;






 __asm__ __volatile__(
  "	lock			\n"
  "	xchgb	%0,%1	\n"
: "+q"(_res), "+m"(*lock)
:
: "memory", "cc");
 return (int) _res;
}



static __inline__ void
spin_delay(void)
{




 __asm__ __volatile__(
  " rep; nop			\n");
}
# 1018 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/s_lock.h"
extern void s_lock(volatile slock_t *lock, const char *file, int line);




extern void set_spins_per_delay(int shared_spins_per_delay);
extern int update_spins_per_delay(int shared_spins_per_delay);
# 60 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/spin.h" 2
# 71 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/spin.h"
extern int SpinlockSemas(void);
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/replication/walreceiver.h" 2
# 1 "./pgtime.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/replication/walreceiver.h" 2

extern int wal_receiver_status_interval;
extern bool hot_standby_feedback;
# 36 "/Users/parrt/tmp/postgresql-9.2.4/src/include/replication/walreceiver.h"
typedef enum
{
 WALRCV_STOPPED,
 WALRCV_STARTING,

 WALRCV_RUNNING,
 WALRCV_STOPPING
} WalRcvState;


typedef struct
{





 pid_t pid;
 WalRcvState walRcvState;
 pg_time_t startTime;






 XLogRecPtr receiveStart;







 XLogRecPtr receivedUpto;







 XLogRecPtr latestChunkStart;




 TimestampTz lastMsgSendTime;
 TimestampTz lastMsgReceiptTime;




 XLogRecPtr latestWalEnd;
 TimestampTz latestWalEndTime;




 char conninfo[1024];

 slock_t mutex;
} WalRcvData;

extern WalRcvData *WalRcv;


typedef bool (*walrcv_connect_type) (char *conninfo, XLogRecPtr startpoint);
extern walrcv_connect_type walrcv_connect;

typedef bool (*walrcv_receive_type) (int timeout, unsigned char *type,
             char **buffer, int *len);
extern walrcv_receive_type walrcv_receive;

typedef void (*walrcv_send_type) (const char *buffer, int nbytes);
extern walrcv_send_type walrcv_send;

typedef void (*walrcv_disconnect_type) (void);
extern walrcv_disconnect_type walrcv_disconnect;


extern void WalReceiverMain(void);


extern Size WalRcvShmemSize(void);
extern void WalRcvShmemInit(void);
extern void ShutdownWalRcv(void);
extern bool WalRcvInProgress(void);
extern void RequestXLogStreaming(XLogRecPtr recptr, const char *conninfo);
extern XLogRecPtr GetWalRcvWriteRecPtr(XLogRecPtr *latestChunkStart);
extern int GetReplicationApplyDelay(void);
extern int GetReplicationTransferLatency(void);
# 61 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/replication/walsender.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/replication/walsender.h"
# 1 "./fmgr.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/replication/walsender.h" 2


extern bool am_walsender;
extern bool am_cascading_walsender;
extern volatile sig_atomic_t walsender_shutdown_requested;
extern volatile sig_atomic_t walsender_ready_to_stop;


extern int max_wal_senders;
extern int replication_timeout;

extern int WalSenderMain(void);
extern void WalSndSignals(void);
extern Size WalSndShmemSize(void);
extern void WalSndShmemInit(void);
extern void WalSndWakeup(void);
extern void WalSndRqstFileReload(void);

extern Datum pg_stat_get_wal_senders(FunctionCallInfo fcinfo);
# 62 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufmgr.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufmgr.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/buf.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufmgr.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufpage.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufmgr.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/relfilenode.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufmgr.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufmgr.h" 2

typedef void *Block;


typedef enum BufferAccessStrategyType
{
 BAS_NORMAL,
 BAS_BULKREAD,

 BAS_BULKWRITE,
 BAS_VACUUM
} BufferAccessStrategyType;


typedef enum
{
 RBM_NORMAL,
 RBM_ZERO,

 RBM_ZERO_ON_ERROR
} ReadBufferMode;


extern int NBuffers;


extern bool zero_damaged_pages;
extern int bgwriter_lru_maxpages;
extern double bgwriter_lru_multiplier;
extern bool track_io_timing;
extern int target_prefetch_pages;


extern char *BufferBlocks;
extern int32 *PrivateRefCount;


extern int NLocBuffer;
extern Block *LocalBufferBlockPointers;
extern int32 *LocalRefCount;
# 162 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/bufmgr.h"
extern void PrefetchBuffer(Relation reln, ForkNumber forkNum,
      BlockNumber blockNum);
extern Buffer ReadBuffer(Relation reln, BlockNumber blockNum);
extern Buffer ReadBufferExtended(Relation reln, ForkNumber forkNum,
       BlockNumber blockNum, ReadBufferMode mode,
       BufferAccessStrategy strategy);
extern Buffer ReadBufferWithoutRelcache(RelFileNode rnode,
        ForkNumber forkNum, BlockNumber blockNum,
        ReadBufferMode mode, BufferAccessStrategy strategy);
extern void ReleaseBuffer(Buffer buffer);
extern void UnlockReleaseBuffer(Buffer buffer);
extern void MarkBufferDirty(Buffer buffer);
extern void IncrBufferRefCount(Buffer buffer);
extern Buffer ReleaseAndReadBuffer(Buffer buffer, Relation relation,
      BlockNumber blockNum);

extern void InitBufferPool(void);
extern void InitBufferPoolAccess(void);
extern void InitBufferPoolBackend(void);
extern void AtEOXact_Buffers(bool isCommit);
extern void PrintBufferLeakWarning(Buffer buffer);
extern void CheckPointBuffers(int flags);
extern BlockNumber BufferGetBlockNumber(Buffer buffer);
extern BlockNumber RelationGetNumberOfBlocksInFork(Relation relation,
        ForkNumber forkNum);
extern void FlushRelationBuffers(Relation rel);
extern void FlushDatabaseBuffers(Oid dbid);
extern void DropRelFileNodeBuffers(RelFileNodeBackend rnode,
        ForkNumber forkNum, BlockNumber firstDelBlock);
extern void DropRelFileNodeAllBuffers(RelFileNodeBackend rnode);
extern void DropDatabaseBuffers(Oid dbid);




extern bool BufferIsPermanent(Buffer buffer);




extern Size BufferShmemSize(void);
extern void BufferGetTag(Buffer buffer, RelFileNode *rnode,
    ForkNumber *forknum, BlockNumber *blknum);

extern void SetBufferCommitInfoNeedsSave(Buffer buffer);

extern void UnlockBuffers(void);
extern void LockBuffer(Buffer buffer, int mode);
extern bool ConditionalLockBuffer(Buffer buffer);
extern void LockBufferForCleanup(Buffer buffer);
extern bool ConditionalLockBufferForCleanup(Buffer buffer);
extern bool HoldingBufferPinThatDelaysRecovery(void);

extern void AbortBufferIO(void);

extern void BufmgrCommit(void);
extern bool BgBufferSync(void);

extern void AtProcExit_LocalBuffers(void);


extern BufferAccessStrategy GetAccessStrategy(BufferAccessStrategyType btype);
extern void FreeAccessStrategy(BufferAccessStrategy strategy);
# 63 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/standby.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/standby.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/procsignal.h" 1
# 30 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/procsignal.h"
typedef enum
{
 PROCSIG_CATCHUP_INTERRUPT,
 PROCSIG_NOTIFY_INTERRUPT,


 PROCSIG_RECOVERY_CONFLICT_DATABASE,
 PROCSIG_RECOVERY_CONFLICT_TABLESPACE,
 PROCSIG_RECOVERY_CONFLICT_LOCK,
 PROCSIG_RECOVERY_CONFLICT_SNAPSHOT,
 PROCSIG_RECOVERY_CONFLICT_BUFFERPIN,
 PROCSIG_RECOVERY_CONFLICT_STARTUP_DEADLOCK,

 NUM_PROCSIGNALS
} ProcSignalReason;




extern Size ProcSignalShmemSize(void);
extern void ProcSignalShmemInit(void);

extern void ProcSignalInit(int pss_idx);
extern int SendProcSignal(pid_t pid, ProcSignalReason reason,
      BackendId backendId);

extern void procsignal_sigusr1_handler(int postgres_signal_arg);
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/standby.h" 2



extern int vacuum_defer_cleanup_age;
extern int max_standby_archive_delay;
extern int max_standby_streaming_delay;

extern void InitRecoveryTransactionEnvironment(void);
extern void ShutdownRecoveryTransactionEnvironment(void);

extern void ResolveRecoveryConflictWithSnapshot(TransactionId latestRemovedXid,
         RelFileNode node);
extern void ResolveRecoveryConflictWithTablespace(Oid tsid);
extern void ResolveRecoveryConflictWithDatabase(Oid dbid);

extern void ResolveRecoveryConflictWithBufferPin(void);
extern void SendRecoveryConflictWithBufferPin(ProcSignalReason reason);
extern void CheckRecoveryConflictDeadlock(void);
# 46 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/standby.h"
extern void StandbyAcquireAccessExclusiveLock(TransactionId xid, Oid dbOid, Oid relOid);
extern void StandbyReleaseLockTree(TransactionId xid,
        int nsubxids, TransactionId *subxids);
extern void StandbyReleaseAllLocks(void);
extern void StandbyReleaseOldLocks(int nxids, TransactionId *xids);







typedef struct xl_standby_locks
{
 int nlocks;
 xl_standby_lock locks[1];
} xl_standby_locks;




typedef struct xl_running_xacts
{
 int xcnt;
 bool subxid_overflow;
 TransactionId nextXid;
 TransactionId oldestRunningXid;
 TransactionId latestCompletedXid;

 TransactionId xids[1];
} xl_running_xacts;





extern void standby_redo(XLogRecPtr lsn, XLogRecord *record);
extern void standby_desc(StringInfo buf, uint8 xl_info, char *rec);
# 97 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/standby.h"
typedef struct RunningTransactionsData
{
 int xcnt;
 bool subxid_overflow;
 TransactionId nextXid;
 TransactionId oldestRunningXid;
 TransactionId latestCompletedXid;

 TransactionId *xids;
} RunningTransactionsData;

typedef RunningTransactionsData *RunningTransactions;

extern void LogAccessExclusiveLock(Oid dbOid, Oid relOid);
extern void LogAccessExclusiveLockPrepare(void);

extern void LogStandbySnapshot(void);
# 64 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/fd.h" 1
# 41 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/fd.h"
# 1 "./dirent.h" 1
# 9 "./dirent.h"
struct dirent
{
 long d_ino;
 unsigned short d_reclen;
 unsigned short d_namlen;
 char d_name[MAX_PATH];
};

typedef struct DIR DIR;

DIR *opendir(const char *);
struct dirent *readdir(DIR *);
int closedir(DIR *);
# 42 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/fd.h" 2






typedef char *FileName;

typedef int File;



extern int max_files_per_process;




extern int max_safe_fds;







extern File PathNameOpenFile(FileName fileName, int fileFlags, int fileMode);
extern File OpenTemporaryFile(bool interXact);
extern void FileClose(File file);
extern int FilePrefetch(File file, off_t offset, int amount);
extern int FileRead(File file, char *buffer, int amount);
extern int FileWrite(File file, char *buffer, int amount);
extern int FileSync(File file);
extern off_t FileSeek(File file, off_t offset, int whence);
extern int FileTruncate(File file, off_t offset);
extern char *FilePathName(File file);


extern FILE *AllocateFile(const char *name, const char *mode);
extern int FreeFile(FILE *file);


extern DIR *AllocateDir(const char *dirname);
extern struct dirent *ReadDir(DIR *dir, const char *dirname);
extern int FreeDir(DIR *dir);


extern int BasicOpenFile(FileName fileName, int fileFlags, int fileMode);


extern void InitFileAccess(void);
extern void set_max_safe_fds(void);
extern void closeAllVfds(void);
extern void SetTempTablespaces(Oid *tableSpaces, int numSpaces);
extern bool TempTablespacesAreSet(void);
extern Oid GetNextTempTableSpace(void);
extern void AtEOXact_Files(void);
extern void AtEOSubXact_Files(bool isCommit, SubTransactionId mySubid,
      SubTransactionId parentSubid);
extern void RemovePgTempFiles(void);

extern int pg_fsync(int fd);
extern int pg_fsync_no_writethrough(int fd);
extern int pg_fsync_writethrough(int fd);
extern int pg_fdatasync(int fd);
extern int pg_flush_data(int fd, off_t offset, off_t amount);
# 65 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/predicate.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/predicate.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/predicate.h" 2





extern int max_predicate_locks_per_xact;
# 36 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/predicate.h"
extern void InitPredicateLocks(void);
extern Size PredicateLockShmemSize(void);

extern void CheckPointPredicate(void);


extern bool PageIsPredicateLocked(Relation relation, BlockNumber blkno);


extern Snapshot GetSerializableTransactionSnapshot(Snapshot snapshot);
extern void SetSerializableTransactionSnapshot(Snapshot snapshot,
           TransactionId sourcexid);
extern void RegisterPredicateLockingXid(TransactionId xid);
extern void PredicateLockRelation(Relation relation, Snapshot snapshot);
extern void PredicateLockPage(Relation relation, BlockNumber blkno, Snapshot snapshot);
extern void PredicateLockTuple(Relation relation, HeapTuple tuple, Snapshot snapshot);
extern void PredicateLockPageSplit(Relation relation, BlockNumber oldblkno, BlockNumber newblkno);
extern void PredicateLockPageCombine(Relation relation, BlockNumber oldblkno, BlockNumber newblkno);
extern void TransferPredicateLocksToHeapRelation(Relation relation);
extern void ReleasePredicateLocks(bool isCommit);


extern void CheckForSerializableConflictOut(bool valid, Relation relation, HeapTuple tuple,
        Buffer buffer, Snapshot snapshot);
extern void CheckForSerializableConflictIn(Relation relation, HeapTuple tuple, Buffer buffer);
extern void CheckTableForSerializableConflictIn(Relation relation);


extern void PreCommit_CheckForSerializationFailure(void);


extern void AtPrepare_PredicateLocks(void);
extern void PostPrepare_PredicateLocks(TransactionId xid);
extern void PredicateLockTwoPhaseFinish(TransactionId xid, bool isCommit);
extern void predicatelock_twophase_recover(TransactionId xid, uint16 info,
          void *recdata, uint32 len);
# 66 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/tcopprot.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/tcopprot.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/execdesc.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/tcopprot.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/parsenodes.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/tcopprot.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/procsignal.h" 1
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/tcopprot.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 1
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tcop/tcopprot.h" 2





extern CommandDest whereToSendOutput;
extern const char *debug_query_string;
extern int max_stack_depth;
extern int PostAuthDelay;



typedef enum
{
 LOGSTMT_NONE,
 LOGSTMT_DDL,
 LOGSTMT_MOD,
 LOGSTMT_ALL
} LogStmtLevel;

extern int log_statement;

extern List *pg_parse_query(const char *query_string);
extern List *pg_analyze_and_rewrite(Node *parsetree, const char *query_string,
        Oid *paramTypes, int numParams);
extern List *pg_analyze_and_rewrite_params(Node *parsetree,
         const char *query_string,
         ParserSetupHook parserSetup,
         void *parserSetupArg);
extern PlannedStmt *pg_plan_query(Query *querytree, int cursorOptions,
     ParamListInfo boundParams);
extern List *pg_plan_queries(List *querytrees, int cursorOptions,
    ParamListInfo boundParams);

extern bool check_max_stack_depth(int *newval, void **extra, GucSource source);
extern void assign_max_stack_depth(int newval, void *extra);

extern void die(int postgres_signal_arg);
extern void quickdie(int postgres_signal_arg);
extern void StatementCancelHandler(int postgres_signal_arg);
extern void FloatExceptionHandler(int postgres_signal_arg);
extern void RecoveryConflictInterrupt(ProcSignalReason reason);

extern void prepare_for_client_read(void);
extern void client_read_ended(void);
extern void process_postgres_switches(int argc, char *argv[],
        GucContext ctx, const char **dbname);
extern int PostgresMain(int argc, char *argv[],
       const char *dbname, const char *username);
extern long get_stack_depth_rlimit(void);
extern void ResetUsage(void);
extern void ShowUsage(const char *title);
extern int check_log_duration(char *msec_str, bool was_logged);
extern void set_debug_options(int debug_flag,
      GucContext context, GucSource source);
extern bool set_plan_disabling_options(const char *arg,
         GucContext context, GucSource source);
extern const char *get_stats_option_name(const char *arg);
# 67 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tsearch/ts_cache.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tsearch/ts_cache.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/tsearch/ts_cache.h" 2






typedef struct TSAnyCacheEntry
{
 Oid objId;
 bool isvalid;
} TSAnyCacheEntry;


typedef struct TSParserCacheEntry
{

 Oid prsId;
 bool isvalid;

 Oid startOid;
 Oid tokenOid;
 Oid endOid;
 Oid headlineOid;
 Oid lextypeOid;




 FmgrInfo prsstart;
 FmgrInfo prstoken;
 FmgrInfo prsend;
 FmgrInfo prsheadline;
} TSParserCacheEntry;

typedef struct TSDictionaryCacheEntry
{

 Oid dictId;
 bool isvalid;


 Oid lexizeOid;
 FmgrInfo lexize;

 MemoryContext dictCtx;
 void *dictData;
} TSDictionaryCacheEntry;

typedef struct
{
 int len;
 Oid *dictIds;
} ListDictionary;

typedef struct
{

 Oid cfgId;
 bool isvalid;

 Oid prsId;

 int lenmap;
 ListDictionary *map;
} TSConfigCacheEntry;





extern char *TSCurrentConfig;


extern TSParserCacheEntry *lookup_ts_parser_cache(Oid prsId);
extern TSDictionaryCacheEntry *lookup_ts_dictionary_cache(Oid dictId);
extern TSConfigCacheEntry *lookup_ts_config_cache(Oid cfgId);

extern Oid getTSCurrentConfig(bool emitError);
extern bool check_TSCurrentConfig(char **newval, void **extra, GucSource source);
extern void assign_TSCurrentConfig(const char *newval, void *extra);
# 68 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/builtins.h" 1
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/builtins.h"
extern Datum has_any_column_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_any_column_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_any_column_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_any_column_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_any_column_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_any_column_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_name_name_name(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_name_name_attnum(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_name_id_name(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_name_id_attnum(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_id_name_name(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_id_name_attnum(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_id_id_name(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_id_id_attnum(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_name_attnum(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_column_privilege_id_attnum(FunctionCallInfo fcinfo);
extern Datum has_table_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_table_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_table_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_table_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_table_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_table_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_sequence_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_sequence_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_sequence_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_sequence_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_sequence_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_sequence_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_database_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_database_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_database_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_database_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_database_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_database_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_foreign_data_wrapper_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_foreign_data_wrapper_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_foreign_data_wrapper_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_foreign_data_wrapper_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_foreign_data_wrapper_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_foreign_data_wrapper_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_function_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_function_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_function_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_function_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_function_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_function_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_language_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_language_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_language_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_language_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_language_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_language_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_schema_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_schema_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_schema_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_schema_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_schema_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_schema_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_server_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_server_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_server_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_server_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_server_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_server_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_tablespace_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_tablespace_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_tablespace_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_tablespace_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_tablespace_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_tablespace_privilege_id(FunctionCallInfo fcinfo);
extern Datum has_type_privilege_name_name(FunctionCallInfo fcinfo);
extern Datum has_type_privilege_name_id(FunctionCallInfo fcinfo);
extern Datum has_type_privilege_id_name(FunctionCallInfo fcinfo);
extern Datum has_type_privilege_id_id(FunctionCallInfo fcinfo);
extern Datum has_type_privilege_name(FunctionCallInfo fcinfo);
extern Datum has_type_privilege_id(FunctionCallInfo fcinfo);
extern Datum pg_has_role_name_name(FunctionCallInfo fcinfo);
extern Datum pg_has_role_name_id(FunctionCallInfo fcinfo);
extern Datum pg_has_role_id_name(FunctionCallInfo fcinfo);
extern Datum pg_has_role_id_id(FunctionCallInfo fcinfo);
extern Datum pg_has_role_name(FunctionCallInfo fcinfo);
extern Datum pg_has_role_id(FunctionCallInfo fcinfo);


extern Datum boolin(FunctionCallInfo fcinfo);
extern Datum boolout(FunctionCallInfo fcinfo);
extern Datum boolrecv(FunctionCallInfo fcinfo);
extern Datum boolsend(FunctionCallInfo fcinfo);
extern Datum booltext(FunctionCallInfo fcinfo);
extern Datum booleq(FunctionCallInfo fcinfo);
extern Datum boolne(FunctionCallInfo fcinfo);
extern Datum boollt(FunctionCallInfo fcinfo);
extern Datum boolgt(FunctionCallInfo fcinfo);
extern Datum boolle(FunctionCallInfo fcinfo);
extern Datum boolge(FunctionCallInfo fcinfo);
extern Datum booland_statefunc(FunctionCallInfo fcinfo);
extern Datum boolor_statefunc(FunctionCallInfo fcinfo);
extern bool parse_bool(const char *value, bool *result);
extern bool parse_bool_with_len(const char *value, size_t len, bool *result);


extern Datum charin(FunctionCallInfo fcinfo);
extern Datum charout(FunctionCallInfo fcinfo);
extern Datum charrecv(FunctionCallInfo fcinfo);
extern Datum charsend(FunctionCallInfo fcinfo);
extern Datum chareq(FunctionCallInfo fcinfo);
extern Datum charne(FunctionCallInfo fcinfo);
extern Datum charlt(FunctionCallInfo fcinfo);
extern Datum charle(FunctionCallInfo fcinfo);
extern Datum chargt(FunctionCallInfo fcinfo);
extern Datum charge(FunctionCallInfo fcinfo);
extern Datum chartoi4(FunctionCallInfo fcinfo);
extern Datum i4tochar(FunctionCallInfo fcinfo);
extern Datum text_char(FunctionCallInfo fcinfo);
extern Datum char_text(FunctionCallInfo fcinfo);


extern Datum domain_in(FunctionCallInfo fcinfo);
extern Datum domain_recv(FunctionCallInfo fcinfo);
extern void domain_check(Datum value, bool isnull, Oid domainType, void **extra, MemoryContext mcxt);


extern Datum binary_encode(FunctionCallInfo fcinfo);
extern Datum binary_decode(FunctionCallInfo fcinfo);
extern unsigned hex_encode(const char *src, unsigned len, char *dst);
extern unsigned hex_decode(const char *src, unsigned len, char *dst);


extern Datum enum_in(FunctionCallInfo fcinfo);
extern Datum enum_out(FunctionCallInfo fcinfo);
extern Datum enum_recv(FunctionCallInfo fcinfo);
extern Datum enum_send(FunctionCallInfo fcinfo);
extern Datum enum_lt(FunctionCallInfo fcinfo);
extern Datum enum_le(FunctionCallInfo fcinfo);
extern Datum enum_eq(FunctionCallInfo fcinfo);
extern Datum enum_ne(FunctionCallInfo fcinfo);
extern Datum enum_ge(FunctionCallInfo fcinfo);
extern Datum enum_gt(FunctionCallInfo fcinfo);
extern Datum enum_cmp(FunctionCallInfo fcinfo);
extern Datum enum_smaller(FunctionCallInfo fcinfo);
extern Datum enum_larger(FunctionCallInfo fcinfo);
extern Datum enum_first(FunctionCallInfo fcinfo);
extern Datum enum_last(FunctionCallInfo fcinfo);
extern Datum enum_range_bounds(FunctionCallInfo fcinfo);
extern Datum enum_range_all(FunctionCallInfo fcinfo);


extern Datum int2in(FunctionCallInfo fcinfo);
extern Datum int2out(FunctionCallInfo fcinfo);
extern Datum int2recv(FunctionCallInfo fcinfo);
extern Datum int2send(FunctionCallInfo fcinfo);
extern Datum int2vectorin(FunctionCallInfo fcinfo);
extern Datum int2vectorout(FunctionCallInfo fcinfo);
extern Datum int2vectorrecv(FunctionCallInfo fcinfo);
extern Datum int2vectorsend(FunctionCallInfo fcinfo);
extern Datum int2vectoreq(FunctionCallInfo fcinfo);
extern Datum int4in(FunctionCallInfo fcinfo);
extern Datum int4out(FunctionCallInfo fcinfo);
extern Datum int4recv(FunctionCallInfo fcinfo);
extern Datum int4send(FunctionCallInfo fcinfo);
extern Datum i2toi4(FunctionCallInfo fcinfo);
extern Datum i4toi2(FunctionCallInfo fcinfo);
extern Datum int4_bool(FunctionCallInfo fcinfo);
extern Datum bool_int4(FunctionCallInfo fcinfo);
extern Datum int4eq(FunctionCallInfo fcinfo);
extern Datum int4ne(FunctionCallInfo fcinfo);
extern Datum int4lt(FunctionCallInfo fcinfo);
extern Datum int4le(FunctionCallInfo fcinfo);
extern Datum int4gt(FunctionCallInfo fcinfo);
extern Datum int4ge(FunctionCallInfo fcinfo);
extern Datum int2eq(FunctionCallInfo fcinfo);
extern Datum int2ne(FunctionCallInfo fcinfo);
extern Datum int2lt(FunctionCallInfo fcinfo);
extern Datum int2le(FunctionCallInfo fcinfo);
extern Datum int2gt(FunctionCallInfo fcinfo);
extern Datum int2ge(FunctionCallInfo fcinfo);
extern Datum int24eq(FunctionCallInfo fcinfo);
extern Datum int24ne(FunctionCallInfo fcinfo);
extern Datum int24lt(FunctionCallInfo fcinfo);
extern Datum int24le(FunctionCallInfo fcinfo);
extern Datum int24gt(FunctionCallInfo fcinfo);
extern Datum int24ge(FunctionCallInfo fcinfo);
extern Datum int42eq(FunctionCallInfo fcinfo);
extern Datum int42ne(FunctionCallInfo fcinfo);
extern Datum int42lt(FunctionCallInfo fcinfo);
extern Datum int42le(FunctionCallInfo fcinfo);
extern Datum int42gt(FunctionCallInfo fcinfo);
extern Datum int42ge(FunctionCallInfo fcinfo);
extern Datum int4um(FunctionCallInfo fcinfo);
extern Datum int4up(FunctionCallInfo fcinfo);
extern Datum int4pl(FunctionCallInfo fcinfo);
extern Datum int4mi(FunctionCallInfo fcinfo);
extern Datum int4mul(FunctionCallInfo fcinfo);
extern Datum int4div(FunctionCallInfo fcinfo);
extern Datum int4abs(FunctionCallInfo fcinfo);
extern Datum int4inc(FunctionCallInfo fcinfo);
extern Datum int2um(FunctionCallInfo fcinfo);
extern Datum int2up(FunctionCallInfo fcinfo);
extern Datum int2pl(FunctionCallInfo fcinfo);
extern Datum int2mi(FunctionCallInfo fcinfo);
extern Datum int2mul(FunctionCallInfo fcinfo);
extern Datum int2div(FunctionCallInfo fcinfo);
extern Datum int2abs(FunctionCallInfo fcinfo);
extern Datum int24pl(FunctionCallInfo fcinfo);
extern Datum int24mi(FunctionCallInfo fcinfo);
extern Datum int24mul(FunctionCallInfo fcinfo);
extern Datum int24div(FunctionCallInfo fcinfo);
extern Datum int42pl(FunctionCallInfo fcinfo);
extern Datum int42mi(FunctionCallInfo fcinfo);
extern Datum int42mul(FunctionCallInfo fcinfo);
extern Datum int42div(FunctionCallInfo fcinfo);
extern Datum int4mod(FunctionCallInfo fcinfo);
extern Datum int2mod(FunctionCallInfo fcinfo);
extern Datum int2larger(FunctionCallInfo fcinfo);
extern Datum int2smaller(FunctionCallInfo fcinfo);
extern Datum int4larger(FunctionCallInfo fcinfo);
extern Datum int4smaller(FunctionCallInfo fcinfo);

extern Datum int4and(FunctionCallInfo fcinfo);
extern Datum int4or(FunctionCallInfo fcinfo);
extern Datum int4xor(FunctionCallInfo fcinfo);
extern Datum int4not(FunctionCallInfo fcinfo);
extern Datum int4shl(FunctionCallInfo fcinfo);
extern Datum int4shr(FunctionCallInfo fcinfo);
extern Datum int2and(FunctionCallInfo fcinfo);
extern Datum int2or(FunctionCallInfo fcinfo);
extern Datum int2xor(FunctionCallInfo fcinfo);
extern Datum int2not(FunctionCallInfo fcinfo);
extern Datum int2shl(FunctionCallInfo fcinfo);
extern Datum int2shr(FunctionCallInfo fcinfo);
extern Datum generate_series_int4(FunctionCallInfo fcinfo);
extern Datum generate_series_step_int4(FunctionCallInfo fcinfo);
extern int2vector *buildint2vector(const int2 *int2s, int n);


extern Datum namein(FunctionCallInfo fcinfo);
extern Datum nameout(FunctionCallInfo fcinfo);
extern Datum namerecv(FunctionCallInfo fcinfo);
extern Datum namesend(FunctionCallInfo fcinfo);
extern Datum nameeq(FunctionCallInfo fcinfo);
extern Datum namene(FunctionCallInfo fcinfo);
extern Datum namelt(FunctionCallInfo fcinfo);
extern Datum namele(FunctionCallInfo fcinfo);
extern Datum namegt(FunctionCallInfo fcinfo);
extern Datum namege(FunctionCallInfo fcinfo);
extern int namecpy(Name n1, Name n2);
extern int namestrcpy(Name name, const char *str);
extern int namestrcmp(Name name, const char *str);
extern Datum current_user(FunctionCallInfo fcinfo);
extern Datum session_user(FunctionCallInfo fcinfo);
extern Datum current_schema(FunctionCallInfo fcinfo);
extern Datum current_schemas(FunctionCallInfo fcinfo);


extern int32 pg_atoi(char *s, int size, int c);
extern void pg_itoa(int16 i, char *a);
extern void pg_ltoa(int32 l, char *a);
extern void pg_lltoa(int64 ll, char *a);





extern Datum btboolcmp(FunctionCallInfo fcinfo);
extern Datum btint2cmp(FunctionCallInfo fcinfo);
extern Datum btint4cmp(FunctionCallInfo fcinfo);
extern Datum btint8cmp(FunctionCallInfo fcinfo);
extern Datum btfloat4cmp(FunctionCallInfo fcinfo);
extern Datum btfloat8cmp(FunctionCallInfo fcinfo);
extern Datum btint48cmp(FunctionCallInfo fcinfo);
extern Datum btint84cmp(FunctionCallInfo fcinfo);
extern Datum btint24cmp(FunctionCallInfo fcinfo);
extern Datum btint42cmp(FunctionCallInfo fcinfo);
extern Datum btint28cmp(FunctionCallInfo fcinfo);
extern Datum btint82cmp(FunctionCallInfo fcinfo);
extern Datum btfloat48cmp(FunctionCallInfo fcinfo);
extern Datum btfloat84cmp(FunctionCallInfo fcinfo);
extern Datum btoidcmp(FunctionCallInfo fcinfo);
extern Datum btoidvectorcmp(FunctionCallInfo fcinfo);
extern Datum btabstimecmp(FunctionCallInfo fcinfo);
extern Datum btreltimecmp(FunctionCallInfo fcinfo);
extern Datum bttintervalcmp(FunctionCallInfo fcinfo);
extern Datum btcharcmp(FunctionCallInfo fcinfo);
extern Datum btnamecmp(FunctionCallInfo fcinfo);
extern Datum bttextcmp(FunctionCallInfo fcinfo);






extern Datum btint2sortsupport(FunctionCallInfo fcinfo);
extern Datum btint4sortsupport(FunctionCallInfo fcinfo);
extern Datum btint8sortsupport(FunctionCallInfo fcinfo);
extern Datum btfloat4sortsupport(FunctionCallInfo fcinfo);
extern Datum btfloat8sortsupport(FunctionCallInfo fcinfo);
extern Datum btoidsortsupport(FunctionCallInfo fcinfo);
extern Datum btnamesortsupport(FunctionCallInfo fcinfo);


extern int extra_float_digits;

extern double get_float8_infinity(void);
extern float get_float4_infinity(void);
extern double get_float8_nan(void);
extern float get_float4_nan(void);
extern int is_infinite(double val);

extern Datum float4in(FunctionCallInfo fcinfo);
extern Datum float4out(FunctionCallInfo fcinfo);
extern Datum float4recv(FunctionCallInfo fcinfo);
extern Datum float4send(FunctionCallInfo fcinfo);
extern Datum float8in(FunctionCallInfo fcinfo);
extern Datum float8out(FunctionCallInfo fcinfo);
extern Datum float8recv(FunctionCallInfo fcinfo);
extern Datum float8send(FunctionCallInfo fcinfo);
extern Datum float4abs(FunctionCallInfo fcinfo);
extern Datum float4um(FunctionCallInfo fcinfo);
extern Datum float4up(FunctionCallInfo fcinfo);
extern Datum float4larger(FunctionCallInfo fcinfo);
extern Datum float4smaller(FunctionCallInfo fcinfo);
extern Datum float8abs(FunctionCallInfo fcinfo);
extern Datum float8um(FunctionCallInfo fcinfo);
extern Datum float8up(FunctionCallInfo fcinfo);
extern Datum float8larger(FunctionCallInfo fcinfo);
extern Datum float8smaller(FunctionCallInfo fcinfo);
extern Datum float4pl(FunctionCallInfo fcinfo);
extern Datum float4mi(FunctionCallInfo fcinfo);
extern Datum float4mul(FunctionCallInfo fcinfo);
extern Datum float4div(FunctionCallInfo fcinfo);
extern Datum float8pl(FunctionCallInfo fcinfo);
extern Datum float8mi(FunctionCallInfo fcinfo);
extern Datum float8mul(FunctionCallInfo fcinfo);
extern Datum float8div(FunctionCallInfo fcinfo);
extern Datum float4eq(FunctionCallInfo fcinfo);
extern Datum float4ne(FunctionCallInfo fcinfo);
extern Datum float4lt(FunctionCallInfo fcinfo);
extern Datum float4le(FunctionCallInfo fcinfo);
extern Datum float4gt(FunctionCallInfo fcinfo);
extern Datum float4ge(FunctionCallInfo fcinfo);
extern Datum float8eq(FunctionCallInfo fcinfo);
extern Datum float8ne(FunctionCallInfo fcinfo);
extern Datum float8lt(FunctionCallInfo fcinfo);
extern Datum float8le(FunctionCallInfo fcinfo);
extern Datum float8gt(FunctionCallInfo fcinfo);
extern Datum float8ge(FunctionCallInfo fcinfo);
extern Datum ftod(FunctionCallInfo fcinfo);
extern Datum i4tod(FunctionCallInfo fcinfo);
extern Datum i2tod(FunctionCallInfo fcinfo);
extern Datum dtof(FunctionCallInfo fcinfo);
extern Datum dtoi4(FunctionCallInfo fcinfo);
extern Datum dtoi2(FunctionCallInfo fcinfo);
extern Datum i4tof(FunctionCallInfo fcinfo);
extern Datum i2tof(FunctionCallInfo fcinfo);
extern Datum ftoi4(FunctionCallInfo fcinfo);
extern Datum ftoi2(FunctionCallInfo fcinfo);
extern Datum dround(FunctionCallInfo fcinfo);
extern Datum dceil(FunctionCallInfo fcinfo);
extern Datum dfloor(FunctionCallInfo fcinfo);
extern Datum dsign(FunctionCallInfo fcinfo);
extern Datum dtrunc(FunctionCallInfo fcinfo);
extern Datum dsqrt(FunctionCallInfo fcinfo);
extern Datum dcbrt(FunctionCallInfo fcinfo);
extern Datum dpow(FunctionCallInfo fcinfo);
extern Datum dexp(FunctionCallInfo fcinfo);
extern Datum dlog1(FunctionCallInfo fcinfo);
extern Datum dlog10(FunctionCallInfo fcinfo);
extern Datum dacos(FunctionCallInfo fcinfo);
extern Datum dasin(FunctionCallInfo fcinfo);
extern Datum datan(FunctionCallInfo fcinfo);
extern Datum datan2(FunctionCallInfo fcinfo);
extern Datum dcos(FunctionCallInfo fcinfo);
extern Datum dcot(FunctionCallInfo fcinfo);
extern Datum dsin(FunctionCallInfo fcinfo);
extern Datum dtan(FunctionCallInfo fcinfo);
extern Datum degrees(FunctionCallInfo fcinfo);
extern Datum dpi(FunctionCallInfo fcinfo);
extern Datum radians(FunctionCallInfo fcinfo);
extern Datum drandom(FunctionCallInfo fcinfo);
extern Datum setseed(FunctionCallInfo fcinfo);
extern Datum float8_accum(FunctionCallInfo fcinfo);
extern Datum float4_accum(FunctionCallInfo fcinfo);
extern Datum float8_avg(FunctionCallInfo fcinfo);
extern Datum float8_var_pop(FunctionCallInfo fcinfo);
extern Datum float8_var_samp(FunctionCallInfo fcinfo);
extern Datum float8_stddev_pop(FunctionCallInfo fcinfo);
extern Datum float8_stddev_samp(FunctionCallInfo fcinfo);
extern Datum float8_regr_accum(FunctionCallInfo fcinfo);
extern Datum float8_regr_sxx(FunctionCallInfo fcinfo);
extern Datum float8_regr_syy(FunctionCallInfo fcinfo);
extern Datum float8_regr_sxy(FunctionCallInfo fcinfo);
extern Datum float8_regr_avgx(FunctionCallInfo fcinfo);
extern Datum float8_regr_avgy(FunctionCallInfo fcinfo);
extern Datum float8_covar_pop(FunctionCallInfo fcinfo);
extern Datum float8_covar_samp(FunctionCallInfo fcinfo);
extern Datum float8_corr(FunctionCallInfo fcinfo);
extern Datum float8_regr_r2(FunctionCallInfo fcinfo);
extern Datum float8_regr_slope(FunctionCallInfo fcinfo);
extern Datum float8_regr_intercept(FunctionCallInfo fcinfo);
extern Datum float48pl(FunctionCallInfo fcinfo);
extern Datum float48mi(FunctionCallInfo fcinfo);
extern Datum float48mul(FunctionCallInfo fcinfo);
extern Datum float48div(FunctionCallInfo fcinfo);
extern Datum float84pl(FunctionCallInfo fcinfo);
extern Datum float84mi(FunctionCallInfo fcinfo);
extern Datum float84mul(FunctionCallInfo fcinfo);
extern Datum float84div(FunctionCallInfo fcinfo);
extern Datum float48eq(FunctionCallInfo fcinfo);
extern Datum float48ne(FunctionCallInfo fcinfo);
extern Datum float48lt(FunctionCallInfo fcinfo);
extern Datum float48le(FunctionCallInfo fcinfo);
extern Datum float48gt(FunctionCallInfo fcinfo);
extern Datum float48ge(FunctionCallInfo fcinfo);
extern Datum float84eq(FunctionCallInfo fcinfo);
extern Datum float84ne(FunctionCallInfo fcinfo);
extern Datum float84lt(FunctionCallInfo fcinfo);
extern Datum float84le(FunctionCallInfo fcinfo);
extern Datum float84gt(FunctionCallInfo fcinfo);
extern Datum float84ge(FunctionCallInfo fcinfo);
extern Datum width_bucket_float8(FunctionCallInfo fcinfo);


extern Datum pg_tablespace_size_oid(FunctionCallInfo fcinfo);
extern Datum pg_tablespace_size_name(FunctionCallInfo fcinfo);
extern Datum pg_database_size_oid(FunctionCallInfo fcinfo);
extern Datum pg_database_size_name(FunctionCallInfo fcinfo);
extern Datum pg_relation_size(FunctionCallInfo fcinfo);
extern Datum pg_total_relation_size(FunctionCallInfo fcinfo);
extern Datum pg_size_pretty(FunctionCallInfo fcinfo);
extern Datum pg_size_pretty_numeric(FunctionCallInfo fcinfo);
extern Datum pg_table_size(FunctionCallInfo fcinfo);
extern Datum pg_indexes_size(FunctionCallInfo fcinfo);
extern Datum pg_relation_filenode(FunctionCallInfo fcinfo);
extern Datum pg_relation_filepath(FunctionCallInfo fcinfo);


extern bytea *read_binary_file(const char *filename,
     int64 seek_offset, int64 bytes_to_read);
extern Datum pg_stat_file(FunctionCallInfo fcinfo);
extern Datum pg_read_file(FunctionCallInfo fcinfo);
extern Datum pg_read_file_all(FunctionCallInfo fcinfo);
extern Datum pg_read_binary_file(FunctionCallInfo fcinfo);
extern Datum pg_read_binary_file_all(FunctionCallInfo fcinfo);
extern Datum pg_ls_dir(FunctionCallInfo fcinfo);


extern Datum current_database(FunctionCallInfo fcinfo);
extern Datum current_query(FunctionCallInfo fcinfo);
extern Datum pg_cancel_backend(FunctionCallInfo fcinfo);
extern Datum pg_terminate_backend(FunctionCallInfo fcinfo);
extern Datum pg_reload_conf(FunctionCallInfo fcinfo);
extern Datum pg_tablespace_databases(FunctionCallInfo fcinfo);
extern Datum pg_tablespace_location(FunctionCallInfo fcinfo);
extern Datum pg_rotate_logfile(FunctionCallInfo fcinfo);
extern Datum pg_sleep(FunctionCallInfo fcinfo);
extern Datum pg_get_keywords(FunctionCallInfo fcinfo);
extern Datum pg_typeof(FunctionCallInfo fcinfo);
extern Datum pg_collation_for(FunctionCallInfo fcinfo);


extern Datum oidin(FunctionCallInfo fcinfo);
extern Datum oidout(FunctionCallInfo fcinfo);
extern Datum oidrecv(FunctionCallInfo fcinfo);
extern Datum oidsend(FunctionCallInfo fcinfo);
extern Datum oideq(FunctionCallInfo fcinfo);
extern Datum oidne(FunctionCallInfo fcinfo);
extern Datum oidlt(FunctionCallInfo fcinfo);
extern Datum oidle(FunctionCallInfo fcinfo);
extern Datum oidge(FunctionCallInfo fcinfo);
extern Datum oidgt(FunctionCallInfo fcinfo);
extern Datum oidlarger(FunctionCallInfo fcinfo);
extern Datum oidsmaller(FunctionCallInfo fcinfo);
extern Datum oidvectorin(FunctionCallInfo fcinfo);
extern Datum oidvectorout(FunctionCallInfo fcinfo);
extern Datum oidvectorrecv(FunctionCallInfo fcinfo);
extern Datum oidvectorsend(FunctionCallInfo fcinfo);
extern Datum oidvectoreq(FunctionCallInfo fcinfo);
extern Datum oidvectorne(FunctionCallInfo fcinfo);
extern Datum oidvectorlt(FunctionCallInfo fcinfo);
extern Datum oidvectorle(FunctionCallInfo fcinfo);
extern Datum oidvectorge(FunctionCallInfo fcinfo);
extern Datum oidvectorgt(FunctionCallInfo fcinfo);
extern oidvector *buildoidvector(const Oid *oids, int n);
extern Oid oidparse(Node *node);


extern Datum cstring_in(FunctionCallInfo fcinfo);
extern Datum cstring_out(FunctionCallInfo fcinfo);
extern Datum cstring_recv(FunctionCallInfo fcinfo);
extern Datum cstring_send(FunctionCallInfo fcinfo);
extern Datum any_in(FunctionCallInfo fcinfo);
extern Datum any_out(FunctionCallInfo fcinfo);
extern Datum anyarray_in(FunctionCallInfo fcinfo);
extern Datum anyarray_out(FunctionCallInfo fcinfo);
extern Datum anyarray_recv(FunctionCallInfo fcinfo);
extern Datum anyarray_send(FunctionCallInfo fcinfo);
extern Datum anynonarray_in(FunctionCallInfo fcinfo);
extern Datum anynonarray_out(FunctionCallInfo fcinfo);
extern Datum anyenum_in(FunctionCallInfo fcinfo);
extern Datum anyenum_out(FunctionCallInfo fcinfo);
extern Datum anyrange_in(FunctionCallInfo fcinfo);
extern Datum anyrange_out(FunctionCallInfo fcinfo);
extern Datum void_in(FunctionCallInfo fcinfo);
extern Datum void_out(FunctionCallInfo fcinfo);
extern Datum void_recv(FunctionCallInfo fcinfo);
extern Datum void_send(FunctionCallInfo fcinfo);
extern Datum trigger_in(FunctionCallInfo fcinfo);
extern Datum trigger_out(FunctionCallInfo fcinfo);
extern Datum language_handler_in(FunctionCallInfo fcinfo);
extern Datum language_handler_out(FunctionCallInfo fcinfo);
extern Datum fdw_handler_in(FunctionCallInfo fcinfo);
extern Datum fdw_handler_out(FunctionCallInfo fcinfo);
extern Datum internal_in(FunctionCallInfo fcinfo);
extern Datum internal_out(FunctionCallInfo fcinfo);
extern Datum opaque_in(FunctionCallInfo fcinfo);
extern Datum opaque_out(FunctionCallInfo fcinfo);
extern Datum anyelement_in(FunctionCallInfo fcinfo);
extern Datum anyelement_out(FunctionCallInfo fcinfo);
extern Datum shell_in(FunctionCallInfo fcinfo);
extern Datum shell_out(FunctionCallInfo fcinfo);
extern Datum pg_node_tree_in(FunctionCallInfo fcinfo);
extern Datum pg_node_tree_out(FunctionCallInfo fcinfo);
extern Datum pg_node_tree_recv(FunctionCallInfo fcinfo);
extern Datum pg_node_tree_send(FunctionCallInfo fcinfo);


extern Datum nameregexeq(FunctionCallInfo fcinfo);
extern Datum nameregexne(FunctionCallInfo fcinfo);
extern Datum textregexeq(FunctionCallInfo fcinfo);
extern Datum textregexne(FunctionCallInfo fcinfo);
extern Datum nameicregexeq(FunctionCallInfo fcinfo);
extern Datum nameicregexne(FunctionCallInfo fcinfo);
extern Datum texticregexeq(FunctionCallInfo fcinfo);
extern Datum texticregexne(FunctionCallInfo fcinfo);
extern Datum textregexsubstr(FunctionCallInfo fcinfo);
extern Datum textregexreplace_noopt(FunctionCallInfo fcinfo);
extern Datum textregexreplace(FunctionCallInfo fcinfo);
extern Datum similar_escape(FunctionCallInfo fcinfo);
extern Datum regexp_matches(FunctionCallInfo fcinfo);
extern Datum regexp_matches_no_flags(FunctionCallInfo fcinfo);
extern Datum regexp_split_to_table(FunctionCallInfo fcinfo);
extern Datum regexp_split_to_table_no_flags(FunctionCallInfo fcinfo);
extern Datum regexp_split_to_array(FunctionCallInfo fcinfo);
extern Datum regexp_split_to_array_no_flags(FunctionCallInfo fcinfo);
extern char *regexp_fixed_prefix(text *text_re, bool case_insensitive,
         Oid collation, bool *exact);


extern Datum regprocin(FunctionCallInfo fcinfo);
extern Datum regprocout(FunctionCallInfo fcinfo);
extern Datum regprocrecv(FunctionCallInfo fcinfo);
extern Datum regprocsend(FunctionCallInfo fcinfo);
extern Datum regprocedurein(FunctionCallInfo fcinfo);
extern Datum regprocedureout(FunctionCallInfo fcinfo);
extern Datum regprocedurerecv(FunctionCallInfo fcinfo);
extern Datum regproceduresend(FunctionCallInfo fcinfo);
extern Datum regoperin(FunctionCallInfo fcinfo);
extern Datum regoperout(FunctionCallInfo fcinfo);
extern Datum regoperrecv(FunctionCallInfo fcinfo);
extern Datum regopersend(FunctionCallInfo fcinfo);
extern Datum regoperatorin(FunctionCallInfo fcinfo);
extern Datum regoperatorout(FunctionCallInfo fcinfo);
extern Datum regoperatorrecv(FunctionCallInfo fcinfo);
extern Datum regoperatorsend(FunctionCallInfo fcinfo);
extern Datum regclassin(FunctionCallInfo fcinfo);
extern Datum regclassout(FunctionCallInfo fcinfo);
extern Datum regclassrecv(FunctionCallInfo fcinfo);
extern Datum regclasssend(FunctionCallInfo fcinfo);
extern Datum regtypein(FunctionCallInfo fcinfo);
extern Datum regtypeout(FunctionCallInfo fcinfo);
extern Datum regtyperecv(FunctionCallInfo fcinfo);
extern Datum regtypesend(FunctionCallInfo fcinfo);
extern Datum regconfigin(FunctionCallInfo fcinfo);
extern Datum regconfigout(FunctionCallInfo fcinfo);
extern Datum regconfigrecv(FunctionCallInfo fcinfo);
extern Datum regconfigsend(FunctionCallInfo fcinfo);
extern Datum regdictionaryin(FunctionCallInfo fcinfo);
extern Datum regdictionaryout(FunctionCallInfo fcinfo);
extern Datum regdictionaryrecv(FunctionCallInfo fcinfo);
extern Datum regdictionarysend(FunctionCallInfo fcinfo);
extern Datum text_regclass(FunctionCallInfo fcinfo);
extern List *stringToQualifiedNameList(const char *string);
extern char *format_procedure(Oid procedure_oid);
extern char *format_operator(Oid operator_oid);


extern Datum record_in(FunctionCallInfo fcinfo);
extern Datum record_out(FunctionCallInfo fcinfo);
extern Datum record_recv(FunctionCallInfo fcinfo);
extern Datum record_send(FunctionCallInfo fcinfo);
extern Datum record_eq(FunctionCallInfo fcinfo);
extern Datum record_ne(FunctionCallInfo fcinfo);
extern Datum record_lt(FunctionCallInfo fcinfo);
extern Datum record_gt(FunctionCallInfo fcinfo);
extern Datum record_le(FunctionCallInfo fcinfo);
extern Datum record_ge(FunctionCallInfo fcinfo);
extern Datum btrecordcmp(FunctionCallInfo fcinfo);


extern bool quote_all_identifiers;
extern Datum pg_get_ruledef(FunctionCallInfo fcinfo);
extern Datum pg_get_ruledef_ext(FunctionCallInfo fcinfo);
extern Datum pg_get_viewdef(FunctionCallInfo fcinfo);
extern Datum pg_get_viewdef_ext(FunctionCallInfo fcinfo);
extern Datum pg_get_viewdef_wrap(FunctionCallInfo fcinfo);
extern Datum pg_get_viewdef_name(FunctionCallInfo fcinfo);
extern Datum pg_get_viewdef_name_ext(FunctionCallInfo fcinfo);
extern Datum pg_get_indexdef(FunctionCallInfo fcinfo);
extern Datum pg_get_indexdef_ext(FunctionCallInfo fcinfo);
extern char *pg_get_indexdef_string(Oid indexrelid);
extern char *pg_get_indexdef_columns(Oid indexrelid, bool pretty);
extern Datum pg_get_triggerdef(FunctionCallInfo fcinfo);
extern Datum pg_get_triggerdef_ext(FunctionCallInfo fcinfo);
extern Datum pg_get_constraintdef(FunctionCallInfo fcinfo);
extern Datum pg_get_constraintdef_ext(FunctionCallInfo fcinfo);
extern char *pg_get_constraintdef_string(Oid constraintId);
extern Datum pg_get_expr(FunctionCallInfo fcinfo);
extern Datum pg_get_expr_ext(FunctionCallInfo fcinfo);
extern Datum pg_get_userbyid(FunctionCallInfo fcinfo);
extern Datum pg_get_serial_sequence(FunctionCallInfo fcinfo);
extern Datum pg_get_functiondef(FunctionCallInfo fcinfo);
extern Datum pg_get_function_arguments(FunctionCallInfo fcinfo);
extern Datum pg_get_function_identity_arguments(FunctionCallInfo fcinfo);
extern Datum pg_get_function_result(FunctionCallInfo fcinfo);
extern char *deparse_expression(Node *expr, List *dpcontext,
       bool forceprefix, bool showimplicit);
extern List *deparse_context_for(const char *aliasname, Oid relid);
extern List *deparse_context_for_planstate(Node *planstate, List *ancestors,
         List *rtable);
extern const char *quote_identifier(const char *ident);
extern char *quote_qualified_identifier(const char *qualifier,
         const char *ident);
extern char *generate_collation_name(Oid collid);



extern Datum tidin(FunctionCallInfo fcinfo);
extern Datum tidout(FunctionCallInfo fcinfo);
extern Datum tidrecv(FunctionCallInfo fcinfo);
extern Datum tidsend(FunctionCallInfo fcinfo);
extern Datum tideq(FunctionCallInfo fcinfo);
extern Datum tidne(FunctionCallInfo fcinfo);
extern Datum tidlt(FunctionCallInfo fcinfo);
extern Datum tidle(FunctionCallInfo fcinfo);
extern Datum tidgt(FunctionCallInfo fcinfo);
extern Datum tidge(FunctionCallInfo fcinfo);
extern Datum bttidcmp(FunctionCallInfo fcinfo);
extern Datum tidlarger(FunctionCallInfo fcinfo);
extern Datum tidsmaller(FunctionCallInfo fcinfo);
extern Datum currtid_byreloid(FunctionCallInfo fcinfo);
extern Datum currtid_byrelname(FunctionCallInfo fcinfo);


extern Datum bpcharin(FunctionCallInfo fcinfo);
extern Datum bpcharout(FunctionCallInfo fcinfo);
extern Datum bpcharrecv(FunctionCallInfo fcinfo);
extern Datum bpcharsend(FunctionCallInfo fcinfo);
extern Datum bpchartypmodin(FunctionCallInfo fcinfo);
extern Datum bpchartypmodout(FunctionCallInfo fcinfo);
extern Datum bpchar(FunctionCallInfo fcinfo);
extern Datum char_bpchar(FunctionCallInfo fcinfo);
extern Datum name_bpchar(FunctionCallInfo fcinfo);
extern Datum bpchar_name(FunctionCallInfo fcinfo);
extern Datum bpchareq(FunctionCallInfo fcinfo);
extern Datum bpcharne(FunctionCallInfo fcinfo);
extern Datum bpcharlt(FunctionCallInfo fcinfo);
extern Datum bpcharle(FunctionCallInfo fcinfo);
extern Datum bpchargt(FunctionCallInfo fcinfo);
extern Datum bpcharge(FunctionCallInfo fcinfo);
extern Datum bpcharcmp(FunctionCallInfo fcinfo);
extern Datum bpchar_larger(FunctionCallInfo fcinfo);
extern Datum bpchar_smaller(FunctionCallInfo fcinfo);
extern Datum bpcharlen(FunctionCallInfo fcinfo);
extern Datum bpcharoctetlen(FunctionCallInfo fcinfo);
extern Datum hashbpchar(FunctionCallInfo fcinfo);
extern Datum bpchar_pattern_lt(FunctionCallInfo fcinfo);
extern Datum bpchar_pattern_le(FunctionCallInfo fcinfo);
extern Datum bpchar_pattern_gt(FunctionCallInfo fcinfo);
extern Datum bpchar_pattern_ge(FunctionCallInfo fcinfo);
extern Datum btbpchar_pattern_cmp(FunctionCallInfo fcinfo);

extern Datum varcharin(FunctionCallInfo fcinfo);
extern Datum varcharout(FunctionCallInfo fcinfo);
extern Datum varcharrecv(FunctionCallInfo fcinfo);
extern Datum varcharsend(FunctionCallInfo fcinfo);
extern Datum varchartypmodin(FunctionCallInfo fcinfo);
extern Datum varchartypmodout(FunctionCallInfo fcinfo);
extern Datum varchar_transform(FunctionCallInfo fcinfo);
extern Datum varchar(FunctionCallInfo fcinfo);


extern text *cstring_to_text(const char *s);
extern text *cstring_to_text_with_len(const char *s, int len);
extern char *text_to_cstring(const text *t);
extern void text_to_cstring_buffer(const text *src, char *dst, size_t dst_len);




extern Datum textin(FunctionCallInfo fcinfo);
extern Datum textout(FunctionCallInfo fcinfo);
extern Datum textrecv(FunctionCallInfo fcinfo);
extern Datum textsend(FunctionCallInfo fcinfo);
extern Datum textcat(FunctionCallInfo fcinfo);
extern Datum texteq(FunctionCallInfo fcinfo);
extern Datum textne(FunctionCallInfo fcinfo);
extern Datum text_lt(FunctionCallInfo fcinfo);
extern Datum text_le(FunctionCallInfo fcinfo);
extern Datum text_gt(FunctionCallInfo fcinfo);
extern Datum text_ge(FunctionCallInfo fcinfo);
extern Datum text_larger(FunctionCallInfo fcinfo);
extern Datum text_smaller(FunctionCallInfo fcinfo);
extern Datum text_pattern_lt(FunctionCallInfo fcinfo);
extern Datum text_pattern_le(FunctionCallInfo fcinfo);
extern Datum text_pattern_gt(FunctionCallInfo fcinfo);
extern Datum text_pattern_ge(FunctionCallInfo fcinfo);
extern Datum bttext_pattern_cmp(FunctionCallInfo fcinfo);
extern Datum textlen(FunctionCallInfo fcinfo);
extern Datum textoctetlen(FunctionCallInfo fcinfo);
extern Datum textpos(FunctionCallInfo fcinfo);
extern Datum text_substr(FunctionCallInfo fcinfo);
extern Datum text_substr_no_len(FunctionCallInfo fcinfo);
extern Datum textoverlay(FunctionCallInfo fcinfo);
extern Datum textoverlay_no_len(FunctionCallInfo fcinfo);
extern Datum name_text(FunctionCallInfo fcinfo);
extern Datum text_name(FunctionCallInfo fcinfo);
extern int varstr_cmp(char *arg1, int len1, char *arg2, int len2, Oid collid);
extern List *textToQualifiedNameList(text *textval);
extern bool SplitIdentifierString(char *rawstring, char separator,
       List **namelist);
extern Datum replace_text(FunctionCallInfo fcinfo);
extern text *replace_text_regexp(text *src_text, void *regexp,
     text *replace_text, bool glob);
extern Datum split_text(FunctionCallInfo fcinfo);
extern Datum text_to_array(FunctionCallInfo fcinfo);
extern Datum array_to_text(FunctionCallInfo fcinfo);
extern Datum text_to_array_null(FunctionCallInfo fcinfo);
extern Datum array_to_text_null(FunctionCallInfo fcinfo);
extern Datum to_hex32(FunctionCallInfo fcinfo);
extern Datum to_hex64(FunctionCallInfo fcinfo);
extern Datum md5_text(FunctionCallInfo fcinfo);
extern Datum md5_bytea(FunctionCallInfo fcinfo);

extern Datum unknownin(FunctionCallInfo fcinfo);
extern Datum unknownout(FunctionCallInfo fcinfo);
extern Datum unknownrecv(FunctionCallInfo fcinfo);
extern Datum unknownsend(FunctionCallInfo fcinfo);

extern Datum pg_column_size(FunctionCallInfo fcinfo);

extern Datum bytea_string_agg_transfn(FunctionCallInfo fcinfo);
extern Datum bytea_string_agg_finalfn(FunctionCallInfo fcinfo);
extern Datum string_agg_transfn(FunctionCallInfo fcinfo);
extern Datum string_agg_finalfn(FunctionCallInfo fcinfo);

extern Datum text_concat(FunctionCallInfo fcinfo);
extern Datum text_concat_ws(FunctionCallInfo fcinfo);
extern Datum text_left(FunctionCallInfo fcinfo);
extern Datum text_right(FunctionCallInfo fcinfo);
extern Datum text_reverse(FunctionCallInfo fcinfo);
extern Datum text_format(FunctionCallInfo fcinfo);
extern Datum text_format_nv(FunctionCallInfo fcinfo);


extern Datum pgsql_version(FunctionCallInfo fcinfo);


extern Datum xidin(FunctionCallInfo fcinfo);
extern Datum xidout(FunctionCallInfo fcinfo);
extern Datum xidrecv(FunctionCallInfo fcinfo);
extern Datum xidsend(FunctionCallInfo fcinfo);
extern Datum xideq(FunctionCallInfo fcinfo);
extern Datum xid_age(FunctionCallInfo fcinfo);
extern int xidComparator(const void *arg1, const void *arg2);
extern Datum cidin(FunctionCallInfo fcinfo);
extern Datum cidout(FunctionCallInfo fcinfo);
extern Datum cidrecv(FunctionCallInfo fcinfo);
extern Datum cidsend(FunctionCallInfo fcinfo);
extern Datum cideq(FunctionCallInfo fcinfo);


extern Datum namelike(FunctionCallInfo fcinfo);
extern Datum namenlike(FunctionCallInfo fcinfo);
extern Datum nameiclike(FunctionCallInfo fcinfo);
extern Datum nameicnlike(FunctionCallInfo fcinfo);
extern Datum textlike(FunctionCallInfo fcinfo);
extern Datum textnlike(FunctionCallInfo fcinfo);
extern Datum texticlike(FunctionCallInfo fcinfo);
extern Datum texticnlike(FunctionCallInfo fcinfo);
extern Datum bytealike(FunctionCallInfo fcinfo);
extern Datum byteanlike(FunctionCallInfo fcinfo);
extern Datum like_escape(FunctionCallInfo fcinfo);
extern Datum like_escape_bytea(FunctionCallInfo fcinfo);


extern Datum lower(FunctionCallInfo fcinfo);
extern Datum upper(FunctionCallInfo fcinfo);
extern Datum initcap(FunctionCallInfo fcinfo);
extern Datum lpad(FunctionCallInfo fcinfo);
extern Datum rpad(FunctionCallInfo fcinfo);
extern Datum btrim(FunctionCallInfo fcinfo);
extern Datum btrim1(FunctionCallInfo fcinfo);
extern Datum byteatrim(FunctionCallInfo fcinfo);
extern Datum ltrim(FunctionCallInfo fcinfo);
extern Datum ltrim1(FunctionCallInfo fcinfo);
extern Datum rtrim(FunctionCallInfo fcinfo);
extern Datum rtrim1(FunctionCallInfo fcinfo);
extern Datum translate(FunctionCallInfo fcinfo);
extern Datum chr (FunctionCallInfo fcinfo);
extern Datum repeat(FunctionCallInfo fcinfo);
extern Datum ascii(FunctionCallInfo fcinfo);


extern char *inet_cidr_ntop(int af, const void *src, int bits,
      char *dst, size_t size);


extern int inet_net_pton(int af, const char *src,
     void *dst, size_t size);


extern Datum inet_in(FunctionCallInfo fcinfo);
extern Datum inet_out(FunctionCallInfo fcinfo);
extern Datum inet_recv(FunctionCallInfo fcinfo);
extern Datum inet_send(FunctionCallInfo fcinfo);
extern Datum cidr_in(FunctionCallInfo fcinfo);
extern Datum cidr_out(FunctionCallInfo fcinfo);
extern Datum cidr_recv(FunctionCallInfo fcinfo);
extern Datum cidr_send(FunctionCallInfo fcinfo);
extern Datum network_cmp(FunctionCallInfo fcinfo);
extern Datum network_lt(FunctionCallInfo fcinfo);
extern Datum network_le(FunctionCallInfo fcinfo);
extern Datum network_eq(FunctionCallInfo fcinfo);
extern Datum network_ge(FunctionCallInfo fcinfo);
extern Datum network_gt(FunctionCallInfo fcinfo);
extern Datum network_ne(FunctionCallInfo fcinfo);
extern Datum hashinet(FunctionCallInfo fcinfo);
extern Datum network_sub(FunctionCallInfo fcinfo);
extern Datum network_subeq(FunctionCallInfo fcinfo);
extern Datum network_sup(FunctionCallInfo fcinfo);
extern Datum network_supeq(FunctionCallInfo fcinfo);
extern Datum network_network(FunctionCallInfo fcinfo);
extern Datum network_netmask(FunctionCallInfo fcinfo);
extern Datum network_hostmask(FunctionCallInfo fcinfo);
extern Datum network_masklen(FunctionCallInfo fcinfo);
extern Datum network_family(FunctionCallInfo fcinfo);
extern Datum network_broadcast(FunctionCallInfo fcinfo);
extern Datum network_host(FunctionCallInfo fcinfo);
extern Datum network_show(FunctionCallInfo fcinfo);
extern Datum inet_abbrev(FunctionCallInfo fcinfo);
extern Datum cidr_abbrev(FunctionCallInfo fcinfo);
extern double convert_network_to_scalar(Datum value, Oid typid);
extern Datum inet_to_cidr(FunctionCallInfo fcinfo);
extern Datum inet_set_masklen(FunctionCallInfo fcinfo);
extern Datum cidr_set_masklen(FunctionCallInfo fcinfo);
extern Datum network_scan_first(Datum in);
extern Datum network_scan_last(Datum in);
extern Datum inet_client_addr(FunctionCallInfo fcinfo);
extern Datum inet_client_port(FunctionCallInfo fcinfo);
extern Datum inet_server_addr(FunctionCallInfo fcinfo);
extern Datum inet_server_port(FunctionCallInfo fcinfo);
extern Datum inetnot(FunctionCallInfo fcinfo);
extern Datum inetand(FunctionCallInfo fcinfo);
extern Datum inetor(FunctionCallInfo fcinfo);
extern Datum inetpl(FunctionCallInfo fcinfo);
extern Datum inetmi_int8(FunctionCallInfo fcinfo);
extern Datum inetmi(FunctionCallInfo fcinfo);
extern void clean_ipv6_addr(int addr_family, char *addr);


extern Datum macaddr_in(FunctionCallInfo fcinfo);
extern Datum macaddr_out(FunctionCallInfo fcinfo);
extern Datum macaddr_recv(FunctionCallInfo fcinfo);
extern Datum macaddr_send(FunctionCallInfo fcinfo);
extern Datum macaddr_cmp(FunctionCallInfo fcinfo);
extern Datum macaddr_lt(FunctionCallInfo fcinfo);
extern Datum macaddr_le(FunctionCallInfo fcinfo);
extern Datum macaddr_eq(FunctionCallInfo fcinfo);
extern Datum macaddr_ge(FunctionCallInfo fcinfo);
extern Datum macaddr_gt(FunctionCallInfo fcinfo);
extern Datum macaddr_ne(FunctionCallInfo fcinfo);
extern Datum macaddr_not(FunctionCallInfo fcinfo);
extern Datum macaddr_and(FunctionCallInfo fcinfo);
extern Datum macaddr_or(FunctionCallInfo fcinfo);
extern Datum macaddr_trunc(FunctionCallInfo fcinfo);
extern Datum hashmacaddr(FunctionCallInfo fcinfo);


extern Datum numeric_in(FunctionCallInfo fcinfo);
extern Datum numeric_out(FunctionCallInfo fcinfo);
extern Datum numeric_recv(FunctionCallInfo fcinfo);
extern Datum numeric_send(FunctionCallInfo fcinfo);
extern Datum numerictypmodin(FunctionCallInfo fcinfo);
extern Datum numerictypmodout(FunctionCallInfo fcinfo);
extern Datum numeric_transform(FunctionCallInfo fcinfo);
extern Datum numeric (FunctionCallInfo fcinfo);
extern Datum numeric_abs(FunctionCallInfo fcinfo);
extern Datum numeric_uminus(FunctionCallInfo fcinfo);
extern Datum numeric_uplus(FunctionCallInfo fcinfo);
extern Datum numeric_sign(FunctionCallInfo fcinfo);
extern Datum numeric_round(FunctionCallInfo fcinfo);
extern Datum numeric_trunc(FunctionCallInfo fcinfo);
extern Datum numeric_ceil(FunctionCallInfo fcinfo);
extern Datum numeric_floor(FunctionCallInfo fcinfo);
extern Datum numeric_cmp(FunctionCallInfo fcinfo);
extern Datum numeric_eq(FunctionCallInfo fcinfo);
extern Datum numeric_ne(FunctionCallInfo fcinfo);
extern Datum numeric_gt(FunctionCallInfo fcinfo);
extern Datum numeric_ge(FunctionCallInfo fcinfo);
extern Datum numeric_lt(FunctionCallInfo fcinfo);
extern Datum numeric_le(FunctionCallInfo fcinfo);
extern Datum numeric_add(FunctionCallInfo fcinfo);
extern Datum numeric_sub(FunctionCallInfo fcinfo);
extern Datum numeric_mul(FunctionCallInfo fcinfo);
extern Datum numeric_div(FunctionCallInfo fcinfo);
extern Datum numeric_div_trunc(FunctionCallInfo fcinfo);
extern Datum numeric_mod(FunctionCallInfo fcinfo);
extern Datum numeric_inc(FunctionCallInfo fcinfo);
extern Datum numeric_smaller(FunctionCallInfo fcinfo);
extern Datum numeric_larger(FunctionCallInfo fcinfo);
extern Datum numeric_fac(FunctionCallInfo fcinfo);
extern Datum numeric_sqrt(FunctionCallInfo fcinfo);
extern Datum numeric_exp(FunctionCallInfo fcinfo);
extern Datum numeric_ln(FunctionCallInfo fcinfo);
extern Datum numeric_log(FunctionCallInfo fcinfo);
extern Datum numeric_power(FunctionCallInfo fcinfo);
extern Datum int4_numeric(FunctionCallInfo fcinfo);
extern Datum numeric_int4(FunctionCallInfo fcinfo);
extern Datum int8_numeric(FunctionCallInfo fcinfo);
extern Datum numeric_int8(FunctionCallInfo fcinfo);
extern Datum int2_numeric(FunctionCallInfo fcinfo);
extern Datum numeric_int2(FunctionCallInfo fcinfo);
extern Datum float8_numeric(FunctionCallInfo fcinfo);
extern Datum numeric_float8(FunctionCallInfo fcinfo);
extern Datum numeric_float8_no_overflow(FunctionCallInfo fcinfo);
extern Datum float4_numeric(FunctionCallInfo fcinfo);
extern Datum numeric_float4(FunctionCallInfo fcinfo);
extern Datum numeric_accum(FunctionCallInfo fcinfo);
extern Datum numeric_avg_accum(FunctionCallInfo fcinfo);
extern Datum int2_accum(FunctionCallInfo fcinfo);
extern Datum int4_accum(FunctionCallInfo fcinfo);
extern Datum int8_accum(FunctionCallInfo fcinfo);
extern Datum int8_avg_accum(FunctionCallInfo fcinfo);
extern Datum numeric_avg(FunctionCallInfo fcinfo);
extern Datum numeric_var_pop(FunctionCallInfo fcinfo);
extern Datum numeric_var_samp(FunctionCallInfo fcinfo);
extern Datum numeric_stddev_pop(FunctionCallInfo fcinfo);
extern Datum numeric_stddev_samp(FunctionCallInfo fcinfo);
extern Datum int2_sum(FunctionCallInfo fcinfo);
extern Datum int4_sum(FunctionCallInfo fcinfo);
extern Datum int8_sum(FunctionCallInfo fcinfo);
extern Datum int2_avg_accum(FunctionCallInfo fcinfo);
extern Datum int4_avg_accum(FunctionCallInfo fcinfo);
extern Datum int8_avg(FunctionCallInfo fcinfo);
extern Datum width_bucket_numeric(FunctionCallInfo fcinfo);
extern Datum hash_numeric(FunctionCallInfo fcinfo);


extern Datum RI_FKey_check_ins(FunctionCallInfo fcinfo);
extern Datum RI_FKey_check_upd(FunctionCallInfo fcinfo);
extern Datum RI_FKey_noaction_del(FunctionCallInfo fcinfo);
extern Datum RI_FKey_noaction_upd(FunctionCallInfo fcinfo);
extern Datum RI_FKey_cascade_del(FunctionCallInfo fcinfo);
extern Datum RI_FKey_cascade_upd(FunctionCallInfo fcinfo);
extern Datum RI_FKey_restrict_del(FunctionCallInfo fcinfo);
extern Datum RI_FKey_restrict_upd(FunctionCallInfo fcinfo);
extern Datum RI_FKey_setnull_del(FunctionCallInfo fcinfo);
extern Datum RI_FKey_setnull_upd(FunctionCallInfo fcinfo);
extern Datum RI_FKey_setdefault_del(FunctionCallInfo fcinfo);
extern Datum RI_FKey_setdefault_upd(FunctionCallInfo fcinfo);


extern Datum suppress_redundant_updates_trigger(FunctionCallInfo fcinfo);


extern Datum getdatabaseencoding(FunctionCallInfo fcinfo);
extern Datum database_character_set(FunctionCallInfo fcinfo);
extern Datum pg_client_encoding(FunctionCallInfo fcinfo);
extern Datum PG_encoding_to_char(FunctionCallInfo fcinfo);
extern Datum PG_char_to_encoding(FunctionCallInfo fcinfo);
extern Datum PG_character_set_name(FunctionCallInfo fcinfo);
extern Datum PG_character_set_id(FunctionCallInfo fcinfo);
extern Datum pg_convert(FunctionCallInfo fcinfo);
extern Datum pg_convert_to(FunctionCallInfo fcinfo);
extern Datum pg_convert_from(FunctionCallInfo fcinfo);
extern Datum length_in_encoding(FunctionCallInfo fcinfo);
extern Datum pg_encoding_max_length_sql(FunctionCallInfo fcinfo);


extern Datum format_type(FunctionCallInfo fcinfo);
extern char *format_type_be(Oid type_oid);
extern char *format_type_with_typemod(Oid type_oid, int32 typemod);
extern Datum oidvectortypes(FunctionCallInfo fcinfo);
extern int32 type_maximum_size(Oid type_oid, int32 typemod);


extern Datum quote_ident(FunctionCallInfo fcinfo);
extern Datum quote_literal(FunctionCallInfo fcinfo);
extern char *quote_literal_cstr(const char *rawstr);
extern Datum quote_nullable(FunctionCallInfo fcinfo);


extern Datum show_config_by_name(FunctionCallInfo fcinfo);
extern Datum set_config_by_name(FunctionCallInfo fcinfo);
extern Datum show_all_settings(FunctionCallInfo fcinfo);


extern Datum pg_lock_status(FunctionCallInfo fcinfo);
extern Datum pg_advisory_lock_int8(FunctionCallInfo fcinfo);
extern Datum pg_advisory_xact_lock_int8(FunctionCallInfo fcinfo);
extern Datum pg_advisory_lock_shared_int8(FunctionCallInfo fcinfo);
extern Datum pg_advisory_xact_lock_shared_int8(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_lock_int8(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_xact_lock_int8(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_lock_shared_int8(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_xact_lock_shared_int8(FunctionCallInfo fcinfo);
extern Datum pg_advisory_unlock_int8(FunctionCallInfo fcinfo);
extern Datum pg_advisory_unlock_shared_int8(FunctionCallInfo fcinfo);
extern Datum pg_advisory_lock_int4(FunctionCallInfo fcinfo);
extern Datum pg_advisory_xact_lock_int4(FunctionCallInfo fcinfo);
extern Datum pg_advisory_lock_shared_int4(FunctionCallInfo fcinfo);
extern Datum pg_advisory_xact_lock_shared_int4(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_lock_int4(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_xact_lock_int4(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_lock_shared_int4(FunctionCallInfo fcinfo);
extern Datum pg_try_advisory_xact_lock_shared_int4(FunctionCallInfo fcinfo);
extern Datum pg_advisory_unlock_int4(FunctionCallInfo fcinfo);
extern Datum pg_advisory_unlock_shared_int4(FunctionCallInfo fcinfo);
extern Datum pg_advisory_unlock_all(FunctionCallInfo fcinfo);


extern Datum txid_snapshot_in(FunctionCallInfo fcinfo);
extern Datum txid_snapshot_out(FunctionCallInfo fcinfo);
extern Datum txid_snapshot_recv(FunctionCallInfo fcinfo);
extern Datum txid_snapshot_send(FunctionCallInfo fcinfo);
extern Datum txid_current(FunctionCallInfo fcinfo);
extern Datum txid_current_snapshot(FunctionCallInfo fcinfo);
extern Datum txid_snapshot_xmin(FunctionCallInfo fcinfo);
extern Datum txid_snapshot_xmax(FunctionCallInfo fcinfo);
extern Datum txid_snapshot_xip(FunctionCallInfo fcinfo);
extern Datum txid_visible_in_snapshot(FunctionCallInfo fcinfo);


extern Datum uuid_in(FunctionCallInfo fcinfo);
extern Datum uuid_out(FunctionCallInfo fcinfo);
extern Datum uuid_send(FunctionCallInfo fcinfo);
extern Datum uuid_recv(FunctionCallInfo fcinfo);
extern Datum uuid_lt(FunctionCallInfo fcinfo);
extern Datum uuid_le(FunctionCallInfo fcinfo);
extern Datum uuid_eq(FunctionCallInfo fcinfo);
extern Datum uuid_ge(FunctionCallInfo fcinfo);
extern Datum uuid_gt(FunctionCallInfo fcinfo);
extern Datum uuid_ne(FunctionCallInfo fcinfo);
extern Datum uuid_cmp(FunctionCallInfo fcinfo);
extern Datum uuid_hash(FunctionCallInfo fcinfo);


extern Datum window_row_number(FunctionCallInfo fcinfo);
extern Datum window_rank(FunctionCallInfo fcinfo);
extern Datum window_dense_rank(FunctionCallInfo fcinfo);
extern Datum window_percent_rank(FunctionCallInfo fcinfo);
extern Datum window_cume_dist(FunctionCallInfo fcinfo);
extern Datum window_ntile(FunctionCallInfo fcinfo);
extern Datum window_lag(FunctionCallInfo fcinfo);
extern Datum window_lag_with_offset(FunctionCallInfo fcinfo);
extern Datum window_lag_with_offset_and_default(FunctionCallInfo fcinfo);
extern Datum window_lead(FunctionCallInfo fcinfo);
extern Datum window_lead_with_offset(FunctionCallInfo fcinfo);
extern Datum window_lead_with_offset_and_default(FunctionCallInfo fcinfo);
extern Datum window_first_value(FunctionCallInfo fcinfo);
extern Datum window_last_value(FunctionCallInfo fcinfo);
extern Datum window_nth_value(FunctionCallInfo fcinfo);


extern Datum spg_quad_config(FunctionCallInfo fcinfo);
extern Datum spg_quad_choose(FunctionCallInfo fcinfo);
extern Datum spg_quad_picksplit(FunctionCallInfo fcinfo);
extern Datum spg_quad_inner_consistent(FunctionCallInfo fcinfo);
extern Datum spg_quad_leaf_consistent(FunctionCallInfo fcinfo);


extern Datum spg_kd_config(FunctionCallInfo fcinfo);
extern Datum spg_kd_choose(FunctionCallInfo fcinfo);
extern Datum spg_kd_picksplit(FunctionCallInfo fcinfo);
extern Datum spg_kd_inner_consistent(FunctionCallInfo fcinfo);


extern Datum spg_text_config(FunctionCallInfo fcinfo);
extern Datum spg_text_choose(FunctionCallInfo fcinfo);
extern Datum spg_text_picksplit(FunctionCallInfo fcinfo);
extern Datum spg_text_inner_consistent(FunctionCallInfo fcinfo);
extern Datum spg_text_leaf_consistent(FunctionCallInfo fcinfo);


extern Datum ginarrayextract(FunctionCallInfo fcinfo);
extern Datum ginarrayextract_2args(FunctionCallInfo fcinfo);
extern Datum ginqueryarrayextract(FunctionCallInfo fcinfo);
extern Datum ginarrayconsistent(FunctionCallInfo fcinfo);


extern Datum pg_prepared_xact(FunctionCallInfo fcinfo);


extern Datum pg_describe_object(FunctionCallInfo fcinfo);


extern Datum unique_key_recheck(FunctionCallInfo fcinfo);


extern Datum pg_available_extensions(FunctionCallInfo fcinfo);
extern Datum pg_available_extension_versions(FunctionCallInfo fcinfo);
extern Datum pg_extension_update_paths(FunctionCallInfo fcinfo);
extern Datum pg_extension_config_dump(FunctionCallInfo fcinfo);


extern Datum pg_prepared_statement(FunctionCallInfo fcinfo);


extern Datum pg_cursor(FunctionCallInfo fcinfo);
# 69 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/bytea.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/bytea.h"
typedef enum
{
 BYTEA_OUTPUT_ESCAPE,
 BYTEA_OUTPUT_HEX
} ByteaOutputType;

extern int bytea_output;


extern Datum byteain(FunctionCallInfo fcinfo);
extern Datum byteaout(FunctionCallInfo fcinfo);
extern Datum bytearecv(FunctionCallInfo fcinfo);
extern Datum byteasend(FunctionCallInfo fcinfo);
extern Datum byteaoctetlen(FunctionCallInfo fcinfo);
extern Datum byteaGetByte(FunctionCallInfo fcinfo);
extern Datum byteaGetBit(FunctionCallInfo fcinfo);
extern Datum byteaSetByte(FunctionCallInfo fcinfo);
extern Datum byteaSetBit(FunctionCallInfo fcinfo);
extern Datum byteaeq(FunctionCallInfo fcinfo);
extern Datum byteane(FunctionCallInfo fcinfo);
extern Datum bytealt(FunctionCallInfo fcinfo);
extern Datum byteale(FunctionCallInfo fcinfo);
extern Datum byteagt(FunctionCallInfo fcinfo);
extern Datum byteage(FunctionCallInfo fcinfo);
extern Datum byteacmp(FunctionCallInfo fcinfo);
extern Datum byteacat(FunctionCallInfo fcinfo);
extern Datum byteapos(FunctionCallInfo fcinfo);
extern Datum bytea_substr(FunctionCallInfo fcinfo);
extern Datum bytea_substr_no_len(FunctionCallInfo fcinfo);
extern Datum byteaoverlay(FunctionCallInfo fcinfo);
extern Datum byteaoverlay_no_len(FunctionCallInfo fcinfo);
# 70 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc_tables.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc_tables.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc_tables.h" 2




enum config_type
{
 PGC_BOOL,
 PGC_INT,
 PGC_REAL,
 PGC_STRING,
 PGC_ENUM
};

union config_var_val
{
 bool boolval;
 int intval;
 double realval;
 char *stringval;
 int enumval;
};





typedef struct config_var_value
{
 union config_var_val val;
 void *extra;
} config_var_value;




enum config_group
{
 UNGROUPED,
 FILE_LOCATIONS,
 CONN_AUTH,
 CONN_AUTH_SETTINGS,
 CONN_AUTH_SECURITY,
 RESOURCES,
 RESOURCES_MEM,
 RESOURCES_DISK,
 RESOURCES_KERNEL,
 RESOURCES_VACUUM_DELAY,
 RESOURCES_BGWRITER,
 RESOURCES_ASYNCHRONOUS,
 WAL,
 WAL_SETTINGS,
 WAL_CHECKPOINTS,
 WAL_ARCHIVING,
 REPLICATION,
 REPLICATION_SENDING,
 REPLICATION_MASTER,
 REPLICATION_STANDBY,
 QUERY_TUNING,
 QUERY_TUNING_METHOD,
 QUERY_TUNING_COST,
 QUERY_TUNING_GEQO,
 QUERY_TUNING_OTHER,
 LOGGING,
 LOGGING_WHERE,
 LOGGING_WHEN,
 LOGGING_WHAT,
 STATS,
 STATS_MONITORING,
 STATS_COLLECTOR,
 AUTOVACUUM,
 CLIENT_CONN,
 CLIENT_CONN_STATEMENT,
 CLIENT_CONN_LOCALE,
 CLIENT_CONN_OTHER,
 LOCK_MANAGEMENT,
 COMPAT_OPTIONS,
 COMPAT_OPTIONS_PREVIOUS,
 COMPAT_OPTIONS_CLIENT,
 ERROR_HANDLING_OPTIONS,
 PRESET_OPTIONS,
 CUSTOM_OPTIONS,
 DEVELOPER_OPTIONS
};





typedef enum
{

 GUC_SAVE,
 GUC_SET,
 GUC_LOCAL,
 GUC_SET_LOCAL
} GucStackState;

typedef struct guc_stack
{
 struct guc_stack *prev;
 int nest_level;
 GucStackState state;
 GucSource source;

 GucContext scontext;
 GucContext masked_scontext;
 config_var_value prior;
 config_var_value masked;
} GucStack;
# 140 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc_tables.h"
struct config_generic
{

 const char *name;
 GucContext context;
 enum config_group group;
 const char *short_desc;
 const char *long_desc;
 int flags;

 enum config_type vartype;
 int status;
 GucSource source;
 GucSource reset_source;
 GucContext scontext;
 GucContext reset_scontext;
 GucStack *stack;
 void *extra;
 char *sourcefile;

 int sourceline;
};
# 173 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc_tables.h"
struct config_bool
{
 struct config_generic gen;

 bool *variable;
 bool boot_val;
 GucBoolCheckHook check_hook;
 GucBoolAssignHook assign_hook;
 GucShowHook show_hook;

 bool reset_val;
 void *reset_extra;
};

struct config_int
{
 struct config_generic gen;

 int *variable;
 int boot_val;
 int min;
 int max;
 GucIntCheckHook check_hook;
 GucIntAssignHook assign_hook;
 GucShowHook show_hook;

 int reset_val;
 void *reset_extra;
};

struct config_real
{
 struct config_generic gen;

 double *variable;
 double boot_val;
 double min;
 double max;
 GucRealCheckHook check_hook;
 GucRealAssignHook assign_hook;
 GucShowHook show_hook;

 double reset_val;
 void *reset_extra;
};

struct config_string
{
 struct config_generic gen;

 char **variable;
 const char *boot_val;
 GucStringCheckHook check_hook;
 GucStringAssignHook assign_hook;
 GucShowHook show_hook;

 char *reset_val;
 void *reset_extra;
};

struct config_enum
{
 struct config_generic gen;

 int *variable;
 int boot_val;
 const struct config_enum_entry *options;
 GucEnumCheckHook check_hook;
 GucEnumAssignHook assign_hook;
 GucShowHook show_hook;

 int reset_val;
 void *reset_extra;
};


extern const char *const config_group_names[];
extern const char *const config_type_names[];
extern const char *const GucContext_Names[];
extern const char *const GucSource_Names[];


extern struct config_generic **get_guc_variables(void);

extern void build_guc_variables(void);


extern const char *config_enum_lookup_by_value(struct config_enum * record, int val);
extern bool config_enum_lookup_by_name(struct config_enum * record,
         const char *value, int *retval);
# 71 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/memnodes.h" 1
# 36 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/memnodes.h"
typedef struct MemoryContextMethods
{
 void *(*alloc) (MemoryContext context, Size size);

 void (*free_p) (MemoryContext context, void *pointer);
 void *(*realloc) (MemoryContext context, void *pointer, Size size);
 void (*init) (MemoryContext context);
 void (*reset) (MemoryContext context);
 void (*delete_context) (MemoryContext context);
 Size (*get_chunk_space) (MemoryContext context, void *pointer);
 bool (*is_empty) (MemoryContext context);
 void (*stats) (MemoryContext context, int level);



} MemoryContextMethods;


typedef struct MemoryContextData
{
 NodeTag type;
 MemoryContextMethods *methods;
 MemoryContext parent;
 MemoryContext firstchild;
 MemoryContext nextchild;
 char *name;
 bool isReset;
} MemoryContextData;
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h" 2
# 53 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h"
typedef struct StandardChunkHeader
{
 MemoryContext context;
 Size size;




} StandardChunkHeader;
# 72 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/memutils.h"
extern MemoryContext TopMemoryContext;
extern MemoryContext ErrorContext;
extern MemoryContext PostmasterContext;
extern MemoryContext CacheMemoryContext;
extern MemoryContext MessageContext;
extern MemoryContext TopTransactionContext;
extern MemoryContext CurTransactionContext;


extern MemoryContext PortalContext;





extern void MemoryContextInit(void);
extern void MemoryContextReset(MemoryContext context);
extern void MemoryContextDelete(MemoryContext context);
extern void MemoryContextResetChildren(MemoryContext context);
extern void MemoryContextDeleteChildren(MemoryContext context);
extern void MemoryContextResetAndDeleteChildren(MemoryContext context);
extern void MemoryContextSetParent(MemoryContext context,
        MemoryContext new_parent);
extern Size GetMemoryChunkSpace(void *pointer);
extern MemoryContext GetMemoryChunkContext(void *pointer);
extern MemoryContext MemoryContextGetParent(MemoryContext context);
extern bool MemoryContextIsEmpty(MemoryContext context);
extern void MemoryContextStats(MemoryContext context);




extern bool MemoryContextContains(MemoryContext context, void *pointer);






extern MemoryContext MemoryContextCreate(NodeTag tag, Size size,
     MemoryContextMethods *methods,
     MemoryContext parent,
     const char *name);







extern MemoryContext AllocSetContextCreate(MemoryContext parent,
       const char *name,
       Size minContextSize,
       Size initBlockSize,
       Size maxBlockSize);
# 72 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/pg_locale.h" 1
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/pg_locale.h"
# 1 "/usr/include/xlocale.h" 1 3 4
# 33 "/usr/include/xlocale.h" 3 4
struct _xlocale;
typedef struct _xlocale * locale_t;


# 1 "/usr/include/_xlocale.h" 1 3 4
# 29 "/usr/include/_xlocale.h" 3 4

int ___mb_cur_max(void);
int ___mb_cur_max_l(locale_t);

# 38 "/usr/include/xlocale.h" 2 3 4
# 65 "/usr/include/xlocale.h" 3 4

extern const locale_t _c_locale;

locale_t duplocale(locale_t);
int freelocale(locale_t);
struct lconv * localeconv_l(locale_t);
locale_t newlocale(int, const char *, locale_t);
const char * querylocale(int, locale_t);
locale_t uselocale(locale_t);



# 1 "/usr/include/xlocale/_ctype.h" 1 3 4
# 34 "/usr/include/xlocale/_ctype.h" 3 4

unsigned long ___runetype_l(__darwin_ct_rune_t, locale_t);
__darwin_ct_rune_t ___tolower_l(__darwin_ct_rune_t, locale_t);
__darwin_ct_rune_t ___toupper_l(__darwin_ct_rune_t, locale_t);



int __maskrune_l(__darwin_ct_rune_t, unsigned long, locale_t);


static __inline int
__istype_l(__darwin_ct_rune_t _c, unsigned long _f, locale_t _l)
{
 return !!(isascii(_c) ? (_DefaultRuneLocale.__runetype[_c] & _f)
  : __maskrune_l(_c, _f, _l));
}

static __inline __darwin_ct_rune_t
__toupper_l(__darwin_ct_rune_t _c, locale_t _l)
{
 return isascii(_c) ? _DefaultRuneLocale.__mapupper[_c]
  : ___toupper_l(_c, _l);
}

static __inline __darwin_ct_rune_t
__tolower_l(__darwin_ct_rune_t _c, locale_t _l)
{
 return isascii(_c) ? _DefaultRuneLocale.__maplower[_c]
  : ___tolower_l(_c, _l);
}

static __inline int
__wcwidth_l(__darwin_ct_rune_t _c, locale_t _l)
{
 unsigned int _x;

 if (_c == 0)
  return (0);
 _x = (unsigned int)__maskrune_l(_c, 0xe0000000L|0x00040000L, _l);
 if ((_x & 0xe0000000L) != 0)
  return ((_x & 0xe0000000L) >> 30);
 return ((_x & 0x00040000L) != 0 ? 1 : -1);
}



static __inline int
digittoint_l(int c, locale_t l)
{
 return (__maskrune_l(c, 0x0F, l));
}

static __inline int
isalnum_l(int c, locale_t l)
{
 return (__istype_l(c, 0x00000100L|0x00000400L, l));
}

static __inline int
isalpha_l(int c, locale_t l)
{
 return (__istype_l(c, 0x00000100L, l));
}

static __inline int
isblank_l(int c, locale_t l)
{
 return (__istype_l(c, 0x00020000L, l));
}

static __inline int
iscntrl_l(int c, locale_t l)
{
 return (__istype_l(c, 0x00000200L, l));
}

static __inline int
isdigit_l(int c, locale_t l)
{
 return (__istype_l(c, 0x00000400L, l));
}

static __inline int
isgraph_l(int c, locale_t l)
{
 return (__istype_l(c, 0x00000800L, l));
}

static __inline int
ishexnumber_l(int c, locale_t l)
{
 return (__istype_l(c, 0x00010000L, l));
}

static __inline int
isideogram_l(int c, locale_t l)
{
 return (__istype_l(c, 0x00080000L, l));
}

static __inline int
islower_l(int c, locale_t l)
{
 return (__istype_l(c, 0x00001000L, l));
}

static __inline int
isnumber_l(int c, locale_t l)
{
 return (__istype_l(c, 0x00000400L, l));
}

static __inline int
isphonogram_l(int c, locale_t l)
{
 return (__istype_l(c, 0x00200000L, l));
}

static __inline int
isprint_l(int c, locale_t l)
{
 return (__istype_l(c, 0x00040000L, l));
}

static __inline int
ispunct_l(int c, locale_t l)
{
 return (__istype_l(c, 0x00002000L, l));
}

static __inline int
isrune_l(int c, locale_t l)
{
 return (__istype_l(c, 0xFFFFFFF0L, l));
}

static __inline int
isspace_l(int c, locale_t l)
{
 return (__istype_l(c, 0x00004000L, l));
}

static __inline int
isspecial_l(int c, locale_t l)
{
 return (__istype_l(c, 0x00100000L, l));
}

static __inline int
isupper_l(int c, locale_t l)
{
 return (__istype_l(c, 0x00008000L, l));
}

static __inline int
isxdigit_l(int c, locale_t l)
{
 return (__istype_l(c, 0x00010000L, l));
}

static __inline int
tolower_l(int c, locale_t l)
{
        return (__tolower_l(c, l));
}

static __inline int
toupper_l(int c, locale_t l)
{
        return (__toupper_l(c, l));
}
# 78 "/usr/include/xlocale.h" 2 3 4
# 92 "/usr/include/xlocale.h" 3 4
# 1 "/usr/include/xlocale/_stdio.h" 1 3 4
# 27 "/usr/include/xlocale/_stdio.h" 3 4


int fprintf_l(FILE * , locale_t, const char * , ...)
        __attribute__((__format__ (__printf__, 3, 4)));
int fscanf_l(FILE * , locale_t, const char * , ...)
        __attribute__((__format__ (__scanf__, 3, 4)));
int printf_l(locale_t, const char * , ...)
        __attribute__((__format__ (__printf__, 2, 3)));
int scanf_l(locale_t, const char * , ...)
        __attribute__((__format__ (__scanf__, 2, 3)));
int sprintf_l(char * , locale_t, const char * , ...)
        __attribute__((__format__ (__printf__, 3, 4)));
int sscanf_l(const char * , locale_t, const char * , ...)
        __attribute__((__format__ (__scanf__, 3, 4)));
int vfprintf_l(FILE * , locale_t, const char * , va_list)
        __attribute__((__format__ (__printf__, 3, 0)));
int vprintf_l(locale_t, const char * , va_list)
        __attribute__((__format__ (__printf__, 2, 0)));
int vsprintf_l(char * , locale_t, const char * , va_list)
        __attribute__((__format__ (__printf__, 3, 0)));


int snprintf_l(char * , size_t, locale_t, const char * , ...)
        __attribute__((__format__ (__printf__, 4, 5)));
int vfscanf_l(FILE * , locale_t, const char * , va_list)
        __attribute__((__format__ (__scanf__, 3, 0)));
int vscanf_l(locale_t, const char * , va_list)
        __attribute__((__format__ (__scanf__, 2, 0)));
int vsnprintf_l(char * , size_t, locale_t, const char * , va_list)
        __attribute__((__format__ (__printf__, 4, 0)));
int vsscanf_l(const char * , locale_t, const char * , va_list)
        __attribute__((__format__ (__scanf__, 3, 0)));



int dprintf_l(int, locale_t, const char * , ...)
  __attribute__((__format__ (__printf__, 3, 4))) __attribute__((visibility("default")));
int vdprintf_l(int, locale_t, const char * , va_list)
        __attribute__((__format__ (__printf__, 3, 0))) __attribute__((visibility("default")));




int asprintf_l(char **, locale_t, const char *, ...)
        __attribute__((__format__ (__printf__, 3, 4)));
int vasprintf_l(char **, locale_t, const char *, va_list)
        __attribute__((__format__ (__printf__, 3, 0)));



# 93 "/usr/include/xlocale.h" 2 3 4


# 1 "/usr/include/xlocale/_stdlib.h" 1 3 4
# 27 "/usr/include/xlocale/_stdlib.h" 3 4

double atof_l(const char *, locale_t);
int atoi_l(const char *, locale_t);
long atol_l(const char *, locale_t);

long long
  atoll_l(const char *, locale_t);

int mblen_l(const char *, size_t, locale_t);
size_t mbstowcs_l(wchar_t * , const char * , size_t,
     locale_t);
int mbtowc_l(wchar_t * , const char * , size_t,
     locale_t);
double strtod_l(const char *, char **, locale_t) __asm("_" "strtod_l" );
float strtof_l(const char *, char **, locale_t) __asm("_" "strtof_l" );
long strtol_l(const char *, char **, int, locale_t);
long double
  strtold_l(const char *, char **, locale_t)
      ;
long long
  strtoll_l(const char *, char **, int, locale_t);

long long
  strtoq_l(const char *, char **, int, locale_t);

unsigned long
  strtoul_l(const char *, char **, int, locale_t);
unsigned long long
  strtoull_l(const char *, char **, int, locale_t);

unsigned long long
  strtouq_l(const char *, char **, int, locale_t);

size_t wcstombs_l(char * , const wchar_t * , size_t,
     locale_t);
int wctomb_l(char *, wchar_t, locale_t);






# 96 "/usr/include/xlocale.h" 2 3 4


# 1 "/usr/include/xlocale/_string.h" 1 3 4
# 27 "/usr/include/xlocale/_string.h" 3 4

int strcoll_l(const char *, const char *, locale_t);
size_t strxfrm_l(char *, const char *, size_t, locale_t);
int strcasecmp_l(const char *, const char *, locale_t);
char *strcasestr_l(const char *, const char *, locale_t);
int strncasecmp_l(const char *, const char *, size_t, locale_t);

# 99 "/usr/include/xlocale.h" 2 3 4
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/pg_locale.h" 2






extern char *locale_messages;
extern char *locale_monetary;
extern char *locale_numeric;
extern char *locale_time;


extern char *localized_abbrev_days[];
extern char *localized_full_days[];
extern char *localized_abbrev_months[];
extern char *localized_full_months[];


extern bool check_locale_messages(char **newval, void **extra, GucSource source);
extern void assign_locale_messages(const char *newval, void *extra);
extern bool check_locale_monetary(char **newval, void **extra, GucSource source);
extern void assign_locale_monetary(const char *newval, void *extra);
extern bool check_locale_numeric(char **newval, void **extra, GucSource source);
extern void assign_locale_numeric(const char *newval, void *extra);
extern bool check_locale_time(char **newval, void **extra, GucSource source);
extern void assign_locale_time(const char *newval, void *extra);

extern bool check_locale(int category, const char *locale, char **canonname);
extern char *pg_perm_setlocale(int category, const char *locale);

extern bool lc_collate_is_c(Oid collation);
extern bool lc_ctype_is_c(Oid collation);





extern struct lconv *PGLC_localeconv(void);

extern void cache_locale_time(void);
# 68 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/pg_locale.h"
typedef locale_t pg_locale_t;




extern pg_locale_t pg_newlocale_from_collation(Oid collid);



extern size_t wchar2char(char *to, const wchar_t *from, size_t tolen,
     pg_locale_t locale);
extern size_t char2wchar(wchar_t *to, size_t tolen,
     const char *from, size_t fromlen, pg_locale_t locale);
# 73 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/plancache.h" 1
# 74 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/portal.h" 1
# 49 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/portal.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/datatype/timestamp.h" 1
# 50 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/portal.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/executor/execdesc.h" 1
# 51 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/portal.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/resowner.h" 1
# 22 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/resowner.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/storage/fd.h" 1
# 23 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/resowner.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/access/skey.h" 1
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/dllist.h" 1
# 45 "/Users/parrt/tmp/postgresql-9.2.4/src/include/lib/dllist.h"
struct Dllist;
struct Dlelem;

typedef struct Dlelem
{
 struct Dlelem *dle_next;
 struct Dlelem *dle_prev;
 void *dle_val;
 struct Dllist *dle_list;
} Dlelem;

typedef struct Dllist
{
 Dlelem *dll_head;
 Dlelem *dll_tail;
} Dllist;

extern Dllist *DLNewList(void);
extern void DLInitList(Dllist *list);
extern void DLFreeList(Dllist *list);

extern Dlelem *DLNewElem(void *val);
extern void DLInitElem(Dlelem *e, void *val);
extern void DLFreeElem(Dlelem *e);
extern void DLRemove(Dlelem *e);
extern void DLAddHead(Dllist *list, Dlelem *node);
extern void DLAddTail(Dllist *list, Dlelem *node);
extern Dlelem *DLRemHead(Dllist *list);
extern Dlelem *DLRemTail(Dllist *list);
extern void DLMoveToFront(Dlelem *e);
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/relcache.h" 1
# 27 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h" 2
# 37 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h"
typedef struct catcache
{
 int id;
 struct catcache *cc_next;
 const char *cc_relname;
 Oid cc_reloid;
 Oid cc_indexoid;
 bool cc_relisshared;
 TupleDesc cc_tupdesc;
 int cc_ntup;
 int cc_nbuckets;
 int cc_nkeys;
 int cc_key[4];
 PGFunction cc_hashfunc[4];
 ScanKeyData cc_skey[4];

 bool cc_isname[4];
 Dllist cc_lists;
# 69 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h"
 Dllist cc_bucket[1];
} CatCache;


typedef struct catctup
{
 int ct_magic;

 CatCache *my_cache;






 Dlelem cache_elem;
# 93 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h"
 struct catclist *c_list;
# 107 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h"
 int refcount;
 bool dead;
 bool negative;
 uint32 hash_value;
 HeapTupleData tuple;
} CatCTup;


typedef struct catclist
{
 int cl_magic;

 CatCache *my_cache;
# 142 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/catcache.h"
 Dlelem cache_elem;
 int refcount;
 bool dead;
 bool ordered;
 short nkeys;
 uint32 hash_value;
 HeapTupleData tuple;
 int n_members;
 CatCTup *members[1];
} CatCList;


typedef struct catcacheheader
{
 CatCache *ch_caches;
 int ch_ntup;
} CatCacheHeader;



extern MemoryContext CacheMemoryContext;

extern void CreateCacheMemoryContext(void);
extern void AtEOXact_CatCache(bool isCommit);

extern CatCache *InitCatCache(int id, Oid reloid, Oid indexoid,
    int nkeys, const int *key,
    int nbuckets);
extern void InitCatCachePhase2(CatCache *cache, bool touch_index);

extern HeapTuple SearchCatCache(CatCache *cache,
      Datum v1, Datum v2,
      Datum v3, Datum v4);
extern void ReleaseCatCache(HeapTuple tuple);

extern uint32 GetCatCacheHashValue(CatCache *cache,
      Datum v1, Datum v2,
      Datum v3, Datum v4);

extern CatCList *SearchCatCacheList(CatCache *cache, int nkeys,
       Datum v1, Datum v2,
       Datum v3, Datum v4);
extern void ReleaseCatCacheList(CatCList *list);

extern void ResetCatalogCaches(void);
extern void CatalogCacheFlushCatalog(Oid catId);
extern void CatalogCacheIdInvalidate(int cacheId, uint32 hashValue);
extern void PrepareToInvalidateCacheTuple(Relation relation,
         HeapTuple tuple,
         HeapTuple newtuple,
         void (*function) (int, uint32, Oid));

extern void PrintCatCacheLeakWarning(HeapTuple tuple);
extern void PrintCatCacheListLeakWarning(CatCList *list);
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/resowner.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/plancache.h" 1
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/resowner.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapshot.h" 1
# 26 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/resowner.h" 2






typedef struct ResourceOwnerData *ResourceOwner;





extern ResourceOwner CurrentResourceOwner;
extern ResourceOwner CurTransactionResourceOwner;
extern ResourceOwner TopTransactionResourceOwner;
# 50 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/resowner.h"
typedef enum
{
 RESOURCE_RELEASE_BEFORE_LOCKS,
 RESOURCE_RELEASE_LOCKS,
 RESOURCE_RELEASE_AFTER_LOCKS
} ResourceReleasePhase;





typedef void (*ResourceReleaseCallback) (ResourceReleasePhase phase,
              bool isCommit,
              bool isTopLevel,
              void *arg);







extern ResourceOwner ResourceOwnerCreate(ResourceOwner parent,
     const char *name);
extern void ResourceOwnerRelease(ResourceOwner owner,
      ResourceReleasePhase phase,
      bool isCommit,
      bool isTopLevel);
extern void ResourceOwnerDelete(ResourceOwner owner);
extern ResourceOwner ResourceOwnerGetParent(ResourceOwner owner);
extern void ResourceOwnerNewParent(ResourceOwner owner,
        ResourceOwner newparent);
extern void RegisterResourceReleaseCallback(ResourceReleaseCallback callback,
        void *arg);
extern void UnregisterResourceReleaseCallback(ResourceReleaseCallback callback,
          void *arg);


extern void ResourceOwnerEnlargeBuffers(ResourceOwner owner);
extern void ResourceOwnerRememberBuffer(ResourceOwner owner, Buffer buffer);
extern void ResourceOwnerForgetBuffer(ResourceOwner owner, Buffer buffer);


extern void ResourceOwnerEnlargeCatCacheRefs(ResourceOwner owner);
extern void ResourceOwnerRememberCatCacheRef(ResourceOwner owner,
         HeapTuple tuple);
extern void ResourceOwnerForgetCatCacheRef(ResourceOwner owner,
          HeapTuple tuple);
extern void ResourceOwnerEnlargeCatCacheListRefs(ResourceOwner owner);
extern void ResourceOwnerRememberCatCacheListRef(ResourceOwner owner,
          CatCList *list);
extern void ResourceOwnerForgetCatCacheListRef(ResourceOwner owner,
           CatCList *list);


extern void ResourceOwnerEnlargeRelationRefs(ResourceOwner owner);
extern void ResourceOwnerRememberRelationRef(ResourceOwner owner,
         Relation rel);
extern void ResourceOwnerForgetRelationRef(ResourceOwner owner,
          Relation rel);


extern void ResourceOwnerEnlargePlanCacheRefs(ResourceOwner owner);
extern void ResourceOwnerRememberPlanCacheRef(ResourceOwner owner,
          CachedPlan *plan);
extern void ResourceOwnerForgetPlanCacheRef(ResourceOwner owner,
        CachedPlan *plan);


extern void ResourceOwnerEnlargeTupleDescs(ResourceOwner owner);
extern void ResourceOwnerRememberTupleDesc(ResourceOwner owner,
          TupleDesc tupdesc);
extern void ResourceOwnerForgetTupleDesc(ResourceOwner owner,
        TupleDesc tupdesc);


extern void ResourceOwnerEnlargeSnapshots(ResourceOwner owner);
extern void ResourceOwnerRememberSnapshot(ResourceOwner owner,
         Snapshot snapshot);
extern void ResourceOwnerForgetSnapshot(ResourceOwner owner,
       Snapshot snapshot);


extern void ResourceOwnerEnlargeFiles(ResourceOwner owner);
extern void ResourceOwnerRememberFile(ResourceOwner owner,
        File file);
extern void ResourceOwnerForgetFile(ResourceOwner owner,
      File file);
# 52 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/portal.h" 2
# 87 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/portal.h"
typedef enum PortalStrategy
{
 PORTAL_ONE_SELECT,
 PORTAL_ONE_RETURNING,
 PORTAL_ONE_MOD_WITH,
 PORTAL_UTIL_SELECT,
 PORTAL_MULTI_QUERY
} PortalStrategy;






typedef enum PortalStatus
{
 PORTAL_NEW,
 PORTAL_DEFINED,
 PORTAL_READY,
 PORTAL_ACTIVE,
 PORTAL_DONE,
 PORTAL_FAILED
} PortalStatus;

typedef struct PortalData *Portal;

typedef struct PortalData
{

 const char *name;
 const char *prepStmtName;
 MemoryContext heap;
 ResourceOwner resowner;
 void (*cleanup) (Portal portal);
 SubTransactionId createSubid;







 const char *sourceText;
 const char *commandTag;
 List *stmts;
 CachedPlan *cplan;

 ParamListInfo portalParams;


 PortalStrategy strategy;
 int cursorOptions;


 PortalStatus status;
 bool portalPinned;


 QueryDesc *queryDesc;


 TupleDesc tupDesc;

 int16 *formats;






 Tuplestorestate *holdStore;
 MemoryContext holdContext;
# 169 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/portal.h"
 bool atStart;
 bool atEnd;
 bool posOverflow;
 long portalPos;


 TimestampTz creation_time;
 bool visible;
} PortalData;
# 194 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/portal.h"
extern void EnablePortalManager(void);
extern bool PreCommit_Portals(bool isPrepare);
extern void AtAbort_Portals(void);
extern void AtCleanup_Portals(void);
extern void AtSubCommit_Portals(SubTransactionId mySubid,
     SubTransactionId parentSubid,
     ResourceOwner parentXactOwner);
extern void AtSubAbort_Portals(SubTransactionId mySubid,
       SubTransactionId parentSubid,
       ResourceOwner parentXactOwner);
extern void AtSubCleanup_Portals(SubTransactionId mySubid);
extern Portal CreatePortal(const char *name, bool allowDup, bool dupSilent);
extern Portal CreateNewPortal(void);
extern void PinPortal(Portal portal);
extern void UnpinPortal(Portal portal);
extern void MarkPortalDone(Portal portal);
extern void MarkPortalFailed(Portal portal);
extern void PortalDrop(Portal portal, bool isTopCommit);
extern Portal GetPortalByName(const char *name);
extern void PortalDefineQuery(Portal portal,
      const char *prepStmtName,
      const char *sourceText,
      const char *commandTag,
      List *stmts,
      CachedPlan *cplan);
extern Node *PortalListGetPrimaryStmt(List *stmts);
extern void PortalCreateHoldStore(Portal portal);
extern void PortalHashTableDeleteAll(void);
# 75 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/ps_status.h" 1
# 15 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/ps_status.h"
extern bool update_process_title;

extern char **save_ps_display_args(int argc, char **argv);

extern void init_ps_display(const char *username, const char *dbname,
    const char *host_info, const char *initial_str);

extern void set_ps_display(const char *activity, bool force);

extern const char *get_ps_display(int *displen);
# 76 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapmgr.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/snapmgr.h"
extern bool FirstSnapshotSet;

extern TransactionId TransactionXmin;
extern TransactionId RecentXmin;
extern TransactionId RecentGlobalXmin;

extern Snapshot GetTransactionSnapshot(void);
extern Snapshot GetLatestSnapshot(void);
extern void SnapshotSetCommandId(CommandId curcid);

extern void PushActiveSnapshot(Snapshot snapshot);
extern void PushCopiedSnapshot(Snapshot snapshot);
extern void UpdateActiveSnapshotCommandId(void);
extern void PopActiveSnapshot(void);
extern Snapshot GetActiveSnapshot(void);
extern bool ActiveSnapshotSet(void);

extern Snapshot RegisterSnapshot(Snapshot snapshot);
extern void UnregisterSnapshot(Snapshot snapshot);
extern Snapshot RegisterSnapshotOnOwner(Snapshot snapshot, ResourceOwner owner);
extern void UnregisterSnapshotFromOwner(Snapshot snapshot, ResourceOwner owner);

extern void AtSubCommit_Snapshot(int level);
extern void AtSubAbort_Snapshot(int level);
extern void AtEOXact_Snapshot(bool isCommit);

extern Datum pg_export_snapshot(FunctionCallInfo fcinfo);
extern void ImportSnapshot(const char *idstr);
extern bool XactHasExportedSnapshots(void);
extern void DeleteAllExportedSnapshotFiles(void);
# 77 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/tzparser.h" 1
# 16 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/tzparser.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/datetime.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/datetime.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/nodes.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/datetime.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/timestamp.h" 1
# 18 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/timestamp.h"
# 1 "./pgtime.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/timestamp.h" 2
# 85 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/timestamp.h"
extern TimestampTz PgStartTime;


extern TimestampTz PgReloadTime;






extern Datum timestamp_in(FunctionCallInfo fcinfo);
extern Datum timestamp_out(FunctionCallInfo fcinfo);
extern Datum timestamp_recv(FunctionCallInfo fcinfo);
extern Datum timestamp_send(FunctionCallInfo fcinfo);
extern Datum timestamptypmodin(FunctionCallInfo fcinfo);
extern Datum timestamptypmodout(FunctionCallInfo fcinfo);
extern Datum timestamp_transform(FunctionCallInfo fcinfo);
extern Datum timestamp_scale(FunctionCallInfo fcinfo);
extern Datum timestamp_eq(FunctionCallInfo fcinfo);
extern Datum timestamp_ne(FunctionCallInfo fcinfo);
extern Datum timestamp_lt(FunctionCallInfo fcinfo);
extern Datum timestamp_le(FunctionCallInfo fcinfo);
extern Datum timestamp_ge(FunctionCallInfo fcinfo);
extern Datum timestamp_gt(FunctionCallInfo fcinfo);
extern Datum timestamp_finite(FunctionCallInfo fcinfo);
extern Datum timestamp_cmp(FunctionCallInfo fcinfo);
extern Datum timestamp_sortsupport(FunctionCallInfo fcinfo);
extern Datum timestamp_hash(FunctionCallInfo fcinfo);
extern Datum timestamp_smaller(FunctionCallInfo fcinfo);
extern Datum timestamp_larger(FunctionCallInfo fcinfo);

extern Datum timestamp_eq_timestamptz(FunctionCallInfo fcinfo);
extern Datum timestamp_ne_timestamptz(FunctionCallInfo fcinfo);
extern Datum timestamp_lt_timestamptz(FunctionCallInfo fcinfo);
extern Datum timestamp_le_timestamptz(FunctionCallInfo fcinfo);
extern Datum timestamp_gt_timestamptz(FunctionCallInfo fcinfo);
extern Datum timestamp_ge_timestamptz(FunctionCallInfo fcinfo);
extern Datum timestamp_cmp_timestamptz(FunctionCallInfo fcinfo);

extern Datum timestamptz_eq_timestamp(FunctionCallInfo fcinfo);
extern Datum timestamptz_ne_timestamp(FunctionCallInfo fcinfo);
extern Datum timestamptz_lt_timestamp(FunctionCallInfo fcinfo);
extern Datum timestamptz_le_timestamp(FunctionCallInfo fcinfo);
extern Datum timestamptz_gt_timestamp(FunctionCallInfo fcinfo);
extern Datum timestamptz_ge_timestamp(FunctionCallInfo fcinfo);
extern Datum timestamptz_cmp_timestamp(FunctionCallInfo fcinfo);

extern Datum interval_in(FunctionCallInfo fcinfo);
extern Datum interval_out(FunctionCallInfo fcinfo);
extern Datum interval_recv(FunctionCallInfo fcinfo);
extern Datum interval_send(FunctionCallInfo fcinfo);
extern Datum intervaltypmodin(FunctionCallInfo fcinfo);
extern Datum intervaltypmodout(FunctionCallInfo fcinfo);
extern Datum interval_transform(FunctionCallInfo fcinfo);
extern Datum interval_scale(FunctionCallInfo fcinfo);
extern Datum interval_eq(FunctionCallInfo fcinfo);
extern Datum interval_ne(FunctionCallInfo fcinfo);
extern Datum interval_lt(FunctionCallInfo fcinfo);
extern Datum interval_le(FunctionCallInfo fcinfo);
extern Datum interval_ge(FunctionCallInfo fcinfo);
extern Datum interval_gt(FunctionCallInfo fcinfo);
extern Datum interval_finite(FunctionCallInfo fcinfo);
extern Datum interval_cmp(FunctionCallInfo fcinfo);
extern Datum interval_hash(FunctionCallInfo fcinfo);
extern Datum interval_smaller(FunctionCallInfo fcinfo);
extern Datum interval_larger(FunctionCallInfo fcinfo);
extern Datum interval_justify_interval(FunctionCallInfo fcinfo);
extern Datum interval_justify_hours(FunctionCallInfo fcinfo);
extern Datum interval_justify_days(FunctionCallInfo fcinfo);

extern Datum timestamp_trunc(FunctionCallInfo fcinfo);
extern Datum interval_trunc(FunctionCallInfo fcinfo);
extern Datum timestamp_part(FunctionCallInfo fcinfo);
extern Datum interval_part(FunctionCallInfo fcinfo);
extern Datum timestamp_zone(FunctionCallInfo fcinfo);
extern Datum timestamp_izone(FunctionCallInfo fcinfo);
extern Datum timestamp_timestamptz(FunctionCallInfo fcinfo);

extern Datum timestamptz_in(FunctionCallInfo fcinfo);
extern Datum timestamptz_out(FunctionCallInfo fcinfo);
extern Datum timestamptz_recv(FunctionCallInfo fcinfo);
extern Datum timestamptz_send(FunctionCallInfo fcinfo);
extern Datum timestamptztypmodin(FunctionCallInfo fcinfo);
extern Datum timestamptztypmodout(FunctionCallInfo fcinfo);
extern Datum timestamptz_scale(FunctionCallInfo fcinfo);
extern Datum timestamptz_timestamp(FunctionCallInfo fcinfo);
extern Datum timestamptz_zone(FunctionCallInfo fcinfo);
extern Datum timestamptz_izone(FunctionCallInfo fcinfo);
extern Datum timestamptz_timestamptz(FunctionCallInfo fcinfo);

extern Datum interval_um(FunctionCallInfo fcinfo);
extern Datum interval_pl(FunctionCallInfo fcinfo);
extern Datum interval_mi(FunctionCallInfo fcinfo);
extern Datum interval_mul(FunctionCallInfo fcinfo);
extern Datum mul_d_interval(FunctionCallInfo fcinfo);
extern Datum interval_div(FunctionCallInfo fcinfo);
extern Datum interval_accum(FunctionCallInfo fcinfo);
extern Datum interval_avg(FunctionCallInfo fcinfo);

extern Datum timestamp_mi(FunctionCallInfo fcinfo);
extern Datum timestamp_pl_interval(FunctionCallInfo fcinfo);
extern Datum timestamp_mi_interval(FunctionCallInfo fcinfo);
extern Datum timestamp_age(FunctionCallInfo fcinfo);
extern Datum overlaps_timestamp(FunctionCallInfo fcinfo);

extern Datum timestamptz_pl_interval(FunctionCallInfo fcinfo);
extern Datum timestamptz_mi_interval(FunctionCallInfo fcinfo);
extern Datum timestamptz_age(FunctionCallInfo fcinfo);
extern Datum timestamptz_trunc(FunctionCallInfo fcinfo);
extern Datum timestamptz_part(FunctionCallInfo fcinfo);

extern Datum now(FunctionCallInfo fcinfo);
extern Datum statement_timestamp(FunctionCallInfo fcinfo);
extern Datum clock_timestamp(FunctionCallInfo fcinfo);

extern Datum pg_postmaster_start_time(FunctionCallInfo fcinfo);
extern Datum pg_conf_load_time(FunctionCallInfo fcinfo);

extern Datum generate_series_timestamp(FunctionCallInfo fcinfo);
extern Datum generate_series_timestamptz(FunctionCallInfo fcinfo);



extern TimestampTz GetCurrentTimestamp(void);

extern void TimestampDifference(TimestampTz start_time, TimestampTz stop_time,
     long *secs, int *microsecs);
extern bool TimestampDifferenceExceeds(TimestampTz start_time,
         TimestampTz stop_time,
         int msec);

extern TimestampTz time_t_to_timestamptz(pg_time_t tm);
extern pg_time_t timestamptz_to_time_t(TimestampTz t);

extern const char *timestamptz_to_str(TimestampTz t);

extern int tm2timestamp(struct pg_tm * tm, fsec_t fsec, int *tzp, Timestamp *dt);
extern int timestamp2tm(Timestamp dt, int *tzp, struct pg_tm * tm,
    fsec_t *fsec, const char **tzn, pg_tz *attimezone);
extern void dt2time(Timestamp dt, int *hour, int *min, int *sec, fsec_t *fsec);

extern int interval2tm(Interval span, struct pg_tm * tm, fsec_t *fsec);
extern int tm2interval(struct pg_tm * tm, fsec_t fsec, Interval *span);

extern Timestamp SetEpochTimestamp(void);
extern void GetEpochTime(struct pg_tm * tm);

extern int timestamp_cmp_internal(Timestamp dt1, Timestamp dt2);




extern int isoweek2j(int year, int week);
extern void isoweek2date(int woy, int *year, int *mon, int *mday);
extern void isoweekdate2date(int isoweek, int isowday, int *year, int *mon, int *mday);
extern int date2isoweek(int year, int mon, int mday);
extern int date2isoyear(int year, int mon, int mday);
extern int date2isoyearday(int year, int mon, int mday);
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/datetime.h" 2


struct tzEntry;
# 199 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/datetime.h"
typedef struct
{
 char token[10];
 char type;
 char value;
} datetkn;


typedef struct TimeZoneAbbrevTable
{
 int numabbrevs;
 datetkn abbrevs[1];
} TimeZoneAbbrevTable;
# 250 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/datetime.h"
extern const int day_tab[2][13];
# 268 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/datetime.h"
extern void GetCurrentDateTime(struct pg_tm * tm);
extern void GetCurrentTimeUsec(struct pg_tm * tm, fsec_t *fsec, int *tzp);
extern void j2date(int jd, int *year, int *month, int *day);
extern int date2j(int year, int month, int day);

extern int ParseDateTime(const char *timestr, char *workbuf, size_t buflen,
     char **field, int *ftype,
     int maxfields, int *numfields);
extern int DecodeDateTime(char **field, int *ftype,
      int nf, int *dtype,
      struct pg_tm * tm, fsec_t *fsec, int *tzp);
extern int DecodeTimeOnly(char **field, int *ftype,
      int nf, int *dtype,
      struct pg_tm * tm, fsec_t *fsec, int *tzp);
extern int DecodeInterval(char **field, int *ftype, int nf, int range,
      int *dtype, struct pg_tm * tm, fsec_t *fsec);
extern int DecodeISO8601Interval(char *str,
       int *dtype, struct pg_tm * tm, fsec_t *fsec);

extern void DateTimeParseError(int dterr, const char *str,
       const char *datatype);

extern int DetermineTimeZoneOffset(struct pg_tm * tm, pg_tz *tzp);

extern void EncodeDateOnly(struct pg_tm * tm, int style, char *str);
extern void EncodeTimeOnly(struct pg_tm * tm, fsec_t fsec, bool print_tz, int tz, int style, char *str);
extern void EncodeDateTime(struct pg_tm * tm, fsec_t fsec, bool print_tz, int tz, const char *tzn, int style, char *str);
extern void EncodeInterval(struct pg_tm * tm, fsec_t fsec, int style, char *str);

extern int DecodeSpecial(int field, char *lowtoken, int *val);
extern int DecodeUnits(int field, char *lowtoken, int *val);

extern int j2day(int jd);

extern Node *TemporalTransform(int32 max_precis, Node *node);

extern bool CheckDateTokenTables(void);

extern void ConvertTimeZoneAbbrevs(TimeZoneAbbrevTable *tbl,
        struct tzEntry *abbrevs, int n);
extern void InstallTimeZoneAbbrevs(TimeZoneAbbrevTable *tbl);

extern Datum pg_timezone_abbrevs(FunctionCallInfo fcinfo);
extern Datum pg_timezone_names(FunctionCallInfo fcinfo);
# 17 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/tzparser.h" 2






typedef struct tzEntry
{

 char *abbrev;
 int offset;
 bool is_dst;

 int lineno;
 const char *filename;
} tzEntry;


extern TimeZoneAbbrevTable *load_tzoffsets(const char *filename);
# 78 "guc.c" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/xml.h" 1
# 19 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/xml.h"
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/execnodes.h" 1
# 20 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/xml.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/nodes/primnodes.h" 1
# 21 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/xml.h" 2

typedef struct varlena xmltype;

typedef enum
{
 XML_STANDALONE_YES,
 XML_STANDALONE_NO,
 XML_STANDALONE_NO_VALUE,
 XML_STANDALONE_OMITTED
} XmlStandaloneType;

typedef enum
{
 XMLBINARY_BASE64,
 XMLBINARY_HEX
} XmlBinaryType;

typedef enum
{
 PG_XML_STRICTNESS_LEGACY,

 PG_XML_STRICTNESS_WELLFORMED,
 PG_XML_STRICTNESS_ALL
} PgXmlStrictness;


typedef struct PgXmlErrorContext PgXmlErrorContext;







extern Datum xml_in(FunctionCallInfo fcinfo);
extern Datum xml_out(FunctionCallInfo fcinfo);
extern Datum xml_recv(FunctionCallInfo fcinfo);
extern Datum xml_send(FunctionCallInfo fcinfo);
extern Datum xmlcomment(FunctionCallInfo fcinfo);
extern Datum xmlconcat2(FunctionCallInfo fcinfo);
extern Datum texttoxml(FunctionCallInfo fcinfo);
extern Datum xmltotext(FunctionCallInfo fcinfo);
extern Datum xmlvalidate(FunctionCallInfo fcinfo);
extern Datum xpath(FunctionCallInfo fcinfo);
extern Datum xpath_exists(FunctionCallInfo fcinfo);
extern Datum xmlexists(FunctionCallInfo fcinfo);
extern Datum xml_is_well_formed(FunctionCallInfo fcinfo);
extern Datum xml_is_well_formed_document(FunctionCallInfo fcinfo);
extern Datum xml_is_well_formed_content(FunctionCallInfo fcinfo);

extern Datum table_to_xml(FunctionCallInfo fcinfo);
extern Datum query_to_xml(FunctionCallInfo fcinfo);
extern Datum cursor_to_xml(FunctionCallInfo fcinfo);
extern Datum table_to_xmlschema(FunctionCallInfo fcinfo);
extern Datum query_to_xmlschema(FunctionCallInfo fcinfo);
extern Datum cursor_to_xmlschema(FunctionCallInfo fcinfo);
extern Datum table_to_xml_and_xmlschema(FunctionCallInfo fcinfo);
extern Datum query_to_xml_and_xmlschema(FunctionCallInfo fcinfo);

extern Datum schema_to_xml(FunctionCallInfo fcinfo);
extern Datum schema_to_xmlschema(FunctionCallInfo fcinfo);
extern Datum schema_to_xml_and_xmlschema(FunctionCallInfo fcinfo);

extern Datum database_to_xml(FunctionCallInfo fcinfo);
extern Datum database_to_xmlschema(FunctionCallInfo fcinfo);
extern Datum database_to_xml_and_xmlschema(FunctionCallInfo fcinfo);

extern void pg_xml_init_library(void);
extern PgXmlErrorContext *pg_xml_init(PgXmlStrictness strictness);
extern void pg_xml_done(PgXmlErrorContext *errcxt, bool isError);
extern bool pg_xml_error_occurred(PgXmlErrorContext *errcxt);
extern void xml_ereport(PgXmlErrorContext *errcxt, int level, int sqlcode,
   const char *msg);

extern xmltype *xmlconcat(List *args);
extern xmltype *xmlelement(XmlExprState *xmlExpr, ExprContext *econtext);
extern xmltype *xmlparse(text *data, XmlOptionType xmloption, bool preserve_whitespace);
extern xmltype *xmlpi(char *target, text *arg, bool arg_is_null, bool *result_is_null);
extern xmltype *xmlroot(xmltype *data, text *version, int standalone);
extern bool xml_is_document(xmltype *arg);
extern text *xmltotext_with_xmloption(xmltype *data, XmlOptionType xmloption_arg);
extern char *escape_xml(const char *str);

extern char *map_sql_identifier_to_xml_name(char *ident, bool fully_escaped, bool escape_period);
extern char *map_xml_name_to_sql_identifier(char *name);
extern char *map_sql_value_to_xml_value(Datum value, Oid type, bool xml_escape_strings);

extern int xmlbinary;

extern int xmloption;
# 79 "guc.c" 2
# 128 "guc.c"
extern bool Log_disconnections;
extern int CommitDelay;
extern int CommitSiblings;
extern char *default_tablespace;
extern char *temp_tablespaces;
extern bool synchronize_seqscans;
extern int ssl_renegotiation_limit;
extern char *SSLCipherSuites;


extern bool trace_sort;
# 147 "guc.c"
static int GUC_check_errcode_value;


char *GUC_check_errmsg_string;
char *GUC_check_errdetail_string;
char *GUC_check_errhint_string;


static void set_config_sourcefile(const char *name, char *sourcefile,
       int sourceline);
static bool call_bool_check_hook(struct config_bool * conf, bool *newval,
      void **extra, GucSource source, int elevel);
static bool call_int_check_hook(struct config_int * conf, int *newval,
     void **extra, GucSource source, int elevel);
static bool call_real_check_hook(struct config_real * conf, double *newval,
      void **extra, GucSource source, int elevel);
static bool call_string_check_hook(struct config_string * conf, char **newval,
        void **extra, GucSource source, int elevel);
static bool call_enum_check_hook(struct config_enum * conf, int *newval,
      void **extra, GucSource source, int elevel);

static bool check_log_destination(char **newval, void **extra, GucSource source);
static void assign_log_destination(const char *newval, void *extra);


static int syslog_facility = (16<<3);




static void assign_syslog_facility(int newval, void *extra);
static void assign_syslog_ident(const char *newval, void *extra);
static void assign_session_replication_role(int newval, void *extra);
static bool check_temp_buffers(int *newval, void **extra, GucSource source);
static bool check_phony_autocommit(bool *newval, void **extra, GucSource source);
static bool check_debug_assertions(bool *newval, void **extra, GucSource source);
static bool check_bonjour(bool *newval, void **extra, GucSource source);
static bool check_ssl(bool *newval, void **extra, GucSource source);
static bool check_stage_log_stats(bool *newval, void **extra, GucSource source);
static bool check_log_stats(bool *newval, void **extra, GucSource source);
static bool check_canonical_path(char **newval, void **extra, GucSource source);
static bool check_timezone_abbreviations(char **newval, void **extra, GucSource source);
static void assign_timezone_abbreviations(const char *newval, void *extra);
static void pg_timezone_abbrev_initialize(void);
static const char *show_archive_command(void);
static void assign_tcp_keepalives_idle(int newval, void *extra);
static void assign_tcp_keepalives_interval(int newval, void *extra);
static void assign_tcp_keepalives_count(int newval, void *extra);
static const char *show_tcp_keepalives_idle(void);
static const char *show_tcp_keepalives_interval(void);
static const char *show_tcp_keepalives_count(void);
static bool check_maxconnections(int *newval, void **extra, GucSource source);
static void assign_maxconnections(int newval, void *extra);
static bool check_autovacuum_max_workers(int *newval, void **extra, GucSource source);
static void assign_autovacuum_max_workers(int newval, void *extra);
static bool check_effective_io_concurrency(int *newval, void **extra, GucSource source);
static void assign_effective_io_concurrency(int newval, void *extra);
static void assign_pgstat_temp_directory(const char *newval, void *extra);
static bool check_application_name(char **newval, void **extra, GucSource source);
static void assign_application_name(const char *newval, void *extra);
static const char *show_unix_socket_permissions(void);
static const char *show_log_file_mode(void);

static char *config_enum_get_options(struct config_enum * record,
      const char *prefix, const char *suffix,
      const char *separator);
# 221 "guc.c"
static const struct config_enum_entry bytea_output_options[] = {
 {"escape", BYTEA_OUTPUT_ESCAPE, ((bool) 0)},
 {"hex", BYTEA_OUTPUT_HEX, ((bool) 0)},
 {((void *)0), 0, ((bool) 0)}
};





static const struct config_enum_entry client_message_level_options[] = {
 {"debug", 13, ((bool) 1)},
 {"debug5", 10, ((bool) 0)},
 {"debug4", 11, ((bool) 0)},
 {"debug3", 12, ((bool) 0)},
 {"debug2", 13, ((bool) 0)},
 {"debug1", 14, ((bool) 0)},
 {"log", 15, ((bool) 0)},
 {"info", 17, ((bool) 1)},
 {"notice", 18, ((bool) 0)},
 {"warning", 19, ((bool) 0)},
 {"error", 20, ((bool) 0)},
 {"fatal", 21, ((bool) 1)},
 {"panic", 22, ((bool) 1)},
 {((void *)0), 0, ((bool) 0)}
};

static const struct config_enum_entry server_message_level_options[] = {
 {"debug", 13, ((bool) 1)},
 {"debug5", 10, ((bool) 0)},
 {"debug4", 11, ((bool) 0)},
 {"debug3", 12, ((bool) 0)},
 {"debug2", 13, ((bool) 0)},
 {"debug1", 14, ((bool) 0)},
 {"info", 17, ((bool) 0)},
 {"notice", 18, ((bool) 0)},
 {"warning", 19, ((bool) 0)},
 {"error", 20, ((bool) 0)},
 {"log", 15, ((bool) 0)},
 {"fatal", 21, ((bool) 0)},
 {"panic", 22, ((bool) 0)},
 {((void *)0), 0, ((bool) 0)}
};

static const struct config_enum_entry intervalstyle_options[] = {
 {"postgres", 0, ((bool) 0)},
 {"postgres_verbose", 1, ((bool) 0)},
 {"sql_standard", 2, ((bool) 0)},
 {"iso_8601", 3, ((bool) 0)},
 {((void *)0), 0, ((bool) 0)}
};

static const struct config_enum_entry log_error_verbosity_options[] = {
 {"terse", PGERROR_TERSE, ((bool) 0)},
 {"default", PGERROR_DEFAULT, ((bool) 0)},
 {"verbose", PGERROR_VERBOSE, ((bool) 0)},
 {((void *)0), 0, ((bool) 0)}
};

static const struct config_enum_entry log_statement_options[] = {
 {"none", LOGSTMT_NONE, ((bool) 0)},
 {"ddl", LOGSTMT_DDL, ((bool) 0)},
 {"mod", LOGSTMT_MOD, ((bool) 0)},
 {"all", LOGSTMT_ALL, ((bool) 0)},
 {((void *)0), 0, ((bool) 0)}
};

static const struct config_enum_entry isolation_level_options[] = {
 {"serializable", 3, ((bool) 0)},
 {"repeatable read", 2, ((bool) 0)},
 {"read committed", 1, ((bool) 0)},
 {"read uncommitted", 0, ((bool) 0)},
 {((void *)0), 0}
};

static const struct config_enum_entry session_replication_role_options[] = {
 {"origin", 0, ((bool) 0)},
 {"replica", 1, ((bool) 0)},
 {"local", 2, ((bool) 0)},
 {((void *)0), 0, ((bool) 0)}
};

static const struct config_enum_entry syslog_facility_options[] = {

 {"local0", (16<<3), ((bool) 0)},
 {"local1", (17<<3), ((bool) 0)},
 {"local2", (18<<3), ((bool) 0)},
 {"local3", (19<<3), ((bool) 0)},
 {"local4", (20<<3), ((bool) 0)},
 {"local5", (21<<3), ((bool) 0)},
 {"local6", (22<<3), ((bool) 0)},
 {"local7", (23<<3), ((bool) 0)},



 {((void *)0), 0}
};

static const struct config_enum_entry track_function_options[] = {
 {"none", TRACK_FUNC_OFF, ((bool) 0)},
 {"pl", TRACK_FUNC_PL, ((bool) 0)},
 {"all", TRACK_FUNC_ALL, ((bool) 0)},
 {((void *)0), 0, ((bool) 0)}
};

static const struct config_enum_entry xmlbinary_options[] = {
 {"base64", XMLBINARY_BASE64, ((bool) 0)},
 {"hex", XMLBINARY_HEX, ((bool) 0)},
 {((void *)0), 0, ((bool) 0)}
};

static const struct config_enum_entry xmloption_options[] = {
 {"content", XMLOPTION_CONTENT, ((bool) 0)},
 {"document", XMLOPTION_DOCUMENT, ((bool) 0)},
 {((void *)0), 0, ((bool) 0)}
};





static const struct config_enum_entry backslash_quote_options[] = {
 {"safe_encoding", BACKSLASH_QUOTE_SAFE_ENCODING, ((bool) 0)},
 {"on", BACKSLASH_QUOTE_ON, ((bool) 0)},
 {"off", BACKSLASH_QUOTE_OFF, ((bool) 0)},
 {"true", BACKSLASH_QUOTE_ON, ((bool) 1)},
 {"false", BACKSLASH_QUOTE_OFF, ((bool) 1)},
 {"yes", BACKSLASH_QUOTE_ON, ((bool) 1)},
 {"no", BACKSLASH_QUOTE_OFF, ((bool) 1)},
 {"1", BACKSLASH_QUOTE_ON, ((bool) 1)},
 {"0", BACKSLASH_QUOTE_OFF, ((bool) 1)},
 {((void *)0), 0, ((bool) 0)}
};





static const struct config_enum_entry constraint_exclusion_options[] = {
 {"partition", CONSTRAINT_EXCLUSION_PARTITION, ((bool) 0)},
 {"on", CONSTRAINT_EXCLUSION_ON, ((bool) 0)},
 {"off", CONSTRAINT_EXCLUSION_OFF, ((bool) 0)},
 {"true", CONSTRAINT_EXCLUSION_ON, ((bool) 1)},
 {"false", CONSTRAINT_EXCLUSION_OFF, ((bool) 1)},
 {"yes", CONSTRAINT_EXCLUSION_ON, ((bool) 1)},
 {"no", CONSTRAINT_EXCLUSION_OFF, ((bool) 1)},
 {"1", CONSTRAINT_EXCLUSION_ON, ((bool) 1)},
 {"0", CONSTRAINT_EXCLUSION_OFF, ((bool) 1)},
 {((void *)0), 0, ((bool) 0)}
};





static const struct config_enum_entry synchronous_commit_options[] = {
 {"local", SYNCHRONOUS_COMMIT_LOCAL_FLUSH, ((bool) 0)},
 {"remote_write", SYNCHRONOUS_COMMIT_REMOTE_WRITE, ((bool) 0)},
 {"on", SYNCHRONOUS_COMMIT_REMOTE_FLUSH, ((bool) 0)},
 {"off", SYNCHRONOUS_COMMIT_OFF, ((bool) 0)},
 {"true", SYNCHRONOUS_COMMIT_REMOTE_FLUSH, ((bool) 1)},
 {"false", SYNCHRONOUS_COMMIT_OFF, ((bool) 1)},
 {"yes", SYNCHRONOUS_COMMIT_REMOTE_FLUSH, ((bool) 1)},
 {"no", SYNCHRONOUS_COMMIT_OFF, ((bool) 1)},
 {"1", SYNCHRONOUS_COMMIT_REMOTE_FLUSH, ((bool) 1)},
 {"0", SYNCHRONOUS_COMMIT_OFF, ((bool) 1)},
 {((void *)0), 0, ((bool) 0)}
};




extern const struct config_enum_entry wal_level_options[];
extern const struct config_enum_entry sync_method_options[];







bool assert_enabled = ((bool) 0);

bool log_duration = ((bool) 0);
bool Debug_print_plan = ((bool) 0);
bool Debug_print_parse = ((bool) 0);
bool Debug_print_rewritten = ((bool) 0);
bool Debug_pretty_print = ((bool) 1);

bool log_parser_stats = ((bool) 0);
bool log_planner_stats = ((bool) 0);
bool log_executor_stats = ((bool) 0);
bool log_statement_stats = ((bool) 0);

bool log_btree_build_stats = ((bool) 0);
char *event_source;

bool check_function_bodies = ((bool) 1);
bool default_with_oids = ((bool) 0);
bool SQL_inheritance = ((bool) 1);

bool Password_encryption = ((bool) 1);

int log_min_error_statement = 20;
int log_min_messages = 19;
int client_min_messages = 18;
int log_min_duration_statement = -1;
int log_temp_files = -1;
int trace_recovery_messages = 15;

int temp_file_limit = -1;

int num_temp_buffers = 1024;

char *data_directory;
char *ConfigFileName;
char *HbaFileName;
char *IdentFileName;
char *external_pid_file;

char *pgstat_temp_directory;

char *application_name;

int tcp_keepalives_idle;
int tcp_keepalives_interval;
int tcp_keepalives_count;






static char *log_destination_string;

static char *syslog_ident_str;
static bool phony_autocommit;
static bool session_auth_is_superuser;
static double phony_random_seed;
static char *client_encoding_string;
static char *datestyle_string;
static char *locale_collate;
static char *locale_ctype;
static char *server_encoding_string;
static char *server_version_string;
static int server_version_num;
static char *timezone_string;
static char *log_timezone_string;
static char *timezone_abbreviations_string;
static char *XactIsoLevel_string;
static char *session_authorization_string;
static int max_function_args;
static int max_index_keys;
static int max_identifier_length;
static int block_size;
static int segment_size;
static int wal_block_size;
static int wal_segment_size;
static bool integer_datetimes;
static int effective_io_concurrency;


char *role_string;







const char *const GucContext_Names[] =
{
                     "internal",
                       "postmaster",
                   "sighup",
                    "backend",
                  "superuser",
                    "user"
};






const char *const GucSource_Names[] =
{
                      "default",
                              "default",
                      "environment variable",
                   "configuration file",
                   "command line",
                       "database",
                   "user",
                            "database user",
                     "client",
                       "override",
                          "interactive",
                   "test",
                      "session"
};




const char *const config_group_names[] =
{

 ("Ungrouped"),

 ("File Locations"),

 ("Connections and Authentication"),

 ("Connections and Authentication / Connection Settings"),

 ("Connections and Authentication / Security and Authentication"),

 ("Resource Usage"),

 ("Resource Usage / Memory"),

 ("Resource Usage / Disk"),

 ("Resource Usage / Kernel Resources"),

 ("Resource Usage / Cost-Based Vacuum Delay"),

 ("Resource Usage / Background Writer"),

 ("Resource Usage / Asynchronous Behavior"),

 ("Write-Ahead Log"),

 ("Write-Ahead Log / Settings"),

 ("Write-Ahead Log / Checkpoints"),

 ("Write-Ahead Log / Archiving"),

 ("Replication"),

 ("Replication / Sending Servers"),

 ("Replication / Master Server"),

 ("Replication / Standby Servers"),

 ("Query Tuning"),

 ("Query Tuning / Planner Method Configuration"),

 ("Query Tuning / Planner Cost Constants"),

 ("Query Tuning / Genetic Query Optimizer"),

 ("Query Tuning / Other Planner Options"),

 ("Reporting and Logging"),

 ("Reporting and Logging / Where to Log"),

 ("Reporting and Logging / When to Log"),

 ("Reporting and Logging / What to Log"),

 ("Statistics"),

 ("Statistics / Monitoring"),

 ("Statistics / Query and Index Statistics Collector"),

 ("Autovacuum"),

 ("Client Connection Defaults"),

 ("Client Connection Defaults / Statement Behavior"),

 ("Client Connection Defaults / Locale and Formatting"),

 ("Client Connection Defaults / Other Defaults"),

 ("Lock Management"),

 ("Version and Platform Compatibility"),

 ("Version and Platform Compatibility / Previous PostgreSQL Versions"),

 ("Version and Platform Compatibility / Other Platforms and Clients"),

 ("Error Handling"),

 ("Preset Options"),

 ("Customized Options"),

 ("Developer Options"),

 ((void *)0)
};






const char *const config_type_names[] =
{
                 "bool",
                "integer",
                 "real",
                   "string",
                 "enum"
};
# 667 "guc.c"
static struct config_bool ConfigureNamesBool[] =
{
 {
  {"enable_seqscan", PGC_USERSET, QUERY_TUNING_METHOD,
   ("Enables the planner's use of sequential-scan plans."),
   ((void *)0)
  },
  &enable_seqscan,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"enable_indexscan", PGC_USERSET, QUERY_TUNING_METHOD,
   ("Enables the planner's use of index-scan plans."),
   ((void *)0)
  },
  &enable_indexscan,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"enable_indexonlyscan", PGC_USERSET, QUERY_TUNING_METHOD,
   ("Enables the planner's use of index-only-scan plans."),
   ((void *)0)
  },
  &enable_indexonlyscan,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"enable_bitmapscan", PGC_USERSET, QUERY_TUNING_METHOD,
   ("Enables the planner's use of bitmap-scan plans."),
   ((void *)0)
  },
  &enable_bitmapscan,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"enable_tidscan", PGC_USERSET, QUERY_TUNING_METHOD,
   ("Enables the planner's use of TID scan plans."),
   ((void *)0)
  },
  &enable_tidscan,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"enable_sort", PGC_USERSET, QUERY_TUNING_METHOD,
   ("Enables the planner's use of explicit sort steps."),
   ((void *)0)
  },
  &enable_sort,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"enable_hashagg", PGC_USERSET, QUERY_TUNING_METHOD,
   ("Enables the planner's use of hashed aggregation plans."),
   ((void *)0)
  },
  &enable_hashagg,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"enable_material", PGC_USERSET, QUERY_TUNING_METHOD,
   ("Enables the planner's use of materialization."),
   ((void *)0)
  },
  &enable_material,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"enable_nestloop", PGC_USERSET, QUERY_TUNING_METHOD,
   ("Enables the planner's use of nested-loop join plans."),
   ((void *)0)
  },
  &enable_nestloop,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"enable_mergejoin", PGC_USERSET, QUERY_TUNING_METHOD,
   ("Enables the planner's use of merge join plans."),
   ((void *)0)
  },
  &enable_mergejoin,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"enable_hashjoin", PGC_USERSET, QUERY_TUNING_METHOD,
   ("Enables the planner's use of hash join plans."),
   ((void *)0)
  },
  &enable_hashjoin,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"geqo", PGC_USERSET, QUERY_TUNING_GEQO,
   ("Enables genetic query optimization."),
   ("This algorithm attempts to do planning without " "exhaustive searching.")

  },
  &enable_geqo,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {

  {"is_superuser", PGC_INTERNAL, UNGROUPED,
   ("Shows whether the current user is a superuser."),
   ((void *)0),
   0x0010 | 0x0004 | 0x0008 | 0x0020 | 0x0040
  },
  &session_auth_is_superuser,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"bonjour", PGC_POSTMASTER, CONN_AUTH_SETTINGS,
   ("Enables advertising the server via Bonjour."),
   ((void *)0)
  },
  &enable_bonjour,
  ((bool) 0),
  check_bonjour, ((void *)0), ((void *)0)
 },
 {
  {"ssl", PGC_POSTMASTER, CONN_AUTH_SECURITY,
   ("Enables SSL connections."),
   ((void *)0)
  },
  &EnableSSL,
  ((bool) 0),
  check_ssl, ((void *)0), ((void *)0)
 },
 {
  {"fsync", PGC_SIGHUP, WAL_SETTINGS,
   ("Forces synchronization of updates to disk."),
   ("The server will use the fsync() system call in several places to make " "sure that updates are physically written to disk. This insures " "that a database cluster will recover to a consistent state after " "an operating system or hardware crash.")



  },
  &enableFsync,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"zero_damaged_pages", PGC_SUSET, DEVELOPER_OPTIONS,
   ("Continues processing past damaged page headers."),
   ("Detection of a damaged page header normally causes PostgreSQL to " "report an error, aborting the current transaction. Setting " "zero_damaged_pages to true causes the system to instead report a " "warning, zero out the damaged page, and continue processing. This " "behavior will destroy data, namely all the rows on the damaged page."),




   0x0020
  },
  &zero_damaged_pages,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"full_page_writes", PGC_SIGHUP, WAL_SETTINGS,
   ("Writes full pages to WAL when first modified after a checkpoint."),
   ("A page write in process during an operating system crash might be " "only partially written to disk.  During recovery, the row changes " "stored in WAL are not enough to recover.  This option writes " "pages when first modified after a checkpoint to WAL so full recovery " "is possible.")




  },
  &fullPageWrites,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"log_checkpoints", PGC_SIGHUP, LOGGING_WHAT,
   ("Logs each checkpoint."),
   ((void *)0)
  },
  &log_checkpoints,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"log_connections", PGC_BACKEND, LOGGING_WHAT,
   ("Logs each successful connection."),
   ((void *)0)
  },
  &Log_connections,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"log_disconnections", PGC_BACKEND, LOGGING_WHAT,
   ("Logs end of a session, including duration."),
   ((void *)0)
  },
  &Log_disconnections,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"debug_assertions", PGC_USERSET, DEVELOPER_OPTIONS,
   ("Turns on various assertion checks."),
   ("This is a debugging aid."),
   0x0020
  },
  &assert_enabled,



  ((bool) 0),

  check_debug_assertions, ((void *)0), ((void *)0)
 },

 {
  {"exit_on_error", PGC_USERSET, ERROR_HANDLING_OPTIONS,
   ("Terminate session on any error."),
   ((void *)0)
  },
  &ExitOnAnyError,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"restart_after_crash", PGC_SIGHUP, ERROR_HANDLING_OPTIONS,
   ("Reinitialize server after backend crash."),
   ((void *)0)
  },
  &restart_after_crash,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"log_duration", PGC_SUSET, LOGGING_WHAT,
   ("Logs the duration of each completed SQL statement."),
   ((void *)0)
  },
  &log_duration,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"debug_print_parse", PGC_USERSET, LOGGING_WHAT,
   ("Logs each query's parse tree."),
   ((void *)0)
  },
  &Debug_print_parse,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"debug_print_rewritten", PGC_USERSET, LOGGING_WHAT,
   ("Logs each query's rewritten parse tree."),
   ((void *)0)
  },
  &Debug_print_rewritten,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"debug_print_plan", PGC_USERSET, LOGGING_WHAT,
   ("Logs each query's execution plan."),
   ((void *)0)
  },
  &Debug_print_plan,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"debug_pretty_print", PGC_USERSET, LOGGING_WHAT,
   ("Indents parse and plan tree displays."),
   ((void *)0)
  },
  &Debug_pretty_print,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"log_parser_stats", PGC_SUSET, STATS_MONITORING,
   ("Writes parser performance statistics to the server log."),
   ((void *)0)
  },
  &log_parser_stats,
  ((bool) 0),
  check_stage_log_stats, ((void *)0), ((void *)0)
 },
 {
  {"log_planner_stats", PGC_SUSET, STATS_MONITORING,
   ("Writes planner performance statistics to the server log."),
   ((void *)0)
  },
  &log_planner_stats,
  ((bool) 0),
  check_stage_log_stats, ((void *)0), ((void *)0)
 },
 {
  {"log_executor_stats", PGC_SUSET, STATS_MONITORING,
   ("Writes executor performance statistics to the server log."),
   ((void *)0)
  },
  &log_executor_stats,
  ((bool) 0),
  check_stage_log_stats, ((void *)0), ((void *)0)
 },
 {
  {"log_statement_stats", PGC_SUSET, STATS_MONITORING,
   ("Writes cumulative performance statistics to the server log."),
   ((void *)0)
  },
  &log_statement_stats,
  ((bool) 0),
  check_log_stats, ((void *)0), ((void *)0)
 },
# 1001 "guc.c"
 {
  {"track_activities", PGC_SUSET, STATS_COLLECTOR,
   ("Collects information about executing commands."),
   ("Enables the collection of information on the currently " "executing command of each session, along with " "the time at which that command began execution.")


  },
  &pgstat_track_activities,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"track_counts", PGC_SUSET, STATS_COLLECTOR,
   ("Collects statistics on database activity."),
   ((void *)0)
  },
  &pgstat_track_counts,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"track_io_timing", PGC_SUSET, STATS_COLLECTOR,
   ("Collects timing statistics for database I/O activity."),
   ((void *)0)
  },
  &track_io_timing,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"update_process_title", PGC_SUSET, STATS_COLLECTOR,
   ("Updates the process title to show the active SQL command."),
   ("Enables updating of the process title every time a new SQL command is received by the server.")
  },
  &update_process_title,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"autovacuum", PGC_SIGHUP, AUTOVACUUM,
   ("Starts the autovacuum subprocess."),
   ((void *)0)
  },
  &autovacuum_start_daemon,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"trace_notify", PGC_USERSET, DEVELOPER_OPTIONS,
   ("Generates debugging output for LISTEN and NOTIFY."),
   ((void *)0),
   0x0020
  },
  &Trace_notify,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },
# 1105 "guc.c"
 {
  {"log_lock_waits", PGC_SUSET, LOGGING_WHAT,
   ("Logs long lock waits."),
   ((void *)0)
  },
  &log_lock_waits,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"log_hostname", PGC_SIGHUP, LOGGING_WHAT,
   ("Logs the host name in the connection logs."),
   ("By default, connection logs only show the IP address " "of the connecting host. If you want them to show the host name you " "can turn this on, but depending on your host name resolution " "setup it might impose a non-negligible performance penalty.")



  },
  &log_hostname,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"sql_inheritance", PGC_USERSET, COMPAT_OPTIONS_PREVIOUS,
   ("Causes subtables to be included by default in various commands."),
   ((void *)0)
  },
  &SQL_inheritance,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"password_encryption", PGC_USERSET, CONN_AUTH_SECURITY,
   ("Encrypt passwords."),
   ("When a password is specified in CREATE USER or " "ALTER USER without writing either ENCRYPTED or UNENCRYPTED, " "this parameter determines whether the password is to be encrypted.")


  },
  &Password_encryption,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"transform_null_equals", PGC_USERSET, COMPAT_OPTIONS_CLIENT,
   ("Treats \"expr=NULL\" as \"expr IS NULL\"."),
   ("When turned on, expressions of the form expr = NULL " "(or NULL = expr) are treated as expr IS NULL, that is, they " "return true if expr evaluates to the null value, and false " "otherwise. The correct behavior of expr = NULL is to always " "return null (unknown).")




  },
  &Transform_null_equals,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"db_user_namespace", PGC_SIGHUP, CONN_AUTH_SECURITY,
   ("Enables per-database user names."),
   ((void *)0)
  },
  &Db_user_namespace,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {

  {"autocommit", PGC_USERSET, CLIENT_CONN_STATEMENT,
   ("This parameter doesn't do anything."),
   ("It's just here so that we won't choke on SET AUTOCOMMIT TO ON from 7.3-vintage clients."),
   0x0004 | 0x0020
  },
  &phony_autocommit,
  ((bool) 1),
  check_phony_autocommit, ((void *)0), ((void *)0)
 },
 {
  {"default_transaction_read_only", PGC_USERSET, CLIENT_CONN_STATEMENT,
   ("Sets the default read-only status of new transactions."),
   ((void *)0)
  },
  &DefaultXactReadOnly,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"transaction_read_only", PGC_USERSET, CLIENT_CONN_STATEMENT,
   ("Sets the current transaction's read-only status."),
   ((void *)0),
   0x0008 | 0x0020 | 0x0040
  },
  &XactReadOnly,
  ((bool) 0),
  check_transaction_read_only, ((void *)0), ((void *)0)
 },
 {
  {"default_transaction_deferrable", PGC_USERSET, CLIENT_CONN_STATEMENT,
   ("Sets the default deferrable status of new transactions."),
   ((void *)0)
  },
  &DefaultXactDeferrable,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"transaction_deferrable", PGC_USERSET, CLIENT_CONN_STATEMENT,
   ("Whether to defer a read-only serializable transaction until it can be executed with no possible serialization failures."),
   ((void *)0),
   0x0008 | 0x0020 | 0x0040
  },
  &XactDeferrable,
  ((bool) 0),
  check_transaction_deferrable, ((void *)0), ((void *)0)
 },
 {
  {"check_function_bodies", PGC_USERSET, CLIENT_CONN_STATEMENT,
   ("Check function bodies during CREATE FUNCTION."),
   ((void *)0)
  },
  &check_function_bodies,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"array_nulls", PGC_USERSET, COMPAT_OPTIONS_PREVIOUS,
   ("Enable input of NULL elements in arrays."),
   ("When turned on, unquoted NULL in an array input " "value means a null value; " "otherwise it is taken literally.")


  },
  &Array_nulls,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"default_with_oids", PGC_USERSET, COMPAT_OPTIONS_PREVIOUS,
   ("Create new tables with OIDs by default."),
   ((void *)0)
  },
  &default_with_oids,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"logging_collector", PGC_POSTMASTER, LOGGING_WHERE,
   ("Start a subprocess to capture stderr output and/or csvlogs into log files."),
   ((void *)0)
  },
  &Logging_collector,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"log_truncate_on_rotation", PGC_SIGHUP, LOGGING_WHERE,
   ("Truncate existing log files of same name during log rotation."),
   ((void *)0)
  },
  &Log_truncate_on_rotation,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },


 {
  {"trace_sort", PGC_USERSET, DEVELOPER_OPTIONS,
   ("Emit information about resource usage in sorting."),
   ((void *)0),
   0x0020
  },
  &trace_sort,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },
# 1321 "guc.c"
 {
  {"integer_datetimes", PGC_INTERNAL, PRESET_OPTIONS,
   ("Datetimes are integer based."),
   ((void *)0),
   0x0010 | 0x0020 | 0x0040
  },
  &integer_datetimes,

  ((bool) 1),



  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"krb_caseins_users", PGC_SIGHUP, CONN_AUTH_SECURITY,
   ("Sets whether Kerberos and GSSAPI user names should be treated as case-insensitive."),
   ((void *)0)
  },
  &pg_krb_caseins_users,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"escape_string_warning", PGC_USERSET, COMPAT_OPTIONS_PREVIOUS,
   ("Warn about backslash escapes in ordinary string literals."),
   ((void *)0)
  },
  &escape_string_warning,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"standard_conforming_strings", PGC_USERSET, COMPAT_OPTIONS_PREVIOUS,
   ("Causes '...' strings to treat backslashes literally."),
   ((void *)0),
   0x0010
  },
  &standard_conforming_strings,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"synchronize_seqscans", PGC_USERSET, COMPAT_OPTIONS_PREVIOUS,
   ("Enable synchronized sequential scans."),
   ((void *)0)
  },
  &synchronize_seqscans,
  ((bool) 1),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"archive_mode", PGC_POSTMASTER, WAL_ARCHIVING,
   ("Allows archiving of WAL files using archive_command."),
   ((void *)0)
  },
  &XLogArchiveMode,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"hot_standby", PGC_POSTMASTER, REPLICATION_STANDBY,
   ("Allows connections and queries during recovery."),
   ((void *)0)
  },
  &EnableHotStandby,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"hot_standby_feedback", PGC_SIGHUP, REPLICATION_STANDBY,
   ("Allows feedback from a hot standby to the primary that will avoid query conflicts."),
   ((void *)0)
  },
  &hot_standby_feedback,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"allow_system_table_mods", PGC_POSTMASTER, DEVELOPER_OPTIONS,
   ("Allows modifications of the structure of system tables."),
   ((void *)0),
   0x0020
  },
  &allowSystemTableMods,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"ignore_system_indexes", PGC_BACKEND, DEVELOPER_OPTIONS,
   ("Disables reading from system indexes."),
   ("It does not prevent updating the indexes, so it is safe " "to use.  The worst consequence is slowness."),

   0x0020
  },
  &IgnoreSystemIndexes,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"lo_compat_privileges", PGC_SUSET, COMPAT_OPTIONS_PREVIOUS,
   ("Enables backward compatibility mode for privilege checks on large objects."),
   ("Skips privilege checks when reading or modifying large objects, " "for compatibility with PostgreSQL releases prior to 9.0.")

  },
  &lo_compat_privileges,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"quote_all_identifiers", PGC_USERSET, COMPAT_OPTIONS_PREVIOUS,
   ("When generating SQL fragments, quote all identifiers."),
   ((void *)0),
  },
  &quote_all_identifiers,
  ((bool) 0),
  ((void *)0), ((void *)0), ((void *)0)
 },


 {
  {((void *)0), 0, 0, ((void *)0), ((void *)0)}, ((void *)0), ((bool) 0), ((void *)0), ((void *)0), ((void *)0)
 }
};


static struct config_int ConfigureNamesInt[] =
{
 {
  {"archive_timeout", PGC_SIGHUP, WAL_ARCHIVING,
   ("Forces a switch to the next xlog file if a " "new file has not been started within N seconds."),

   ((void *)0),
   0x2000
  },
  &XLogArchiveTimeout,
  0, 0, 2147483647 / 2,
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"post_auth_delay", PGC_BACKEND, DEVELOPER_OPTIONS,
   ("Waits N seconds on connection startup after authentication."),
   ("This allows attaching a debugger to the process."),
   0x0020 | 0x2000
  },
  &PostAuthDelay,
  0, 0, 2147483647 / 1000000,
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"default_statistics_target", PGC_USERSET, QUERY_TUNING_OTHER,
   ("Sets the default statistics target."),
   ("This applies to table columns that have not had a " "column-specific target set via ALTER TABLE SET STATISTICS.")

  },
  &default_statistics_target,
  100, 1, 10000,
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"from_collapse_limit", PGC_USERSET, QUERY_TUNING_OTHER,
   ("Sets the FROM-list size beyond which subqueries " "are not collapsed."),

   ("The planner will merge subqueries into upper " "queries if the resulting FROM list would have no more than " "this many items.")


  },
  &from_collapse_limit,
  8, 1, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"join_collapse_limit", PGC_USERSET, QUERY_TUNING_OTHER,
   ("Sets the FROM-list size beyond which JOIN " "constructs are not flattened."),

   ("The planner will flatten explicit JOIN " "constructs into lists of FROM items whenever a " "list of no more than this many items would result.")


  },
  &join_collapse_limit,
  8, 1, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"geqo_threshold", PGC_USERSET, QUERY_TUNING_GEQO,
   ("Sets the threshold of FROM items beyond which GEQO is used."),
   ((void *)0)
  },
  &geqo_threshold,
  12, 2, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"geqo_effort", PGC_USERSET, QUERY_TUNING_GEQO,
   ("GEQO: effort is used to set the default for other GEQO parameters."),
   ((void *)0)
  },
  &Geqo_effort,
  5, 1, 10,
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"geqo_pool_size", PGC_USERSET, QUERY_TUNING_GEQO,
   ("GEQO: number of individuals in the population."),
   ("Zero selects a suitable default value.")
  },
  &Geqo_pool_size,
  0, 0, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"geqo_generations", PGC_USERSET, QUERY_TUNING_GEQO,
   ("GEQO: number of iterations of the algorithm."),
   ("Zero selects a suitable default value.")
  },
  &Geqo_generations,
  0, 0, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {

  {"deadlock_timeout", PGC_SUSET, LOCK_MANAGEMENT,
   ("Sets the time to wait on a lock before checking for deadlock."),
   ((void *)0),
   0x1000
  },
  &DeadlockTimeout,
  1000, 1, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"max_standby_archive_delay", PGC_SIGHUP, REPLICATION_STANDBY,
   ("Sets the maximum delay before canceling queries when a hot standby server is processing archived WAL data."),
   ((void *)0),
   0x1000
  },
  &max_standby_archive_delay,
  30 * 1000, -1, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"max_standby_streaming_delay", PGC_SIGHUP, REPLICATION_STANDBY,
   ("Sets the maximum delay before canceling queries when a hot standby server is processing streamed WAL data."),
   ((void *)0),
   0x1000
  },
  &max_standby_streaming_delay,
  30 * 1000, -1, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"wal_receiver_status_interval", PGC_SIGHUP, REPLICATION_STANDBY,
   ("Sets the maximum interval between WAL receiver status reports to the primary."),
   ((void *)0),
   0x2000
  },
  &wal_receiver_status_interval,
  10, 0, 2147483647 / 1000,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"max_connections", PGC_POSTMASTER, CONN_AUTH_SETTINGS,
   ("Sets the maximum number of concurrent connections."),
   ((void *)0)
  },
  &MaxConnections,
  100, 1, 0x7fffff,
  check_maxconnections, assign_maxconnections, ((void *)0)
 },

 {
  {"superuser_reserved_connections", PGC_POSTMASTER, CONN_AUTH_SETTINGS,
   ("Sets the number of connection slots reserved for superusers."),
   ((void *)0)
  },
  &ReservedBackends,
  3, 0, 0x7fffff,
  ((void *)0), ((void *)0), ((void *)0)
 },





 {
  {"shared_buffers", PGC_POSTMASTER, RESOURCES_MEM,
   ("Sets the number of shared memory buffers used by the server."),
   ((void *)0),
   0x0800
  },
  &NBuffers,
  1024, 16, 2147483647 / 2,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"temp_buffers", PGC_USERSET, RESOURCES_MEM,
   ("Sets the maximum number of temporary buffers used by each session."),
   ((void *)0),
   0x0800
  },
  &num_temp_buffers,
  1024, 100, 2147483647 / 2,
  check_temp_buffers, ((void *)0), ((void *)0)
 },

 {
  {"port", PGC_POSTMASTER, CONN_AUTH_SETTINGS,
   ("Sets the TCP port the server listens on."),
   ((void *)0)
  },
  &PostPortNumber,
  5432, 1, 65535,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"unix_socket_permissions", PGC_POSTMASTER, CONN_AUTH_SETTINGS,
   ("Sets the access permissions of the Unix-domain socket."),
   ("Unix-domain sockets use the usual Unix file system " "permission set. The parameter value is expected " "to be a numeric mode specification in the form " "accepted by the chmod and umask system calls. " "(To use the customary octal format the number must " "start with a 0 (zero).)")





  },
  &Unix_socket_permissions,
  0777, 0000, 0777,
  ((void *)0), ((void *)0), show_unix_socket_permissions
 },

 {
  {"log_file_mode", PGC_SIGHUP, LOGGING_WHERE,
   ("Sets the file permissions for log files."),
   ("The parameter value is expected " "to be a numeric mode specification in the form " "accepted by the chmod and umask system calls. " "(To use the customary octal format the number must " "start with a 0 (zero).)")




  },
  &Log_file_mode,
  0600, 0000, 0777,
  ((void *)0), ((void *)0), show_log_file_mode
 },

 {
  {"work_mem", PGC_USERSET, RESOURCES_MEM,
   ("Sets the maximum memory to be used for query workspaces."),
   ("This much memory can be used by each internal " "sort operation and hash table before switching to " "temporary disk files."),


   0x0400
  },
  &work_mem,
  1024, 64, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"maintenance_work_mem", PGC_USERSET, RESOURCES_MEM,
   ("Sets the maximum memory to be used for maintenance operations."),
   ("This includes operations such as VACUUM and CREATE INDEX."),
   0x0400
  },
  &maintenance_work_mem,
  16384, 1024, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },






 {
  {"max_stack_depth", PGC_SUSET, RESOURCES_MEM,
   ("Sets the maximum stack depth, in kilobytes."),
   ((void *)0),
   0x0400
  },
  &max_stack_depth,
  100, 100, 2147483647,
  check_max_stack_depth, assign_max_stack_depth, ((void *)0)
 },

 {
  {"temp_file_limit", PGC_SUSET, RESOURCES_DISK,
   ("Limits the total size of all temporary files used by each session."),
   ("-1 means no limit."),
   0x0400
  },
  &temp_file_limit,
  -1, -1, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"vacuum_cost_page_hit", PGC_USERSET, RESOURCES_VACUUM_DELAY,
   ("Vacuum cost for a page found in the buffer cache."),
   ((void *)0)
  },
  &VacuumCostPageHit,
  1, 0, 10000,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"vacuum_cost_page_miss", PGC_USERSET, RESOURCES_VACUUM_DELAY,
   ("Vacuum cost for a page not found in the buffer cache."),
   ((void *)0)
  },
  &VacuumCostPageMiss,
  10, 0, 10000,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"vacuum_cost_page_dirty", PGC_USERSET, RESOURCES_VACUUM_DELAY,
   ("Vacuum cost for a page dirtied by vacuum."),
   ((void *)0)
  },
  &VacuumCostPageDirty,
  20, 0, 10000,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"vacuum_cost_limit", PGC_USERSET, RESOURCES_VACUUM_DELAY,
   ("Vacuum cost amount available before napping."),
   ((void *)0)
  },
  &VacuumCostLimit,
  200, 1, 10000,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"vacuum_cost_delay", PGC_USERSET, RESOURCES_VACUUM_DELAY,
   ("Vacuum cost delay in milliseconds."),
   ((void *)0),
   0x1000
  },
  &VacuumCostDelay,
  0, 0, 100,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"autovacuum_vacuum_cost_delay", PGC_SIGHUP, AUTOVACUUM,
   ("Vacuum cost delay in milliseconds, for autovacuum."),
   ((void *)0),
   0x1000
  },
  &autovacuum_vac_cost_delay,
  20, -1, 100,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"autovacuum_vacuum_cost_limit", PGC_SIGHUP, AUTOVACUUM,
   ("Vacuum cost amount available before napping, for autovacuum."),
   ((void *)0)
  },
  &autovacuum_vac_cost_limit,
  -1, -1, 10000,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"max_files_per_process", PGC_POSTMASTER, RESOURCES_KERNEL,
   ("Sets the maximum number of simultaneously open files for each server process."),
   ((void *)0)
  },
  &max_files_per_process,
  1000, 25, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },




 {
  {"max_prepared_transactions", PGC_POSTMASTER, RESOURCES_MEM,
   ("Sets the maximum number of simultaneously prepared transactions."),
   ((void *)0)
  },
  &max_prepared_xacts,
  0, 0, 0x7fffff,
  ((void *)0), ((void *)0), ((void *)0)
 },
# 1851 "guc.c"
 {
  {"statement_timeout", PGC_USERSET, CLIENT_CONN_STATEMENT,
   ("Sets the maximum allowed duration of any statement."),
   ("A value of 0 turns off the timeout."),
   0x1000
  },
  &StatementTimeout,
  0, 0, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"vacuum_freeze_min_age", PGC_USERSET, CLIENT_CONN_STATEMENT,
   ("Minimum age at which VACUUM should freeze a table row."),
   ((void *)0)
  },
  &vacuum_freeze_min_age,
  50000000, 0, 1000000000,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"vacuum_freeze_table_age", PGC_USERSET, CLIENT_CONN_STATEMENT,
   ("Age at which VACUUM should scan whole table to freeze tuples."),
   ((void *)0)
  },
  &vacuum_freeze_table_age,
  150000000, 0, 2000000000,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"vacuum_defer_cleanup_age", PGC_SIGHUP, REPLICATION_MASTER,
   ("Number of transactions by which VACUUM and HOT cleanup should be deferred, if any."),
   ((void *)0)
  },
  &vacuum_defer_cleanup_age,
  0, 0, 1000000,
  ((void *)0), ((void *)0), ((void *)0)
 },




 {
  {"max_locks_per_transaction", PGC_POSTMASTER, LOCK_MANAGEMENT,
   ("Sets the maximum number of locks per transaction."),
   ("The shared lock table is sized on the assumption that " "at most max_locks_per_transaction * max_connections distinct " "objects will need to be locked at any one time.")


  },
  &max_locks_per_xact,
  64, 10, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"max_pred_locks_per_transaction", PGC_POSTMASTER, LOCK_MANAGEMENT,
   ("Sets the maximum number of predicate locks per transaction."),
   ("The shared predicate lock table is sized on the assumption that " "at most max_pred_locks_per_transaction * max_connections distinct " "objects will need to be locked at any one time.")


  },
  &max_predicate_locks_per_xact,
  64, 10, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"authentication_timeout", PGC_SIGHUP, CONN_AUTH_SECURITY,
   ("Sets the maximum allowed time to complete client authentication."),
   ((void *)0),
   0x2000
  },
  &AuthenticationTimeout,
  60, 1, 600,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {

  {"pre_auth_delay", PGC_SIGHUP, DEVELOPER_OPTIONS,
   ("Waits N seconds on connection startup before authentication."),
   ("This allows attaching a debugger to the process."),
   0x0020 | 0x2000
  },
  &PreAuthDelay,
  0, 0, 60,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"wal_keep_segments", PGC_SIGHUP, REPLICATION_SENDING,
   ("Sets the number of WAL files held for standby servers."),
   ((void *)0)
  },
  &wal_keep_segments,
  0, 0, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"checkpoint_segments", PGC_SIGHUP, WAL_CHECKPOINTS,
   ("Sets the maximum distance in log segments between automatic WAL checkpoints."),
   ((void *)0)
  },
  &CheckPointSegments,
  3, 1, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"checkpoint_timeout", PGC_SIGHUP, WAL_CHECKPOINTS,
   ("Sets the maximum time between automatic WAL checkpoints."),
   ((void *)0),
   0x2000
  },
  &CheckPointTimeout,
  300, 30, 3600,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"checkpoint_warning", PGC_SIGHUP, WAL_CHECKPOINTS,
   ("Enables warnings if checkpoint segments are filled more " "frequently than this."),

   ("Write a message to the server log if checkpoints " "caused by the filling of checkpoint segment files happens more " "frequently than this number of seconds. Zero turns off the warning."),


   0x2000
  },
  &CheckPointWarning,
  30, 0, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"wal_buffers", PGC_POSTMASTER, WAL_SETTINGS,
   ("Sets the number of disk-page buffers in shared memory for WAL."),
   ((void *)0),
   0x0C00
  },
  &XLOGbuffers,
  -1, -1, 2147483647,
  check_wal_buffers, ((void *)0), ((void *)0)
 },

 {
  {"wal_writer_delay", PGC_SIGHUP, WAL_SETTINGS,
   ("WAL writer sleep time between WAL flushes."),
   ((void *)0),
   0x1000
  },
  &WalWriterDelay,
  200, 1, 10000,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {

  {"max_wal_senders", PGC_POSTMASTER, REPLICATION_SENDING,
   ("Sets the maximum number of simultaneously running WAL sender processes."),
   ((void *)0)
  },
  &max_wal_senders,
  0, 0, 0x7fffff,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"replication_timeout", PGC_SIGHUP, REPLICATION_SENDING,
   ("Sets the maximum time to wait for WAL replication."),
   ((void *)0),
   0x1000
  },
  &replication_timeout,
  60 * 1000, 0, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"commit_delay", PGC_USERSET, WAL_SETTINGS,
   ("Sets the delay in microseconds between transaction commit and " "flushing WAL to disk."),

   ((void *)0)
  },
  &CommitDelay,
  0, 0, 100000,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"commit_siblings", PGC_USERSET, WAL_SETTINGS,
   ("Sets the minimum concurrent open transactions before performing " "commit_delay."),

   ((void *)0)
  },
  &CommitSiblings,
  5, 0, 1000,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"extra_float_digits", PGC_USERSET, CLIENT_CONN_LOCALE,
   ("Sets the number of digits displayed for floating-point values."),
   ("This affects real, double precision, and geometric data types. " "The parameter value is added to the standard number of digits " "(FLT_DIG or DBL_DIG as appropriate).")


  },
  &extra_float_digits,
  0, -15, 3,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"log_min_duration_statement", PGC_SUSET, LOGGING_WHEN,
   ("Sets the minimum execution time above which " "statements will be logged."),

   ("Zero prints all queries. -1 turns this feature off."),
   0x1000
  },
  &log_min_duration_statement,
  -1, -1, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"log_autovacuum_min_duration", PGC_SIGHUP, LOGGING_WHAT,
   ("Sets the minimum execution time above which " "autovacuum actions will be logged."),

   ("Zero prints all actions. -1 turns autovacuum logging off."),
   0x1000
  },
  &Log_autovacuum_min_duration,
  -1, -1, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"bgwriter_delay", PGC_SIGHUP, RESOURCES_BGWRITER,
   ("Background writer sleep time between rounds."),
   ((void *)0),
   0x1000
  },
  &BgWriterDelay,
  200, 10, 10000,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"bgwriter_lru_maxpages", PGC_SIGHUP, RESOURCES_BGWRITER,
   ("Background writer maximum number of LRU pages to flush per round."),
   ((void *)0)
  },
  &bgwriter_lru_maxpages,
  100, 0, 1000,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"effective_io_concurrency",



   PGC_INTERNAL,

   RESOURCES_ASYNCHRONOUS,
   ("Number of simultaneous requests that can be handled efficiently by the disk subsystem."),
   ("For RAID arrays, this should be approximately the number of drive spindles in the array.")
  },
  &effective_io_concurrency,



  0, 0, 0,

  check_effective_io_concurrency, assign_effective_io_concurrency, ((void *)0)
 },

 {
  {"log_rotation_age", PGC_SIGHUP, LOGGING_WHERE,
   ("Automatic log file rotation will occur after N minutes."),
   ((void *)0),
   0x4000
  },
  &Log_RotationAge,
  24 * 60, 0, 2147483647 / 60,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"log_rotation_size", PGC_SIGHUP, LOGGING_WHERE,
   ("Automatic log file rotation will occur after N kilobytes."),
   ((void *)0),
   0x0400
  },
  &Log_RotationSize,
  10 * 1024, 0, 2147483647 / 1024,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"max_function_args", PGC_INTERNAL, PRESET_OPTIONS,
   ("Shows the maximum number of function arguments."),
   ((void *)0),
   0x0020 | 0x0040
  },
  &max_function_args,
  100, 100, 100,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"max_index_keys", PGC_INTERNAL, PRESET_OPTIONS,
   ("Shows the maximum number of index keys."),
   ((void *)0),
   0x0020 | 0x0040
  },
  &max_index_keys,
  32, 32, 32,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"max_identifier_length", PGC_INTERNAL, PRESET_OPTIONS,
   ("Shows the maximum identifier length."),
   ((void *)0),
   0x0020 | 0x0040
  },
  &max_identifier_length,
  64 - 1, 64 - 1, 64 - 1,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"block_size", PGC_INTERNAL, PRESET_OPTIONS,
   ("Shows the size of a disk block."),
   ((void *)0),
   0x0020 | 0x0040
  },
  &block_size,
  8192, 8192, 8192,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"segment_size", PGC_INTERNAL, PRESET_OPTIONS,
   ("Shows the number of pages per disk file."),
   ((void *)0),
   0x0800 | 0x0020 | 0x0040
  },
  &segment_size,
  131072, 131072, 131072,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"wal_block_size", PGC_INTERNAL, PRESET_OPTIONS,
   ("Shows the block size in the write ahead log."),
   ((void *)0),
   0x0020 | 0x0040
  },
  &wal_block_size,
  8192, 8192, 8192,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"wal_segment_size", PGC_INTERNAL, PRESET_OPTIONS,
   ("Shows the number of pages per write ahead log segment."),
   ((void *)0),
   0x0C00 | 0x0020 | 0x0040
  },
  &wal_segment_size,
  ((16 * 1024 * 1024) / 8192),
  ((16 * 1024 * 1024) / 8192),
  ((16 * 1024 * 1024) / 8192),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"autovacuum_naptime", PGC_SIGHUP, AUTOVACUUM,
   ("Time to sleep between autovacuum runs."),
   ((void *)0),
   0x2000
  },
  &autovacuum_naptime,
  60, 1, 2147483647 / 1000,
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"autovacuum_vacuum_threshold", PGC_SIGHUP, AUTOVACUUM,
   ("Minimum number of tuple updates or deletes prior to vacuum."),
   ((void *)0)
  },
  &autovacuum_vac_thresh,
  50, 0, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"autovacuum_analyze_threshold", PGC_SIGHUP, AUTOVACUUM,
   ("Minimum number of tuple inserts, updates, or deletes prior to analyze."),
   ((void *)0)
  },
  &autovacuum_anl_thresh,
  50, 0, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },
 {

  {"autovacuum_freeze_max_age", PGC_POSTMASTER, AUTOVACUUM,
   ("Age at which to autovacuum a table to prevent transaction ID wraparound."),
   ((void *)0)
  },
  &autovacuum_freeze_max_age,

  200000000, 100000000, 2000000000,
  ((void *)0), ((void *)0), ((void *)0)
 },
 {

  {"autovacuum_max_workers", PGC_POSTMASTER, AUTOVACUUM,
   ("Sets the maximum number of simultaneously running autovacuum worker processes."),
   ((void *)0)
  },
  &autovacuum_max_workers,
  3, 1, 0x7fffff,
  check_autovacuum_max_workers, assign_autovacuum_max_workers, ((void *)0)
 },

 {
  {"tcp_keepalives_idle", PGC_USERSET, CLIENT_CONN_OTHER,
   ("Time between issuing TCP keepalives."),
   ("A value of 0 uses the system default."),
   0x2000
  },
  &tcp_keepalives_idle,
  0, 0, 2147483647,
  ((void *)0), assign_tcp_keepalives_idle, show_tcp_keepalives_idle
 },

 {
  {"tcp_keepalives_interval", PGC_USERSET, CLIENT_CONN_OTHER,
   ("Time between TCP keepalive retransmits."),
   ("A value of 0 uses the system default."),
   0x2000
  },
  &tcp_keepalives_interval,
  0, 0, 2147483647,
  ((void *)0), assign_tcp_keepalives_interval, show_tcp_keepalives_interval
 },

 {
  {"ssl_renegotiation_limit", PGC_USERSET, CONN_AUTH_SECURITY,
   ("Set the amount of traffic to send and receive before renegotiating the encryption keys."),
   ((void *)0),
   0x0400,
  },
  &ssl_renegotiation_limit,
  512 * 1024, 0, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"tcp_keepalives_count", PGC_USERSET, CLIENT_CONN_OTHER,
   ("Maximum number of TCP keepalive retransmits."),
   ("This controls the number of consecutive keepalive retransmits that can be " "lost before a connection is considered dead. A value of 0 uses the " "system default."),


  },
  &tcp_keepalives_count,
  0, 0, 2147483647,
  ((void *)0), assign_tcp_keepalives_count, show_tcp_keepalives_count
 },

 {
  {"gin_fuzzy_search_limit", PGC_USERSET, CLIENT_CONN_OTHER,
   ("Sets the maximum allowed result for exact search by GIN."),
   ((void *)0),
   0
  },
  &GinFuzzySearchLimit,
  0, 0, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"effective_cache_size", PGC_USERSET, QUERY_TUNING_COST,
   ("Sets the planner's assumption about the size of the disk cache."),
   ("That is, the portion of the kernel's disk cache that " "will be used for PostgreSQL data files. This is measured in disk " "pages, which are normally 8 kB each."),


   0x0800,
  },
  &effective_cache_size,
  16384, 1, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {

  {"server_version_num", PGC_INTERNAL, PRESET_OPTIONS,
   ("Shows the server version as an integer."),
   ((void *)0),
   0x0020 | 0x0040
  },
  &server_version_num,
  90204, 90204, 90204,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"log_temp_files", PGC_SUSET, LOGGING_WHAT,
   ("Log the use of temporary files larger than this number of kilobytes."),
   ("Zero logs all files. The default is -1 (turning this feature off)."),
   0x0400
  },
  &log_temp_files,
  -1, -1, 2147483647,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"track_activity_query_size", PGC_POSTMASTER, RESOURCES_MEM,
   ("Sets the size reserved for pg_stat_activity.query, in bytes."),
   ((void *)0),
  },
  &pgstat_track_activity_query_size,
  1024, 100, 102400,
  ((void *)0), ((void *)0), ((void *)0)
 },


 {
  {((void *)0), 0, 0, ((void *)0), ((void *)0)}, ((void *)0), 0, 0, 0, ((void *)0), ((void *)0), ((void *)0)
 }
};


static struct config_real ConfigureNamesReal[] =
{
 {
  {"seq_page_cost", PGC_USERSET, QUERY_TUNING_COST,
   ("Sets the planner's estimate of the cost of a " "sequentially fetched disk page."),

   ((void *)0)
  },
  &seq_page_cost,
  1.0, 0, 1.7976931348623157e+308,
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"random_page_cost", PGC_USERSET, QUERY_TUNING_COST,
   ("Sets the planner's estimate of the cost of a " "nonsequentially fetched disk page."),

   ((void *)0)
  },
  &random_page_cost,
  4.0, 0, 1.7976931348623157e+308,
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"cpu_tuple_cost", PGC_USERSET, QUERY_TUNING_COST,
   ("Sets the planner's estimate of the cost of " "processing each tuple (row)."),

   ((void *)0)
  },
  &cpu_tuple_cost,
  0.01, 0, 1.7976931348623157e+308,
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"cpu_index_tuple_cost", PGC_USERSET, QUERY_TUNING_COST,
   ("Sets the planner's estimate of the cost of " "processing each index entry during an index scan."),

   ((void *)0)
  },
  &cpu_index_tuple_cost,
  0.005, 0, 1.7976931348623157e+308,
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"cpu_operator_cost", PGC_USERSET, QUERY_TUNING_COST,
   ("Sets the planner's estimate of the cost of " "processing each operator or function call."),

   ((void *)0)
  },
  &cpu_operator_cost,
  0.0025, 0, 1.7976931348623157e+308,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"cursor_tuple_fraction", PGC_USERSET, QUERY_TUNING_OTHER,
   ("Sets the planner's estimate of the fraction of " "a cursor's rows that will be retrieved."),

   ((void *)0)
  },
  &cursor_tuple_fraction,
  0.1, 0.0, 1.0,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"geqo_selection_bias", PGC_USERSET, QUERY_TUNING_GEQO,
   ("GEQO: selective pressure within the population."),
   ((void *)0)
  },
  &Geqo_selection_bias,
  2.0,
  1.5, 2.0,
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"geqo_seed", PGC_USERSET, QUERY_TUNING_GEQO,
   ("GEQO: seed for random path selection."),
   ((void *)0)
  },
  &Geqo_seed,
  0.0, 0.0, 1.0,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"bgwriter_lru_multiplier", PGC_SIGHUP, RESOURCES_BGWRITER,
   ("Multiple of the average buffer usage to free per round."),
   ((void *)0)
  },
  &bgwriter_lru_multiplier,
  2.0, 0.0, 10.0,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"seed", PGC_USERSET, UNGROUPED,
   ("Sets the seed for random-number generation."),
   ((void *)0),
   0x0004 | 0x0008 | 0x0020 | 0x0040
  },
  &phony_random_seed,
  0.0, -1.0, 1.0,
  check_random_seed, assign_random_seed, show_random_seed
 },

 {
  {"autovacuum_vacuum_scale_factor", PGC_SIGHUP, AUTOVACUUM,
   ("Number of tuple updates or deletes prior to vacuum as a fraction of reltuples."),
   ((void *)0)
  },
  &autovacuum_vac_scale,
  0.2, 0.0, 100.0,
  ((void *)0), ((void *)0), ((void *)0)
 },
 {
  {"autovacuum_analyze_scale_factor", PGC_SIGHUP, AUTOVACUUM,
   ("Number of tuple inserts, updates, or deletes prior to analyze as a fraction of reltuples."),
   ((void *)0)
  },
  &autovacuum_anl_scale,
  0.1, 0.0, 100.0,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"checkpoint_completion_target", PGC_SIGHUP, WAL_CHECKPOINTS,
   ("Time spent flushing dirty buffers during checkpoint, as fraction of checkpoint interval."),
   ((void *)0)
  },
  &CheckPointCompletionTarget,
  0.5, 0.0, 1.0,
  ((void *)0), ((void *)0), ((void *)0)
 },


 {
  {((void *)0), 0, 0, ((void *)0), ((void *)0)}, ((void *)0), 0.0, 0.0, 0.0, ((void *)0), ((void *)0), ((void *)0)
 }
};


static struct config_string ConfigureNamesString[] =
{
 {
  {"archive_command", PGC_SIGHUP, WAL_ARCHIVING,
   ("Sets the shell command that will be called to archive a WAL file."),
   ((void *)0)
  },
  &XLogArchiveCommand,
  "",
  ((void *)0), ((void *)0), show_archive_command
 },

 {
  {"client_encoding", PGC_USERSET, CLIENT_CONN_LOCALE,
   ("Sets the client's character set encoding."),
   ((void *)0),
   0x0200 | 0x0010
  },
  &client_encoding_string,
  "SQL_ASCII",
  check_client_encoding, assign_client_encoding, ((void *)0)
 },

 {
  {"log_line_prefix", PGC_SIGHUP, LOGGING_WHAT,
   ("Controls information prefixed to each log line."),
   ("If blank, no prefix is used.")
  },
  &Log_line_prefix,
  "",
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"log_timezone", PGC_SIGHUP, LOGGING_WHAT,
   ("Sets the time zone to use in log messages."),
   ((void *)0)
  },
  &log_timezone_string,
  "GMT",
  check_log_timezone, assign_log_timezone, show_log_timezone
 },

 {
  {"DateStyle", PGC_USERSET, CLIENT_CONN_LOCALE,
   ("Sets the display format for date and time values."),
   ("Also controls interpretation of ambiguous " "date inputs."),

   0x0001 | 0x0010
  },
  &datestyle_string,
  "ISO, MDY",
  check_datestyle, assign_datestyle, ((void *)0)
 },

 {
  {"default_tablespace", PGC_USERSET, CLIENT_CONN_STATEMENT,
   ("Sets the default tablespace to create tables and indexes in."),
   ("An empty string selects the database's default tablespace."),
   0x0200
  },
  &default_tablespace,
  "",
  check_default_tablespace, ((void *)0), ((void *)0)
 },

 {
  {"temp_tablespaces", PGC_USERSET, CLIENT_CONN_STATEMENT,
   ("Sets the tablespace(s) to use for temporary tables and sort files."),
   ((void *)0),
   0x0001 | 0x0002
  },
  &temp_tablespaces,
  "",
  check_temp_tablespaces, assign_temp_tablespaces, ((void *)0)
 },

 {
  {"dynamic_library_path", PGC_SUSET, CLIENT_CONN_OTHER,
   ("Sets the path for dynamically loadable modules."),
   ("If a dynamically loadable module needs to be opened and " "the specified name does not have a directory component (i.e., the " "name does not contain a slash), the system will search this path for " "the specified file."),



   0x0100
  },
  &Dynamic_library_path,
  "$libdir",
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"krb_server_keyfile", PGC_SIGHUP, CONN_AUTH_SECURITY,
   ("Sets the location of the Kerberos server key file."),
   ((void *)0),
   0x0100
  },
  &pg_krb_server_keyfile,
  "",
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"krb_srvname", PGC_SIGHUP, CONN_AUTH_SECURITY,
   ("Sets the name of the Kerberos service."),
   ((void *)0)
  },
  &pg_krb_srvnam,
  "postgres",
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"bonjour_name", PGC_POSTMASTER, CONN_AUTH_SETTINGS,
   ("Sets the Bonjour service name."),
   ((void *)0)
  },
  &bonjour_name,
  "",
  ((void *)0), ((void *)0), ((void *)0)
 },



 {
  {"lc_collate", PGC_INTERNAL, CLIENT_CONN_LOCALE,
   ("Shows the collation order locale."),
   ((void *)0),
   0x0020 | 0x0040
  },
  &locale_collate,
  "C",
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"lc_ctype", PGC_INTERNAL, CLIENT_CONN_LOCALE,
   ("Shows the character classification and case conversion locale."),
   ((void *)0),
   0x0020 | 0x0040
  },
  &locale_ctype,
  "C",
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"lc_messages", PGC_SUSET, CLIENT_CONN_LOCALE,
   ("Sets the language in which messages are displayed."),
   ((void *)0)
  },
  &locale_messages,
  "",
  check_locale_messages, assign_locale_messages, ((void *)0)
 },

 {
  {"lc_monetary", PGC_USERSET, CLIENT_CONN_LOCALE,
   ("Sets the locale for formatting monetary amounts."),
   ((void *)0)
  },
  &locale_monetary,
  "C",
  check_locale_monetary, assign_locale_monetary, ((void *)0)
 },

 {
  {"lc_numeric", PGC_USERSET, CLIENT_CONN_LOCALE,
   ("Sets the locale for formatting numbers."),
   ((void *)0)
  },
  &locale_numeric,
  "C",
  check_locale_numeric, assign_locale_numeric, ((void *)0)
 },

 {
  {"lc_time", PGC_USERSET, CLIENT_CONN_LOCALE,
   ("Sets the locale for formatting date and time values."),
   ((void *)0)
  },
  &locale_time,
  "C",
  check_locale_time, assign_locale_time, ((void *)0)
 },

 {
  {"shared_preload_libraries", PGC_POSTMASTER, RESOURCES_KERNEL,
   ("Lists shared libraries to preload into server."),
   ((void *)0),
   0x0001 | 0x0002 | 0x0100
  },
  &shared_preload_libraries_string,
  "",
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"local_preload_libraries", PGC_BACKEND, CLIENT_CONN_OTHER,
   ("Lists shared libraries to preload into each backend."),
   ((void *)0),
   0x0001 | 0x0002
  },
  &local_preload_libraries_string,
  "",
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"search_path", PGC_USERSET, CLIENT_CONN_STATEMENT,
   ("Sets the schema search order for names that are not schema-qualified."),
   ((void *)0),
   0x0001 | 0x0002
  },
  &namespace_search_path,
  "\"$user\",public",
  check_search_path, assign_search_path, ((void *)0)
 },

 {

  {"server_encoding", PGC_INTERNAL, CLIENT_CONN_LOCALE,
   ("Sets the server (database) character set encoding."),
   ((void *)0),
   0x0200 | 0x0010 | 0x0020 | 0x0040
  },
  &server_encoding_string,
  "SQL_ASCII",
  ((void *)0), ((void *)0), ((void *)0)
 },

 {

  {"server_version", PGC_INTERNAL, PRESET_OPTIONS,
   ("Shows the server version."),
   ((void *)0),
   0x0010 | 0x0020 | 0x0040
  },
  &server_version_string,
  "9.2.4",
  ((void *)0), ((void *)0), ((void *)0)
 },

 {

  {"role", PGC_USERSET, UNGROUPED,
   ("Sets the current role."),
   ((void *)0),
   0x0200 | 0x0004 | 0x0008 | 0x0020 | 0x0040 | 0x8000
  },
  &role_string,
  "none",
  check_role, assign_role, show_role
 },

 {

  {"session_authorization", PGC_USERSET, UNGROUPED,
   ("Sets the session user name."),
   ((void *)0),
   0x0200 | 0x0010 | 0x0004 | 0x0008 | 0x0020 | 0x0040 | 0x8000
  },
  &session_authorization_string,
  ((void *)0),
  check_session_authorization, assign_session_authorization, ((void *)0)
 },

 {
  {"log_destination", PGC_SIGHUP, LOGGING_WHERE,
   ("Sets the destination for server log output."),
   ("Valid values are combinations of \"stderr\", " "\"syslog\", \"csvlog\", and \"eventlog\", " "depending on the platform."),


   0x0001
  },
  &log_destination_string,
  "stderr",
  check_log_destination, assign_log_destination, ((void *)0)
 },
 {
  {"log_directory", PGC_SIGHUP, LOGGING_WHERE,
   ("Sets the destination directory for log files."),
   ("Can be specified as relative to the data directory " "or as absolute path."),

   0x0100
  },
  &Log_directory,
  "pg_log",
  check_canonical_path, ((void *)0), ((void *)0)
 },
 {
  {"log_filename", PGC_SIGHUP, LOGGING_WHERE,
   ("Sets the file name pattern for log files."),
   ((void *)0),
   0x0100
  },
  &Log_filename,
  "postgresql-%Y-%m-%d_%H%M%S.log",
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"syslog_ident", PGC_SIGHUP, LOGGING_WHERE,
   ("Sets the program name used to identify PostgreSQL " "messages in syslog."),

   ((void *)0)
  },
  &syslog_ident_str,
  "postgres",
  ((void *)0), assign_syslog_ident, ((void *)0)
 },

 {
  {"event_source", PGC_POSTMASTER, LOGGING_WHERE,
   ("Sets the application name used to identify " "PostgreSQL messages in the event log."),

   ((void *)0)
  },
  &event_source,
  "PostgreSQL",
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"TimeZone", PGC_USERSET, CLIENT_CONN_LOCALE,
   ("Sets the time zone for displaying and interpreting time stamps."),
   ((void *)0),
   0x0010
  },
  &timezone_string,
  "GMT",
  check_timezone, assign_timezone, show_timezone
 },
 {
  {"timezone_abbreviations", PGC_USERSET, CLIENT_CONN_LOCALE,
   ("Selects a file of time zone abbreviations."),
   ((void *)0)
  },
  &timezone_abbreviations_string,
  ((void *)0),
  check_timezone_abbreviations, assign_timezone_abbreviations, ((void *)0)
 },

 {
  {"transaction_isolation", PGC_USERSET, CLIENT_CONN_STATEMENT,
   ("Sets the current transaction's isolation level."),
   ((void *)0),
   0x0008 | 0x0020 | 0x0040
  },
  &XactIsoLevel_string,
  "default",
  check_XactIsoLevel, assign_XactIsoLevel, show_XactIsoLevel
 },

 {
  {"unix_socket_group", PGC_POSTMASTER, CONN_AUTH_SETTINGS,
   ("Sets the owning group of the Unix-domain socket."),
   ("The owning user of the socket is always the user " "that starts the server.")

  },
  &Unix_socket_group,
  "",
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"unix_socket_directory", PGC_POSTMASTER, CONN_AUTH_SETTINGS,
   ("Sets the directory where the Unix-domain socket will be created."),
   ((void *)0),
   0x0100
  },
  &UnixSocketDir,
  "",
  check_canonical_path, ((void *)0), ((void *)0)
 },

 {
  {"listen_addresses", PGC_POSTMASTER, CONN_AUTH_SETTINGS,
   ("Sets the host name or IP address(es) to listen to."),
   ((void *)0),
   0x0001
  },
  &ListenAddresses,
  "localhost",
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"data_directory", PGC_POSTMASTER, FILE_LOCATIONS,
   ("Sets the server's data directory."),
   ((void *)0),
   0x0100
  },
  &data_directory,
  ((void *)0),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"config_file", PGC_POSTMASTER, FILE_LOCATIONS,
   ("Sets the server's main configuration file."),
   ((void *)0),
   0x0040 | 0x0100
  },
  &ConfigFileName,
  ((void *)0),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"hba_file", PGC_POSTMASTER, FILE_LOCATIONS,
   ("Sets the server's \"hba\" configuration file."),
   ((void *)0),
   0x0100
  },
  &HbaFileName,
  ((void *)0),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"ident_file", PGC_POSTMASTER, FILE_LOCATIONS,
   ("Sets the server's \"ident\" configuration file."),
   ((void *)0),
   0x0100
  },
  &IdentFileName,
  ((void *)0),
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"external_pid_file", PGC_POSTMASTER, FILE_LOCATIONS,
   ("Writes the postmaster PID to the specified file."),
   ((void *)0),
   0x0100
  },
  &external_pid_file,
  ((void *)0),
  check_canonical_path, ((void *)0), ((void *)0)
 },

 {
  {"ssl_cert_file", PGC_POSTMASTER, CONN_AUTH_SECURITY,
   ("Location of the SSL server certificate file."),
   ((void *)0)
  },
  &ssl_cert_file,
  "server.crt",
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"ssl_key_file", PGC_POSTMASTER, CONN_AUTH_SECURITY,
   ("Location of the SSL server private key file."),
   ((void *)0)
  },
  &ssl_key_file,
  "server.key",
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"ssl_ca_file", PGC_POSTMASTER, CONN_AUTH_SECURITY,
   ("Location of the SSL certificate authority file."),
   ((void *)0)
  },
  &ssl_ca_file,
  "",
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"ssl_crl_file", PGC_POSTMASTER, CONN_AUTH_SECURITY,
   ("Location of the SSL certificate revocation list file."),
   ((void *)0)
  },
  &ssl_crl_file,
  "",
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"stats_temp_directory", PGC_SIGHUP, STATS_COLLECTOR,
   ("Writes temporary statistics files to the specified directory."),
   ((void *)0),
   0x0100
  },
  &pgstat_temp_directory,
  "pg_stat_tmp",
  check_canonical_path, assign_pgstat_temp_directory, ((void *)0)
 },

 {
  {"synchronous_standby_names", PGC_SIGHUP, REPLICATION_MASTER,
   ("List of names of potential synchronous standbys."),
   ((void *)0),
   0x0001
  },
  &SyncRepStandbyNames,
  "",
  check_synchronous_standby_names, ((void *)0), ((void *)0)
 },

 {
  {"default_text_search_config", PGC_USERSET, CLIENT_CONN_LOCALE,
   ("Sets default text search configuration."),
   ((void *)0)
  },
  &TSCurrentConfig,
  "pg_catalog.simple",
  check_TSCurrentConfig, assign_TSCurrentConfig, ((void *)0)
 },

 {
  {"ssl_ciphers", PGC_POSTMASTER, CONN_AUTH_SECURITY,
   ("Sets the list of allowed SSL ciphers."),
   ((void *)0),
   0x0100
  },
  &SSLCipherSuites,



  "none",

  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"application_name", PGC_USERSET, LOGGING_WHAT,
   ("Sets the application name to be reported in statistics and logs."),
   ((void *)0),
   0x0200 | 0x0010 | 0x0020
  },
  &application_name,
  "",
  check_application_name, assign_application_name, ((void *)0)
 },


 {
  {((void *)0), 0, 0, ((void *)0), ((void *)0)}, ((void *)0), ((void *)0), ((void *)0), ((void *)0), ((void *)0)
 }
};


static struct config_enum ConfigureNamesEnum[] =
{
 {
  {"backslash_quote", PGC_USERSET, COMPAT_OPTIONS_PREVIOUS,
   ("Sets whether \"\\'\" is allowed in string literals."),
   ((void *)0)
  },
  &backslash_quote,
  BACKSLASH_QUOTE_SAFE_ENCODING, backslash_quote_options,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"bytea_output", PGC_USERSET, CLIENT_CONN_STATEMENT,
   ("Sets the output format for bytea."),
   ((void *)0)
  },
  &bytea_output,
  BYTEA_OUTPUT_HEX, bytea_output_options,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"client_min_messages", PGC_USERSET, LOGGING_WHEN,
   ("Sets the message levels that are sent to the client."),
   ("Each level includes all the levels that follow it. The later" " the level, the fewer messages are sent.")

  },
  &client_min_messages,
  18, client_message_level_options,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"constraint_exclusion", PGC_USERSET, QUERY_TUNING_OTHER,
   ("Enables the planner to use constraints to optimize queries."),
   ("Table scans will be skipped if their constraints" " guarantee that no rows match the query.")

  },
  &constraint_exclusion,
  CONSTRAINT_EXCLUSION_PARTITION, constraint_exclusion_options,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"default_transaction_isolation", PGC_USERSET, CLIENT_CONN_STATEMENT,
   ("Sets the transaction isolation level of each new transaction."),
   ((void *)0)
  },
  &DefaultXactIsoLevel,
  1, isolation_level_options,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"IntervalStyle", PGC_USERSET, CLIENT_CONN_LOCALE,
   ("Sets the display format for interval values."),
   ((void *)0),
   0x0010
  },
  &IntervalStyle,
  0, intervalstyle_options,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"log_error_verbosity", PGC_SUSET, LOGGING_WHAT,
   ("Sets the verbosity of logged messages."),
   ((void *)0)
  },
  &Log_error_verbosity,
  PGERROR_DEFAULT, log_error_verbosity_options,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"log_min_messages", PGC_SUSET, LOGGING_WHEN,
   ("Sets the message levels that are logged."),
   ("Each level includes all the levels that follow it. The later" " the level, the fewer messages are sent.")

  },
  &log_min_messages,
  19, server_message_level_options,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"log_min_error_statement", PGC_SUSET, LOGGING_WHEN,
   ("Causes all statements generating error at or above this level to be logged."),
   ("Each level includes all the levels that follow it. The later" " the level, the fewer messages are sent.")

  },
  &log_min_error_statement,
  20, server_message_level_options,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"log_statement", PGC_SUSET, LOGGING_WHAT,
   ("Sets the type of statements logged."),
   ((void *)0)
  },
  &log_statement,
  LOGSTMT_NONE, log_statement_options,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"syslog_facility", PGC_SIGHUP, LOGGING_WHERE,
   ("Sets the syslog \"facility\" to be used when syslog enabled."),
   ((void *)0)
  },
  &syslog_facility,

  (16<<3),



  syslog_facility_options,
  ((void *)0), assign_syslog_facility, ((void *)0)
 },

 {
  {"session_replication_role", PGC_SUSET, CLIENT_CONN_STATEMENT,
   ("Sets the session's behavior for triggers and rewrite rules."),
   ((void *)0)
  },
  &SessionReplicationRole,
  0, session_replication_role_options,
  ((void *)0), assign_session_replication_role, ((void *)0)
 },

 {
  {"synchronous_commit", PGC_USERSET, WAL_SETTINGS,
   ("Sets the current transaction's synchronization level."),
   ((void *)0)
  },
  &synchronous_commit,
  SYNCHRONOUS_COMMIT_REMOTE_FLUSH, synchronous_commit_options,
  ((void *)0), assign_synchronous_commit, ((void *)0)
 },

 {
  {"trace_recovery_messages", PGC_SIGHUP, DEVELOPER_OPTIONS,
   ("Enables logging of recovery-related debugging information."),
   ("Each level includes all the levels that follow it. The later" " the level, the fewer messages are sent.")

  },
  &trace_recovery_messages,





  15, client_message_level_options,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"track_functions", PGC_SUSET, STATS_COLLECTOR,
   ("Collects function-level statistics on database activity."),
   ((void *)0)
  },
  &pgstat_track_functions,
  TRACK_FUNC_OFF, track_function_options,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"wal_level", PGC_POSTMASTER, WAL_SETTINGS,
   ("Set the level of information written to the WAL."),
   ((void *)0)
  },
  &wal_level,
  WAL_LEVEL_MINIMAL, wal_level_options,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"wal_sync_method", PGC_SIGHUP, WAL_SETTINGS,
   ("Selects the method used for forcing WAL updates to disk."),
   ((void *)0)
  },
  &sync_method,
  4, sync_method_options,
  ((void *)0), assign_xlog_sync_method, ((void *)0)
 },

 {
  {"xmlbinary", PGC_USERSET, CLIENT_CONN_STATEMENT,
   ("Sets how binary values are to be encoded in XML."),
   ((void *)0)
  },
  &xmlbinary,
  XMLBINARY_BASE64, xmlbinary_options,
  ((void *)0), ((void *)0), ((void *)0)
 },

 {
  {"xmloption", PGC_USERSET, CLIENT_CONN_STATEMENT,
   ("Sets whether XML data in implicit parsing and serialization " "operations is to be considered as documents or content fragments."),

   ((void *)0)
  },
  &xmloption,
  XMLOPTION_CONTENT, xmloption_options,
  ((void *)0), ((void *)0), ((void *)0)
 },



 {
  {((void *)0), 0, 0, ((void *)0), ((void *)0)}, ((void *)0), 0, ((void *)0), ((void *)0), ((void *)0), ((void *)0)
 }
};
# 3303 "guc.c"
static const char *const map_old_guc_names[] = {
 "sort_mem", "work_mem",
 "vacuum_mem", "maintenance_work_mem",
 ((void *)0)
};





static struct config_generic **guc_variables;


static int num_guc_variables;


static int size_guc_variables;


static bool guc_dirty;

static bool reporting_enabled;

static int GUCNestLevel = 0;


static int guc_var_compare(const void *a, const void *b);
static int guc_name_compare(const char *namea, const char *nameb);
static void InitializeGUCOptionsFromEnvironment(void);
static void InitializeOneGUCOption(struct config_generic * gconf);
static void push_old_value(struct config_generic * gconf, GucAction action);
static void ReportGUCOption(struct config_generic * record);
static void reapply_stacked_values(struct config_generic * variable,
        struct config_string * pHolder,
        GucStack *stack,
        const char *curvalue,
        GucContext curscontext, GucSource cursource);
static void ShowGUCConfigOption(const char *name, DestReceiver *dest);
static void ShowAllGUCConfig(DestReceiver *dest);
static char *_ShowOption(struct config_generic * record, bool use_units);
static bool validate_option_array_item(const char *name, const char *value,
         bool skipIfNoPermissions);





static void *
guc_malloc(int elevel, size_t size)
{
 void *data;


 if (size == 0)
  size = 1;
 data = malloc(size);
 if (data == ((void *)0))
  (errstart(elevel, "guc.c", 3362, __func__, ((void *)0)) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('3') - '0') & 0x3F) << 6) + (((('2') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("out of memory"))) : (void) 0);


 return data;
}

static void *
guc_realloc(int elevel, void *old, size_t size)
{
 void *data;


 if (old == ((void *)0) && size == 0)
  size = 1;
 data = realloc(old, size);
 if (data == ((void *)0))
  (errstart(elevel, "guc.c", 3378, __func__, ((void *)0)) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('3') - '0') & 0x3F) << 6) + (((('2') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("out of memory"))) : (void) 0);


 return data;
}

static char *
guc_strdup(int elevel, const char *src)
{
 char *data;

 data = strdup(src);
 if (data == ((void *)0))
  (errstart(elevel, "guc.c", 3391, __func__, ((void *)0)) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('3') - '0') & 0x3F) << 6) + (((('2') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("out of memory"))) : (void) 0);


 return data;
}





static bool
string_field_used(struct config_string * conf, char *strval)
{
 GucStack *stack;

 if (strval == *(conf->variable) ||
  strval == conf->reset_val ||
  strval == conf->boot_val)
  return ((bool) 1);
 for (stack = conf->gen.stack; stack; stack = stack->prev)
 {
  if (strval == stack->prior.val.stringval ||
   strval == stack->masked.val.stringval)
   return ((bool) 1);
 }
 return ((bool) 0);
}






static void
set_string_field(struct config_string * conf, char **field, char *newval)
{
 char *oldval = *field;


 *field = newval;


 if (oldval && !string_field_used(conf, oldval))
  free(oldval);
}




static bool
extra_field_used(struct config_generic * gconf, void *extra)
{
 GucStack *stack;

 if (extra == gconf->extra)
  return ((bool) 1);
 switch (gconf->vartype)
 {
  case PGC_BOOL:
   if (extra == ((struct config_bool *) gconf)->reset_extra)
    return ((bool) 1);
   break;
  case PGC_INT:
   if (extra == ((struct config_int *) gconf)->reset_extra)
    return ((bool) 1);
   break;
  case PGC_REAL:
   if (extra == ((struct config_real *) gconf)->reset_extra)
    return ((bool) 1);
   break;
  case PGC_STRING:
   if (extra == ((struct config_string *) gconf)->reset_extra)
    return ((bool) 1);
   break;
  case PGC_ENUM:
   if (extra == ((struct config_enum *) gconf)->reset_extra)
    return ((bool) 1);
   break;
 }
 for (stack = gconf->stack; stack; stack = stack->prev)
 {
  if (extra == stack->prior.extra ||
   extra == stack->masked.extra)
   return ((bool) 1);
 }

 return ((bool) 0);
}






static void
set_extra_field(struct config_generic * gconf, void **field, void *newval)
{
 void *oldval = *field;


 *field = newval;


 if (oldval && !extra_field_used(gconf, oldval))
  free(oldval);
}
# 3503 "guc.c"
static void
set_stack_value(struct config_generic * gconf, config_var_value *val)
{
 switch (gconf->vartype)
 {
  case PGC_BOOL:
   val->val.boolval =
    *((struct config_bool *) gconf)->variable;
   break;
  case PGC_INT:
   val->val.intval =
    *((struct config_int *) gconf)->variable;
   break;
  case PGC_REAL:
   val->val.realval =
    *((struct config_real *) gconf)->variable;
   break;
  case PGC_STRING:
   set_string_field((struct config_string *) gconf,
        &(val->val.stringval),
        *((struct config_string *) gconf)->variable);
   break;
  case PGC_ENUM:
   val->val.enumval =
    *((struct config_enum *) gconf)->variable;
   break;
 }
 set_extra_field(gconf, &(val->extra), gconf->extra);
}





static void
discard_stack_value(struct config_generic * gconf, config_var_value *val)
{
 switch (gconf->vartype)
 {
  case PGC_BOOL:
  case PGC_INT:
  case PGC_REAL:
  case PGC_ENUM:

   break;
  case PGC_STRING:
   set_string_field((struct config_string *) gconf,
        &(val->val.stringval),
        ((void *)0));
   break;
 }
 set_extra_field(gconf, &(val->extra), ((void *)0));
}





struct config_generic **
get_guc_variables(void)
{
 return guc_variables;
}







void
build_guc_variables(void)
{
 int size_vars;
 int num_vars = 0;
 struct config_generic **guc_vars;
 int i;

 for (i = 0; ConfigureNamesBool[i].gen.name; i++)
 {
  struct config_bool *conf = &ConfigureNamesBool[i];


  conf->gen.vartype = PGC_BOOL;
  num_vars++;
 }

 for (i = 0; ConfigureNamesInt[i].gen.name; i++)
 {
  struct config_int *conf = &ConfigureNamesInt[i];

  conf->gen.vartype = PGC_INT;
  num_vars++;
 }

 for (i = 0; ConfigureNamesReal[i].gen.name; i++)
 {
  struct config_real *conf = &ConfigureNamesReal[i];

  conf->gen.vartype = PGC_REAL;
  num_vars++;
 }

 for (i = 0; ConfigureNamesString[i].gen.name; i++)
 {
  struct config_string *conf = &ConfigureNamesString[i];

  conf->gen.vartype = PGC_STRING;
  num_vars++;
 }

 for (i = 0; ConfigureNamesEnum[i].gen.name; i++)
 {
  struct config_enum *conf = &ConfigureNamesEnum[i];

  conf->gen.vartype = PGC_ENUM;
  num_vars++;
 }




 size_vars = num_vars + num_vars / 4;

 guc_vars = (struct config_generic **)
  guc_malloc(21, size_vars * sizeof(struct config_generic *));

 num_vars = 0;

 for (i = 0; ConfigureNamesBool[i].gen.name; i++)
  guc_vars[num_vars++] = &ConfigureNamesBool[i].gen;

 for (i = 0; ConfigureNamesInt[i].gen.name; i++)
  guc_vars[num_vars++] = &ConfigureNamesInt[i].gen;

 for (i = 0; ConfigureNamesReal[i].gen.name; i++)
  guc_vars[num_vars++] = &ConfigureNamesReal[i].gen;

 for (i = 0; ConfigureNamesString[i].gen.name; i++)
  guc_vars[num_vars++] = &ConfigureNamesString[i].gen;

 for (i = 0; ConfigureNamesEnum[i].gen.name; i++)
  guc_vars[num_vars++] = &ConfigureNamesEnum[i].gen;

 if (guc_variables)
  free(guc_variables);
 guc_variables = guc_vars;
 num_guc_variables = num_vars;
 size_guc_variables = size_vars;
 pg_qsort((void *) guc_variables,num_guc_variables,sizeof(struct config_generic *),guc_var_compare);

}





static bool
add_guc_variable(struct config_generic * var, int elevel)
{
 if (num_guc_variables + 1 >= size_guc_variables)
 {



  int size_vars = size_guc_variables + size_guc_variables / 4;
  struct config_generic **guc_vars;

  if (size_vars == 0)
  {
   size_vars = 100;
   guc_vars = (struct config_generic **)
    guc_malloc(elevel, size_vars * sizeof(struct config_generic *));
  }
  else
  {
   guc_vars = (struct config_generic **)
    guc_realloc(elevel, guc_variables, size_vars * sizeof(struct config_generic *));
  }

  if (guc_vars == ((void *)0))
   return ((bool) 0);

  guc_variables = guc_vars;
  size_guc_variables = size_vars;
 }
 guc_variables[num_guc_variables++] = var;
 pg_qsort((void *) guc_variables,num_guc_variables,sizeof(struct config_generic *),guc_var_compare);

 return ((bool) 1);
}




static struct config_generic *
add_placeholder_variable(const char *name, int elevel)
{
 size_t sz = sizeof(struct config_string) + sizeof(char *);
 struct config_string *var;
 struct config_generic *gen;

 var = (struct config_string *) guc_malloc(elevel, sz);
 if (var == ((void *)0))
  return ((void *)0);
 ((__builtin_object_size (var, 0) != (size_t) -1) ? __builtin___memset_chk (var, 0, sz, __builtin_object_size (var, 0)) : __inline_memset_chk (var, 0, sz));
 gen = &var->gen;

 gen->name = guc_strdup(elevel, name);
 if (gen->name == ((void *)0))
 {
  free(var);
  return ((void *)0);
 }

 gen->context = PGC_USERSET;
 gen->group = CUSTOM_OPTIONS;
 gen->short_desc = "GUC placeholder variable";
 gen->flags = 0x0004 | 0x0020 | 0x0080;
 gen->vartype = PGC_STRING;






 var->variable = (char **) (var + 1);

 if (!add_guc_variable((struct config_generic *) var, elevel))
 {
  free((void *) gen->name);
  free(var);
  return ((void *)0);
 }

 return gen;
}






static struct config_generic *
find_option(const char *name, bool create_placeholders, int elevel)
{
 const char **key = &name;
 struct config_generic **res;
 int i;

 ;





 res = (struct config_generic **) bsearch((void *) &key,
            (void *) guc_variables,
            num_guc_variables,
            sizeof(struct config_generic *),
            guc_var_compare);
 if (res)
  return *res;






 for (i = 0; map_old_guc_names[i] != ((void *)0); i += 2)
 {
  if (guc_name_compare(name, map_old_guc_names[i]) == 0)
   return find_option(map_old_guc_names[i + 1], ((bool) 0), elevel);
 }

 if (create_placeholders)
 {



  if (strchr(name, '.') != ((void *)0))
   return add_placeholder_variable(name, elevel);
 }


 return ((void *)0);
}





static int
guc_var_compare(const void *a, const void *b)
{
 const struct config_generic *confa = *(struct config_generic * const *) a;
 const struct config_generic *confb = *(struct config_generic * const *) b;

 return guc_name_compare(confa->name, confb->name);
}




static int
guc_name_compare(const char *namea, const char *nameb)
{





 while (*namea && *nameb)
 {
  char cha = *namea++;
  char chb = *nameb++;

  if (cha >= 'A' && cha <= 'Z')
   cha += 'a' - 'A';
  if (chb >= 'A' && chb <= 'Z')
   chb += 'a' - 'A';
  if (cha != chb)
   return cha - chb;
 }
 if (*namea)
  return 1;
 if (*nameb)
  return -1;
 return 0;
}
# 3841 "guc.c"
void
InitializeGUCOptions(void)
{
 int i;





 pg_timezone_initialize();




 build_guc_variables();





 for (i = 0; i < num_guc_variables; i++)
 {
  InitializeOneGUCOption(guc_variables[i]);
 }

 guc_dirty = ((bool) 0);

 reporting_enabled = ((bool) 0);





 SetConfigOption("transaction_isolation", "default",
     PGC_POSTMASTER, PGC_S_OVERRIDE);
 SetConfigOption("transaction_read_only", "no",
     PGC_POSTMASTER, PGC_S_OVERRIDE);
 SetConfigOption("transaction_deferrable", "no",
     PGC_POSTMASTER, PGC_S_OVERRIDE);





 InitializeGUCOptionsFromEnvironment();
}
# 3897 "guc.c"
static void
InitializeGUCOptionsFromEnvironment(void)
{
 char *env;
 long stack_rlimit;

 env = getenv("PGPORT");
 if (env != ((void *)0))
  SetConfigOption("port", env, PGC_POSTMASTER, PGC_S_ENV_VAR);

 env = getenv("PGDATESTYLE");
 if (env != ((void *)0))
  SetConfigOption("datestyle", env, PGC_POSTMASTER, PGC_S_ENV_VAR);

 env = getenv("PGCLIENTENCODING");
 if (env != ((void *)0))
  SetConfigOption("client_encoding", env, PGC_POSTMASTER, PGC_S_ENV_VAR);






 stack_rlimit = get_stack_depth_rlimit();
 if (stack_rlimit > 0)
 {
  long new_limit = (stack_rlimit - (512 * 1024L)) / 1024L;

  if (new_limit > 100)
  {
   char limbuf[16];

   new_limit = ((new_limit) < (2048) ? (new_limit) : (2048));
   __builtin___sprintf_chk (limbuf, 0, __builtin_object_size (limbuf, 2 > 1), "%ld", new_limit);
   SetConfigOption("max_stack_depth", limbuf,
       PGC_POSTMASTER, PGC_S_ENV_VAR);
  }
 }
}







static void
InitializeOneGUCOption(struct config_generic * gconf)
{
 gconf->status = 0;
 gconf->source = PGC_S_DEFAULT;
 gconf->reset_source = PGC_S_DEFAULT;
 gconf->scontext = PGC_INTERNAL;
 gconf->reset_scontext = PGC_INTERNAL;
 gconf->stack = ((void *)0);
 gconf->extra = ((void *)0);
 gconf->sourcefile = ((void *)0);
 gconf->sourceline = 0;

 switch (gconf->vartype)
 {
  case PGC_BOOL:
   {
    struct config_bool *conf = (struct config_bool *) gconf;
    bool newval = conf->boot_val;
    void *extra = ((void *)0);

    if (!call_bool_check_hook(conf, &newval, &extra,
            PGC_S_DEFAULT, 15))
     elog_start("guc.c", 3966, __func__), elog_finish(21, "failed to initialize %s to %d",
       conf->gen.name, (int) newval);
    if (conf->assign_hook)
     (*conf->assign_hook) (newval, extra);
    *conf->variable = conf->reset_val = newval;
    conf->gen.extra = conf->reset_extra = extra;
    break;
   }
  case PGC_INT:
   {
    struct config_int *conf = (struct config_int *) gconf;
    int newval = conf->boot_val;
    void *extra = ((void *)0);

    ;
    ;
    if (!call_int_check_hook(conf, &newval, &extra,
           PGC_S_DEFAULT, 15))
     elog_start("guc.c", 3984, __func__), elog_finish(21, "failed to initialize %s to %d",
       conf->gen.name, newval);
    if (conf->assign_hook)
     (*conf->assign_hook) (newval, extra);
    *conf->variable = conf->reset_val = newval;
    conf->gen.extra = conf->reset_extra = extra;
    break;
   }
  case PGC_REAL:
   {
    struct config_real *conf = (struct config_real *) gconf;
    double newval = conf->boot_val;
    void *extra = ((void *)0);

    ;
    ;
    if (!call_real_check_hook(conf, &newval, &extra,
            PGC_S_DEFAULT, 15))
     elog_start("guc.c", 4002, __func__), elog_finish(21, "failed to initialize %s to %g",
       conf->gen.name, newval);
    if (conf->assign_hook)
     (*conf->assign_hook) (newval, extra);
    *conf->variable = conf->reset_val = newval;
    conf->gen.extra = conf->reset_extra = extra;
    break;
   }
  case PGC_STRING:
   {
    struct config_string *conf = (struct config_string *) gconf;
    char *newval;
    void *extra = ((void *)0);


    if (conf->boot_val != ((void *)0))
     newval = guc_strdup(21, conf->boot_val);
    else
     newval = ((void *)0);

    if (!call_string_check_hook(conf, &newval, &extra,
           PGC_S_DEFAULT, 15))
     elog_start("guc.c", 4024, __func__), elog_finish(21, "failed to initialize %s to \"%s\"",
       conf->gen.name, newval ? newval : "");
    if (conf->assign_hook)
     (*conf->assign_hook) (newval, extra);
    *conf->variable = conf->reset_val = newval;
    conf->gen.extra = conf->reset_extra = extra;
    break;
   }
  case PGC_ENUM:
   {
    struct config_enum *conf = (struct config_enum *) gconf;
    int newval = conf->boot_val;
    void *extra = ((void *)0);

    if (!call_enum_check_hook(conf, &newval, &extra,
            PGC_S_DEFAULT, 15))
     elog_start("guc.c", 4040, __func__), elog_finish(21, "failed to initialize %s to %d",
       conf->gen.name, newval);
    if (conf->assign_hook)
     (*conf->assign_hook) (newval, extra);
    *conf->variable = conf->reset_val = newval;
    conf->gen.extra = conf->reset_extra = extra;
    break;
   }
 }
}
# 4063 "guc.c"
bool
SelectConfigFiles(const char *userDoption, const char *progname)
{
 char *configdir;
 char *fname;
 struct stat stat_buf;


 if (userDoption)
  configdir = make_absolute_path(userDoption);
 else
  configdir = make_absolute_path(getenv("PGDATA"));







 if (ConfigFileName)
  fname = make_absolute_path(ConfigFileName);
 else if (configdir)
 {
  fname = guc_malloc(21,
         strlen(configdir) + strlen("postgresql.conf") + 2);
  __builtin___sprintf_chk (fname, 0, __builtin_object_size (fname, 2 > 1), "%s/%s", configdir, "postgresql.conf");
 }
 else
 {
  write_stderr("%s does not know where to find the server configuration file.\n"
      "You must specify the --config-file or -D invocation "
      "option or set the PGDATA environment variable.\n",
      progname);
  return ((bool) 0);
 }





 SetConfigOption("config_file", fname, PGC_POSTMASTER, PGC_S_OVERRIDE);
 free(fname);




 if (stat(ConfigFileName, &stat_buf) != 0)
 {
  write_stderr("%s cannot access the server configuration file \"%s\": %s\n",
      progname, ConfigFileName, strerror((*__error())));
  free(configdir);
  return ((bool) 0);
 }

 ProcessConfigFile(PGC_POSTMASTER);
# 4126 "guc.c"
 if (data_directory)
  SetDataDir(data_directory);
 else if (configdir)
  SetDataDir(configdir);
 else
 {
  write_stderr("%s does not know where to find the database system data.\n"
      "This can be specified as \"data_directory\" in \"%s\", "
      "or by the -D invocation option, or by the "
      "PGDATA environment variable.\n",
      progname, ConfigFileName);
  return ((bool) 0);
 }
# 4148 "guc.c"
 SetConfigOption("data_directory", DataDir, PGC_POSTMASTER, PGC_S_OVERRIDE);
# 4157 "guc.c"
 pg_timezone_abbrev_initialize();




 if (HbaFileName)
  fname = make_absolute_path(HbaFileName);
 else if (configdir)
 {
  fname = guc_malloc(21,
         strlen(configdir) + strlen("pg_hba.conf") + 2);
  __builtin___sprintf_chk (fname, 0, __builtin_object_size (fname, 2 > 1), "%s/%s", configdir, "pg_hba.conf");
 }
 else
 {
  write_stderr("%s does not know where to find the \"hba\" configuration file.\n"
      "This can be specified as \"hba_file\" in \"%s\", "
      "or by the -D invocation option, or by the "
      "PGDATA environment variable.\n",
      progname, ConfigFileName);
  return ((bool) 0);
 }
 SetConfigOption("hba_file", fname, PGC_POSTMASTER, PGC_S_OVERRIDE);
 free(fname);




 if (IdentFileName)
  fname = make_absolute_path(IdentFileName);
 else if (configdir)
 {
  fname = guc_malloc(21,
         strlen(configdir) + strlen("pg_ident.conf") + 2);
  __builtin___sprintf_chk (fname, 0, __builtin_object_size (fname, 2 > 1), "%s/%s", configdir, "pg_ident.conf");
 }
 else
 {
  write_stderr("%s does not know where to find the \"ident\" configuration file.\n"
      "This can be specified as \"ident_file\" in \"%s\", "
      "or by the -D invocation option, or by the "
      "PGDATA environment variable.\n",
      progname, ConfigFileName);
  return ((bool) 0);
 }
 SetConfigOption("ident_file", fname, PGC_POSTMASTER, PGC_S_OVERRIDE);
 free(fname);

 free(configdir);

 return ((bool) 1);
}





void
ResetAllOptions(void)
{
 int i;

 for (i = 0; i < num_guc_variables; i++)
 {
  struct config_generic *gconf = guc_variables[i];


  if (gconf->context != PGC_SUSET &&
   gconf->context != PGC_USERSET)
   continue;

  if (gconf->flags & 0x0008)
   continue;

  if (gconf->source <= PGC_S_OVERRIDE)
   continue;


  push_old_value(gconf, GUC_ACTION_SET);

  switch (gconf->vartype)
  {
   case PGC_BOOL:
    {
     struct config_bool *conf = (struct config_bool *) gconf;

     if (conf->assign_hook)
      (*conf->assign_hook) (conf->reset_val,
             conf->reset_extra);
     *conf->variable = conf->reset_val;
     set_extra_field(&conf->gen, &conf->gen.extra,
         conf->reset_extra);
     break;
    }
   case PGC_INT:
    {
     struct config_int *conf = (struct config_int *) gconf;

     if (conf->assign_hook)
      (*conf->assign_hook) (conf->reset_val,
             conf->reset_extra);
     *conf->variable = conf->reset_val;
     set_extra_field(&conf->gen, &conf->gen.extra,
         conf->reset_extra);
     break;
    }
   case PGC_REAL:
    {
     struct config_real *conf = (struct config_real *) gconf;

     if (conf->assign_hook)
      (*conf->assign_hook) (conf->reset_val,
             conf->reset_extra);
     *conf->variable = conf->reset_val;
     set_extra_field(&conf->gen, &conf->gen.extra,
         conf->reset_extra);
     break;
    }
   case PGC_STRING:
    {
     struct config_string *conf = (struct config_string *) gconf;

     if (conf->assign_hook)
      (*conf->assign_hook) (conf->reset_val,
             conf->reset_extra);
     set_string_field(conf, conf->variable, conf->reset_val);
     set_extra_field(&conf->gen, &conf->gen.extra,
         conf->reset_extra);
     break;
    }
   case PGC_ENUM:
    {
     struct config_enum *conf = (struct config_enum *) gconf;

     if (conf->assign_hook)
      (*conf->assign_hook) (conf->reset_val,
             conf->reset_extra);
     *conf->variable = conf->reset_val;
     set_extra_field(&conf->gen, &conf->gen.extra,
         conf->reset_extra);
     break;
    }
  }

  gconf->source = gconf->reset_source;
  gconf->scontext = gconf->reset_scontext;

  if (gconf->flags & 0x0010)
   ReportGUCOption(gconf);
 }
}






static void
push_old_value(struct config_generic * gconf, GucAction action)
{
 GucStack *stack;


 if (GUCNestLevel == 0)
  return;


 stack = gconf->stack;
 if (stack && stack->nest_level >= GUCNestLevel)
 {

  ;
  switch (action)
  {
   case GUC_ACTION_SET:

    if (stack->state == GUC_SET_LOCAL)
    {

     discard_stack_value(gconf, &stack->masked);
    }
    stack->state = GUC_SET;
    break;
   case GUC_ACTION_LOCAL:
    if (stack->state == GUC_SET)
    {

     stack->masked_scontext = gconf->scontext;
     set_stack_value(gconf, &stack->masked);
     stack->state = GUC_SET_LOCAL;
    }

    break;
   case GUC_ACTION_SAVE:

    ;
    break;
  }
  ;
  return;
 }






 stack = (GucStack *) MemoryContextAllocZero(TopTransactionContext,
            sizeof(GucStack));

 stack->prev = gconf->stack;
 stack->nest_level = GUCNestLevel;
 switch (action)
 {
  case GUC_ACTION_SET:
   stack->state = GUC_SET;
   break;
  case GUC_ACTION_LOCAL:
   stack->state = GUC_LOCAL;
   break;
  case GUC_ACTION_SAVE:
   stack->state = GUC_SAVE;
   break;
 }
 stack->source = gconf->source;
 stack->scontext = gconf->scontext;
 set_stack_value(gconf, &stack->prior);

 gconf->stack = stack;


 guc_dirty = ((bool) 1);
}





void
AtStart_GUC(void)
{





 if (GUCNestLevel != 0)
  elog_start("guc.c", 4404, __func__), elog_finish(19, "GUC nest level = %d at transaction start",
    GUCNestLevel);
 GUCNestLevel = 1;
}







int
NewGUCNestLevel(void)
{
 return ++GUCNestLevel;
}
# 4429 "guc.c"
void
AtEOXact_GUC(bool isCommit, int nestLevel)
{
 bool still_dirty;
 int i;






 ;




 if (!guc_dirty)
 {
  GUCNestLevel = nestLevel - 1;
  return;
 }

 still_dirty = ((bool) 0);
 for (i = 0; i < num_guc_variables; i++)
 {
  struct config_generic *gconf = guc_variables[i];
  GucStack *stack;
# 4464 "guc.c"
  while ((stack = gconf->stack) != ((void *)0) &&
      stack->nest_level >= nestLevel)
  {
   GucStack *prev = stack->prev;
   bool restorePrior = ((bool) 0);
   bool restoreMasked = ((bool) 0);
   bool changed;







   if (!isCommit)
    restorePrior = ((bool) 1);
   else if (stack->state == GUC_SAVE)
    restorePrior = ((bool) 1);
   else if (stack->nest_level == 1)
   {

    if (stack->state == GUC_SET_LOCAL)
     restoreMasked = ((bool) 1);
    else if (stack->state == GUC_SET)
    {

     discard_stack_value(gconf, &stack->prior);
    }
    else
     restorePrior = ((bool) 1);
   }
   else if (prev == ((void *)0) ||
      prev->nest_level < stack->nest_level - 1)
   {

    stack->nest_level--;
    continue;
   }
   else
   {




    switch (stack->state)
    {
     case GUC_SAVE:
      ;

     case GUC_SET:

      discard_stack_value(gconf, &stack->prior);
      if (prev->state == GUC_SET_LOCAL)
       discard_stack_value(gconf, &prev->masked);
      prev->state = GUC_SET;
      break;

     case GUC_LOCAL:
      if (prev->state == GUC_SET)
      {

       prev->masked_scontext = stack->scontext;
       prev->masked = stack->prior;
       prev->state = GUC_SET_LOCAL;
      }
      else
      {

       discard_stack_value(gconf, &stack->prior);
      }
      break;

     case GUC_SET_LOCAL:

      discard_stack_value(gconf, &stack->prior);

      prev->masked_scontext = stack->masked_scontext;
      if (prev->state == GUC_SET_LOCAL)
       discard_stack_value(gconf, &prev->masked);
      prev->masked = stack->masked;
      prev->state = GUC_SET_LOCAL;
      break;
    }
   }

   changed = ((bool) 0);

   if (restorePrior || restoreMasked)
   {

    config_var_value newvalue;
    GucSource newsource;
    GucContext newscontext;

    if (restoreMasked)
    {
     newvalue = stack->masked;
     newsource = PGC_S_SESSION;
     newscontext = stack->masked_scontext;
    }
    else
    {
     newvalue = stack->prior;
     newsource = stack->source;
     newscontext = stack->scontext;
    }

    switch (gconf->vartype)
    {
     case PGC_BOOL:
      {
       struct config_bool *conf = (struct config_bool *) gconf;
       bool newval = newvalue.val.boolval;
       void *newextra = newvalue.extra;

       if (*conf->variable != newval ||
        conf->gen.extra != newextra)
       {
        if (conf->assign_hook)
         (*conf->assign_hook) (newval, newextra);
        *conf->variable = newval;
        set_extra_field(&conf->gen, &conf->gen.extra,
            newextra);
        changed = ((bool) 1);
       }
       break;
      }
     case PGC_INT:
      {
       struct config_int *conf = (struct config_int *) gconf;
       int newval = newvalue.val.intval;
       void *newextra = newvalue.extra;

       if (*conf->variable != newval ||
        conf->gen.extra != newextra)
       {
        if (conf->assign_hook)
         (*conf->assign_hook) (newval, newextra);
        *conf->variable = newval;
        set_extra_field(&conf->gen, &conf->gen.extra,
            newextra);
        changed = ((bool) 1);
       }
       break;
      }
     case PGC_REAL:
      {
       struct config_real *conf = (struct config_real *) gconf;
       double newval = newvalue.val.realval;
       void *newextra = newvalue.extra;

       if (*conf->variable != newval ||
        conf->gen.extra != newextra)
       {
        if (conf->assign_hook)
         (*conf->assign_hook) (newval, newextra);
        *conf->variable = newval;
        set_extra_field(&conf->gen, &conf->gen.extra,
            newextra);
        changed = ((bool) 1);
       }
       break;
      }
     case PGC_STRING:
      {
       struct config_string *conf = (struct config_string *) gconf;
       char *newval = newvalue.val.stringval;
       void *newextra = newvalue.extra;

       if (*conf->variable != newval ||
        conf->gen.extra != newextra)
       {
        if (conf->assign_hook)
         (*conf->assign_hook) (newval, newextra);
        set_string_field(conf, conf->variable, newval);
        set_extra_field(&conf->gen, &conf->gen.extra,
            newextra);
        changed = ((bool) 1);
       }







       set_string_field(conf, &stack->prior.val.stringval, ((void *)0));
       set_string_field(conf, &stack->masked.val.stringval, ((void *)0));
       break;
      }
     case PGC_ENUM:
      {
       struct config_enum *conf = (struct config_enum *) gconf;
       int newval = newvalue.val.enumval;
       void *newextra = newvalue.extra;

       if (*conf->variable != newval ||
        conf->gen.extra != newextra)
       {
        if (conf->assign_hook)
         (*conf->assign_hook) (newval, newextra);
        *conf->variable = newval;
        set_extra_field(&conf->gen, &conf->gen.extra,
            newextra);
        changed = ((bool) 1);
       }
       break;
      }
    }




    set_extra_field(gconf, &(stack->prior.extra), ((void *)0));
    set_extra_field(gconf, &(stack->masked.extra), ((void *)0));


    gconf->source = newsource;
    gconf->scontext = newscontext;
   }


   gconf->stack = prev;
   pfree(stack);


   if (changed && (gconf->flags & 0x0010))
    ReportGUCOption(gconf);
  }

  if (stack != ((void *)0))
   still_dirty = ((bool) 1);
 }


 guc_dirty = still_dirty;


 GUCNestLevel = nestLevel - 1;
}






void
BeginReportingGUCOptions(void)
{
 int i;





 if (whereToSendOutput != DestRemote ||
  ((FrontendProtocol) >> 16) < 3)
  return;

 reporting_enabled = ((bool) 1);


 for (i = 0; i < num_guc_variables; i++)
 {
  struct config_generic *conf = guc_variables[i];

  if (conf->flags & 0x0010)
   ReportGUCOption(conf);
 }
}




static void
ReportGUCOption(struct config_generic * record)
{
 if (reporting_enabled && (record->flags & 0x0010))
 {
  char *val = _ShowOption(record, ((bool) 0));
  StringInfoData msgbuf;

  pq_beginmessage(&msgbuf, 'S');
  pq_sendstring(&msgbuf, record->name);
  pq_sendstring(&msgbuf, val);
  pq_endmessage(&msgbuf);

  pfree(val);
 }
}
# 4765 "guc.c"
bool
parse_int(const char *value, int *result, int flags, const char **hintmsg)
{
 int64 val;
 char *endptr;


 if (result)
  *result = 0;
 if (hintmsg)
  *hintmsg = ((void *)0);


 (*__error()) = 0;
 val = strtol(value, &endptr, 0);

 if (endptr == value)
  return ((bool) 0);

 if ((*__error()) == 34 || val != (int64) ((int32) val))
 {
  if (hintmsg)
   *hintmsg = ("Value exceeds integer range.");
  return ((bool) 0);
 }


 while (isspace((unsigned char) *endptr))
  endptr++;


 if (*endptr != '\0')
 {




  if (flags & 0x0C00)
  {

   if (hintmsg)
    *hintmsg = ("Valid units for this parameter are \"kB\", \"MB\", and \"GB\".");
# 4815 "guc.c"
   if (strncmp(endptr, "kB", 2) == 0)
   {
    endptr += 2;
    switch (flags & 0x0C00)
    {
     case 0x0800:
      val /= (8192 / 1024);
      break;
     case 0x0C00:
      val /= (8192 / 1024);
      break;
    }
   }
   else if (strncmp(endptr, "MB", 2) == 0)
   {
    endptr += 2;
    switch (flags & 0x0C00)
    {
     case 0x0400:
      val *= (1024);
      break;
     case 0x0800:
      val *= (1024) / (8192 / 1024);
      break;
     case 0x0C00:
      val *= (1024) / (8192 / 1024);
      break;
    }
   }
   else if (strncmp(endptr, "GB", 2) == 0)
   {
    endptr += 2;
    switch (flags & 0x0C00)
    {
     case 0x0400:
      val *= (1024*1024);
      break;
     case 0x0800:
      val *= (1024*1024) / (8192 / 1024);
      break;
     case 0x0C00:
      val *= (1024*1024) / (8192 / 1024);
      break;
    }
   }
  }
  else if (flags & 0x7000)
  {

   if (hintmsg)
    *hintmsg = ("Valid units for this parameter are \"ms\", \"s\", \"min\", \"h\", and \"d\".");

   if (strncmp(endptr, "ms", 2) == 0)
   {
    endptr += 2;
    switch (flags & 0x7000)
    {
     case 0x2000:
      val /= 1000;
      break;
     case 0x4000:
      val /= (1000 * 60);
      break;
    }
   }
   else if (strncmp(endptr, "s", 1) == 0)
   {
    endptr += 1;
    switch (flags & 0x7000)
    {
     case 0x1000:
      val *= 1000;
      break;
     case 0x4000:
      val /= 60;
      break;
    }
   }
   else if (strncmp(endptr, "min", 3) == 0)
   {
    endptr += 3;
    switch (flags & 0x7000)
    {
     case 0x1000:
      val *= (1000 * 60);
      break;
     case 0x2000:
      val *= 60;
      break;
    }
   }
   else if (strncmp(endptr, "h", 1) == 0)
   {
    endptr += 1;
    switch (flags & 0x7000)
    {
     case 0x1000:
      val *= (1000 * 60 * 60);
      break;
     case 0x2000:
      val *= (60 * 60);
      break;
     case 0x4000:
      val *= 60;
      break;
    }
   }
   else if (strncmp(endptr, "d", 1) == 0)
   {
    endptr += 1;
    switch (flags & 0x7000)
    {
     case 0x1000:
      val *= (1000 * 60 * 60 * 24);
      break;
     case 0x2000:
      val *= (60 * 60 * 24);
      break;
     case 0x4000:
      val *= (60 * 24);
      break;
    }
   }
  }


  while (isspace((unsigned char) *endptr))
   endptr++;

  if (*endptr != '\0')
   return ((bool) 0);


  if (val != (int64) ((int32) val))
  {
   if (hintmsg)
    *hintmsg = ("Value exceeds integer range.");
   return ((bool) 0);
  }
 }

 if (result)
  *result = (int) val;
 return ((bool) 1);
}
# 4968 "guc.c"
bool
parse_real(const char *value, double *result)
{
 double val;
 char *endptr;

 if (result)
  *result = 0;

 (*__error()) = 0;
 val = strtod(value, &endptr);
 if (endptr == value || (*__error()) == 34)
  return ((bool) 0);


 while (isspace((unsigned char) *endptr))
  endptr++;
 if (*endptr != '\0')
  return ((bool) 0);

 if (result)
  *result = val;
 return ((bool) 1);
}
# 5002 "guc.c"
const char *
config_enum_lookup_by_value(struct config_enum * record, int val)
{
 const struct config_enum_entry *entry;

 for (entry = record->options; entry && entry->name; entry++)
 {
  if (entry->val == val)
   return entry->name;
 }

 elog_start("guc.c", 5013, __func__), elog_finish(20, "could not find enum option %d for %s",
   val, record->gen.name);
 return ((void *)0);
}
# 5025 "guc.c"
bool
config_enum_lookup_by_name(struct config_enum * record, const char *value,
         int *retval)
{
 const struct config_enum_entry *entry;

 for (entry = record->options; entry && entry->name; entry++)
 {
  if (pg_strcasecmp(value, entry->name) == 0)
  {
   *retval = entry->val;
   return 1;
  }
 }

 *retval = 0;
 return 0;
}
# 5051 "guc.c"
static char *
config_enum_get_options(struct config_enum * record, const char *prefix,
      const char *suffix, const char *separator)
{
 const struct config_enum_entry *entry;
 StringInfoData retstr;
 int seplen;

 initStringInfo(&retstr);
 appendStringInfoString(&retstr, prefix);

 seplen = strlen(separator);
 for (entry = record->options; entry && entry->name; entry++)
 {
  if (!entry->hidden)
  {
   appendStringInfoString(&retstr, entry->name);
   appendBinaryStringInfo(&retstr, separator, seplen);
  }
 }
# 5079 "guc.c"
 if (retstr.len >= seplen)
 {

  retstr.data[retstr.len - seplen] = '\0';
  retstr.len -= seplen;
 }

 appendStringInfoString(&retstr, suffix);

 return retstr.data;
}
# 5127 "guc.c"
int
set_config_option(const char *name, const char *value,
      GucContext context, GucSource source,
      GucAction action, bool changeVal, int elevel)
{
 struct config_generic *record;
 bool prohibitValueChange = ((bool) 0);
 bool makeDefault;

 if (elevel == 0)
 {
  if (source == PGC_S_DEFAULT || source == PGC_S_FILE)
  {




   elevel = IsUnderPostmaster ? 12 : 15;
  }
  else if (source == PGC_S_DATABASE || source == PGC_S_USER ||
     source == PGC_S_DATABASE_USER)
   elevel = 19;
  else
   elevel = 20;
 }

 record = find_option(name, ((bool) 1), elevel);
 if (record == ((void *)0))
 {
  (errstart(elevel, "guc.c", 5158, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('7') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('4') - '0') & 0x3F) << 24))), errmsg("unrecognized configuration parameter \"%s\"", name))) : (void) 0);


  return 0;
 }





 switch (record->context)
 {
  case PGC_INTERNAL:
   if (context != PGC_INTERNAL)
   {
    (errstart(elevel, "guc.c", 5174, __func__, ((void *)0)) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('5') - '0') & 0x3F) << 6) + (((('P') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('2') - '0') & 0x3F) << 24))), errmsg("parameter \"%s\" cannot be changed", name))) : (void) 0);



    return 0;
   }
   break;
  case PGC_POSTMASTER:
   if (context == PGC_SIGHUP)
   {
# 5190 "guc.c"
    prohibitValueChange = ((bool) 1);
   }
   else if (context != PGC_POSTMASTER)
   {
    (errstart(elevel, "guc.c", 5197, __func__, ((void *)0)) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('5') - '0') & 0x3F) << 6) + (((('P') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('2') - '0') & 0x3F) << 24))), errmsg("parameter \"%s\" cannot be changed without restarting the server", name))) : (void) 0);



    return 0;
   }
   break;
  case PGC_SIGHUP:
   if (context != PGC_SIGHUP && context != PGC_POSTMASTER)
   {
    (errstart(elevel, "guc.c", 5207, __func__, ((void *)0)) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('5') - '0') & 0x3F) << 6) + (((('P') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('2') - '0') & 0x3F) << 24))), errmsg("parameter \"%s\" cannot be changed now", name))) : (void) 0);



    return 0;
   }







   break;
  case PGC_BACKEND:
   if (context == PGC_SIGHUP)
   {
# 5229 "guc.c"
    if (IsUnderPostmaster)
     return -1;
   }
   else if (context != PGC_POSTMASTER && context != PGC_BACKEND &&
      source != PGC_S_CLIENT)
   {
    (errstart(elevel, "guc.c", 5238, __func__, ((void *)0)) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('5') - '0') & 0x3F) << 6) + (((('P') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('2') - '0') & 0x3F) << 24))), errmsg("parameter \"%s\" cannot be set after connection start", name))) : (void) 0);



    return 0;
   }
   break;
  case PGC_SUSET:
   if (context == PGC_USERSET || context == PGC_BACKEND)
   {
    (errstart(elevel, "guc.c", 5248, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('5') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('1') - '0') & 0x3F) << 24))), errmsg("permission denied to set parameter \"%s\"", name))) : (void) 0);



    return 0;
   }
   break;
  case PGC_USERSET:

   break;
 }
# 5275 "guc.c"
 if (record->flags & 0x8000)
 {
  if (InLocalUserIdChange())
  {




   (errstart(elevel, "guc.c", 5286, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('5') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('1') - '0') & 0x3F) << 24))), errmsg("cannot set parameter \"%s\" within security-definer function", name))) : (void) 0);



   return 0;
  }
  if (InSecurityRestrictedOperation())
  {
   (errstart(elevel, "guc.c", 5294, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('5') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('1') - '0') & 0x3F) << 24))), errmsg("cannot set parameter \"%s\" within security-restricted operation", name))) : (void) 0);



   return 0;
  }
 }







 makeDefault = changeVal && (source <= PGC_S_OVERRIDE) &&
  ((value != ((void *)0)) || source == PGC_S_DEFAULT);
# 5315 "guc.c"
 if (record->source > source)
 {
  if (changeVal && !makeDefault)
  {
   elog_start("guc.c", 5319, __func__), elog_finish(12, "\"%s\": setting ignored because previous source is higher priority",
     name);
   return -1;
  }
  changeVal = ((bool) 0);
 }




 switch (record->vartype)
 {
  case PGC_BOOL:
   {
    struct config_bool *conf = (struct config_bool *) record;
    bool newval;
    void *newextra = ((void *)0);

    if (value)
    {
     if (!parse_bool(value, &newval))
     {
      (errstart(elevel, "guc.c", 5344, __func__, ((void *)0)) ? (errfinish (errcode((((('2') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('2') - '0') & 0x3F) << 18) + (((('3') - '0') & 0x3F) << 24))), errmsg("parameter \"%s\" requires a Boolean value", name))) : (void) 0);



      return 0;
     }
     if (!call_bool_check_hook(conf, &newval, &newextra,
             source, elevel))
      return 0;
    }
    else if (source == PGC_S_DEFAULT)
    {
     newval = conf->boot_val;
     if (!call_bool_check_hook(conf, &newval, &newextra,
             source, elevel))
      return 0;
    }
    else
    {
     newval = conf->reset_val;
     newextra = conf->reset_extra;
     source = conf->gen.reset_source;
     context = conf->gen.reset_scontext;
    }

    if (prohibitValueChange)
    {
     if (*conf->variable != newval)
     {
      (errstart(elevel, "guc.c", 5373, __func__, ((void *)0)) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('5') - '0') & 0x3F) << 6) + (((('P') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('2') - '0') & 0x3F) << 24))), errmsg("parameter \"%s\" cannot be changed without restarting the server", name))) : (void) 0);



      return 0;
     }
     return -1;
    }

    if (changeVal)
    {

     if (!makeDefault)
      push_old_value(&conf->gen, action);

     if (conf->assign_hook)
      (*conf->assign_hook) (newval, newextra);
     *conf->variable = newval;
     set_extra_field(&conf->gen, &conf->gen.extra,
         newextra);
     conf->gen.source = source;
     conf->gen.scontext = context;
    }
    if (makeDefault)
    {
     GucStack *stack;

     if (conf->gen.reset_source <= source)
     {
      conf->reset_val = newval;
      set_extra_field(&conf->gen, &conf->reset_extra,
          newextra);
      conf->gen.reset_source = source;
      conf->gen.reset_scontext = context;
     }
     for (stack = conf->gen.stack; stack; stack = stack->prev)
     {
      if (stack->source <= source)
      {
       stack->prior.val.boolval = newval;
       set_extra_field(&conf->gen, &stack->prior.extra,
           newextra);
       stack->source = source;
       stack->scontext = context;
      }
     }
    }


    if (newextra && !extra_field_used(&conf->gen, newextra))
     free(newextra);
    break;
   }

  case PGC_INT:
   {
    struct config_int *conf = (struct config_int *) record;
    int newval;
    void *newextra = ((void *)0);

    if (value)
    {
     const char *hintmsg;

     if (!parse_int(value, &newval, conf->gen.flags, &hintmsg))
     {
      (errstart(elevel, "guc.c", 5440, __func__, ((void *)0)) ? (errfinish (errcode((((('2') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('2') - '0') & 0x3F) << 18) + (((('3') - '0') & 0x3F) << 24))), errmsg("invalid value for parameter \"%s\": \"%s\"", name, value), hintmsg ? errhint("%s", (hintmsg)) : 0)) : (void) 0);




      return 0;
     }
     if (newval < conf->min || newval > conf->max)
     {
      (errstart(elevel, "guc.c", 5448, __func__, ((void *)0)) ? (errfinish (errcode((((('2') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('2') - '0') & 0x3F) << 18) + (((('3') - '0') & 0x3F) << 24))), errmsg("%d is outside the valid range for parameter \"%s\" (%d .. %d)", newval, name, conf->min, conf->max))) : (void) 0);



      return 0;
     }
     if (!call_int_check_hook(conf, &newval, &newextra,
            source, elevel))
      return 0;
    }
    else if (source == PGC_S_DEFAULT)
    {
     newval = conf->boot_val;
     if (!call_int_check_hook(conf, &newval, &newextra,
            source, elevel))
      return 0;
    }
    else
    {
     newval = conf->reset_val;
     newextra = conf->reset_extra;
     source = conf->gen.reset_source;
     context = conf->gen.reset_scontext;
    }

    if (prohibitValueChange)
    {
     if (*conf->variable != newval)
     {
      (errstart(elevel, "guc.c", 5477, __func__, ((void *)0)) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('5') - '0') & 0x3F) << 6) + (((('P') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('2') - '0') & 0x3F) << 24))), errmsg("parameter \"%s\" cannot be changed without restarting the server", name))) : (void) 0);



      return 0;
     }
     return -1;
    }

    if (changeVal)
    {

     if (!makeDefault)
      push_old_value(&conf->gen, action);

     if (conf->assign_hook)
      (*conf->assign_hook) (newval, newextra);
     *conf->variable = newval;
     set_extra_field(&conf->gen, &conf->gen.extra,
         newextra);
     conf->gen.source = source;
     conf->gen.scontext = context;
    }
    if (makeDefault)
    {
     GucStack *stack;

     if (conf->gen.reset_source <= source)
     {
      conf->reset_val = newval;
      set_extra_field(&conf->gen, &conf->reset_extra,
          newextra);
      conf->gen.reset_source = source;
      conf->gen.reset_scontext = context;
     }
     for (stack = conf->gen.stack; stack; stack = stack->prev)
     {
      if (stack->source <= source)
      {
       stack->prior.val.intval = newval;
       set_extra_field(&conf->gen, &stack->prior.extra,
           newextra);
       stack->source = source;
       stack->scontext = context;
      }
     }
    }


    if (newextra && !extra_field_used(&conf->gen, newextra))
     free(newextra);
    break;
   }

  case PGC_REAL:
   {
    struct config_real *conf = (struct config_real *) record;
    double newval;
    void *newextra = ((void *)0);

    if (value)
    {
     if (!parse_real(value, &newval))
     {
      (errstart(elevel, "guc.c", 5541, __func__, ((void *)0)) ? (errfinish (errcode((((('2') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('2') - '0') & 0x3F) << 18) + (((('3') - '0') & 0x3F) << 24))), errmsg("parameter \"%s\" requires a numeric value", name))) : (void) 0);



      return 0;
     }
     if (newval < conf->min || newval > conf->max)
     {
      (errstart(elevel, "guc.c", 5549, __func__, ((void *)0)) ? (errfinish (errcode((((('2') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('2') - '0') & 0x3F) << 18) + (((('3') - '0') & 0x3F) << 24))), errmsg("%g is outside the valid range for parameter \"%s\" (%g .. %g)", newval, name, conf->min, conf->max))) : (void) 0);



      return 0;
     }
     if (!call_real_check_hook(conf, &newval, &newextra,
             source, elevel))
      return 0;
    }
    else if (source == PGC_S_DEFAULT)
    {
     newval = conf->boot_val;
     if (!call_real_check_hook(conf, &newval, &newextra,
             source, elevel))
      return 0;
    }
    else
    {
     newval = conf->reset_val;
     newextra = conf->reset_extra;
     source = conf->gen.reset_source;
     context = conf->gen.reset_scontext;
    }

    if (prohibitValueChange)
    {
     if (*conf->variable != newval)
     {
      (errstart(elevel, "guc.c", 5578, __func__, ((void *)0)) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('5') - '0') & 0x3F) << 6) + (((('P') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('2') - '0') & 0x3F) << 24))), errmsg("parameter \"%s\" cannot be changed without restarting the server", name))) : (void) 0);



      return 0;
     }
     return -1;
    }

    if (changeVal)
    {

     if (!makeDefault)
      push_old_value(&conf->gen, action);

     if (conf->assign_hook)
      (*conf->assign_hook) (newval, newextra);
     *conf->variable = newval;
     set_extra_field(&conf->gen, &conf->gen.extra,
         newextra);
     conf->gen.source = source;
     conf->gen.scontext = context;
    }
    if (makeDefault)
    {
     GucStack *stack;

     if (conf->gen.reset_source <= source)
     {
      conf->reset_val = newval;
      set_extra_field(&conf->gen, &conf->reset_extra,
          newextra);
      conf->gen.reset_source = source;
      conf->gen.reset_scontext = context;
     }
     for (stack = conf->gen.stack; stack; stack = stack->prev)
     {
      if (stack->source <= source)
      {
       stack->prior.val.realval = newval;
       set_extra_field(&conf->gen, &stack->prior.extra,
           newextra);
       stack->source = source;
       stack->scontext = context;
      }
     }
    }


    if (newextra && !extra_field_used(&conf->gen, newextra))
     free(newextra);
    break;
   }

  case PGC_STRING:
   {
    struct config_string *conf = (struct config_string *) record;
    char *newval;
    void *newextra = ((void *)0);

    if (value)
    {




     newval = guc_strdup(elevel, value);
     if (newval == ((void *)0))
      return 0;





     if (conf->gen.flags & 0x0200)
      truncate_identifier(newval, strlen(newval), ((bool) 1));

     if (!call_string_check_hook(conf, &newval, &newextra,
            source, elevel))
     {
      free(newval);
      return 0;
     }
    }
    else if (source == PGC_S_DEFAULT)
    {

     if (conf->boot_val != ((void *)0))
     {
      newval = guc_strdup(elevel, conf->boot_val);
      if (newval == ((void *)0))
       return 0;
     }
     else
      newval = ((void *)0);

     if (!call_string_check_hook(conf, &newval, &newextra,
            source, elevel))
     {
      free(newval);
      return 0;
     }
    }
    else
    {




     newval = conf->reset_val;
     newextra = conf->reset_extra;
     source = conf->gen.reset_source;
     context = conf->gen.reset_scontext;
    }

    if (prohibitValueChange)
    {

     if (*conf->variable == ((void *)0) || newval == ((void *)0) ||
      strcmp(*conf->variable, newval) != 0)
     {
      (errstart(elevel, "guc.c", 5699, __func__, ((void *)0)) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('5') - '0') & 0x3F) << 6) + (((('P') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('2') - '0') & 0x3F) << 24))), errmsg("parameter \"%s\" cannot be changed without restarting the server", name))) : (void) 0);



      return 0;
     }
     return -1;
    }

    if (changeVal)
    {

     if (!makeDefault)
      push_old_value(&conf->gen, action);

     if (conf->assign_hook)
      (*conf->assign_hook) (newval, newextra);
     set_string_field(conf, conf->variable, newval);
     set_extra_field(&conf->gen, &conf->gen.extra,
         newextra);
     conf->gen.source = source;
     conf->gen.scontext = context;
    }

    if (makeDefault)
    {
     GucStack *stack;

     if (conf->gen.reset_source <= source)
     {
      set_string_field(conf, &conf->reset_val, newval);
      set_extra_field(&conf->gen, &conf->reset_extra,
          newextra);
      conf->gen.reset_source = source;
      conf->gen.reset_scontext = context;
     }
     for (stack = conf->gen.stack; stack; stack = stack->prev)
     {
      if (stack->source <= source)
      {
       set_string_field(conf, &stack->prior.val.stringval,
            newval);
       set_extra_field(&conf->gen, &stack->prior.extra,
           newextra);
       stack->source = source;
       stack->scontext = context;
      }
     }
    }


    if (newval && !string_field_used(conf, newval))
     free(newval);

    if (newextra && !extra_field_used(&conf->gen, newextra))
     free(newextra);
    break;
   }

  case PGC_ENUM:
   {
    struct config_enum *conf = (struct config_enum *) record;
    int newval;
    void *newextra = ((void *)0);

    if (value)
    {
     if (!config_enum_lookup_by_name(conf, value, &newval))
     {
      char *hintmsg;

      hintmsg = config_enum_get_options(conf,
              "Available values: ",
                ".", ", ");

      (errstart(elevel, "guc.c", 5775, __func__, ((void *)0)) ? (errfinish (errcode((((('2') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('2') - '0') & 0x3F) << 18) + (((('3') - '0') & 0x3F) << 24))), errmsg("invalid value for parameter \"%s\": \"%s\"", name, value), hintmsg ? errhint("%s", (hintmsg)) : 0)) : (void) 0);





      if (hintmsg)
       pfree(hintmsg);
      return 0;
     }
     if (!call_enum_check_hook(conf, &newval, &newextra,
             source, elevel))
      return 0;
    }
    else if (source == PGC_S_DEFAULT)
    {
     newval = conf->boot_val;
     if (!call_enum_check_hook(conf, &newval, &newextra,
             source, elevel))
      return 0;
    }
    else
    {
     newval = conf->reset_val;
     newextra = conf->reset_extra;
     source = conf->gen.reset_source;
     context = conf->gen.reset_scontext;
    }

    if (prohibitValueChange)
    {
     if (*conf->variable != newval)
     {
      (errstart(elevel, "guc.c", 5807, __func__, ((void *)0)) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('5') - '0') & 0x3F) << 6) + (((('P') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('2') - '0') & 0x3F) << 24))), errmsg("parameter \"%s\" cannot be changed without restarting the server", name))) : (void) 0);



      return 0;
     }
     return -1;
    }

    if (changeVal)
    {

     if (!makeDefault)
      push_old_value(&conf->gen, action);

     if (conf->assign_hook)
      (*conf->assign_hook) (newval, newextra);
     *conf->variable = newval;
     set_extra_field(&conf->gen, &conf->gen.extra,
         newextra);
     conf->gen.source = source;
     conf->gen.scontext = context;
    }
    if (makeDefault)
    {
     GucStack *stack;

     if (conf->gen.reset_source <= source)
     {
      conf->reset_val = newval;
      set_extra_field(&conf->gen, &conf->reset_extra,
          newextra);
      conf->gen.reset_source = source;
      conf->gen.reset_scontext = context;
     }
     for (stack = conf->gen.stack; stack; stack = stack->prev)
     {
      if (stack->source <= source)
      {
       stack->prior.val.enumval = newval;
       set_extra_field(&conf->gen, &stack->prior.extra,
           newextra);
       stack->source = source;
       stack->scontext = context;
      }
     }
    }


    if (newextra && !extra_field_used(&conf->gen, newextra))
     free(newextra);
    break;
   }
 }

 if (changeVal && (record->flags & 0x0010))
  ReportGUCOption(record);

 return changeVal ? 1 : -1;
}





static void
set_config_sourcefile(const char *name, char *sourcefile, int sourceline)
{
 struct config_generic *record;
 int elevel;





 elevel = IsUnderPostmaster ? 12 : 15;

 record = find_option(name, ((bool) 1), elevel);

 if (record == ((void *)0))
  elog_start("guc.c", 5884, __func__), elog_finish(20, "unrecognized configuration parameter \"%s\"", name);

 sourcefile = guc_strdup(elevel, sourcefile);
 if (record->sourcefile)
  free(record->sourcefile);
 record->sourcefile = sourcefile;
 record->sourceline = sourceline;
}
# 5903 "guc.c"
void
SetConfigOption(const char *name, const char *value,
    GucContext context, GucSource source)
{
 (void) set_config_option(name, value, context, source,
        GUC_ACTION_SET, ((bool) 1), 0);
}
# 5927 "guc.c"
const char *
GetConfigOption(const char *name, bool missing_ok, bool restrict_superuser)
{
 struct config_generic *record;
 static char buffer[256];

 record = find_option(name, ((bool) 0), 20);
 if (record == ((void *)0))
 {
  if (missing_ok)
   return ((void *)0);
  (errstart(20, "guc.c", 5941, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('7') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('4') - '0') & 0x3F) << 24))), errmsg("unrecognized configuration parameter \"%s\"", name))) : (void) 0);



 }
 if (restrict_superuser &&
  (record->flags & 0x0100) &&
  !superuser())
  (errstart(20, "guc.c", 5948, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('5') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('1') - '0') & 0x3F) << 24))), errmsg("must be superuser to examine \"%s\"", name))) : (void) 0);



 switch (record->vartype)
 {
  case PGC_BOOL:
   return *((struct config_bool *) record)->variable ? "on" : "off";

  case PGC_INT:
   __builtin___snprintf_chk (buffer, sizeof(buffer), 0, __builtin_object_size (buffer, 2 > 1), "%d", *((struct config_int *) record)->variable);

   return buffer;

  case PGC_REAL:
   __builtin___snprintf_chk (buffer, sizeof(buffer), 0, __builtin_object_size (buffer, 2 > 1), "%g", *((struct config_real *) record)->variable);

   return buffer;

  case PGC_STRING:
   return *((struct config_string *) record)->variable;

  case PGC_ENUM:
   return config_enum_lookup_by_value((struct config_enum *) record,
         *((struct config_enum *) record)->variable);
 }
 return ((void *)0);
}
# 5982 "guc.c"
const char *
GetConfigOptionResetString(const char *name)
{
 struct config_generic *record;
 static char buffer[256];

 record = find_option(name, ((bool) 0), 20);
 if (record == ((void *)0))
  (errstart(20, "guc.c", 5992, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('7') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('4') - '0') & 0x3F) << 24))), errmsg("unrecognized configuration parameter \"%s\"", name))) : (void) 0);


 if ((record->flags & 0x0100) && !superuser())
  (errstart(20, "guc.c", 5996, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('5') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('1') - '0') & 0x3F) << 24))), errmsg("must be superuser to examine \"%s\"", name))) : (void) 0);



 switch (record->vartype)
 {
  case PGC_BOOL:
   return ((struct config_bool *) record)->reset_val ? "on" : "off";

  case PGC_INT:
   __builtin___snprintf_chk (buffer, sizeof(buffer), 0, __builtin_object_size (buffer, 2 > 1), "%d", ((struct config_int *) record)->reset_val);

   return buffer;

  case PGC_REAL:
   __builtin___snprintf_chk (buffer, sizeof(buffer), 0, __builtin_object_size (buffer, 2 > 1), "%g", ((struct config_real *) record)->reset_val);

   return buffer;

  case PGC_STRING:
   return ((struct config_string *) record)->reset_val;

  case PGC_ENUM:
   return config_enum_lookup_by_value((struct config_enum *) record,
         ((struct config_enum *) record)->reset_val);
 }
 return ((void *)0);
}
# 6035 "guc.c"
static char *
flatten_set_variable_args(const char *name, List *args)
{
 struct config_generic *record;
 int flags;
 StringInfoData buf;
 ListCell *l;


 if (args == ((List *) ((void *)0)))
  return ((void *)0);





 record = find_option(name, ((bool) 0), 19);
 if (record)
  flags = record->flags;
 else
  flags = 0;


 if ((flags & 0x0001) == 0 &&
  list_length(args) != 1)
  (errstart(20, "guc.c", 6062, __func__, ((void *)0)) ? (errfinish (errcode((((('2') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('2') - '0') & 0x3F) << 18) + (((('3') - '0') & 0x3F) << 24))), errmsg("SET %s takes only one argument", name))) : (void) 0);



 initStringInfo(&buf);






 for ((l) = list_head(args); (l) != ((void *)0); (l) = ((l)->next))
 {
  Node *arg = (Node *) ((l)->data.ptr_value);
  char *val;
  TypeName *typeName = ((void *)0);
  A_Const *con;

  if (l != list_head(args))
   appendStringInfo(&buf, ", ");

  if (((((const Node*)(arg))->type) == T_TypeCast))
  {
   TypeCast *tc = (TypeCast *) arg;

   arg = tc->arg;
   typeName = tc->typeName;
  }

  if (!((((const Node*)(arg))->type) == T_A_Const))
   elog_start("guc.c", 6090, __func__), elog_finish(20, "unrecognized node type: %d", (int) (((const Node*)(arg))->type));
  con = (A_Const *) arg;

  switch ((((const Node*)(&con->val))->type))
  {
   case T_Integer:
    appendStringInfo(&buf, "%ld", (((Value *)(&con->val))->val.ival));
    break;
   case T_Float:

    appendStringInfoString(&buf, (((Value *)(&con->val))->val.str));
    break;
   case T_String:
    val = (((Value *)(&con->val))->val.str);
    if (typeName != ((void *)0))
    {





     Oid typoid;
     int32 typmod;
     Datum interval;
     char *intervalout;

     typenameTypeIdAndMod(((void *)0), typeName, &typoid, &typmod);
     ;

     interval =
      DirectFunctionCall3Coll(interval_in, ((Oid) 0), ((Datum) (val)), ((Datum) (((Datum) (((Oid) 0))) & 0xffffffff)), ((Datum) (((Datum) (typmod)) & 0xffffffff)));




     intervalout =
      ((char *) ((Pointer) (DirectFunctionCall1Coll(interval_out, ((Oid) 0), interval))));

     appendStringInfo(&buf, "INTERVAL '%s'", intervalout);
    }
    else
    {




     if (flags & 0x0002)
      appendStringInfoString(&buf, quote_identifier(val));
     else
      appendStringInfoString(&buf, val);
    }
    break;
   default:
    elog_start("guc.c", 6143, __func__), elog_finish(20, "unrecognized node type: %d",
      (int) (((const Node*)(&con->val))->type));
    break;
  }
 }

 return buf.data;
}





void
ExecSetVariableStmt(VariableSetStmt *stmt)
{
 GucAction action = stmt->is_local ? GUC_ACTION_LOCAL : GUC_ACTION_SET;

 switch (stmt->kind)
 {
  case VAR_SET_VALUE:
  case VAR_SET_CURRENT:
   (void) set_config_option(stmt->name,
          ExtractSetVariableArgs(stmt),
          (superuser() ? PGC_SUSET : PGC_USERSET),
          PGC_S_SESSION,
          action,
          ((bool) 1),
          0);
   break;
  case VAR_SET_MULTI:
# 6182 "guc.c"
   if (strcmp(stmt->name, "TRANSACTION") == 0)
   {
    ListCell *head;

    for ((head) = list_head(stmt->args); (head) != ((void *)0); (head) = ((head)->next))
    {
     DefElem *item = (DefElem *) ((head)->data.ptr_value);

     if (strcmp(item->defname, "transaction_isolation") == 0)
      SetPGVariable("transaction_isolation",
           lcons(item->arg, ((List *) ((void *)0))), stmt->is_local);
     else if (strcmp(item->defname, "transaction_read_only") == 0)
      SetPGVariable("transaction_read_only",
           lcons(item->arg, ((List *) ((void *)0))), stmt->is_local);
     else if (strcmp(item->defname, "transaction_deferrable") == 0)
      SetPGVariable("transaction_deferrable",
           lcons(item->arg, ((List *) ((void *)0))), stmt->is_local);
     else
      elog_start("guc.c", 6200, __func__), elog_finish(20, "unexpected SET TRANSACTION element: %s",
        item->defname);
    }
   }
   else if (strcmp(stmt->name, "SESSION CHARACTERISTICS") == 0)
   {
    ListCell *head;

    for ((head) = list_head(stmt->args); (head) != ((void *)0); (head) = ((head)->next))
    {
     DefElem *item = (DefElem *) ((head)->data.ptr_value);

     if (strcmp(item->defname, "transaction_isolation") == 0)
      SetPGVariable("default_transaction_isolation",
           lcons(item->arg, ((List *) ((void *)0))), stmt->is_local);
     else if (strcmp(item->defname, "transaction_read_only") == 0)
      SetPGVariable("default_transaction_read_only",
           lcons(item->arg, ((List *) ((void *)0))), stmt->is_local);
     else if (strcmp(item->defname, "transaction_deferrable") == 0)
      SetPGVariable("default_transaction_deferrable",
           lcons(item->arg, ((List *) ((void *)0))), stmt->is_local);
     else
      elog_start("guc.c", 6222, __func__), elog_finish(20, "unexpected SET SESSION element: %s",
        item->defname);
    }
   }
   else if (strcmp(stmt->name, "TRANSACTION SNAPSHOT") == 0)
   {
    A_Const *con = (A_Const *) ((list_head(stmt->args))->data.ptr_value);

    if (stmt->is_local)
     (errstart(20, "guc.c", 6233, __func__, ((void *)0)) ? (errfinish (errcode((((('0') - '0') & 0x3F) + (((('A') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("SET LOCAL TRANSACTION SNAPSHOT is not implemented"))) : (void) 0);


    ;
    ;
    ImportSnapshot((((Value *)(&con->val))->val.str));
   }
   else
    elog_start("guc.c", 6239, __func__), elog_finish(20, "unexpected SET MULTI element: %s",
      stmt->name);
   break;
  case VAR_SET_DEFAULT:
  case VAR_RESET:
   (void) set_config_option(stmt->name,
          ((void *)0),
          (superuser() ? PGC_SUSET : PGC_USERSET),
          PGC_S_SESSION,
          action,
          ((bool) 1),
          0);
   break;
  case VAR_RESET_ALL:
   ResetAllOptions();
   break;
 }
}







char *
ExtractSetVariableArgs(VariableSetStmt *stmt)
{
 switch (stmt->kind)
 {
  case VAR_SET_VALUE:
   return flatten_set_variable_args(stmt->name, stmt->args);
  case VAR_SET_CURRENT:
   return GetConfigOptionByName(stmt->name, ((void *)0));
  default:
   return ((void *)0);
 }
}







void
SetPGVariable(const char *name, List *args, bool is_local)
{
 char *argstring = flatten_set_variable_args(name, args);


 (void) set_config_option(name,
        argstring,
        (superuser() ? PGC_SUSET : PGC_USERSET),
        PGC_S_SESSION,
        is_local ? GUC_ACTION_LOCAL : GUC_ACTION_SET,
        ((bool) 1),
        0);
}




Datum
set_config_by_name(FunctionCallInfo fcinfo)
{
 char *name;
 char *value;
 char *new_value;
 bool is_local;

 if ((fcinfo->argnull[0]))
  (errstart(20, "guc.c", 6313, __func__, ((void *)0)) ? (errfinish (errcode((((('2') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('4') - '0') & 0x3F) << 24))), errmsg("SET requires parameter name"))) : (void) 0);




 name = text_to_cstring((text *) ((Pointer) ((fcinfo->arg[0]))));


 if ((fcinfo->argnull[1]))
  value = ((void *)0);
 else
  value = text_to_cstring((text *) ((Pointer) ((fcinfo->arg[1]))));





 if ((fcinfo->argnull[2]))
  is_local = ((bool) 0);
 else
  is_local = ((bool) (((bool) ((fcinfo->arg[2]))) != 0));


 (void) set_config_option(name,
        value,
        (superuser() ? PGC_SUSET : PGC_USERSET),
        PGC_S_SESSION,
        is_local ? GUC_ACTION_LOCAL : GUC_ACTION_SET,
        ((bool) 1),
        0);


 new_value = GetConfigOptionByName(name, ((void *)0));


 return ((Datum) (cstring_to_text(new_value)));
}






static struct config_generic *
init_custom_variable(const char *name,
      const char *short_desc,
      const char *long_desc,
      GucContext context,
      int flags,
      enum config_type type,
      size_t sz)
{
 struct config_generic *gen;
# 6372 "guc.c"
 if (context == PGC_POSTMASTER &&
  !process_shared_preload_libraries_in_progress)
  elog_start("guc.c", 6374, __func__), elog_finish(21, "cannot create PGC_POSTMASTER variables after startup");

 gen = (struct config_generic *) guc_malloc(20, sz);
 ((__builtin_object_size (gen, 0) != (size_t) -1) ? __builtin___memset_chk (gen, 0, sz, __builtin_object_size (gen, 0)) : __inline_memset_chk (gen, 0, sz));

 gen->name = guc_strdup(20, name);
 gen->context = context;
 gen->group = CUSTOM_OPTIONS;
 gen->short_desc = short_desc;
 gen->long_desc = long_desc;
 gen->flags = flags;
 gen->vartype = type;

 return gen;
}





static void
define_custom_variable(struct config_generic * variable)
{
 const char *name = variable->name;
 const char **nameAddr = &name;
 struct config_string *pHolder;
 struct config_generic **res;




 res = (struct config_generic **) bsearch((void *) &nameAddr,
            (void *) guc_variables,
            num_guc_variables,
            sizeof(struct config_generic *),
            guc_var_compare);
 if (res == ((void *)0))
 {




  InitializeOneGUCOption(variable);
  add_guc_variable(variable, 20);
  return;
 }




 if (((*res)->flags & 0x0080) == 0)
  (errstart(20, "guc.c", 6427, __func__, ((void *)0)) ? (errfinish (errcode((((('X') - '0') & 0x3F) + (((('X') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("attempt to redefine parameter \"%s\"", name))) : (void) 0);



 ;
 pHolder = (struct config_string *) (*res);






 InitializeOneGUCOption(variable);





 *res = variable;
# 6457 "guc.c"
 if (pHolder->reset_val)
  (void) set_config_option(name, pHolder->reset_val,
         pHolder->gen.reset_scontext,
         pHolder->gen.reset_source,
         GUC_ACTION_SET, ((bool) 1), 19);

 ;


 reapply_stacked_values(variable, pHolder, pHolder->gen.stack,
         *(pHolder->variable),
         pHolder->gen.scontext, pHolder->gen.source);


 if (pHolder->gen.sourcefile)
  set_config_sourcefile(name, pHolder->gen.sourcefile,
         pHolder->gen.sourceline);







 set_string_field(pHolder, pHolder->variable, ((void *)0));
 set_string_field(pHolder, &pHolder->reset_val, ((void *)0));

 free(pHolder);
}
# 6494 "guc.c"
static void
reapply_stacked_values(struct config_generic * variable,
        struct config_string * pHolder,
        GucStack *stack,
        const char *curvalue,
        GucContext curscontext, GucSource cursource)
{
 const char *name = variable->name;
 GucStack *oldvarstack = variable->stack;

 if (stack != ((void *)0))
 {

  reapply_stacked_values(variable, pHolder, stack->prev,
          stack->prior.val.stringval,
          stack->scontext, stack->source);


  switch (stack->state)
  {
   case GUC_SAVE:
    (void) set_config_option(name, curvalue,
           curscontext, cursource,
           GUC_ACTION_SAVE, ((bool) 1), 19);
    break;

   case GUC_SET:
    (void) set_config_option(name, curvalue,
           curscontext, cursource,
           GUC_ACTION_SET, ((bool) 1), 19);
    break;

   case GUC_LOCAL:
    (void) set_config_option(name, curvalue,
           curscontext, cursource,
           GUC_ACTION_LOCAL, ((bool) 1), 19);
    break;

   case GUC_SET_LOCAL:

    (void) set_config_option(name, stack->masked.val.stringval,
            stack->masked_scontext, PGC_S_SESSION,
           GUC_ACTION_SET, ((bool) 1), 19);

    (void) set_config_option(name, curvalue,
           curscontext, cursource,
           GUC_ACTION_LOCAL, ((bool) 1), 19);
    break;
  }


  if (variable->stack != oldvarstack)
   variable->stack->nest_level = stack->nest_level;
 }
 else
 {
# 6558 "guc.c"
  if (curvalue != pHolder->reset_val ||
   curscontext != pHolder->gen.reset_scontext ||
   cursource != pHolder->gen.reset_source)
  {
   (void) set_config_option(name, curvalue,
          curscontext, cursource,
          GUC_ACTION_SET, ((bool) 1), 19);
   variable->stack = ((void *)0);
  }
 }
}

void
DefineCustomBoolVariable(const char *name,
       const char *short_desc,
       const char *long_desc,
       bool *valueAddr,
       bool bootValue,
       GucContext context,
       int flags,
       GucBoolCheckHook check_hook,
       GucBoolAssignHook assign_hook,
       GucShowHook show_hook)
{
 struct config_bool *var;

 var = (struct config_bool *)
  init_custom_variable(name, short_desc, long_desc, context, flags,
        PGC_BOOL, sizeof(struct config_bool));
 var->variable = valueAddr;
 var->boot_val = bootValue;
 var->reset_val = bootValue;
 var->check_hook = check_hook;
 var->assign_hook = assign_hook;
 var->show_hook = show_hook;
 define_custom_variable(&var->gen);
}

void
DefineCustomIntVariable(const char *name,
      const char *short_desc,
      const char *long_desc,
      int *valueAddr,
      int bootValue,
      int minValue,
      int maxValue,
      GucContext context,
      int flags,
      GucIntCheckHook check_hook,
      GucIntAssignHook assign_hook,
      GucShowHook show_hook)
{
 struct config_int *var;

 var = (struct config_int *)
  init_custom_variable(name, short_desc, long_desc, context, flags,
        PGC_INT, sizeof(struct config_int));
 var->variable = valueAddr;
 var->boot_val = bootValue;
 var->reset_val = bootValue;
 var->min = minValue;
 var->max = maxValue;
 var->check_hook = check_hook;
 var->assign_hook = assign_hook;
 var->show_hook = show_hook;
 define_custom_variable(&var->gen);
}

void
DefineCustomRealVariable(const char *name,
       const char *short_desc,
       const char *long_desc,
       double *valueAddr,
       double bootValue,
       double minValue,
       double maxValue,
       GucContext context,
       int flags,
       GucRealCheckHook check_hook,
       GucRealAssignHook assign_hook,
       GucShowHook show_hook)
{
 struct config_real *var;

 var = (struct config_real *)
  init_custom_variable(name, short_desc, long_desc, context, flags,
        PGC_REAL, sizeof(struct config_real));
 var->variable = valueAddr;
 var->boot_val = bootValue;
 var->reset_val = bootValue;
 var->min = minValue;
 var->max = maxValue;
 var->check_hook = check_hook;
 var->assign_hook = assign_hook;
 var->show_hook = show_hook;
 define_custom_variable(&var->gen);
}

void
DefineCustomStringVariable(const char *name,
         const char *short_desc,
         const char *long_desc,
         char **valueAddr,
         const char *bootValue,
         GucContext context,
         int flags,
         GucStringCheckHook check_hook,
         GucStringAssignHook assign_hook,
         GucShowHook show_hook)
{
 struct config_string *var;

 var = (struct config_string *)
  init_custom_variable(name, short_desc, long_desc, context, flags,
        PGC_STRING, sizeof(struct config_string));
 var->variable = valueAddr;
 var->boot_val = bootValue;
 var->check_hook = check_hook;
 var->assign_hook = assign_hook;
 var->show_hook = show_hook;
 define_custom_variable(&var->gen);
}

void
DefineCustomEnumVariable(const char *name,
       const char *short_desc,
       const char *long_desc,
       int *valueAddr,
       int bootValue,
       const struct config_enum_entry * options,
       GucContext context,
       int flags,
       GucEnumCheckHook check_hook,
       GucEnumAssignHook assign_hook,
       GucShowHook show_hook)
{
 struct config_enum *var;

 var = (struct config_enum *)
  init_custom_variable(name, short_desc, long_desc, context, flags,
        PGC_ENUM, sizeof(struct config_enum));
 var->variable = valueAddr;
 var->boot_val = bootValue;
 var->reset_val = bootValue;
 var->options = options;
 var->check_hook = check_hook;
 var->assign_hook = assign_hook;
 var->show_hook = show_hook;
 define_custom_variable(&var->gen);
}

void
EmitWarningsOnPlaceholders(const char *className)
{
 int classLen = strlen(className);
 int i;

 for (i = 0; i < num_guc_variables; i++)
 {
  struct config_generic *var = guc_variables[i];

  if ((var->flags & 0x0080) != 0 &&
   strncmp(className, var->name, classLen) == 0 &&
   var->name[classLen] == '.')
  {
   (errstart(19, "guc.c", 6726, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('7') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('4') - '0') & 0x3F) << 24))), errmsg("unrecognized configuration parameter \"%s\"", var->name))) : (void) 0);



  }
 }
}





void
GetPGVariable(const char *name, DestReceiver *dest)
{
 if (guc_name_compare(name, "all") == 0)
  ShowAllGUCConfig(dest);
 else
  ShowGUCConfigOption(name, dest);
}

TupleDesc
GetPGVariableResultDesc(const char *name)
{
 TupleDesc tupdesc;

 if (guc_name_compare(name, "all") == 0)
 {

  tupdesc = CreateTemplateTupleDesc(3, ((bool) 0));
  TupleDescInitEntry(tupdesc, (AttrNumber) 1, "name",
         25, -1, 0);
  TupleDescInitEntry(tupdesc, (AttrNumber) 2, "setting",
         25, -1, 0);
  TupleDescInitEntry(tupdesc, (AttrNumber) 3, "description",
         25, -1, 0);
 }
 else
 {
  const char *varname;


  (void) GetConfigOptionByName(name, &varname);


  tupdesc = CreateTemplateTupleDesc(1, ((bool) 0));
  TupleDescInitEntry(tupdesc, (AttrNumber) 1, varname,
         25, -1, 0);
 }
 return tupdesc;
}





static void
ShowGUCConfigOption(const char *name, DestReceiver *dest)
{
 TupOutputState *tstate;
 TupleDesc tupdesc;
 const char *varname;
 char *value;


 value = GetConfigOptionByName(name, &varname);


 tupdesc = CreateTemplateTupleDesc(1, ((bool) 0));
 TupleDescInitEntry(tupdesc, (AttrNumber) 1, varname,
        25, -1, 0);


 tstate = begin_tup_output_tupdesc(dest, tupdesc);


 do { Datum values_[1]; bool isnull_[1]; values_[0] = ((Datum) (cstring_to_text(value))); isnull_[0] = ((bool) 0); do_tup_output(tstate, values_, isnull_); pfree(((Pointer) (values_[0]))); } while (0);

 end_tup_output(tstate);
}




static void
ShowAllGUCConfig(DestReceiver *dest)
{
 bool am_superuser = superuser();
 int i;
 TupOutputState *tstate;
 TupleDesc tupdesc;
 Datum values[3];
 bool isnull[3] = {((bool) 0), ((bool) 0), ((bool) 0)};


 tupdesc = CreateTemplateTupleDesc(3, ((bool) 0));
 TupleDescInitEntry(tupdesc, (AttrNumber) 1, "name",
        25, -1, 0);
 TupleDescInitEntry(tupdesc, (AttrNumber) 2, "setting",
        25, -1, 0);
 TupleDescInitEntry(tupdesc, (AttrNumber) 3, "description",
        25, -1, 0);


 tstate = begin_tup_output_tupdesc(dest, tupdesc);

 for (i = 0; i < num_guc_variables; i++)
 {
  struct config_generic *conf = guc_variables[i];
  char *setting;

  if ((conf->flags & 0x0004) ||
   ((conf->flags & 0x0100) && !am_superuser))
   continue;


  values[0] = ((Datum) (cstring_to_text(conf->name)));

  setting = _ShowOption(conf, ((bool) 1));
  if (setting)
  {
   values[1] = ((Datum) (cstring_to_text(setting)));
   isnull[1] = ((bool) 0);
  }
  else
  {
   values[1] = ((Datum) (((void *)0)));
   isnull[1] = ((bool) 1);
  }

  values[2] = ((Datum) (cstring_to_text(conf->short_desc)));


  do_tup_output(tstate, values, isnull);


  pfree(((Pointer) (values[0])));
  if (setting)
  {
   pfree(setting);
   pfree(((Pointer) (values[1])));
  }
  pfree(((Pointer) (values[2])));
 }

 end_tup_output(tstate);
}





char *
GetConfigOptionByName(const char *name, const char **varname)
{
 struct config_generic *record;

 record = find_option(name, ((bool) 0), 20);
 if (record == ((void *)0))
  (errstart(20, "guc.c", 6884, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('7') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('4') - '0') & 0x3F) << 24))), errmsg("unrecognized configuration parameter \"%s\"", name))) : (void) 0);


 if ((record->flags & 0x0100) && !superuser())
  (errstart(20, "guc.c", 6888, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('5') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('1') - '0') & 0x3F) << 24))), errmsg("must be superuser to examine \"%s\"", name))) : (void) 0);



 if (varname)
  *varname = record->name;

 return _ShowOption(record, ((bool) 1));
}





void
GetConfigOptionByNum(int varnum, const char **values, bool *noshow)
{
 char buffer[256];
 struct config_generic *conf;


 ;

 conf = guc_variables[varnum];

 if (noshow)
 {
  if ((conf->flags & 0x0004) ||
   ((conf->flags & 0x0100) && !superuser()))
   *noshow = ((bool) 1);
  else
   *noshow = ((bool) 0);
 }




 values[0] = conf->name;


 values[1] = _ShowOption(conf, ((bool) 0));


 if (conf->vartype == PGC_INT)
 {
  static char buf[8];

  switch (conf->flags & (0x0C00 | 0x7000))
  {
   case 0x0400:
    values[2] = "kB";
    break;
   case 0x0800:
    __builtin___snprintf_chk (buf, sizeof(buf), 0, __builtin_object_size (buf, 2 > 1), "%dkB", 8192 / 1024);
    values[2] = buf;
    break;
   case 0x0C00:
    __builtin___snprintf_chk (buf, sizeof(buf), 0, __builtin_object_size (buf, 2 > 1), "%dkB", 8192 / 1024);
    values[2] = buf;
    break;
   case 0x1000:
    values[2] = "ms";
    break;
   case 0x2000:
    values[2] = "s";
    break;
   case 0x4000:
    values[2] = "min";
    break;
   default:
    values[2] = "";
    break;
  }
 }
 else
  values[2] = ((void *)0);


 values[3] = config_group_names[conf->group];


 values[4] = conf->short_desc;


 values[5] = conf->long_desc;


 values[6] = GucContext_Names[conf->context];


 values[7] = config_type_names[conf->vartype];


 values[8] = GucSource_Names[conf->source];


 switch (conf->vartype)
 {
  case PGC_BOOL:
   {
    struct config_bool *lconf = (struct config_bool *) conf;


    values[9] = ((void *)0);


    values[10] = ((void *)0);


    values[11] = ((void *)0);


    values[12] = MemoryContextStrdup(CurrentMemoryContext, (lconf->boot_val ? "on" : "off"));


    values[13] = MemoryContextStrdup(CurrentMemoryContext, (lconf->reset_val ? "on" : "off"));
   }
   break;

  case PGC_INT:
   {
    struct config_int *lconf = (struct config_int *) conf;


    __builtin___snprintf_chk (buffer, sizeof(buffer), 0, __builtin_object_size (buffer, 2 > 1), "%d", lconf->min);
    values[9] = MemoryContextStrdup(CurrentMemoryContext, (buffer));


    __builtin___snprintf_chk (buffer, sizeof(buffer), 0, __builtin_object_size (buffer, 2 > 1), "%d", lconf->max);
    values[10] = MemoryContextStrdup(CurrentMemoryContext, (buffer));


    values[11] = ((void *)0);


    __builtin___snprintf_chk (buffer, sizeof(buffer), 0, __builtin_object_size (buffer, 2 > 1), "%d", lconf->boot_val);
    values[12] = MemoryContextStrdup(CurrentMemoryContext, (buffer));


    __builtin___snprintf_chk (buffer, sizeof(buffer), 0, __builtin_object_size (buffer, 2 > 1), "%d", lconf->reset_val);
    values[13] = MemoryContextStrdup(CurrentMemoryContext, (buffer));
   }
   break;

  case PGC_REAL:
   {
    struct config_real *lconf = (struct config_real *) conf;


    __builtin___snprintf_chk (buffer, sizeof(buffer), 0, __builtin_object_size (buffer, 2 > 1), "%g", lconf->min);
    values[9] = MemoryContextStrdup(CurrentMemoryContext, (buffer));


    __builtin___snprintf_chk (buffer, sizeof(buffer), 0, __builtin_object_size (buffer, 2 > 1), "%g", lconf->max);
    values[10] = MemoryContextStrdup(CurrentMemoryContext, (buffer));


    values[11] = ((void *)0);


    __builtin___snprintf_chk (buffer, sizeof(buffer), 0, __builtin_object_size (buffer, 2 > 1), "%g", lconf->boot_val);
    values[12] = MemoryContextStrdup(CurrentMemoryContext, (buffer));


    __builtin___snprintf_chk (buffer, sizeof(buffer), 0, __builtin_object_size (buffer, 2 > 1), "%g", lconf->reset_val);
    values[13] = MemoryContextStrdup(CurrentMemoryContext, (buffer));
   }
   break;

  case PGC_STRING:
   {
    struct config_string *lconf = (struct config_string *) conf;


    values[9] = ((void *)0);


    values[10] = ((void *)0);


    values[11] = ((void *)0);


    if (lconf->boot_val == ((void *)0))
     values[12] = ((void *)0);
    else
     values[12] = MemoryContextStrdup(CurrentMemoryContext, (lconf->boot_val));


    if (lconf->reset_val == ((void *)0))
     values[13] = ((void *)0);
    else
     values[13] = MemoryContextStrdup(CurrentMemoryContext, (lconf->reset_val));
   }
   break;

  case PGC_ENUM:
   {
    struct config_enum *lconf = (struct config_enum *) conf;


    values[9] = ((void *)0);


    values[10] = ((void *)0);







    values[11] = config_enum_get_options((struct config_enum *) conf,
              "{\"", "\"}", "\",\"");


    values[12] = MemoryContextStrdup(CurrentMemoryContext, (config_enum_lookup_by_value(lconf, lconf->boot_val)));



    values[13] = MemoryContextStrdup(CurrentMemoryContext, (config_enum_lookup_by_value(lconf, lconf->reset_val)));

   }
   break;

  default:
   {





    values[9] = ((void *)0);


    values[10] = ((void *)0);


    values[11] = ((void *)0);


    values[12] = ((void *)0);


    values[13] = ((void *)0);
   }
   break;
 }






 if (conf->source == PGC_S_FILE && superuser())
 {
  values[14] = conf->sourcefile;
  __builtin___snprintf_chk (buffer, sizeof(buffer), 0, __builtin_object_size (buffer, 2 > 1), "%d", conf->sourceline);
  values[15] = MemoryContextStrdup(CurrentMemoryContext, (buffer));
 }
 else
 {
  values[14] = ((void *)0);
  values[15] = ((void *)0);
 }
}




int
GetNumConfigOptions(void)
{
 return num_guc_variables;
}





Datum
show_config_by_name(FunctionCallInfo fcinfo)
{
 char *varname;
 char *varval;


 varname = text_to_cstring((text *) ((Pointer) ((fcinfo->arg[0]))));


 varval = GetConfigOptionByName(varname, ((void *)0));


 return ((Datum) (cstring_to_text(varval)));
}







Datum
show_all_settings(FunctionCallInfo fcinfo)
{
 FuncCallContext *funcctx;
 TupleDesc tupdesc;
 int call_cntr;
 int max_calls;
 AttInMetadata *attinmeta;
 MemoryContext oldcontext;


 if ((fcinfo->flinfo->fn_extra == ((void *)0)))
 {

  funcctx = init_MultiFuncCall(fcinfo);




  oldcontext = MemoryContextSwitchTo(funcctx->multi_call_memory_ctx);





  tupdesc = CreateTemplateTupleDesc(16, ((bool) 0));
  TupleDescInitEntry(tupdesc, (AttrNumber) 1, "name",
         25, -1, 0);
  TupleDescInitEntry(tupdesc, (AttrNumber) 2, "setting",
         25, -1, 0);
  TupleDescInitEntry(tupdesc, (AttrNumber) 3, "unit",
         25, -1, 0);
  TupleDescInitEntry(tupdesc, (AttrNumber) 4, "category",
         25, -1, 0);
  TupleDescInitEntry(tupdesc, (AttrNumber) 5, "short_desc",
         25, -1, 0);
  TupleDescInitEntry(tupdesc, (AttrNumber) 6, "extra_desc",
         25, -1, 0);
  TupleDescInitEntry(tupdesc, (AttrNumber) 7, "context",
         25, -1, 0);
  TupleDescInitEntry(tupdesc, (AttrNumber) 8, "vartype",
         25, -1, 0);
  TupleDescInitEntry(tupdesc, (AttrNumber) 9, "source",
         25, -1, 0);
  TupleDescInitEntry(tupdesc, (AttrNumber) 10, "min_val",
         25, -1, 0);
  TupleDescInitEntry(tupdesc, (AttrNumber) 11, "max_val",
         25, -1, 0);
  TupleDescInitEntry(tupdesc, (AttrNumber) 12, "enumvals",
         1009, -1, 0);
  TupleDescInitEntry(tupdesc, (AttrNumber) 13, "boot_val",
         25, -1, 0);
  TupleDescInitEntry(tupdesc, (AttrNumber) 14, "reset_val",
         25, -1, 0);
  TupleDescInitEntry(tupdesc, (AttrNumber) 15, "sourcefile",
         25, -1, 0);
  TupleDescInitEntry(tupdesc, (AttrNumber) 16, "sourceline",
         23, -1, 0);





  attinmeta = TupleDescGetAttInMetadata(tupdesc);
  funcctx->attinmeta = attinmeta;


  funcctx->max_calls = GetNumConfigOptions();

  MemoryContextSwitchTo(oldcontext);
 }


 funcctx = per_MultiFuncCall(fcinfo);

 call_cntr = funcctx->call_cntr;
 max_calls = funcctx->max_calls;
 attinmeta = funcctx->attinmeta;

 if (call_cntr < max_calls)
 {
  char *values[16];
  bool noshow;
  HeapTuple tuple;
  Datum result;




  do
  {
   GetConfigOptionByNum(call_cntr, (const char **) values, &noshow);
   if (noshow)
   {

    call_cntr = ++funcctx->call_cntr;


    if (call_cntr >= max_calls)
     do { ReturnSetInfo *rsi; end_MultiFuncCall(fcinfo, funcctx); rsi = (ReturnSetInfo *) fcinfo->resultinfo; rsi->isDone = ExprEndResult; do { fcinfo->isnull = ((bool) 1); return (Datum) 0; } while (0); } while (0);
   }
  } while (noshow);


  tuple = BuildTupleFromCStrings(attinmeta, values);


  result = ((Datum) ((tuple)->t_data));

  do { ReturnSetInfo *rsi; (funcctx)->call_cntr++; rsi = (ReturnSetInfo *) fcinfo->resultinfo; rsi->isDone = ExprMultipleResult; return (result); } while (0);
 }
 else
 {

  do { ReturnSetInfo *rsi; end_MultiFuncCall(fcinfo, funcctx); rsi = (ReturnSetInfo *) fcinfo->resultinfo; rsi->isDone = ExprEndResult; do { fcinfo->isnull = ((bool) 1); return (Datum) 0; } while (0); } while (0);
 }
}

static char *
_ShowOption(struct config_generic * record, bool use_units)
{
 char buffer[256];
 const char *val;

 switch (record->vartype)
 {
  case PGC_BOOL:
   {
    struct config_bool *conf = (struct config_bool *) record;

    if (conf->show_hook)
     val = (*conf->show_hook) ();
    else
     val = *conf->variable ? "on" : "off";
   }
   break;

  case PGC_INT:
   {
    struct config_int *conf = (struct config_int *) record;

    if (conf->show_hook)
     val = (*conf->show_hook) ();
    else
    {




     int64 result = *conf->variable;
     const char *unit;

     if (use_units && result > 0 &&
      (record->flags & 0x0C00))
     {
      switch (record->flags & 0x0C00)
      {
       case 0x0800:
        result *= 8192 / 1024;
        break;
       case 0x0C00:
        result *= 8192 / 1024;
        break;
      }

      if (result % (1024*1024) == 0)
      {
       result /= (1024*1024);
       unit = "GB";
      }
      else if (result % (1024) == 0)
      {
       result /= (1024);
       unit = "MB";
      }
      else
      {
       unit = "kB";
      }
     }
     else if (use_units && result > 0 &&
        (record->flags & 0x7000))
     {
      switch (record->flags & 0x7000)
      {
       case 0x2000:
        result *= 1000;
        break;
       case 0x4000:
        result *= (1000 * 60);
        break;
      }

      if (result % (1000 * 60 * 60 * 24) == 0)
      {
       result /= (1000 * 60 * 60 * 24);
       unit = "d";
      }
      else if (result % (1000 * 60 * 60) == 0)
      {
       result /= (1000 * 60 * 60);
       unit = "h";
      }
      else if (result % (1000 * 60) == 0)
      {
       result /= (1000 * 60);
       unit = "min";
      }
      else if (result % 1000 == 0)
      {
       result /= 1000;
       unit = "s";
      }
      else
      {
       unit = "ms";
      }
     }
     else
      unit = "";

     __builtin___snprintf_chk (buffer, sizeof(buffer), 0, __builtin_object_size (buffer, 2 > 1), "%ld" "%s", result, unit);

     val = buffer;
    }
   }
   break;

  case PGC_REAL:
   {
    struct config_real *conf = (struct config_real *) record;

    if (conf->show_hook)
     val = (*conf->show_hook) ();
    else
    {
     __builtin___snprintf_chk (buffer, sizeof(buffer), 0, __builtin_object_size (buffer, 2 > 1), "%g", *conf->variable);

     val = buffer;
    }
   }
   break;

  case PGC_STRING:
   {
    struct config_string *conf = (struct config_string *) record;

    if (conf->show_hook)
     val = (*conf->show_hook) ();
    else if (*conf->variable && **conf->variable)
     val = *conf->variable;
    else
     val = "";
   }
   break;

  case PGC_ENUM:
   {
    struct config_enum *conf = (struct config_enum *) record;

    if (conf->show_hook)
     val = (*conf->show_hook) ();
    else
     val = config_enum_lookup_by_value(conf, *conf->variable);
   }
   break;

  default:

   val = "???";
   break;
 }

 return MemoryContextStrdup(CurrentMemoryContext, (val));
}
# 7698 "guc.c"
void
ParseLongOption(const char *string, char **name, char **value)
{
 size_t equal_pos;
 char *cp;

 ;
 ;
 ;

 equal_pos = strcspn(string, "=");

 if (string[equal_pos] == '=')
 {
  *name = guc_malloc(21, equal_pos + 1);
  strlcpy(*name, string, equal_pos + 1);

  *value = guc_strdup(21, &string[equal_pos + 1]);
 }
 else
 {

  *name = guc_strdup(21, string);
  *value = ((void *)0);
 }

 for (cp = *name; *cp; cp++)
  if (*cp == '-')
   *cp = '_';
}
# 7736 "guc.c"
void
ProcessGUCArray(ArrayType *array,
    GucContext context, GucSource source, GucAction action)
{
 int i;

 ;
 ;
 ;
 ;

 for (i = 1; i <= ((int *) (((char *) (array)) + sizeof(ArrayType)))[0]; i++)
 {
  Datum d;
  bool isnull;
  char *s;
  char *name;
  char *value;

  d = array_ref(array, 1, &i,
       -1 ,
       -1 ,
       ((bool) 0) ,
       'i' ,
       &isnull);

  if (isnull)
   continue;

  s = text_to_cstring((text *) ((Pointer) (d)));

  ParseLongOption(s, &name, &value);
  if (!value)
  {
   (errstart(19, "guc.c", 7773, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('6') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('1') - '0') & 0x3F) << 24))), errmsg("could not parse setting for parameter \"%s\"", name))) : (void) 0);



   free(name);
   continue;
  }

  (void) set_config_option(name, value,
         context, source,
         action, ((bool) 1), 0);

  free(name);
  if (value)
   free(value);
  pfree(s);
 }
}






ArrayType *
GUCArrayAdd(ArrayType *array, const char *name, const char *value)
{
 struct config_generic *record;
 Datum datum;
 char *newval;
 ArrayType *a;

 ;
 ;


 (void) validate_option_array_item(name, value, ((bool) 0));


 record = find_option(name, ((bool) 0), 19);
 if (record)
  name = record->name;


 newval = MemoryContextAlloc(CurrentMemoryContext, (strlen(name) + 1 + strlen(value) + 1));
 __builtin___sprintf_chk (newval, 0, __builtin_object_size (newval, 2 > 1), "%s=%s", name, value);
 datum = ((Datum) (cstring_to_text(newval)));

 if (array)
 {
  int index;
  bool isnull;
  int i;

  ;
  ;
  ;

  index = ((int *) (((char *) (array)) + sizeof(ArrayType)))[0] + 1;

  for (i = 1; i <= ((int *) (((char *) (array)) + sizeof(ArrayType)))[0]; i++)
  {
   Datum d;
   char *current;

   d = array_ref(array, 1, &i,
        -1 ,
        -1 ,
        ((bool) 0) ,
        'i' ,
        &isnull);
   if (isnull)
    continue;
   current = text_to_cstring((text *) ((Pointer) (d)));


   if (strncmp(current, newval, strlen(name) + 1) == 0)
   {
    index = i;
    break;
   }
  }

  a = array_set(array, 1, &index,
       datum,
       ((bool) 0),
       -1 ,
       -1 ,
       ((bool) 0) ,
       'i' );
 }
 else
  a = construct_array(&datum, 1,
       25,
       -1, ((bool) 0), 'i');

 return a;
}







ArrayType *
GUCArrayDelete(ArrayType *array, const char *name)
{
 struct config_generic *record;
 ArrayType *newarray;
 int i;
 int index;

 ;


 (void) validate_option_array_item(name, ((void *)0), ((bool) 0));


 record = find_option(name, ((bool) 0), 19);
 if (record)
  name = record->name;


 if (!array)
  return ((void *)0);

 newarray = ((void *)0);
 index = 1;

 for (i = 1; i <= ((int *) (((char *) (array)) + sizeof(ArrayType)))[0]; i++)
 {
  Datum d;
  char *val;
  bool isnull;

  d = array_ref(array, 1, &i,
       -1 ,
       -1 ,
       ((bool) 0) ,
       'i' ,
       &isnull);
  if (isnull)
   continue;
  val = text_to_cstring((text *) ((Pointer) (d)));


  if (strncmp(val, name, strlen(name)) == 0
   && val[strlen(name)] == '=')
   continue;


  if (newarray)
   newarray = array_set(newarray, 1, &index,
         d,
         ((bool) 0),
         -1 ,
         -1 ,
         ((bool) 0) ,
         'i' );
  else
   newarray = construct_array(&d, 1,
            25,
            -1, ((bool) 0), 'i');

  index++;
 }

 return newarray;
}







ArrayType *
GUCArrayReset(ArrayType *array)
{
 ArrayType *newarray;
 int i;
 int index;


 if (!array)
  return ((void *)0);


 if (superuser())
  return ((void *)0);

 newarray = ((void *)0);
 index = 1;

 for (i = 1; i <= ((int *) (((char *) (array)) + sizeof(ArrayType)))[0]; i++)
 {
  Datum d;
  char *val;
  char *eqsgn;
  bool isnull;

  d = array_ref(array, 1, &i,
       -1 ,
       -1 ,
       ((bool) 0) ,
       'i' ,
       &isnull);
  if (isnull)
   continue;
  val = text_to_cstring((text *) ((Pointer) (d)));

  eqsgn = strchr(val, '=');
  *eqsgn = '\0';


  if (validate_option_array_item(val, ((void *)0), ((bool) 1)))
   continue;


  if (newarray)
   newarray = array_set(newarray, 1, &index,
         d,
         ((bool) 0),
         -1 ,
         -1 ,
         ((bool) 0) ,
         'i' );
  else
   newarray = construct_array(&d, 1,
            25,
            -1, ((bool) 0), 'i');

  index++;
  pfree(val);
 }

 return newarray;
}
# 8021 "guc.c"
static bool
validate_option_array_item(const char *name, const char *value,
         bool skipIfNoPermissions)

{
 struct config_generic *gconf;
# 8045 "guc.c"
 gconf = find_option(name, ((bool) 1), 19);
 if (!gconf)
 {

  if (skipIfNoPermissions)
   return ((bool) 0);
  (errstart(20, "guc.c", 8054, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('7') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('4') - '0') & 0x3F) << 24))), errmsg("unrecognized configuration parameter \"%s\"", name))) : (void) 0);



 }

 if (gconf->flags & 0x0080)
 {




  if (superuser())
   return ((bool) 1);
  if (skipIfNoPermissions)
   return ((bool) 0);
  (errstart(20, "guc.c", 8069, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('5') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('1') - '0') & 0x3F) << 24))), errmsg("permission denied to set parameter \"%s\"", name))) : (void) 0);


 }


 if (gconf->context == PGC_USERSET)
            ;
 else if (gconf->context == PGC_SUSET && superuser())
            ;
 else if (skipIfNoPermissions)
  return ((bool) 0);



 (void) set_config_option(name, value,
        superuser() ? PGC_SUSET : PGC_USERSET,
        PGC_S_TEST, GUC_ACTION_SET, ((bool) 0), 0);

 return ((bool) 1);
}
# 8098 "guc.c"
void
GUC_check_errcode(int sqlerrcode)
{
 GUC_check_errcode_value = sqlerrcode;
}
# 8111 "guc.c"
static bool
call_bool_check_hook(struct config_bool * conf, bool *newval, void **extra,
      GucSource source, int elevel)
{

 if (!conf->check_hook)
  return ((bool) 1);


 GUC_check_errcode_value = (((('2') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('2') - '0') & 0x3F) << 18) + (((('3') - '0') & 0x3F) << 24));
 GUC_check_errmsg_string = ((void *)0);
 GUC_check_errdetail_string = ((void *)0);
 GUC_check_errhint_string = ((void *)0);

 if (!(*conf->check_hook) (newval, extra, source))
 {
  (errstart(elevel, "guc.c", 8136, __func__, ((void *)0)) ? (errfinish (errcode(GUC_check_errcode_value), GUC_check_errmsg_string ? errmsg_internal("%s", GUC_check_errmsg_string) : errmsg("invalid value for parameter \"%s\": %d", conf->gen.name, (int) *newval), GUC_check_errdetail_string ? errdetail_internal("%s", GUC_check_errdetail_string) : 0, GUC_check_errhint_string ? errhint("%s", GUC_check_errhint_string) : 0)) : (void) 0);
# 8138 "guc.c"
  FlushErrorState();
  return ((bool) 0);
 }

 return ((bool) 1);
}

static bool
call_int_check_hook(struct config_int * conf, int *newval, void **extra,
     GucSource source, int elevel)
{

 if (!conf->check_hook)
  return ((bool) 1);


 GUC_check_errcode_value = (((('2') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('2') - '0') & 0x3F) << 18) + (((('3') - '0') & 0x3F) << 24));
 GUC_check_errmsg_string = ((void *)0);
 GUC_check_errdetail_string = ((void *)0);
 GUC_check_errhint_string = ((void *)0);

 if (!(*conf->check_hook) (newval, extra, source))
 {
  (errstart(elevel, "guc.c", 8170, __func__, ((void *)0)) ? (errfinish (errcode(GUC_check_errcode_value), GUC_check_errmsg_string ? errmsg_internal("%s", GUC_check_errmsg_string) : errmsg("invalid value for parameter \"%s\": %d", conf->gen.name, *newval), GUC_check_errdetail_string ? errdetail_internal("%s", GUC_check_errdetail_string) : 0, GUC_check_errhint_string ? errhint("%s", GUC_check_errhint_string) : 0)) : (void) 0);
# 8172 "guc.c"
  FlushErrorState();
  return ((bool) 0);
 }

 return ((bool) 1);
}

static bool
call_real_check_hook(struct config_real * conf, double *newval, void **extra,
      GucSource source, int elevel)
{

 if (!conf->check_hook)
  return ((bool) 1);


 GUC_check_errcode_value = (((('2') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('2') - '0') & 0x3F) << 18) + (((('3') - '0') & 0x3F) << 24));
 GUC_check_errmsg_string = ((void *)0);
 GUC_check_errdetail_string = ((void *)0);
 GUC_check_errhint_string = ((void *)0);

 if (!(*conf->check_hook) (newval, extra, source))
 {
  (errstart(elevel, "guc.c", 8204, __func__, ((void *)0)) ? (errfinish (errcode(GUC_check_errcode_value), GUC_check_errmsg_string ? errmsg_internal("%s", GUC_check_errmsg_string) : errmsg("invalid value for parameter \"%s\": %g", conf->gen.name, *newval), GUC_check_errdetail_string ? errdetail_internal("%s", GUC_check_errdetail_string) : 0, GUC_check_errhint_string ? errhint("%s", GUC_check_errhint_string) : 0)) : (void) 0);
# 8206 "guc.c"
  FlushErrorState();
  return ((bool) 0);
 }

 return ((bool) 1);
}

static bool
call_string_check_hook(struct config_string * conf, char **newval, void **extra,
        GucSource source, int elevel)
{

 if (!conf->check_hook)
  return ((bool) 1);


 GUC_check_errcode_value = (((('2') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('2') - '0') & 0x3F) << 18) + (((('3') - '0') & 0x3F) << 24));
 GUC_check_errmsg_string = ((void *)0);
 GUC_check_errdetail_string = ((void *)0);
 GUC_check_errhint_string = ((void *)0);

 if (!(*conf->check_hook) (newval, extra, source))
 {
  (errstart(elevel, "guc.c", 8238, __func__, ((void *)0)) ? (errfinish (errcode(GUC_check_errcode_value), GUC_check_errmsg_string ? errmsg_internal("%s", GUC_check_errmsg_string) : errmsg("invalid value for parameter \"%s\": \"%s\"", conf->gen.name, *newval ? *newval : ""), GUC_check_errdetail_string ? errdetail_internal("%s", GUC_check_errdetail_string) : 0, GUC_check_errhint_string ? errhint("%s", GUC_check_errhint_string) : 0)) : (void) 0);
# 8240 "guc.c"
  FlushErrorState();
  return ((bool) 0);
 }

 return ((bool) 1);
}

static bool
call_enum_check_hook(struct config_enum * conf, int *newval, void **extra,
      GucSource source, int elevel)
{

 if (!conf->check_hook)
  return ((bool) 1);


 GUC_check_errcode_value = (((('2') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('2') - '0') & 0x3F) << 18) + (((('3') - '0') & 0x3F) << 24));
 GUC_check_errmsg_string = ((void *)0);
 GUC_check_errdetail_string = ((void *)0);
 GUC_check_errhint_string = ((void *)0);

 if (!(*conf->check_hook) (newval, extra, source))
 {
  (errstart(elevel, "guc.c", 8273, __func__, ((void *)0)) ? (errfinish (errcode(GUC_check_errcode_value), GUC_check_errmsg_string ? errmsg_internal("%s", GUC_check_errmsg_string) : errmsg("invalid value for parameter \"%s\": \"%s\"", conf->gen.name, config_enum_lookup_by_value(conf, *newval)), GUC_check_errdetail_string ? errdetail_internal("%s", GUC_check_errdetail_string) : 0, GUC_check_errhint_string ? errhint("%s", GUC_check_errhint_string) : 0)) : (void) 0);
# 8275 "guc.c"
  FlushErrorState();
  return ((bool) 0);
 }

 return ((bool) 1);
}






static bool
check_log_destination(char **newval, void **extra, GucSource source)
{
 char *rawstring;
 List *elemlist;
 ListCell *l;
 int newlogdest = 0;
 int *myextra;


 rawstring = MemoryContextStrdup(CurrentMemoryContext, (*newval));


 if (!SplitIdentifierString(rawstring, ',', &elemlist))
 {

  pre_format_elog_string((*__error()), ((void *)0)), GUC_check_errdetail_string = format_elog_string("List syntax is invalid.");
  pfree(rawstring);
  list_free(elemlist);
  return ((bool) 0);
 }

 for ((l) = list_head(elemlist); (l) != ((void *)0); (l) = ((l)->next))
 {
  char *tok = (char *) ((l)->data.ptr_value);

  if (pg_strcasecmp(tok, "stderr") == 0)
   newlogdest |= 1;
  else if (pg_strcasecmp(tok, "csvlog") == 0)
   newlogdest |= 8;

  else if (pg_strcasecmp(tok, "syslog") == 0)
   newlogdest |= 2;





  else
  {
   pre_format_elog_string((*__error()), ((void *)0)), GUC_check_errdetail_string = format_elog_string("Unrecognized key word: \"%s\".", tok);
   pfree(rawstring);
   list_free(elemlist);
   return ((bool) 0);
  }
 }

 pfree(rawstring);
 list_free(elemlist);

 myextra = (int *) guc_malloc(20, sizeof(int));
 *myextra = newlogdest;
 *extra = (void *) myextra;

 return ((bool) 1);
}

static void
assign_log_destination(const char *newval, void *extra)
{
 Log_destination = *((int *) extra);
}

static void
assign_syslog_facility(int newval, void *extra)
{

 set_syslog_parameters(syslog_ident_str ? syslog_ident_str : "postgres",
        newval);


}

static void
assign_syslog_ident(const char *newval, void *extra)
{

 set_syslog_parameters(newval, syslog_facility);


}


static void
assign_session_replication_role(int newval, void *extra)
{




 if (SessionReplicationRole != newval)
  ResetPlanCache();
}

static bool
check_temp_buffers(int *newval, void **extra, GucSource source)
{



 if (NLocBuffer && NLocBuffer != *newval)
 {
  pre_format_elog_string((*__error()), ((void *)0)), GUC_check_errdetail_string = format_elog_string("\"temp_buffers\" cannot be changed after any temporary tables have been accessed in the session.");
  return ((bool) 0);
 }
 return ((bool) 1);
}

static bool
check_phony_autocommit(bool *newval, void **extra, GucSource source)
{
 if (!*newval)
 {
  GUC_check_errcode((((('0') - '0') & 0x3F) + (((('A') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24)));
  pre_format_elog_string((*__error()), ((void *)0)), GUC_check_errmsg_string = format_elog_string("SET AUTOCOMMIT TO OFF is no longer supported");
  return ((bool) 0);
 }
 return ((bool) 1);
}

static bool
check_debug_assertions(bool *newval, void **extra, GucSource source)
{

 if (*newval)
 {
  pre_format_elog_string((*__error()), ((void *)0)), GUC_check_errmsg_string = format_elog_string("assertion checking is not supported by this build");
  return ((bool) 0);
 }

 return ((bool) 1);
}

static bool
check_bonjour(bool *newval, void **extra, GucSource source)
{

 if (*newval)
 {
  pre_format_elog_string((*__error()), ((void *)0)), GUC_check_errmsg_string = format_elog_string("Bonjour is not supported by this build");
  return ((bool) 0);
 }

 return ((bool) 1);
}

static bool
check_ssl(bool *newval, void **extra, GucSource source)
{

 if (*newval)
 {
  pre_format_elog_string((*__error()), ((void *)0)), GUC_check_errmsg_string = format_elog_string("SSL is not supported by this build");
  return ((bool) 0);
 }

 return ((bool) 1);
}

static bool
check_stage_log_stats(bool *newval, void **extra, GucSource source)
{
 if (*newval && log_statement_stats)
 {
  pre_format_elog_string((*__error()), ((void *)0)), GUC_check_errdetail_string = format_elog_string("Cannot enable parameter when \"log_statement_stats\" is true.");
  return ((bool) 0);
 }
 return ((bool) 1);
}

static bool
check_log_stats(bool *newval, void **extra, GucSource source)
{
 if (*newval &&
  (log_parser_stats || log_planner_stats || log_executor_stats))
 {
  pre_format_elog_string((*__error()), ((void *)0)), GUC_check_errdetail_string = format_elog_string("Cannot enable \"log_statement_stats\" when "
       "\"log_parser_stats\", \"log_planner_stats\", "
       "or \"log_executor_stats\" is true.");
  return ((bool) 0);
 }
 return ((bool) 1);
}

static bool
check_canonical_path(char **newval, void **extra, GucSource source)
{





 if (*newval)
  canonicalize_path(*newval);
 return ((bool) 1);
}

static bool
check_timezone_abbreviations(char **newval, void **extra, GucSource source)
{
# 8498 "guc.c"
 if (*newval == ((void *)0))
 {
  ;
  return ((bool) 1);
 }


 *extra = load_tzoffsets(*newval);


 if (!*extra)
  return ((bool) 0);

 return ((bool) 1);
}

static void
assign_timezone_abbreviations(const char *newval, void *extra)
{

 if (!extra)
  return;

 InstallTimeZoneAbbrevs((TimeZoneAbbrevTable *) extra);
}
# 8534 "guc.c"
static void
pg_timezone_abbrev_initialize(void)
{
 SetConfigOption("timezone_abbreviations", "Default",
     PGC_POSTMASTER, PGC_S_DYNAMIC_DEFAULT);
}

static const char *
show_archive_command(void)
{
 if ((XLogArchiveMode && wal_level >= WAL_LEVEL_ARCHIVE))
  return XLogArchiveCommand;
 else
  return "(disabled)";
}

static void
assign_tcp_keepalives_idle(int newval, void *extra)
{
# 8564 "guc.c"
 (void) pq_setkeepalivesidle(newval, MyProcPort);
}

static const char *
show_tcp_keepalives_idle(void)
{

 static char nbuf[16];

 __builtin___snprintf_chk (nbuf, sizeof(nbuf), 0, __builtin_object_size (nbuf, 2 > 1), "%d", pq_getkeepalivesidle(MyProcPort));
 return nbuf;
}

static void
assign_tcp_keepalives_interval(int newval, void *extra)
{

 (void) pq_setkeepalivesinterval(newval, MyProcPort);
}

static const char *
show_tcp_keepalives_interval(void)
{

 static char nbuf[16];

 __builtin___snprintf_chk (nbuf, sizeof(nbuf), 0, __builtin_object_size (nbuf, 2 > 1), "%d", pq_getkeepalivesinterval(MyProcPort));
 return nbuf;
}

static void
assign_tcp_keepalives_count(int newval, void *extra)
{

 (void) pq_setkeepalivescount(newval, MyProcPort);
}

static const char *
show_tcp_keepalives_count(void)
{

 static char nbuf[16];

 __builtin___snprintf_chk (nbuf, sizeof(nbuf), 0, __builtin_object_size (nbuf, 2 > 1), "%d", pq_getkeepalivescount(MyProcPort));
 return nbuf;
}

static bool
check_maxconnections(int *newval, void **extra, GucSource source)
{
 if (*newval + autovacuum_max_workers + 1 > 0x7fffff)
  return ((bool) 0);
 return ((bool) 1);
}

static void
assign_maxconnections(int newval, void *extra)
{
 MaxBackends = newval + autovacuum_max_workers + 1;
}

static bool
check_autovacuum_max_workers(int *newval, void **extra, GucSource source)
{
 if (MaxConnections + *newval + 1 > 0x7fffff)
  return ((bool) 0);
 return ((bool) 1);
}

static void
assign_autovacuum_max_workers(int newval, void *extra)
{
 MaxBackends = MaxConnections + newval + 1;
}

static bool
check_effective_io_concurrency(int *newval, void **extra, GucSource source)
{
# 8695 "guc.c"
 return ((bool) 1);

}

static void
assign_effective_io_concurrency(int newval, void *extra)
{



}

static void
assign_pgstat_temp_directory(const char *newval, void *extra)
{

 char *tname;
 char *fname;

 tname = guc_malloc(20, strlen(newval) + 12);
 __builtin___sprintf_chk (tname, 0, __builtin_object_size (tname, 2 > 1), "%s/pgstat.tmp", newval);
 fname = guc_malloc(20, strlen(newval) + 13);
 __builtin___sprintf_chk (fname, 0, __builtin_object_size (fname, 2 > 1), "%s/pgstat.stat", newval);

 if (pgstat_stat_tmpname)
  free(pgstat_stat_tmpname);
 pgstat_stat_tmpname = tname;
 if (pgstat_stat_filename)
  free(pgstat_stat_filename);
 pgstat_stat_filename = fname;
}

static bool
check_application_name(char **newval, void **extra, GucSource source)
{

 char *p;

 for (p = *newval; *p; p++)
 {
  if (*p < 32 || *p > 126)
   *p = '?';
 }

 return ((bool) 1);
}

static void
assign_application_name(const char *newval, void *extra)
{

 pgstat_report_appname(newval);
}

static const char *
show_unix_socket_permissions(void)
{
 static char buf[8];

 __builtin___snprintf_chk (buf, sizeof(buf), 0, __builtin_object_size (buf, 2 > 1), "%04o", Unix_socket_permissions);
 return buf;
}

static const char *
show_log_file_mode(void)
{
 static char buf[8];

 __builtin___snprintf_chk (buf, sizeof(buf), 0, __builtin_object_size (buf, 2 > 1), "%04o", Log_file_mode);
 return buf;
}

# 1 "guc-file.c" 1
# 2 "guc-file.c"
# 4 "guc-file.c"
# 41 "guc-file.c"
# 1 "/usr/include/errno.h" 1 3 4
# 42 "guc-file.c" 2
# 70 "guc-file.c"
typedef signed char flex_int8_t;
typedef short int flex_int16_t;
typedef int flex_int32_t;
typedef unsigned char flex_uint8_t;
typedef unsigned short int flex_uint16_t;
typedef unsigned int flex_uint32_t;
# 181 "guc-file.c"
typedef struct yy_buffer_state *YY_BUFFER_STATE;


extern int GUC_yyleng;

extern FILE *GUC_yyin, *GUC_yyout;
# 212 "guc-file.c"
typedef size_t yy_size_t;




struct yy_buffer_state
 {
 FILE *yy_input_file;

 char *yy_ch_buf;
 char *yy_buf_pos;




 yy_size_t yy_buf_size;




 int yy_n_chars;





 int yy_is_our_buffer;






 int yy_is_interactive;





 int yy_at_bol;

    int yy_bs_lineno;
    int yy_bs_column;




 int yy_fill_buffer;

 int yy_buffer_status;
# 277 "guc-file.c"
 };



static size_t yy_buffer_stack_top = 0;
static size_t yy_buffer_stack_max = 0;
static YY_BUFFER_STATE * yy_buffer_stack = 0;
# 301 "guc-file.c"
static char yy_hold_char;
static int yy_n_chars;
int GUC_yyleng;


static char *yy_c_buf_p = (char *) 0;
static int yy_init = 0;
static int yy_start = 0;




static int yy_did_buffer_switch_on_eof;

void GUC_yyrestart (FILE *input_file );
void GUC_yy_switch_to_buffer (YY_BUFFER_STATE new_buffer );
YY_BUFFER_STATE GUC_yy_create_buffer (FILE *file,int size );
void GUC_yy_delete_buffer (YY_BUFFER_STATE b );
void GUC_yy_flush_buffer (YY_BUFFER_STATE b );
void GUC_yypush_buffer_state (YY_BUFFER_STATE new_buffer );
void GUC_yypop_buffer_state (void );

static void GUC_yyensure_buffer_stack (void );
static void GUC_yy_load_buffer_state (void );
static void GUC_yy_init_buffer (YY_BUFFER_STATE b,FILE *file );



YY_BUFFER_STATE GUC_yy_scan_buffer (char *base,yy_size_t size );
YY_BUFFER_STATE GUC_yy_scan_string (const char *yy_str );
YY_BUFFER_STATE GUC_yy_scan_bytes (const char *bytes,int len );

void *GUC_yyalloc (yy_size_t );
void *GUC_yyrealloc (void *,yy_size_t );
void GUC_yyfree (void * );
# 366 "guc-file.c"
typedef unsigned char YY_CHAR;

FILE *GUC_yyin = (FILE *) 0, *GUC_yyout = (FILE *) 0;

typedef int yy_state_type;

extern int GUC_yylineno;

int GUC_yylineno = 1;

extern char *GUC_yytext;


static yy_state_type yy_get_previous_state (void );
static yy_state_type yy_try_NUL_trans (yy_state_type current_state );
static int yy_get_next_buffer (void );
static void yy_fatal_error (const char msg[] );
# 398 "guc-file.c"
struct yy_trans_info
 {
 flex_int32_t yy_verify;
 flex_int32_t yy_nxt;
 };
static const flex_int16_t yy_accept[41] =
    { 0,
        0, 0, 13, 11, 2, 1, 3, 11, 11, 9,
        8, 8, 10, 4, 2, 3, 0, 6, 0, 9,
        8, 8, 9, 0, 8, 8, 7, 7, 4, 4,
        0, 9, 8, 8, 7, 5, 5, 5, 5, 0
    } ;

static const flex_int32_t yy_ec[256] =
    { 0,
        1, 1, 1, 1, 1, 1, 1, 1, 2, 3,
        1, 1, 2, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 2, 1, 1, 4, 1, 1, 1, 5, 1,
        1, 1, 6, 1, 7, 8, 9, 10, 11, 11,
       11, 11, 11, 11, 11, 11, 11, 9, 1, 1,
       12, 1, 1, 1, 13, 13, 13, 13, 14, 13,
       15, 15, 15, 15, 15, 15, 15, 15, 15, 15,
       15, 15, 15, 15, 15, 15, 15, 15, 15, 15,
        1, 16, 1, 1, 17, 1, 13, 13, 13, 13,

       14, 13, 15, 15, 15, 15, 15, 15, 15, 15,
       15, 15, 15, 15, 15, 15, 15, 15, 15, 18,
       15, 15, 1, 1, 1, 1, 1, 19, 19, 19,
       19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
       19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
       19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
       19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
       19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
       19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
       19, 19, 19, 19, 19, 19, 19, 19, 19, 19,

       19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
       19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
       19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
       19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
       19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
       19, 19, 19, 19, 19
    } ;

static const flex_int32_t yy_meta[20] =
    { 0,
        1, 1, 2, 1, 1, 1, 3, 3, 3, 4,
        4, 1, 5, 6, 5, 1, 3, 5, 3
    } ;

static const flex_int16_t yy_base[48] =
    { 0,
        0, 0, 50, 148, 43, 148, 0, 15, 24, 30,
       28, 22, 148, 40, 35, 0, 17, 25, 0, 15,
        0, 10, 0, 52, 0, 54, 10, 66, 79, 0,
       13, 15, 0, 0, 4, 90, 101, 0, 0, 148,
      118, 124, 127, 131, 133, 137, 141
    } ;

static const flex_int16_t yy_def[48] =
    { 0,
       40, 1, 40, 40, 40, 40, 41, 42, 40, 43,
       40, 11, 40, 44, 40, 41, 42, 40, 42, 43,
       11, 11, 20, 40, 45, 40, 46, 40, 44, 29,
       40, 40, 26, 26, 46, 47, 47, 37, 37, 0,
       40, 40, 40, 40, 40, 40, 40
    } ;

static const flex_int16_t yy_nxt[168] =
    { 0,
        4, 5, 6, 7, 8, 9, 9, 10, 4, 11,
       12, 13, 14, 14, 14, 4, 14, 14, 14, 18,
       35, 18, 32, 32, 32, 32, 35, 25, 24, 17,
       19, 20, 19, 21, 22, 20, 15, 22, 22, 25,
       25, 25, 25, 24, 15, 26, 27, 28, 27, 40,
       40, 40, 40, 40, 40, 40, 30, 31, 31, 40,
       40, 32, 32, 33, 33, 40, 34, 34, 25, 40,
       40, 25, 27, 27, 27, 27, 27, 40, 36, 36,
       36, 40, 37, 36, 36, 27, 28, 27, 40, 40,
       40, 40, 40, 40, 40, 30, 27, 27, 27, 40,

       40, 40, 40, 40, 40, 40, 39, 27, 27, 27,
       40, 40, 40, 40, 40, 40, 40, 39, 16, 40,
       16, 16, 16, 16, 17, 40, 17, 17, 17, 17,
       23, 40, 23, 29, 29, 29, 29, 25, 25, 27,
       27, 27, 27, 38, 38, 38, 38, 3, 40, 40,
       40, 40, 40, 40, 40, 40, 40, 40, 40, 40,
       40, 40, 40, 40, 40, 40, 40
    } ;

static const flex_int16_t yy_chk[168] =
    { 0,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 8,
       35, 17, 31, 31, 32, 32, 27, 22, 20, 18,
        8, 9, 17, 9, 9, 11, 15, 11, 11, 12,
       11, 11, 11, 10, 5, 11, 14, 14, 14, 3,
        0, 0, 0, 0, 0, 0, 14, 24, 24, 0,
        0, 24, 24, 26, 26, 0, 26, 26, 26, 0,
        0, 26, 28, 28, 28, 28, 28, 0, 28, 28,
       28, 0, 28, 28, 28, 29, 29, 29, 0, 0,
        0, 0, 0, 0, 0, 29, 36, 36, 36, 0,

        0, 0, 0, 0, 0, 0, 36, 37, 37, 37,
        0, 0, 0, 0, 0, 0, 0, 37, 41, 0,
       41, 41, 41, 41, 42, 0, 42, 42, 42, 42,
       43, 0, 43, 44, 44, 44, 44, 45, 45, 46,
       46, 46, 46, 47, 47, 47, 47, 40, 40, 40,
       40, 40, 40, 40, 40, 40, 40, 40, 40, 40,
       40, 40, 40, 40, 40, 40, 40
    } ;

static yy_state_type yy_last_accepting_state;
static char *yy_last_accepting_cpos;

extern int GUC_yy_flex_debug;
int GUC_yy_flex_debug = 0;
# 524 "guc-file.c"
char *GUC_yytext;
# 1 "guc-file.l"
# 11 "guc-file.l"




# 1 "./unistd.h" 1
# 16 "guc-file.l" 2

# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/mb/pg_wchar.h" 1
# 25 "/Users/parrt/tmp/postgresql-9.2.4/src/include/mb/pg_wchar.h"
typedef unsigned int pg_wchar;
# 179 "/Users/parrt/tmp/postgresql-9.2.4/src/include/mb/pg_wchar.h"
typedef enum pg_enc
{
 PG_SQL_ASCII = 0,
 PG_EUC_JP,
 PG_EUC_CN,
 PG_EUC_KR,
 PG_EUC_TW,
 PG_EUC_JIS_2004,
 PG_UTF8,
 PG_MULE_INTERNAL,
 PG_LATIN1,
 PG_LATIN2,
 PG_LATIN3,
 PG_LATIN4,
 PG_LATIN5,
 PG_LATIN6,
 PG_LATIN7,
 PG_LATIN8,
 PG_LATIN9,
 PG_LATIN10,
 PG_WIN1256,
 PG_WIN1258,
 PG_WIN866,
 PG_WIN874,
 PG_KOI8R,
 PG_WIN1251,
 PG_WIN1252,
 PG_ISO_8859_5,
 PG_ISO_8859_6,
 PG_ISO_8859_7,
 PG_ISO_8859_8,
 PG_WIN1250,
 PG_WIN1253,
 PG_WIN1254,
 PG_WIN1255,
 PG_WIN1257,
 PG_KOI8U,



 PG_SJIS,
 PG_BIG5,
 PG_GBK,
 PG_UHC,
 PG_GB18030,
 PG_JOHAB,
 PG_SHIFT_JIS_2004,
 _PG_LAST_ENCODING_

} pg_enc;
# 251 "/Users/parrt/tmp/postgresql-9.2.4/src/include/mb/pg_wchar.h"
typedef struct pg_encname
{
 char *name;
 pg_enc encoding;
} pg_encname;

extern pg_encname pg_encname_tbl[];
extern unsigned int pg_encname_tbl_sz;







typedef struct pg_enc2name
{
 char *name;
 pg_enc encoding;



} pg_enc2name;

extern pg_enc2name pg_enc2name_tbl[];




typedef struct pg_enc2gettext
{
 pg_enc encoding;
 const char *name;
} pg_enc2gettext;

extern pg_enc2gettext pg_enc2gettext_tbl[];




typedef int (*mb2wchar_with_len_converter) (const unsigned char *from,
             pg_wchar *to,
             int len);

typedef int (*wchar2mb_with_len_converter) (const pg_wchar *from,
              unsigned char *to,
              int len);

typedef int (*mblen_converter) (const unsigned char *mbstr);

typedef int (*mbdisplaylen_converter) (const unsigned char *mbstr);

typedef bool (*mbcharacter_incrementer) (unsigned char *mbstr, int len);

typedef int (*mbverifier) (const unsigned char *mbstr, int len);

typedef struct
{
 mb2wchar_with_len_converter mb2wchar_with_len;

 wchar2mb_with_len_converter wchar2mb_with_len;

 mblen_converter mblen;
 mbdisplaylen_converter dsplen;
 mbverifier mbverify;
 int maxmblen;
} pg_wchar_tbl;

extern pg_wchar_tbl pg_wchar_table[];






typedef struct
{
 uint32 utf;
 uint32 code;
} pg_utf_to_local;




typedef struct
{
 uint32 code;
 uint32 utf;
} pg_local_to_utf;




typedef struct
{
 uint32 utf1;
 uint32 utf2;
 uint32 code;
} pg_utf_to_local_combined;




typedef struct
{
 uint32 code;
 uint32 utf1;
 uint32 utf2;
} pg_local_to_utf_combined;
# 379 "/Users/parrt/tmp/postgresql-9.2.4/src/include/mb/pg_wchar.h"
extern int pg_char_to_encoding(const char *name);
extern const char *pg_encoding_to_char(int encoding);
extern int pg_valid_server_encoding_id(int encoding);





extern pg_encname *pg_char_to_encname_struct(const char *name);

extern int pg_mb2wchar(const char *from, pg_wchar *to);
extern int pg_mb2wchar_with_len(const char *from, pg_wchar *to, int len);
extern int pg_encoding_mb2wchar_with_len(int encoding,
         const char *from, pg_wchar *to, int len);
extern int pg_wchar2mb(const pg_wchar *from, char *to);
extern int pg_wchar2mb_with_len(const pg_wchar *from, char *to, int len);
extern int pg_encoding_wchar2mb_with_len(int encoding,
         const pg_wchar *from, char *to, int len);
extern int pg_char_and_wchar_strcmp(const char *s1, const pg_wchar *s2);
extern int pg_wchar_strncmp(const pg_wchar *s1, const pg_wchar *s2, size_t n);
extern int pg_char_and_wchar_strncmp(const char *s1, const pg_wchar *s2, size_t n);
extern size_t pg_wchar_strlen(const pg_wchar *wstr);
extern int pg_mblen(const char *mbstr);
extern int pg_dsplen(const char *mbstr);
extern int pg_encoding_mblen(int encoding, const char *mbstr);
extern int pg_encoding_dsplen(int encoding, const char *mbstr);
extern int pg_encoding_verifymb(int encoding, const char *mbstr, int len);
extern int pg_mule_mblen(const unsigned char *mbstr);
extern int pg_mic_mblen(const unsigned char *mbstr);
extern int pg_mbstrlen(const char *mbstr);
extern int pg_mbstrlen_with_len(const char *mbstr, int len);
extern int pg_mbcliplen(const char *mbstr, int len, int limit);
extern int pg_encoding_mbcliplen(int encoding, const char *mbstr,
       int len, int limit);
extern int pg_mbcharcliplen(const char *mbstr, int len, int imit);
extern int pg_encoding_max_length(int encoding);
extern int pg_database_encoding_max_length(void);
extern mbcharacter_incrementer pg_database_encoding_character_incrementer(void);

extern int PrepareClientEncoding(int encoding);
extern int SetClientEncoding(int encoding);
extern void InitializeClientEncoding(void);
extern int pg_get_client_encoding(void);
extern const char *pg_get_client_encoding_name(void);

extern void SetDatabaseEncoding(int encoding);
extern int GetDatabaseEncoding(void);
extern const char *GetDatabaseEncodingName(void);
extern int GetPlatformEncoding(void);
extern void pg_bind_textdomain_codeset(const char *domainname);

extern int pg_valid_client_encoding(const char *name);
extern int pg_valid_server_encoding(const char *name);

extern unsigned char *unicode_to_utf8(pg_wchar c, unsigned char *utf8string);
extern pg_wchar utf8_to_unicode(const unsigned char *c);
extern int pg_utf_mblen(const unsigned char *);
extern unsigned char *pg_do_encoding_conversion(unsigned char *src, int len,
        int src_encoding,
        int dest_encoding);

extern char *pg_client_to_server(const char *s, int len);
extern char *pg_server_to_client(const char *s, int len);
extern char *pg_any_to_server(const char *s, int len, int encoding);
extern char *pg_server_to_any(const char *s, int len, int encoding);

extern unsigned short BIG5toCNS(unsigned short big5, unsigned char *lc);
extern unsigned short CNStoBIG5(unsigned short cns, unsigned char lc);

extern void LocalToUtf(const unsigned char *iso, unsigned char *utf,
     const pg_local_to_utf *map, const pg_local_to_utf_combined *cmap,
     int size1, int size2, int encoding, int len);

extern void UtfToLocal(const unsigned char *utf, unsigned char *iso,
     const pg_utf_to_local *map, const pg_utf_to_local_combined *cmap,
     int size1, int size2, int encoding, int len);

extern bool pg_verifymbstr(const char *mbstr, int len, bool noError);
extern bool pg_verify_mbstr(int encoding, const char *mbstr, int len,
    bool noError);
extern int pg_verify_mbstr_len(int encoding, const char *mbstr, int len,
     bool noError);

extern void check_encoding_conversion_args(int src_encoding,
          int dest_encoding,
          int len,
          int expected_src_encoding,
          int expected_dest_encoding);

extern void report_invalid_encoding(int encoding, const char *mbstr, int len);
extern void report_untranslatable_char(int src_encoding, int dest_encoding,
         const char *mbstr, int len);

extern void pg_ascii2mic(const unsigned char *l, unsigned char *p, int len);
extern void pg_mic2ascii(const unsigned char *mic, unsigned char *p, int len);
extern void latin2mic(const unsigned char *l, unsigned char *p, int len,
    int lc, int encoding);
extern void mic2latin(const unsigned char *mic, unsigned char *p, int len,
    int lc, int encoding);
extern void latin2mic_with_table(const unsigned char *l, unsigned char *p,
      int len, int lc, int encoding,
      const unsigned char *tab);
extern void mic2latin_with_table(const unsigned char *mic, unsigned char *p,
      int len, int lc, int encoding,
      const unsigned char *tab);

extern bool pg_utf8_islegal(const unsigned char *source, int length);
# 18 "guc-file.l" 2


# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/utils/guc.h" 1
# 21 "guc-file.l" 2
# 32 "guc-file.l"
enum {
 GUC_ID = 1,
 GUC_STRING = 2,
 GUC_INTEGER = 3,
 GUC_REAL = 4,
 GUC_EQUALS = 5,
 GUC_UNQUOTED_STRING = 6,
 GUC_QUALIFIED_ID = 7,
 GUC_EOL = 99,
 GUC_ERROR = 100
};

static unsigned int ConfigFileLineno;
static const char *GUC_flex_fatal_errmsg;
static sigjmp_buf *GUC_flex_fatal_jmp;


int GUC_yylex(void);

static int GUC_flex_fatal(const char *msg);
static char *GUC_scanstr(const char *s);
# 580 "guc-file.c"
# 588 "guc-file.c"
# 1 "./unistd.h" 1
# 589 "guc-file.c" 2






static int yy_init_globals (void );




int GUC_yylex_destroy (void );

int GUC_yyget_debug (void );

void GUC_yyset_debug (int debug_flag );

void * GUC_yyget_extra (void );

void GUC_yyset_extra (void * user_defined );

FILE *GUC_yyget_in (void );

void GUC_yyset_in (FILE * in_str );

FILE *GUC_yyget_out (void );

void GUC_yyset_out (FILE * out_str );

int GUC_yyget_leng (void );

char *GUC_yyget_text (void );

int GUC_yyget_lineno (void );

void GUC_yyset_lineno (int line_number );
# 736 "guc-file.c"
extern int GUC_yylex (void);
# 758 "guc-file.c"
int GUC_yylex (void)
{
 register yy_state_type yy_current_state;
 register char *yy_cp, *yy_bp;
 register int yy_act;
# 86 "guc-file.l"
# 768 "guc-file.c"

 if ( !(yy_init) )
  {
  (yy_init) = 1;





  if ( ! (yy_start) )
   (yy_start) = 1;

  if ( ! GUC_yyin )
   GUC_yyin = __stdinp;

  if ( ! GUC_yyout )
   GUC_yyout = __stdoutp;

  if ( ! ( (yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *)0)) ) {
   GUC_yyensure_buffer_stack ();
   (yy_buffer_stack)[(yy_buffer_stack_top)] =
    GUC_yy_create_buffer(GUC_yyin,16384 );
  }

  GUC_yy_load_buffer_state( );
  }

 while ( 1 )
  {
  yy_cp = (yy_c_buf_p);


  *yy_cp = (yy_hold_char);




  yy_bp = yy_cp;

  yy_current_state = (yy_start);
yy_match:
  do
   {
   register YY_CHAR yy_c = yy_ec[((unsigned int) (unsigned char) *yy_cp)];
   if ( yy_accept[yy_current_state] )
    {
    (yy_last_accepting_state) = yy_current_state;
    (yy_last_accepting_cpos) = yy_cp;
    }
   while ( yy_chk[yy_base[yy_current_state] + yy_c] != yy_current_state )
    {
    yy_current_state = (int) yy_def[yy_current_state];
    if ( yy_current_state >= 41 )
     yy_c = yy_meta[(unsigned int) yy_c];
    }
   yy_current_state = yy_nxt[yy_base[yy_current_state] + (unsigned int) yy_c];
   ++yy_cp;
   }
  while ( yy_current_state != 40 );
  yy_cp = (yy_last_accepting_cpos);
  yy_current_state = (yy_last_accepting_state);

yy_find_action:
  yy_act = yy_accept[yy_current_state];

  (GUC_yytext) = yy_bp; GUC_yyleng = (size_t) (yy_cp - yy_bp); (yy_hold_char) = *yy_cp; *yy_cp = '\0'; (yy_c_buf_p) = yy_cp;;

do_action:

  switch ( yy_act )
 {
   case 0:

   *yy_cp = (yy_hold_char);
   yy_cp = (yy_last_accepting_cpos);
   yy_current_state = (yy_last_accepting_state);
   goto yy_find_action;

case 1:


# 88 "guc-file.l"
ConfigFileLineno++; return GUC_EOL;
 break;
case 2:

# 89 "guc-file.l"

 break;
case 3:

# 90 "guc-file.l"

 break;
case 4:

# 92 "guc-file.l"
return GUC_ID;
 break;
case 5:

# 93 "guc-file.l"
return GUC_QUALIFIED_ID;
 break;
case 6:

# 94 "guc-file.l"
return GUC_STRING;
 break;
case 7:

# 95 "guc-file.l"
return GUC_UNQUOTED_STRING;
 break;
case 8:

# 96 "guc-file.l"
return GUC_INTEGER;
 break;
case 9:

# 97 "guc-file.l"
return GUC_REAL;
 break;
case 10:

# 98 "guc-file.l"
return GUC_EQUALS;
 break;
case 11:

# 100 "guc-file.l"
return GUC_ERROR;
 break;
case 12:

# 102 "guc-file.l"
yy_fatal_error( "flex scanner jammed" );
 break;
# 908 "guc-file.c"
case (13 + 0 + 1):
 return 0;

 case 13:
  {

  int yy_amount_of_matched_text = (int) (yy_cp - (GUC_yytext)) - 1;


  *yy_cp = (yy_hold_char);
 

  if ( (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buffer_status == 0 )
   {
# 931 "guc-file.c"
   (yy_n_chars) = (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_n_chars;
   (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_input_file = GUC_yyin;
   (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buffer_status = 1;
   }
# 943 "guc-file.c"
  if ( (yy_c_buf_p) <= &(yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[(yy_n_chars)] )
   {
   yy_state_type yy_next_state;

   (yy_c_buf_p) = (GUC_yytext) + yy_amount_of_matched_text;

   yy_current_state = yy_get_previous_state( );
# 960 "guc-file.c"
   yy_next_state = yy_try_NUL_trans( yy_current_state );

   yy_bp = (GUC_yytext) + 0;

   if ( yy_next_state )
    {

    yy_cp = ++(yy_c_buf_p);
    yy_current_state = yy_next_state;
    goto yy_match;
    }

   else
    {
    yy_cp = (yy_last_accepting_cpos);
    yy_current_state = (yy_last_accepting_state);
    goto yy_find_action;
    }
   }

  else switch ( yy_get_next_buffer( ) )
   {
   case 1:
    {
    (yy_did_buffer_switch_on_eof) = 0;

    if ( 1 )
     {
# 997 "guc-file.c"
     (yy_c_buf_p) = (GUC_yytext) + 0;

     yy_act = (13 + (((yy_start) - 1) / 2) + 1);
     goto do_action;
     }

    else
     {
     if ( ! (yy_did_buffer_switch_on_eof) )
      GUC_yyrestart(GUC_yyin );
     }
    break;
    }

   case 0:
    (yy_c_buf_p) =
     (GUC_yytext) + yy_amount_of_matched_text;

    yy_current_state = yy_get_previous_state( );

    yy_cp = (yy_c_buf_p);
    yy_bp = (GUC_yytext) + 0;
    goto yy_match;

   case 2:
    (yy_c_buf_p) =
    &(yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[(yy_n_chars)];

    yy_current_state = yy_get_previous_state( );

    yy_cp = (yy_c_buf_p);
    yy_bp = (GUC_yytext) + 0;
    goto yy_find_action;
   }
  break;
  }

 default:
  yy_fatal_error( "fatal flex scanner internal error--no action found" );

 }
  }
}
# 1048 "guc-file.c"
static int yy_get_next_buffer (void)
{
     register char *dest = (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf;
 register char *source = (GUC_yytext);
 register int number_to_move, i;
 int ret_val;

 if ( (yy_c_buf_p) > &(yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[(yy_n_chars) + 1] )
  yy_fatal_error( "fatal flex scanner internal error--end of buffer missed" );


 if ( (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_fill_buffer == 0 )
  {
  if ( (yy_c_buf_p) - (GUC_yytext) - 0 == 1 )
   {



   return 1;
   }

  else
   {



   return 2;
   }
  }




 number_to_move = (int) ((yy_c_buf_p) - (GUC_yytext)) - 1;

 for ( i = 0; i < number_to_move; ++i )
  *(dest++) = *(source++);

 if ( (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buffer_status == 2 )



  (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_n_chars = (yy_n_chars) = 0;

 else
  {
   int num_to_read =
   (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buf_size - number_to_move - 1;

  while ( num_to_read <= 0 )
   {


   YY_BUFFER_STATE b = ( (yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *)0));

   int yy_c_buf_p_offset =
    (int) ((yy_c_buf_p) - b->yy_ch_buf);

   if ( b->yy_is_our_buffer )
    {
    int new_size = b->yy_buf_size * 2;

    if ( new_size <= 0 )
     b->yy_buf_size += b->yy_buf_size / 8;
    else
     b->yy_buf_size *= 2;

    b->yy_ch_buf = (char *)

     GUC_yyrealloc((void *) b->yy_ch_buf,b->yy_buf_size + 2 );
    }
   else

    b->yy_ch_buf = 0;

   if ( ! b->yy_ch_buf )
    yy_fatal_error( "fatal error - scanner input buffer overflow" );


   (yy_c_buf_p) = &b->yy_ch_buf[yy_c_buf_p_offset];

   num_to_read = (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buf_size -
      number_to_move - 1;

   }

  if ( num_to_read > 8192 )
   num_to_read = 8192;


  if ( (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_is_interactive ) { int c = '*'; size_t n; for ( n = 0; n < (size_t) num_to_read && (c = getc( GUC_yyin )) != (-1) && c != '\n'; ++n ) (&(yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[number_to_move])[n] = (char) c; if ( c == '\n' ) (&(yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[number_to_move])[n++] = (char) c; if ( c == (-1) && ferror( GUC_yyin ) ) yy_fatal_error( "input in flex scanner failed" ); (yy_n_chars) = n; } else { (*__error())=0; while ( ((yy_n_chars) = fread((&(yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[number_to_move]), 1, (size_t) num_to_read, GUC_yyin))==0 && ferror(GUC_yyin)) { if( (*__error()) != 4) { yy_fatal_error( "input in flex scanner failed" ); break; } (*__error())=0; clearerr(GUC_yyin); } };


  (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_n_chars = (yy_n_chars);
  }

 if ( (yy_n_chars) == 0 )
  {
  if ( number_to_move == 0 )
   {
   ret_val = 1;
   GUC_yyrestart(GUC_yyin );
   }

  else
   {
   ret_val = 2;
   (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buffer_status =
    2;
   }
  }

 else
  ret_val = 0;

 if ((yy_size_t) ((yy_n_chars) + number_to_move) > (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buf_size) {

  yy_size_t new_size = (yy_n_chars) + number_to_move + ((yy_n_chars) >> 1);
  (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf = (char *) GUC_yyrealloc((void *) (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf,new_size );
  if ( ! (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf )
   yy_fatal_error( "out of dynamic memory in yy_get_next_buffer()" );
 }

 (yy_n_chars) += number_to_move;
 (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[(yy_n_chars)] = 0;
 (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[(yy_n_chars) + 1] = 0;

 (GUC_yytext) = &(yy_buffer_stack)[(yy_buffer_stack_top)]->yy_ch_buf[0];

 return ret_val;
}



    static yy_state_type yy_get_previous_state (void)
{
 register yy_state_type yy_current_state;
 register char *yy_cp;

 yy_current_state = (yy_start);

 for ( yy_cp = (GUC_yytext) + 0; yy_cp < (yy_c_buf_p); ++yy_cp )
  {
  register YY_CHAR yy_c = (*yy_cp ? yy_ec[((unsigned int) (unsigned char) *yy_cp)] : 1);
  if ( yy_accept[yy_current_state] )
   {
   (yy_last_accepting_state) = yy_current_state;
   (yy_last_accepting_cpos) = yy_cp;
   }
  while ( yy_chk[yy_base[yy_current_state] + yy_c] != yy_current_state )
   {
   yy_current_state = (int) yy_def[yy_current_state];
   if ( yy_current_state >= 41 )
    yy_c = yy_meta[(unsigned int) yy_c];
   }
  yy_current_state = yy_nxt[yy_base[yy_current_state] + (unsigned int) yy_c];
  }

 return yy_current_state;
}






    static yy_state_type yy_try_NUL_trans (yy_state_type yy_current_state )
{
 register int yy_is_jam;
     register char *yy_cp = (yy_c_buf_p);

 register YY_CHAR yy_c = 1;
 if ( yy_accept[yy_current_state] )
  {
  (yy_last_accepting_state) = yy_current_state;
  (yy_last_accepting_cpos) = yy_cp;
  }
 while ( yy_chk[yy_base[yy_current_state] + yy_c] != yy_current_state )
  {
  yy_current_state = (int) yy_def[yy_current_state];
  if ( yy_current_state >= 41 )
   yy_c = yy_meta[(unsigned int) yy_c];
  }
 yy_current_state = yy_nxt[yy_base[yy_current_state] + (unsigned int) yy_c];
 yy_is_jam = (yy_current_state == 40);

 return yy_is_jam ? 0 : yy_current_state;
}
# 1316 "guc-file.c"
    void GUC_yyrestart (FILE * input_file )
{

 if ( ! ( (yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *)0)) ){
        GUC_yyensure_buffer_stack ();
  (yy_buffer_stack)[(yy_buffer_stack_top)] =
            GUC_yy_create_buffer(GUC_yyin,16384 );
 }

 GUC_yy_init_buffer(( (yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *)0)),input_file );
 GUC_yy_load_buffer_state( );
}





    void GUC_yy_switch_to_buffer (YY_BUFFER_STATE new_buffer )
{






 GUC_yyensure_buffer_stack ();
 if ( ( (yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *)0)) == new_buffer )
  return;

 if ( ( (yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *)0)) )
  {

  *(yy_c_buf_p) = (yy_hold_char);
  (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buf_pos = (yy_c_buf_p);
  (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_n_chars = (yy_n_chars);
  }

 (yy_buffer_stack)[(yy_buffer_stack_top)] = new_buffer;
 GUC_yy_load_buffer_state( );






 (yy_did_buffer_switch_on_eof) = 1;
}

static void GUC_yy_load_buffer_state (void)
{
     (yy_n_chars) = (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_n_chars;
 (GUC_yytext) = (yy_c_buf_p) = (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buf_pos;
 GUC_yyin = (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_input_file;
 (yy_hold_char) = *(yy_c_buf_p);
}







    YY_BUFFER_STATE GUC_yy_create_buffer (FILE * file, int size )
{
 YY_BUFFER_STATE b;

 b = (YY_BUFFER_STATE) GUC_yyalloc(sizeof( struct yy_buffer_state ) );
 if ( ! b )
  yy_fatal_error( "out of dynamic memory in GUC_yy_create_buffer()" );

 b->yy_buf_size = size;




 b->yy_ch_buf = (char *) GUC_yyalloc(b->yy_buf_size + 2 );
 if ( ! b->yy_ch_buf )
  yy_fatal_error( "out of dynamic memory in GUC_yy_create_buffer()" );

 b->yy_is_our_buffer = 1;

 GUC_yy_init_buffer(b,file );

 return b;
}





    void GUC_yy_delete_buffer (YY_BUFFER_STATE b )
{

 if ( ! b )
  return;

 if ( b == ( (yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *)0)) )
  (yy_buffer_stack)[(yy_buffer_stack_top)] = (YY_BUFFER_STATE) 0;

 if ( b->yy_is_our_buffer )
  GUC_yyfree((void *) b->yy_ch_buf );

 GUC_yyfree((void *) b );
}





    static void GUC_yy_init_buffer (YY_BUFFER_STATE b, FILE * file )

{
 int oerrno = (*__error());

 GUC_yy_flush_buffer(b );

 b->yy_input_file = file;
 b->yy_fill_buffer = 1;





    if (b != ( (yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *)0))){
        b->yy_bs_lineno = 1;
        b->yy_bs_column = 0;
    }

        b->yy_is_interactive = 0;

 (*__error()) = oerrno;
}





    void GUC_yy_flush_buffer (YY_BUFFER_STATE b )
{
     if ( ! b )
  return;

 b->yy_n_chars = 0;





 b->yy_ch_buf[0] = 0;
 b->yy_ch_buf[1] = 0;

 b->yy_buf_pos = &b->yy_ch_buf[0];

 b->yy_at_bol = 1;
 b->yy_buffer_status = 0;

 if ( b == ( (yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *)0)) )
  GUC_yy_load_buffer_state( );
}







void GUC_yypush_buffer_state (YY_BUFFER_STATE new_buffer )
{
     if (new_buffer == ((void *)0))
  return;

 GUC_yyensure_buffer_stack();


 if ( ( (yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *)0)) )
  {

  *(yy_c_buf_p) = (yy_hold_char);
  (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_buf_pos = (yy_c_buf_p);
  (yy_buffer_stack)[(yy_buffer_stack_top)]->yy_n_chars = (yy_n_chars);
  }


 if (( (yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *)0)))
  (yy_buffer_stack_top)++;
 (yy_buffer_stack)[(yy_buffer_stack_top)] = new_buffer;


 GUC_yy_load_buffer_state( );
 (yy_did_buffer_switch_on_eof) = 1;
}





void GUC_yypop_buffer_state (void)
{
     if (!( (yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *)0)))
  return;

 GUC_yy_delete_buffer(( (yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *)0)) );
 (yy_buffer_stack)[(yy_buffer_stack_top)] = ((void *)0);
 if ((yy_buffer_stack_top) > 0)
  --(yy_buffer_stack_top);

 if (( (yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *)0))) {
  GUC_yy_load_buffer_state( );
  (yy_did_buffer_switch_on_eof) = 1;
 }
}




static void GUC_yyensure_buffer_stack (void)
{
 int num_to_alloc;

 if (!(yy_buffer_stack)) {





  num_to_alloc = 1;
  (yy_buffer_stack) = (struct yy_buffer_state**)GUC_yyalloc
        (num_to_alloc * sizeof(struct yy_buffer_state*)
        );
  if ( ! (yy_buffer_stack) )
   yy_fatal_error( "out of dynamic memory in GUC_yyensure_buffer_stack()" );

  ((__builtin_object_size ((yy_buffer_stack), 0) != (size_t) -1) ? __builtin___memset_chk ((yy_buffer_stack), 0, num_to_alloc * sizeof(struct yy_buffer_state*), __builtin_object_size ((yy_buffer_stack), 0)) : __inline_memset_chk ((yy_buffer_stack), 0, num_to_alloc * sizeof(struct yy_buffer_state*)));

  (yy_buffer_stack_max) = num_to_alloc;
  (yy_buffer_stack_top) = 0;
  return;
 }

 if ((yy_buffer_stack_top) >= ((yy_buffer_stack_max)) - 1){


  int grow_size = 8 ;

  num_to_alloc = (yy_buffer_stack_max) + grow_size;
  (yy_buffer_stack) = (struct yy_buffer_state**)GUC_yyrealloc
        ((yy_buffer_stack),
        num_to_alloc * sizeof(struct yy_buffer_state*)
        );
  if ( ! (yy_buffer_stack) )
   yy_fatal_error( "out of dynamic memory in GUC_yyensure_buffer_stack()" );


  ((__builtin_object_size ((yy_buffer_stack) + (yy_buffer_stack_max), 0) != (size_t) -1) ? __builtin___memset_chk ((yy_buffer_stack) + (yy_buffer_stack_max), 0, grow_size * sizeof(struct yy_buffer_state*), __builtin_object_size ((yy_buffer_stack) + (yy_buffer_stack_max), 0)) : __inline_memset_chk ((yy_buffer_stack) + (yy_buffer_stack_max), 0, grow_size * sizeof(struct yy_buffer_state*)));
  (yy_buffer_stack_max) = num_to_alloc;
 }
}







YY_BUFFER_STATE GUC_yy_scan_buffer (char * base, yy_size_t size )
{
 YY_BUFFER_STATE b;

 if ( size < 2 ||
      base[size-2] != 0 ||
      base[size-1] != 0 )

  return 0;

 b = (YY_BUFFER_STATE) GUC_yyalloc(sizeof( struct yy_buffer_state ) );
 if ( ! b )
  yy_fatal_error( "out of dynamic memory in GUC_yy_scan_buffer()" );

 b->yy_buf_size = size - 2;
 b->yy_buf_pos = b->yy_ch_buf = base;
 b->yy_is_our_buffer = 0;
 b->yy_input_file = 0;
 b->yy_n_chars = b->yy_buf_size;
 b->yy_is_interactive = 0;
 b->yy_at_bol = 1;
 b->yy_fill_buffer = 0;
 b->yy_buffer_status = 0;

 GUC_yy_switch_to_buffer(b );

 return b;
}
# 1617 "guc-file.c"
YY_BUFFER_STATE GUC_yy_scan_string (const char * yystr )
{

 return GUC_yy_scan_bytes(yystr,strlen(yystr) );
}
# 1630 "guc-file.c"
YY_BUFFER_STATE GUC_yy_scan_bytes (const char * yybytes, int _yybytes_len )
{
 YY_BUFFER_STATE b;
 char *buf;
 yy_size_t n;
 int i;


 n = _yybytes_len + 2;
 buf = (char *) GUC_yyalloc(n );
 if ( ! buf )
  yy_fatal_error( "out of dynamic memory in GUC_yy_scan_bytes()" );

 for ( i = 0; i < _yybytes_len; ++i )
  buf[i] = yybytes[i];

 buf[_yybytes_len] = buf[_yybytes_len+1] = 0;

 b = GUC_yy_scan_buffer(buf,n );
 if ( ! b )
  yy_fatal_error( "bad buffer in GUC_yy_scan_bytes()" );




 b->yy_is_our_buffer = 1;

 return b;
}





static void yy_fatal_error (const char* msg )
{
     (void) GUC_flex_fatal(msg);
 exit( 2 );
}
# 1692 "guc-file.c"
int GUC_yyget_lineno (void)
{

    return GUC_yylineno;
}




FILE *GUC_yyget_in (void)
{
        return GUC_yyin;
}




FILE *GUC_yyget_out (void)
{
        return GUC_yyout;
}




int GUC_yyget_leng (void)
{
        return GUC_yyleng;
}





char *GUC_yyget_text (void)
{
        return GUC_yytext;
}





void GUC_yyset_lineno (int line_number )
{

    GUC_yylineno = line_number;
}







void GUC_yyset_in (FILE * in_str )
{
        GUC_yyin = in_str ;
}

void GUC_yyset_out (FILE * out_str )
{
        GUC_yyout = out_str ;
}

int GUC_yyget_debug (void)
{
        return GUC_yy_flex_debug;
}

void GUC_yyset_debug (int bdebug )
{
        GUC_yy_flex_debug = bdebug ;
}

static int yy_init_globals (void)
{




    (yy_buffer_stack) = 0;
    (yy_buffer_stack_top) = 0;
    (yy_buffer_stack_max) = 0;
    (yy_c_buf_p) = (char *) 0;
    (yy_init) = 0;
    (yy_start) = 0;






    GUC_yyin = (FILE *) 0;
    GUC_yyout = (FILE *) 0;





    return 0;
}


int GUC_yylex_destroy (void)
{


 while(( (yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *)0))){
  GUC_yy_delete_buffer(( (yy_buffer_stack) ? (yy_buffer_stack)[(yy_buffer_stack_top)] : ((void *)0)) );
  (yy_buffer_stack)[(yy_buffer_stack_top)] = ((void *)0);
  GUC_yypop_buffer_state();
 }


 GUC_yyfree((yy_buffer_stack) );
 (yy_buffer_stack) = ((void *)0);



    yy_init_globals( );

    return 0;
}
# 1841 "guc-file.c"
void *GUC_yyalloc (yy_size_t size )
{
 return (void *) malloc( size );
}

void *GUC_yyrealloc (void * ptr, yy_size_t size )
{







 return (void *) realloc( (char *) ptr, size );
}

void GUC_yyfree (void * ptr )
{
 free( (char *) ptr );
}
# 102 "guc-file.l"
# 114 "guc-file.l"
void
ProcessConfigFile(GucContext context)
{
 bool error = ((bool) 0);
 bool apply = ((bool) 0);
 int elevel;
 ConfigVariable *item,
       *head,
       *tail;
 int i;





 ;






 elevel = IsUnderPostmaster ? 13 : 15;


 head = tail = ((void *)0);

 if (!ParseConfigFile(ConfigFileName, ((void *)0), ((bool) 1), 0, elevel, &head, &tail))
 {

  error = ((bool) 1);
  goto cleanup_list;
 }






 for (i = 0; i < num_guc_variables; i++)
 {
  struct config_generic *gconf = guc_variables[i];

  gconf->status &= ~0x0001;
 }
# 172 "guc-file.l"
 for (item = head; item; item = item->next)
 {
  struct config_generic *record;





  record = find_option(item->name, ((bool) 0), elevel);

  if (record)
  {

   record->status |= 0x0001;
  }
  else if (strchr(item->name, '.') == ((void *)0))
  {

   (errstart(elevel, "guc-file.l", 194, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('7') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('4') - '0') & 0x3F) << 24))), errmsg("unrecognized configuration parameter \"%s\" in file \"%s\" line %u", item->name, item->filename, item->sourceline))) : (void) 0);




   error = ((bool) 1);
  }
 }





 if (error)
  goto cleanup_list;


 apply = ((bool) 1);







 for (i = 0; i < num_guc_variables; i++)
 {
  struct config_generic *gconf = guc_variables[i];
  GucStack *stack;

  if (gconf->reset_source != PGC_S_FILE ||
   (gconf->status & 0x0001))
   continue;
  if (gconf->context < PGC_SIGHUP)
  {
   (errstart(elevel, "guc-file.l", 228, __func__, ((void *)0)) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('5') - '0') & 0x3F) << 6) + (((('P') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('2') - '0') & 0x3F) << 24))), errmsg("parameter \"%s\" cannot be changed without restarting the server", gconf->name))) : (void) 0);



   error = ((bool) 1);
   continue;
  }





  if (gconf->reset_source == PGC_S_FILE)
   gconf->reset_source = PGC_S_DEFAULT;
  if (gconf->source == PGC_S_FILE)
   gconf->source = PGC_S_DEFAULT;
  for (stack = gconf->stack; stack; stack = stack->prev)
  {
   if (stack->source == PGC_S_FILE)
    stack->source = PGC_S_DEFAULT;
  }


  if (set_config_option(gconf->name, ((void *)0),
         context, PGC_S_DEFAULT,
         GUC_ACTION_SET, ((bool) 1), 0) > 0)
  {

   if (context == PGC_SIGHUP)
    (errstart(elevel, "guc-file.l", 256, __func__, ((void *)0)) ? (errfinish (errmsg("parameter \"%s\" removed from configuration file, reset to default", gconf->name))) : (void) 0);


  }
 }
# 274 "guc-file.l"
 if (context == PGC_SIGHUP)
 {
  InitializeGUCOptionsFromEnvironment();
  pg_timezone_abbrev_initialize();

  SetConfigOption("client_encoding", GetDatabaseEncodingName(),
      PGC_BACKEND, PGC_S_DYNAMIC_DEFAULT);
 }




 for (item = head; item; item = item->next)
 {
  char *pre_value = ((void *)0);
  int scres;


  if (context == PGC_SIGHUP && !IsUnderPostmaster)
  {
   const char *preval = GetConfigOption(item->name, ((bool) 1), ((bool) 0));


   if (!preval)
    preval = "";

   pre_value = MemoryContextStrdup(CurrentMemoryContext, (preval));
  }

  scres = set_config_option(item->name, item->value,
          context, PGC_S_FILE,
          GUC_ACTION_SET, ((bool) 1), 0);
  if (scres > 0)
  {

   if (pre_value)
   {
    const char *post_value = GetConfigOption(item->name, ((bool) 1), ((bool) 0));

    if (!post_value)
     post_value = "";
    if (strcmp(pre_value, post_value) != 0)
     (errstart(elevel, "guc-file.l", 318, __func__, ((void *)0)) ? (errfinish (errmsg("parameter \"%s\" changed to \"%s\"", item->name, item->value))) : (void) 0);


   }
  }
  else if (scres == 0)
   error = ((bool) 1);
# 331 "guc-file.l"
  if (scres != 0)
   set_config_sourcefile(item->name, item->filename,
          item->sourceline);

  if (pre_value)
   pfree(pre_value);
 }


 PgReloadTime = GetCurrentTimestamp();

 cleanup_list:
 FreeConfigVariables(head);

 if (error)
 {

  if (context == PGC_POSTMASTER)
   (errstart(20, "guc-file.l", 352, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("configuration file \"%s\" contains errors", ConfigFileName))) : (void) 0);



  else if (apply)
   (errstart(elevel, "guc-file.l", 357, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("configuration file \"%s\" contains errors; unaffected changes were applied", ConfigFileName))) : (void) 0);



  else
   (errstart(elevel, "guc-file.l", 362, __func__, ((void *)0)) ? (errfinish (errcode((((('F') - '0') & 0x3F) + (((('0') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("configuration file \"%s\" contains errors; no changes were applied", ConfigFileName))) : (void) 0);



 }
}
# 374 "guc-file.l"
bool
ParseConfigFile(const char *config_file, const char *calling_file, bool strict,
    int depth, int elevel,
    ConfigVariable **head_p,
    ConfigVariable **tail_p)
{
 bool OK = ((bool) 1);
 FILE *fp;
 char abs_path[1024];






 if (depth > 10)
 {
  (errstart(elevel, "guc-file.l", 394, __func__, ((void *)0)) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('4') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("could not open configuration file \"%s\": maximum nesting depth exceeded", config_file))) : (void) 0);



  return ((bool) 0);
 }





 if (!( (((config_file)[0]) == '/') ))
 {
  if (calling_file != ((void *)0))
  {
   strlcpy(abs_path, calling_file, sizeof(abs_path));
   get_parent_directory(abs_path);
   join_path_components(abs_path, abs_path, config_file);
   canonicalize_path(abs_path);
   config_file = abs_path;
  }
  else
  {



   join_path_components(abs_path, data_directory, config_file);
   canonicalize_path(abs_path);
   config_file = abs_path;
  }
 }

 fp = AllocateFile(config_file, "r");
 if (!fp)
 {
  if (strict)
  {
   (errstart(elevel, "guc-file.l", 431, __func__, ((void *)0)) ? (errfinish (errcode_for_file_access(), errmsg("could not open configuration file \"%s\": %m", config_file))) : (void) 0);



   return ((bool) 0);
  }

  (errstart(15, "guc-file.l", 437, __func__, ((void *)0)) ? (errfinish (errmsg("skipping missing configuration file \"%s\"", config_file))) : (void) 0);


  return OK;
 }

 OK = ParseConfigFp(fp, config_file, depth, elevel, head_p, tail_p);

 FreeFile(fp);

 return OK;
}
# 456 "guc-file.l"
static int
GUC_flex_fatal(const char *msg)
{
 GUC_flex_fatal_errmsg = msg;
 siglongjmp(*GUC_flex_fatal_jmp, 1);
 return 0;
}
# 487 "guc-file.l"
bool
ParseConfigFp(FILE *fp, const char *config_file, int depth, int elevel,
     ConfigVariable **head_p, ConfigVariable **tail_p)
{
 volatile bool OK = ((bool) 1);
 unsigned int save_ConfigFileLineno = ConfigFileLineno;
 sigjmp_buf *save_GUC_flex_fatal_jmp = GUC_flex_fatal_jmp;
 sigjmp_buf flex_fatal_jmp;
 volatile YY_BUFFER_STATE lex_buffer = ((void *)0);
 int errorcount;
 int token;

 if (sigsetjmp(flex_fatal_jmp, 1) == 0)
  GUC_flex_fatal_jmp = &flex_fatal_jmp;
 else
 {





  elog_start("guc-file.l", 508, __func__), elog_finish(elevel, "%s at file \"%s\" line %u",
    GUC_flex_fatal_errmsg, config_file, ConfigFileLineno);

  OK = ((bool) 0);
  goto cleanup;
 }




 ConfigFileLineno = 1;
 errorcount = 0;

 lex_buffer = GUC_yy_create_buffer(fp,16384);
 GUC_yy_switch_to_buffer(lex_buffer);


 while ((token = GUC_yylex()))
 {
  char *opt_name = ((void *)0);
  char *opt_value = ((void *)0);
  ConfigVariable *item;

  if (token == GUC_EOL)
   continue;


  if (token != GUC_ID && token != GUC_QUALIFIED_ID)
   goto parse_error;
  opt_name = MemoryContextStrdup(CurrentMemoryContext, (GUC_yytext));


  token = GUC_yylex();
  if (token == GUC_EQUALS)
   token = GUC_yylex();


  if (token != GUC_ID &&
   token != GUC_STRING &&
   token != GUC_INTEGER &&
   token != GUC_REAL &&
   token != GUC_UNQUOTED_STRING)
   goto parse_error;
  if (token == GUC_STRING)
   opt_value = GUC_scanstr(GUC_yytext);
  else
   opt_value = MemoryContextStrdup(CurrentMemoryContext, (GUC_yytext));


  token = GUC_yylex();
  if (token != GUC_EOL)
  {
   if (token != 0)
    goto parse_error;

   ConfigFileLineno++;
  }


  if (guc_name_compare(opt_name, "include_if_exists") == 0)
  {




   if (!ParseConfigFile(opt_value, config_file, ((bool) 0),
         depth + 1, elevel,
         head_p, tail_p))
    OK = ((bool) 0);
   GUC_yy_switch_to_buffer(lex_buffer);
   pfree(opt_name);
   pfree(opt_value);
  }
  else if (guc_name_compare(opt_name, "include") == 0)
  {




   if (!ParseConfigFile(opt_value, config_file, ((bool) 1),
         depth + 1, elevel,
         head_p, tail_p))
    OK = ((bool) 0);
   GUC_yy_switch_to_buffer(lex_buffer);
   pfree(opt_name);
   pfree(opt_value);
  }
  else
  {

   item = MemoryContextAlloc(CurrentMemoryContext, (sizeof *item));
   item->name = opt_name;
   item->value = opt_value;
   item->filename = MemoryContextStrdup(CurrentMemoryContext, (config_file));
   item->sourceline = ConfigFileLineno-1;
   item->next = ((void *)0);
   if (*head_p == ((void *)0))
    *head_p = item;
   else
    (*tail_p)->next = item;
   *tail_p = item;
  }


  if (token == 0)
   break;
  continue;

 parse_error:

  if (opt_name)
   pfree(opt_name);
  if (opt_value)
   pfree(opt_value);


  if (token == GUC_EOL || token == 0)
   (errstart(elevel, "guc-file.l", 628, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('6') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('1') - '0') & 0x3F) << 24))), errmsg("syntax error in file \"%s\" line %u, near end of line", config_file, ConfigFileLineno - 1))) : (void) 0);



  else
   (errstart(elevel, "guc-file.l", 633, __func__, ((void *)0)) ? (errfinish (errcode((((('4') - '0') & 0x3F) + (((('2') - '0') & 0x3F) << 6) + (((('6') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('1') - '0') & 0x3F) << 24))), errmsg("syntax error in file \"%s\" line %u, near token \"%s\"", config_file, ConfigFileLineno, GUC_yytext))) : (void) 0);



  OK = ((bool) 0);
  errorcount++;
# 644 "guc-file.l"
  if (errorcount >= 100 || elevel <= 14)
  {
   (errstart(elevel, "guc-file.l", 649, __func__, ((void *)0)) ? (errfinish (errcode((((('5') - '0') & 0x3F) + (((('4') - '0') & 0x3F) << 6) + (((('0') - '0') & 0x3F) << 12) + (((('0') - '0') & 0x3F) << 18) + (((('0') - '0') & 0x3F) << 24))), errmsg("too many syntax errors found, abandoning file \"%s\"", config_file))) : (void) 0);



   break;
  }


  while (token != GUC_EOL && token != 0)
   token = GUC_yylex();

  if (token == 0)
   break;
 }

cleanup:
 GUC_yy_delete_buffer(lex_buffer);

 ConfigFileLineno = save_ConfigFileLineno;
 GUC_flex_fatal_jmp = save_GUC_flex_fatal_jmp;
 return OK;
}





void
FreeConfigVariables(ConfigVariable *list)
{
 ConfigVariable *item;

 item = list;
 while (item)
 {
  ConfigVariable *next = item->next;

  pfree(item->name);
  pfree(item->value);
  pfree(item->filename);
  pfree(item);
  item = next;
 }
}
# 701 "guc-file.l"
static char *
GUC_scanstr(const char *s)
{
 char *newStr;
 int len,
    i,
    j;

 ;
 len = strlen(s);
 ;
 ;


 s++, len--;


 newStr = MemoryContextAlloc(CurrentMemoryContext, (len));

 for (i = 0, j = 0; i < len; i++)
 {
  if (s[i] == '\\')
  {
   i++;
   switch (s[i])
   {
    case 'b':
     newStr[j] = '\b';
     break;
    case 'f':
     newStr[j] = '\f';
     break;
    case 'n':
     newStr[j] = '\n';
     break;
    case 'r':
     newStr[j] = '\r';
     break;
    case 't':
     newStr[j] = '\t';
     break;
    case '0':
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
    case '6':
    case '7':
     {
      int k;
      long octVal = 0;

      for (k = 0;
        s[i + k] >= '0' && s[i + k] <= '7' && k < 3;
        k++)
       octVal = (octVal << 3) + (s[i + k] - '0');
      i += k - 1;
      newStr[j] = ((char) octVal);
     }
     break;
    default:
     newStr[j] = s[i];
     break;
   }
  }
  else if (s[i] == '\'' && s[i+1] == '\'')
  {

   newStr[j] = s[++i];
  }
  else
   newStr[j] = s[i];
  j++;
 }


 ;
 newStr[--j] = '\0';

 return newStr;
}
# 8767 "guc.c" 2

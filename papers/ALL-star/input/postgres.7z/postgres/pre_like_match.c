# 1 "like_match.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "like_match.c"
# 78 "like_match.c"
static int
MatchText(char *t, int tlen, char *p, int plen,
    pg_locale_t locale, bool locale_is_c)
{

 if (plen == 1 && *p == '%')
  return LIKE_TRUE;
# 94 "like_match.c"
 while (tlen > 0 && plen > 0)
 {
  if (*p == '\\')
  {

   NextByte(p, plen);

   if (plen <= 0)
    ereport(ERROR,
      (errcode(ERRCODE_INVALID_ESCAPE_SEQUENCE),
     errmsg("LIKE pattern must not end with escape character")));
   if ((*p) != (*t))
    return LIKE_FALSE;
  }
  else if (*p == '%')
  {
   char firstpat;
# 125 "like_match.c"
   NextByte(p, plen);

   while (plen > 0)
   {
    if (*p == '%')
     NextByte(p, plen);
    else if (*p == '_')
    {

     if (tlen <= 0)
      return LIKE_ABORT;
     NextChar(t, tlen);
     NextByte(p, plen);
    }
    else
     break;
   }





   if (plen <= 0)
    return LIKE_TRUE;
# 159 "like_match.c"
   if (*p == '\\')
   {
    if (plen < 2)
     ereport(ERROR,
       (errcode(ERRCODE_INVALID_ESCAPE_SEQUENCE),
        errmsg("LIKE pattern must not end with escape character")));
    firstpat = (p[1]);
   }
   else
    firstpat = (*p);

   while (tlen > 0)
   {
    if ((*t) == firstpat)
    {
     int matched = MatchText(t, tlen, p, plen,
             locale, locale_is_c);

     if (matched != LIKE_FALSE)
      return matched;
    }

    NextChar(t, tlen);
   }





   return LIKE_ABORT;
  }
  else if (*p == '_')
  {

   NextChar(t, tlen);
   NextByte(p, plen);
   continue;
  }
  else if ((*p) != (*t))
  {

   return LIKE_FALSE;
  }
# 215 "like_match.c"
  NextByte(t, tlen);
  NextByte(p, plen);
 }

 if (tlen > 0)
  return LIKE_FALSE;





 while (plen > 0 && *p == '%')
  NextByte(p, plen);
 if (plen <= 0)
  return LIKE_TRUE;





 return LIKE_ABORT;
}

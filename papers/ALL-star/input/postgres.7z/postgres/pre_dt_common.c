# 1 "dt_common.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "dt_common.c"


# 1 "postgres_fe.h" 1
# 25 "postgres_fe.h"
# 1 "c.h" 1
# 53 "c.h"
# 1 "pg_config.h" 1
# 54 "c.h" 2
# 1 "pg_config_manual.h" 1
# 55 "c.h" 2


# 1 "pg_config_os.h" 1
# 58 "c.h" 2

# 1 "postgres_ext.h" 1
# 29 "postgres_ext.h"
typedef unsigned int Oid;
# 60 "c.h" 2







# 1 "/usr/include/stdio.h" 1 3 4
# 64 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/sys/cdefs.h" 1 3 4
# 417 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_symbol_aliasing.h" 1 3 4
# 418 "/usr/include/sys/cdefs.h" 2 3 4
# 494 "/usr/include/sys/cdefs.h" 3 4
# 1 "/usr/include/sys/_posix_availability.h" 1 3 4
# 495 "/usr/include/sys/cdefs.h" 2 3 4
# 65 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/Availability.h" 1 3 4
# 141 "/usr/include/Availability.h" 3 4
# 1 "/usr/include/AvailabilityInternal.h" 1 3 4
# 142 "/usr/include/Availability.h" 2 3 4
# 66 "/usr/include/stdio.h" 2 3 4

# 1 "/usr/include/_types.h" 1 3 4
# 27 "/usr/include/_types.h" 3 4
# 1 "/usr/include/sys/_types.h" 1 3 4
# 33 "/usr/include/sys/_types.h" 3 4
# 1 "/usr/include/machine/_types.h" 1 3 4
# 32 "/usr/include/machine/_types.h" 3 4
# 1 "/usr/include/i386/_types.h" 1 3 4
# 37 "/usr/include/i386/_types.h" 3 4
typedef signed char __int8_t;



typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;

typedef long __darwin_intptr_t;
typedef unsigned int __darwin_natural_t;
# 70 "/usr/include/i386/_types.h" 3 4
typedef int __darwin_ct_rune_t;





typedef union {
 char __mbstate8[128];
 long long _mbstateL;
} __mbstate_t;

typedef __mbstate_t __darwin_mbstate_t;


typedef long int __darwin_ptrdiff_t;





typedef long unsigned int __darwin_size_t;





typedef __builtin_va_list __darwin_va_list;





typedef int __darwin_wchar_t;




typedef __darwin_wchar_t __darwin_rune_t;


typedef int __darwin_wint_t;




typedef unsigned long __darwin_clock_t;
typedef __uint32_t __darwin_socklen_t;
typedef long __darwin_ssize_t;
typedef long __darwin_time_t;
# 33 "/usr/include/machine/_types.h" 2 3 4
# 34 "/usr/include/sys/_types.h" 2 3 4
# 58 "/usr/include/sys/_types.h" 3 4
struct __darwin_pthread_handler_rec
{
 void (*__routine)(void *);
 void *__arg;
 struct __darwin_pthread_handler_rec *__next;
};
struct _opaque_pthread_attr_t { long __sig; char __opaque[56]; };
struct _opaque_pthread_cond_t { long __sig; char __opaque[40]; };
struct _opaque_pthread_condattr_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_mutex_t { long __sig; char __opaque[56]; };
struct _opaque_pthread_mutexattr_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_once_t { long __sig; char __opaque[8]; };
struct _opaque_pthread_rwlock_t { long __sig; char __opaque[192]; };
struct _opaque_pthread_rwlockattr_t { long __sig; char __opaque[16]; };
struct _opaque_pthread_t { long __sig; struct __darwin_pthread_handler_rec *__cleanup_stack; char __opaque[1168]; };
# 94 "/usr/include/sys/_types.h" 3 4
typedef __int64_t __darwin_blkcnt_t;
typedef __int32_t __darwin_blksize_t;
typedef __int32_t __darwin_dev_t;
typedef unsigned int __darwin_fsblkcnt_t;
typedef unsigned int __darwin_fsfilcnt_t;
typedef __uint32_t __darwin_gid_t;
typedef __uint32_t __darwin_id_t;
typedef __uint64_t __darwin_ino64_t;

typedef __darwin_ino64_t __darwin_ino_t;



typedef __darwin_natural_t __darwin_mach_port_name_t;
typedef __darwin_mach_port_name_t __darwin_mach_port_t;
typedef __uint16_t __darwin_mode_t;
typedef __int64_t __darwin_off_t;
typedef __int32_t __darwin_pid_t;
typedef struct _opaque_pthread_attr_t
   __darwin_pthread_attr_t;
typedef struct _opaque_pthread_cond_t
   __darwin_pthread_cond_t;
typedef struct _opaque_pthread_condattr_t
   __darwin_pthread_condattr_t;
typedef unsigned long __darwin_pthread_key_t;
typedef struct _opaque_pthread_mutex_t
   __darwin_pthread_mutex_t;
typedef struct _opaque_pthread_mutexattr_t
   __darwin_pthread_mutexattr_t;
typedef struct _opaque_pthread_once_t
   __darwin_pthread_once_t;
typedef struct _opaque_pthread_rwlock_t
   __darwin_pthread_rwlock_t;
typedef struct _opaque_pthread_rwlockattr_t
   __darwin_pthread_rwlockattr_t;
typedef struct _opaque_pthread_t
   *__darwin_pthread_t;
typedef __uint32_t __darwin_sigset_t;
typedef __int32_t __darwin_suseconds_t;
typedef __uint32_t __darwin_uid_t;
typedef __uint32_t __darwin_useconds_t;
typedef unsigned char __darwin_uuid_t[16];
typedef char __darwin_uuid_string_t[37];
# 28 "/usr/include/_types.h" 2 3 4
# 39 "/usr/include/_types.h" 3 4
typedef int __darwin_nl_item;
typedef int __darwin_wctrans_t;

typedef __uint32_t __darwin_wctype_t;
# 68 "/usr/include/stdio.h" 2 3 4





typedef __darwin_va_list va_list;




typedef __darwin_size_t size_t;






typedef __darwin_off_t fpos_t;
# 96 "/usr/include/stdio.h" 3 4
struct __sbuf {
 unsigned char *_base;
 int _size;
};


struct __sFILEX;
# 130 "/usr/include/stdio.h" 3 4
typedef struct __sFILE {
 unsigned char *_p;
 int _r;
 int _w;
 short _flags;
 short _file;
 struct __sbuf _bf;
 int _lbfsize;


 void *_cookie;
 int (*_close)(void *);
 int (*_read) (void *, char *, int);
 fpos_t (*_seek) (void *, fpos_t, int);
 int (*_write)(void *, const char *, int);


 struct __sbuf _ub;
 struct __sFILEX *_extra;
 int _ur;


 unsigned char _ubuf[3];
 unsigned char _nbuf[1];


 struct __sbuf _lb;


 int _blksize;
 fpos_t _offset;
} FILE;


extern FILE *__stdinp;
extern FILE *__stdoutp;
extern FILE *__stderrp;

# 238 "/usr/include/stdio.h" 3 4

void clearerr(FILE *);
int fclose(FILE *);
int feof(FILE *);
int ferror(FILE *);
int fflush(FILE *);
int fgetc(FILE *);
int fgetpos(FILE * , fpos_t *);
char *fgets(char * , int, FILE *);



FILE *fopen(const char * , const char * ) __asm("_" "fopen" );

int fprintf(FILE * , const char * , ...) __attribute__((__format__ (__printf__, 2, 3)));
int fputc(int, FILE *);
int fputs(const char * , FILE * ) __asm("_" "fputs" );
size_t fread(void * , size_t, size_t, FILE * );
FILE *freopen(const char * , const char * ,
                 FILE * ) __asm("_" "freopen" );
int fscanf(FILE * , const char * , ...) __attribute__((__format__ (__scanf__, 2, 3)));
int fseek(FILE *, long, int);
int fsetpos(FILE *, const fpos_t *);
long ftell(FILE *);
size_t fwrite(const void * , size_t, size_t, FILE * ) __asm("_" "fwrite" );
int getc(FILE *);
int getchar(void);
char *gets(char *);
void perror(const char *);
int printf(const char * , ...) __attribute__((__format__ (__printf__, 1, 2)));
int putc(int, FILE *);
int putchar(int);
int puts(const char *);
int remove(const char *);
int rename (const char *, const char *);
void rewind(FILE *);
int scanf(const char * , ...) __attribute__((__format__ (__scanf__, 1, 2)));
void setbuf(FILE * , char * );
int setvbuf(FILE * , char * , int, size_t);
int sprintf(char * , const char * , ...) __attribute__((__format__ (__printf__, 2, 3)));
int sscanf(const char * , const char * , ...) __attribute__((__format__ (__scanf__, 2, 3)));
FILE *tmpfile(void);
char *tmpnam(char *);
int ungetc(int, FILE *);
int vfprintf(FILE * , const char * , va_list) __attribute__((__format__ (__printf__, 2, 0)));
int vprintf(const char * , va_list) __attribute__((__format__ (__printf__, 1, 0)));
int vsprintf(char * , const char * , va_list) __attribute__((__format__ (__printf__, 2, 0)));

# 296 "/usr/include/stdio.h" 3 4




char *ctermid(char *);





FILE *fdopen(int, const char *) __asm("_" "fdopen" );

int fileno(FILE *);

# 318 "/usr/include/stdio.h" 3 4

int pclose(FILE *);



FILE *popen(const char *, const char *) __asm("_" "popen" );


# 340 "/usr/include/stdio.h" 3 4

int __srget(FILE *);
int __svfscanf(FILE *, const char *, va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int __swbuf(int, FILE *);








static __inline int __sputc(int _c, FILE *_p) {
 if (--_p->_w >= 0 || (_p->_w >= _p->_lbfsize && (char)_c != '\n'))
  return (*_p->_p++ = _c);
 else
  return (__swbuf(_c, _p));
}
# 377 "/usr/include/stdio.h" 3 4

void flockfile(FILE *);
int ftrylockfile(FILE *);
void funlockfile(FILE *);
int getc_unlocked(FILE *);
int getchar_unlocked(void);
int putc_unlocked(int, FILE *);
int putchar_unlocked(int);



int getw(FILE *);
int putw(int, FILE *);


char *tempnam(const char *, const char *) __asm("_" "tempnam" );

# 414 "/usr/include/stdio.h" 3 4
typedef __darwin_off_t off_t;



int fseeko(FILE *, off_t, int);
off_t ftello(FILE *);





int snprintf(char * , size_t, const char * , ...) __attribute__((__format__ (__printf__, 3, 4)));
int vfscanf(FILE * , const char * , va_list) __attribute__((__format__ (__scanf__, 2, 0)));
int vscanf(const char * , va_list) __attribute__((__format__ (__scanf__, 1, 0)));
int vsnprintf(char * , size_t, const char * , va_list) __attribute__((__format__ (__printf__, 3, 0)));
int vsscanf(const char * , const char * , va_list) __attribute__((__format__ (__scanf__, 2, 0)));

# 442 "/usr/include/stdio.h" 3 4
typedef __darwin_ssize_t ssize_t;



int dprintf(int, const char * , ...) __attribute__((__format__ (__printf__, 2, 3))) __attribute__((visibility("default")));
int vdprintf(int, const char * , va_list) __attribute__((__format__ (__printf__, 2, 0))) __attribute__((visibility("default")));
ssize_t getdelim(char ** , size_t * , int, FILE * ) __attribute__((visibility("default")));
ssize_t getline(char ** , size_t * , FILE * ) __attribute__((visibility("default")));









extern const int sys_nerr;
extern const char *const sys_errlist[];

int asprintf(char **, const char *, ...) __attribute__((__format__ (__printf__, 2, 3)));
char *ctermid_r(char *);
char *fgetln(FILE *, size_t *);
const char *fmtcheck(const char *, const char *);
int fpurge(FILE *);
void setbuffer(FILE *, char *, int);
int setlinebuf(FILE *);
int vasprintf(char **, const char *, va_list) __attribute__((__format__ (__printf__, 2, 0)));
FILE *zopen(const char *, const char *, int);





FILE *funopen(const void *,
                 int (*)(void *, char *, int),
                 int (*)(void *, const char *, int),
                 fpos_t (*)(void *, fpos_t, int),
                 int (*)(void *));

# 499 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/secure/_stdio.h" 1 3 4
# 31 "/usr/include/secure/_stdio.h" 3 4
# 1 "/usr/include/secure/_common.h" 1 3 4
# 32 "/usr/include/secure/_stdio.h" 2 3 4
# 45 "/usr/include/secure/_stdio.h" 3 4
extern int __sprintf_chk (char * , int, size_t,
     const char * , ...)
  ;




extern int __snprintf_chk (char * , size_t, int, size_t,
      const char * , ...)
  ;





extern int __vsprintf_chk (char * , int, size_t,
      const char * , va_list)
  ;




extern int __vsnprintf_chk (char * , size_t, int, size_t,
       const char * , va_list)
  ;
# 500 "/usr/include/stdio.h" 2 3 4
# 68 "c.h" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 65 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/sys/wait.h" 1 3 4
# 79 "/usr/include/sys/wait.h" 3 4
typedef enum {
 P_ALL,
 P_PID,
 P_PGID
} idtype_t;






typedef __darwin_pid_t pid_t;




typedef __darwin_id_t id_t;
# 116 "/usr/include/sys/wait.h" 3 4
# 1 "/usr/include/sys/signal.h" 1 3 4
# 73 "/usr/include/sys/signal.h" 3 4
# 1 "/usr/include/sys/appleapiopts.h" 1 3 4
# 74 "/usr/include/sys/signal.h" 2 3 4







# 1 "/usr/include/machine/signal.h" 1 3 4
# 32 "/usr/include/machine/signal.h" 3 4
# 1 "/usr/include/i386/signal.h" 1 3 4
# 39 "/usr/include/i386/signal.h" 3 4
typedef int sig_atomic_t;
# 55 "/usr/include/i386/signal.h" 3 4
# 1 "/usr/include/i386/_structs.h" 1 3 4
# 56 "/usr/include/i386/signal.h" 2 3 4
# 33 "/usr/include/machine/signal.h" 2 3 4
# 82 "/usr/include/sys/signal.h" 2 3 4
# 148 "/usr/include/sys/signal.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 57 "/usr/include/sys/_structs.h" 3 4
# 1 "/usr/include/machine/_structs.h" 1 3 4
# 29 "/usr/include/machine/_structs.h" 3 4
# 1 "/usr/include/i386/_structs.h" 1 3 4
# 38 "/usr/include/i386/_structs.h" 3 4
# 1 "/usr/include/mach/i386/_structs.h" 1 3 4
# 43 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_thread_state
{
    unsigned int __eax;
    unsigned int __ebx;
    unsigned int __ecx;
    unsigned int __edx;
    unsigned int __edi;
    unsigned int __esi;
    unsigned int __ebp;
    unsigned int __esp;
    unsigned int __ss;
    unsigned int __eflags;
    unsigned int __eip;
    unsigned int __cs;
    unsigned int __ds;
    unsigned int __es;
    unsigned int __fs;
    unsigned int __gs;
};
# 89 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_fp_control
{
    unsigned short __invalid :1,
        __denorm :1,
    __zdiv :1,
    __ovrfl :1,
    __undfl :1,
    __precis :1,
      :2,
    __pc :2,





    __rc :2,






             :1,
      :3;
};
typedef struct __darwin_fp_control __darwin_fp_control_t;
# 147 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_fp_status
{
    unsigned short __invalid :1,
        __denorm :1,
    __zdiv :1,
    __ovrfl :1,
    __undfl :1,
    __precis :1,
    __stkflt :1,
    __errsumm :1,
    __c0 :1,
    __c1 :1,
    __c2 :1,
    __tos :3,
    __c3 :1,
    __busy :1;
};
typedef struct __darwin_fp_status __darwin_fp_status_t;
# 191 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_mmst_reg
{
 char __mmst_reg[10];
 char __mmst_rsrv[6];
};
# 210 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_xmm_reg
{
 char __xmm_reg[16];
};
# 232 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_float_state
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;
 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;
 __uint16_t __fpu_rsrv2;
 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;
 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 char __fpu_rsrv4[14*16];
 int __fpu_reserved1;
};


struct __darwin_i386_avx_state
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;
 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;
 __uint16_t __fpu_rsrv2;
 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;
 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 char __fpu_rsrv4[14*16];
 int __fpu_reserved1;
 char __avx_reserved1[64];
 struct __darwin_xmm_reg __fpu_ymmh0;
 struct __darwin_xmm_reg __fpu_ymmh1;
 struct __darwin_xmm_reg __fpu_ymmh2;
 struct __darwin_xmm_reg __fpu_ymmh3;
 struct __darwin_xmm_reg __fpu_ymmh4;
 struct __darwin_xmm_reg __fpu_ymmh5;
 struct __darwin_xmm_reg __fpu_ymmh6;
 struct __darwin_xmm_reg __fpu_ymmh7;
};
# 402 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_i386_exception_state
{
 __uint16_t __trapno;
 __uint16_t __cpu;
 __uint32_t __err;
 __uint32_t __faultvaddr;
};
# 422 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_debug_state32
{
 unsigned int __dr0;
 unsigned int __dr1;
 unsigned int __dr2;
 unsigned int __dr3;
 unsigned int __dr4;
 unsigned int __dr5;
 unsigned int __dr6;
 unsigned int __dr7;
};
# 454 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_thread_state64
{
 __uint64_t __rax;
 __uint64_t __rbx;
 __uint64_t __rcx;
 __uint64_t __rdx;
 __uint64_t __rdi;
 __uint64_t __rsi;
 __uint64_t __rbp;
 __uint64_t __rsp;
 __uint64_t __r8;
 __uint64_t __r9;
 __uint64_t __r10;
 __uint64_t __r11;
 __uint64_t __r12;
 __uint64_t __r13;
 __uint64_t __r14;
 __uint64_t __r15;
 __uint64_t __rip;
 __uint64_t __rflags;
 __uint64_t __cs;
 __uint64_t __fs;
 __uint64_t __gs;
};
# 509 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_float_state64
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;


 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;

 __uint16_t __fpu_rsrv2;


 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;

 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 struct __darwin_xmm_reg __fpu_xmm8;
 struct __darwin_xmm_reg __fpu_xmm9;
 struct __darwin_xmm_reg __fpu_xmm10;
 struct __darwin_xmm_reg __fpu_xmm11;
 struct __darwin_xmm_reg __fpu_xmm12;
 struct __darwin_xmm_reg __fpu_xmm13;
 struct __darwin_xmm_reg __fpu_xmm14;
 struct __darwin_xmm_reg __fpu_xmm15;
 char __fpu_rsrv4[6*16];
 int __fpu_reserved1;
};


struct __darwin_x86_avx_state64
{
 int __fpu_reserved[2];
 struct __darwin_fp_control __fpu_fcw;
 struct __darwin_fp_status __fpu_fsw;
 __uint8_t __fpu_ftw;
 __uint8_t __fpu_rsrv1;
 __uint16_t __fpu_fop;


 __uint32_t __fpu_ip;
 __uint16_t __fpu_cs;

 __uint16_t __fpu_rsrv2;


 __uint32_t __fpu_dp;
 __uint16_t __fpu_ds;

 __uint16_t __fpu_rsrv3;
 __uint32_t __fpu_mxcsr;
 __uint32_t __fpu_mxcsrmask;
 struct __darwin_mmst_reg __fpu_stmm0;
 struct __darwin_mmst_reg __fpu_stmm1;
 struct __darwin_mmst_reg __fpu_stmm2;
 struct __darwin_mmst_reg __fpu_stmm3;
 struct __darwin_mmst_reg __fpu_stmm4;
 struct __darwin_mmst_reg __fpu_stmm5;
 struct __darwin_mmst_reg __fpu_stmm6;
 struct __darwin_mmst_reg __fpu_stmm7;
 struct __darwin_xmm_reg __fpu_xmm0;
 struct __darwin_xmm_reg __fpu_xmm1;
 struct __darwin_xmm_reg __fpu_xmm2;
 struct __darwin_xmm_reg __fpu_xmm3;
 struct __darwin_xmm_reg __fpu_xmm4;
 struct __darwin_xmm_reg __fpu_xmm5;
 struct __darwin_xmm_reg __fpu_xmm6;
 struct __darwin_xmm_reg __fpu_xmm7;
 struct __darwin_xmm_reg __fpu_xmm8;
 struct __darwin_xmm_reg __fpu_xmm9;
 struct __darwin_xmm_reg __fpu_xmm10;
 struct __darwin_xmm_reg __fpu_xmm11;
 struct __darwin_xmm_reg __fpu_xmm12;
 struct __darwin_xmm_reg __fpu_xmm13;
 struct __darwin_xmm_reg __fpu_xmm14;
 struct __darwin_xmm_reg __fpu_xmm15;
 char __fpu_rsrv4[6*16];
 int __fpu_reserved1;
 char __avx_reserved1[64];
 struct __darwin_xmm_reg __fpu_ymmh0;
 struct __darwin_xmm_reg __fpu_ymmh1;
 struct __darwin_xmm_reg __fpu_ymmh2;
 struct __darwin_xmm_reg __fpu_ymmh3;
 struct __darwin_xmm_reg __fpu_ymmh4;
 struct __darwin_xmm_reg __fpu_ymmh5;
 struct __darwin_xmm_reg __fpu_ymmh6;
 struct __darwin_xmm_reg __fpu_ymmh7;
 struct __darwin_xmm_reg __fpu_ymmh8;
 struct __darwin_xmm_reg __fpu_ymmh9;
 struct __darwin_xmm_reg __fpu_ymmh10;
 struct __darwin_xmm_reg __fpu_ymmh11;
 struct __darwin_xmm_reg __fpu_ymmh12;
 struct __darwin_xmm_reg __fpu_ymmh13;
 struct __darwin_xmm_reg __fpu_ymmh14;
 struct __darwin_xmm_reg __fpu_ymmh15;
};
# 751 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_exception_state64
{
    __uint16_t __trapno;
    __uint16_t __cpu;
    __uint32_t __err;
    __uint64_t __faultvaddr;
};
# 771 "/usr/include/mach/i386/_structs.h" 3 4
struct __darwin_x86_debug_state64
{
 __uint64_t __dr0;
 __uint64_t __dr1;
 __uint64_t __dr2;
 __uint64_t __dr3;
 __uint64_t __dr4;
 __uint64_t __dr5;
 __uint64_t __dr6;
 __uint64_t __dr7;
};
# 39 "/usr/include/i386/_structs.h" 2 3 4
# 48 "/usr/include/i386/_structs.h" 3 4
struct __darwin_mcontext32
{
 struct __darwin_i386_exception_state __es;
 struct __darwin_i386_thread_state __ss;
 struct __darwin_i386_float_state __fs;
};


struct __darwin_mcontext_avx32
{
 struct __darwin_i386_exception_state __es;
 struct __darwin_i386_thread_state __ss;
 struct __darwin_i386_avx_state __fs;
};
# 86 "/usr/include/i386/_structs.h" 3 4
struct __darwin_mcontext64
{
 struct __darwin_x86_exception_state64 __es;
 struct __darwin_x86_thread_state64 __ss;
 struct __darwin_x86_float_state64 __fs;
};


struct __darwin_mcontext_avx64
{
 struct __darwin_x86_exception_state64 __es;
 struct __darwin_x86_thread_state64 __ss;
 struct __darwin_x86_avx_state64 __fs;
};
# 127 "/usr/include/i386/_structs.h" 3 4
typedef struct __darwin_mcontext64 *mcontext_t;
# 30 "/usr/include/machine/_structs.h" 2 3 4
# 58 "/usr/include/sys/_structs.h" 2 3 4
# 75 "/usr/include/sys/_structs.h" 3 4
struct __darwin_sigaltstack
{
 void *ss_sp;
 __darwin_size_t ss_size;
 int ss_flags;
};
# 128 "/usr/include/sys/_structs.h" 3 4
struct __darwin_ucontext
{
 int uc_onstack;
 __darwin_sigset_t uc_sigmask;
 struct __darwin_sigaltstack uc_stack;
 struct __darwin_ucontext *uc_link;
 __darwin_size_t uc_mcsize;
 struct __darwin_mcontext64 *uc_mcontext;



};
# 218 "/usr/include/sys/_structs.h" 3 4
typedef struct __darwin_sigaltstack stack_t;
# 227 "/usr/include/sys/_structs.h" 3 4
typedef struct __darwin_ucontext ucontext_t;
# 149 "/usr/include/sys/signal.h" 2 3 4
# 157 "/usr/include/sys/signal.h" 3 4
typedef __darwin_pthread_attr_t pthread_attr_t;




typedef __darwin_sigset_t sigset_t;
# 172 "/usr/include/sys/signal.h" 3 4
typedef __darwin_uid_t uid_t;


union sigval {

 int sival_int;
 void *sival_ptr;
};





struct sigevent {
 int sigev_notify;
 int sigev_signo;
 union sigval sigev_value;
 void (*sigev_notify_function)(union sigval);
 pthread_attr_t *sigev_notify_attributes;
};


typedef struct __siginfo {
 int si_signo;
 int si_errno;
 int si_code;
 pid_t si_pid;
 uid_t si_uid;
 int si_status;
 void *si_addr;
 union sigval si_value;
 long si_band;
 unsigned long __pad[7];
} siginfo_t;
# 286 "/usr/include/sys/signal.h" 3 4
union __sigaction_u {
 void (*__sa_handler)(int);
 void (*__sa_sigaction)(int, struct __siginfo *,
         void *);
};


struct __sigaction {
 union __sigaction_u __sigaction_u;
 void (*sa_tramp)(void *, int, int, siginfo_t *, void *);
 sigset_t sa_mask;
 int sa_flags;
};




struct sigaction {
 union __sigaction_u __sigaction_u;
 sigset_t sa_mask;
 int sa_flags;
};
# 348 "/usr/include/sys/signal.h" 3 4
typedef void (*sig_t)(int);
# 365 "/usr/include/sys/signal.h" 3 4
struct sigvec {
 void (*sv_handler)(int);
 int sv_mask;
 int sv_flags;
};
# 384 "/usr/include/sys/signal.h" 3 4
struct sigstack {
 char *ss_sp;
 int ss_onstack;
};
# 406 "/usr/include/sys/signal.h" 3 4

void (*signal(int, void (*)(int)))(int);

# 117 "/usr/include/sys/wait.h" 2 3 4
# 1 "/usr/include/sys/resource.h" 1 3 4
# 77 "/usr/include/sys/resource.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 100 "/usr/include/sys/_structs.h" 3 4
struct timeval
{
 __darwin_time_t tv_sec;
 __darwin_suseconds_t tv_usec;
};
# 78 "/usr/include/sys/resource.h" 2 3 4
# 89 "/usr/include/sys/resource.h" 3 4
typedef __uint64_t rlim_t;
# 151 "/usr/include/sys/resource.h" 3 4
struct rusage {
 struct timeval ru_utime;
 struct timeval ru_stime;
# 162 "/usr/include/sys/resource.h" 3 4
 long ru_maxrss;

 long ru_ixrss;
 long ru_idrss;
 long ru_isrss;
 long ru_minflt;
 long ru_majflt;
 long ru_nswap;
 long ru_inblock;
 long ru_oublock;
 long ru_msgsnd;
 long ru_msgrcv;
 long ru_nsignals;
 long ru_nvcsw;
 long ru_nivcsw;


};
# 222 "/usr/include/sys/resource.h" 3 4
struct rlimit {
 rlim_t rlim_cur;
 rlim_t rlim_max;
};
# 244 "/usr/include/sys/resource.h" 3 4

int getpriority(int, id_t);

int getiopolicy_np(int, int) __attribute__((visibility("default")));

int getrlimit(int, struct rlimit *) __asm("_" "getrlimit" );
int getrusage(int, struct rusage *);
int setpriority(int, id_t, int);

int setiopolicy_np(int, int, int) __attribute__((visibility("default")));

int setrlimit(int, const struct rlimit *) __asm("_" "setrlimit" );

# 118 "/usr/include/sys/wait.h" 2 3 4
# 193 "/usr/include/sys/wait.h" 3 4
# 1 "/usr/include/machine/endian.h" 1 3 4
# 35 "/usr/include/machine/endian.h" 3 4
# 1 "/usr/include/i386/endian.h" 1 3 4
# 99 "/usr/include/i386/endian.h" 3 4
# 1 "/usr/include/sys/_endian.h" 1 3 4
# 124 "/usr/include/sys/_endian.h" 3 4
# 1 "/usr/include/libkern/_OSByteOrder.h" 1 3 4
# 66 "/usr/include/libkern/_OSByteOrder.h" 3 4
# 1 "/usr/include/libkern/i386/_OSByteOrder.h" 1 3 4
# 44 "/usr/include/libkern/i386/_OSByteOrder.h" 3 4
static __inline__
__uint16_t
_OSSwapInt16(
    __uint16_t _data
)
{
    return ((_data << 8) | (_data >> 8));
}

static __inline__
__uint32_t
_OSSwapInt32(
    __uint32_t _data
)
{

    return __builtin_bswap32(_data);




}


static __inline__
__uint64_t
_OSSwapInt64(
    __uint64_t _data
)
{
    return __builtin_bswap64(_data);
}
# 67 "/usr/include/libkern/_OSByteOrder.h" 2 3 4
# 125 "/usr/include/sys/_endian.h" 2 3 4
# 100 "/usr/include/i386/endian.h" 2 3 4
# 36 "/usr/include/machine/endian.h" 2 3 4
# 194 "/usr/include/sys/wait.h" 2 3 4







union wait {
 int w_status;



 struct {

  unsigned int w_Termsig:7,
    w_Coredump:1,
    w_Retcode:8,
    w_Filler:16;







 } w_T;





 struct {

  unsigned int w_Stopval:8,
    w_Stopsig:8,
    w_Filler:16;






 } w_S;
};
# 254 "/usr/include/sys/wait.h" 3 4

pid_t wait(int *) __asm("_" "wait" );
pid_t waitpid(pid_t, int *, int) __asm("_" "waitpid" );

int waitid(idtype_t, id_t, siginfo_t *, int) __asm("_" "waitid" );


pid_t wait3(int *, int, struct rusage *);
pid_t wait4(pid_t, int *, int, struct rusage *);


# 66 "/usr/include/stdlib.h" 2 3 4

# 1 "/usr/include/alloca.h" 1 3 4
# 35 "/usr/include/alloca.h" 3 4

void *alloca(size_t);

# 68 "/usr/include/stdlib.h" 2 3 4
# 81 "/usr/include/stdlib.h" 3 4
typedef __darwin_ct_rune_t ct_rune_t;




typedef __darwin_rune_t rune_t;






typedef __darwin_wchar_t wchar_t;



typedef struct {
 int quot;
 int rem;
} div_t;

typedef struct {
 long quot;
 long rem;
} ldiv_t;


typedef struct {
 long long quot;
 long long rem;
} lldiv_t;
# 134 "/usr/include/stdlib.h" 3 4
extern int __mb_cur_max;
# 144 "/usr/include/stdlib.h" 3 4

void abort(void) __attribute__((__noreturn__));
int abs(int) __attribute__((__const__));
int atexit(void (*)(void));
double atof(const char *);
int atoi(const char *);
long atol(const char *);

long long
  atoll(const char *);

void *bsearch(const void *, const void *, size_t,
     size_t, int (*)(const void *, const void *));
void *calloc(size_t, size_t);
div_t div(int, int) __attribute__((__const__));
void exit(int) __attribute__((__noreturn__));
void free(void *);
char *getenv(const char *);
long labs(long) __attribute__((__const__));
ldiv_t ldiv(long, long) __attribute__((__const__));

long long
  llabs(long long);
lldiv_t lldiv(long long, long long);

void *malloc(size_t);
int mblen(const char *, size_t);
size_t mbstowcs(wchar_t * , const char * , size_t);
int mbtowc(wchar_t * , const char * , size_t);
int posix_memalign(void **, size_t, size_t) __attribute__((visibility("default")));
void qsort(void *, size_t, size_t,
     int (*)(const void *, const void *));
int rand(void);
void *realloc(void *, size_t);
void srand(unsigned);
double strtod(const char *, char **) __asm("_" "strtod" );
float strtof(const char *, char **) __asm("_" "strtof" );
long strtol(const char *, char **, int);
long double
  strtold(const char *, char **) ;

long long
  strtoll(const char *, char **, int);

unsigned long
  strtoul(const char *, char **, int);

unsigned long long
  strtoull(const char *, char **, int);

int system(const char *) __asm("_" "system" );
size_t wcstombs(char * , const wchar_t * , size_t);
int wctomb(char *, wchar_t);


void _Exit(int) __attribute__((__noreturn__));
long a64l(const char *);
double drand48(void);
char *ecvt(double, int, int *, int *);
double erand48(unsigned short[3]);
char *fcvt(double, int, int *, int *);
char *gcvt(double, int, char *);
int getsubopt(char **, char * const *, char **);
int grantpt(int);

char *initstate(unsigned, char *, size_t);



long jrand48(unsigned short[3]);
char *l64a(long);
void lcong48(unsigned short[7]);
long lrand48(void);
char *mktemp(char *);
int mkstemp(char *);
long mrand48(void);
long nrand48(unsigned short[3]);
int posix_openpt(int);
char *ptsname(int);
int putenv(char *) __asm("_" "putenv" );
long random(void);
int rand_r(unsigned *);

char *realpath(const char * , char * ) __asm("_" "realpath" "$DARWIN_EXTSN");



unsigned short
 *seed48(unsigned short[3]);
int setenv(const char *, const char *, int) __asm("_" "setenv" );

void setkey(const char *) __asm("_" "setkey" );



char *setstate(const char *);
void srand48(long);

void srandom(unsigned);



int unlockpt(int);

int unsetenv(const char *) __asm("_" "unsetenv" );






# 1 "/usr/include/machine/types.h" 1 3 4
# 35 "/usr/include/machine/types.h" 3 4
# 1 "/usr/include/i386/types.h" 1 3 4
# 70 "/usr/include/i386/types.h" 3 4
# 1 "/usr/include/i386/_types.h" 1 3 4
# 71 "/usr/include/i386/types.h" 2 3 4







typedef signed char int8_t;

typedef unsigned char u_int8_t;


typedef short int16_t;

typedef unsigned short u_int16_t;


typedef int int32_t;

typedef unsigned int u_int32_t;


typedef long long int64_t;

typedef unsigned long long u_int64_t;


typedef int64_t register_t;






typedef __darwin_intptr_t intptr_t;



typedef unsigned long uintptr_t;




typedef u_int64_t user_addr_t;
typedef u_int64_t user_size_t;
typedef int64_t user_ssize_t;
typedef int64_t user_long_t;
typedef u_int64_t user_ulong_t;
typedef int64_t user_time_t;
typedef int64_t user_off_t;







typedef u_int64_t syscall_arg_t;
# 36 "/usr/include/machine/types.h" 2 3 4
# 256 "/usr/include/stdlib.h" 2 3 4


typedef __darwin_dev_t dev_t;




typedef __darwin_mode_t mode_t;



u_int32_t
  arc4random(void);
void arc4random_addrandom(unsigned char * , int );
void arc4random_buf(void * , size_t ) __attribute__((visibility("default")));
void arc4random_stir(void);
u_int32_t
  arc4random_uniform(u_int32_t ) __attribute__((visibility("default")));

int atexit_b(void (^)(void)) __attribute__((visibility("default")));
void *bsearch_b(const void *, const void *, size_t,
     size_t, int (^)(const void *, const void *)) __attribute__((visibility("default")));



char *cgetcap(char *, const char *, int);
int cgetclose(void);
int cgetent(char **, char **, const char *);
int cgetfirst(char **, char **);
int cgetmatch(const char *, const char *);
int cgetnext(char **, char **);
int cgetnum(char *, const char *, long *);
int cgetset(const char *);
int cgetstr(char *, const char *, char **);
int cgetustr(char *, const char *, char **);

int daemon(int, int) __asm("_" "daemon" "$1050") __attribute__((deprecated,visibility("default")));
char *devname(dev_t, mode_t);
char *devname_r(dev_t, mode_t, char *buf, int len);
char *getbsize(int *, long *);
int getloadavg(double [], int);
const char
 *getprogname(void);

int heapsort(void *, size_t, size_t,
     int (*)(const void *, const void *));

int heapsort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

int mergesort(void *, size_t, size_t,
     int (*)(const void *, const void *));

int mergesort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void psort(void *, size_t, size_t,
     int (*)(const void *, const void *)) __attribute__((visibility("default")));

void psort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void psort_r(void *, size_t, size_t, void *,
     int (*)(void *, const void *, const void *)) __attribute__((visibility("default")));

void qsort_b(void *, size_t, size_t,
     int (^)(const void *, const void *)) __attribute__((visibility("default")));

void qsort_r(void *, size_t, size_t, void *,
     int (*)(void *, const void *, const void *));
int radixsort(const unsigned char **, int, const unsigned char *,
     unsigned);
void setprogname(const char *);
int sradixsort(const unsigned char **, int, const unsigned char *,
     unsigned);
void sranddev(void);
void srandomdev(void);
void *reallocf(void *, size_t);

long long
  strtoq(const char *, char **, int);
unsigned long long
  strtouq(const char *, char **, int);

extern char *suboptarg;
void *valloc(size_t);







# 69 "c.h" 2
# 1 "/usr/include/string.h" 1 3 4
# 79 "/usr/include/string.h" 3 4

void *memchr(const void *, int, size_t);
int memcmp(const void *, const void *, size_t);
void *memcpy(void *, const void *, size_t);
void *memmove(void *, const void *, size_t);
void *memset(void *, int, size_t);
char *strcat(char *, const char *);
char *strchr(const char *, int);
int strcmp(const char *, const char *);
int strcoll(const char *, const char *);
char *strcpy(char *, const char *);
size_t strcspn(const char *, const char *);
char *strerror(int) __asm("_" "strerror" );
size_t strlen(const char *);
char *strncat(char *, const char *, size_t);
int strncmp(const char *, const char *, size_t);
char *strncpy(char *, const char *, size_t);
char *strpbrk(const char *, const char *);
char *strrchr(const char *, int);
size_t strspn(const char *, const char *);
char *strstr(const char *, const char *);
char *strtok(char *, const char *);
size_t strxfrm(char *, const char *, size_t);

# 113 "/usr/include/string.h" 3 4

char *strtok_r(char *, const char *, char **);

# 125 "/usr/include/string.h" 3 4

int strerror_r(int, char *, size_t);
char *strdup(const char *);
void *memccpy(void *, const void *, int, size_t);

# 139 "/usr/include/string.h" 3 4

char *stpcpy(char *, const char *);
char *stpncpy(char *, const char *, size_t) __attribute__((visibility("default")));
char *strndup(const char *, size_t) __attribute__((visibility("default")));
size_t strnlen(const char *, size_t) __attribute__((visibility("default")));
char *strsignal(int sig);

# 158 "/usr/include/string.h" 3 4

void *memmem(const void *, size_t, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern4(void *, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern8(void *, const void *, size_t) __attribute__((visibility("default")));
void memset_pattern16(void *, const void *, size_t) __attribute__((visibility("default")));

char *strcasestr(const char *, const char *);
char *strnstr(const char *, const char *, size_t);
size_t strlcat(char *, const char *, size_t);
size_t strlcpy(char *, const char *, size_t);
void strmode(int, char *);
char *strsep(char **, const char *);


void swab(const void * , void * , ssize_t);







# 1 "/usr/include/strings.h" 1 3 4
# 71 "/usr/include/strings.h" 3 4



int bcmp(const void *, const void *, size_t) ;
void bcopy(const void *, void *, size_t) ;
void bzero(void *, size_t) ;
char *index(const char *, int) ;
char *rindex(const char *, int) ;


int ffs(int);
int strcasecmp(const char *, const char *);
int strncasecmp(const char *, const char *, size_t);





int ffsl(long) __attribute__((visibility("default")));
int fls(int) __attribute__((visibility("default")));
int flsl(long) __attribute__((visibility("default")));


# 1 "/usr/include/string.h" 1 3 4
# 95 "/usr/include/strings.h" 2 3 4
# 181 "/usr/include/string.h" 2 3 4
# 190 "/usr/include/string.h" 3 4
# 1 "/usr/include/secure/_string.h" 1 3 4
# 58 "/usr/include/secure/_string.h" 3 4
static __inline void *
__inline_memcpy_chk (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memcpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 0));
}






static __inline void *
__inline_memmove_chk (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memmove_chk (__dest, __src, __len, __builtin_object_size (__dest, 0));
}






static __inline void *
__inline_memset_chk (void *__dest, int __val, size_t __len)
{
  return __builtin___memset_chk (__dest, __val, __len, __builtin_object_size (__dest, 0));
}






static __inline char *
__inline_strcpy_chk (char * __dest, const char * __src)
{
  return __builtin___strcpy_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_stpcpy_chk (char *__dest, const char *__src)
{
  return __builtin___stpcpy_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}






static __inline char *
__inline_stpncpy_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___stpncpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_strncpy_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___strncpy_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}






static __inline char *
__inline_strcat_chk (char * __dest, const char * __src)
{
  return __builtin___strcat_chk (__dest, __src, __builtin_object_size (__dest, 2 > 1));
}







static __inline char *
__inline_strncat_chk (char * __dest, const char * __src,
        size_t __len)
{
  return __builtin___strncat_chk (__dest, __src, __len, __builtin_object_size (__dest, 2 > 1));
}
# 191 "/usr/include/string.h" 2 3 4
# 70 "c.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stddef.h" 1 3 4
# 152 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 71 "c.h" 2
# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stdarg.h" 1 3 4
# 43 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 72 "c.h" 2

# 1 "./strings.h" 1
char *s1,
     *s2,
     *s3,
     *s4,
     *s5,
     *s6;
# 74 "c.h" 2


# 1 "/usr/include/stdint.h" 1 3 4
# 40 "/usr/include/stdint.h" 3 4
typedef unsigned char uint8_t;




typedef unsigned short uint16_t;




typedef unsigned int uint32_t;




typedef unsigned long long uint64_t;



typedef int8_t int_least8_t;
typedef int16_t int_least16_t;
typedef int32_t int_least32_t;
typedef int64_t int_least64_t;
typedef uint8_t uint_least8_t;
typedef uint16_t uint_least16_t;
typedef uint32_t uint_least32_t;
typedef uint64_t uint_least64_t;



typedef int8_t int_fast8_t;
typedef int16_t int_fast16_t;
typedef int32_t int_fast32_t;
typedef int64_t int_fast64_t;
typedef uint8_t uint_fast8_t;
typedef uint16_t uint_fast16_t;
typedef uint32_t uint_fast32_t;
typedef uint64_t uint_fast64_t;
# 97 "/usr/include/stdint.h" 3 4
typedef long int intmax_t;
# 106 "/usr/include/stdint.h" 3 4
typedef long unsigned int uintmax_t;
# 77 "c.h" 2

# 1 "/usr/include/sys/types.h" 1 3 4
# 84 "/usr/include/sys/types.h" 3 4
typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned int u_int;

typedef unsigned long u_long;


typedef unsigned short ushort;
typedef unsigned int uint;


typedef u_int64_t u_quad_t;
typedef int64_t quad_t;
typedef quad_t * qaddr_t;

typedef char * caddr_t;
typedef int32_t daddr_t;






typedef u_int32_t fixpt_t;


typedef __darwin_blkcnt_t blkcnt_t;




typedef __darwin_blksize_t blksize_t;




typedef __darwin_gid_t gid_t;





typedef __uint32_t in_addr_t;




typedef __uint16_t in_port_t;



typedef __darwin_ino_t ino_t;





typedef __darwin_ino64_t ino64_t;






typedef __int32_t key_t;
# 157 "/usr/include/sys/types.h" 3 4
typedef __uint16_t nlink_t;
# 176 "/usr/include/sys/types.h" 3 4
typedef int32_t segsz_t;
typedef int32_t swblk_t;
# 223 "/usr/include/sys/types.h" 3 4
typedef __darwin_clock_t clock_t;
# 240 "/usr/include/sys/types.h" 3 4
typedef __darwin_time_t time_t;




typedef __darwin_useconds_t useconds_t;




typedef __darwin_suseconds_t suseconds_t;
# 260 "/usr/include/sys/types.h" 3 4
# 1 "/usr/include/sys/_structs.h" 1 3 4
# 183 "/usr/include/sys/_structs.h" 3 4

typedef struct fd_set {
 __int32_t fds_bits[((((1024) % ((sizeof(__int32_t) * 8))) == 0) ? ((1024) / ((sizeof(__int32_t) * 8))) : (((1024) / ((sizeof(__int32_t) * 8))) + 1))];
} fd_set;



static __inline int
__darwin_fd_isset(int _n, const struct fd_set *_p)
{
 return (_p->fds_bits[_n/(sizeof(__int32_t) * 8)] & (1<<(_n % (sizeof(__int32_t) * 8))));
}
# 261 "/usr/include/sys/types.h" 2 3 4




typedef __int32_t fd_mask;
# 322 "/usr/include/sys/types.h" 3 4
typedef __darwin_pthread_cond_t pthread_cond_t;



typedef __darwin_pthread_condattr_t pthread_condattr_t;



typedef __darwin_pthread_mutex_t pthread_mutex_t;



typedef __darwin_pthread_mutexattr_t pthread_mutexattr_t;



typedef __darwin_pthread_once_t pthread_once_t;



typedef __darwin_pthread_rwlock_t pthread_rwlock_t;



typedef __darwin_pthread_rwlockattr_t pthread_rwlockattr_t;



typedef __darwin_pthread_t pthread_t;






typedef __darwin_pthread_key_t pthread_key_t;





typedef __darwin_fsblkcnt_t fsblkcnt_t;




typedef __darwin_fsfilcnt_t fsfilcnt_t;
# 79 "c.h" 2

# 1 "/usr/include/errno.h" 1 3 4
# 23 "/usr/include/errno.h" 3 4
# 1 "/usr/include/sys/errno.h" 1 3 4
# 74 "/usr/include/sys/errno.h" 3 4

extern int * __error(void);


# 24 "/usr/include/errno.h" 2 3 4
# 81 "c.h" 2
# 91 "c.h"
# 1 "/usr/include/locale.h" 1 3 4
# 40 "/usr/include/locale.h" 3 4
# 1 "/usr/include/_locale.h" 1 3 4
# 43 "/usr/include/_locale.h" 3 4
struct lconv {
 char *decimal_point;
 char *thousands_sep;
 char *grouping;
 char *int_curr_symbol;
 char *currency_symbol;
 char *mon_decimal_point;
 char *mon_thousands_sep;
 char *mon_grouping;
 char *positive_sign;
 char *negative_sign;
 char int_frac_digits;
 char frac_digits;
 char p_cs_precedes;
 char p_sep_by_space;
 char n_cs_precedes;
 char n_sep_by_space;
 char p_sign_posn;
 char n_sign_posn;
 char int_p_cs_precedes;
 char int_n_cs_precedes;
 char int_p_sep_by_space;
 char int_n_sep_by_space;
 char int_p_sign_posn;
 char int_n_sign_posn;
};






struct lconv *localeconv(void);

# 41 "/usr/include/locale.h" 2 3 4
# 52 "/usr/include/locale.h" 3 4

char *setlocale(int, const char *);

# 92 "c.h" 2
# 181 "c.h"
typedef char bool;
# 193 "c.h"
typedef bool *BoolPtr;
# 224 "c.h"
typedef char *Pointer;
# 233 "c.h"
typedef signed char int8;
typedef signed short int16;
typedef signed int int32;
# 245 "c.h"
typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;






typedef uint8 bits8;
typedef uint16 bits16;
typedef uint32 bits32;
# 265 "c.h"
typedef long int int64;


typedef unsigned long int uint64;
# 308 "c.h"
typedef size_t Size;
# 317 "c.h"
typedef unsigned int Index;
# 327 "c.h"
typedef signed int Offset;




typedef int16 int2;
typedef int32 int4;
typedef float float4;
typedef double float8;
# 348 "c.h"
typedef Oid regproc;
typedef regproc RegProcedure;

typedef uint32 TransactionId;

typedef uint32 LocalTransactionId;

typedef uint32 SubTransactionId;





typedef TransactionId MultiXactId;

typedef uint32 MultiXactOffset;

typedef uint32 CommandId;







typedef struct
{
 int indx[6];
} IntArray;
# 391 "c.h"
struct varlena
{
 char vl_len_[4];
 char vl_dat[1];
};
# 404 "c.h"
typedef struct varlena bytea;
typedef struct varlena text;
typedef struct varlena BpChar;
typedef struct varlena VarChar;
# 419 "c.h"
typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
 int dim1;
 int lbound1;
 int2 values[1];
} int2vector;

typedef struct
{
 int32 vl_len_;
 int ndim;
 int32 dataoffset;
 Oid elemtype;
 int dim1;
 int lbound1;
 Oid values[1];
} oidvector;





typedef struct nameData
{
 char data[64];
} NameData;
typedef NameData *Name;
# 829 "c.h"
extern int fdatasync(int fildes);
# 860 "c.h"
# 1 "port.h" 1
# 16 "port.h"
# 1 "/usr/include/ctype.h" 1 3 4
# 69 "/usr/include/ctype.h" 3 4
# 1 "/usr/include/runetype.h" 1 3 4
# 70 "/usr/include/runetype.h" 3 4
typedef __darwin_wint_t wint_t;
# 81 "/usr/include/runetype.h" 3 4
typedef struct {
 __darwin_rune_t __min;
 __darwin_rune_t __max;
 __darwin_rune_t __map;
 __uint32_t *__types;
} _RuneEntry;

typedef struct {
 int __nranges;
 _RuneEntry *__ranges;
} _RuneRange;

typedef struct {
 char __name[14];
 __uint32_t __mask;
} _RuneCharClass;

typedef struct {
 char __magic[8];
 char __encoding[32];

 __darwin_rune_t (*__sgetrune)(const char *, __darwin_size_t, char const **);
 int (*__sputrune)(__darwin_rune_t, char *, __darwin_size_t, char **);
 __darwin_rune_t __invalid_rune;

 __uint32_t __runetype[(1 <<8 )];
 __darwin_rune_t __maplower[(1 <<8 )];
 __darwin_rune_t __mapupper[(1 <<8 )];






 _RuneRange __runetype_ext;
 _RuneRange __maplower_ext;
 _RuneRange __mapupper_ext;

 void *__variable;
 int __variable_len;




 int __ncharclasses;
 _RuneCharClass *__charclasses;
} _RuneLocale;




extern _RuneLocale _DefaultRuneLocale;
extern _RuneLocale *_CurrentRuneLocale;

# 70 "/usr/include/ctype.h" 2 3 4
# 145 "/usr/include/ctype.h" 3 4

unsigned long ___runetype(__darwin_ct_rune_t);
__darwin_ct_rune_t ___tolower(__darwin_ct_rune_t);
__darwin_ct_rune_t ___toupper(__darwin_ct_rune_t);


static __inline int
isascii(int _c)
{
 return ((_c & ~0x7F) == 0);
}
# 164 "/usr/include/ctype.h" 3 4

int __maskrune(__darwin_ct_rune_t, unsigned long);



static __inline int
__istype(__darwin_ct_rune_t _c, unsigned long _f)
{



 return (isascii(_c) ? !!(_DefaultRuneLocale.__runetype[_c] & _f)
  : !!__maskrune(_c, _f));

}

static __inline __darwin_ct_rune_t
__isctype(__darwin_ct_rune_t _c, unsigned long _f)
{



 return (_c < 0 || _c >= (1 <<8 )) ? 0 :
  !!(_DefaultRuneLocale.__runetype[_c] & _f);

}
# 204 "/usr/include/ctype.h" 3 4

__darwin_ct_rune_t __toupper(__darwin_ct_rune_t);
__darwin_ct_rune_t __tolower(__darwin_ct_rune_t);



static __inline int
__wcwidth(__darwin_ct_rune_t _c)
{
 unsigned int _x;

 if (_c == 0)
  return (0);
 _x = (unsigned int)__maskrune(_c, 0xe0000000L|0x00040000L);
 if ((_x & 0xe0000000L) != 0)
  return ((_x & 0xe0000000L) >> 30);
 return ((_x & 0x00040000L) != 0 ? 1 : -1);
}






static __inline int
isalnum(int _c)
{
 return (__istype(_c, 0x00000100L|0x00000400L));
}

static __inline int
isalpha(int _c)
{
 return (__istype(_c, 0x00000100L));
}

static __inline int
isblank(int _c)
{
 return (__istype(_c, 0x00020000L));
}

static __inline int
iscntrl(int _c)
{
 return (__istype(_c, 0x00000200L));
}


static __inline int
isdigit(int _c)
{
 return (__isctype(_c, 0x00000400L));
}

static __inline int
isgraph(int _c)
{
 return (__istype(_c, 0x00000800L));
}

static __inline int
islower(int _c)
{
 return (__istype(_c, 0x00001000L));
}

static __inline int
isprint(int _c)
{
 return (__istype(_c, 0x00040000L));
}

static __inline int
ispunct(int _c)
{
 return (__istype(_c, 0x00002000L));
}

static __inline int
isspace(int _c)
{
 return (__istype(_c, 0x00004000L));
}

static __inline int
isupper(int _c)
{
 return (__istype(_c, 0x00008000L));
}


static __inline int
isxdigit(int _c)
{
 return (__isctype(_c, 0x00010000L));
}

static __inline int
toascii(int _c)
{
 return (_c & 0x7F);
}

static __inline int
tolower(int _c)
{
        return (__tolower(_c));
}

static __inline int
toupper(int _c)
{
        return (__toupper(_c));
}


static __inline int
digittoint(int _c)
{
 return (__maskrune(_c, 0x0F));
}

static __inline int
ishexnumber(int _c)
{
 return (__istype(_c, 0x00010000L));
}

static __inline int
isideogram(int _c)
{
 return (__istype(_c, 0x00080000L));
}

static __inline int
isnumber(int _c)
{
 return (__istype(_c, 0x00000400L));
}

static __inline int
isphonogram(int _c)
{
 return (__istype(_c, 0x00200000L));
}

static __inline int
isrune(int _c)
{
 return (__istype(_c, 0xFFFFFFF0L));
}

static __inline int
isspecial(int _c)
{
 return (__istype(_c, 0x00100000L));
}
# 17 "port.h" 2
# 1 "./netdb.h" 1
# 18 "port.h" 2
# 1 "./pwd.h" 1
# 19 "port.h" 2



typedef int pgsocket;
# 32 "port.h"
extern bool pg_set_noblock(pgsocket sock);
extern bool pg_set_block(pgsocket sock);



extern bool has_drive_prefix(const char *filename);
extern char *first_dir_separator(const char *filename);
extern char *last_dir_separator(const char *filename);
extern char *first_path_var_separator(const char *pathlist);
extern void join_path_components(char *ret_path,
      const char *head, const char *tail);
extern void canonicalize_path(char *path);
extern void make_native_path(char *path);
extern bool path_contains_parent_reference(const char *path);
extern bool path_is_relative_and_below_cwd(const char *path);
extern bool path_is_prefix_of_path(const char *path1, const char *path2);
extern const char *get_progname(const char *argv0);
extern void get_share_path(const char *my_exec_path, char *ret_path);
extern void get_etc_path(const char *my_exec_path, char *ret_path);
extern void get_include_path(const char *my_exec_path, char *ret_path);
extern void get_pkginclude_path(const char *my_exec_path, char *ret_path);
extern void get_includeserver_path(const char *my_exec_path, char *ret_path);
extern void get_lib_path(const char *my_exec_path, char *ret_path);
extern void get_pkglib_path(const char *my_exec_path, char *ret_path);
extern void get_locale_path(const char *my_exec_path, char *ret_path);
extern void get_doc_path(const char *my_exec_path, char *ret_path);
extern void get_html_path(const char *my_exec_path, char *ret_path);
extern void get_man_path(const char *my_exec_path, char *ret_path);
extern bool get_home_path(char *ret_path);
extern void get_parent_directory(char *path);


extern char **pgfnames(const char *path);
extern void pgfnames_cleanup(char **filenames);
# 92 "port.h"
extern void set_pglocale_pgservice(const char *argv0, const char *app);


extern int find_my_exec(const char *argv0, char *retpath);
extern int find_other_exec(const char *argv0, const char *target,
    const char *versionstr, char *retpath);
# 149 "port.h"
extern void pg_usleep(long microsec);


extern int pg_strcasecmp(const char *s1, const char *s2);
extern int pg_strncasecmp(const char *s1, const char *s2, size_t n);
extern unsigned char pg_toupper(unsigned char ch);
extern unsigned char pg_tolower(unsigned char ch);
extern unsigned char pg_ascii_toupper(unsigned char ch);
extern unsigned char pg_ascii_tolower(unsigned char ch);
# 247 "port.h"
extern char *simple_prompt(const char *prompt, int maxlen, bool echo);







extern int pclose_check(FILE *stream);
# 300 "port.h"
extern bool rmtree(const char *path, bool rmtopdir);
# 372 "port.h"
extern double pg_erand48(unsigned short xseed[3]);
extern long pg_lrand48(void);
extern void pg_srand48(long seed);
# 428 "port.h"
extern char *pqStrerror(int errnum, char *strerrbuf, size_t buflen);


extern int pqGetpwuid(uid_t uid, struct passwd * resultbuf, char *buffer,
     size_t buflen, struct passwd ** result);


extern int pqGethostbyname(const char *name,
    struct hostent * resultbuf,
    char *buffer, size_t buflen,
    struct hostent ** result,
    int *herrno);

extern void pg_qsort(void *base, size_t nel, size_t elsize,
   int (*cmp) (const void *, const void *));



typedef int (*qsort_arg_comparator) (const void *a, const void *b, void *arg);

extern void qsort_arg(void *base, size_t nel, size_t elsize,
    qsort_arg_comparator cmp, void *arg);


extern int pg_get_encoding_from_locale(const char *ctype, bool write_message);


extern char *inet_net_ntop(int af, const void *src, int bits,
     char *dst, size_t size);


extern int pg_check_dir(const char *dir);


extern int pg_mkdir_p(char *path, int omode);
# 861 "c.h" 2
# 26 "postgres_fe.h" 2
# 4 "dt_common.c" 2

# 1 "./time.h" 1
# 6 "dt_common.c" 2

# 1 "/usr/include/math.h" 1 3 4
# 28 "/usr/include/math.h" 3 4
# 1 "/usr/include/architecture/i386/math.h" 1 3 4
# 49 "/usr/include/architecture/i386/math.h" 3 4
 typedef float float_t;
 typedef double double_t;
# 108 "/usr/include/architecture/i386/math.h" 3 4
extern int __math_errhandling ( void );
# 128 "/usr/include/architecture/i386/math.h" 3 4
extern int __fpclassifyf(float );
extern int __fpclassifyd(double );
extern int __fpclassify (long double);
# 163 "/usr/include/architecture/i386/math.h" 3 4
 static __inline__ int __inline_isfinitef (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isfinited (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isfinite (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_isinff (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isinfd (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isinf (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_isnanf (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnand (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnan (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_isnormalf (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnormald (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_isnormal (long double) __attribute__ ((always_inline));
 static __inline__ int __inline_signbitf (float ) __attribute__ ((always_inline));
 static __inline__ int __inline_signbitd (double ) __attribute__ ((always_inline));
 static __inline__ int __inline_signbit (long double) __attribute__ ((always_inline));

 static __inline__ int __inline_isinff( float __x ) { return __builtin_fabsf(__x) == __builtin_inff(); }
 static __inline__ int __inline_isinfd( double __x ) { return __builtin_fabs(__x) == __builtin_inf(); }
 static __inline__ int __inline_isinf( long double __x ) { return __builtin_fabsl(__x) == __builtin_infl(); }
 static __inline__ int __inline_isfinitef( float __x ) { return __x == __x && __builtin_fabsf(__x) != __builtin_inff(); }
 static __inline__ int __inline_isfinited( double __x ) { return __x == __x && __builtin_fabs(__x) != __builtin_inf(); }
 static __inline__ int __inline_isfinite( long double __x ) { return __x == __x && __builtin_fabsl(__x) != __builtin_infl(); }
 static __inline__ int __inline_isnanf( float __x ) { return __x != __x; }
 static __inline__ int __inline_isnand( double __x ) { return __x != __x; }
 static __inline__ int __inline_isnan( long double __x ) { return __x != __x; }
 static __inline__ int __inline_signbitf( float __x ) { union{ float __f; unsigned int __u; }__u; __u.__f = __x; return (int)(__u.__u >> 31); }
 static __inline__ int __inline_signbitd( double __x ) { union{ double __f; unsigned int __u[2]; }__u; __u.__f = __x; return (int)(__u.__u[1] >> 31); }
 static __inline__ int __inline_signbit( long double __x ){ union{ long double __ld; struct{ unsigned int __m[2]; short __sexp; }__p; }__u; __u.__ld = __x; return (int) (((unsigned short) __u.__p.__sexp) >> 15); }
 static __inline__ int __inline_isnormalf( float __x ) { float fabsf = __builtin_fabsf(__x); if( __x != __x ) return 0; return fabsf < __builtin_inff() && fabsf >= 1.17549435e-38F; }
 static __inline__ int __inline_isnormald( double __x ) { double fabsf = __builtin_fabs(__x); if( __x != __x ) return 0; return fabsf < __builtin_inf() && fabsf >= 2.2250738585072014e-308; }
 static __inline__ int __inline_isnormal( long double __x ) { long double fabsf = __builtin_fabsl(__x); if( __x != __x ) return 0; return fabsf < __builtin_infl() && fabsf >= 3.36210314311209350626e-4932L; }
# 253 "/usr/include/architecture/i386/math.h" 3 4
extern double acos( double );
extern float acosf( float );

extern double asin( double );
extern float asinf( float );

extern double atan( double );
extern float atanf( float );

extern double atan2( double, double );
extern float atan2f( float, float );

extern double cos( double );
extern float cosf( float );

extern double sin( double );
extern float sinf( float );

extern double tan( double );
extern float tanf( float );

extern double acosh( double );
extern float acoshf( float );

extern double asinh( double );
extern float asinhf( float );

extern double atanh( double );
extern float atanhf( float );

extern double cosh( double );
extern float coshf( float );

extern double sinh( double );
extern float sinhf( float );

extern double tanh( double );
extern float tanhf( float );

extern double exp ( double );
extern float expf ( float );

extern double exp2 ( double );
extern float exp2f ( float );

extern double expm1 ( double );
extern float expm1f ( float );

extern double log ( double );
extern float logf ( float );

extern double log10 ( double );
extern float log10f ( float );

extern double log2 ( double );
extern float log2f ( float );

extern double log1p ( double );
extern float log1pf ( float );

extern double logb ( double );
extern float logbf ( float );

extern double modf ( double, double * );
extern float modff ( float, float * );

extern double ldexp ( double, int );
extern float ldexpf ( float, int );

extern double frexp ( double, int * );
extern float frexpf ( float, int * );

extern int ilogb ( double );
extern int ilogbf ( float );

extern double scalbn ( double, int );
extern float scalbnf ( float, int );

extern double scalbln ( double, long int );
extern float scalblnf ( float, long int );

extern double fabs( double );
extern float fabsf( float );

extern double cbrt( double );
extern float cbrtf( float );

extern double hypot ( double, double );
extern float hypotf ( float, float );

extern double pow ( double, double );
extern float powf ( float, float );

extern double sqrt( double );
extern float sqrtf( float );

extern double erf( double );
extern float erff( float );

extern double erfc( double );
extern float erfcf( float );






extern double lgamma( double );
extern float lgammaf( float );

extern double tgamma( double );
extern float tgammaf( float );

extern double ceil ( double );
extern float ceilf ( float );

extern double floor ( double );
extern float floorf ( float );

extern double nearbyint ( double );
extern float nearbyintf ( float );

extern double rint ( double );
extern float rintf ( float );

extern long int lrint ( double );
extern long int lrintf ( float );

extern double round ( double );
extern float roundf ( float );

extern long int lround ( double );
extern long int lroundf ( float );



    extern long long int llrint ( double );
    extern long long int llrintf ( float );
    extern long long int llround ( double );
    extern long long int llroundf ( float );


extern double trunc ( double );
extern float truncf ( float );

extern double fmod ( double, double );
extern float fmodf ( float, float );

extern double remainder ( double, double );
extern float remainderf ( float, float );

extern double remquo ( double, double, int * );
extern float remquof ( float, float, int * );

extern double copysign ( double, double );
extern float copysignf ( float, float );

extern double nan( const char * );
extern float nanf( const char * );

extern double nextafter ( double, double );
extern float nextafterf ( float, float );

extern double fdim ( double, double );
extern float fdimf ( float, float );

extern double fmax ( double, double );
extern float fmaxf ( float, float );

extern double fmin ( double, double );
extern float fminf ( float, float );

extern double fma ( double, double, double );
extern float fmaf ( float, float, float );

extern long double acosl(long double);
extern long double asinl(long double);
extern long double atanl(long double);
extern long double atan2l(long double, long double);
extern long double cosl(long double);
extern long double sinl(long double);
extern long double tanl(long double);
extern long double acoshl(long double);
extern long double asinhl(long double);
extern long double atanhl(long double);
extern long double coshl(long double);
extern long double sinhl(long double);
extern long double tanhl(long double);
extern long double expl(long double);
extern long double exp2l(long double);
extern long double expm1l(long double);
extern long double logl(long double);
extern long double log10l(long double);
extern long double log2l(long double);
extern long double log1pl(long double);
extern long double logbl(long double);
extern long double modfl(long double, long double *);
extern long double ldexpl(long double, int);
extern long double frexpl(long double, int *);
extern int ilogbl(long double);
extern long double scalbnl(long double, int);
extern long double scalblnl(long double, long int);
extern long double fabsl(long double);
extern long double cbrtl(long double);
extern long double hypotl(long double, long double);
extern long double powl(long double, long double);
extern long double sqrtl(long double);
extern long double erfl(long double);
extern long double erfcl(long double);






extern long double lgammal(long double);

extern long double tgammal(long double);
extern long double ceill(long double);
extern long double floorl(long double);
extern long double nearbyintl(long double);
extern long double rintl(long double);
extern long int lrintl(long double);
extern long double roundl(long double);
extern long int lroundl(long double);



    extern long long int llrintl(long double);
    extern long long int llroundl(long double);


extern long double truncl(long double);
extern long double fmodl(long double, long double);
extern long double remainderl(long double, long double);
extern long double remquol(long double, long double, int *);
extern long double copysignl(long double, long double);
extern long double nanl(const char *);
extern long double nextafterl(long double, long double);
extern double nexttoward(double, long double);
extern float nexttowardf(float, long double);
extern long double nexttowardl(long double, long double);
extern long double fdiml(long double, long double);
extern long double fmaxl(long double, long double);
extern long double fminl(long double, long double);
extern long double fmal(long double, long double, long double);
# 507 "/usr/include/architecture/i386/math.h" 3 4
extern double __inf( void );
extern float __inff( void );
extern long double __infl( void );
extern float __nan( void );


extern double j0 ( double );

extern double j1 ( double );

extern double jn ( int, double );

extern double y0 ( double );

extern double y1 ( double );

extern double yn ( int, double );

extern double scalb ( double, double );
# 543 "/usr/include/architecture/i386/math.h" 3 4
extern int signgam;
# 558 "/usr/include/architecture/i386/math.h" 3 4
extern long int rinttol ( double );


extern long int roundtol ( double );
# 570 "/usr/include/architecture/i386/math.h" 3 4
struct exception {
 int type;
 char *name;
 double arg1;
 double arg2;
 double retval;
};
# 601 "/usr/include/architecture/i386/math.h" 3 4
extern int finite ( double );


extern double gamma ( double );




extern int matherr ( struct exception * );





extern double significand ( double );






extern double drem ( double, double );
# 29 "/usr/include/math.h" 2 3 4
# 8 "dt_common.c" 2

# 1 "extern.h" 1





# 1 "type.h" 1






# 1 "ecpgtype.h" 1
# 41 "ecpgtype.h"
enum ECPGttype
{
 ECPGt_char = 1, ECPGt_unsigned_char, ECPGt_short, ECPGt_unsigned_short,
 ECPGt_int, ECPGt_unsigned_int, ECPGt_long, ECPGt_unsigned_long,
 ECPGt_long_long, ECPGt_unsigned_long_long,
 ECPGt_bool,
 ECPGt_float, ECPGt_double,
 ECPGt_varchar, ECPGt_varchar2,
 ECPGt_numeric,

 ECPGt_decimal,

 ECPGt_date,
 ECPGt_timestamp,
 ECPGt_interval,
 ECPGt_array,
 ECPGt_struct,
 ECPGt_union,
 ECPGt_descriptor,
 ECPGt_char_variable,
 ECPGt_const,
 ECPGt_EOIT,
 ECPGt_EORT,
 ECPGt_NO_INDICATOR,
 ECPGt_string,
 ECPGt_sqlda
};


enum ECPGdtype
{
 ECPGd_count = 1,
 ECPGd_data,
 ECPGd_di_code,
 ECPGd_di_precision,
 ECPGd_indicator,
 ECPGd_key_member,
 ECPGd_length,
 ECPGd_name,
 ECPGd_nullable,
 ECPGd_octet,
 ECPGd_precision,
 ECPGd_ret_length,
 ECPGd_ret_octet,
 ECPGd_scale,
 ECPGd_type,
 ECPGd_EODT,
 ECPGd_cardinality
};




enum ECPG_statement_type
{
 ECPGst_normal,
 ECPGst_execute,
 ECPGst_exec_immediate,
 ECPGst_prepnormal
};
# 8 "type.h" 2

struct ECPGtype;
struct ECPGstruct_member
{
 char *name;
 struct ECPGtype *type;
 struct ECPGstruct_member *next;
};

struct ECPGtype
{
 enum ECPGttype type;
 char *type_name;

 char *size;

 char *struct_sizeof;

 union
 {
  struct ECPGtype *element;

  struct ECPGstruct_member *members;

 } u;
 int counter;
};


void ECPGmake_struct_member(char *, struct ECPGtype *, struct ECPGstruct_member **);
struct ECPGtype *ECPGmake_simple_type(enum ECPGttype, char *, int);
struct ECPGtype *ECPGmake_array_type(struct ECPGtype *, char *);
struct ECPGtype *ECPGmake_struct_type(struct ECPGstruct_member *, enum ECPGttype, char *, char *);
struct ECPGstruct_member *ECPGstruct_member_dup(struct ECPGstruct_member *);


void ECPGfree_struct_member(struct ECPGstruct_member *);
void ECPGfree_type(struct ECPGtype *);
# 57 "type.h"
void ECPGdump_a_type(FILE *, const char *, struct ECPGtype *, const int,
    const char *, struct ECPGtype *, const int,
    const char *, const char *, char *,
    const char *, const char *);


struct ECPGtemp_type
{
 struct ECPGtype *type;
 const char *name;
};

extern const char *ecpg_type_name(enum ECPGttype type);


enum WHEN_TYPE
{
 W_NOTHING,
 W_CONTINUE,
 W_BREAK,
 W_SQLPRINT,
 W_GOTO,
 W_DO,
 W_STOP
};

struct when
{
 enum WHEN_TYPE code;
 char *command;
 char *str;
};

struct index
{
 char *index1;
 char *index2;
 char *str;
};

struct su_symbol
{
 char *su;
 char *symbol;
};

struct prep
{
 char *name;
 char *stmt;
 char *type;
};

struct this_type
{
 enum ECPGttype type_enum;
 char *type_str;
 char *type_dimension;
 char *type_index;
 char *type_sizeof;
};

struct _include_path
{
 char *path;
 struct _include_path *next;
};

struct cursor
{
 char *name;
 char *function;
 char *command;
 char *connection;
 bool opened;
 struct arguments *argsinsert;
 struct arguments *argsinsert_oos;
 struct arguments *argsresult;
 struct arguments *argsresult_oos;
 struct cursor *next;
};

struct typedefs
{
 char *name;
 struct this_type *type;
 struct ECPGstruct_member *struct_member_list;
 int brace_level;
 struct typedefs *next;
};

struct _defines
{
 char *old;
 char *new;
 int pertinent;
 void *used;
 struct _defines *next;
};


struct variable
{
 char *name;
 struct ECPGtype *type;
 int brace_level;
 struct variable *next;
};

struct arguments
{
 struct variable *variable;
 struct variable *indicator;
 struct arguments *next;
};

struct descriptor
{
 char *name;
 char *connection;
 struct descriptor *next;
};

struct assignment
{
 char *variable;
 enum ECPGdtype value;
 struct assignment *next;
};

enum errortype
{
 ET_WARNING, ET_ERROR, ET_FATAL
};

struct fetch_desc
{
 char *str;
 char *name;
};
# 7 "extern.h" 2
# 1 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/keywords.h" 1
# 24 "/Users/parrt/tmp/postgresql-9.2.4/src/include/parser/keywords.h"
typedef struct ScanKeyword
{
 const char *name;
 int16 value;
 int16 category;
} ScanKeyword;

extern const ScanKeyword ScanKeywords[];
extern const int NumScanKeywords;

extern const ScanKeyword *ScanKeywordLookup(const char *text,
      const ScanKeyword *keywords,
      int num_keywords);
# 8 "extern.h" 2

# 1 "/usr/include/errno.h" 1 3 4
# 10 "extern.h" 2

# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 1 3 4






# 1 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/syslimits.h" 1 3 4
# 8 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 2 3 4







# 1 "/usr/include/limits.h" 1 3 4
# 64 "/usr/include/limits.h" 3 4
# 1 "/usr/include/machine/limits.h" 1 3 4





# 1 "/usr/include/i386/limits.h" 1 3 4
# 40 "/usr/include/i386/limits.h" 3 4
# 1 "/usr/include/i386/_limits.h" 1 3 4
# 41 "/usr/include/i386/limits.h" 2 3 4
# 7 "/usr/include/machine/limits.h" 2 3 4
# 65 "/usr/include/limits.h" 2 3 4
# 1 "/usr/include/sys/syslimits.h" 1 3 4
# 66 "/usr/include/limits.h" 2 3 4
# 16 "/Developer/usr/llvm-gcc-4.2/lib/gcc/i686-apple-darwin11/4.2.1/include/limits.h" 2 3 4
# 12 "extern.h" 2
# 21 "extern.h"
extern bool autocommit,
   auto_create_c,
   system_includes,
   force_indicator,
   questionmarks,
   regression_mode,
   auto_prepare;
extern int braces_open,
   ret_value,
   struct_level,
   ecpg_internal_var;
extern char *current_function;
extern char *descriptor_index;
extern char *descriptor_name;
extern char *connection;
extern char *input_filename;
extern char *yytext,
     *token_start;




extern int yylineno;
extern FILE *yyin,
     *yyout;
extern char *output_filename;

extern struct _include_path *include_paths;
extern struct cursor *cur;
extern struct typedefs *types;
extern struct _defines *defines;
extern struct ECPGtype ecpg_no_indicator;
extern struct variable no_indicator;
extern struct arguments *argsinsert;
extern struct arguments *argsresult;
extern struct when when_error,
   when_nf,
   when_warn;
extern struct ECPGstruct_member *struct_member_list[128];



extern const char *get_dtype(enum ECPGdtype);
extern void lex_init(void);
extern void output_line_number(void);
extern void output_statement(char *, int, enum ECPG_statement_type);
extern void output_prepare_statement(char *, char *);
extern void output_deallocate_prepare_statement(char *);
extern void output_simple_statement(char *);
extern char *hashline_number(void);
extern int base_yyparse(void);
extern int base_yylex(void);
extern void base_yyerror(const char *);
extern void *mm_alloc(size_t), *mm_realloc(void *, size_t);
extern char *mm_strdup(const char *);
extern void
mmerror(int, enum errortype, const char *,...)

__attribute__((format(printf, 3, 4)));
extern void output_get_descr_header(char *);
extern void output_get_descr(char *, char *);
extern void output_set_descr_header(char *);
extern void output_set_descr(char *, char *);
extern void push_assignment(char *, enum ECPGdtype);
extern struct variable *find_variable(char *);
extern void whenever_action(int);
extern void add_descriptor(char *, char *);
extern void drop_descriptor(char *, char *);
extern struct descriptor *lookup_descriptor(char *, char *);
extern struct variable *descriptor_variable(const char *name, int input);
extern struct variable *sqlda_variable(const char *name);
extern void add_variable_to_head(struct arguments **, struct variable *, struct variable *);
extern void add_variable_to_tail(struct arguments **, struct variable *, struct variable *);
extern void remove_variable_from_list(struct arguments ** list, struct variable * var);
extern void dump_variables(struct arguments *, int);
extern struct typedefs *get_typedef(char *);
extern void adjust_array(enum ECPGttype, char **, char **, char *, char *, int, bool);
extern void reset_variables(void);
extern void check_indicator(struct ECPGtype *);
extern void remove_typedefs(int);
extern void remove_variables(int);
extern struct variable *new_variable(const char *, struct ECPGtype *, int);
extern const ScanKeyword *ScanCKeywordLookup(const char *);
extern const ScanKeyword *ScanECPGKeywordLookup(const char *text);
extern void scanner_init(const char *);
extern void parser_init(void);
extern void scanner_finish(void);
extern int filtered_base_yylex(void);
# 120 "extern.h"
enum COMPAT_MODE
{
 ECPG_COMPAT_PGSQL = 0, ECPG_COMPAT_INFORMIX, ECPG_COMPAT_INFORMIX_SE
};
extern enum COMPAT_MODE compat;
# 10 "dt_common.c" 2
# 1 "dt.h" 1





# 1 "./pgtypes_timestamp.h" 1






# 1 "./pgtypes_interval.h" 1





# 1 "./ecpg_config.h" 1
# 7 "./pgtypes_interval.h" 2
# 28 "./pgtypes_interval.h"
typedef struct
{

 int64 time;



 long month;
} interval;






extern interval *PGTYPESinterval_new(void);
extern void PGTYPESinterval_free(interval *);
extern interval *PGTYPESinterval_from_asc(char *, char **);
extern char *PGTYPESinterval_to_asc(interval *);
extern int PGTYPESinterval_copy(interval *, interval *);
# 8 "./pgtypes_timestamp.h" 2


typedef int64 timestamp;
typedef int64 TimestampTz;
# 22 "./pgtypes_timestamp.h"
extern timestamp PGTYPEStimestamp_from_asc(char *, char **);
extern char *PGTYPEStimestamp_to_asc(timestamp);
extern int PGTYPEStimestamp_sub(timestamp *, timestamp *, interval *);
extern int PGTYPEStimestamp_fmt_asc(timestamp *, char *, int, const char *);
extern void PGTYPEStimestamp_current(timestamp *);
extern int PGTYPEStimestamp_defmt_asc(char *, const char *, timestamp *);
extern int PGTYPEStimestamp_add_interval(timestamp * tin, interval * span, timestamp * tout);
extern int PGTYPEStimestamp_sub_interval(timestamp * tin, interval * span, timestamp * tout);
# 7 "dt.h" 2





typedef int32 fsec_t;
# 203 "dt.h"
typedef struct
{



 char token[10];

 char type;
 char value;
} datetkn;
# 335 "dt.h"
int DecodeInterval(char **, int *, int, int *, struct tm *, fsec_t *);
int DecodeTime(char *, int *, struct tm *, fsec_t *);
int EncodeDateTime(struct tm * tm, fsec_t fsec, bool print_tz, int tz, const char *tzn, int style, char *str, bool EuroDates);
int EncodeInterval(struct tm * tm, fsec_t fsec, int style, char *str);
int tm2timestamp(struct tm *, fsec_t, int *, timestamp *);
int DecodeUnits(int field, char *lowtoken, int *val);
bool CheckDateTokenTables(void);
int EncodeDateOnly(struct tm * tm, int style, char *str, bool EuroDates);
int GetEpochTime(struct tm *);
int ParseDateTime(char *, char *, char **, int *, int *, char **);
int DecodeDateTime(char **, int *, int, int *, struct tm *, fsec_t *, bool);
void j2date(int, int *, int *, int *);
void GetCurrentDateTime(struct tm *);
int date2j(int, int, int);
void TrimTrailingZeros(char *);
void dt2time(double, int *, int *, int *, fsec_t *);

extern char *pgtypes_date_weekdays_short[];
extern char *pgtypes_date_months[];
extern char *months[];
extern char *days[];
extern int day_tab[2][13];
# 11 "dt_common.c" 2
# 1 "pgtypes_timestamp.h" 1
# 12 "dt_common.c" 2

int day_tab[2][13] = {
 {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31, 0},
{31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31, 0}};

typedef long AbsoluteTime;
# 26 "dt_common.c"
static datetkn datetktbl[] = {

 {"-infinity", 0, 9},
 {"acsst", 6, (42)},
 {"acst", 6, ((16)|((char) 0200))},
 {"act", 5, ((20)|((char) 0200))},
 {"ad", 18, 0},
 {"adt", 6, ((12)|((char) 0200))},
 {"aesst", 6, (44)},
 {"aest", 5, (40)},
 {"aft", 5, (18)},
 {"ahst", 5, ((40)|((char) 0200))},
 {"akdt", 6, ((32)|((char) 0200))},
 {"akst", 6, ((36)|((char) 0200))},
 {"allballs", 0, 16},
 {"almst", 5, (28)},
 {"almt", 5, (24)},
 {"am", 9, 0},
 {"amst", 6, (20)},



 {"amt", 5, (16)},
 {"anast", 6, (52)},
 {"anat", 5, (48)},
 {"apr", 1, 4},
 {"april", 1, 4},





 {"art", 5, ((12)|((char) 0200))},





 {"ast", 5, ((16)|((char) 0200))},
 {"at", 8, 0},
 {"aug", 1, 8},
 {"august", 1, 8},
 {"awsst", 6, (36)},
 {"awst", 5, (32)},
 {"awt", 6, ((12)|((char) 0200))},
 {"azost", 6, (0)},
 {"azot", 5, ((4)|((char) 0200))},
 {"azst", 6, (20)},
 {"azt", 5, (16)},
 {"bc", 18, 1},
 {"bdst", 5, (8)},
 {"bdt", 5, (24)},
 {"bnt", 5, (32)},
 {"bort", 5, (32)},




 {"bot", 5, ((16)|((char) 0200))},
 {"bra", 5, ((12)|((char) 0200))},




 {"bst", 6, (4)},




 {"bt", 5, (12)},
 {"btt", 5, (24)},
 {"cadt", 6, (42)},
 {"cast", 5, (38)},
 {"cat", 5, ((40)|((char) 0200))},
 {"cct", 5, (32)},



 {"cdt", 6, ((20)|((char) 0200))},
 {"cest", 6, (8)},
 {"cet", 5, (4)},
 {"cetdst", 6, (8)},
 {"chadt", 6, (55)},
 {"chast", 5, (51)},



 {"ckt", 5, (48)},
 {"clst", 6, ((12)|((char) 0200))},
 {"clt", 5, ((16)|((char) 0200))},



 {"cot", 5, ((20)|((char) 0200))},
 {"cst", 5, ((24)|((char) 0200))},
 {"current", 0, 8},



 {"cvt", 5, (28)},
 {"cxt", 5, (28)},
 {"d", 17, 21},
 {"davt", 5, (28)},
 {"ddut", 5, (40)},
 {"dec", 1, 12},
 {"december", 1, 12},
 {"dnt", 5, (4)},
 {"dow", 0, 32},
 {"doy", 0, 33},
 {"dst", 7, 6},



 {"easst", 6, ((20)|((char) 0200))},
 {"east", 5, ((24)|((char) 0200))},
 {"eat", 5, (12)},






 {"edt", 6, ((16)|((char) 0200))},
 {"eest", 6, (12)},
 {"eet", 5, (8)},
 {"eetdst", 6, (12)},
 {"egst", 6, (0)},
 {"egt", 5, ((4)|((char) 0200))},



 {"epoch", 0, 11},
 {"est", 5, ((20)|((char) 0200))},
 {"feb", 1, 2},
 {"february", 1, 2},
 {"fjst", 6, ((52)|((char) 0200))},
 {"fjt", 5, ((48)|((char) 0200))},
 {"fkst", 6, ((12)|((char) 0200))},
 {"fkt", 5, ((8)|((char) 0200))},




 {"fri", 16, 5},
 {"friday", 16, 5},
 {"fst", 5, (4)},
 {"fwt", 6, (8)},
 {"galt", 5, ((24)|((char) 0200))},
 {"gamt", 5, ((36)|((char) 0200))},
 {"gest", 6, (20)},
 {"get", 5, (16)},
 {"gft", 5, ((12)|((char) 0200))},



 {"gilt", 5, (48)},
 {"gmt", 5, (0)},
 {"gst", 5, (40)},
 {"gyt", 5, ((16)|((char) 0200))},
 {"h", 17, 20},




 {"hdt", 6, ((36)|((char) 0200))},



 {"hkt", 5, (32)},





 {"hst", 5, ((40)|((char) 0200))},



 {"ict", 5, (28)},
 {"idle", 5, (48)},
 {"idlw", 5, ((48)|((char) 0200))},



 {"infinity", 0, 10},
 {"invalid", 0, 7},
 {"iot", 5, (20)},
 {"irkst", 6, (36)},
 {"irkt", 5, (32)},
 {"irt", 5, (14)},
 {"isodow", 0, 37},



 {"ist", 5, (8)},
 {"it", 5, (14)},
 {"j", 17, 31},
 {"jan", 1, 1},
 {"january", 1, 1},
 {"javt", 5, (28)},
 {"jayt", 5, (36)},
 {"jd", 17, 31},
 {"jst", 5, (36)},
 {"jt", 5, (30)},
 {"jul", 1, 7},
 {"julian", 17, 31},
 {"july", 1, 7},
 {"jun", 1, 6},
 {"june", 1, 6},
 {"kdt", 6, (40)},
 {"kgst", 6, (24)},
 {"kgt", 5, (20)},
 {"kost", 5, (48)},
 {"krast", 6, (28)},
 {"krat", 5, (32)},
 {"kst", 5, (36)},
 {"lhdt", 6, (44)},
 {"lhst", 5, (42)},
 {"ligt", 5, (40)},
 {"lint", 5, (56)},
 {"lkt", 5, (24)},
 {"m", 17, 23},
 {"magst", 6, (48)},
 {"magt", 5, (44)},
 {"mar", 1, 3},
 {"march", 1, 3},
 {"mart", 5, ((38)|((char) 0200))},
 {"mawt", 5, (24)},
 {"may", 1, 5},
 {"mdt", 6, ((24)|((char) 0200))},
 {"mest", 6, (8)},
 {"met", 5, (4)},
 {"metdst", 6, (8)},
 {"mewt", 5, (4)},
 {"mez", 5, (4)},
 {"mht", 5, (48)},
 {"mm", 17, 19},
 {"mmt", 5, (26)},
 {"mon", 16, 1},
 {"monday", 16, 1},



 {"mpt", 5, (40)},
 {"msd", 6, (16)},
 {"msk", 5, (12)},
 {"mst", 5, ((28)|((char) 0200))},
 {"mt", 5, (34)},
 {"mut", 5, (16)},
 {"mvt", 5, (20)},
 {"myt", 5, (32)},



 {"nct", 5, (44)},
 {"ndt", 6, ((10)|((char) 0200))},
 {"nft", 5, ((14)|((char) 0200))},
 {"nor", 5, (4)},
 {"nov", 1, 11},
 {"november", 1, 11},
 {"novst", 6, (28)},
 {"novt", 5, (24)},
 {"now", 0, 12},
 {"npt", 5, (23)},
 {"nst", 5, ((14)|((char) 0200))},
 {"nt", 5, ((44)|((char) 0200))},
 {"nut", 5, ((44)|((char) 0200))},
 {"nzdt", 6, (52)},
 {"nzst", 5, (48)},
 {"nzt", 5, (48)},
 {"oct", 1, 10},
 {"october", 1, 10},
 {"omsst", 6, (28)},
 {"omst", 5, (24)},
 {"on", 8, 0},
 {"pdt", 6, ((28)|((char) 0200))},



 {"pet", 5, ((20)|((char) 0200))},
 {"petst", 6, (52)},
 {"pett", 5, (48)},
 {"pgt", 5, (40)},
 {"phot", 5, (52)},



 {"pht", 5, (32)},
 {"pkt", 5, (20)},
 {"pm", 9, 1},
 {"pmdt", 6, ((8)|((char) 0200))},



 {"pont", 5, (44)},
 {"pst", 5, ((32)|((char) 0200))},
 {"pwt", 5, (36)},
 {"pyst", 6, ((12)|((char) 0200))},
 {"pyt", 5, ((16)|((char) 0200))},
 {"ret", 6, (16)},
 {"s", 17, 18},
 {"sadt", 6, (42)},




 {"sast", 5, (38)},
 {"sat", 16, 6},
 {"saturday", 16, 6},



 {"sct", 6, (16)},
 {"sep", 1, 9},
 {"sept", 1, 9},
 {"september", 1, 9},
 {"set", 5, ((4)|((char) 0200))},



 {"sst", 6, (8)},
 {"sun", 16, 0},
 {"sunday", 16, 0},
 {"swt", 5, (4)},



 {"t", 23, 3},
 {"tft", 5, (20)},
 {"that", 5, ((40)|((char) 0200))},
 {"thu", 16, 4},
 {"thur", 16, 4},
 {"thurs", 16, 4},
 {"thursday", 16, 4},
 {"tjt", 5, (20)},
 {"tkt", 5, ((40)|((char) 0200))},
 {"tmt", 5, (20)},
 {"today", 0, 14},
 {"tomorrow", 0, 15},



 {"tot", 5, (52)},



 {"truk", 5, (40)},
 {"tue", 16, 2},
 {"tues", 16, 2},
 {"tuesday", 16, 2},
 {"tvt", 5, (48)},



 {"ulast", 6, (36)},
 {"ulat", 5, (32)},
 {"undefined", 0, 7},
 {"ut", 5, (0)},
 {"utc", 5, (0)},
 {"uyst", 6, ((8)|((char) 0200))},
 {"uyt", 5, ((12)|((char) 0200))},
 {"uzst", 6, (24)},
 {"uzt", 5, (20)},
 {"vet", 5, ((16)|((char) 0200))},
 {"vlast", 6, (44)},
 {"vlat", 5, (40)},



 {"vut", 5, (44)},
 {"wadt", 6, (32)},
 {"wakt", 5, (48)},



 {"wast", 5, (28)},
 {"wat", 5, ((4)|((char) 0200))},
 {"wdt", 6, (36)},
 {"wed", 16, 3},
 {"wednesday", 16, 3},
 {"weds", 16, 3},
 {"west", 6, (4)},
 {"wet", 5, (0)},
 {"wetdst", 6, (4)},
 {"wft", 5, (48)},
 {"wgst", 6, ((8)|((char) 0200))},
 {"wgt", 5, ((12)|((char) 0200))},
 {"wst", 5, (32)},
 {"y", 17, 25},
 {"yakst", 6, (40)},
 {"yakt", 5, (36)},
 {"yapt", 5, (40)},
 {"ydt", 6, ((32)|((char) 0200))},
 {"yekst", 6, (24)},
 {"yekt", 5, (20)},
 {"yesterday", 0, 13},
 {"yst", 5, ((36)|((char) 0200))},
 {"z", 5, (0)},
 {"zp4", 5, ((16)|((char) 0200))},
 {"zp5", 5, ((20)|((char) 0200))},
 {"zp6", 5, ((24)|((char) 0200))},
 {"zulu", 5, (0)},
};

static datetkn deltatktbl[] = {

 {"@", 8, 0},
 {"ago", 19, 0},
 {"c", 17, 27},
 {"cent", 17, 27},
 {"centuries", 17, 27},
 {"century", 17, 27},
 {"d", 17, 21},
 {"day", 17, 21},
 {"days", 17, 21},
 {"dec", 17, 26},
 {"decade", 17, 26},
 {"decades", 17, 26},
 {"decs", 17, 26},
 {"h", 17, 20},
 {"hour", 17, 20},
 {"hours", 17, 20},
 {"hr", 17, 20},
 {"hrs", 17, 20},
 {"invalid", 0, 7},
 {"m", 17, 19},
 {"microsecon", 17, 30},
 {"mil", 17, 28},
 {"millennia", 17, 28},
 {"millennium", 17, 28},
 {"millisecon", 17, 29},
 {"mils", 17, 28},
 {"min", 17, 19},
 {"mins", 17, 19},
 {"minute", 17, 19},
 {"minutes", 17, 19},
 {"mon", 17, 23},
 {"mons", 17, 23},
 {"month", 17, 23},
 {"months", 17, 23},
 {"ms", 17, 29},
 {"msec", 17, 29},
 {"msecond", 17, 29},
 {"mseconds", 17, 29},
 {"msecs", 17, 29},
 {"qtr", 17, 24},
 {"quarter", 17, 24},
 {"s", 17, 18},
 {"sec", 17, 18},
 {"second", 17, 18},
 {"seconds", 17, 18},
 {"secs", 17, 18},
 {"timezone", 17, 4},
 {"timezone_h", 17, 34},
 {"timezone_m", 17, 35},
 {"undefined", 0, 7},
 {"us", 17, 30},
 {"usec", 17, 30},
 {"usecond", 17, 30},
 {"useconds", 17, 30},
 {"usecs", 17, 30},
 {"w", 17, 22},
 {"week", 17, 22},
 {"weeks", 17, 22},
 {"y", 17, 25},
 {"year", 17, 25},
 {"years", 17, 25},
 {"yr", 17, 25},
 {"yrs", 17, 25},
};

static const unsigned int szdatetktbl = (sizeof (datetktbl) / sizeof ((datetktbl)[0]));
static const unsigned int szdeltatktbl = (sizeof (deltatktbl) / sizeof ((deltatktbl)[0]));

static datetkn *datecache[25] = {((void *)0)};

static datetkn *deltacache[25] = {((void *)0)};

char *months[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", ((void *)0)};

char *days[] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", ((void *)0)};

char *pgtypes_date_weekdays_short[] = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", ((void *)0)};

char *pgtypes_date_months[] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December", ((void *)0)};

static datetkn *
datebsearch(char *key, datetkn *base, unsigned int nel)
{
 if (nel > 0)
 {
  datetkn *last = base + nel - 1,
       *position;
  int result;

  while (last >= base)
  {
   position = base + ((last - base) >> 1);
   result = key[0] - position->token[0];
   if (result == 0)
   {
    result = strncmp(key, position->token, 10);
    if (result == 0)
     return position;
   }
   if (result < 0)
    last = position - 1;
   else
    base = position + 1;
  }
 }
 return ((void *)0);
}





int
DecodeUnits(int field, char *lowtoken, int *val)
{
 int type;
 datetkn *tp;

 if (deltacache[field] != ((void *)0) &&
  strncmp(lowtoken, deltacache[field]->token, 10) == 0)
  tp = deltacache[field];
 else
  tp = datebsearch(lowtoken, deltatktbl, szdeltatktbl);
 deltacache[field] = tp;
 if (tp == ((void *)0))
 {
  type = 31;
  *val = 0;
 }
 else
 {
  type = tp->type;
  if (type == 5 || type == 6)
   *val = (-(((tp)->value)&((char) 0200)? -(((tp)->value)&((char) 0177)): ((tp)->value)) * 15);
  else
   *val = tp->value;
 }

 return type;
}
# 591 "dt_common.c"
int
date2j(int y, int m, int d)
{
 int julian;
 int century;

 if (m > 2)
 {
  m += 1;
  y += 4800;
 }
 else
 {
  m += 13;
  y += 4799;
 }

 century = y / 100;
 julian = y * 365 - 32167;
 julian += y / 4 - century + century / 4;
 julian += 7834 * m / 256 + d;

 return julian;
}

void
j2date(int jd, int *year, int *month, int *day)
{
 unsigned int julian;
 unsigned int quad;
 unsigned int extra;
 int y;

 julian = jd;
 julian += 32044;
 quad = julian / 146097;
 extra = (julian - quad * 146097) * 4 + 3;
 julian += 60 + quad * 3 + extra / 146097;
 quad = julian / 1461;
 julian -= quad * 1461;
 y = julian * 4 / 1461;
 julian = ((y != 0) ? (julian + 305) % 365 : (julian + 306) % 366) + 123;
 y += quad * 4;
 *year = y - 4800;
 quad = julian * 2141 / 65536;
 *day = julian - 7834 * quad / 256;
 *month = (quad + 10) % 12 + 1;

 return;
}






static int
DecodeSpecial(int field, char *lowtoken, int *val)
{
 int type;
 datetkn *tp;

 if (datecache[field] != ((void *)0) &&
  strncmp(lowtoken, datecache[field]->token, 10) == 0)
  tp = datecache[field];
 else
 {
  tp = ((void *)0);
  if (!tp)
   tp = datebsearch(lowtoken, datetktbl, szdatetktbl);
 }
 datecache[field] = tp;
 if (tp == ((void *)0))
 {
  type = 31;
  *val = 0;
 }
 else
 {
  type = tp->type;
  switch (type)
  {
   case 5:
   case 6:
   case 7:
    *val = (-(((tp)->value)&((char) 0200)? -(((tp)->value)&((char) 0177)): ((tp)->value)) * 15);
    break;

   default:
    *val = tp->value;
    break;
  }
 }

 return type;
}




int
EncodeDateOnly(struct tm * tm, int style, char *str, bool EuroDates)
{
 if (tm->tm_mon < 1 || tm->tm_mon > 12)
  return -1;

 switch (style)
 {
  case 1:

   if (tm->tm_year > 0)
    __builtin___sprintf_chk (str, 0, __builtin_object_size (str, 2 > 1), "%04d-%02d-%02d", tm->tm_year, tm->tm_mon, tm->tm_mday);

   else
    __builtin___sprintf_chk (str, 0, __builtin_object_size (str, 2 > 1), "%04d-%02d-%02d %s", -(tm->tm_year - 1), tm->tm_mon, tm->tm_mday, "BC");

   break;

  case 2:

   if (EuroDates)
    __builtin___sprintf_chk (str, 0, __builtin_object_size (str, 2 > 1), "%02d/%02d", tm->tm_mday, tm->tm_mon);
   else
    __builtin___sprintf_chk (str, 0, __builtin_object_size (str, 2 > 1), "%02d/%02d", tm->tm_mon, tm->tm_mday);
   if (tm->tm_year > 0)
    __builtin___sprintf_chk (str + 5, 0, __builtin_object_size (str + 5, 2 > 1), "/%04d", tm->tm_year);
   else
    __builtin___sprintf_chk (str + 5, 0, __builtin_object_size (str + 5, 2 > 1), "/%04d %s", -(tm->tm_year - 1), "BC");
   break;

  case 3:

   __builtin___sprintf_chk (str, 0, __builtin_object_size (str, 2 > 1), "%02d.%02d", tm->tm_mday, tm->tm_mon);
   if (tm->tm_year > 0)
    __builtin___sprintf_chk (str + 5, 0, __builtin_object_size (str + 5, 2 > 1), ".%04d", tm->tm_year);
   else
    __builtin___sprintf_chk (str + 5, 0, __builtin_object_size (str + 5, 2 > 1), ".%04d %s", -(tm->tm_year - 1), "BC");
   break;

  case 0:
  default:

   if (EuroDates)
    __builtin___sprintf_chk (str, 0, __builtin_object_size (str, 2 > 1), "%02d-%02d", tm->tm_mday, tm->tm_mon);
   else
    __builtin___sprintf_chk (str, 0, __builtin_object_size (str, 2 > 1), "%02d-%02d", tm->tm_mon, tm->tm_mday);
   if (tm->tm_year > 0)
    __builtin___sprintf_chk (str + 5, 0, __builtin_object_size (str + 5, 2 > 1), "-%04d", tm->tm_year);
   else
    __builtin___sprintf_chk (str + 5, 0, __builtin_object_size (str + 5, 2 > 1), "-%04d %s", -(tm->tm_year - 1), "BC");
   break;
 }

 return 1;
}

void
TrimTrailingZeros(char *str)
{
 int len = strlen(str);


 while (*(str + len - 1) == '0' && *(str + len - 3) != '.')
 {
  len--;
  *(str + len) = '\0';
 }
}
# 778 "dt_common.c"
int
EncodeDateTime(struct tm * tm, fsec_t fsec, bool print_tz, int tz, const char *tzn, int style, char *str, bool EuroDates)
{
 int day,
    hour,
    min;




 if (tm->tm_isdst < 0)
  print_tz = ((bool) 0);

 switch (style)
 {
  case 1:


   __builtin___sprintf_chk (str, 0, __builtin_object_size (str, 2 > 1), "%04d-%02d-%02d %02d:%02d", (tm->tm_year > 0) ? tm->tm_year : -(tm->tm_year - 1), tm->tm_mon, tm->tm_mday, tm->tm_hour, tm->tm_min);
# 808 "dt_common.c"
   if (fsec != 0)
   {
    __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), ":%02d.%06d", tm->tm_sec, fsec);





    TrimTrailingZeros(str);
   }
   else
    __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), ":%02d", tm->tm_sec);

   if (tm->tm_year <= 0)
    __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), " BC");

   if (print_tz)
   {
    hour = -(tz / 3600);
    min = (abs(tz) / 60) % 60;
    if (min != 0)
     __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), "%+03d:%02d", hour, min);
    else
     __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), "%+03d", hour);
   }
   break;

  case 2:


   if (EuroDates)
    __builtin___sprintf_chk (str, 0, __builtin_object_size (str, 2 > 1), "%02d/%02d", tm->tm_mday, tm->tm_mon);
   else
    __builtin___sprintf_chk (str, 0, __builtin_object_size (str, 2 > 1), "%02d/%02d", tm->tm_mon, tm->tm_mday);

   __builtin___sprintf_chk (str + 5, 0, __builtin_object_size (str + 5, 2 > 1), "/%04d %02d:%02d", (tm->tm_year > 0) ? tm->tm_year : -(tm->tm_year - 1), tm->tm_hour, tm->tm_min);
# 855 "dt_common.c"
   if (fsec != 0)
   {
    __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), ":%02d.%06d", tm->tm_sec, fsec);





    TrimTrailingZeros(str);
   }
   else
    __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), ":%02d", tm->tm_sec);

   if (tm->tm_year <= 0)
    __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), " BC");







   if (print_tz)
   {
    if (tzn)
     __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), " %.*s", 10, tzn);
    else
    {
     hour = -(tz / 3600);
     min = (abs(tz) / 60) % 60;
     if (min != 0)
      __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), "%+03d:%02d", hour, min);
     else
      __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), "%+03d", hour);
    }
   }
   break;

  case 3:


   __builtin___sprintf_chk (str, 0, __builtin_object_size (str, 2 > 1), "%02d.%02d", tm->tm_mday, tm->tm_mon);

   __builtin___sprintf_chk (str + 5, 0, __builtin_object_size (str + 5, 2 > 1), ".%04d %02d:%02d", (tm->tm_year > 0) ? tm->tm_year : -(tm->tm_year - 1), tm->tm_hour, tm->tm_min);
# 910 "dt_common.c"
   if (fsec != 0)
   {
    __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), ":%02d.%06d", tm->tm_sec, fsec);





    TrimTrailingZeros(str);
   }
   else
    __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), ":%02d", tm->tm_sec);

   if (tm->tm_year <= 0)
    __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), " BC");

   if (print_tz)
   {
    if (tzn)
     __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), " %.*s", 10, tzn);
    else
    {
     hour = -(tz / 3600);
     min = (abs(tz) / 60) % 60;
     if (min != 0)
      __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), "%+03d:%02d", hour, min);
     else
      __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), "%+03d", hour);
    }
   }
   break;

  case 0:
  default:


   day = date2j(tm->tm_year, tm->tm_mon, tm->tm_mday);
   tm->tm_wday = (int) ((day + date2j(2000, 1, 1) + 1) % 7);

   ((__builtin_object_size (str, 0) != (size_t) -1) ? __builtin___strncpy_chk (str, days[tm->tm_wday], 3, __builtin_object_size (str, 2 > 1)) : __inline_strncpy_chk (str, days[tm->tm_wday], 3));
   ((__builtin_object_size (str + 3, 0) != (size_t) -1) ? __builtin___strcpy_chk (str + 3, " ", __builtin_object_size (str + 3, 2 > 1)) : __inline_strcpy_chk (str + 3, " "));

   if (EuroDates)
    __builtin___sprintf_chk (str + 4, 0, __builtin_object_size (str + 4, 2 > 1), "%02d %3s", tm->tm_mday, months[tm->tm_mon - 1]);
   else
    __builtin___sprintf_chk (str + 4, 0, __builtin_object_size (str + 4, 2 > 1), "%3s %02d", months[tm->tm_mon - 1], tm->tm_mday);

   __builtin___sprintf_chk (str + 10, 0, __builtin_object_size (str + 10, 2 > 1), " %02d:%02d", tm->tm_hour, tm->tm_min);
# 967 "dt_common.c"
   if (fsec != 0)
   {
    __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), ":%02d.%06d", tm->tm_sec, fsec);





    TrimTrailingZeros(str);
   }
   else
    __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), ":%02d", tm->tm_sec);

   __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), " %04d", (tm->tm_year > 0) ? tm->tm_year : -(tm->tm_year - 1));

   if (tm->tm_year <= 0)
    __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), " BC");

   if (print_tz)
   {
    if (tzn)
     __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), " %.*s", 10, tzn);
    else
    {






     hour = -(tz / 3600);
     min = (abs(tz) / 60) % 60;
     if (min != 0)
      __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), " %+03d:%02d", hour, min);
     else
      __builtin___sprintf_chk (str + strlen(str), 0, __builtin_object_size (str + strlen(str), 2 > 1), " %+03d", hour);
    }
   }
   break;
 }

 return 1;
}

int
GetEpochTime(struct tm * tm)
{
 struct tm *t0;
 time_t epoch = 0;

 t0 = gmtime(&epoch);

 if (t0)
 {
  tm->tm_year = t0->tm_year + 1900;
  tm->tm_mon = t0->tm_mon + 1;
  tm->tm_mday = t0->tm_mday;
  tm->tm_hour = t0->tm_hour;
  tm->tm_min = t0->tm_min;
  tm->tm_sec = t0->tm_sec;

  return 0;
 }

 return -1;
}

static void
abstime2tm(AbsoluteTime _time, int *tzp, struct tm * tm, char **tzn)
{
 time_t time = (time_t) _time;
 struct tm *tx;

 (*__error()) = 0;
 if (tzp != ((void *)0))
  tx = localtime((time_t *) &time);
 else
  tx = gmtime((time_t *) &time);

 if (!tx)
 {
  (*__error()) = PGTYPES_TS_BAD_TIMESTAMP;
  return;
 }

 tm->tm_year = tx->tm_year + 1900;
 tm->tm_mon = tx->tm_mon + 1;
 tm->tm_mday = tx->tm_mday;
 tm->tm_hour = tx->tm_hour;
 tm->tm_min = tx->tm_min;
 tm->tm_sec = tx->tm_sec;
 tm->tm_isdst = tx->tm_isdst;


 tm->tm_gmtoff = tx->tm_gmtoff;
 tm->tm_zone = tx->tm_zone;

 if (tzp != ((void *)0))
 {




  *tzp = -tm->tm_gmtoff;




  if (tzn != ((void *)0))
  {




   do { char * _dst = (*tzn); Size _len = (10 + 1); if (_len > 0) { ((__builtin_object_size (_dst, 0) != (size_t) -1) ? __builtin___strncpy_chk (_dst, (tm->tm_zone), _len, __builtin_object_size (_dst, 2 > 1)) : __inline_strncpy_chk (_dst, (tm->tm_zone), _len)); _dst[_len-1] = '\0'; } } while (0);
   if (strlen(tm->tm_zone) > 10)
    tm->tm_isdst = -1;
  }
 }
 else
  tm->tm_isdst = -1;
# 1117 "dt_common.c"
}

void
GetCurrentDateTime(struct tm * tm)
{
 int tz;

 abstime2tm(time(((void *)0)), &tz, tm, ((void *)0));
}

void
dt2time(double jd, int *hour, int *min, int *sec, fsec_t *fsec)
{

 int64 time;




 time = jd;

 *hour = time / ((int64) 3600000000);
 time -= (*hour) * ((int64) 3600000000);
 *min = time / ((int64) 60000000);
 time -= (*min) * ((int64) 60000000);
 *sec = time / ((int64) 1000000);
 *fsec = time - (*sec * ((int64) 1000000));
# 1152 "dt_common.c"
}
# 1161 "dt_common.c"
static int
DecodeNumberField(int len, char *str, int fmask,
      int *tmask, struct tm * tm, fsec_t *fsec, int *is2digits)
{
 char *cp;





 if ((cp = strchr(str, '.')) != ((void *)0))
 {

  char fstr[63 + 1];





  ((__builtin_object_size (fstr, 0) != (size_t) -1) ? __builtin___strcpy_chk (fstr, (cp + 1), __builtin_object_size (fstr, 2 > 1)) : __inline_strcpy_chk (fstr, (cp + 1)));
  ((__builtin_object_size (fstr + strlen(fstr), 0) != (size_t) -1) ? __builtin___strcpy_chk (fstr + strlen(fstr), "000000", __builtin_object_size (fstr + strlen(fstr), 2 > 1)) : __inline_strcpy_chk (fstr + strlen(fstr), "000000"));
  *(fstr + 6) = '\0';
  *fsec = strtol(fstr, ((void *)0), 10);



  *cp = '\0';
  len = strlen(str);
 }

 else if ((fmask & ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3)))) != ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3))))
 {

  if (len == 8)
  {
   *tmask = ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3)));

   tm->tm_mday = atoi(str + 6);
   *(str + 6) = '\0';
   tm->tm_mon = atoi(str + 4);
   *(str + 4) = '\0';
   tm->tm_year = atoi(str + 0);

   return 2;
  }

  else if (len == 6)
  {
   *tmask = ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3)));
   tm->tm_mday = atoi(str + 4);
   *(str + 4) = '\0';
   tm->tm_mon = atoi(str + 2);
   *(str + 2) = '\0';
   tm->tm_year = atoi(str + 0);
   *is2digits = 1;

   return 2;
  }

  else if (len == 5)
  {
   *tmask = ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3)));
   tm->tm_mday = atoi(str + 2);
   *(str + 2) = '\0';
   tm->tm_mon = 1;
   tm->tm_year = atoi(str + 0);
   *is2digits = 1;

   return 2;
  }
 }


 if ((fmask & ((0x01 << (10)) | (0x01 << (11)) | (0x01 << (12)))) != ((0x01 << (10)) | (0x01 << (11)) | (0x01 << (12))))
 {

  if (len == 6)
  {
   *tmask = ((0x01 << (10)) | (0x01 << (11)) | (0x01 << (12)));
   tm->tm_sec = atoi(str + 4);
   *(str + 4) = '\0';
   tm->tm_min = atoi(str + 2);
   *(str + 2) = '\0';
   tm->tm_hour = atoi(str + 0);

   return 3;
  }

  else if (len == 4)
  {
   *tmask = ((0x01 << (10)) | (0x01 << (11)) | (0x01 << (12)));
   tm->tm_sec = 0;
   tm->tm_min = atoi(str + 2);
   *(str + 2) = '\0';
   tm->tm_hour = atoi(str + 0);

   return 3;
  }
 }

 return -1;
}





static int
DecodeNumber(int flen, char *str, int fmask,
 int *tmask, struct tm * tm, fsec_t *fsec, int *is2digits, bool EuroDates)
{
 int val;
 char *cp;

 *tmask = 0;

 val = strtol(str, &cp, 10);
 if (cp == str)
  return -1;

 if (*cp == '.')
 {




  if (cp - str > 2)
   return DecodeNumberField(flen, str, (fmask | ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3)))),
          tmask, tm, fsec, is2digits);

  *fsec = strtod(cp, &cp);
  if (*cp != '\0')
   return -1;
 }
 else if (*cp != '\0')
  return -1;


 if (flen == 3 && (fmask & (0x01 << (2))) && val >= 1 && val <= 366)
 {
  *tmask = ((0x01 << (15)) | (0x01 << (1)) | (0x01 << (3)));
  tm->tm_yday = val;
  j2date(date2j(tm->tm_year, 1, 1) + tm->tm_yday - 1,
      &tm->tm_year, &tm->tm_mon, &tm->tm_mday);
 }
# 1315 "dt_common.c"
 else if (flen >= 4)
 {
  *tmask = (0x01 << (2));


  if ((fmask & (0x01 << (2))) && !(fmask & (0x01 << (3))) &&
   tm->tm_year >= 1 && tm->tm_year <= 31)
  {
   tm->tm_mday = tm->tm_year;
   *tmask = (0x01 << (3));
  }

  tm->tm_year = val;
 }


 else if ((fmask & (0x01 << (2))) && !(fmask & (0x01 << (1))) && val >= 1 && val <= 12)
 {
  *tmask = (0x01 << (1));
  tm->tm_mon = val;
 }

 else if ((EuroDates || (fmask & (0x01 << (1)))) &&
    !(fmask & (0x01 << (2))) && !(fmask & (0x01 << (3))) &&
    val >= 1 && val <= 31)
 {
  *tmask = (0x01 << (3));
  tm->tm_mday = val;
 }
 else if (!(fmask & (0x01 << (1))) && val >= 1 && val <= 12)
 {
  *tmask = (0x01 << (1));
  tm->tm_mon = val;
 }
 else if (!(fmask & (0x01 << (3))) && val >= 1 && val <= 31)
 {
  *tmask = (0x01 << (3));
  tm->tm_mday = val;
 }





 else if (!(fmask & (0x01 << (2))) && (flen >= 4 || flen == 2))
 {
  *tmask = (0x01 << (2));
  tm->tm_year = val;


  *is2digits = (flen == 2);
 }
 else
  return -1;

 return 0;
}





static int
DecodeDate(char *str, int fmask, int *tmask, struct tm * tm, bool EuroDates)
{
 fsec_t fsec;

 int nf = 0;
 int i,
    len;
 int bc = 0;
 int is2digits = 0;
 int type,
    val,
    dmask = 0;
 char *field[25];


 while (*str != '\0' && nf < 25)
 {

  while (!isalnum((unsigned char) *str))
   str++;

  field[nf] = str;
  if (isdigit((unsigned char) *str))
  {
   while (isdigit((unsigned char) *str))
    str++;
  }
  else if (isalpha((unsigned char) *str))
  {
   while (isalpha((unsigned char) *str))
    str++;
  }


  if (*str != '\0')
   *str++ = '\0';
  nf++;
 }







 *tmask = 0;


 for (i = 0; i < nf; i++)
 {
  if (isalpha((unsigned char) *field[i]))
  {
   type = DecodeSpecial(i, field[i], &val);
   if (type == 8)
    continue;

   dmask = (0x01 << (type));
   switch (type)
   {
    case 1:
     tm->tm_mon = val;
     break;

    case 18:
     bc = (val == 1);
     break;

    default:
     return -1;
   }
   if (fmask & dmask)
    return -1;

   fmask |= dmask;
   *tmask |= dmask;


   field[i] = ((void *)0);
  }
 }


 for (i = 0; i < nf; i++)
 {
  if (field[i] == ((void *)0))
   continue;

  if ((len = strlen(field[i])) <= 0)
   return -1;

  if (DecodeNumber(len, field[i], fmask, &dmask, tm, &fsec, &is2digits, EuroDates) != 0)
   return -1;

  if (fmask & dmask)
   return -1;

  fmask |= dmask;
  *tmask |= dmask;
 }

 if ((fmask & ~((0x01 << (15)) | (0x01 << (5)))) != ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3))))
  return -1;


 if (bc)
 {
  if (tm->tm_year > 0)
   tm->tm_year = -(tm->tm_year - 1);
  else
   return -1;
 }
 else if (is2digits)
 {
  if (tm->tm_year < 70)
   tm->tm_year += 2000;
  else if (tm->tm_year < 100)
   tm->tm_year += 1900;
 }

 return 0;
}







int
DecodeTime(char *str, int *tmask, struct tm * tm, fsec_t *fsec)
{
 char *cp;

 *tmask = ((0x01 << (10)) | (0x01 << (11)) | (0x01 << (12)));

 tm->tm_hour = strtol(str, &cp, 10);
 if (*cp != ':')
  return -1;
 str = cp + 1;
 tm->tm_min = strtol(str, &cp, 10);
 if (*cp == '\0')
 {
  tm->tm_sec = 0;
  *fsec = 0;
 }
 else if (*cp != ':')
  return -1;
 else
 {
  str = cp + 1;
  tm->tm_sec = strtol(str, &cp, 10);
  if (*cp == '\0')
   *fsec = 0;
  else if (*cp == '.')
  {

   char fstr[63 + 1];





   ((__builtin_object_size (fstr, 0) != (size_t) -1) ? __builtin___strncpy_chk (fstr, (cp + 1), 7, __builtin_object_size (fstr, 2 > 1)) : __inline_strncpy_chk (fstr, (cp + 1), 7));
   ((__builtin_object_size (fstr + strlen(fstr), 0) != (size_t) -1) ? __builtin___strcpy_chk (fstr + strlen(fstr), "000000", __builtin_object_size (fstr + strlen(fstr), 2 > 1)) : __inline_strcpy_chk (fstr + strlen(fstr), "000000"));
   *(fstr + 6) = '\0';
   *fsec = strtol(fstr, &cp, 10);




   if (*cp != '\0')
    return -1;
  }
  else
   return -1;
 }



 if (tm->tm_hour < 0 || tm->tm_min < 0 || tm->tm_min > 59 ||
  tm->tm_sec < 0 || tm->tm_sec > 59 || *fsec >= ((int64) 1000000))
  return -1;






 return 0;
}







static int
DecodeTimezone(char *str, int *tzp)
{
 int tz;
 int hr,
    min;
 char *cp;
 int len;


 hr = strtol(str + 1, &cp, 10);


 if (*cp == ':')
  min = strtol(cp + 1, &cp, 10);

 else if (*cp == '\0' && (len = strlen(str)) > 3)
 {
  min = strtol(str + len - 2, &cp, 10);
  if (min < 0 || min >= 60)
   return -1;

  *(str + len - 2) = '\0';
  hr = strtol(str + 1, &cp, 10);
  if (hr < 0 || hr > 13)
   return -1;
 }
 else
  min = 0;

 tz = (hr * 60 + min) * 60;
 if (*str == '-')
  tz = -tz;

 *tzp = -tz;
 return *cp != '\0';
}
# 1620 "dt_common.c"
static int
DecodePosixTimezone(char *str, int *tzp)
{
 int val,
    tz;
 int type;
 char *cp;
 char delim;

 cp = str;
 while (*cp != '\0' && isalpha((unsigned char) *cp))
  cp++;

 if (DecodeTimezone(cp, &tz) != 0)
  return -1;

 delim = *cp;
 *cp = '\0';
 type = DecodeSpecial(25 - 1, str, &val);
 *cp = delim;

 switch (type)
 {
  case 6:
  case 5:
   *tzp = (val * 60) - tz;
   break;

  default:
   return -1;
 }

 return 0;
}
# 1669 "dt_common.c"
int
ParseDateTime(char *timestr, char *lowstr,
     char **field, int *ftype, int *numfields, char **endstr)
{
 int nf = 0;
 char *lp = lowstr;

 *endstr = timestr;

 while (*(*endstr) != '\0')
 {
  field[nf] = lp;


  if (isdigit((unsigned char) *(*endstr)))
  {
   *lp++ = *(*endstr)++;
   while (isdigit((unsigned char) *(*endstr)))
    *lp++ = *(*endstr)++;


   if (*(*endstr) == ':')
   {
    ftype[nf] = 3;
    *lp++ = *(*endstr)++;
    while (isdigit((unsigned char) *(*endstr)) ||
        (*(*endstr) == ':') || (*(*endstr) == '.'))
     *lp++ = *(*endstr)++;
   }

   else if (*(*endstr) == '-' || *(*endstr) == '/' || *(*endstr) == '.')
   {

    char *dp = (*endstr);

    *lp++ = *(*endstr)++;

    if (isdigit((unsigned char) *(*endstr)))
    {
     ftype[nf] = (*dp == '.') ? 0 : 2;
     while (isdigit((unsigned char) *(*endstr)))
      *lp++ = *(*endstr)++;





     if (*(*endstr) == *dp)
     {
      ftype[nf] = 2;
      *lp++ = *(*endstr)++;
      while (isdigit((unsigned char) *(*endstr)) || (*(*endstr) == *dp))
       *lp++ = *(*endstr)++;
     }
    }
    else
    {
     ftype[nf] = 2;
     while (isalnum((unsigned char) *(*endstr)) || (*(*endstr) == *dp))
      *lp++ = pg_tolower((unsigned char) *(*endstr)++);
    }
   }





   else
    ftype[nf] = 0;
  }

  else if (*(*endstr) == '.')
  {
   *lp++ = *(*endstr)++;
   while (isdigit((unsigned char) *(*endstr)))
    *lp++ = *(*endstr)++;

   ftype[nf] = 0;
  }




  else if (isalpha((unsigned char) *(*endstr)))
  {
   ftype[nf] = 1;
   *lp++ = pg_tolower((unsigned char) *(*endstr)++);
   while (isalpha((unsigned char) *(*endstr)))
    *lp++ = pg_tolower((unsigned char) *(*endstr)++);





   if (*(*endstr) == '-' || *(*endstr) == '/' || *(*endstr) == '.')
   {
    char *dp = (*endstr);

    ftype[nf] = 2;
    *lp++ = *(*endstr)++;
    while (isdigit((unsigned char) *(*endstr)) || *(*endstr) == *dp)
     *lp++ = *(*endstr)++;
   }
  }

  else if (isspace((unsigned char) *(*endstr)))
  {
   (*endstr)++;
   continue;
  }

  else if (*(*endstr) == '+' || *(*endstr) == '-')
  {
   *lp++ = *(*endstr)++;

   while (isspace((unsigned char) *(*endstr)))
    (*endstr)++;

   if (isdigit((unsigned char) *(*endstr)))
   {
    ftype[nf] = 4;
    *lp++ = *(*endstr)++;
    while (isdigit((unsigned char) *(*endstr)) ||
        (*(*endstr) == ':') || (*(*endstr) == '.'))
     *lp++ = *(*endstr)++;
   }

   else if (isalpha((unsigned char) *(*endstr)))
   {
    ftype[nf] = 6;
    *lp++ = pg_tolower((unsigned char) *(*endstr)++);
    while (isalpha((unsigned char) *(*endstr)))
     *lp++ = pg_tolower((unsigned char) *(*endstr)++);
   }

   else
    return -1;
  }

  else if (ispunct((unsigned char) *(*endstr)))
  {
   (*endstr)++;
   continue;

  }

  else
   return -1;


  *lp++ = '\0';
  nf++;
  if (nf > 25)
   return -1;
 }

 *numfields = nf;

 return 0;
}
# 1851 "dt_common.c"
int
DecodeDateTime(char **field, int *ftype, int nf,
      int *dtype, struct tm * tm, fsec_t *fsec, bool EuroDates)
{
 int fmask = 0,
    tmask,
    type;
 int ptype = 0;
 int i;
 int val;
 int mer = 2;
 int haveTextMonth = 0;
 int is2digits = 0;
 int bc = 0;
 int t = 0;
 int *tzp = &t;





 *dtype = 2;
 tm->tm_hour = 0;
 tm->tm_min = 0;
 tm->tm_sec = 0;
 *fsec = 0;

 tm->tm_isdst = -1;
 if (tzp != ((void *)0))
  *tzp = 0;

 for (i = 0; i < nf; i++)
 {
  switch (ftype[i])
  {
   case 2:





    if (ptype == 31)
    {
     char *cp;
     int val;

     if (tzp == ((void *)0))
      return -1;

     val = strtol(field[i], &cp, 10);
     if (*cp != '-')
      return -1;

     j2date(val, &tm->tm_year, &tm->tm_mon, &tm->tm_mday);

     if (DecodeTimezone(cp, tzp) != 0)
      return -1;

     tmask = ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3))) | ((0x01 << (10)) | (0x01 << (11)) | (0x01 << (12))) | (0x01 << (5));
     ptype = 0;
     break;
    }






    else if (((fmask & ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3)))) == ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3))))
       || (ptype != 0))
    {

     if (tzp == ((void *)0))
      return -1;

     if (isdigit((unsigned char) *field[i]) || ptype != 0)
     {
      char *cp;

      if (ptype != 0)
      {

       if (ptype != 3)
        return -1;
       ptype = 0;
      }






      if ((fmask & ((0x01 << (10)) | (0x01 << (11)) | (0x01 << (12)))) == ((0x01 << (10)) | (0x01 << (11)) | (0x01 << (12))))
       return -1;

      if ((cp = strchr(field[i], '-')) == ((void *)0))
       return -1;


      if (DecodeTimezone(cp, tzp) != 0)
       return -1;
      *cp = '\0';





      if ((ftype[i] = DecodeNumberField(strlen(field[i]), field[i], fmask,
            &tmask, tm, fsec, &is2digits)) < 0)
       return -1;





      tmask |= (0x01 << (5));
     }
     else
     {
      if (DecodePosixTimezone(field[i], tzp) != 0)
       return -1;

      ftype[i] = 4;
      tmask = (0x01 << (5));
     }
    }
    else if (DecodeDate(field[i], fmask, &tmask, tm, EuroDates) != 0)
     return -1;
    break;

   case 3:
    if (DecodeTime(field[i], &tmask, tm, fsec) != 0)
     return -1;






    if (tm->tm_hour > 24 ||
     (tm->tm_hour == 24 && (tm->tm_min > 0 || tm->tm_sec > 0)))
     return -1;
    break;

   case 4:
    {
     int tz;

     if (tzp == ((void *)0))
      return -1;

     if (DecodeTimezone(field[i], &tz) != 0)
      return -1;





     if (i > 0 && (fmask & (0x01 << (5))) != 0 &&
      ftype[i - 1] == 4 &&
      isalpha((unsigned char) *field[i - 1]))
     {
      *tzp -= tz;
      tmask = 0;
     }
     else
     {
      *tzp = tz;
      tmask = (0x01 << (5));
     }
    }
    break;

   case 0:





    if (ptype != 0)
    {
     char *cp;
     int val;

     val = strtol(field[i], &cp, 10);





     if (*cp == '.')
      switch (ptype)
      {
       case 31:
       case 3:
       case 18:
        break;
       default:
        return 1;
        break;
      }
     else if (*cp != '\0')
      return -1;

     switch (ptype)
     {
      case 25:
       tm->tm_year = val;
       tmask = (0x01 << (2));
       break;

      case 23:





       if ((fmask & (0x01 << (1))) != 0 &&
        (fmask & (0x01 << (10))) != 0)
       {
        tm->tm_min = val;
        tmask = (0x01 << (11));
       }
       else
       {
        tm->tm_mon = val;
        tmask = (0x01 << (1));
       }
       break;

      case 21:
       tm->tm_mday = val;
       tmask = (0x01 << (3));
       break;

      case 20:
       tm->tm_hour = val;
       tmask = (0x01 << (10));
       break;

      case 19:
       tm->tm_min = val;
       tmask = (0x01 << (11));
       break;

      case 18:
       tm->tm_sec = val;
       tmask = (0x01 << (12));
       if (*cp == '.')
       {
        double frac;

        frac = strtod(cp, &cp);
        if (*cp != '\0')
         return -1;

        *fsec = frac * 1000000;



       }
       break;

      case 4:
       tmask = (0x01 << (5));
       if (DecodeTimezone(field[i], tzp) != 0)
        return -1;
       break;

      case 31:



       tmask = ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3)));
       j2date(val, &tm->tm_year, &tm->tm_mon, &tm->tm_mday);

       if (*cp == '.')
       {
        double time;

        time = strtod(cp, &cp);
        if (*cp != '\0')
         return -1;

        tmask |= ((0x01 << (10)) | (0x01 << (11)) | (0x01 << (12)));

        dt2time((time * ((int64) 86400000000)), &tm->tm_hour, &tm->tm_min, &tm->tm_sec, fsec);



       }
       break;

      case 3:

       if ((ftype[i] = DecodeNumberField(strlen(field[i]), field[i], (fmask | ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3)))),
            &tmask, tm, fsec, &is2digits)) < 0)
        return -1;

       if (tmask != ((0x01 << (10)) | (0x01 << (11)) | (0x01 << (12))))
        return -1;
       break;

      default:
       return -1;
       break;
     }

     ptype = 0;
     *dtype = 2;
    }
    else
    {
     char *cp;
     int flen;

     flen = strlen(field[i]);
     cp = strchr(field[i], '.');


     if (cp != ((void *)0) && !(fmask & ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3)))))
     {
      if (DecodeDate(field[i], fmask, &tmask, tm, EuroDates) != 0)
       return -1;
     }

     else if (cp != ((void *)0) && flen - strlen(cp) > 2)
     {





      if ((ftype[i] = DecodeNumberField(flen, field[i], fmask,
            &tmask, tm, fsec, &is2digits)) < 0)
       return -1;
     }
     else if (flen > 4)
     {
      if ((ftype[i] = DecodeNumberField(flen, field[i], fmask,
            &tmask, tm, fsec, &is2digits)) < 0)
       return -1;
     }

     else if (DecodeNumber(flen, field[i], fmask,
          &tmask, tm, fsec, &is2digits, EuroDates) != 0)
      return -1;
    }
    break;

   case 1:
   case 6:
    type = DecodeSpecial(i, field[i], &val);
    if (type == 8)
     continue;

    tmask = (0x01 << (type));
    switch (type)
    {
     case 0:
      switch (val)
      {
       case 12:
        tmask = (((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3))) | ((0x01 << (10)) | (0x01 << (11)) | (0x01 << (12))) | (0x01 << (5)));
        *dtype = 2;
        GetCurrentDateTime(tm);
        break;

       case 13:
        tmask = ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3)));
        *dtype = 2;
        GetCurrentDateTime(tm);
        j2date(date2j(tm->tm_year, tm->tm_mon, tm->tm_mday) - 1,
         &tm->tm_year, &tm->tm_mon, &tm->tm_mday);
        tm->tm_hour = 0;
        tm->tm_min = 0;
        tm->tm_sec = 0;
        break;

       case 14:
        tmask = ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3)));
        *dtype = 2;
        GetCurrentDateTime(tm);
        tm->tm_hour = 0;
        tm->tm_min = 0;
        tm->tm_sec = 0;
        break;

       case 15:
        tmask = ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3)));
        *dtype = 2;
        GetCurrentDateTime(tm);
        j2date(date2j(tm->tm_year, tm->tm_mon, tm->tm_mday) + 1,
         &tm->tm_year, &tm->tm_mon, &tm->tm_mday);
        tm->tm_hour = 0;
        tm->tm_min = 0;
        tm->tm_sec = 0;
        break;

       case 16:
        tmask = (((0x01 << (10)) | (0x01 << (11)) | (0x01 << (12))) | (0x01 << (5)));
        *dtype = 2;
        tm->tm_hour = 0;
        tm->tm_min = 0;
        tm->tm_sec = 0;
        if (tzp != ((void *)0))
         *tzp = 0;
        break;

       default:
        *dtype = val;
      }

      break;

     case 1:





      if ((fmask & (0x01 << (1))) && !haveTextMonth &&
       !(fmask & (0x01 << (3))) && tm->tm_mon >= 1 && tm->tm_mon <= 31)
      {
       tm->tm_mday = tm->tm_mon;
       tmask = (0x01 << (3));
      }
      haveTextMonth = 1;
      tm->tm_mon = val;
      break;

     case 7:





      tmask |= (0x01 << (6));
      tm->tm_isdst = 1;
      if (tzp == ((void *)0))
       return -1;
      *tzp += val * 60;
      break;

     case 6:





      tmask |= (0x01 << (5));
      tm->tm_isdst = 1;
      if (tzp == ((void *)0))
       return -1;
      *tzp = val * 60;
      ftype[i] = 4;
      break;

     case 5:
      tm->tm_isdst = 0;
      if (tzp == ((void *)0))
       return -1;
      *tzp = val * 60;
      ftype[i] = 4;
      break;

     case 8:
      break;

     case 9:
      mer = val;
      break;

     case 18:
      bc = (val == 1);
      break;

     case 16:
      tm->tm_wday = val;
      break;

     case 17:
      tmask = 0;
      ptype = val;
      break;

     case 23:





      tmask = 0;


      if ((fmask & ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3)))) != ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3))))
       return -1;







      if (i >= nf - 1 ||
       (ftype[i + 1] != 0 &&
        ftype[i + 1] != 3 &&
        ftype[i + 1] != 2))
       return -1;

      ptype = val;
      break;

     default:
      return -1;
    }
    break;

   default:
    return -1;
  }

  if (tmask & fmask)
   return -1;
  fmask |= tmask;
 }


 if (bc)
 {
  if (tm->tm_year > 0)
   tm->tm_year = -(tm->tm_year - 1);
  else
   return -1;
 }
 else if (is2digits)
 {
  if (tm->tm_year < 70)
   tm->tm_year += 2000;
  else if (tm->tm_year < 100)
   tm->tm_year += 1900;
 }

 if (mer != 2 && tm->tm_hour > 12)
  return -1;
 if (mer == 0 && tm->tm_hour == 12)
  tm->tm_hour = 0;
 else if (mer == 1 && tm->tm_hour != 12)
  tm->tm_hour += 12;


 if (*dtype == 2)
 {
  if ((fmask & ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3)))) != ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3))))
   return ((fmask & ((0x01 << (10)) | (0x01 << (11)) | (0x01 << (12)))) == ((0x01 << (10)) | (0x01 << (11)) | (0x01 << (12)))) ? 1 : -1;





  if (tm->tm_mday < 1 || tm->tm_mday > day_tab[(((tm->tm_year) % 4) == 0 && (((tm->tm_year) % 100) != 0 || ((tm->tm_year) % 400) == 0))][tm->tm_mon - 1])
   return -1;






  if ((fmask & ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3)))) == ((0x01 << (2)) | (0x01 << (1)) | (0x01 << (3))) && tzp != ((void *)0) && !(fmask & (0x01 << (5))) && (fmask & (0x01 << (7))))
   return -1;
 }

 return 0;
}






static char *
find_end_token(char *str, char *fmt)
{
# 2449 "dt_common.c"
 char *end_position = ((void *)0);
 char *next_percent,
      *subst_location = ((void *)0);
 int scan_offset = 0;
 char last_char;


 if (!*fmt)
 {
  end_position = fmt;
  return end_position;
 }


 while (fmt[scan_offset] == '%' && fmt[scan_offset + 1])
 {






  scan_offset += 2;
 }
 next_percent = strchr(fmt + scan_offset, '%');
 if (next_percent)
 {







  subst_location = next_percent;
  while (*(subst_location - 1) == ' ' && subst_location - 1 > fmt + scan_offset)
   subst_location--;
  last_char = *subst_location;
  *subst_location = '\0';
# 2501 "dt_common.c"
  while (*str == ' ')
   str++;
  end_position = strstr(str, fmt + scan_offset);
  *subst_location = last_char;
 }
 else
 {




  end_position = str + strlen(str);
 }
 if (!end_position)
 {
# 2530 "dt_common.c"
  if ((fmt + scan_offset)[0] == ' ' && fmt + scan_offset + 1 == subst_location)
   end_position = str + strlen(str);
 }
 return end_position;
}

static int
pgtypes_defmt_scan(union un_fmt_comb * scan_val, int scan_type, char **pstr, char *pfmt)
{





 char last_char;
 int err = 0;
 char *pstr_end;
 char *strtol_end = ((void *)0);

 while (**pstr == ' ')
  pstr++;
 pstr_end = find_end_token(*pstr, pfmt);
 if (!pstr_end)
 {

  return 1;
 }
 last_char = *pstr_end;
 *pstr_end = '\0';

 switch (scan_type)
 {
  case PGTYPES_TYPE_UINT:





   while (**pstr == ' ')
    (*pstr)++;
   (*__error()) = 0;
   scan_val->uint_val = (unsigned int) strtol(*pstr, &strtol_end, 10);
   if ((*__error()))
    err = 1;
   break;
  case PGTYPES_TYPE_UINT_LONG:
   while (**pstr == ' ')
    (*pstr)++;
   (*__error()) = 0;
   scan_val->luint_val = (unsigned long int) strtol(*pstr, &strtol_end, 10);
   if ((*__error()))
    err = 1;
   break;
  case PGTYPES_TYPE_STRING_MALLOCED:
   scan_val->str_val = pgtypes_strdup(*pstr);
   if (scan_val->str_val == ((void *)0))
    err = 1;
   break;
 }
 if (strtol_end && *strtol_end)
  *pstr = strtol_end;
 else
  *pstr = pstr_end;
 *pstr_end = last_char;
 return err;
}


int PGTYPEStimestamp_defmt_scan(char **, char *, timestamp *, int *, int *, int *,
       int *, int *, int *, int *);

int
PGTYPEStimestamp_defmt_scan(char **str, char *fmt, timestamp * d,
       int *year, int *month, int *day,
       int *hour, int *minute, int *second,
       int *tz)
{
 union un_fmt_comb scan_val;
 int scan_type;

 char *pstr,
      *pfmt,
      *tmp;
 int err = 1;
 unsigned int j;
 struct tm tm;

 pfmt = fmt;
 pstr = *str;

 while (*pfmt)
 {
  err = 0;
  while (*pfmt == ' ')
   pfmt++;
  while (*pstr == ' ')
   pstr++;
  if (*pfmt != '%')
  {
   if (*pfmt == *pstr)
   {
    pfmt++;
    pstr++;
   }
   else
   {

    err = 1;
    return err;
   }
   continue;
  }

  pfmt++;
  switch (*pfmt)
  {
   case 'a':
    pfmt++;





    err = 1;
    j = 0;
    while (pgtypes_date_weekdays_short[j])
    {
     if (strncmp(pgtypes_date_weekdays_short[j], pstr,
        strlen(pgtypes_date_weekdays_short[j])) == 0)
     {

      err = 0;
      pstr += strlen(pgtypes_date_weekdays_short[j]);
      break;
     }
     j++;
    }
    break;
   case 'A':

    pfmt++;
    err = 1;
    j = 0;
    while (days[j])
    {
     if (strncmp(days[j], pstr, strlen(days[j])) == 0)
     {

      err = 0;
      pstr += strlen(days[j]);
      break;
     }
     j++;
    }
    break;
   case 'b':
   case 'h':
    pfmt++;
    err = 1;
    j = 0;
    while (months[j])
    {
     if (strncmp(months[j], pstr, strlen(months[j])) == 0)
     {

      err = 0;
      pstr += strlen(months[j]);
      *month = j + 1;
      break;
     }
     j++;
    }
    break;
   case 'B':

    pfmt++;
    err = 1;
    j = 0;
    while (pgtypes_date_months[j])
    {
     if (strncmp(pgtypes_date_months[j], pstr, strlen(pgtypes_date_months[j])) == 0)
     {

      err = 0;
      pstr += strlen(pgtypes_date_months[j]);
      *month = j + 1;
      break;
     }
     j++;
    }
    break;
   case 'c':

    break;
   case 'C':
    pfmt++;
    scan_type = PGTYPES_TYPE_UINT;
    err = pgtypes_defmt_scan(&scan_val, scan_type, &pstr, pfmt);
    *year = scan_val.uint_val * 100;
    break;
   case 'd':
   case 'e':
    pfmt++;
    scan_type = PGTYPES_TYPE_UINT;
    err = pgtypes_defmt_scan(&scan_val, scan_type, &pstr, pfmt);
    *day = scan_val.uint_val;
    break;
   case 'D':





    pfmt++;
    tmp = pgtypes_alloc(strlen("%m/%d/%y") + strlen(pstr) + 1);
    ((__builtin_object_size (tmp, 0) != (size_t) -1) ? __builtin___strcpy_chk (tmp, "%m/%d/%y", __builtin_object_size (tmp, 2 > 1)) : __inline_strcpy_chk (tmp, "%m/%d/%y"));
    ((__builtin_object_size (tmp, 0) != (size_t) -1) ? __builtin___strcat_chk (tmp, pfmt, __builtin_object_size (tmp, 2 > 1)) : __inline_strcat_chk (tmp, pfmt));
    err = PGTYPEStimestamp_defmt_scan(&pstr, tmp, d, year, month, day, hour, minute, second, tz);
    free(tmp);
    return err;
   case 'm':
    pfmt++;
    scan_type = PGTYPES_TYPE_UINT;
    err = pgtypes_defmt_scan(&scan_val, scan_type, &pstr, pfmt);
    *month = scan_val.uint_val;
    break;
   case 'y':
   case 'g':
    pfmt++;
    scan_type = PGTYPES_TYPE_UINT;
    err = pgtypes_defmt_scan(&scan_val, scan_type, &pstr, pfmt);
    if (*year < 0)
    {

     *year = scan_val.uint_val;
    }
    else
     *year += scan_val.uint_val;
    if (*year < 100)
     *year += 1900;
    break;
   case 'G':

    pfmt++;
    scan_type = PGTYPES_TYPE_UINT;
    err = pgtypes_defmt_scan(&scan_val, scan_type, &pstr, pfmt);
    *year = scan_val.uint_val;
    break;
   case 'H':
   case 'I':
   case 'k':
   case 'l':
    pfmt++;
    scan_type = PGTYPES_TYPE_UINT;
    err = pgtypes_defmt_scan(&scan_val, scan_type, &pstr, pfmt);
    *hour += scan_val.uint_val;
    break;
   case 'j':
    pfmt++;
    scan_type = PGTYPES_TYPE_UINT;
    err = pgtypes_defmt_scan(&scan_val, scan_type, &pstr, pfmt);






    break;
   case 'M':
    pfmt++;
    scan_type = PGTYPES_TYPE_UINT;
    err = pgtypes_defmt_scan(&scan_val, scan_type, &pstr, pfmt);
    *minute = scan_val.uint_val;
    break;
   case 'n':
    pfmt++;
    if (*pstr == '\n')
     pstr++;
    else
     err = 1;
    break;
   case 'p':
    err = 1;
    pfmt++;
    if (strncmp(pstr, "am", 2) == 0)
    {
     *hour += 0;
     err = 0;
     pstr += 2;
    }
    if (strncmp(pstr, "a.m.", 4) == 0)
    {
     *hour += 0;
     err = 0;
     pstr += 4;
    }
    if (strncmp(pstr, "pm", 2) == 0)
    {
     *hour += 12;
     err = 0;
     pstr += 2;
    }
    if (strncmp(pstr, "p.m.", 4) == 0)
    {
     *hour += 12;
     err = 0;
     pstr += 4;
    }
    break;
   case 'P':
    err = 1;
    pfmt++;
    if (strncmp(pstr, "AM", 2) == 0)
    {
     *hour += 0;
     err = 0;
     pstr += 2;
    }
    if (strncmp(pstr, "A.M.", 4) == 0)
    {
     *hour += 0;
     err = 0;
     pstr += 4;
    }
    if (strncmp(pstr, "PM", 2) == 0)
    {
     *hour += 12;
     err = 0;
     pstr += 2;
    }
    if (strncmp(pstr, "P.M.", 4) == 0)
    {
     *hour += 12;
     err = 0;
     pstr += 4;
    }
    break;
   case 'r':
    pfmt++;
    tmp = pgtypes_alloc(strlen("%I:%M:%S %p") + strlen(pstr) + 1);
    ((__builtin_object_size (tmp, 0) != (size_t) -1) ? __builtin___strcpy_chk (tmp, "%I:%M:%S %p", __builtin_object_size (tmp, 2 > 1)) : __inline_strcpy_chk (tmp, "%I:%M:%S %p"));
    ((__builtin_object_size (tmp, 0) != (size_t) -1) ? __builtin___strcat_chk (tmp, pfmt, __builtin_object_size (tmp, 2 > 1)) : __inline_strcat_chk (tmp, pfmt));
    err = PGTYPEStimestamp_defmt_scan(&pstr, tmp, d, year, month, day, hour, minute, second, tz);
    free(tmp);
    return err;
   case 'R':
    pfmt++;
    tmp = pgtypes_alloc(strlen("%H:%M") + strlen(pstr) + 1);
    ((__builtin_object_size (tmp, 0) != (size_t) -1) ? __builtin___strcpy_chk (tmp, "%H:%M", __builtin_object_size (tmp, 2 > 1)) : __inline_strcpy_chk (tmp, "%H:%M"));
    ((__builtin_object_size (tmp, 0) != (size_t) -1) ? __builtin___strcat_chk (tmp, pfmt, __builtin_object_size (tmp, 2 > 1)) : __inline_strcat_chk (tmp, pfmt));
    err = PGTYPEStimestamp_defmt_scan(&pstr, tmp, d, year, month, day, hour, minute, second, tz);
    free(tmp);
    return err;
   case 's':
    pfmt++;
    scan_type = PGTYPES_TYPE_UINT_LONG;
    err = pgtypes_defmt_scan(&scan_val, scan_type, &pstr, pfmt);

    {
     struct tm *tms;
     time_t et = (time_t) scan_val.luint_val;

     tms = gmtime(&et);

     if (tms)
     {
      *year = tms->tm_year + 1900;
      *month = tms->tm_mon + 1;
      *day = tms->tm_mday;
      *hour = tms->tm_hour;
      *minute = tms->tm_min;
      *second = tms->tm_sec;
     }
     else
      err = 1;
    }
    break;
   case 'S':
    pfmt++;
    scan_type = PGTYPES_TYPE_UINT;
    err = pgtypes_defmt_scan(&scan_val, scan_type, &pstr, pfmt);
    *second = scan_val.uint_val;
    break;
   case 't':
    pfmt++;
    if (*pstr == '\t')
     pstr++;
    else
     err = 1;
    break;
   case 'T':
    pfmt++;
    tmp = pgtypes_alloc(strlen("%H:%M:%S") + strlen(pstr) + 1);
    ((__builtin_object_size (tmp, 0) != (size_t) -1) ? __builtin___strcpy_chk (tmp, "%H:%M:%S", __builtin_object_size (tmp, 2 > 1)) : __inline_strcpy_chk (tmp, "%H:%M:%S"));
    ((__builtin_object_size (tmp, 0) != (size_t) -1) ? __builtin___strcat_chk (tmp, pfmt, __builtin_object_size (tmp, 2 > 1)) : __inline_strcat_chk (tmp, pfmt));
    err = PGTYPEStimestamp_defmt_scan(&pstr, tmp, d, year, month, day, hour, minute, second, tz);
    free(tmp);
    return err;
   case 'u':
    pfmt++;
    scan_type = PGTYPES_TYPE_UINT;
    err = pgtypes_defmt_scan(&scan_val, scan_type, &pstr, pfmt);
    if (scan_val.uint_val < 1 || scan_val.uint_val > 7)
     err = 1;
    break;
   case 'U':
    pfmt++;
    scan_type = PGTYPES_TYPE_UINT;
    err = pgtypes_defmt_scan(&scan_val, scan_type, &pstr, pfmt);
    if (scan_val.uint_val > 53)
     err = 1;
    break;
   case 'V':
    pfmt++;
    scan_type = PGTYPES_TYPE_UINT;
    err = pgtypes_defmt_scan(&scan_val, scan_type, &pstr, pfmt);
    if (scan_val.uint_val < 1 || scan_val.uint_val > 53)
     err = 1;
    break;
   case 'w':
    pfmt++;
    scan_type = PGTYPES_TYPE_UINT;
    err = pgtypes_defmt_scan(&scan_val, scan_type, &pstr, pfmt);
    if (scan_val.uint_val > 6)
     err = 1;
    break;
   case 'W':
    pfmt++;
    scan_type = PGTYPES_TYPE_UINT;
    err = pgtypes_defmt_scan(&scan_val, scan_type, &pstr, pfmt);
    if (scan_val.uint_val > 53)
     err = 1;
    break;
   case 'x':
   case 'X':

    break;
   case 'Y':
    pfmt++;
    scan_type = PGTYPES_TYPE_UINT;
    err = pgtypes_defmt_scan(&scan_val, scan_type, &pstr, pfmt);
    *year = scan_val.uint_val;
    break;
   case 'z':
    pfmt++;
    scan_type = PGTYPES_TYPE_STRING_MALLOCED;
    err = pgtypes_defmt_scan(&scan_val, scan_type, &pstr, pfmt);
    if (!err)
    {
     err = DecodeTimezone(scan_val.str_val, tz);
     free(scan_val.str_val);
    }
    break;
   case 'Z':
    pfmt++;
    scan_type = PGTYPES_TYPE_STRING_MALLOCED;
    err = pgtypes_defmt_scan(&scan_val, scan_type, &pstr, pfmt);





    for (j = 0; !err && j < szdatetktbl; j++)
    {
     if (pg_strcasecmp(datetktbl[j].token, scan_val.str_val) == 0)
     {





      *tz = -15 * 60 * datetktbl[j].value;
      break;
     }
    }
    free(scan_val.str_val);
    break;
   case '+':

    break;
   case '%':
    pfmt++;
    if (*pstr == '%')
     pstr++;
    else
     err = 1;
    break;
   default:
    err = 1;
  }
 }
 if (!err)
 {
  if (*second < 0)
   *second = 0;
  if (*minute < 0)
   *minute = 0;
  if (*hour < 0)
   *hour = 0;
  if (*day < 0)
  {
   err = 1;
   *day = 1;
  }
  if (*month < 0)
  {
   err = 1;
   *month = 1;
  }
  if (*year < 0)
  {
   err = 1;
   *year = 1970;
  }

  if (*second > 59)
  {
   err = 1;
   *second = 0;
  }
  if (*minute > 59)
  {
   err = 1;
   *minute = 0;
  }
  if (*hour > 24 ||
   (*hour == 24 && (*minute > 0 || *second > 0)))
  {
   err = 1;
   *hour = 0;
  }
  if (*month > 12)
  {
   err = 1;
   *month = 1;
  }
  if (*day > day_tab[(((*year) % 4) == 0 && (((*year) % 100) != 0 || ((*year) % 400) == 0))][*month - 1])
  {
   *day = day_tab[(((*year) % 4) == 0 && (((*year) % 100) != 0 || ((*year) % 400) == 0))][*month - 1];
   err = 1;
  }

  tm.tm_sec = *second;
  tm.tm_min = *minute;
  tm.tm_hour = *hour;
  tm.tm_mday = *day;
  tm.tm_mon = *month;
  tm.tm_year = *year;

  tm2timestamp(&tm, 0, tz, d);
 }
 return err;
}

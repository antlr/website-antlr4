print "digraph T {"
for x in range(1000000):
	print "x%d -> y%d" % (x,x)
print "}"

Most taken from:
http://www.graphviz.org/Gallery.php

some from here:
http://www.linuxjournal.com/article/7275

generated some huffman trees here:
http://huffman.ooz.ie/

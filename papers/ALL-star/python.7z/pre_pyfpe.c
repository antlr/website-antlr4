# 1 "pyfpe.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "pyfpe.c"
# 1 "/Users/parrt/tmp/Python-3.3.1/pyconfig.h" 1
# 2 "pyfpe.c" 2
# 1 "/Users/parrt/tmp/Python-3.3.1/Include/pyfpe.h" 1
# 3 "pyfpe.c" 2
# 19 "pyfpe.c"
double
PyFPE_dummy(void *dummy)
{
 return 1.0;
}

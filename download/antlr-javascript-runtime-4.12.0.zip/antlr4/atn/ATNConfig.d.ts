import { ATNState } from "../state";

export declare class ATNConfig {
    state: ATNState;
}

import {SyntaxTree} from "./SyntaxTree";

export declare class ParseTree extends SyntaxTree {
    getText(): string;
}

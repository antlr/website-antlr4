import {Tree} from "./Tree";

export declare class SyntaxTree extends Tree {}

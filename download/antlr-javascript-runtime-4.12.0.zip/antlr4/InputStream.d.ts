export declare class InputStream {
    constructor(data: string);
    constructor(data: string, decodeToUnicodeCodePoints: boolean);
}

export declare class DFA {
    constructor(ds: any, index: number);
    toLexerString(): string;
}


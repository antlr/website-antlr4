import {ATN} from "../atn";

export declare class ATNState {
    atn: ATN;
    stateNumber: number;
}

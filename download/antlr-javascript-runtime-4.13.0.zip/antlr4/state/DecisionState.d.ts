import {ATNState} from "./index";

export declare class DecisionState extends ATNState {
    decision: number;
    nonGreedy: boolean;
}

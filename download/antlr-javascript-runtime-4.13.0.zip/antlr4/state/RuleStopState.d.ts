import {ATNState} from "./index";

export declare class RuleStopState extends ATNState {

}

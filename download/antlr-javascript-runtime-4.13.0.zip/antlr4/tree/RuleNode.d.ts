import {ParseTree} from "./ParseTree";

export declare abstract class RuleNode extends ParseTree {

}

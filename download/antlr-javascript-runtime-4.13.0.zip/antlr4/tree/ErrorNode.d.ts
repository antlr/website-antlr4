import {TerminalNode} from "./TerminalNode";

export declare class ErrorNode extends TerminalNode {

}

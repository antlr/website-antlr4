export declare function stringToCharArray(str: string) : Uint16Array;

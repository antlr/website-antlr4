export declare function arrayToString(value: any[]) : string;

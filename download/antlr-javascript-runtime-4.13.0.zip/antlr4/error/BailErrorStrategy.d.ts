import {DefaultErrorStrategy} from "./DefaultErrorStrategy";

export declare class BailErrorStrategy extends DefaultErrorStrategy {

    constructor();

}

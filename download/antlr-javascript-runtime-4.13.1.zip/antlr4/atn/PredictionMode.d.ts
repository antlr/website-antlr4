export declare class PredictionMode {
    static SLL: number;
    static LL: number;
    static LL_EXACT_AMBIG_DETECTION: number;
}

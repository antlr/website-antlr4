export declare class PredictionContextCache {

}

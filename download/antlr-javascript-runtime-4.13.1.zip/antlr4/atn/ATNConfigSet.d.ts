import {ATNConfig} from "./ATNConfig";

export declare class ATNConfigSet {
    configs: ATNConfig[];
}

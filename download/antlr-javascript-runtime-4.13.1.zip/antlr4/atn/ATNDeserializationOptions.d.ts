export declare class ATNDeserializationOptions {
    readOnly?: boolean;
    verifyATN?: boolean;
    generateRuleBypassTransitions?: boolean;

}

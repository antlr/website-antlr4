export declare class TokenSource {

}

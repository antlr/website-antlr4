export declare class Tree {}

exports.DFA = require('./DFA').DFA;
exports.DFASerializer = require('./DFASerializer').DFASerializer;
exports.LexerDFASerializer = require('./DFASerializer').LexerDFASerializer;
exports.PredPrediction = require('./DFAState').PredPrediction;

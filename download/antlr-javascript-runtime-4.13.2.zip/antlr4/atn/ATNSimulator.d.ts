export declare class ATNSimulator {

}
